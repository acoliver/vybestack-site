import express, { Request, Response, Application } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database, Statement } from 'sql.js';

// Get the directory name for resolving static paths
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express app
const app: Application = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Initialize database
let db: Database | null = null;
let server: any = null;

const dbPath = path.resolve(__dirname, '../data/submissions.sqlite');
const schemaPath = path.resolve(__dirname, '../db/schema.sql');

async function initDatabase() {
  // In a test environment, we won't be able to load the WASM file from CDN
  // So we use a simplified initialization that works in tests
  if (process.env.NODE_ENV === 'test') {
    const SQL = await initSqlJs();
    db = new SQL.Database();
  } else {
    const SQL = await initSqlJs({ 
      locateFile: (file: string) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.0/${file}` 
    });
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create new one
    let dbData: Buffer | undefined;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }
    
    db = new SQL.Database(dbData);
  }
  
  // Apply schema
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.run(schema);
}

// Validation functions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateForm(data: FormData) {
  const errors: string[] = [];
  
  // Check required fields
  const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 
                         'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  for (const field of requiredFields) {
    if (!data[field as keyof FormData] || data[field as keyof FormData].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1')} is required`);
    }
  }
  
  // Validate email with simple regex
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Email must be valid');
  }
  
  // Validate phone number (accept international formats)
  if (data.phone && !/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  // Validate postal code (alphanumeric, allowing international formats)
  if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.push('Postal code format is invalid');
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body as FormData;
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: formData });
  }
  
  // Insert data into database
  if (db) {
    const stmt: Statement = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Write database back to file
    if (process.env.NODE_ENV !== 'test') {
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(dbPath, buffer);
    }
  }
  
  // Redirect to thank you page with first name
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function closeServer() {
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db && process.env.NODE_ENV !== 'test') {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    db.close();
    console.log('Database closed');
  }
}

process.on('SIGTERM', closeServer);
process.on('SIGINT', closeServer);

// Initialize and start server
async function startServer() {
  try {
    await initDatabase();
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export { app, server };