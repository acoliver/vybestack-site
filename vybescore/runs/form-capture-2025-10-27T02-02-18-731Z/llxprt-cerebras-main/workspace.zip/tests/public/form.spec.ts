import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

// Need to start the server before importing app
let app: any;
let server: any;

beforeAll(async () => {
  // Ensure clean state for tests
  const dbPath = path.resolve('data', 'submissions.sqlite');
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Dynamically import the app and server after cleaning up db
  const module = await import('../../src/server.js');
  app = module.app;
  server = module.server;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    // Check that all form fields are present in response
    expect(response.text).toContain('id="firstName"');
    expect(response.text).toContain('id="lastName"');
    expect(response.text).toContain('id="streetAddress"');
    expect(response.text).toContain('id="city"');
    expect(response.text).toContain('id="stateProvince"');
    expect(response.text).toContain('id="postalCode"');
    expect(response.text).toContain('id="country"');
    expect(response.text).toContain('id="email"');
    expect(response.text).toContain('id="phone"');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: 'SW1A 1AA',  // Using UK postal code format as a test
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'  // Using UK phone format as a test
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
      
    expect(response.headers.location).toBe('/thank-you?firstName=John');
  });
});