/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies: Set<Subject<unknown>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
  ;(globalThis as Record<string, unknown>).__activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Clear previous dependencies
  observer.dependencies.clear()
  
  const previous = activeObserver
  activeObserver = observer
  ;(globalThis as Record<string, unknown>).__activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    
    // After updating, notify all observers of this computed if it has any
    if ((observer as Record<string, unknown>).notifyObservers) {
      ((observer as Record<string, unknown>).notifyObservers as () => void)()
    }
  } finally {
    activeObserver = previous
    ;(globalThis as Record<string, unknown>).__activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Create a copy to avoid issues with observers being removed during iteration
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    if (subject.observers.has(observer)) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}

export function trackDependency<T>(subject: Subject<T>): void {
  if (activeObserver && !activeObserver.dependencies.has(subject as Subject<unknown>)) {
    activeObserver.dependencies.add(subject as Subject<unknown>)
    subject.observers.add(activeObserver as Observer<unknown>)
  }
}

export function cleanupObserver(observer: ObserverR): void {
  // Remove observer from all subjects it depends on
  for (const subject of observer.dependencies) {
    subject.observers.delete(observer as Observer<unknown>)
  }
  observer.dependencies.clear()
}
