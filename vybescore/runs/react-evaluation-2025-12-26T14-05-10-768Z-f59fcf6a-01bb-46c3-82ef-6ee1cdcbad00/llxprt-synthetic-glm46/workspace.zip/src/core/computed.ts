/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Make the observer work like a subject so it can be observed
  const observerData = {
    observers: new Set<Observer<unknown>>(),
    addObserver: (observer: Observer<unknown>) => {
      observerData.observers.add(observer)
    },
    removeObserver: (observer: Observer<unknown>) => {
      observerData.observers.delete(observer)
    },
    notifyObservers: () => {
      // Create a copy to avoid issues with observers being removed during iteration
      const observers = Array.from(observerData.observers)
      for (const observer of observers) {
        if (observerData.observers.has(observer)) {
          updateObserver(observer as Observer<unknown>)
        }
      }
    }
  }
  
  // Store observer data on the observer instance
  ;(o as Record<string, unknown>).observers = observerData.observers
  ;(o as Record<string, unknown>).addObserver = observerData.addObserver
  ;(o as Record<string, unknown>).removeObserver = observerData.removeObserver
  ;(o as Record<string, unknown>).notifyObservers = observerData.notifyObservers
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter = (): T => {
    const currentObserver = getActiveObserver()

    // If called during re-computation, just read the current value
    if (currentObserver === o) {
      return o.value!
    }
    
    // If called without an active observer, compute the value
    if (!currentObserver) {
      o.value = o.updateFn(undefined as T)
      return o.value!
    }
    
// Track this computed as a dependency for the current observer
    if (!currentObserver.dependencies.has(o as unknown as Subject<unknown>)) {
      currentObserver.dependencies.add(o as unknown as Subject<unknown>)
      const observerData = o as Record<string, unknown>
      if (observerData.observers && observerData.addObserver) {
        (observerData.addObserver as (observer: Observer<unknown>) => void)(currentObserver as Observer<unknown>)
      }
    }
    
    return o.value!
  }

  // Store getter on observer for cleanup reference
  ;(o as Record<string, unknown>).getter = getter
  
  return getter
}
