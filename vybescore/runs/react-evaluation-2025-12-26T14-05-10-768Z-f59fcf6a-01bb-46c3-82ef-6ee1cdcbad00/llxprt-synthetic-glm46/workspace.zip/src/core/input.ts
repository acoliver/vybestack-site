/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Subject-as-observer pattern for computed values
      if (!currentObserver.dependencies.has(s as Subject<T> as Subject<unknown>)) {
        currentObserver.dependencies.add(s as Subject<T> as Subject<unknown>)
        s.observers.add(currentObserver as Observer<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value should be updated based on equal function
    const shouldUpdate = s.equalFn ? !s.equalFn(s.value, nextValue) : s.value !== nextValue
    
    if (shouldUpdate) {
      s.value = nextValue
      notifyObservers(s)
    }
    
    return s.value
  }

  return [read, write]
}
