import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Test 1: Simple dependency (in callback context) ===')
const [input1, setInput1] = createInput(1)
const timesTwo = createComputed(() => input1() * 2)
createCallback(() => { console.log('Callback: input', input1(), '=>', timesTwo()) })
setInput1(3)
setInput1(5)

console.log('\n=== Test 2: Multiple computed dependencies (callback context) ===')
const [input2, setInput2] = createInput(1)
const timesTwo2 = createComputed(() => input2() * 2)
const timesThirty = createComputed(() => input2() * 30)
const sum = createComputed(() => timesTwo2() + timesThirty())
createCallback(() => console.log('Sum callback:', sum()))
setInput2(3)

console.log('\n=== Test 3: Callback test ===')
const [input3, setInput3] = createInput(1)
const output = createComputed(() => input3() + 1)
let value = 0
createCallback(() => { value = output(); console.log('Callback executed, value is now:', value) })
console.log('Before set to 3, value:', value)
setInput3(3)
console.log('After set to 3, value:', value)

console.log('\n=== Test 4: Multiple callbacks ===')
const [input4, setInput4] = createInput(11)
const output4 = createComputed(() => input4() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => values1.push(output4()))
const values2: number[] = []
createCallback(() => values2.push(output4()))

setInput4(31)
console.log('Values1:', values1)
console.log('Values2:', values2)

unsubscribe1()
setInput4(41)
console.log('Values1 after unsubscribe:', values1)
console.log('Values2 after unsubscribe:', values2)