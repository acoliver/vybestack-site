/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create equality function
  let equalFn: EqualFn<T>
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (equal === false) {
    equalFn = () => false
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = (a, b) => a === b // Default behavior
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      // Use provided prevValue if available
      const currentValue = prevValue === undefined ? value : prevValue
      const newValue = updateFn(currentValue)
      // Check if value actually changed using equality function
      if (equalFn && o.value !== undefined && equalFn(o.value, newValue)) {
        return o.value
      }
      return newValue
    },
  }
  
  // Compute initial value if not provided
  if (o.value === undefined) {
    try {
      o.value = updateFn(value)
    } catch (e) {
      // If updateFn fails, use the provided value as fallback
    }
  }
  
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      o.observer = currentObserver
    }
    
    // Recalculate when dependencies may have changed
    updateObserver(o)
    
    return updateFn()
  }
  
  // Register observer to track dependencies
  updateObserver(o)
  
  return getter
}