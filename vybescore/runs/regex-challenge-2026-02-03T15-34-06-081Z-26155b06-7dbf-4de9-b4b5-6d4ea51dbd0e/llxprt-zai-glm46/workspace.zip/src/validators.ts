export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical formats like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows letters, digits, dots, hyphens, underscores in local part
  // - Rejects consecutive dots, leading/trailing dots
  // - Rejects underscores in domain
  // - Allows multiple @ signs (like name@tag@example.co.uk)
  const emailRegex = /^(?!.*\.\.)[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]?(?:@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9])+\.[a-zA-Z]{2,}$/;
  
  // Additional checks for no trailing dot in any segment
  if (value.includes('.@') || value.endsWith('.')) {
    return false;
  }
  
  // Check no underscores in domain parts (after @)
  const domainParts = value.split('@').slice(1);
  for (const part of domainParts) {
    if (part.includes('_')) {
      return false;
    }
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix. Area code cannot start with 0 or 1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Currently, extensions are not supported, but we keep the parameter for API compatibility
  if (options?.allowExtensions) {
    // Extension handling could be added here in the future
  }
  
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must be at least 10 digits (basic number) or 11 with country code
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }
  
  // Validate format with regex for common patterns
  const phoneRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Supports both landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Try to match the full pattern
  const fullPattern = /^(?:(?:\+54)?(?:0)?(?:9)?)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(fullPattern);
  
  if (!match) {
    return false;
  }
  
  const [, area, subscriber] = match;
  
  // Check if country code is present
  const hasCountry = cleaned.startsWith('+54') || cleaned.startsWith('54');
  
  // Check if trunk prefix is present
  const hasTrunk = cleaned.includes('0');
  
  // If country code is omitted, trunk prefix is required
  if (!hasCountry && !hasTrunk && cleaned.length > 0) {
    // The number might not start with 0 if we've stripped it
    // Check original value
    const originalHasTrunk = value.includes('0');
    if (!originalHasTrunk) {
      return false;
    }
  }
  
  // Area code must be 2-4 digits (already enforced by regex)
  const areaCode = area;
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits (already enforced by regex)
  const subscriberNum = subscriber;
  if (subscriberNum.length < 6 || subscriberNum.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and strange names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least 2 characters, start with a letter
  const nameRegex = /^\p{L}[\p{L}'\-\s]*\p{L}$/u;
  
  // Must be at least 2 characters
  if (value.trim().length < 2) {
    return false;
  }
  
  // Check for digits or symbols (excluding allowed apostrophe, hyphen, space)
  const hasInvalidChars = /[\d"`~!@#$%^&*()_+=[\]{}|\\:;<>,./?]/.test(value);
  if (hasInvalidChars) {
    return false;
  }
  
  // Reject if contains only special characters or looks like X Æ A-12
  // Check for standalone numbers or number sequences
  const hasNumberSequence = /\d{2,}/.test(value);
  if (hasNumberSequence) {
    return false;
  }
  
  // Check for strange combinations like Æ (allowed but should be part of a name)
  // The main regex should handle this - Æ is a unicode letter
  
  return nameRegex.test(value.trim());
}

/**
 * Validates credit card numbers using Luhn checksum and format checks.
 * Supports Visa, Mastercard, and American Express.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits (standard card lengths)
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  // Check valid prefixes for Visa (4), Mastercard (51-55, 2221-2720), AmEx (34, 37)
  const visaRegex = /^4/;
  const mastercardRegex = /^5[1-5]|^2[2-7][0-2][0-9]/;
  const amexRegex = /^3[47]/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Verify length based on card type
  if (visaRegex.test(cleaned) && (cleaned.length !== 13 && cleaned.length !== 16)) {
    return false;
  }
  if (mastercardRegex.test(cleaned) && cleaned.length !== 16) {
    return false;
  }
  if (amexRegex.test(cleaned) && cleaned.length !== 15) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
