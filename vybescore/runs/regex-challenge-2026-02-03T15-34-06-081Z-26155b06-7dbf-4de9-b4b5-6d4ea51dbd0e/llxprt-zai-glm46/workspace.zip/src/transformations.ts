/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations that shouldn't trigger sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'eg', 'ie', 'approx', 'no', 'dept', 'univ'];
  
  // Split into sentences using . ? ! as delimiters
  const sentences: string[] = [];
  let current = '';
  
  for (let i = 0; i < text.length; i++) {
    current += text[i];
    
    // Check if we're at a sentence ending
    if (/[.?!]/.test(text[i])) {
      // Look ahead to see if there's a space or end of string
      const nextChar = text[i + 1];
      
      // Check if this might be an abbreviation
      const beforePeriod = current.slice(0, -1).trim().split(/\s+/).pop() || '';
      const isAbbr = abbreviations.some(abbr => beforePeriod.toLowerCase() === abbr.toLowerCase());
      
      if (!nextChar || nextChar === ' ' || nextChar === '\n' || nextChar === '\t') {
        if (!isAbbr) {
          sentences.push(current.trim());
          current = '';
        }
      }
    }
  }
  
  // Add any remaining text
  if (current.trim()) {
    sentences.push(current.trim());
  }
  
  // Capitalize first letter of each sentence and join with single space
  const result = sentences
    .map(sentence => {
      if (sentence.length === 0) return '';
      // Find first letter and capitalize it
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    })
    .join(' ');
  
  // Collapse multiple spaces (but preserve newlines as single space for simplicity)
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Extracts all URLs from the given text.
 * Removes trailing punctuation from URLs.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. URLs
  // Matches the URL but excludes trailing punctuation
  const urlPattern = /https?:\/\/[^\s<>"{}|\\^`[\]]+|www\.[^\s<>"{}|\\^`[\]]+/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation (.,;!?:,)
    url = url.replace(/[.,;!?,:(){}[\]]+$/, '');
    // Remove trailing quotes
    url = url.replace(/["']+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Replaces all http:// URLs with https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, being careful not to match https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://...
 * When path begins with /docs/, rewrites host to docs.example.com
 * Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 * Always upgrades the scheme to https://.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = [
      /\bcgi-bin\b/i,
      /[?&=[\]]/,  // query strings
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    const shouldSkipHostRewrite = dynamicHints.some(hint => hint.test(path));
    
    // Always upgrade scheme
    const newScheme = 'https://';
    
    // Rewrite host if path starts with /docs/ and no dynamic hints
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      return newScheme + 'docs.example.com' + path;
    }
    
    // Otherwise just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > (daysInMonth[month] || 31)) {
    return 'N/A';
  }
  
  return year;
}
