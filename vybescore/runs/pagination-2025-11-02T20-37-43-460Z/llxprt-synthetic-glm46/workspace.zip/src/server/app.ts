import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Parse to numbers. Keep undefined if not provided or if it's an empty string.
      let page: number | undefined;
      let limit: number | undefined;
      
      if (pageParam !== undefined && pageParam !== '') {
        page = Number(pageParam);
        if (isNaN(page)) {
          throw new Error('Page parameter must be a number');
        }
      }
      
      if (limitParam !== undefined && limitParam !== '') {
        limit = Number(limitParam);
        if (isNaN(limit)) {
          throw new Error('Limit parameter must be a number');
        }
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error occurred while fetching inventory';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
