import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100; // Set a reasonable maximum limit to prevent excessive queries

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

/**
 * Validates pagination parameters and throws an error with an informative message if validation fails.
 */
function validatePaginationParams(page: number | undefined, limit: number | undefined): void {
  // Validate page parameter
  if (page !== undefined) {
    if (isNaN(page)) {
      throw new Error('Page parameter must be a number');
    }
    if (page < 1) {
      throw new Error('Page parameter must be greater than 0');
    }
  }

  // Validate limit parameter
  if (limit !== undefined) {
    if (isNaN(limit)) {
      throw new Error('Limit parameter must be a number');
    }
    if (limit < 1) {
      throw new Error('Limit parameter must be greater than 0');
    }
    if (limit > MAX_LIMIT) {
      throw new Error(`Limit parameter cannot exceed ${MAX_LIMIT}`);
    }
  }
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  // Validate pagination parameters
  validatePaginationParams(options.page, options.limit);

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  // FIX: offset should be (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
