import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({
  currentPage,
  hasNext,
  onNextPage,
  onPreviousPage,
  isLoading
}: {
  currentPage: number;
  hasNext: boolean;
  onNextPage: () => void;
  onPreviousPage: () => void;
  isLoading: boolean;
}) {
  return (
    <div style={{ marginTop: '1rem' }}>
      <button
        onClick={onPreviousPage}
        disabled={currentPage <= 1 || isLoading}
        aria-label="Previous page"
      >
        Previous
      </button>
      <span style={{ margin: '0 1rem' }}>Page {currentPage}</span>
      <button
        onClick={onNextPage}
        disabled={!hasNext || isLoading}
        aria-label="Next page"
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handleNextPage = () => {
    setCurrentPage((prev) => prev + 1);
  };

  const handlePreviousPage = () => {
    setCurrentPage((prev) => Math.max(1, prev - 1));
  };

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory items found.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={data.page}
        hasNext={data.hasNext}
        onNextPage={handleNextPage}
        onPreviousPage={handlePreviousPage}
        isLoading={false} // Not loading since we already checked status above
      />
    </section>
  );
}