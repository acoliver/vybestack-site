import express from 'express';
import fs from 'fs';
import path from 'path';
import createSqlFactory from 'sql.js';

const port = process.env.PORT || 3535;
const app = express();

// Middleware setup
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Database setup
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

// Initialize SQLite database with sql.js
let db: import('sql.js').Database | null = null;

async function initDatabase() {
  try {
    const SQLFactory = await createSqlFactory({
      locateFile: (file: string) => {
        return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
      },
    });

    let dbBuffer: Uint8Array | null = null;
    const { Database } = SQLFactory;

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      if (fileBuffer) {
        db = new Database(new Uint8Array(fileBuffer));
      }
    } else {
      // Create new database with schema
      db = new Database();
      const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
      db.run(schema);
      dbBuffer = db.export();
      if (dbBuffer) {
        fs.writeFileSync(DB_PATH, Buffer.from(dbBuffer));
      }
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to file
function saveDatabase() {
  if (db) {
    try {
      const dbBuffer = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(dbBuffer));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading @
  const phoneRegex = /^@?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.replace(/[^\d]/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

// Validation middleware
function validateForm(req: express.Request, res: express.Response, next: express.NextFunction) {
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
  const errors: string[] = [];

  if (!validateRequired(firstName)) {
    errors.push('First name is required');
  }

  if (!validateRequired(lastName)) {
    errors.push('Last name is required');
  }

  if (!validateRequired(streetAddress)) {
    errors.push('Street address is required');
  }

  if (!validateRequired(city)) {
    errors.push('City is required');
  }

  if (!validateRequired(stateProvince)) {
    errors.push('State / Province / Region is required');
  }

  if (!validateRequired(postalCode)) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(postalCode)) {
    errors.push('Invalid postal code format');
  }

  if (!validateRequired(country)) {
    errors.push('Country is required');
  }

  if (!validateRequired(email)) {
    errors.push('Email is required');
  } else if (!validateEmail(email)) {
    errors.push('Invalid email format');
  }

  if (!validateRequired(phone)) {
    errors.push('Phone number is required');
  } else if (!validatePhone(phone)) {
    errors.push('Invalid phone number format');
  }

  if (errors.length > 0) {
    res.render('form', { 
      errors, 
      values: req.body as FormData
    });
    return;
  }

  next();
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', validateForm, (req, res) => {
  if (!db) {
    res.status(500).send('Database not available');
    return;
  }

  try {
    const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
    
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone]);
    stmt.free();
    
    // Save database to file
    saveDatabase();
    
    // Store first name for thank you page
    req.app.locals.firstName = firstName;
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Database error occurred');
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = (req.app.locals.firstName as string) || 'Friend';
  res.render('thank-you', { firstName });
});

// Set up EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start the server
async function startServer() {
  await initDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Types
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}
