declare module 'sql.js' {
  interface DatabaseResult {
    columns: string[];
    values: unknown[][];
  }

  export class Database {
    constructor(data?: ArrayBuffer | Uint8Array);
    run(sql: string, ...params: unknown[]): DatabaseResult;
    prepare(sql: string): PreparedStatement;
    export(): Uint8Array;
    close(): void;
  }
  
  export class PreparedStatement {
    run(...params: unknown[]): DatabaseResult;
    free(): void;
  }
  
  export interface SqlJsOptions {
    locateFile?: (file: string) => string;
  }
  
  function createSqlFactory(config?: SqlJsOptions): Promise<{
    Database: typeof Database;
  }>;
  
  export default createSqlFactory;
}