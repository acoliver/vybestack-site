import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('page');
    expect(response.body).toHaveProperty('limit');
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
    expect(response.body).toHaveProperty('items');
  });

  it('returns correct default pagination (page 1, limit 5)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns second page correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.items[0].id).toBe(6);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns last page correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.items[0].id).toBe(11);
    expect(response.body.hasNext).toBe(false);
  });

  it('returns empty page beyond available data', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=4&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(4);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(0);
    expect(response.body.hasNext).toBe(false);
  });

  it('rejects non-numeric page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });

  it('rejects negative page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });

  it('rejects zero page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });

  it('rejects non-numeric limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });

  it('rejects negative limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });

  it('rejects zero limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });

  it('rejects excessive limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body).toHaveProperty('error');
  });

  it('respects custom limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=10');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(10);
    expect(response.body.items.length).toBe(10);
    expect(response.body.hasNext).toBe(true);
  });
});
