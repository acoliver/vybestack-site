const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Basic validation: check for invalid characters
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Normalize padding: add missing padding if needed
  const normalizedInput = normalizePadding(input);

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Normalize Base64 padding by adding the required '=' characters.
 */
function normalizePadding(input: string): string {
  // Remove any existing padding and add the correct amount
  const withoutPadding = input.replace(/=+$/, '');
  const paddingLength = (4 - (withoutPadding.length % 4)) % 4;
  return withoutPadding + '='.repeat(paddingLength);
}
