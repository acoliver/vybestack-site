import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    if (pageParam !== undefined) {
      if (pageParam === '' || isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a number' });
      }
      if (page !== undefined && (page <= 0 || !Number.isInteger(page))) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
    }

    if (limitParam !== undefined) {
      if (limitParam === '' || isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a number' });
      }
      if (limit !== undefined && (limit <= 0 || !Number.isInteger(limit))) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }
      if (limit !== undefined && limit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: maximum value is 100' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
