export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for common patterns including +tags.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || value.length > 254) return false;
  
  // Basic email regex with support for +tags and various TLDs
  const emailRegex = /^[a-zA-Z0-9]+([._+-][a-zA-Z0-9]+)*@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Local part checks
  const [localPart] = value.split('@');
  if (localPart.length > 64) return false;
  
  // Domain part checks
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) return false;
  if (domainPart.includes('..')) return false;
  
  // Local part checks
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  if (localPart.includes('.-') || localPart.includes('-.')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting formats like (212) 555-7890, 212-555-7890, 2125557890, optional +1.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have either 10 digits (standard) or 11 digits (with country code)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    const areaCode = digitsOnly.substring(1, 4);
    // Area codes can't start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  } else if (digitsOnly.length === 10) {
    const areaCode = digitsOnly.substring(0, 3);
    // Area codes can't start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  } else {
    return false;
  }
  
  // Format validation - check if the format is valid
  const usPhoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  if (!usPhoneRegex.test(value)) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers supporting landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Clean the input by removing spaces and hyphens
  const cleanValue = value.replace(/[ -]/g, '');
  
  // Test multiple patterns for Argentine phone numbers
  // Pattern 1: +54 [9] [area code] [subscriber number]
  // Pattern 2: 0[area code] [subscriber number]
  const pattern1 = /^\+54?9?([1-9]\d{1,3})(\d{6,8})$/;
  const pattern2 = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  let match;
  if (pattern1.test(cleanValue)) {
    match = cleanValue.match(pattern1);
  } else if (pattern2.test(cleanValue)) {
    match = cleanValue.match(pattern2);
  } else {
    // Try the version with spaces
    const patternWithSpaces = /^(\+54)?\s*(9)?\s*0?([1-9]\d{1,3})\s*(\d{6,8})$/;
    if (patternWithSpaces.test(value)) {
      match = value.match(patternWithSpaces);
      // Shift indices if using this pattern
      if (match) {
        match = [null, null, match[3], match[4]]; // Rearrange to match the other patterns
      }
    }
  }
  
  if (!match) return false;
  
  const areaCode = match[1] || '';
  const subscriberNumber = match[2] || '';
  
  // Area code must be 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and Elon Musk style names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Name regex: allows unicode letters (including accented characters), apostrophes, hyphens, and spaces
  const nameRegex = /^[\u00C0-\u017Fa-zA-Z\'\-\s]+$/;
  if (!nameRegex.test(value)) return false;
  
  // Check that the name doesn't start or end with special characters
  if (value.match(/^[\s\'\-]|[\s\'\-]$/)) return false;
  
  // Check for consecutive special characters
  if (value.match(/\'{2,}|-{2,}|\s{2,}|[\'\-]\s|[\'\-]\'|[\-\s]-/)) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx with prefix/length checks and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{12}))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the number matches any card type pattern
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to run the Luhn checksum algorithm.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Start from the rightmost digit and move left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}