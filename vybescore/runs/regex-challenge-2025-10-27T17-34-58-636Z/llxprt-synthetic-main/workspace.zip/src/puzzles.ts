/**
 * Finds words starting with the given prefix but excluding the specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matching words
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  const exceptionsSet = new Set(exceptions.map(w => w.toLowerCase()));
  
  return matches
    .filter(word => !exceptionsSet.has(word.toLowerCase()))
    .filter((word, index, self) => self.indexOf(word) === index); // Remove duplicates
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match digit followed by token
  // but not at the start of the string
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  return matches;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter, one lowercase letter, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string' || value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter, one lowercase letter, one digit, and one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (e.g., abab, abcabc, 123123)
  // We use a regex to detect repeated patterns of 2 or more characters
  const repeatedPatternRegex = /(.{2,})\1/;
  if (repeatedPatternRegex.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // First check for IPv4 addresses to exclude them
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Regex.test(value)) {
    // Check if this also looks like IPv6 (it shouldn't, but we'll be sure)
    return false;
  }
  
  // IPv6 patterns
  // Standard form with 8 groups of 1-4 hex digits separated by colons
  const standardIPv6Regex = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed form with ::
  const compressedIPv6Regex = /\b([0-9a-fA-F]{1,4}:)*:(:[0-9a-fA-F]{1,4})*\b/;
  
  // Mixed form (IPv6 addresses with embedded IPv4)
  const mixedIPv6Regex = /\b([0-9a-fA-F]{1,4}:){6}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check for any IPv6 pattern
  if (standardIPv6Regex.test(value) || compressedIPv6Regex.test(value) || mixedIPv6Regex.test(value)) {
    return true;
  }
  
  return false;
}