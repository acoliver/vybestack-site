/**
 * Capitalizes the first character of each sentence, inserts exactly one space between sentences,
 * and collapses extra spaces while preserving abbreviations where possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Lowercase everything first for consistency, then capitalize
  let normalizedText = text.toLowerCase();
  
  // Capitalize the first character
  if (normalizedText.length > 0) {
    normalizedText = normalizedText[0].toUpperCase() + normalizedText.slice(1);
  }
  
  // Replace the sentence pattern: punctuation followed by space and lowercase letter
  normalizedText = normalizedText.replace(/([.?!])\s+([a-z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Also handle missing space after punctuation
  normalizedText = normalizedText.replace(/([.?!])([a-z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Collapse multiple spaces to a single space
  normalizedText = normalizedText.replace(/ {2,}/g, ' ');
  
  return normalizedText;
}

/**
 * Extracts URLs from text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern
  // Matches http(s)://, domain names with subdomains, optional ports, paths, query strings, and fragments
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])+)?(?:#(?:[\w.])+)?)?/g;
  
  // Find all URLs in the text
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    return url.replace(/[.,;:!'"?)\]\}]+$/g, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs by upgrading to HTTPS and moving docs paths to docs.example.com when appropriate.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Pattern to match URLs with example.com
  const urlPattern = /https?:\/\/(?:www\.)?example\.com(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, path = '') => {
    // Always upgrade to HTTPS
    let newUrl = 'https://';
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic segments or legacy extensions
      const dynamicSegments = /\/cgi-bin|\?|=|&|\.(jsp|php|asp|aspx|do|cgi|pl|py)/;
      
      if (!dynamicSegments.test(path)) {
        // Rewrite host to docs.example.com
        newUrl += 'docs.example.com';
      } else {
        // Keep example.com but upgrade scheme
        newUrl += 'example.com';
      }
    } else {
      // Keep example.com but upgrade scheme
      newUrl += 'example.com';
    }
    
    return newUrl + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings or returns 'N/A' for invalid dates.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Date format: mm/dd/yyyy
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string for return
    
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  
  // Check day range based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Simple leap year check
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  // Adjust February for leap years
  if (month === 2 && isLeapYear(year)) {
    daysInMonth[1] = 29;
  }
  
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}