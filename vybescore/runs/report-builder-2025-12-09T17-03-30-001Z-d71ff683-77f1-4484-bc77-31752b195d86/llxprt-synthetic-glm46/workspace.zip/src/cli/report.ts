#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: 'markdown' | 'text';
  outputFile?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const outputFile = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    inputFile,
    format,
    outputFile,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object' || Array.isArray(data)) {
    throw new Error('Invalid JSON: expected an object');
  }

  const record = data as Record<string, unknown>;
  
  if (!record.title || typeof record.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }
  
  if (!record.summary || typeof record.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(record.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }
  
  for (const entry of record.entries) {
    if (!entry || typeof entry !== 'object' || Array.isArray(entry)) {
      throw new Error('Invalid entry: expected an object');
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (!entryRecord.label || typeof entryRecord.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid "label" field');
    }
    
    if (typeof entryRecord.amount !== 'number') {
      throw new Error('Invalid entry: missing or invalid "amount" field');
    }
  }
  
  return {
    title: record.title,
    summary: record.summary,
    entries: record.entries,
  } as ReportData;
}

function main() {
  try {
    const args = parseArguments();
    
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.inputFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading or parsing ${args.inputFile}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    const reportData: ReportData = validateReportData(jsonData);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    let output: string;
    if (args.format === 'markdown') {
      output = markdownFormatter.format(reportData, options);
    } else {
      output = textFormatter.format(reportData, options);
    }
    
    if (args.outputFile) {
      try {
        writeFileSync(args.outputFile, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing to ${args.outputFile}: ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
    process.exit(0);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
