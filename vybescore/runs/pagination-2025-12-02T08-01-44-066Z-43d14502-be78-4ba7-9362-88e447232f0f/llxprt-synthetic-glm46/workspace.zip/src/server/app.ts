import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    let page: number | undefined;
    if (pageParam === undefined) {
      page = 1; // Default to page 1
    } else {
      const parsed = Number(pageParam);
      if (isNaN(parsed) || parsed <= 0 || !Number.isInteger(parsed)) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      }
      page = parsed;
    }

    let limit: number | undefined;
    if (limitParam === undefined) {
      limit = 5; // Default limit
    } else {
      const parsed = Number(limitParam);
      if (isNaN(parsed) || parsed <= 0 || !Number.isInteger(parsed) || parsed > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer not exceeding 100.' });
      }
      limit = parsed;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
