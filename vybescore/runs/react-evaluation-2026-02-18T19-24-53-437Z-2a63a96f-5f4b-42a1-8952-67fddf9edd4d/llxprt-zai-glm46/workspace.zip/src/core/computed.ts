/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create the observer
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track observers that depend on this computed value
  const dependentObservers: Array<Observer<unknown>> = []
  
  // Initial computation to establish dependencies and get initial value
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    // When this computed is accessed, register the current observer (if any)
    // to be notified when this computed's dependencies change
    const observer = getActiveObserver()
    if (observer) {
      // Store the observer so we can notify it when our dependencies change
      const fullObserver = observer as Observer<unknown>
      if (!dependentObservers.includes(fullObserver)) {
        dependentObservers.push(fullObserver)
      }
    }
    return o.value!
  }
  
  // Wrap the updateObserver to re-compute when dependencies change
  // and notify dependent observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    // Re-run the original update function to get the new value
    const newValue = originalUpdateFn(prevValue)
    o.value = newValue
    
    // Notify all dependent observers
    dependentObservers.forEach(depObserver => {
      // Skip disposed observers
      try {
        updateObserver(depObserver)
      } catch (e) {
        // Observer might be disposed, ignore
      }
    })
    
    return newValue
  }
  
  return getter
}
