/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }
  
  // Support multiple observers by storing them in a list
  // We use a WeakMap to avoid modifying the Subject type
  const observersMap = new WeakMap<Subject<T>, ObserverR[]>()
  observersMap.set(s, [])

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      const observers = observersMap.get(s)!
      if (!observers.includes(observer)) {
        observers.push(observer)
      }
      // Also set the single observer for backwards compatibility
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    
    // Only update observers if value actually changed
    if (prevValue !== nextValue) {
      const observers = observersMap.get(s)!
      observers.forEach(obs => {
        try {
          updateObserver(obs as Observer<unknown>)
        } catch (e) {
          // Observer might be disposed, ignore
        }
      })
    }
    return s.value
  }

  return [read, write]
}
