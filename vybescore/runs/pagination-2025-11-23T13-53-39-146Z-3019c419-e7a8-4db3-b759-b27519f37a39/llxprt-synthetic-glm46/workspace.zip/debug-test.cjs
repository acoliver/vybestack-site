const { createApp } = require('./src/server/app.ts');
const { createDatabase } = require('./src/server/db.ts');

async function testValidation() {
  console.log('Testing limit=0 validation...');
  const db = await createDatabase();
  const app = await createApp(db);
  
  // Simulate Express request object
  const mockReq = {
    query: { limit: '0' }
  };
  
  // Simulate Express response object
  let statusCode;
  let responseBody;
  const mockRes = {
    status: (code) => {
      statusCode = code;
      return mockRes;
    },
    json: (data) => {
      responseBody = data;
    }
  };
  
  // Manually call the route handler
  try {
    const listInventory = require('./src/server/inventoryRepository.ts').listInventory;
    const result = listInventory(db, { pageParam: undefined, limitParam: '0' });
    mockRes.json(result);
  } catch (error) {
    mockRes.status(400).json({ error: error.message });
  }
  
  console.log('Status:', statusCode);
  console.log('Body:', responseBody);
}

testValidation().catch(console.error);