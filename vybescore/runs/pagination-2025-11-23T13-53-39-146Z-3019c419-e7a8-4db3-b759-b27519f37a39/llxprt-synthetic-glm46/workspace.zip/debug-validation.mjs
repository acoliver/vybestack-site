// Direct test of parse and validation when called with strings
import { readFileSync, writeFileSync } from 'fs';

// Extract and test the actual validation function code 
const ts_code = readFileSync('./src/server/inventoryRepository.ts', 'utf8');

// Test with raw strings like they would come from query params
function validatePaginationParams(pageParam, limitParam) {
  const DEFAULT_LIMIT = 5;
  const parsedPage = pageParam ? Number(pageParam) : 1;
  const parsedLimit = limitParam ? Number(limitParam) : DEFAULT_LIMIT;
  
  console.log(`Input: pageParam="${pageParam}", limitParam="${limitParam}"`);
  console.log(`After Number(): parsedPage=${parsedPage}, parsedLimit=${parsedLimit}`);
  console.log(`Types: ${typeof parsedPage}, ${typeof parsedLimit}`);
  
  if (!Number.isInteger(parsedPage) || parsedPage < 1) {
    console.log('Validation failed: Page must be a positive integer');
    throw new Error('Page must be a positive integer');
  }
  
  if (!Number.isInteger(parsedLimit) || parsedLimit < 1) {
    console.log('Validation failed: Limit must be a positive integer');
    throw new Error('Limit must be a positive integer');
  }
  
  if (parsedPage > 1000) {
    console.log('Validation failed: Page number exceeds maximum allowed value');
    throw new Error('Page number exceeds maximum allowed value');
  }
  
  if (parsedLimit > 100) {
    console.log('Validation failed: Limit exceeds maximum allowed value');
    throw new Error('Limit exceeds maximum allowed value');
  }
  
  return { page: parsedPage, limit: parsedLimit };
}

// Test all interesting cases
const testCases = [
  ['0', '5'],  // Page 0 should fail
  [0, '5'],   // Numeric zero should fail
  ['0', 5],   // string zero, numeric limit
  ['', '5'],  // Empty string page
  [null, '5'], // null page
  [undefined, '5'], // undefined page
  [-1, '5'],  // Negative numeric page
  ['-1', '5'], // Negative string page
  ['abc', '5'], // Non-numeric page
  ['   ', '5'], // Whitespace page
  ['.0', '5']  // Zero as float string
];

for (const [page, limit] of testCases) {
  console.log('---');
  try {
    const result = validatePaginationParams(page, limit);
    console.log('[OK] Validation passed:', result);
  } catch (error) {
    console.log(' Validation failed:', error.message);
  }
}