import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationParams(pageParam?: string | undefined, limitParam?: string | undefined): { page: number; limit: number } {
    // Check for the string '0', which should fail validation since 0 is not a valid page
    if (pageParam === '0' || (typeof pageParam === 'number' && pageParam === 0)) {
        throw new Error('Page must be a positive integer');
    }
    
    // Check for the string '0' for limit, which should also fail validation
    if (limitParam === '0' || (typeof limitParam === 'number' && limitParam === 0)) {
        throw new Error('Limit must be a positive integer');
    }
    
    const parsedPage = pageParam && pageParam !== '' && pageParam !== '0' ? Number(pageParam) : 1;
    
    // Don't use default limit if limitParam is explicitly provided (even if it's 0)
    let parsedLimit: number;
    if (limitParam !== undefined && limitParam !== '') {
        parsedLimit = Number(limitParam);
    } else {
        parsedLimit = DEFAULT_LIMIT;
    }
    
    if (!Number.isInteger(parsedPage) || isNaN(parsedPage) || parsedPage < 1) {
        throw new Error('Page must be a positive integer');
    }
    
    if (!Number.isInteger(parsedLimit) || isNaN(parsedLimit) || parsedLimit < 1) {
        throw new Error('Limit must be a positive integer');
    }
    
    if (parsedPage > 1000) {
        throw new Error('Page number exceeds maximum allowed value');
    }
    
    if (parsedLimit > 100) {
        throw new Error('Limit exceeds maximum allowed value');
    }
    
    return { page: parsedPage, limit: parsedLimit };
}

export function listInventory(
  db: Database,
  options: { pageParam?: string | undefined; limitParam?: string | undefined }
): InventoryPage {
  const { page, limit } = validatePaginationParams(options.pageParam, options.limitParam);
  
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // Fixed: use (page - 1) * limit for correct offset calculation
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  // Fixed hasNext logic: There's a next page if the total items on all previous pages 
  // plus the current page's items plus the next page's potential items is less than or equal to total
  const hasNext = offset + rows.length + limit <= total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
