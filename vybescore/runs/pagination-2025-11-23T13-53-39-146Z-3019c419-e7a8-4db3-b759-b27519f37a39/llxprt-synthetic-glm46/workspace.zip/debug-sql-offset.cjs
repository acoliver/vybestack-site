

// Run SQL in-memory test
function sqlQuerySimulation(totalItems, limit, page) {
  console.log(`SQL Query Simulation test: page=${page}, limit=${limit}, total=${totalItems}`);
  
  // Calculate offset
  const offset = (page - 1) * limit;
  const sql = `SELECT * FROM inventory ORDER BY id LIMIT ${limit} OFFSET ${offset}`;
  
  // Simulate query results
  const availableItems = Math.max(0, totalItems - offset);
  const returnedItems = Math.min(limit, availableItems);
  const results = {
    total: totalItems,
    page: page,
    limit: limit,
    items: Array.from({ length: returnedItems }, (_, i) => i + 1 + offset),
    hasNext: false
  };
  
  // Original (broken) logic
  const originalHasNextLogic = (page + 1) * limit < totalItems;
  console.log(`Original hasNext logic: ${(page + 1) * limit} < ${totalItems} => ${originalHasNextLogic}`);
  
  // New (fixed) logic
  const newHasNextLogic = offset + returnedItems + limit <= totalItems;
  console.log(`New hasNext logic: ${offset} + ${returnedItems} + ${limit} <= ${totalItems} => ${newHasNextLogic}`);
  results.hasNext = newHasNextLogic;
  
  console.log(`Result: ${JSON.stringify(results)}`);
  console.log('---');
}

// Test with our case: page=1, limit=5, total=15, returnedItems=5
sqlQuerySimulation(15, 5, 1);

// Test with page=2, limit=5, total=15, returnedItems=5
sqlQuerySimulation(15, 5, 2);

// Test with page=3, limit=5, total=15, returnedItems=5 (final page)
sqlQuerySimulation(15, 5, 3);

// Verify the SQL offset calculation
console.log('SQL Verification:');
console.log(`Page 1: OFFSET ${(1-1)*5}, SELECT up to 5, Expected 5 items`);
console.log(`Page 2: OFFSET ${(2-1)*5}, SELECT up to 5, Expected 5 items`);
console.log(`Page 3: OFFSET ${(3-1)*5}, SELECT up to 5, Expected 5 items`);
console.log(`Remaining items after page 3: ${15 - ((3-1)*5)}`);