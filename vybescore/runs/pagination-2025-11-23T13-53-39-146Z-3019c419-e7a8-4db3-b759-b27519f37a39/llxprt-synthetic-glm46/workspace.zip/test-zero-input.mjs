// Direct test to validate what happens with 0 value
function validateInput(v) {
  console.log(`Input: ${JSON.stringify(v)}`);
  console.log(`Type: ${typeof v}`);
  console.log(`Number(${JSON.stringify(v)}): ${Number(v)}`);
  console.log(`Number.isInteger(Number(v)): ${Number.isInteger(Number(v))}`);
  console.log(`Number(v) < 1: ${Number(v) < 1}`);
  
  const result = Number.isInteger(Number(v)) && Number(v) >= 1;
  console.log(`Is valid page: ${result}`);
  console.log('---');
}

// Test different ways 0 could come in
validateInput('0');           // String "0"
validateInput(0);             // Number 0
validateInput(0.0);           // Float 0.0
validateInput(new String('0')); // String object
validateInput({});            // Empty object (might be query param)
validateInput(undefined);     // Undefined (missing param)
validateInput(null);          // Null
validateInput('');            // Empty string
validateInput([]);            // Empty array
validateInput([0]);           // Array with 0