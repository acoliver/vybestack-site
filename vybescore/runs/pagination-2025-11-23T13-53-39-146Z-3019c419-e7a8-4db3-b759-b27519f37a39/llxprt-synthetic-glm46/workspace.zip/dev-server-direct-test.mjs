import { createApp } from './src/server/app.js';
import request from 'supertest';

async function testServer() {
  const app = await createApp();
  
  console.log('Testing limit=0...');
  const response = await request(app).get('/inventory?limit=0');
  console.log('Status:', response.status);
  console.log('Body:', response.body);
  
  console.log('Testing page=0...');
  const response2 = await request(app).get('/inventory?page=0');
  console.log('Status:', response2.status);
  console.log('Body:', response2.body);
}

testServer().catch(console.error);