// Test validation with strings that might be coming from the URL
function validatePaginationParams(pageParam, limitParam) {
  const DEFAULT_LIMIT = 5;
  const parsedPage = pageParam ? Number(pageParam) : 1;
  const parsedLimit = limitParam ? Number(limitParam) : DEFAULT_LIMIT;
  
  if (!Number.isInteger(parsedPage) || parsedPage < 1) {
    throw new Error('Page must be a positive integer');
  }
  
  if (!Number.isInteger(parsedLimit) || parsedLimit < 1) {
    throw new Error('Limit must be a positive integer');
  }
  
  if (parsedPage > 1000) {
    throw new Error('Page number exceeds maximum allowed value');
  }
  
  if (parsedLimit > 100) {
    throw new Error('Limit exceeds maximum allowed value');
  }
  
  return { page: parsedPage, limit: parsedLimit };
}

// Test cases
try {
  console.log('Testing with pageParam="0", limitParam="5"');
  const result = validatePaginationParams("0", "5");
  console.log('Result:', result);
} catch (error) {
  console.log('Error caught:', error.message);
}

try {
  console.log('Testing with pageParam=undefined, limitParam="5"');
  const result = validatePaginationParams(undefined, "5");
  console.log('Result:', result);
} catch (error) {
  console.log('Error caught:', error.message);
}