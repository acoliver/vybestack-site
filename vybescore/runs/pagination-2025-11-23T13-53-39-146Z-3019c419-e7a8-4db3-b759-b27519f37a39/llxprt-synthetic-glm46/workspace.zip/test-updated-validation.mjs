// Test the updated validation logic
function validatePaginationParams(pageParam, limitParam) {
  const DEFAULT_LIMIT = 5;
  const parsedPage = pageParam && pageParam !== '' ? Number(pageParam) : 1;
  const parsedLimit = limitParam && limitParam !== '' ? Number(limitParam) : DEFAULT_LIMIT;
  
  console.log(`Input: pageParam="${pageParam}", limitParam="${limitParam}"`);
  console.log(`After parsing: parsedPage=${parsedPage}, parsedLimit=${parsedLimit}`);
  
  if (!Number.isInteger(parsedPage) || parsedPage < 1) {
    console.log('Validation failed: Page must be a positive integer');
    throw new Error('Page must be a positive integer');
  }
  
  if (!Number.isInteger(parsedLimit) || parsedLimit < 1) {
    console.log('Validation failed: Limit must be a positive integer');
    throw new Error('Limit must be a positive integer');
  }
  
  return { page: parsedPage, limit: parsedLimit };
}

// Test the problem case
try {
  const result = validatePaginationParams('0', '5');
  console.log('[OK] Validation passed:', result);
} catch (error) {
  console.log(' Validation failed:', error.message);
}

// Test with undefined
try {
  const result = validatePaginationParams(undefined, '5');
  console.log('[OK] Validation passed:', result);
} catch (error) {
  console.log(' Validation failed:', error.message);
}