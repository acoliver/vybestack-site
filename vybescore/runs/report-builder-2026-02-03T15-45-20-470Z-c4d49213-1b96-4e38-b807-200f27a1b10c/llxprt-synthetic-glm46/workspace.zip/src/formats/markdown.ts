import { ReportData, RenderOptions, Renderer, calculateTotal, formatAmount } from '../types.js';

export class MarkdownRenderer implements Renderer {
  render(data: ReportData, options?: RenderOptions): string {
    const { title, summary, entries } = data;
    const includeTotals = options?.includeTotals || false;

    let result = '';

    // Title
    result += `# ${title}\n\n`;

    // Summary
    result += `${summary}\n\n`;

    // Entries section
    result += `## Entries\n`;

    // Entry list
    for (const entry of entries) {
      result += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
    }

    // Total if requested
    if (includeTotals) {
      const total = calculateTotal(entries);
      result += `**Total:** ${formatAmount(total)}\n`;
    }

    return result;
  }
}