// Shared interfaces for the report data model and options

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface RenderOptions {
  includeTotals?: boolean;
}

export interface Renderer {
  render(data: ReportData, options: RenderOptions): string;
}

export interface CliOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals?: boolean;
}

// Validate that the input data conforms to our expected schema
export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Expected valid JSON object');
  }

  const { title, summary, entries } = data as Record<string, unknown>;

  if (typeof title !== 'string') {
    throw new Error('Missing or invalid "title" field');
  }

  if (typeof summary !== 'string') {
    throw new Error('Missing or invalid "summary" field');
  }

  if (!Array.isArray(entries)) {
    throw new Error('Missing or invalid "entries" field');
  }

  for (const [index, entry] of entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected object`);
    }

    const { label, amount } = entry as Record<string, unknown>;

    if (typeof label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "label"`);
    }

    if (typeof amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "amount"`);
    }
  }

  return data as ReportData;
}

// Calculate total amount from entries
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

// Format amount with two decimal places as currency
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}