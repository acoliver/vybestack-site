#!/usr/bin/env node

import * as fs from 'node:fs';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';
import { validateReportData, CliOptions, Renderer } from '../types.js';

// Map format names to renderer instances
const renderers: Record<string, Renderer> = {
  markdown: new MarkdownRenderer(),
  text: new TextRenderer(),
};

// Parse command line arguments
function parseArgs(): { filepath: string; options: CliOptions } {
  const args = process.argv.slice(2);

  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filepath = args[0];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse options
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip next argument since it's the format value
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next argument since it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--format=')) {
      format = arg.substring(9);
    } else if (arg.startsWith('--output=')) {
      outputPath = arg.substring(9);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (!renderers[format]) {
    console.error(`Error: Unsupported format: ${format}`);
    process.exit(1);
  }

  return {
    filepath,
    options: {
      format: format as 'markdown' | 'text',
      outputPath,
      includeTotals,
    },
  };
}

// Main function
async function main(): Promise<void> {
  try {
    const { filepath, options } = parseArgs();

    // Read and parse the JSON file
    const fileContent = fs.readFileSync(filepath, 'utf-8');
    let data: unknown;

    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Failed to parse JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    // Validate the data
    const reportData = validateReportData(data);

    // Get the appropriate renderer
    const renderer = renderers[options.format];

    // Render the report
    const output = renderer.render(reportData, { includeTotals: options.includeTotals });

    // Write to file or stdout
    if (options.outputPath) {
      fs.writeFileSync(options.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

// Run the main function
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
