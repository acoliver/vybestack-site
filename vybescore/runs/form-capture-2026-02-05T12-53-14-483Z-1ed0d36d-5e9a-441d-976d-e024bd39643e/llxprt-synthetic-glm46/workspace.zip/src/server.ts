import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';

// Define Database interface since sql.js doesn't have proper TypeScript definitions
interface Database {
  prepare(sql: string): {
    run(...params: unknown[]): void;
    free(): void;
  };
  run(sql: string): void;
  export(): Uint8Array;
  close(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Database
let db: Database | null = null;
const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

// Initialize database
const initializeDatabase = async (): Promise<void> => {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();

    // Initialize database
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database from', dbPath);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read and execute the schema
      const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db!.run(schema);
        console.log('Created new database with schema from', schemaPath);
      } else {
        // If schema file doesn't exist, create it manually
        const schema = `
          CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            street_address TEXT NOT NULL,
            city TEXT NOT NULL,
            state_province TEXT NOT NULL,
            postal_code TEXT NOT NULL,
            country TEXT NOT NULL,
            email TEXT NOT NULL,
            phone TEXT NOT NULL,
            created_at TEXT NOT NULL DEFAULT (datetime('now'))
          );
        `;
        db!.run(schema);
        console.log('Created new database with manual schema');
      }
      
      // Save the new database
      const data = db!.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Initialized new database at', dbPath);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

// Save database to disk
const saveDatabase = (): void => {
  if (!db) return;
  
  try {
    const data = db!.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to', dbPath);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
};

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Validation functions
const validateSubmission = (body: Record<string, string>): { isValid: boolean; errors: string[] } => {
  const errors: string[] = [];

  // Required fields
  const requiredFields = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    if (!body[field]?.trim()) {
      const fieldName = field.replace(/([A-Z])/g, ' $1').trim();
      errors.push(`${fieldName} is required`);
    }
  }

  // Email validation
  if (body.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(body.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  if (body.phone && !/^\+?[0-9\s()\-.]+$/.test(body.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  // Postal code validation (alphanumeric)
  if (body.postalCode && !/^[a-zA-Z0-9\s]+$/.test(body.postalCode)) {
    errors.push('Postal code can only contain letters and numbers');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const { errors, isValid } = validateSubmission(req.body);

  if (!isValid) {
    return res.status(400).render('form', {
      errors,
      values: req.body,
    });
  }

  try {
    // Insert into database
    const stmt = db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone,
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(req.body.firstName)}`);
  } catch (error) {
    console.error('Error saving submission:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    return res.status(500).render('form', {
      errors,
      values: req.body,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Extract first name from submitted data if available
  // In a real app, this would come from the database
  const firstName = req.query.firstName || 'friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;

const gracefulShutdown = (): void => {
  console.log('Shutting down gracefully...');

  if (server) {
    server.close(() => {
      console.log('Express server closed');

      // Close database connection if it exists
      if (db) {
        db.close();
        console.log('Database connection closed');
      }

      process.exit(0);
    });

    // Force shutdown if it takes too long
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 10000);
  }
};

// Handle SIGTERM
process.on('SIGTERM', gracefulShutdown);

// Start server
const startServer = async (): Promise<void> => {
  try {
    // Initialize database
    await initializeDatabase();
    
    // Start Express server
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();

export default app;
