export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Basic structure check - must have @ and at least one dot in domain
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(trimmed)) {
    return false;
  }
  
  // Check for double dots anywhere
  if (trimmed.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (trimmed.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't start or end with hyphen or dot
  const parts = trimmed.split('@');
  const domain = parts[1];
  
  // Domain can't have underscore
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain parts (after dot) validation
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.length === 0 || part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Allow various US phone formats
  const phonePatterns = [
    /^\+1\s?[2-9]\d{2}[-.\s]?[2-9]\d{2}[-.\s]?\d{4}$/, // +1 212-555-7890
    /^1\s?[2-9]\d{2}[-.\s]?[2-9]\d{2}[-.\s]?\d{4}$/,   // 1 212-555-7890
    /^[2-9]\d{2}[-.\s]?[2-9]\d{2}[-.\s]?\d{4}$/,       // 212-555-7890
    /^\([2-9]\d{2}\)\s?[2-9]\d{2}[-.\s]?\d{4}$/,         // (212) 555-7890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value.trim()));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input - remove spaces and hyphens for digit counting
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Extract digits to analyze structure
  const digits = cleaned.replace(/[^\d]/g, '');
  
  // Country code (+54) present?
  const hasCountryCode = digits.startsWith('54');
  
  let remainingDigits = digits;
  let hasTrunk = false;
  
  if (hasCountryCode) {
    remainingDigits = remainingDigits.substring(2);
    // Check for mobile indicator 9
    if (remainingDigits.startsWith('9')) {
      remainingDigits = remainingDigits.substring(1);
    }
  } else {
    // Check for trunk prefix 0
    if (remainingDigits.startsWith('0')) {
      hasTrunk = true;
      remainingDigits = remainingDigits.substring(1);
    }
  }
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (remainingDigits.length < 8) {
    return false; // Not enough digits for area + subscriber
  }
  
  // Check trunk validation (when country code is omitted)
  if (!hasCountryCode && !hasTrunk) {
    return false;
  }
  
  // Format validation - allow various Argentine formats
  // Pattern for: +54 341 123 4567 (landline format) - account for spaces within subscriber number
  const pattern1 = /^\+54\s[1-9]\d{1,3}\s(?:\d+\s*){2,}$/;  
  // Pattern for: +54 9 11 1234 5678 (mobile format)
  const pattern2 = /^\+54\s9\s[1-9]\d{1,3}\s(?:\d+\s*){2,}$/;   
  // Pattern for: 011 1234 5678 (domestic landline)
  const pattern3 = /^0\s[1-9]\d{1,3}\s(?:\d+\s*){2,}$/;        
  // Pattern for: 011 1234 5678 (domestic mobile)
  const pattern4 = /^0\s9\s[1-9]\d{1,3}\s(?:\d+\s*){2,}$/;    
  
  return pattern1.test(value.trim()) || 
         pattern2.test(value.trim()) || 
         pattern3.test(value.trim()) || 
         pattern4.test(value.trim());
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  // Must have at least 2 characters
  if (trimmed.length < 2) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}\s'’-]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Check for at least one letter (not just spaces/symbols)
  if (!/[^\p{L}\p{M}\s'’-]/u.test(trimmed)) {
    // Only contains allowed characters, but we need at least one letter
    return /[\p{L}\p{M}]/u.test(trimmed);
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Basic length check
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid card type and length
  let isValidCard = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidCard = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
             digits.startsWith('54') || digits.startsWith('55')) || 
            (digits.startsWith('222') && parseInt(digits.substring(3, 4), 10) >= 1 && parseInt(digits.substring(3, 4), 10) <= 9) ||
            (digits.startsWith('272') && parseInt(digits.substring(3, 4), 10) <= 0)) {
    isValidCard = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    isValidCard = true;
  }
  // Discover: starts with 6011, 65, or 644-649, length 16
  else if ((digits.startsWith('6011') || digits.startsWith('65')) || 
           (digits.startsWith('64') && parseInt(digits.charAt(2), 10) >= 4 && parseInt(digits.charAt(2), 10) <= 9)) {
    isValidCard = true;
  }
  
  if (!isValidCard) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
