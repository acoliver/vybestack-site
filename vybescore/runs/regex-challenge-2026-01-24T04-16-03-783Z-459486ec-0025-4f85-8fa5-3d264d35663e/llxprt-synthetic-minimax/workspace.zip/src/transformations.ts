/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Trim leading/trailing whitespace
  let result = text.trim();
  
  // Capitalize first character if it's a letter
  result = result.replace(/^([a-zA-Z])/, (match) => match.toUpperCase());
  
  // Find sentence endings and capitalize following text
  result = result.replace(/([.!?])\s*([a-zA-Z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Handle case where there might be multiple sentences without proper spacing
  // Ensure exactly one space after sentence endings
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Handle abbreviations by not capitalizing after common abbreviations
  // This is tricky - we'll be conservative and focus on the main goal
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs (http/https protocols)
  // Match http:// or https:// followed by any non-whitespace characters
  const urlRegex = /(https?:\/\/\S+)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up any trailing punctuation that might have been captured
  return matches.map(url => {
    // Remove trailing sentence punctuation, but keep dots within URLs
    return url.replace(/[!,;.?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const httpUrlRegex = /http:\/\/([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    let result = '';
    
    // Always upgrade scheme to https
    result += 'https://';
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|cgi-bin|=|&|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        result += 'docs.' + host;
        result += path;
      } else {
        // Keep original host
        result += host;
        result += path;
      }
    } else {
      // Keep original host for non-docs URLs
      result += host;
      if (path) {
        result += path;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic day validation for months (not perfect but reasonable)
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  // Year must be reasonable (1000-9999, which it is by format)
  return year;
}
