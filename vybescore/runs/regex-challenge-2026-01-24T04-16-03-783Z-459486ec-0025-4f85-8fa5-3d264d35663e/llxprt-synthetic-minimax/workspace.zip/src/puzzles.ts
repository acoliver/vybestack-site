/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for prefixed words
  // Use word boundaries to match whole words
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  const filteredMatches = matches.filter(match => {
    const normalizedMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === normalizedMatch.toLowerCase()
    );
  });
  
  // Return unique matches
  return [...new Set(filteredMatches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Match digit followed by token (but not at start of string)
  const matches = text.match(new RegExp(`(?<!^)\\d+(${token})`, 'gi')) || [];
  
  // Extract the full matched pattern (digit + token)
  return matches.map(match => {
    const tokenMatch = match.match(new RegExp(`\\d+(${token})`, 'i'));
    return tokenMatch ? tokenMatch[0] : token;
  });
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-={};"|,.<>?]/.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (like abab)
  // This pattern looks for any 2-character sequence that immediately repeats
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check if string contains IPv4 pattern first - if it does, reject
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns
  // Standard IPv6: 8 groups of 4 hex digits, separated by colons
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with shorthand (::) - various positions
  // Leading shorthand: ::1
  const leadingShorthandPattern = /\b::[0-9a-fA-F]{1,4}\b/;
  
  // Trailing shorthand: 1::
  const trailingShorthandPattern = /\b[0-9a-fA-F]{1,4}::\b/;
  
  // Middle shorthand: 1::2
  const middleShorthandPattern = /\b[0-9a-fA-F]{1,4}:[0-9a-fA-F]{0,4}:[0-9a-fA-F]{0,4}\b/;
  
  // More comprehensive IPv6 pattern that handles various shorthand notations
  // Check for shorthand notation anywhere
  const shorthandPattern = /\b(?:[0-9a-fA-F]{0,4}:){0,7}::(?:[0-9a-fA-F]{0,4}:){0,7}[0-9a-fA-F]{0,4}\b/;
  
  // Check for various IPv6 formats
  if (fullIPv6Pattern.test(value) || 
      leadingShorthandPattern.test(value) || 
      trailingShorthandPattern.test(value) || 
      middleShorthandPattern.test(value) ||
      shorthandPattern.test(value)) {
    return true;
  }
  
  // Also check for IPv6-like patterns in contexts where they might be embedded
  // This pattern looks for sequences of hex digits separated by colons
  // with potential shorthand notation
  const contextIPv6Pattern = /(?<![0-9a-fA-F])(?:[0-9a-fA-F]{0,4}:){1,7}[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{1,4}){0,7}(?![0-9a-fA-F])/;
  
  return contextIPv6Pattern.test(value);
}
