/**
 * Capitalize the first character of each sentence while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Split text into potential sentences using .?!
  // Use a regex that captures the delimiter
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  let capitalizeNext = true; // First character should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part === '.' || part === '?' || part === '!') {
      // This is a punctuation mark, add it and set flag to capitalize next word
      result += part;
      capitalizeNext = true;
    } else if (part.trim() === '') {
      // This is whitespace, preserve single space
      if (capitalizeNext && result && result[result.length - 1] !== ' ') {
        result += ' ';
      }
    } else {
      // This is text content, handle capitalization if needed
      if (capitalizeNext) {
        // Check if this looks like an abbreviation (all lowercase, short, no spaces)
        const isAbbreviation = /^(e\.g|i\.e|etc|mr|mrs|dr|ms|prof|st)\.?$/i.test(part.trim());
        
        if (!isAbbreviation) {
          result += part.charAt(0).toUpperCase() + part.slice(1);
        } else {
          result += part;
        }
      } else {
        result += part;
      }
      
      if (part.trim()) {
        capitalizeNext = false;
      }
    }
  }
  
  return result;
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Regular expression to match URLs
  // Matches http://, https://, and protocol-less URLs
  const urlRegex = /(?:https?:\/\/|(?<![\w])(?:www\.))?[^\s,;'"]+(?:\/[^\s,;'"]*)?(?:\?[^\s,;'"]*)?(?:#[^\s,;'"]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation marks that are unlikely to be part of the URL
    return url.replace(/[.,;:!?)]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs to use https and docs subdomain while preserving dynamic URLs.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // First, enforce HTTPS on all URLs
  let result = enforceHttps(text);
  
  // Then process http://example.com URLs with /docs/ paths
  // Pattern to match https://example.com/docs/... URLs
  const docsUrlRegex = /https:\/\/example\.com(\/docs\/[^?\s]+)/g;
  
  // Replace with docs.example.com
  result = result.replace(docsUrlRegex, 'https://docs.example.com$1');
  
  // For URLs that contain dynamic hints (cgi-bin, query params, or legacy extensions),
  // only upgrade the scheme (already done above) but skip the host rewrite
  // This is handled by the regex not matching these patterns
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings or return 'N/A' if invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month/day combinations
  // Check for February 29th in non-leap years
  if (month === 2 && day === 29) {
    const leapYear = parseInt(year, 10) % 4 === 0 && 
                    (parseInt(year, 10) % 100 !== 0 || parseInt(year, 10) % 400 === 0);
    if (!leapYear) {
      return 'N/A';
    }
  }
  
  // Check for 31 day months
  if (day === 31 && [4, 6, 9, 11].includes(month)) {
    return 'N/A';
  }
  
  // All checks passed
  return year;
}
