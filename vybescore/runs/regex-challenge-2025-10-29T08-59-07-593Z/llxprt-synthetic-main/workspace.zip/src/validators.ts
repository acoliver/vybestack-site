export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation that accepts typical addresses and rejects invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation using regex
  // Must allow: name+tag@example.co.uk, but reject double dots, trailing dots, domains with underscores
  
  // Email pattern explanation:
  // ^[a-zA-Z0-9] - Must start with alphanumeric
  // [a-zA-Z0-9+%_.-]* - Can contain alphanumeric, plus, percent, underscore, dot, hyphen
  // (?:\.[a-zA-Z0-9+%_.-]+)* - Dot-separated segments (prevents consecutive dots)
  // @ - The @ symbol
  // (?!.*[._])$ - Negative lookahead to prevent underscores or dots at end of domain
  // [a-zA-Z0-9-]+ - Domain segments (no underscores)
  // (?:\.[a-zA-Z]{2,})+ - TLD segments with at least 2 characters
  
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9+%_.-]*@(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for dot before @ (local part must not end with dot)
  const [local, domain] = value.split('@');
  if (local.endsWith('.') || local.startsWith('.')) {
    return false;
  }
  
  // Domain must not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * US phone number validation supporting common formats and optional +1 prefix.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check if there's an optional +1 prefix
  const hasCountryCode = digits.startsWith('1') && digits.length === 11;
  const phoneNumber = hasCountryCode ? digits.substring(1) : digits;
  
  // US phone numbers should have 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check for common formats using regex
  const usPhoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[-]?)?\d{3}[-]?\d{4}$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Argentine phone number validation covering mobile and landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Clean the input - remove spaces, hyphens, parentheses
  const cleaned = value.replace(/[\s()-]/g, '');
  
  // Argentine phone regex pattern
  // Optional +54 country code
  // Optional 0 trunk prefix (if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?9?(\d{2,4})(\d{6,8})$/;
  
  // Special case for numbers without country code - must start with 0
  const withoutCountryRegex = /^0(\d{2,4})(\d{6,8})$/;
  
  // Try matching with country code optional
  const matchWithCountry = argentinePhoneRegex.exec(cleaned);
  if (matchWithCountry) {
    const areaCode = matchWithCountry[1];
    const subscriber = matchWithCountry[2];
    
    // Area code must start with 1-9
    if (!/^[1-9]/.test(areaCode)) {
      return false;
    }
    
    return true;
  }
  
  // Try matching without country code (must start with 0)
  const matchWithoutCountry = withoutCountryRegex.exec(cleaned);
  if (matchWithoutCountry) {
    const areaCode = matchWithoutCountry[1];
    const subscriber = matchWithoutCountry[2];
    
    // Area code must start with 1-9
    if (!/^[1-9]/.test(areaCode)) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 */
export function isValidName(value: string): boolean {
  if (!value) return false;
  
  // Allow:
  // Unicode letters (from any language)
  // Accents
  // Apostrophes
  // Hyphens
  // Spaces
  // Reject:
  // Digits
  // Symbols like @, #, $, etc.
  
  // The pattern allows:
  // ^\p{L} - Start with a unicode letter
  // [\p{L}' -\s]+$ - Followed by more unicode letters, apostrophes, hyphens, or spaces
  
  // Using Unicode property escapes
  try {
    const nameRegex = /^[\p{L}'\-\s ]+$/u;
    return nameRegex.test(value);
  } catch (e) {
    // Fallback for environments without full Unicode support
    const nameRegex = /^[a-zA-Zà-žÀ-Ž\u00C0-\u017F\s'\-]+$/;
    return nameRegex.test(value);
  }
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length based on card type
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55, 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  const isVisa = /^4\d{12}(?:\d{3})?$/.test(cleaned);
  const isMastercard = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/.test(cleaned);
  const isAmex = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn checksum validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + 1;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
