/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Validate that the input contains only valid Base64 characters and optional whitespace
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  const trimmedInput = input.trim();
  
  if (!base64Pattern.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Normalize padding: add padding if missing but required
  const paddedInput = addPadding(trimmedInput);
  
  try {
    const result = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Validate that the decoded content is valid UTF-8
    if (containsInvalidUTF8(result)) {
      throw new Error('Invalid UTF-8 content in decoded Base64');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Add proper padding to Base64 strings that are missing it.
 * Base64 padding must be added to make the length a multiple of 4.
 */
function addPadding(input: string): string {
  const paddingNeeded = (4 - (input.length % 4)) % 4;
  return input + '='.repeat(paddingNeeded);
}

/**
 * Check if a string contains invalid UTF-8 sequences.
 */
function containsInvalidUTF8(str: string): boolean {
  // Empty strings are valid UTF-8
  if (str === '') {
    return false;
  }
  
  // Check for problematic characters using character codes
  const hasInvalidChars = [...str].some(char => {
    const code = char.charCodeAt(0);
    // Null byte and control characters (except common ones like tab, newline, etc.)
    return code === 0 || (code < 32 && code !== 9 && code !== 10 && code !== 13) || code === 127;
  });
  
  // Also check for non-UTF8 bytes by attempting to encode/decode roundtrip
  const encoded = Buffer.from(str, 'utf8');
  const decoded = encoded.toString('utf8');
  
  return hasInvalidChars || decoded !== str;
}
