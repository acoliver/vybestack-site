export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject double dots, trailing dots, and domains with underscores
  if (value.includes('..') || value.endsWith('.') || value.includes('_')) {
    return false;
  }
  
  // Email validation regex
  const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9._%+-]*[a-zA-Z0-9]+)?@[a-zA-Z0-9]+([a-zA-Z0-9-]*[a-zA-Z0-9]+)?(\.[a-zA-Z]{2,})+$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all whitespace for validation
  const cleaned = value.replace(/\s/g, '');
  
  // US phone regex supporting:
  // - Optional +1 country code
  // - Optional parentheses around area code
  // - Common separators: - . spaces
  // - Disallow area codes starting with 0 or 1
  const usPhoneRegex = /^(\+1[\s-]?)?(\(?([2-9]\d{2})\)?[\s-]?)([2-9]\d{2})[\s-]?(\d{4})$/;
  
  return usPhoneRegex.test(cleaned);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex supporting:
  // - Optional +54 country code
  // - Optional 0 trunk prefix (required when country code is omitted)
  // - Optional 9 mobile indicator
  // - Area code: 2-4 digits (leading digit 1-9)
  // - Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Additional validation: if country code is omitted, trunk prefix must be present
  const match = cleaned.match(argentinePhoneRegex);
  if (match) {
    const hasCountryCode = match[1] !== undefined;
    const hasTrunkPrefix = match[2] !== undefined;
    
    // If no country code, trunk prefix must be present
    if (!hasCountryCode && !hasTrunkPrefix) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject names with digits or the specific "X Æ A-12" style
  if (/\d/.test(value) || /^[Xx][\s-]*Æ[\s-]*[Aa][\s-]*-?12$/.test(value)) {
    return false;
  }
  
  // Name validation regex:
  // - Unicode letters and accented characters
  // - Apostrophes and hyphens (not at start/end)
  // - Spaces between words
  // - At least 2 characters
  const nameRegex = /^[\p{L}\p{M}]+(['-][\p{L}\p{M}]+)*(\s+[\p{L}\p{M}]+(['-][\p{L}\p{M}]+)*)*$/u;
  
  return nameRegex.test(value) && value.trim().length >= 2;
}

/**
 * TODO: Validate credit card numbers for major brands with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check basic length constraints (13-19 digits)
  if (cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }
  
  // Credit card regex for major brands:
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|4[0-1]\d|5[0-2]\d|6[0-9]\d|7[0-1]\d|720)\d{12})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card pattern
  const isValidPattern = visaRegex.test(cardNumber) || 
                        mastercardRegex.test(cardNumber) || 
                        amexRegex.test(cardNumber);
  
  if (!isValidPattern) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}
