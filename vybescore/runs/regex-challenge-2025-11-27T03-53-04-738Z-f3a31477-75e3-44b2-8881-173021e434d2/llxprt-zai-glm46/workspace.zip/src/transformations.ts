/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, split text into sentences using punctuation marks
  // This regex looks for sentence endings followed by optional whitespace
  const sentences = text.split(/([.!?]+)(\s*)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part === '') continue;
    
    // Check if this is punctuation (ending a sentence)
    if (/[.!?]/.test(part)) {
      result += part;
      capitalizeNext = true;
    } 
    // Check if this is whitespace after punctuation
    else if (capitalizeNext && /^\s+$/.test(part)) {
      // Ensure exactly one space after punctuation
      result += ' ';
    }
    // Regular text content
    else {
      if (capitalizeNext) {
        // Capitalize first character, keep rest as is
        result += part.charAt(0).toUpperCase() + part.slice(1);
        capitalizeNext = false;
      } else {
        result += part;
      }
    }
  }
  
  // Collapse multiple spaces into single spaces
  result = result.replace(/\s+/g, ' ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches various URL formats
  // Supports http, https, ftp protocols and www domains
  // Captures domain, optional port, path, query string, and fragment
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+|(?:(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})(?:\/[^\s<>"']*)?/g;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up matches by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?'"()[\]{}]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using a simple approach
  // Look for http:// that is not part of https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/(example\.com)(\/[^\s]*)?/g, (match, domain, path = '') => {
    // Always upgrade to https
    const secureScheme = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i;
    
    // If path has dynamic hints or starts with /docs/, rewrite host accordingly
    if (path.startsWith('/docs/') && !hasDynamicHints.test(path)) {
      // Move docs.example.com while preserving the path
      return secureScheme + 'docs.' + domain + path;
    } else {
      // Just upgrade to https, keep original domain
      return secureScheme + domain + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format where month and day are valid
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const year = match[3];
  return year;
}
