/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  // \b ensures we match whole words only
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions (case-insensitive)
  const filteredWords = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
  
  // Return the filtered words (without deduplication to ensure order is preserved)
  return filteredWords;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex to find digit followed by token, capturing the digit + token
  // This uses lookbehind to match only when preceded by a digit, then captures the digit + token
  const tokenRegex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches and prepend the digit from the original string
  const matches = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    // Get the digit that precedes this match
    const digitIndex = match.index - 1;
    const digit = text[digitIndex];
    if (digit && /\d/.test(digit)) {
      matches.push(digit + match[0]);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate strong password requirements described in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab")
  // This looks for any sequence of 2-4 characters that repeats immediately
  if (/(.{2,4})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern that includes shorthand (::)
  // This pattern matches valid IPv6 addresses while excluding IPv4
  const ipv6Pattern = /(?:^|(?<!\d))((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  return ipv6Pattern.test(value);
}