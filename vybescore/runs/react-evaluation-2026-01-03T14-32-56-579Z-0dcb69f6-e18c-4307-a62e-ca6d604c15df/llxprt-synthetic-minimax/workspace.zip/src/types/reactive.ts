/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Observer interfaces for reactive system
export interface Observer<T = any> {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  equalFn?: EqualFn<T>
  dependents?: Set<Observer<T>>
  read?: GetterFn<T>
  write?: SetterFn<T>
}

export interface ObserverR<T = any> extends Observer<T> {
  read: GetterFn<T>
}

export interface ObserverV<T = any> extends Observer<T> {
  write: SetterFn<T>
}

// Subject interfaces for reactive system
export interface Subject<T = any> {
  name?: string
  value?: T
  dependents?: Set<Observer<T>>
  equalFn?: EqualFn<T>
  read?: GetterFn<T>
  write?: SetterFn<T>
}

export interface SubjectR<T = any> extends Subject<T> {
  read: GetterFn<T>
}

export interface SubjectV<T = any> extends Subject<T> {
  write: SetterFn<T>
}

// Observer management functions
export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.updateFn) {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    
    // Notify dependents that this observer's value has changed
    if (observer.dependents && observer.dependents.size > 0) {
      const dependents = new Set(observer.dependents)
      dependents.forEach((dependent) => {
        if (dependent !== observer) {
          updateObserver(dependent)
        }
      })
    }
  }
}

// Global state for tracking active observer and execution context
export type ExecutionContext = {
  observers: Observer<any>[]
  index: number
}

let currentContext: ExecutionContext | null = null
let activeObserver: Observer<any> | null = null

export function getActiveObserver(): Observer<any> | null {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | null): void {
  activeObserver = observer
}

export function beginTracking(): void {
  if (!currentContext) {
    currentContext = { observers: [], index: 0 }
  }
}

export function trackObserver(observer: Observer<any>): void {
  if (!currentContext) return
  
  // Only track if not already tracked
  if (!currentContext.observers.includes(observer)) {
    currentContext.observers.push(observer)
    currentContext.index++
  }
}

export function endTracking(): Observer<any>[] | null {
  if (!currentContext) return null
  
  const observers = currentContext.observers
  currentContext = null
  return observers
}
