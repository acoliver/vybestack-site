/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let computedValue: T | undefined = value
  const subscribers: Set<() => void> = new Set()
  let currentValue: T | undefined = value

  const read: GetterFn<T> = () => {
    // Re-compute the value every time it's accessed
    const newValue = updateFn(currentValue)
    
    // Always update and notify subscribers
    currentValue = newValue
    computedValue = newValue
    
    // Notify all subscribers that the computed value has changed
    notifySubscribers()
    
    return computedValue!
  }

  // Notify all subscribers that this computed value has changed
  const notifySubscribers = () => {
    const currentSubscribers = new Set(subscribers)
    currentSubscribers.forEach(callback => {
      callback()
    })
  }

  // Store subscription system for external access
  ;(read as any)._subscribe = (callback: () => void) => {
    subscribers.add(callback)
    return () => {
      subscribers.delete(callback)
    }
  }

  // Initial evaluation
  if (value !== undefined) {
    currentValue = updateFn(value)
    computedValue = currentValue
  }
  
  return read
}
