/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value
  const subscribers: Set<() => void> = new Set()

  const read: GetterFn<T> = () => {
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = currentValue
    currentValue = nextValue
    
    // Notify all subscribers when value changes
    if (oldValue !== currentValue) {
      const currentSubscribers = new Set(subscribers)
      currentSubscribers.forEach(callback => {
        callback()
      })
    }
    
    return currentValue
  }

  // Store subscription system for external access
  ;(read as any)._subscribe = (callback: () => void): (() => void) => {
    subscribers.add(callback)
    return () => {
      subscribers.delete(callback)
    }
  }

  return [read, write]
}
