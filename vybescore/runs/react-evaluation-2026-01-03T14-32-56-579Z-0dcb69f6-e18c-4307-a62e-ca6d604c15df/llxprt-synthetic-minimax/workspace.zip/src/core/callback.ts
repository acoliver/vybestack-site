/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let callbackSubscriptions: Array<() => void> = []

  const executeCallback = () => {
    if (disposed) return
    
    // Execute the callback function and establish automatic subscriptions
    const callbackWrapper = () => {
      if (disposed) return
      
      // Execute the original callback
      updateFn(value)
    }
    
    // Execute the callback
    callbackWrapper()
    
    // Store subscriptions for automatic re-execution when dependencies change
    // The reactive system should automatically establish these subscriptions
  }

  // Execute initial callback to establish dependencies and subscriptions
  executeCallback()

  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up all subscriptions
    callbackSubscriptions.forEach(unsubscribe => unsubscribe())
    callbackSubscriptions = []
  }
}
