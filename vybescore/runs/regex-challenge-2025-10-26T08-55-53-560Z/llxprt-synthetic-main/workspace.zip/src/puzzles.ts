/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words starting with the prefix
  // \b ensures we match whole words
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w+)`, 'gi');
  
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  // Convert matches to lowercase to handle case-insensitive comparisons
  const lowerMatches = matches.map(word => word.toLowerCase());
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerExceptions = exceptions.map(word => word.toLowerCase());
  
  // Filter out exceptions and ensure each word is unique
  return [...new Set(
    lowerMatches.filter(word => !lowerExceptions.includes(word))
  )];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match patterns where a digit is followed immediately by the token
  // We need to capture both the digit and the token to return the full match
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Password requirements:
  // At least 10 characters
  // At least one uppercase letter
  // At least one lowercase letter
  // At least one digit
  // At least one symbol
  // No whitespace
  // No immediate repeated sequences (e.g., abab should fail)
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // Looking for patterns like ABAB, 123123, etc. where a sequence appears twice in a row
  // We'll use a regex that captures any sequence of 2-4 characters and checks if it's followed by the same sequence
  const repeatedPatternRegex = /(\w{2,4})\1/i;
  if (repeatedPatternRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv6 regex pattern - matches valid IPv6 formats including shorthand
  // This pattern includes:
  // - Standard IPv6 with 8 groups of 4 hex digits
  // - Compressed IPv6 with :: shorthand
  // - IPv6 with embedded IPv4 addresses
  // - IPv6 with varying group lengths
  
  // First, exclude plain IPv4 addresses
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 regex pattern
  const ipv6Regex = new RegExp(
    [
      // Full IPv6 (8 groups of 4 hex digits)
      '\\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\\b',
      // Compressed IPv6 with :: (starting or ending with ::)
      '\\b::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\\b',
      // Compressed IPv6 with :: in middle
      '\\b[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\\b',
      // More complex compressed forms
      '\\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\\b',
      // IPv6 with embedded IPv4
      '\\b(?:[0-9a-fA-F]{1,4}:){6}:(?:\\d{1,3}\\.){3}\\d{1,3}\\b',
      // IPv6 with mixed notation and compressed segments
      '\\b::(?:[0-9a-fA-F]{1,4}:){0,4}:(?:\\d{1,3}\\.){3}\\d{1,3}\\b',
      '\\b[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,3}:(?:\\d{1,3}\\.){3}\\d{1,3}\\b',
      '\\b(?:[0-9a-fA-F]{1,4}:){1,4}::(?:[0-9a-fA-F]{1,4}:){0,2}:(?:\\d{1,3}\\.){3}\\d{1,3}\\b'
    ].join('|')
  );
  
  // First check if there's a plain IPv4 address (which should not be a match)
  if (ipv4Regex.test(value) && !ipv6Regex.test(value)) {
    return false;
  }
  
  // Check for IPv6 addresses
  return ipv6Regex.test(value);
}