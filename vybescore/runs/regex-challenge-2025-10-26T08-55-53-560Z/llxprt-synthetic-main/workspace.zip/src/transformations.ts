/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // Regex to match sentence boundaries
  // Looks for sentence ending punctuation followed by optional quotes/brackets and whitespace
  const sentenceRegex = /([.!?])(?=\s*[\"')\]\}]?\s*[A-Za-z0-9])/g;
  
  // Split by sentence boundaries and process each part
  let result = text;
  
  // First, replace multiple spaces with a single space while preserving sentence boundaries
  result = result.replace(/\s{2,}/g, ' ');
  
  // Add space after sentence ending if missing (before another letter)
  result = result.replace(/([.!?])(?=[A-Za-z0-9])/g, '$1 ');
  
  // Capitalize the first character of the text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Process sentence boundaries and capitalize the first character after each
  const parts = result.split(sentenceRegex);
  
  for (let i = 2; i < parts.length; i += 2) {
    const textAfterPunctuation = parts[i];
    
    if (textAfterPunctuation && textAfterPunctuation.length > 0) {
      // Find the first alphabetic character and capitalize it
      parts[i] = textAfterPunctuation.replace(/^(\s*)([a-z])/, (match, spaces, letter) => {
        return spaces + letter.toUpperCase();
      });
    }
  }
  
  return parts.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // URL regex pattern to match HTTP/HTTPS URLs
  // Pattern breakdown:
  // (https?:\/\/) - Protocol (http:// or https://)
  // ([^\s<>\"\']+) - One or more characters that aren't spaces, <, >, ", or '
  // (?=[\s<>\.\"\'\)]|$) - Positive lookahead to ensure the URL ends before space, punctuation, or end of string
  const urlRegex = /https?:\/\/([^\s<>\"\']+)(?=[\s<>\.\"\'\)]|$)/gi;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean each match by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,;:!?)]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https://
  // Using negative lookahead to avoid matching https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // First replace http:// with https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then rewrite docs URLs to use the docs.example.com subdomain
  // Match URLs with /docs/ path, but exclude certain dynamic content
  const docsUrlRegex = /(https:\/\/example\.com)\/docs\/([^?\s]*)(?!\.(jsp|php|asp|aspx|do|cgi|pl|py))/gi;
  
  result = result.replace(docsUrlRegex, 'https://docs.example.com/docs/$2');
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate that month/day combination is valid
  // Using a simple approach: create a Date object and check if it's valid
  const date = new Date(`${year}-${month}-${day}`);
  
  // Check if the date is valid and the month/day match what we parsed
  // This handles edge cases like 02/30/2023 which should be invalid
  if (
    isNaN(date.getTime()) || // Invalid date
    date.getMonth() !== month - 1 || // Month mismatch (getMonth() is 0-indexed)
    date.getDate() !== day
  ) {
    return 'N/A';
  }
  
  return year;
}
