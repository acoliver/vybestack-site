export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex for typical addresses
  // Local part: letters, digits, plus, dots, hyphens
  // Domain: letters, digits, hyphens, dots (no consecutive dots)
  // TLD: at least 2 letters
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9+.-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Test basic format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // Local part shouldn't start/end with dot or have consecutive dots
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }
  
  // Domain shouldn't have consecutive dots
  const domain = value.split('@')[1];
  if (domain.includes('..')) {
    return false;
  }
  
  // Domain segments shouldn't start/end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and whitespace
  const normalizedPhone = value.replace(/[-\s\(\)]/g, '');
  
  // Check if it starts with +1 and remove it for validation
  const phoneWithoutCountry = normalizedPhone.startsWith('+1') 
    ? normalizedPhone.substring(2) 
    : normalizedPhone;
  
  // Must be 10 digits for standard US number
  if (!/^\d{10}$/.test(phoneWithoutCountry)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneWithoutCountry.substring(0, 3);
  
  // Disallow area codes starting with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if it matches common formats
  const usPhonePatterns = [
    /^\+1\s*\(\d{3}\)\s*\d{3}[-\s]*\d{4}$/, // +1 (212) 555-7890
    /^\+1\s*\d{3}[-\s]*\d{3}[-\s]*\d{4}$/, // +1 212-555-7890 or +1 212 555 7890
    /^\(\d{3}\)\s*\d{3}[-\s]*\d{4}$/, // (212) 555-7890
    /^\d{3}[-\s]*\d{3}[-\s]*\d{4}$/, // 212-555-7890 or 212 555 7890
    /^\d{10}$/, // 2125557890
  ];
  
  return usPhonePatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const normalizedPhone = value.replace(/[-\s]/g, '');
  
  // Argentine phone regex patterns
  // Pattern breakdown:
  // ^\+?54? - Optional +54 country code
  // 0? - Optional trunk prefix
  // 9? - Optional mobile indicator
  // ([2-9]\d{1,3}) - Area code (2-4 digits, starting with 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^\+?54?0?9?([2-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(normalizedPhone)) {
    return false;
  }
  
  // Extract area code and subscriber number
  const match = normalizedPhone.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code (2-4 digits, not starting with 0 or 1)
  if (areaCode.length < 2 || areaCode.length > 4 || /^[01]/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Special rule: if country code is omitted, must start with trunk prefix 0
  const hasCountryCode = normalizedPhone.startsWith('+54');
  if (!hasCountryCode && !normalizedPhone.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex
  // Allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes (')
  // - Hyphens (-)
  // - Spaces
  // Disallows:
  // - Digits
  // - Symbols
  // - Names like "X Æ A-12" with special symbols/numbers
  
  // At least one character is required
  if (value.trim().length === 0) {
    return false;
  }
  
  // Regex pattern allows letters, accents, apostrophes, hyphens, and spaces
  // But not digits or other symbols
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0590-\u05FF\u0600-\u06FF\s'-]+$/;
  
  // Check if the name contains only allowed characters
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for digits (should not be present in valid names)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with symbols like Æ or other special characters
  // We're being stricter than the basic regex by checking for special symbols
  const symbolRegex = /[^\w\s'-]/;
  if (symbolRegex.test(value)) {
    return false;
  }
  
  // Names shouldn't start or end with hyphen, apostrophe, or space
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */

// Helper function to perform Luhn algorithm checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process each digit from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check if the card number is empty
  if (!cardNumber || cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Check card type prefixes and lengths
  const cardPatterns = [
    // Visa: starts with 4, length 13 or 16
    {
      regex: /^4(\d{12}|\d{15})$/,
      test: (num: string) => num.length === 13 || num.length === 16
    },
    // Mastercard: starts with 51-55 or 2221-2720, length 16
    {
      regex: /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{10})))$/,
      test: (num: string) => num.length === 16
    },
    // American Express: starts with 34 or 37, length 15
    {
      regex: /^3[47]\d{13}$/,
      test: (num: string) => num.length === 15
    }
  ];
  
  // Check if the card number matches any of the patterns
  const isValidPattern = cardPatterns.some(pattern => {
    return pattern.regex.test(cardNumber) && pattern.test(cardNumber);
  });
  
  if (!isValidPattern) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cardNumber);
}
