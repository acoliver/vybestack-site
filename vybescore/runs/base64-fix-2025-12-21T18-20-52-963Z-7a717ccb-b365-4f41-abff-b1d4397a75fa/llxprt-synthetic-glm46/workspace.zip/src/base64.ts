const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!validateBase64Format(input)) {
    throw new Error(`${INVALID_BASE64_ERROR}: contains invalid characters`);
  }
  
  if (!validateBase64Padding(input)) {
    throw new Error(`${INVALID_BASE64_ERROR}: incorrect padding`);
  }
  
  return decodeWithValidation(input);
}

function validateBase64Format(input: string): boolean {
  return BASE64_REGEX.test(input);
}

function validateBase64Padding(input: string): boolean {
  const inputLength = input.length;
  
  // According to Base64 specification, length modulo 4 should never be 1
  if (inputLength % 4 === 1) {
    return false;
  }
  
  // Padding characters can only appear at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1 && paddingIndex < inputLength - 2) {
    return false;
  }
  
  // Check for incorrect padding count
  const paddingCount = getPaddingCount(input);
  return !(paddingCount > 0 && inputLength % 4 !== 0);
}

function getPaddingCount(input: string): number {
  return input.endsWith('==') ? 2 : input.endsWith('=') ? 1 : 0;
}

function decodeWithValidation(input: string): string {
  try {
    // First try to decode with Node's built-in
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Re-encode and compare to detect invalid cases
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    
    // Normalize both strings for comparison
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    const normalizedInput = input.replace(/=+$/, '');
    
    // If they don't match, the input was likely invalid
    if (normalizedReencoded !== normalizedInput) {
      throw new Error(`${INVALID_BASE64_ERROR}: incorrect padding`);
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes(INVALID_BASE64_ERROR)) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
