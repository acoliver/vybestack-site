/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

// Global tracking for all computed values
const computedRegistry = new Set<() => void>()


/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  // Track who depends on this computed value
const dependencies = new Set<ObserverR>()
  
  // Compute initial value
  const compute = () => {
    return updateFn(value)
  }
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    if (observer) {
      // Register this computed as a dependency of the current observer
      dependencies.add(observer)
    }
    
    return currentValue
  }
  
  const recompute = () => {
    const newValue = compute()
    if (newValue !== currentValue) {
      currentValue = newValue
      
      // Notify all dependent observers
      dependencies.forEach(dep => {
        if ((dep as Observer<unknown>).updateFn) {
          const prevActive = getActiveObserver()
          activeObserver = dep
          try {
            (dep as Observer<unknown>).value = (dep as Observer<unknown>).updateFn((dep as Observer<unknown>).value)
          } finally {
            activeObserver = prevActive
          }
        }
      })
    }
  }
  
  // Initial computation
  currentValue = compute()
  
  // Register for global notification when inputs change
  computedRegistry.add(recompute)
  
  return getter
}

// Helper to mark computed values as invalid when inputs change
export function markComputablesDirty(): void {
  computedRegistry.forEach(recompute => recompute())
}
