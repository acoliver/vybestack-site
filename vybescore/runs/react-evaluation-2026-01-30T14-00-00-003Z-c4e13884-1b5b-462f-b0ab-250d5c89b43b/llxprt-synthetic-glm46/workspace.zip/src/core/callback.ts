/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from '../types/reactive.js'

// Global registry for all callbacks to ensure they get notified
const callbackRegistry = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register dependencies to track what this callback depends on
  const dependencies = new Set<ObserverR>()
  
  // Register observer to track dependencies and execute initial callback
  // The observer tracking happens automatically through the getActiveObserver system
  observer.value = updateFn(value)
  
  // Add to global registry so it gets notifications
  callbackRegistry.add(observer as Observer<unknown>)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from global registry
    callbackRegistry.delete(observer as Observer<unknown>)
    
    // Clear dependencies
    dependencies.clear()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}



// Export for input to send notifications
export function notifyAllCallbacks(): void {
  callbackRegistry.forEach(callback => {
    updateObserver(callback as Observer<unknown>)
  })
}
