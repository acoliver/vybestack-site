const BASE64_ALPHABET = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 (with padding) and rejects invalid inputs.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Only accept standard Base64
  if (!BASE64_ALPHABET.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  const normalizedInput = normalizeInput(input);
  
  return decodeWithValidation(normalizedInput);
}

/**
 * Normalize Base64 input by adding proper padding.
 */
function normalizeInput(input: string): string {
  // Add padding if missing
  const padLength = (4 - (input.length % 4)) % 4;
  if (padLength > 0) {
    return input + '='.repeat(padLength);
  }
  return input;
}

/**
 * Decode Base64 input and validate it by round-tripping.
 */
function decodeWithValidation(normalizedInput: string): string {
  try {
    const result = Buffer.from(normalizedInput, 'base64').toString('utf8');
    validateBase64Input(normalizedInput, result);
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}

/**
 * Validate that the input was actually valid Base64 by re-encoding.
 */
function validateBase64Input(normalizedInput: string, result: string): void {
  const reencoded = Buffer.from(result, 'utf8').toString('base64');
  const normalizedReencoded = reencoded.replace(/=+$/, '');
  const normalizedOriginal = normalizedInput.replace(/=+$/, '');
  
  if (normalizedReencoded !== normalizedOriginal && 
      normalizedReencoded + '=' !== normalizedOriginal && 
      normalizedReencoded + '==' !== normalizedOriginal) {
    throw new Error('Invalid Base64 input: failed validation');
  }
}
