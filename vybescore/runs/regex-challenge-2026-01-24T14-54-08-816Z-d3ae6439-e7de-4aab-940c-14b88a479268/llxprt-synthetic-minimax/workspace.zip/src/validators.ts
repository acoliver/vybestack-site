export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern: name@domain.tld
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Additional validation checks
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in any part
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.replace(/[^\d]/g, '');
  
  // Check if it starts with optional +1
  const phoneRegex = /^(?:\+?1[\s-]?)?(\([2-9][0-8][0-9]\)|[2-9][0-8][0-9])[\s-]?[2-9][0-9]{2}[\s-]?[0-9]{4}$/;
  
  // Basic length check (10 digits without country code, 11 with +1)
  if (cleanValue.length < 10 || cleanValue.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1
  if (cleanValue.length === 11 && !cleanValue.startsWith('1')) {
    return false;
  }
  
  // Extract area code (first 3 digits after optional country code)
  const areaCodeMatch = cleanValue.match(/^1?([2-9][0-8][0-9])/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  
  // Validate area code (cannot start with 0 or 1)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Use regex for full validation
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters to validate structure
  const cleanValue = value.replace(/[\s\-()]/g, '');
  
  // Check if it matches Argentine phone pattern
  // Pattern: optional +54, optional 0, optional 9, area code 2-4 digits, subscriber 6-8 digits
  const pattern = /^(?:\+?54)?(?:0)?(?:9)?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  const match = cleanValue.match(pattern);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // If no country code in original, must start with trunk prefix
  if (!value.includes('+54')) {
    // Should start with 0 (trunk prefix)
    const originalClean = value.replace(/[\s\-()]/g, '');
    if (!originalClean.startsWith('0')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain only letters (unicode), apostrophes, hyphens, and spaces
  // Reject digits, symbols, and unusual characters
  
  // Check if string contains any digits or symbols (excluding allowed characters)
  const invalidPattern = /[0-9!@#$%^&*()_+=[\]{};':"\\|,.<>?~`]/;
  if (invalidPattern.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (unicode pattern)
  const hasLetterPattern = /[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]/;
  if (!hasLetterPattern.test(value)) {
    return false;
  }
  
  // Pattern to match valid names: starts with letter, then letters/spaces/apostrophes/hyphens
  const namePattern = /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF](?:[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF\s'-]*[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF])?$/;
  
  return namePattern.test(value);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits for most cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check card type prefixes and valid lengths
  // Visa: 4xxx-xxxx-xxxx-xxxx (13-19 digits)
  if (/^4/.test(digitsOnly)) {
    return digitsOnly.length >= 13 && digitsOnly.length <= 19 && runLuhnCheck(digitsOnly);
  }
  
  // Mastercard: 5[1-5]xxx-xxxx-xxxx-xxxx (16 digits) or 2[2-7]xxx-xxxx-xxxx-xxxx (16 digits)
  if (/^(5[1-5]|2[2-7])/.test(digitsOnly)) {
    return digitsOnly.length === 16 && runLuhnCheck(digitsOnly);
  }
  
  // American Express: 3[47]xx-xxxx-xxxx-xxxx (15 digits)
  if (/^3[47]/.test(digitsOnly)) {
    return digitsOnly.length === 15 && runLuhnCheck(digitsOnly);
  }
  
  // Discover: 6011xx-xxxx-xxxx-xxxx (16 digits) or 65xx-xxxx-xxxx-xxxx (16 digits)
  if (/^(6011|65)/.test(digitsOnly)) {
    return digitsOnly.length === 16 && runLuhnCheck(digitsOnly);
  }
  
  // If no specific pattern matched but length is valid, still check Luhn
  return digitsOnly.length >= 13 && digitsOnly.length <= 19 && runLuhnCheck(digitsOnly);
}
