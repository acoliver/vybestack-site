/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word pattern that matches words starting with prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const result = matches.filter(match => {
    const matchLower = match.toLowerCase();
    return !exceptionsLower.includes(matchLower);
  });
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern using lookbehind to find token that appears after a digit
  // This should match the complete token occurrence (digit + token)
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace (should not contain)
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':"\\|,.<>?~`]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // This pattern looks for any 2+ character sequence that repeats immediately
  const repeatedSequencePattern = /(.+)\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv4 addresses first - if found, this is NOT IPv6
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Check if this is pure IPv4 (no colons, standard dotted quad)
    const pureIPv4 = /^(?:\d{1,3}\.){3}\d{1,3}$/;
    if (pureIPv4.test(value.trim())) {
      return false; // Pure IPv4 should not match IPv6
    }
  }
  
  // IPv6 pattern - must contain colons and hex digits
  // Includes shorthand notation with ::
  const ipv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{0,4}|(?:[a-fA-F0-9]{1,4}:){0,7}:|(?::|::)[a-fA-F0-9]{1,4}\b/i;
  
  // Additional validation: IPv6 addresses contain hex digits and colons
  // They should not be pure numbers or dots only
  const hasIPv6Structure = /[a-fA-F0-9]:[a-fA-F0-9]/.test(value) || /::/.test(value);
  
  if (!hasIPv6Structure) {
    return false;
  }
  
  return ipv6Pattern.test(value);
}
