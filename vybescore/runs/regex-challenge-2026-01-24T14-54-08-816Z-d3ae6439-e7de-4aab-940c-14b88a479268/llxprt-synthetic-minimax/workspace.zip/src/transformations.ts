/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split into sentences by looking for sentence endings
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  return sentences.map(sentence => {
    // Remove leading spaces and capitalize first letter
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return trimmed;
    
    // Capitalize first letter, preserve the rest
    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
  }).join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http://, https://, www. prefixed)
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s"'<>]+(?=\s|$)/gi;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,!?;)]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't touch existing https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs with paths
  const urlPattern = /http:\/\/([^/\s]+)([^\s]*)/g;
  
  return text.replace(urlPattern, (match, host, path) => {
    let newUrl = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|=|&|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com for /docs/ paths
      newUrl += 'docs.example.com';
    } else {
      // Keep original host for other paths or when dynamic hints present
      newUrl += host;
    }
    
    newUrl += path;
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const yearPattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(yearPattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic month/day validation (not accounting for leap years or variable days)
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  return year;
}
