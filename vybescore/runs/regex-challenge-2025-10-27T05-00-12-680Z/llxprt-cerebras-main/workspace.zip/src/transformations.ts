/**
 * Capitalizes the first character of each sentence, preserves spacing rules.
 * Inserts exactly one space after sentence-ending punctuation and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence-ending punctuation (., !, ?) followed by a space or end of string
  // This regex finds the punctuation marks that end sentences
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  })
  // Ensure there's exactly one space after sentence-ending punctuation
  .replace(/([.!?])\s+/g, '$1 ')
  // Collapse multiple spaces to single spaces (but avoid breaking abbreviations)
  .replace(/(?<!\.)\s{2,}/g, ' ')
  // Trim trailing and leading whitespace
  .trim();
}

/**
 * Extracts all URLs from text and returns them as an array.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern (simplified but functional)
  const urlRegex = /\b(?:https?|ftp):\/\/[^\s/$.?#].[^\s]*\b/gi;
  const matches = text.match(urlRegex);
  return matches ? matches.map(url => url.replace(/[.!?;:,]$/, '')) : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't affect https:// URLs
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs by upgrading http to https and rewriting docs paths to docs subdomain.
 */
export function rewriteDocsUrls(text: string): string {
  // Process URLs that start with http://
  // Move /docs/* paths to docs subdomain, but skip dynamic paths
  return text.replace(
    /http:\/\/([\w.-]+)(\/[^\s]*)/gi,
    (match, domain, path) => {
      // Skip rewriting if path contains dynamic elements
      if (path.includes('cgi-bin') || 
          path.includes('?') || 
          path.includes('&') || 
          path.includes('=') ||
          path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)$/)) {
        return `https://${domain}${path}`;
      }
      
      // Rewrite docs paths to docs subdomain
      if (path.startsWith('/docs/')) {
        return `https://docs.${domain}${path}`;
      }
      
      // Otherwise, just upgrade to https
      return `https://${domain}${path}`;
    }
  );
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' when format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Check if the string matches mm/dd/yyyy format
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  // Extract components
  const [, month, day, year] = match;
  
  // Validate month and day ranges
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Basic validation for month/day
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}