export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic pattern: local-part@domain
  // Local part can contain alphanumeric chars, dots, hyphens, underscores, and plus signs
  // Domain part must follow standard domain naming rules
  
  // More comprehensive email regex that handles the requirements
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check basic email format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dots in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for basic validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's too short
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let phoneNumber = digitsOnly;
  if (phoneNumber.length === 11 && phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Now check if it's exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Match common formats with regex
  const phoneRegex = /^(\+?1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize spaces in the input
  const cleanValue = value.replace(/\s+/g, ' ').trim();
  
  // Extract digits only version
  const digitsOnly = cleanValue.replace(/\D/g, '');
  
  // Check if the country code is present
  const hasCountryCode = cleanValue.startsWith('+54');
  
  // Check if trunk prefix is present (either as 0XXX format or +54 0XXX format)
  const hasTrunkPrefix = cleanValue.includes(' 0') || cleanValue.startsWith('0');
  
  // Extract area code and subscriber number
  let processedValue = cleanValue;
  
  // Remove country code if present
  if (hasCountryCode) {
    processedValue = processedValue.substring(4).trim();
  }
  
  // Check for mobile indicator
  const hasMobileIndicator = processedValue.startsWith('9 ');
  if (hasMobileIndicator) {
    processedValue = processedValue.substring(2).trim();
  }
  
  // Check that when there's no country code, there must be a trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // For numbers with trunk prefix, ensure it's formatted properly
  if (hasTrunkPrefix && !hasCountryCode) {
    // Must start with 0 followed by area code
    if (!processedValue.startsWith('0')) {
      return false;
    }
  }
  
  // Extract digits from the processed value
  const digits = processedValue.replace(/\D/g, '');
  
  // Find where area code ends and subscriber number begins
  // Area code must be 2-4 digits and start with 1-9
  let areaCodeEnd = 0;
  for (let i = 0; i < Math.min(4, digits.length); i++) {
    if (digits[i] !== '0') {
      areaCodeEnd = i + 1;
      break;
    }
  }
  
  // Ensure we found at least 2 digits for the area code
  if (areaCodeEnd < 2) {
    areaCodeEnd = 2;
  }
  
  const areaCode = digits.substring(0, areaCodeEnd);
  const subscriberNumber = digits.substring(areaCodeEnd);
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Regex to match valid names
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols (except apostrophes and hyphens)
  const nameRegex = /^[^\d\p{S}]+$/u;
  
  // Basic check: must not be empty
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Check if name contains only valid characters
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check to reject X Æ A-12 style names
  // (names with digits even after passing the regex)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) using prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: starts with 4, 13 or 16 digits
  // Mastercard: starts with 5, 16 digits
  // AmEx: starts with 34 or 37, 15 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5\d{15}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Implement Luhn algorithm
  return runLuhnCheck(cleanValue);
}

// Helper function to run Luhn checksum algorithm
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}