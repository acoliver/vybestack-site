/**
 * Finds words starting with a prefix but excluding exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // Use word boundaries to ensure we match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for use in regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to ensure the token appears after a digit
  // and negative lookbehind to ensure it's not at the beginning of the string
  // Capture the digit and token together
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * Validates passwords according to the specified policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex looks for any sequence of 2 or more characters that immediately repeats
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern (simplified but handling common formats including :: shorthand)
  // This pattern matches IPv6 addresses but excludes IPv4 addresses
  const ipv6Regex = /(?<!\d\.)\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|(?<!\d\.)\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b|(?<!\d\.)\b(?:[0-9a-fA-F]{1,4}:)+::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b|(?<!\d\.)\b::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/g;
  
  // IPv4 regex pattern to exclude false positives
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it matches IPv4, it's not a valid IPv6 detection
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Test for IPv6 patterns
  return ipv6Regex.test(value);
}