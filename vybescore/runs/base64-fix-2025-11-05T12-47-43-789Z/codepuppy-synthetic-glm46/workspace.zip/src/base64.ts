/**
 * Encode plain text to RFC 4648 Base64.
 * Uses the canonical Base64 alphabet and includes required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode RFC 4648 Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate input is non-empty and contains only valid Base64 characters
  if (!input.trim()) {
    throw new Error('Input is empty');
  }

  // Check for invalid characters (only A-Z, a-z, 0-9, +, /, = are allowed)
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check if padding is correct (only allowed at the end and max 2 chars)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.substring(paddingIndex);
    // Padding must be at the end and can only be 1 or 2 '=' characters
    if (!/^(=){1,2}$/.test(paddingPart) || paddingIndex < input.length - 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
