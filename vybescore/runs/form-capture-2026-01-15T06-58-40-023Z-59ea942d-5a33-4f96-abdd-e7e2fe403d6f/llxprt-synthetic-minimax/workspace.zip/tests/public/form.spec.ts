import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type http from 'node:http';

let server: http.Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Import the compiled server module
  const { default: app } = await import('../../dist/server.js');
  
  // Start server on a test port
  server = app.listen(0); // Use port 0 to let OS choose available port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    
    const html = response.text;
    const $ = cheerio.load(html);
    
    // Check that form contains all required fields
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="state"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check that labels are properly associated
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('label[for="streetAddress"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('label[for="state"]').length).toBe(1);
    expect($('label[for="postalCode"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      state: 'CA',
      postalCode: '90210',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567'
    };

    // Submit the form as form data (URL encoded)
    const response = await request(server)
      .post('/submit')
      .type('form') // Send as application/x-www-form-urlencoded
      .send(testData)
      .expect(302);

    // Should redirect to thank-you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Check that data was persisted
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Clean up for next test
    fs.unlinkSync(dbPath);
  });

  it('validates required fields', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: 'Doe',
        email: 'invalid-email'
      })
      .expect(400);

    const html = response.text;
    const $ = cheerio.load(html);
    
    // Should show validation errors
    expect($('.error-container').length).toBe(1);
  });

  it('validates email format', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        state: 'CA',
        postalCode: '90210',
        country: 'United States',
        email: 'not-an-email',
        phone: '+1 555 123 4567'
      })
      .expect(400);

    const html = response.text;
    const $ = cheerio.load(html);
    
    expect($('.error-container').length).toBe(1);
  });

  it('accepts international phone formats', async () => {
    const testData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'London',
      state: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(server)
      .post('/submit')
      .type('form')
      .send(testData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
    
    // Clean up
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  it('accepts alphanumeric postal codes', async () => {
    const testData = {
      firstName: 'Carlos',
      lastName: 'Gomez',
      streetAddress: '789 Calle Principal',
      city: 'Buenos Aires',
      state: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos.gomez@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(server)
      .post('/submit')
      .type('form')
      .send(testData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
    
    // Clean up
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  it('renders thank-you page', async () => {
    // First submit to create database entry
    await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '100 Test St',
        city: 'Testville',
        state: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555 000 0000'
      })
      .expect(302);

    // Then check thank-you page
    const thankYouResponse = await request(server).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    const html = thankYouResponse.text;
    expect(html).toContain('Thank You!');
    expect(html).toContain('Why did you give your personal information');
    
    // Clean up
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });
});
