import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs from 'sql.js';

// Validation types and functions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phoneRegex = /^\+?[\d\s\-()]+$/;

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'state', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || (typeof data[field] === 'string' && data[field]!.trim() === '')) {
      errors.push({ field, message: `${field} is required` });
    }
  });

  // Email validation
  if (data.email && !emailRegex.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return errors;
}

// Database management
class DatabaseManager {
  private db: import('sql.js').Database | null = null;
  private dbPath: string;
  private initialized: boolean = false;
  private initializing: Promise<void> | null = null;

  constructor(dbPath: string) {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    // If already initialized, return immediately
    if (this.initialized) return;
    
    // If currently initializing, wait for it to complete
    if (this.initializing) {
      return this.initializing;
    }

    // Start initialization
    this.initializing = this.performInitialization();
    await this.initializing;
    this.initializing = null;
  }

  private async performInitialization(): Promise<void> {
    const SQL = await initSqlJs();

    // Create database file if it doesn't exist
    if (!fs.existsSync(this.dbPath)) {
      const emptyDb = new SQL.Database();
      fs.writeFileSync(this.dbPath, emptyDb.export());
    }

    // Load existing database
    const dbBuffer = fs.readFileSync(this.dbPath);
    this.db = new SQL.Database(dbBuffer);

    // Create table if it doesn't exist
    this.db.run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
    
    this.initialized = true;
  }

  async ensureInitialized(): Promise<void> {
    if (!this.initialized) {
      await this.initialize();
    }
  }

  async insertSubmission(data: FormData): Promise<void> {
    await this.ensureInitialized();
    
    if (!this.db) {
      throw new Error('Database not available');
    }
    
    this.db.run(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      data.firstName, data.lastName, data.streetAddress,
      data.city, data.state, data.postalCode,
      data.country, data.email, data.phone
    ]);

    // Save database to file
    if (this.db) {
      const dbBinary = this.db.export();
      fs.writeFileSync(this.dbPath, dbBinary);
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
      this.initialized = false;
    }
  }

  isInitialized(): boolean {
    return this.initialized;
  }
}

// Server setup
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

// Initialize database manager
const dbManager = new DatabaseManager(dbPath);

// Express app configuration
app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(process.cwd(), 'public')));

// Initialize database immediately
dbManager.initialize().catch(error => {
  console.error('Failed to initialize database:', error);
  // Don't exit in test environment
  if (process.env.NODE_ENV !== 'test') {
    process.exit(1);
  }
});

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(process.cwd(), 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    formData: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  console.log('Form submission received:', req.body);
  
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    state: req.body.state,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  console.log('Parsed form data:', formData);

  const errors = validateFormData(formData);
  console.log('Validation errors:', errors);

  if (errors.length > 0) {
    console.log('Validation failed, re-rendering form with errors');
    res.status(400).render('form', {
      errors,
      formData: req.body,
      title: 'Contact Form - Please Fix Errors'
    });
    return;
  }

  // Insert into database
  try {
    console.log('Inserting data into database');
    await dbManager.insertSubmission(formData as FormData);
    console.log('Database insert successful, redirecting to thank-you');
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'Internal server error. Please try again.' }],
      formData: req.body,
      title: 'Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Export app for testing
export default app;

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  dbManager.close();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, shutting down gracefully...');
  dbManager.close();
  process.exit(0);
});

// Initialize database immediately when module loads
let dbInitialized = false;

async function initializeDatabase() {
  if (!dbInitialized) {
    await dbManager.initialize();
    dbInitialized = true;
  }
}

// Routes
app.get('/', async (req: Request, res: Response) => {
  await initializeDatabase();
  res.render('form', { 
    errors: [], 
    formData: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  console.log('Form submission received:', req.body);
  
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    state: req.body.state,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  console.log('Parsed form data:', formData);

  const errors = validateFormData(formData);
  console.log('Validation errors:', errors);

  if (errors.length > 0) {
    console.log('Validation failed, re-rendering form with errors');
    res.status(400).render('form', {
      errors,
      formData: req.body,
      title: 'Contact Form - Please Fix Errors'
    });
    return;
  }

  // Insert into database
  try {
    console.log('Inserting data into database');
    await dbManager.insertSubmission(formData as FormData);
    console.log('Database insert successful, redirecting to thank-you');
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'Internal server error. Please try again.' }],
      formData: req.body,
      title: 'Contact Form - Error'
    });
  }
});

app.get('/thank-you', async (req: Request, res: Response) => {
  await initializeDatabase();
  res.render('thank-you', { title: 'Thank You!' });
});

// Start server function
async function startServer() {
  try {
    await initializeDatabase();
    console.log(`Database initialized at ${dbPath}`);
    
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Always start the server when this module is executed directly
if (require.main === module) {
  startServer();
}
