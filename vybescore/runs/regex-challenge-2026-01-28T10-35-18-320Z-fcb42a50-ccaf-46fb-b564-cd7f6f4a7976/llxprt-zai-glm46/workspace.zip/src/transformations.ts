/**
 * Capitalize the first character of each sentence.
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces sensibly
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around sentence terminators
  // Replace multiple spaces with single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure space after sentence terminators if not present
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first character of text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize first letter after sentence terminators, but be careful with abbreviations
  // Common abbreviations to avoid capitalizing after
  const abbreviations = ['mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'vs', 'etc', 'eg', 'ie', 'approx', 'no'];
  
  // Split by sentence terminators and capitalize
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    // Check if this might be an abbreviation by looking back
    const beforeMatch = result.substring(0, result.indexOf(match)).match(/[.!?]\s*\w+$/);
    if (beforeMatch) {
      const lastWord = result.substring(0, result.indexOf(match)).match(/\b(\w+)\.$/);
      if (lastWord && abbreviations.includes(lastWord[1].toLowerCase())) {
        return prefix + letter; // Don't capitalize after abbreviation
      }
    }
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern matching http, https, www
  // Captures the full URL but excludes trailing punctuation
  // eslint-disable-next-line no-useless-escape
  const urlRegex = /(https?:\/\/|www\.)[^\s<"{}\|^`[\]]+[^\s<"{}\|^[\].,!?;:]/g;
  
  const matches = text.match(urlRegex);
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation if present
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://...
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/[^\s]*)/g, (match, path) => {
    // Always upgrade to https
    let newUrl = 'https://example.com' + path;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for exclusion criteria
      const exclusions = [
        /cgi-bin/,
        /[?&=]/,  // Query strings
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[/?]|$)/i  // Legacy extensions
      ];
      
      // Only rewrite host if no exclusions match
      const hasExclusion = exclusions.some(pattern => pattern.test(path));
      
      if (!hasExclusion) {
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Returns 'N/A' when format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // More specific day validation based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
