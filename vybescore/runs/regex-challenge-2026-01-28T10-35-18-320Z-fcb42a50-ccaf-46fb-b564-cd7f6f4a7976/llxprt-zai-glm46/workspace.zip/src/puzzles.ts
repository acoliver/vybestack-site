/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words with the prefix
  // \\b ensures word boundaries
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to ensure token follows a digit
  // Match the digit plus the token together
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to strong password policy.
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric, non-space)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // This pattern captures any 2-4 character sequence that repeats immediately
  const repeatedSequencePattern = /(.{2,4})\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true only if IPv6 is detected and not confused with IPv4.
 */
export function containsIPv6(value: string): boolean {
  // More precise IPv6 pattern
  const ipv6PatternPrecise = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;
  
  // Check if it contains IPv6
  const hasIPv6 = ipv6PatternPrecise.test(value);
  
  // Return true only if IPv6 pattern is found
  return hasIPv6;
}
