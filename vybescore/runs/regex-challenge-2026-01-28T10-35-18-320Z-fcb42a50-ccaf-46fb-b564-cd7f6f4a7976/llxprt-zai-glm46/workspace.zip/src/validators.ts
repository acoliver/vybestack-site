export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to common patterns.
 * Accepts: user@example.com, name@tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern:
  // - Local part: alphanumeric, dots, hyphens, plus, but no consecutive dots, no leading/trailing dots
  // - @ separator
  // - Domain: alphanumeric labels with hyphens, but no underscores
  // - TLD: at least 2 letters
  // - Allow multiple @ for tags like name+tag@example.com
  const emailRegex = /^(?!.*\.\.)[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?!.*\.\.)(?!.*_)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: area codes starting with 0 or 1, too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let effectiveDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    effectiveDigits = digitsOnly.slice(1);
  } else if (digitsOnly.length > 11) {
    // Too long for standard US format
    return false;
  }
  
  // Must have exactly 10 digits after removing country code
  if (effectiveDigits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = effectiveDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Optional: allow extensions if configured
  if (options?.allowExtensions) {
    const usPhoneWithExtensionRegex = /^(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})(?:\s?(?:ext|ex|x)\s?\d+)?$/i;
    return usPhoneWithExtensionRegex.test(value);
  }
  
  // Check if the original format is valid
  const usPhoneRegex = /^(?:\+?1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  return usPhoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers for mobile and landline formats.
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, parentheses)
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Test with country code
  if (cleaned.startsWith('+54')) {
    const match = cleaned.match(/^\+54(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/);
    if (match) {
      const areaCode = match[1];
      const subscriber = match[2];
      // Area code must be 2-4 digits
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      // Subscriber must be 6-8 digits
      if (subscriber.length < 6 || subscriber.length > 8) return false;
      return true;
    }
  }
  
  // Test without country code (must start with 0)
  const match = cleaned.match(/^0(?:9)?([1-9]\d{1,3})(\d{6,8})$/);
  if (match) {
    const areaCode = match[1];
    const subscriber = match[2];
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    // Subscriber must be 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    return true;
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, and "X Æ A-12" style names (with digits in the name)
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  // No digits or special symbols allowed
  const nameRegex = /^[\p{L}\p{M}'-][\p{L}\p{M}'\s-]*[\p{L}\p{M}'-]$/u;
  
  // Check if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check if contains special symbols (excluding allowed apostrophes, hyphens, spaces)
  const symbolsRegex = /[^\p{L}\p{M}'\s-]/u;
  if (symbolsRegex.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Helper function to perform Luhn checksum validation on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa, Mastercard, AmEx).
 * Checks prefixes, lengths, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any card type
  const validLength = visaRegex.test(cardNumber) || mastercardRegex.test(cardNumber) || amexRegex.test(cardNumber);
  
  if (!validLength) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cardNumber);
}
