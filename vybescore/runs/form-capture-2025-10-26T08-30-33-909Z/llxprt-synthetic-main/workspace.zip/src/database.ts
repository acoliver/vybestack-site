import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import initSqlJs from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// Define type for Database
type Database = {
  run: (query: string, params?: unknown[]) => void;
  export: () => Uint8Array;
  close: () => void;
  get: (query: string, params?: unknown[]) => { id?: number; first_name?: string } | undefined;
};

// Initialize SQLite database with sql.js
async function initDatabase(): Promise<Database> {
  // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
  const SQL = await initSqlJs();
  
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
  
  let db: Database;
  
  try {
    // Try to load existing database
    const fileBuffer = fs.readFileSync(dbPath);
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    db = new SQL.Database(fileBuffer) as Database;
  } catch (error) {
    // Database doesn't exist, create a new one
    // eslint-disable-next-line @typescript-eslint/no-unsafe-assignment
    db = new SQL.Database() as Database;
    
    // Read and execute schema
    const schema = fs.readFileSync(schemaPath, 'utf8');
    const statements = schema.split(';').filter(stmt => stmt.trim());
    
    statements.forEach(statement => {
      if (statement.trim()) {
        db.run(statement);
      }
    });
    
    // Save the initial database
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
  
  return db;
}

export default initDatabase;