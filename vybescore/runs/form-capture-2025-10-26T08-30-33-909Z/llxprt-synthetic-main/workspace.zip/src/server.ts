import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initDatabase from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

const app = express();

// Set up view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Define form data type
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Define database type
interface Database {
  run: (query: string, params?: unknown[]) => void;
  export: () => Uint8Array;
  close: () => void;
  get: (query: string, params?: unknown[]) => { id?: number; first_name?: string } | undefined;
}

// Initialize database variable - let it be undefined until initialization
let db: Database | undefined;

// Ensure directory for database exists
const dataDir = path.join(__dirname, '..', 'data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Form validation function
function validateForm(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  // Required fields validation
  if (!formData.firstName?.trim()) {
    errors.push('First name is required');
  }

  if (!formData.lastName?.trim()) {
    errors.push('Last name is required');
  }

  if (!formData.streetAddress?.trim()) {
    errors.push('Street address is required');
  }

  if (!formData.city?.trim()) {
    errors.push('City is required');
  }

  if (!formData.stateProvince?.trim()) {
    errors.push('State/Province/Region is required');
  }

  if (!formData.postalCode?.trim()) {
    errors.push('Postal code is required');
  }

  if (!formData.country?.trim()) {
    errors.push('Country is required');
  }

  // Email validation
  if (!formData.email?.trim()) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation - digits, spaces, parentheses, dashes, and leading +
  if (!formData.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!/^[+]?[0-9\s()-.]+$/.test(formData.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Postal code validation - alphanumeric values
  if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
    errors.push('Postal code should only contain letters and numbers');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Initialize database - can be awaited
async function initializeDatabase() {
  try {
    db = await initDatabase();
    return true;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    return false;
  }
}

// Initialize database synchronously as part of module initialization
initializeDatabase();

// Routes
app.get('/', (req: Request, res: Response) => {
  // If database is not yet initialized, render with a warning
  if (!db) {
    return res.status(500).send('Database is initializing. Please try again later.');
  }
  
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  if (!db) {
    return res.status(500).render('form', {
      errors: ['Database is initializing. Please try again later.'],
      values: req.body
    });
  }

  const formData: FormData = req.body;
  const validation = validateForm(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  try {
    // Insert data into database
    db.run(`
      INSERT INTO submissions (
        first_name, 
        last_name, 
        street_address, 
        city, 
        state_province, 
        postal_code, 
        country, 
        email, 
        phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    // Save database to file after insert
    const data = db.export();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    fs.writeFileSync(dbPath, Buffer.from(data));

    // Note: Last insert rowid could be retrieved if needed for future enhancements
    // const result = db.get('SELECT last_insert_rowid() as id');
    
    // Redirect to thank you page with the first name parameter
    return res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: ['An error occurred while saving your information. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Route to retrieve a submission's first name by id
app.get('/submission/:id', (req: Request, res: Response) => {
  if (!db) {
    return res.status(500).json({ error: 'Database is initializing. Please try again later.' });
  }

  try {
    const id = parseInt(req.params.id, 10);
    if (isNaN(id)) {
      return res.status(400).json({ error: 'Invalid submission ID' });
    }
    
    const result = db.get('SELECT first_name FROM submissions WHERE id = ?', [id]);
    
    if (!result) {
      return res.status(404).json({ error: 'Submission not found' });
    }
    
    return res.json({ firstName: result.first_name });
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).json({ error: 'Database error' });
  }
});

// Async server startup with retry logic for database initialization
async function startServer() {
  let retries = 3;
  while (!db && retries > 0) {
    console.log(`Waiting for database to initialize... (${retries} attempts remaining)`);
    await new Promise(resolve => setTimeout(resolve, 500));
    retries--;
  }

  if (!db) {
    console.error('Failed to initialize database after multiple attempts. Exiting.');
    process.exit(1);
  }

  const server = app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
  });

  // Gracefully handle shutdown
  let isShuttingDown = false;
  const gracefulShutdown = () => {
    if (isShuttingDown) return;
    isShuttingDown = true;
    
    console.log('Shutting down gracefully...');
    
    // Close database connection
    if (db) {
      try {
        db.close();
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }
    
    // Close server
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
    
    // Force close if graceful shutdown takes too long
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 5000);
  };

  // Handle termination signals
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer();

// Export server for testing
export default app;