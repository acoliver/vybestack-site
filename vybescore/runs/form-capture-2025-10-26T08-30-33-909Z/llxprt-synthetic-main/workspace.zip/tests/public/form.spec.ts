import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

// Import server module
const serverModule = await import('../../src/server.js');
const app = serverModule.default;

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database file before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Give the server a moment to initialize the database
  await new Promise(resolve => setTimeout(resolve, 1500));
});

afterAll(async () => {
  // Clean up database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Verify form exists and all required fields are present
    const form = $('form[method="post"][action="/submit"]');
    expect(form.length).toBe(1);
    
    // Check all required fields are present
    const fields = [
      { id: 'firstName', label: 'First name' },
      { id: 'lastName', label: 'Last name' },
      { id: 'streetAddress', label: 'Street address' },
      { id: 'city', label: 'City' },
      { id: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', label: 'Country' },
      { id: 'email', label: 'Email' },
      { id: 'phone', label: 'Phone number' }
    ];
    
    fields.forEach(field => {
      const input = $(`#${field.id}`);
      const label = $(`label[for="${field.id}"]`);
      
      expect(input.length).toBe(1);
      expect(label.length).toBe(1);
      expect(input.attr('name')).toBe(field.id);
      expect(label.text().trim()).toBe(field.label);
    });
  });

  it('persists submission and redirects', async () => {
    // Make sure database doesn't exist initially
    expect(fs.existsSync(dbPath)).toBe(false);
    
    // Submit form with valid data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank-you page with first name parameter
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you?firstName=John');
    
    // Database file should be created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Also test retrieving the submission via our API endpoint
    const submissionResponse = await request(app)
      .get('/submission/1')
      .expect(200);
    
    expect(submissionResponse.body.firstName).toBe('John');
  });

  it('shows thank-you page with first name', async () => {
    const response = await request(app)
      .get('/thank-you')
      .query({ firstName: 'Jane' });
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you, Jane!');
    expect(response.text).toContain('stranger on the internet');
  });

  it(' validates international inputs correctly', async () => {
    // Test with valid Argentine postal code and UK postal code
    const internationalData = {
      firstName: 'Juan',
      lastName: 'García',
      streetAddress: 'Av. Corrientes 1000',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000', // Argentine postal code format
      country: 'Argentina',
      email: 'juan@example.com',
      phone: '+54 9 11 1234-5678' // Argentine phone format
    };
    
    let response = await request(app)
      .post('/submit')
      .send(internationalData);
    
    // Should redirect without errors
    expect(response.status).toBe(302);
    
    // Test with UK postal code
    internationalData.postalCode = 'SW1A 1AA'; // UK postal code
    internationalData.phone = '+44 20 7946 0958'; // UK phone
    
    response = await request(app)
      .post('/submit')
      .send(internationalData);
    
    // Should redirect without errors
    expect(response.status).toBe(302);
    
    // Test with invalid email
    const invalidEmailData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'invalid-email',
      phone: '+1 555-123-4567'
    };
    
    response = await request(app)
      .post('/submit')
      .send(invalidEmailData);
    
    // Should show form again with errors
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });
});