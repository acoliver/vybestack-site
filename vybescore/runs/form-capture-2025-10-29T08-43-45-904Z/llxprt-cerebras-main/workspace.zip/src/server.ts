import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import { Server } from 'node:http';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
const dbPath = path.resolve(__dirname, '../data/submissions.sqlite');
let db: Database | null = null;

// Initialize the database
async function initDatabase() {
  const SQL = await initSqlJs({
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
  });
  
  // Load existing database or create a new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    saveDatabase();
  }
}

// Save database to file
function saveDatabase() {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  }
}

// Helper to validate email
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  return emailRegex.test(email);
}

// Helper to validate phone number
function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading plus
  // Using a character class that doesn't create range errors
  const phoneRegex = /^[+\\d\\s\\-()]+$/;
  return phoneRegex.test(phone);
}

// Helper to validate postal code
function validatePostalCode(postalCode: string): boolean {
  // Simple regex to allow alphanumeric characters, spaces, and hyphens
  const postalCodeRegex = /^[A-Za-z0-9\\s\\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Helper to check if string is not empty
function isNotEmpty(value: string): boolean {
  return value.trim().length > 0;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: null, values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;

  // Validation
  const errors: string[] = [];
  const values = req.body;

  if (!isNotEmpty(firstName)) errors.push('First name is required');
  if (!isNotEmpty(lastName)) errors.push('Last name is required');
  if (!isNotEmpty(streetAddress)) errors.push('Street address is required');
  if (!isNotEmpty(city)) errors.push('City is required');
  if (!isNotEmpty(stateProvince)) errors.push('State/Province is required');
  if (!isNotEmpty(postalCode)) errors.push('Postal code is required');
  if (!isNotEmpty(country)) errors.push('Country is required');
  if (!isNotEmpty(email) || !validateEmail(email)) errors.push('Valid email is required');
  if (!isNotEmpty(phone) || !validatePhone(phone)) errors.push('Valid phone number is required');
  if (!isNotEmpty(postalCode) || !validatePostalCode(postalCode)) errors.push('Valid postal code is required');

  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values });
  }

  // Insert into database
  const stmt = db!.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  stmt.run([
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  ]);
  stmt.free();
  saveDatabase();

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Render the thank-you page
  res.render('thank-you', { firstName: 'Friend' });
});

// Graceful shutdown
let server: Server | null = null;

function startServer() {
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

function closeServer() {
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db) {
    db.close();
    console.log('Database closed');
  }
}

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  closeServer();
  process.exit(0);
});

// Initialize and start server
initDatabase().then(() => {
  startServer();
}).catch((err) => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

export { app, closeServer };