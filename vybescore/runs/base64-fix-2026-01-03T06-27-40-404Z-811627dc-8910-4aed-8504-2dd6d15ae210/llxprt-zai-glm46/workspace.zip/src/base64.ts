/**
 * Regular expression for validating Base64 strings.
 * Matches the canonical Base64 alphabet: A-Z, a-z, 0-9, +, /, with optional padding (=).
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]+=*$/;

/**
 * Maximum allowed length of a Base64 string to prevent potential abuse.
 */
const MAX_BASE64_LENGTH = 10_000_000; // ~7.5MB of decoded data

/**
 * Encodes a UTF-8 string to standard Base64 using the canonical alphabet.
 * Padding characters (=) are included when required by the Base64 specification.
 *
 * @param input - The UTF-8 string to encode.
 * @returns The Base64-encoded string with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates the padding of a Base64 string.
 * @throws {Error} If padding is invalid.
 */
function validatePadding(input: string): void {
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64: too many padding characters');
    }
    const beforePadding = input.replace(/=+$/, '');
    if (beforePadding.includes('=')) {
      throw new Error('Invalid Base64: padding characters in the middle');
    }
  }
}

/**
 * Validates the overall length of a Base64 string.
 * Base64 encodes 3 bytes into 4 characters, so the total length
 * (including any padding) must be a multiple of 4.
 * @throws {Error} If the length is invalid.
 */
function validateLength(input: string): void {
  if (input.length % 4 !== 0) {
    throw new Error('Invalid Base64: length must be a multiple of 4');
  }
}

/**
 * Decodes a Base64 string back to a UTF-8 string.
 * Accepts valid Base64 input with or without padding.
 * Rejects invalid input by throwing an error.
 *
 * @param input - The Base64 string to decode.
 * @returns The decoded UTF-8 string.
 * @throws {Error} If the input contains invalid Base64 characters or has invalid padding.
 */
export function decode(input: string): string {
  if (input.length === 0) {
    throw new Error('Base64 input cannot be empty');
  }

  if (input.length > MAX_BASE64_LENGTH) {
    throw new Error('Base64 input exceeds maximum allowed length');
  }

  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64: contains characters outside the Base64 alphabet');
  }

  validatePadding(input);
  validateLength(input);

  const buffer = Buffer.from(input, 'base64');
  
  // Check for non-UTF-8 bytes (i.e., invalid sequences).
  // In Node, Buffer.toString('utf8') replaces invalid bytes with the replacement char (�).
  // We re-encode; if any replacement chars appear, the original wasn't valid UTF-8.
  const decoded = buffer.toString('utf8');
  const reEncoded = Buffer.from(decoded, 'utf8');
  if (!buffer.equals(reEncoded)) {
    throw new Error('Invalid Base64: not valid UTF-8');
  }
  
  return decoded;
}
