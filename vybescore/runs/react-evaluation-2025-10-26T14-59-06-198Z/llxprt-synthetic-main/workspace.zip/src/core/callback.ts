/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create observer that will track dependencies and execute the callback
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies on initial creation
  updateObserver(observer)
  
  let disposed = false
  
  // Return unsubscribe function
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    // This effectively removes the callback from the dependency graph
    observer.value = undefined
    
    // Set updateFn to a no-op function to prevent further execution
    observer.updateFn = () => value as T
  }
  
  // Hook into observer notification process
  // When dependencies change, updateObserver will be called
  // and our updateFn will execute with the new value
  const originalUpdateFn = observer.updateFn
  
  // Override the observer's updateFn to execute the callback function
  observer.updateFn = (prev?: T) => {
    if (disposed) return value as T
    
    // Execute the original callback function
    const result = originalUpdateFn(prev)
    return result as T
  }
  
  return unsubscribe
}