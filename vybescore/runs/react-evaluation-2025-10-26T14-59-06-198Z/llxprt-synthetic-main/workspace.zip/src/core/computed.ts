/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

// Global registry to track dependencies between observers
const dependencies = new Map<string, Set<ObserverR>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Helper function to determine equality
  const isEqual: EqualFn<T> | undefined = (() => {
    if (typeof _equal === 'function') return _equal
    if (_equal === true) return (prev: T, next: T) => prev === next
    return undefined
  })()

  // Create a unique ID for this computed value
  const id = options?.name || `computed-${Math.random().toString(36).substr(2, 9)}`

  // Create observer with initial value
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initial computation
  updateObserver(observer)
  
  // Create dependency set for this observer using its ID as key
  const deps = new Set<ObserverR>()
  dependencies.set(id, deps)

  // Override the observer's update function
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prev?: T) => {
    const newValue = originalUpdateFn(prev)
    
    // Update the value if it changed (or always update if no equality function)
    if (isEqual === undefined || prev === undefined || !isEqual(prev, newValue)) {
      observer.value = newValue
      
      // Update all dependent observers
      deps.forEach(dep => {
        updateObserver(dep as Observer<T>)
      })
    }
    
    return newValue
  }

  // Getter function that establishes dependencies when accessed
  const getter: GetterFn<T> = () => {
    // Get current active observer (if any)
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add the active observer as a dependent of this computed value
      deps.add(activeObserver)
    }
    
    return observer.value!
  }

  return getter
}