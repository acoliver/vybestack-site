/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

// Global registry to track dependents for each input
const dependents = new Map<string, Set<ObserverR>>()

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Helper function to determine equality
  const isEqual: EqualFn<T> = (prev: T, next: T): boolean => {
    if (typeof _equal === 'function') return _equal(prev, next)
    if (_equal === true) return prev === next
    return prev === next
  }

  // Create unique ID for this input
  const id = options?.name || `input-${Math.random().toString(36).substr(2, 9)}`

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: isEqual,
  }

  // Register this input's dependents using its ID as key
  const deps = new Set<ObserverR>()
  dependents.set(id, deps)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Store the observer to notify when value changes
      s.observer = observer
      
      // Also add to dependents set for direct notifications
      deps.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if values should be considered equal
    const valuesEqual = typeof s.equalFn === 'function' 
      ? s.equalFn(s.value, nextValue)
      : s.value === nextValue
      
    // Only update if values are different according to equality function
    if (!valuesEqual) {
      s.value = nextValue
      
      // Direct notification to assigned observer (if any)
      if (s.observer) {
        const observer = s.observer as Observer<T>
        updateObserver(observer)
      }
      
      // Notify all registered dependents
      deps.forEach(dep => {
        // Skip the direct observer if already notified
        if (s.observer && dep !== s.observer) {
          updateObserver(dep as Observer<T>)
        }
      })
    }
    return s.value
  }

  return [read, write]
}