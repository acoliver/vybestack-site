const PADDING_CHAR = '=';
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Regular expression to validate standard Base64 strings.
 * Allows the canonical alphabet (A-Z, a-z, 0-9, +, /) with optional padding (=).
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Check if a string is valid Base64.
 * Valid Base64 consists of characters from the canonical alphabet
 * and may have 0, 1, or 2 padding characters at the end.
 * 
 * This function accepts both padded and unpadded input.
 * Unpadded input must have a length that's a multiple of 4.
 */
function isValidBase64(input: string): boolean {
  // Empty input is invalid
  if (input.length === 0) {
    return false;
  }

  // Check character set validity - must have at least one base64 char
  if (!BASE64_REGEX.test(input)) {
    return false;
  }

  // Check padding rules: padding can only appear at the end
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    // Padding length must be 0, 1, or 2
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return false;
    }
    // Padding characters can only appear at the very end
    const paddingIndex = input.indexOf(PADDING_CHAR);
    // Check that there are no non-padding characters after padding starts
    return input.slice(paddingIndex).replace(/=/g, '') === '';
  }

  return true;
}

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding (=).
 */
export function encode(input: string): string {
  // Use standard base64 encoding, not base64url
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and recovers the original string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the input format
  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    // Buffer.from with 'base64' encoding handles both padded and unpadded input
    const buffer = Buffer.from(trimmed, 'base64');
    
    // If the buffer is empty but input wasn't empty, the input was invalid
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error(INVALID_BASE64_ERROR);
    }

    // Re-encode and compare to detect malformed input that Buffer silently decoded
    // This catches cases like "abc" which decodes to garbage data
    const reencoded = buffer.toString('base64');
    
    // Normalize both for comparison - strip all padding
    const paddingRegex = /=+$/g;
    const normalizedInput = trimmed.replace(paddingRegex, '');
    const normalizedReencoded = reencoded.replace(paddingRegex, '');
    
    // If re-encoding doesn't match the original (after normalization),
    // the input was malformed or contained non-canonical data
    if (normalizedInput !== normalizedReencoded) {
      throw new Error(INVALID_BASE64_ERROR);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
