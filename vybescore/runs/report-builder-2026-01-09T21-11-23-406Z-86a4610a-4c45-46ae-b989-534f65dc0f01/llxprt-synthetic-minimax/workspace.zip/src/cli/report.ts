#!/usr/bin/env node

import { readFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): CLIOptions {
  const args = argv.slice(2); // Remove node and script name
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  const formatArgIndex = args.findIndex((arg) => {
    return arg === '--format' || arg.startsWith('--format=');
  });
  
  if (formatArgIndex === -1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  let format: string;
  const formatArg = args[formatArgIndex];
  if (formatArg.includes('=')) {
    format = formatArg.split('=')[1];
  } else {
    if (formatArgIndex + 1 >= args.length) {
      console.error('Error: --format requires a value');
      process.exit(1);
    }
    format = args[formatArgIndex + 1];
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }
  
  // Handle --output argument
  const outputArgIndex = args.findIndex((arg) => {
    return arg === '--output' || arg.startsWith('--output=');
  });
  
  let includeTotals = false;
  const includeTotalsIndex = args.findIndex((arg) => {
    return arg === '--includeTotals';
  });
  includeTotals = includeTotalsIndex !== -1;
  
  const options: CLIOptions = {
    dataFile,
    format: format as 'markdown' | 'text',
    includeTotals
  };
  
  if (outputArgIndex !== -1) {
    const outputArg = args[outputArgIndex];
    if (outputArg.includes('=')) {
      options.outputPath = outputArg.split('=')[1];
    } else {
      if (outputArgIndex + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.outputPath = args[outputArgIndex + 1];
    }
  }
  
  return options;
}

function readAndParseJSON(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(rawData);
    
    // Validate required fields
    if (!data.title || !data.summary || !data.entries) {
      throw new Error('Missing required fields: title, summary, and entries are required');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid entries format: entries must be an array');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: entries must have 'label' (string) and 'amount' (number)`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading JSON file: ${error.message}`);
    } else {
      console.error('Error reading JSON file: Invalid JSON format');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    // For file output, we could implement file writing here
    // But the requirement says output goes to stdout unless --output is provided
    // Since we're not implementing file writing for now, we'll just handle stdout
    console.log(content);
  } else {
    console.log(content);
  }
}

// Main execution
function main(): void {
  try {
    const options = parseArgs(process.argv);
    const data = readAndParseJSON(options.dataFile);
    const report = renderReport(data, options.format, options.includeTotals);
    writeOutput(report, options.outputPath);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
