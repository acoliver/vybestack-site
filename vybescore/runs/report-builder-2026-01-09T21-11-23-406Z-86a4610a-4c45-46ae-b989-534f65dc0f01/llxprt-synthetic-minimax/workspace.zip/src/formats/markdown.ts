import { ReportData } from '../types/index.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title with heading
  lines.push(`# ${data.title}`);
  lines.push(''); // blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Entries section
  lines.push('## Entries');
  
  // Bullet list for entries
  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  }
  
  // Optional total
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0).toFixed(2);
    lines.push('');
    lines.push(`**Total:** $${total}`);
  }
  
  return lines.join('\n');
}