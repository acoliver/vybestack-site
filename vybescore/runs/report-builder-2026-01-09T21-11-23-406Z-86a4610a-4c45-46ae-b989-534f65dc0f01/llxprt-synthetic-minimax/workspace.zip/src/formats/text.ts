import { ReportData } from '../types/index.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push(''); // blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Entries heading
  lines.push('Entries:');
  
  // Bullet list for entries
  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    lines.push(`- ${entry.label}: $${amount}`);
  }
  
  // Optional total
  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0).toFixed(2);
    lines.push('');
    lines.push(`Total: $${total}`);
  }
  
  return lines.join('\n');
}