/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equality function
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a, b) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (_equal) {
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equalFn if available
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (!hasChanged) return s.value
    
    s.value = nextValue
    notifyObservers(s)
    return s.value
  }

  return [read, write]
}
