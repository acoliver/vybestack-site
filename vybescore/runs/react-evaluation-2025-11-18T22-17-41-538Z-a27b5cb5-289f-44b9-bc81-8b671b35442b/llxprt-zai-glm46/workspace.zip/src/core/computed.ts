/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  addObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a, b) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (_equal) {
    equalFn = _equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      const newValue = updateFn(prevValue)
      // Only update if value actually changed
      if (equalFn && prevValue !== undefined && equalFn(prevValue, newValue)) {
        return prevValue
      }
      return newValue
    },
  }
  
  // Add to global observer list
  addObserver(o)
  
  // Initial computation
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    // Track dependencies when accessing computed value
    const observer = getActiveObserver()
    if (observer) o.observer = observer
    return o.value as T
  }
  
  return getter
}
