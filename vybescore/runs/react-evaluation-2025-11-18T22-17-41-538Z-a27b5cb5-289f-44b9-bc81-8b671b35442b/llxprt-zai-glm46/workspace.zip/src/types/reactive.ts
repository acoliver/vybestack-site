/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observer?: ObserverR | undefined
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observer) {
    const observer = subject.observer as Observer<T>
    updateObserver(observer)
  }
  
  // Update all registered observers to ensure dependencies are recalculated
  updateAllObservers()
}

// Global list of all observers for proper cleanup
const allObservers = new Set()

export function addObserver<T>(observer: Observer<T>): void {
  allObservers.add(observer)
}

export function removeObserver<T>(observer: Observer<T>): void {
  allObservers.delete(observer)
}

export function updateAllObservers(): void {
  // Create a copy to avoid issues with observers being added/removed during iteration
  const observers = Array.from(allObservers)
  observers.forEach(observer => {
    // Always update since updateFn is required for Observer
    updateObserver(observer as Observer<unknown>)
  })
}
