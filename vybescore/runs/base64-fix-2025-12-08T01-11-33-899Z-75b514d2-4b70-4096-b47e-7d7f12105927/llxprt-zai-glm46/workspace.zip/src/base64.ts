/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate Base64 format - only allow characters from standard Base64 alphabet and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }
  
  // Check for invalid padding patterns
  if (input.includes('=')) {
    const paddingStart = input.indexOf('=');
    
    // Check for padding at wrong positions (should only be at the end)
    if (input.substring(paddingStart).split('').some(char => char !== '=')) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Only allow 1 or 2 padding characters at the end
    const padding = input.substring(paddingStart);
    if (padding.length > 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}
