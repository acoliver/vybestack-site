/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Validate if a string is valid Base64.
 * Checks for valid characters. Padding is optional for decoding.
 */
function isValidBase64(input: string): boolean {
  // Empty input is not valid
  if (input.length === 0) {
    return false;
  }

  // Base64 can only contain A-Z, a-z, 0-9, +, /, and = (for padding)
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Check that padding, if present, is only at the end and in correct amounts
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    const nonPaddingLength = input.length - paddingLength;
    
    // Padding can only be 1 or 2 characters
    // When padding is present, the total length must be divisible by 4
    // There must be at least 2 non-padding characters before padding
    return paddingLength <= 2 && 
           input.length % 4 === 0 && 
           nonPaddingLength >= 2;
  }

  // Without padding, length should still be reasonable (at least 2 chars)
  return input.length >= 2;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding actually succeeded (Buffer.from doesn't always throw)
    // If the input was invalid, the buffer might be empty or contain null bytes
    // A simple check is to verify the buffer has content for non-empty input
    if (buffer.length === 0 && trimmed.length > 0) {
      // This might indicate invalid base64 that silently failed
      // But could also be legitimate (e.g., decoding empty content)
      // Let's verify by trying to re-encode
      const reencoded = buffer.toString('base64');
      if (reencoded === '' && !/^AA==$/.test(trimmed) && !/^AAA=$/.test(trimmed)) {
        throw new Error(INVALID_BASE64_ERROR);
      }
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
