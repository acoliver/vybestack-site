import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    let page: number | undefined;
    let limit: number | undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      if (pageParam === '' || isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'Page must be a numeric value' });
      }
      page = Number(pageParam);
      if (!Number.isInteger(page) || page < 1 || page > 1000) {
        return res.status(400).json({ error: 'Page must be an integer between 1 and 1000' });
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      if (limitParam === '' || isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'Limit must be a numeric value' });
      }
      limit = Number(limitParam);
      if (!Number.isInteger(limit) || limit < 1 || limit > 100) {
        return res.status(400).json({ error: 'Limit must be an integer between 1 and 100' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
