#!/usr/bin/env node

import fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, Format, ReportOptions } from '../types.js';

const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  dataFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const defaultArgs: CliArgs = {
    dataFile: '',
    format: 'markdown',
    outputPath: undefined,
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      switch (arg) {
        case '--format': {
          i++;
          const format = args[i] as Format;
          if (!formatters[format]) {
            throw new Error(`Unsupported format: ${format}`);
          }
          defaultArgs.format = format;
          break;
        }
        
        case '--output': {
          i++;
          defaultArgs.outputPath = args[i];
          break;
        }
        
        case '--includeTotals':
          defaultArgs.includeTotals = true;
          break;
        
        default:
          throw new Error(`Unknown option: ${arg}`);
      }
    } else if (!defaultArgs.dataFile) {
      defaultArgs.dataFile = arg;
    }
  }

  if (!defaultArgs.dataFile) {
    throw new Error('Data file path is required');
  }

  return defaultArgs;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as object;
  
  if (!('title' in obj) || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title field');
  }
  
  if (!('summary' in obj) || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary field');
  }
  
  if (!('entries' in obj) || !Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries field');
  }
  
  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry ${i} is not an object`);
    }
    
    if (!('label' in entry) || typeof entry.label !== 'string') {
      throw new Error(`Invalid report data: entry ${i} missing or invalid label field`);
    }
    
    if (!('amount' in entry) || typeof entry.amount !== 'number') {
      throw new Error(`Invalid report data: entry ${i} missing or invalid amount field`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));
    
    if (!fs.existsSync(args.dataFile)) {
      throw new Error(`Data file not found: ${args.dataFile}`);
    }
    
    const fileContent = fs.readFileSync(args.dataFile, 'utf8');
    let data: unknown;
    
    try {
      data = JSON.parse(fileContent);
    } catch {
      throw new Error(`Invalid JSON in data file: ${args.dataFile}`);
    }
    
    const reportData = validateReportData(data);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    const formatter = formatters[args.format];
    const output = formatter(reportData, options);
    
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output);
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
