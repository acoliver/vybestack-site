import { ReportData, ReportOptions, ReportRenderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export const renderMarkdown: ReportRenderer = (
  data: ReportData,
  options: ReportOptions
): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let result = `# ${title}\n\n${summary}\n\n## Entries\n`;

  for (const entry of entries) {
    result += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\n**Total:** ${formatAmount(total)}`;
  }

  return result;
};