/**
 * Format registry for report renderers.
 */

import type { ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const FORMATS: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const SUPPORTED_FORMATS = Object.keys(FORMATS);
