#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import { readFileSync, writeFileSync } from 'fs';
import { FORMATS, SUPPORTED_FORMATS } from '../formats/index.js';
import type { ReportData } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | undefined;
  includeTotals: boolean;
}

/**
 * Parse command-line arguments using Node's standard library.
 */
function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // Positional argument (input file)
      if (result.inputFile) {
        console.error(`Error: Unexpected argument: ${arg}`);
        process.exit(1);
      }
      result.inputFile = arg;
    } else {
      console.error(`Error: Unknown option: ${arg}`);
      process.exit(1);
    }

    i++;
  }

  // Validate required arguments
  if (!result.inputFile) {
    console.error('Error: Input file path is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!result.format) {
    console.error('Error: --format is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return result;
}

/**
 * Load and parse JSON data from a file.
 */
function loadData(filePath: string): ReportData {
  let content: string;
  try {
    content = readFileSync(filePath, 'utf-8');
  } catch (error) {
    console.error(`Error: Unable to read file "${filePath}": ${(error as Error).message}`);
    process.exit(1);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    console.error(`Error: Invalid JSON in file "${filePath}": ${(error as Error).message}`);
    process.exit(1);
  }

  // Validate data structure
  if (typeof data !== 'object' || data === null) {
    console.error('Error: JSON data must be an object');
    process.exit(1);
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error('Error: Missing or invalid "title" field (must be a string)');
    process.exit(1);
  }

  if (typeof obj.summary !== 'string') {
    console.error('Error: Missing or invalid "summary" field (must be a string)');
    process.exit(1);
  }

  if (!Array.isArray(obj.entries)) {
    console.error('Error: Missing or invalid "entries" field (must be an array)');
    process.exit(1);
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${i} must be an object`);
      process.exit(1);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Entry at index ${i} missing or invalid "label" field (must be a string)`);
      process.exit(1);
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Entry at index ${i} missing or invalid "amount" field (must be a number)`);
      process.exit(1);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI entry point.
 */
function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Validate format
  if (!SUPPORTED_FORMATS.includes(args.format)) {
    console.error(`Error: Unsupported format "${args.format}"`);
    console.error(`Supported formats: ${SUPPORTED_FORMATS.join(', ')}`);
    process.exit(1);
  }

  // Load and validate data
  const data = loadData(args.inputFile);

  // Render report
  const renderer = FORMATS[args.format];
  const output = renderer(data, { includeTotals: args.includeTotals });

  // Write output
  if (args.outputPath) {
    try {
      writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Unable to write to file "${args.outputPath}": ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
