/**
 * RFC 4648 Base64 validation pattern.
 * Allows standard Base64 characters (A-Z, a-z, 0-9, +, /) with optional padding.
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate if a string is proper Base64 format.
 * Throws an error if the input is invalid Base64.
 */
function validateBase64(input: string): void {
  // Remove whitespace for more forgiving validation
  const trimmed = input.replace(/\s+/g, '');
  
  if (!trimmed) {
    throw new Error('Input cannot be empty');
  }
  
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check proper padding
  const paddingLength = (trimmed.match(/=+$/) || [''])[0].length;
  if (paddingLength > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Ensure padding only appears at the end
  if (trimmed.includes('=') && !trimmed.endsWith('=')) {
    throw new Error('Invalid Base64 input: padding must be at the end');
  }
  
  // Additional length validation: strings with length modulo 4 = 1 are never valid
  // This catches clearly malformed inputs
  const lengthMod4 = trimmed.length % 4;
  if (lengthMod4 === 1 && !trimmed.includes('=')) {
    throw new Error('Invalid Base64 input: incorrect length');
  }
}

/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  // Use standard base64 encoding which includes proper padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects malformed Base64 strings.
 */
export function decode(input: string): string {
  // Validate the input first
  validateBase64(input);
  
  try {
    // Use standard base64 decoding
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}