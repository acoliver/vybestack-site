

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

// Define valid Base64 characters pattern (standard Base64 alphabet with optional padding)
const VALID_BASE64_PATTERN = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input as standard Base64 and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Basic validation for non-empty inputs
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check if the input contains only valid Base64 characters
  if (!VALID_BASE64_PATTERN.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check padding is correct (if present)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, it should only appear at the end
    const paddingLength = input.length - paddingIndex;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Total length should be a multiple of 4
    if ((input.length % 4) !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
