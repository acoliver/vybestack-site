import { FormatOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

export function parseArgs(args: string[]): CliArgs {
  if (args.length < 1) {
    throw new Error('Data file path is required');
  }
  
  const dataFile = args[0];
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      const nextArg = args[++i];
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        throw new Error(`Unsupported format: ${nextArg}`);
      }
      format = nextArg;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!format) {
    throw new Error('--format is required');
  }
  
  return { dataFile, format, output, includeTotals };
}