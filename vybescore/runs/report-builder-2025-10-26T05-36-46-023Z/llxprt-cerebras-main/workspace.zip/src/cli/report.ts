#!/usr/bin/env node

import * as fs from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { parseArgs } from './args.js';

function readDataFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    
    // Validate data structure
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid title in data file');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary in data file');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries in data file');
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry structure in data file');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in data file: ${filePath}`);
    }
    throw error;
  }
}

function main() {
  try {
    const args = parseArgs(process.argv.slice(2));
    const data = readDataFile(args.dataFile);
    
    let output: string;
    if (args.format === 'markdown') {
      output = renderMarkdown(data, { includeTotals: args.includeTotals });
    } else if (args.format === 'text') {
      output = renderText(data, { includeTotals: args.includeTotals });
    } else {
      throw new Error(`Unsupported format: ${args.format}`);
    }
    
    if (args.output) {
      fs.writeFileSync(args.output, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error.message);
    process.exit(1);
  }
}

main();