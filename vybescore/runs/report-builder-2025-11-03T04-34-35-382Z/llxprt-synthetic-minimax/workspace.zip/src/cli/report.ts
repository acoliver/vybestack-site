#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  // Skip 'node' and script name
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      args.format = argv[++i] || '';
    } else if (arg === '--output') {
      args.output = argv[++i] || '';
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      args.dataFile = arg;
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Missing data file argument');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Missing --format argument');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Error: Unsupported format '${args.format}'. Supported formats: markdown, text`);
    process.exit(1);
  }
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      console.error('Error: Invalid or missing "title" field in data file');
      process.exit(1);
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      console.error('Error: Invalid or missing "summary" field in data file');
      process.exit(1);
    }
    
    if (!Array.isArray(data.entries)) {
      console.error('Error: Invalid or missing "entries" field in data file');
      process.exit(1);
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry || typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
        console.error(`Error: Invalid entry at index ${i}. Each entry must have "label" (string) and "amount" (number)`);
        process.exit(1);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if ('code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error instanceof SyntaxError) {
        console.error('Error: Invalid JSON in data file');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Unknown error reading data file');
    }
    process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);
  
  const data = loadAndValidateData(args.dataFile);
  
  const options: RenderOptions = {
    includeTotals: args.includeTotals
  };

  let output: string;
  
  if (args.format === 'markdown') {
    output = renderMarkdown.render(data, options);
  } else if (args.format === 'text') {
    output = renderText.render(data, options);
  } else {
    console.error(`Error: Unsupported format '${args.format}'`);
    process.exit(1);
  }

  if (args.output) {
    try {
      writeFileSync(args.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${error instanceof Error ? error.message : 'unknown error'}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();