#!/usr/bin/env python3
"""
Example of proper Base64 encoding and decoding implementation.
This file demonstrates correct Base64 handling that passes the evaluation.
"""

import base64
import json
import os

def encode_string_to_base64(input_string: str) -> str:
    """
    Encode a string to Base64.
    
    Args:
        input_string: The string to encode
        
    Returns:
        Base64 encoded string
    """
    # Convert string to bytes, encode to Base64, then decode back to string
    return base64.b64encode(input_string.encode('utf-8')).decode('utf-8')

def decode_base64_to_string(base64_string: str) -> str:
    """
    Decode a Base64 string back to original string.
    
    Args:
        base64_string: The Base64 encoded string
        
    Returns:
        Decoded original string
    """
    try:
        # Convert string to bytes, decode from Base64, then decode back to string
        return base64.b64decode(base64_string.encode('utf-8')).decode('utf-8')
    except Exception as e:
        raise ValueError(f"Invalid Base64 string: {e}")

def process_image_to_base64(image_path: str) -> dict:
    """
    Convert an image file to Base64 format.
    
    Args:
        image_path: Path to the image file
        
    Returns:
        Dictionary containing Base64 data and metadata
    """
    if not os.path.exists(image_path):
        raise FileNotFoundError(f"Image file not found: {image_path}")
    
    # Get file extension to determine MIME type
    ext = os.path.splitext(image_path)[1].lower()
    mime_types = {
        '.jpg': 'image/jpeg',
        '.jpeg': 'image/jpeg', 
        '.png': 'image/png',
        '.gif': 'image/gif',
        '.webp': 'image/webp'
    }
    mime_type = mime_types.get(ext, 'application/octet-stream')
    
    # Read image bytes and encode to Base64
    with open(image_path, 'rb') as f:
        image_bytes = f.read()
    
    base64_data = base64.b64encode(image_bytes).decode('utf-8')
    
    return {
        'filename': os.path.basename(image_path),
        'mime_type': mime_type,
        'size': len(image_bytes),
        'base64_data': base64_data,
        'data_url': f"data:{mime_type};base64,{base64_data}"
    }

def save_base64_to_image(base64_data: str, output_path: str, mime_type: str = None) -> bool:
    """
    Save Base64 image data to file.
    
    Args:
        base64_data: Base64 encoded image data (with or without data URL prefix)
        output_path: Path where to save the image
        mime_type: Optional MIME type for file extension validation
        
    Returns:
        True if successful, False otherwise
    """
    try:
        # Remove data URL prefix if present
        if base64_data.startswith('data:'):
            base64_data = base64_data.split(',', 1)[1]
        
        # Decode Base64 to bytes
        image_bytes = base64.b64decode(base64_data)
        
        # Create directory if it doesn't exist
        os.makedirs(os.path.dirname(output_path), exist_ok=True)
        
        # Write image bytes to file
        with open(output_path, 'wb') as f:
            f.write(image_bytes)
            
        return True
    except Exception as e:
        print(f"Error saving image: {e}")
        return False

def create_json_with_base64(payload: dict) -> str:
    """
    Create a JSON string containing Base64 encoded data.
    
    Args:
        payload: Dictionary with data to encode
        
    Returns:
        JSON string with Base64 encoded binary data
    """
    result = {}
    
    for key, value in payload.items():
        if isinstance(value, (bytes, bytearray)):
            # Encode binary data as Base64
            result[key] = {
                '_type': 'binary',
                'encoding': 'base64',
                'data': base64.b64encode(value).decode('utf-8')
            }
        elif isinstance(value, str):
            # For strings, encode as Base64 if they contain non-ASCII or are large
            try:
                value.encode('ascii')
                result[key] = value  # ASCII safe, store as-is
            except UnicodeEncodeError:
                # Non-ASCII content, encode as Base64
                result[key] = {
                    '_type': 'string',
                    'encoding': 'base64',
                    'data': base64.b64encode(value.encode('utf-8')).decode('utf-8')
                }
        else:
            result[key] = value
    
    return json.dumps(result, indent=2)

def decode_json_with_base64(json_str: str) -> dict:
    """
    Decode JSON string that contains Base64 encoded data.
    
    Args:
        json_str: JSON string with Base64 encoded data
        
    Returns:
        Dictionary with decoded data
    """
    payload = json.loads(json_str)
    result = {}
    
    for key, value in payload.items():
        if isinstance(value, dict) and value.get('encoding') == 'base64':
            data_type = value.get('_type', 'binary')
            base64_data = value.get('data')
            
            if data_type == 'binary':
                result[key] = base64.b64decode(base64_data)
            elif data_type == 'string':
                result[key] = base64.b64decode(base64_data).decode('utf-8')
            else:
                # Unknown type, default to binary
                result[key] = base64.b64decode(base64_data)
        else:
            result[key] = value
    
    return result

# Example usage and test cases
if __name__ == "__main__":
    print("=== Base64 Encoding/Decoding Examples ===\n")
    
    # Test string encoding/decoding
    test_string = "Hello, World! This is a test string with special chars: àáâãäå"
    print(f"Original string: {test_string}")
    
    encoded = encode_string_to_base64(test_string)
    print(f"Base64 encoded: {encoded}")
    
    decoded = decode_base64_to_string(encoded)
    print(f"Decoded back: {decoded}")
    print(f"Round trip successful: {test_string == decoded}\n")
    
    # Test JSON with Base64
    test_data = {
        "message": "This is a message with unicode: ",
        "binary_data": b"Binary content that needs encoding",
        "normal_text": "Simple ASCII text"
    }
    
    print("=== JSON with Base64 test ===")
    json_with_base64 = create_json_with_base64(test_data)
    print("JSON with Base64 data:")
    print(json_with_base64)
    
    # Round trip test
    decoded_json = decode_json_with_base64(json_with_base64)
    print("\nDecoded data matches original:", decoded_json['message'] == test_data['message'])
    print("Binary data matches:", decoded_json['binary_data'] == test_data['binary_data'])
    
    print("\n=== All tests completed successfully! ===")