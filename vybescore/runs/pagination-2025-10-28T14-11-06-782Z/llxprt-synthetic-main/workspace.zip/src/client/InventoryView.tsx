import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const goToPreviousPage = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const goToNextPage = () => {
    if (data.hasNext) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      {data.items.length > 0 ? (
        <>
          <InventoryList items={data.items} />
          <div className="pagination-controls">
            <button 
              onClick={goToPreviousPage}
              disabled={currentPage <= 1}
            >
              Previous
            </button>
            <span>Page {currentPage} of {Math.ceil(data.total / PAGE_LIMIT)}</span>
            <button 
              onClick={goToNextPage}
              disabled={!data.hasNext}
            >
              Next
            </button>
          </div>
        </>
      ) : (
        <p>No inventory items found.</p>
      )}
    </section>
  );
}
