import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

// Validate page number: must be a positive integer
function validatePage(pageParam: string | undefined): number | null {
  if (pageParam === undefined) return 1; // Default to 1
  
  const parsed = Number(pageParam);
  if (!Number.isInteger(parsed) || parsed < 1) return null;
  return parsed;
}

// Validate limit: must be a positive integer within reasonable bounds
function validateLimit(limitParam: string | undefined): number | null {
  if (limitParam === undefined) return 5; // Default to 5
  
  const parsed = Number(limitParam);
  if (!Number.isInteger(parsed) || parsed < 1 || parsed > 100) return null;
  return parsed;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate input parameters
    const page = validatePage(pageParam);
    const limit = validateLimit(limitParam);
    
    // Return 400 for invalid parameters
    if (page === null || limit === null) {
      return res.status(400).json({
        error: 'Invalid pagination parameters. Page and limit must be positive integers. Limit must not exceed 100.'
      });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
