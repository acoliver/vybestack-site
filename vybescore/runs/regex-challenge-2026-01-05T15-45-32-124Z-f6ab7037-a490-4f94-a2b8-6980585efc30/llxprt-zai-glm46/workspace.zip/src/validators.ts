export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex =
    /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;

  // Basic structure check
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for specific invalid patterns
  const [localPart, domain] = value.split('@');

  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // Reject trailing dot in local part or domain
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }

  // Reject leading dot in local part or domain
  if (localPart.startsWith('.') || domain.startsWith('.')) {
    return false;
  }

  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }

  // Reject consecutive dots in domain parts
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(
  value: string,
  _options?: PhoneValidationOptions,
): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Validate format matches one of the accepted patterns
  const patterns = [
    /^\+1\s?\(\d{3}\)\s?\d{3}-?\d{4}$/, // +1 (212) 555-7890
    /^\(\d{3}\)\s?\d{3}-?\d{4}$/, // (212) 555-7890
    /^\+1\s?\d{3}-?\d{3}-?\d{4}$/, // +1 212-555-7890
    /^\d{3}-?\d{3}-?\d{4}$/, // 212-555-7890
    /^\+1\d{10}$/, // +12125557890
    /^\d{10}$/, // 2125557890
  ];

  return patterns.some((pattern) => pattern.test(value));
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep structure info
  const cleaned = value.replace(/[\s-]/g, '');

  // Main regex pattern for Argentine phone numbers
  // Format: [+54][9]?[0]?area_code subscriber_number
  const argPhoneRegex = /^(?:\+54)?(?:9)?0?[1-9]\d{1,3}\d{6,8}$/;

  if (!argPhoneRegex.test(cleaned)) {
    return false;
  }

  // Parse components
  let remaining = cleaned;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;

  // Check for country code +54
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }

  // Check for mobile indicator 9 (only if country code present or if it follows trunk prefix)
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }

  // Check for trunk prefix 0
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.slice(1);
  }

  // If no country code, trunk prefix is required
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }

  const areaCode = areaCodeMatch[1];
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  remaining = remaining.slice(areaCode.length);

  // Subscriber number must be 6-8 digits
  if (remaining.length < 6 || remaining.length > 8) {
    return false;
  }

  // All remaining characters must be digits
  if (!/^\d+$/.test(remaining)) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Regex to match valid name characters:
  // - Unicode letters (\p{L})
  // - Marks/accents (\p{M})
  // - Apostrophes, hyphens, spaces
  // Reject digits, symbols, and other special characters
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s][\p{L}\p{M}'-]+)*$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }

  // Reject names that look like "X Æ A-12" (contain digits after symbols)
  // or have suspicious patterns like multiple consecutive symbols
  if (/'-|-'|-['\s]|['-]{2,}/.test(value)) {
    return false;
  }

  // Name should contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{13})$/;
  const amexRegex = /^3[47]\d{13}$/;

  const validFormat =
    visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map((d) => parseInt(d, 10));
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
