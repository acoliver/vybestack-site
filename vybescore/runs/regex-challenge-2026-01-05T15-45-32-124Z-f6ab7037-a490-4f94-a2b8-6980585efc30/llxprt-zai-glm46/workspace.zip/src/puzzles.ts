/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match words starting with the prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'gi');

  const matches = text.match(wordRegex) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map((e) => e.toLowerCase());

  return matches.filter((word) => {
    return !exceptionsLower.includes(word.toLowerCase());
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use lookbehind to find token preceded by a digit
  // Match includes the digit + token
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'gi');

  const matches = text.match(tokenRegex) || [];

  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must have at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, 123123)
  // Look for patterns of length 2-4 that repeat immediately
  for (let seqLen = 2; seqLen <= 4; seqLen++) {
    for (let i = 0; i <= value.length - seqLen * 2; i++) {
      const sequence = value.slice(i, i + seqLen);
      const nextSequence = value.slice(i + seqLen, i + seqLen * 2);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Simplified IPv6 regex that handles common formats
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // Compressed: :: can replace one or more consecutive groups of zeros

  // Pattern for IPv6 (including compressed forms)
  // Must have at least 2 colons and hex digit groups
  const ipv6BasicPattern =
    /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?::[0-9a-fA-F]{1,4}){1,7}|::|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+|::(?:ffff:)?0?(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9]?[0-9]))(?=$|\s)/;

  // First check if this might be an IPv6 address
  if (!ipv6BasicPattern.test(value)) {
    return false;
  }

  // Now make sure it's not just an IPv4 address
  // IPv4 pattern: xxx.xxx.xxx.xxx
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  // If the entire value is a plain IPv4, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Otherwise, it contains IPv6
  return true;
}
