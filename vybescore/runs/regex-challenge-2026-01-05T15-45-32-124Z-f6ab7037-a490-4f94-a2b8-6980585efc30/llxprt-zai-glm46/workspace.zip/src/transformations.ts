/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, trim and collapse multiple spaces
  let normalized = text.trim().replace(/\s+/g, ' ');

  // Insert space after sentence-ending punctuation if needed (before capital letter)
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');

  // Split by sentence endings
  const sentences = normalized.split(/([.!?]\s*)/);
  const result: string[] = [];
  let capitalizeNext = true;

  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];

    if (!part) continue;

    // Check if this is a sentence ending
    if (part.match(/^[.!?]+\s*$/)) {
      result.push(part.replace(/\s+/g, ' '));
      capitalizeNext = true;
    } else if (capitalizeNext) {
      // Capitalize first letter of sentence
      result.push(part.charAt(0).toUpperCase() + part.slice(1));
      capitalizeNext = false;
    } else {
      result.push(part);
    }
  }

  // Join and ensure single spaces
  return result.join('').replace(/\s+/g, ' ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Removes trailing punctuation from URLs.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  // Matches http://, https://, and www. URLs
  // Captures the URL but not trailing punctuation
  const urlRegex = /(https?:\/\/[^\s<>"{}|^`[\]]+|www\.[^\s<>"{}|^`[\]]+)/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation
  return matches.map((url) => {
    // Remove trailing punctuation: .,;:?!
    return url.replace(/[.,;:?!]+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com/ URLs
  // Capture groups: (1) scheme, (2) host, (3) path
  const urlRegex = /(http?:\/\/)(example\.com)(\/[^\s<>"{}|^`[\]]*)/gi;

  return text.replace(urlRegex, (match, scheme, host, path) => {
    // Always upgrade scheme to https
    const newScheme = 'https://';

    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);

  // Check if path contains dynamic hints that should skip host rewrite
  const dynamicHints = [
    'cgi-bin',
    '\\?',
    '\\&',
    '\\=',
    '\\.jsp$',
    '\\.php$',
    '\\.asp$',
    '\\.aspx$',
    '\\.do$',
    '\\.cgi$',
    '\\.pl$',
    '\\.py$',
  ];
  const hasDynamicHint = new RegExp(dynamicHints.join('|')).test(path);

    if (isDocsPath && !hasDynamicHint) {
      // Rewrite host to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade the scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);

  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  // Year should be reasonable (e.g., 1000-9999)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }

  return yearStr;
}
