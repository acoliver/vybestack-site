const Buffer = require("buffer").Buffer; console.log("Require Buffer test:", Buffer.from("hello", "utf8").toString("base64"));
