import { encode } from "./src/base64.js"; console.log("encode result:", JSON.stringify(encode("hello")));
