console.log("Direct Buffer test:", Buffer.from("hello", "utf8").toString("base64"));
