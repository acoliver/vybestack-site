import { encode, decode } from "./src/base64.js"; console.log("encode:", JSON.stringify(encode("hello"))); console.log("decode:", decode("aGVsbG8="));
