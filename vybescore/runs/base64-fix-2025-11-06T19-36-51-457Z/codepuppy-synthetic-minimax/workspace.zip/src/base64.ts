/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Uses standard Base64 with padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove whitespace first
  const cleaned = input.replace(/\s/g, '');
  
  // Check for empty input
  if (cleaned.length === 0) {
    return '';
  }

  // Validate basic Base64 format (only allow A-Z, a-z, 0-9, +, /, =)
  if (!/^[A-Za-z0-9+/=]*$/.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Validate padding and structure according to RFC 4648
  validateBase64Structure(cleaned);

  try {
    const result = Buffer.from(cleaned, 'base64').toString('utf8');
    
    // Additional validation: if we got an empty result but input wasn't just padding
    if (result.length === 0 && !/^=+$/.test(cleaned)) {
      // This suggests invalid input that Buffer silently handled
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validate the structure of Base64 data according to RFC 4648.
 */
function validateBase64Structure(input: string): void {
  // Count padding characters
  const paddingCount = (input.match(/=/g) || []).length;
  
  // No more than 2 padding characters allowed
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
  
  // Padding can only appear at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Check that all characters after first '=' are also '='
    const paddingSection = input.substring(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
  }
  
  // If there's padding, validate the length
  if (paddingCount > 0) {
    // Length must be multiple of 4 when padding is present
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length with padding');
    }
  } else {
    // Without padding, length must be multiple of 4, or we can add virtual padding
    // But let's be strict and require proper length unless it's valid unpadded base64
    if (input.length % 4 !== 0) {
      // Try to decode with virtual padding first
      const padded = input + '='.repeat(4 - (input.length % 4));
      try {
        Buffer.from(padded, 'base64');
      } catch {
        throw new Error('Invalid Base64 input: incorrect length');
      }
    }
  }
}
