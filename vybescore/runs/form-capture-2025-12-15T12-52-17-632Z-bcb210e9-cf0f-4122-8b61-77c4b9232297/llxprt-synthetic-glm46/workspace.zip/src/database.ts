import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// We'll dynamically import sql.js since it's an ES module
let initSqlJs: ((options?: unknown) => Promise<{ Database: new (data?: ArrayBuffer | Uint8Array) => Database }>) | null = null;
let Database: new (data?: ArrayBuffer | Uint8Array) => {
  run(sql: string, ...params: unknown[]): unknown[];
  prepare(sql: string): {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
  };
  exec(sql: string): { columns: string[]; values: unknown[][] }[];
  export(): Uint8Array;
  close(): void;
};

interface Database {
  run(sql: string, ...params: unknown[]): unknown[];
  prepare(sql: string): {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
  };
  exec(sql: string): { columns: string[]; values: unknown[][] }[];
  export(): Uint8Array;
  close(): void;
}

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(__dirname, '../data/submissions.sqlite');
    this.schemaPath = path.join(__dirname, '../db/schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      if (!initSqlJs) {
        const sqlJs = await import('sql.js');
        initSqlJs = sqlJs.default;
        const sqlJsModule = await initSqlJs();
        Database = sqlJsModule.Database;
      }

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        this.db = new Database(fileBuffer);
        console.log('Database loaded from file');
      } else {
        this.db = new Database();
        console.log('New database created');
        
        // Read and execute schema
        const schema = fs.readFileSync(this.schemaPath, 'utf8');
        this.db.run(schema);
        console.log('Database schema initialized');
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async insertSubmission(data: SubmissionData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        data.first_name,
        data.last_name,
        data.street_address,
        data.city,
        data.state_province,
        data.postal_code,
        data.country,
        data.email,
        data.phone
      ]);

      const result = this.db.run('SELECT last_insert_rowid() as id') as Array<{ id: number }>;
      const submissionId = result[0].id;

      console.log(`Inserted submission with ID: ${submissionId}`);
      return submissionId;
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  async getSubmissions(): Promise<Record<string, unknown>[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const result = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
      if (result.length === 0) return [];
      
      const columns = result[0].columns;
      const values = result[0].values;
      
      return values.map((row: unknown[]) => {
        const obj: Record<string, unknown> = {};
        columns.forEach((col: string, index: number) => {
          obj[col] = row[index];
        });
        return obj;
      });
    } catch (error) {
      console.error('Failed to get submissions:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (!this.db) {
      console.log('Database already closed');
      return;
    }

    try {
      // Export database to file
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
      console.log('Database saved to file');
      
      // Close database
      this.db.close();
      this.db = null;
      console.log('Database connection closed');
    } catch (error) {
      console.error('Failed to close database:', error);
      throw error;
    }
  }
}

export default DatabaseManager;