import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import DatabaseManager from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;
const dbManager = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Form validation
interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

const validateForm = (data: Partial<FormData>): { isValid: boolean; errors: FormErrors } => {
  const errors: FormErrors = {};

  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field]!.trim() === '') {
      errors[field] = `${field.replace('_', ' ')} is required`;
    }
  }

  // Email validation
  if (data.email && !data.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (allow international formats)
  if (data.phone && !data.phone.match(/^[+]?[(]?[0-9]{1,3}[)]?[-\s.]?[(]?[0-9]{1,4}[)]?[-\s.]?[0-9]{1,4}[-\s.]?[0-9]{1,9}$/)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (allow alphanumeric)
  if (data.postal_code && !data.postal_code.match(/^[a-zA-Z0-9\s-]+$/)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    data: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData = req.body as Partial<FormData>;
  const validation = validateForm(formData);
  
  // Debug output to see what's happening
  console.log('Form data received:', formData);
  console.log('Validation result:', validation);

  if (!validation.isValid) {
    console.log('Validation errors found:', validation.errors);
    return res.status(400).render('form', { 
      errors: validation.errors, 
      data: formData 
    });
  }

  try {
    // Insert into database
    await dbManager.insertSubmission(formData as SubmissionData);
    console.log('Form submitted and saved to database:', formData);
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', { 
      errors: { general: 'Database error. Please try again.' }, 
      data: formData 
    });
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Server startup and graceful shutdown
/* eslint-disable @typescript-eslint/no-explicit-any */
let server: any;
/* eslint-enable @typescript-eslint/no-explicit-any */

const startServer = async () => {
  try {
    // Initialize database
    await dbManager.initialize();
    console.log('Database initialized');
    
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Handle graceful shutdown
const shutdown = async () => {
  console.log('SIGTERM signal received: closing HTTP server');
  if (server) {
    server.close(async () => {
      console.log('HTTP server closed');
      try {
        await dbManager.close();
        console.log('Database connection closed');
        process.exit(0);
      } catch (error) {
        console.error('Error closing database:', error);
        process.exit(1);
      }
    });
  }
};

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

startServer();

export default app;