import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

// Import the app from the built server
/* eslint-disable @typescript-eslint/no-explicit-any */
/* eslint-disable @typescript-eslint/no-explicit-any */
let app: any;
/* eslint-enable @typescript-eslint/no-explicit-any */

/* eslint-disable @typescript-eslint/no-explicit-any */
let server: any;
/* eslint-enable @typescript-eslint/no-explicit-any */
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the app from the built server
  const serverModule = await import('../../dist/server.js');
  app = serverModule.default;
  
  // Clean up existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start server on a test port
  server = app.listen(0); // Use random available port
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('International Contact Form');
    expect(response.text).toContain('first_name');
    expect(response.text).toContain('last_name');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // First check if form loads properly
    await request(app)
      .get('/')
      .expect(200);

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows thank you page with humorous content', async () => {
    const response = await request(app)
      .get('/thank-you')
      .expect(200);
    
    expect(response.text).toContain('Thank You');
    expect(response.text).toContain('stranger on the internet');
    expect(response.text).toContain('spam');
  });
});