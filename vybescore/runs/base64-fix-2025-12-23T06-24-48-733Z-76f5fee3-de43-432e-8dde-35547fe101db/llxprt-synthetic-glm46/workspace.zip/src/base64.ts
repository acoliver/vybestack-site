

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) and includes padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate Base64 format - only allow A-Z, a-z, 0-9, +, /, and optional padding =
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for padding format issues
  const nonPaddingChars = input.replace(/[=]/g, '');
  const paddingChars = input.length - nonPaddingChars.length;
  
  // Base64 padding should only be at the end and max 3 characters
  if (paddingChars > 3) {
    throw new Error('Invalid Base64 input: too much padding');
  }

  // If padding exists, ensure it's at the end and valid
  if (paddingChars > 0) {
    const hasPaddingInMiddle = /=.*[^=]/.test(input);
    if (hasPaddingInMiddle) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
  }

  try {
    // Use regular base64 encoding for decoding to maintain standard compatibility
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
