/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  
  
  // List of observers that depend on this computed
  const dependentObservers: Set<Observer<unknown>> = new Set()
  
  // Observer for this computed that tracks its dependencies
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Compute initial value
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add current observer as a dependent of this computed
      dependentObservers.add(observer as Observer<unknown>)
    }
    
    return o.value!
  }
  
  // Expose a function to mark this computed as needing recomputation
  ;(o as Observer<T> & { markDirty: () => void }).markDirty = () => {
    // Recompute this computed value
    updateObserver(o)
    
    // Notify all observers that depend on this computed
    for (const depObserver of dependentObservers) {
      if (!depObserver.updateFn) continue
      if (depObserver.updateFn.toString && depObserver.updateFn.toString().includes('value as T')) continue
        
      // If the dependent observer is also a computed, mark it dirty too
      if ((depObserver as Observer<unknown> & { markDirty?: () => void }).markDirty) {
        (depObserver as Observer<unknown> & { markDirty: () => void }).markDirty()
      } else {
        // Otherwise just update it directly
        updateObserver(depObserver as Observer<unknown>)
      }
    }
  }
  
  return getter
}
