/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Function to check if values are equal using provided equal function or strict equality
  const equalFn = typeof _equal === 'function' ? _equal : 
                  _equal === false ? () => false : 
                  (lhs: T, rhs: T) => lhs === rhs

  // List of observers watching this input
  const observers: Set<Observer<unknown>> = new Set()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track this observer as dependent on this input
      observers.add(observer as Observer<unknown>)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify all dependent observers
      const observersToNotify = Array.from(observers)
      for (const depObserver of observersToNotify) {
        // Skip if disposed (updateFn undefined or no-op)
        if (!depObserver.updateFn || 
            (depObserver.updateFn.toString && depObserver.updateFn.toString().includes('value as T'))) continue
        
        // Mark computed observers as dirty before notifying them
        if ((depObserver as Observer<unknown> & { markDirty?: () => void }).markDirty) {
          (depObserver as Observer<unknown> & { markDirty: () => void }).markDirty()
        } else {
          // Update the observer to trigger its update function
          updateObserver(depObserver as Observer<unknown>)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
