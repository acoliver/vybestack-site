#!/bin/bash

# Clean up old database
rm -f data/submissions.sqlite

# Start server in background
PORT=3535 node dist/server.js &
SERVER_PID=$!

# Wait for server to start
sleep 2

# Test 1: UK submission
echo "Test 1: UK phone and postal code"
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=John&lastName=Doe&streetAddress=123+Main+St&city=London&stateProvince=England&postalCode=SW1A+1AA&country=United+Kingdom&email=john@example.com&phone=%2B44+20+7946+0958" \
  -w "\nStatus: %{http_code}\n" > /dev/null

# Test 2: Argentina submission
echo "Test 2: Argentina phone and postal code"
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Maria&lastName=Gonzalez&streetAddress=Calle+Falsa+123&city=Buenos+Aires&stateProvince=CABA&postalCode=C1000&country=Argentina&email=maria@example.com&phone=%2B54+9+11+1234-5678" \
  -w "\nStatus: %{http_code}\n" > /dev/null

# Test 3: US submission
echo "Test 3: US phone and postal code"
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Bob&lastName=Smith&streetAddress=456+Oak+Ave&city=New+York&stateProvince=NY&postalCode=10001&country=United+States&email=bob@example.com&phone=%2B1+555-123-4567" \
  -w "\nStatus: %{http_code}\n" > /dev/null

# Wait a moment for database writes
sleep 1

# Check database
echo ""
echo "Database contents:"
if [ -f "data/submissions.sqlite" ]; then
  # Use SQLite CLI if available, otherwise show file exists
  if command -v sqlite3 &> /dev/null; then
    sqlite3 data/submissions.sqlite "SELECT id, first_name, last_name, city, postal_code, phone FROM submissions;"
  else
    echo "Database file exists with $(stat -c%s data/submissions.sqlite) bytes"
  fi
fi

# Clean up - send SIGTERM to gracefully shutdown
echo ""
echo "Stopping server..."
kill -TERM $SERVER_PID
wait $SERVER_PID

echo "Verification complete!"
