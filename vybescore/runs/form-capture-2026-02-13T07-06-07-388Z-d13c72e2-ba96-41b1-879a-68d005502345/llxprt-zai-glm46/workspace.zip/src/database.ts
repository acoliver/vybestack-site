import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

let dbInstance: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Initialize SQL.js
  const SQL = await initSqlJs();

  // Check if database file exists
  if (fs.existsSync(DB_PATH)) {
    // Load existing database
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
    console.log('Loaded existing database from', DB_PATH);
  } else {
    // Create new database
    dbInstance = new SQL.Database();
    
    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    
    // Save to disk
    saveDatabase();
    console.log('Created new database at', DB_PATH);
  }

  return dbInstance;
}

export function saveDatabase(): void {
  if (dbInstance) {
    const data = dbInstance.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

export function getDatabase(): Database {
  if (!dbInstance) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return dbInstance;
}

export function closeDatabase(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function insertSubmission(data: SubmissionData): void {
  const db = getDatabase();
  const stmt = db.prepare(
    'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  stmt.run([
    data.first_name,
    data.last_name,
    data.street_address,
    data.city,
    data.state_province,
    data.postal_code,
    data.country,
    data.email,
    data.phone
  ]);
  stmt.free();
  
  // Save to disk after each insert
  saveDatabase();
}
