import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import * as dbModule from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use('/public', express.static(path.resolve(__dirname, '../public')));

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, '../src/templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+]?[\d\s()()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  
  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field]!.trim() === '') {
      errors.push(`${field} is required`);
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number (digits, spaces, parentheses, dashes, and + allowed)');
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal code (letters and digits allowed)');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}



// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  // Insert into database
  try {
    dbModule.insertSubmission({
      first_name: formData.firstName!,
      last_name: formData.lastName!,
      street_address: formData.streetAddress!,
      city: formData.city!,
      state_province: formData.stateProvince!,
      postal_code: formData.postalCode!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!
    });

    // Redirect to thank you page with firstName
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Extract first name from query or use a generic greeting
  const firstName = typeof req.query.firstName === 'string' 
    ? req.query.firstName 
    : 'friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  dbModule.closeDatabase();
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  await dbModule.initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Keep process alive
  return new Promise(() => {});
}

// Export for testing
export { app, startServer };

// If this file is run directly, start the server
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
