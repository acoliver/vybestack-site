#!/bin/bash

# Start server in background
PORT=3535 node dist/server.js &
SERVER_PID=$!

# Wait for server to start
sleep 2

# Test 1: GET /
echo "Test 1: GET /"
curl -s http://localhost:3535/ | grep -q "Tell us who you are" && echo "[OK] Form renders" || echo " Form failed"

# Test 2: POST /submit with valid data
echo "Test 2: POST /submit"
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=John&lastName=Doe&streetAddress=123+Main+St&city=London&stateProvince=England&postalCode=SW1A+1AA&country=United+Kingdom&email=john@example.com&phone=%2B44+20+7946+0958" \
  -w "\nStatus: %{http_code}\n" | grep -q "302" && echo "[OK] Submission redirects" || echo " Submission failed"

# Test 3: POST /submit with invalid email
echo "Test 3: POST /submit with invalid email"
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Jane&lastName=Smith&streetAddress=456+Oak+Ave&city=Buenos+Aires&stateProvince=CABA&postalCode=C1000&country=Argentina&email=invalid-email&phone=%2B54+9+11+1234-5678" \
  -w "\nStatus: %{http_code}\n" | grep -q "400" && echo "[OK] Validation catches invalid email" || echo " Validation failed"

# Test 4: GET /thank-you
echo "Test 4: GET /thank-you"
curl -s http://localhost:3535/thank-you\?firstName=Test | grep -q "Thank you" && echo "[OK] Thank you page renders" || echo " Thank you page failed"

# Clean up - send SIGTERM to gracefully shutdown
echo "Stopping server..."
kill -TERM $SERVER_PID
wait $SERVER_PID

echo "All tests completed!"
