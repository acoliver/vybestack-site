#!/bin/bash

echo "Starting server (should load existing database)..."
PORT=3535 node dist/server.js &
SERVER_PID=$!

sleep 2

echo ""
echo "Checking database has previous data..."
if command -v sqlite3 &> /dev/null; then
  COUNT=$(sqlite3 data/submissions.sqlite "SELECT COUNT(*) FROM submissions;")
  echo "Previous submissions found: $COUNT"
fi

# Add one more submission
echo ""
echo "Adding new submission..."
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Test&lastName=User&streetAddress=789+Test+St&city=Paris&stateProvince=Ile-de-France&postalCode=75001&country=France&email=test@example.com&phone=%2B33+1+23+45+67+89" \
  -w "\nStatus: %{http_code}\n" > /dev/null

sleep 1

echo ""
echo "Final database contents:"
if command -v sqlite3 &> /dev/null; then
  sqlite3 data/submissions.sqlite "SELECT id, first_name, last_name, city, country FROM submissions ORDER BY id;"
fi

# Clean up
echo ""
echo "Stopping server..."
kill -TERM $SERVER_PID
wait $SERVER_PID

echo "Restart test complete!"
