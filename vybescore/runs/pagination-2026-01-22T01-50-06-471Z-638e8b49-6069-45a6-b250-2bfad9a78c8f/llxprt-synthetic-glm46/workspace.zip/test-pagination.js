import { createApp } from './dist/src/server/app.js';
import { createDatabase } from './dist/src/server/db.js';

async function main() {
  console.log('Pagination functionality test');
  console.log('============================');

  // Create a database and app directly without starting a server
  const db = await createDatabase();
  const app = await createApp(db);

  // Import supertest for testing the Express app
  const request = (await import('supertest')).default(app);

  try {
    // Test 1: Default pagination
    const response1 = await request.get('/inventory');
    console.log('Test 1 - Default pagination (page 1, limit 5):');
    console.log(JSON.stringify(response1.body, null, 2));

    // Test 2: Invalid page parameter - should return 400
    const response2 = await request.get('/inventory?page=abc');
    console.log('\nTest 2 - Invalid page parameter:');
    console.log('Status:', response2.status);
    console.log('Body:', response2.body);

    // Test 3: Page 2 with default limit
    const response3 = await request.get('/inventory?page=2');
    console.log('\nTest 3 - Page 2 with default limit:');
    console.log(JSON.stringify(response3.body, null, 2));

    // Test 4: Custom limit and page
    const response4 = await request.get('/inventory?page=1&limit=3');
    console.log('\nTest 4 - Custom limit (3) and page (1):');
    console.log(JSON.stringify(response4.body, null, 2));

    // Test 5: Excessive limit parameter - should return 400
    const response5 = await request.get('/inventory?limit=101');
    console.log('\nTest 5 - Excessive limit parameter:');
    console.log('Status:', response5.status);
    console.log('Body:', response5.body);

    // Test 6: Negative page parameter - should return 400
    const response6 = await request.get('/inventory?page=-1');
    console.log('\nTest 6 - Negative page parameter:');
    console.log('Status:', response6.status);
    console.log('Body:', response6.body);

    // Test 7: Zero limit parameter - should return 400
    const response7 = await request.get('/inventory?limit=0');
    console.log('\nTest 7 - Zero limit parameter:');
    console.log('Status:', response7.status);
    console.log('Body:', response7.body);

    console.log('\n============================');
    console.log('All tests completed');
  } catch (error) {
    console.error('Error during testing:', error);
  }
}

main();