export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // - Local part: letters, digits, +, ., -, _ but no consecutive dots or starting/ending with dot
  // - Domain: no underscores, valid TLD patterns
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])*$/;

  // Check overall format first
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for invalid patterns
  // No consecutive dots in local part or domain
  if (value.includes('..')) {
    return false;
  }

  // Domain should not contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }

  // Should not end with a dot
  if (value.endsWith('.')) {
    return false;
  }

  // Should not start with a dot after @
  if (value.includes('@.')) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Validate the format matches one of:
  // - (212) 555-7890
  // - 212-555-7890
  // - 2125557890
  // - +1 2125557890
  const phoneRegex = /^\+?1?\s*\(?([2-9]\d{2})\)?[-\s]?(\d{3})[-\s]?(\d{4})$/;
  
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  // Remove all non-digit characters to extract the number
  const digits = value.replace(/\D/g, '');
  
  // Must be either 10 digits (without country code) or 11 digits starting with 1
  if (digits.length === 11 && digits.startsWith('1')) {
    // Remove the country code for validation
    const localDigits = digits.substring(1);
    return validateAreaCode(localDigits);
  } else if (digits.length === 10) {
    return validateAreaCode(digits);
  }
  
  return false;
}

function validateAreaCode(digits: string): boolean {
  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input: remove spaces and hyphens for validation
  const cleanValue = value.replace(/[-\s]/g, '');
  
  // Argentine phone regex pattern
  // Pattern breakdown:
  // ^\+54?          - Optional +54 country code
  // (?:9)?          - Optional mobile indicator 9
  // 0?              - Optional trunk prefix 0
  // ([1-9]\d{1,3})  - Area code: 2-4 digits, starting with 1-9
  // (\d{6,8})$      - Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^\+54?(?:9)?0?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Alternative format when country code is omitted (must start with 0)
  const withoutCountryRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  return argentinePhoneRegex.test(cleanValue) || withoutCountryRegex.test(cleanValue);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name validation regex:
  // ^[\p{L}\p{M}]+          - Start with one or more unicode letters (including accents)
  // (?:['-\s][\p{L}\p{M}]+)* - Allow apostrophes, hyphens, or spaces followed by more letters
  // $                       - End of string
  // \p{L} matches any kind of letter from any language
  // \p{M} matches combining marks (like accents)
  const nameRegex = /^[A-Za-z\u00C0-\u024F]+(?:['-\s][A-Za-z\u00C0-\u024F]+)*$/;
  
  // Reject obvious invalid cases
  // Empty string
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Too short (less than 2 characters after trimming)
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject patterns like "X Æ A-12" which contains digits and non-letter symbols
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value.trim());
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check valid lengths for major cards
  const validLengths = [13, 14, 15, 16, 19];
  if (!validLengths.includes(digits.length)) {
    return false;
  }
  
  // Card patterns:
  // Visa: 4 followed by 12-18 digits (13 or 16 digits total)
  // Mastercard: 51-55 or 2221-2720 followed by 12-14 digits (16 digits total)
  // Amex: 34 or 37 followed by 13 digits (15 digits total)
  
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^((51|52|53|54|55)\d{14}|(222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[0-1]\d|2720)\d{12})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Test against card patterns
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(digits);
}

/**
 * Helper function to run the Luhn algorithm for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
