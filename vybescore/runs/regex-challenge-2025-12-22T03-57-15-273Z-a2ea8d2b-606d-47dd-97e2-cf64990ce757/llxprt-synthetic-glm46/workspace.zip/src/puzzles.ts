/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // \\b ensures matching whole words
  // \\w+ matches the rest of the word
  const pattern = new RegExp(`\\b${escapeRegex(prefix)}\\w+`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
  
  // Return unique matches
  return [...new Set(result)];
}

// Helper function to escape regex special characters
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences of the token that are preceded by a digit and not at start of string
  // Match digit followed by our token
  const pattern = new RegExp(`\\d${escapeRegex(token)}`, 'g');
  const matches = [];
  
  let match;
  while ((match = pattern.exec(text)) !== null) {
    const matchedText = match[0];
    const index = match.index;
    
    // Make sure the token is not at the very beginning of the string
    if (index > 0) {
      matches.push(matchedText);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Contains at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Contains at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Contains at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
// Contains at least one symbol
  if (!/[!@#$%^&*()_+=[\]{};':"|,.<>]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // Check for repeating patterns of 2+ characters
  for (let i = 0; i < value.length - 2; i++) {
    for (let len = 1; len <= (value.length - i) / 2; len++) {
      const segment = value.substr(i, len);
      const nextSegment = value.substr(i + len, len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check if the text contains an IPv6 address pattern
  // IPv6 has colons, which IPv4 doesn't
  if (!value.includes(':')) {
    return false;
  }
  
  // IPv6 patterns that include shorthand and mixed notation
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){7}/;
  
  // Compressed IPv6 with :: (at least one pair of hexadecimal groups separated by ::)
  const compressedIPv6 = /[0-9a-fA-F]{0,4}(?:::[0-9a-fA-F]{0,4})+/;
  
  // Special case: just :: (compressed to zero)
  const justCompressed = /::/;
  
  // Check if it matches any IPv6 pattern
  return fullIPv6.test(value) || 
         compressedIPv6.test(value) || 
         justCompressed.test(value);
}
