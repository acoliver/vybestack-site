/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // Simple approach: split by sentence boundaries and capitalize each part
  const parts = text.split(/([.?!])/);
  
  // First character of the text should always be capitalized
  parts[0] = parts[0].charAt(0).toUpperCase() + parts[0].slice(1);
  
  // For each sentence part followed by a terminator, capitalize the next part
  for (let i = 2; i < parts.length; i += 2) {
    // parts[i-2] is the text
    // parts[i-1] is the terminator (., ?, !)
    // parts[i] is the text after it
    if (parts[i].length > 0) {
      // Skip leading whitespace and capitalize the first character
      const textAfterTerminator = parts[i];
      if (textAfterTerminator.charAt(0) === ' ') {
        // Skip space and capitalize first letter
        if (textAfterTerminator.length > 1) {
          parts[i] = ' ' + textAfterTerminator.substring(1, 2).toUpperCase() + textAfterTerminator.substring(2);
        }
      } else {
        parts[i] = textAfterTerminator.substring(0, 1).toUpperCase() + textAfterTerminator.substring(1);
      }
    }
  }
  
  return parts.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: http/https scheme, optional www, domain with TLD, optional path
  // This regex captures URLs without trailing punctuation
  const urlRegex = /(https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_.~#?&//=]*))/g;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation that isn't part of the URL
    url = url.replace(/[.,;!?'")+]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // This function rewrites URLs according to these rules:
  // 1. Always upgrade the scheme to https://
  // 2. For docs paths, rewrite the host to docs.example.com
  // 3. Skip host rewrite for dynamic content, query strings, or legacy extensions
  
  // First, upgrade all schemes to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then rewrite docs paths
  // Match https://example.com/docs/... -> https://docs.example.com/...
  // But exclude paths with dynamic hints, query strings, or legacy extensions
  const docsUrlPattern = /(https:\/\/)([a-zA-Z0-9.-]+)(\/docs\/[a-zA-Z0-9._/-]+)(?![?&]|[.](jsp|php|asp|aspx|do|cgi|pl|py))/g;
  
  result = result.replace(docsUrlPattern, (match, scheme, host, path) => {
    // Extract the domain without subdomains, and preserve TLD
    const domainParts = host.split('.');
    const tld = domainParts[domainParts.length - 1];
    const baseDomain = domainParts[0];
    
    // Reconstruct as docs.domain.tld
    return `${scheme}docs.${baseDomain}.${tld}${path}`;
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with validation
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const year = match[3];
  return year;
}
