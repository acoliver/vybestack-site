export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportOptions {
  includeTotals: boolean;
  outputPath?: string;
  format: 'markdown' | 'text';
}

export type ReportFormatter = (
  data: ReportData,
  options: Pick<ReportOptions, 'includeTotals'>
) => string;