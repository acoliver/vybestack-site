#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { parseArgs } from '../utils/cli.js';
import { validateReportData } from '../utils/validation.js';
import { getFormatter } from '../formatters/index.js';

async function main(): Promise<void> {
  try {
    const { dataPath, options } = parseArgs(process.argv.slice(2));

    // Read and parse JSON
    let dataJson: unknown;
    try {
      const fileContent = readFileSync(dataPath, 'utf8');
      dataJson = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Invalid JSON in ${dataPath}: ${error.message}`);
      }
      throw error;
    }

    // Validate data
    const reportData = validateReportData(dataJson);

    // Get formatter and render
    const formatter = getFormatter(options.format);
    const output = formatter(reportData, { includeTotals: options.includeTotals });

    // Write output
    if (options.outputPath) {
      writeFileSync(options.outputPath, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
