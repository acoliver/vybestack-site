import type { ReportData, ReportEntry } from '../types.js';

function isReportEntry(obj: unknown): obj is ReportEntry {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'label' in obj &&
    typeof (obj as ReportEntry).label === 'string' &&
    'amount' in obj &&
    typeof (obj as ReportEntry).amount === 'number'
  );
}

export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!('title' in obj) || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title');
  }

  if (!('summary' in obj) || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary');
  }

  if (!('entries' in obj) || !Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries array');
  }

  const entries = obj.entries;
  if (entries.some((entry) => !isReportEntry(entry))) {
    throw new Error(
      'Invalid report data: all entries must have a label (string) and amount (number)'
    );
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries as ReportEntry[],
  };
}