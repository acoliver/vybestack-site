import type { ReportOptions } from '../types.js';

export function parseArgs(args: string[]): {
  dataPath: string;
  options: ReportOptions;
} {
  // Default options
  const options: ReportOptions = {
    format: 'markdown',
    includeTotals: false,
  };

  let dataPath = '';
  
  // Parse arguments
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      options.format = format;
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      options.outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (!dataPath) {
      dataPath = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!dataPath) {
    throw new Error('Missing data file path');
  }

  return { dataPath, options };
}