import { createInput, createComputed } from './dist/index.js';

console.log('Testing cascade reactivity...');
// Test 1: Direct cascade
const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => input() * 2);
const sum = createComputed(() => timesTwo() + input());

console.log('initials:');
console.log('-- input:', input());
console.log('-- timesTwo:', timesTwo()); 
console.log('-- sum:', sum());

console.log('\nafter setting input to 3:');
setInput(3);
console.log('-- input:', input());
console.log('-- timesTwo (should be 6):', timesTwo()); 
console.log('-- sum (should be 9):', sum());