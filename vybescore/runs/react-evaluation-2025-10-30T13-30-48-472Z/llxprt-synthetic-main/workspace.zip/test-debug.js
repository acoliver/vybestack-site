import { createInput, createComputed, createCallback } from './dist/index.js';

console.log('Testing the reactive system step by step...');

// Test 1: Basic createInput test
console.log('\nTest 1: Basic createInput test');
const [getter, setter] = createInput(1);
console.log('Initial value:', getter()); // Should be 1
setter(3);
console.log('After setting to 3:', getter()); // Should be 3

// Test 2: Simple computed
console.log('\nTest 2: Simple computed');
const [input, setInput] = createInput(1);
const double = createComputed(() => input() * 2);
console.log('Initial double:', double()); // Should be 2
setInput(3);
console.log('After setting input to 3, double is:', double()); // Should be 6

// Test 3: Compute cells depend on other compute cells
console.log('\nTest 3: Compute cells depend on other compute cells');
const [input2, setInput2] = createInput(1);
const timesTwo = createComputed(() => input2() * 2);
const timesThirty = createComputed(() => input2() * 30);
const sum = createComputed(() => timesTwo() + timesThirty());

console.log('Initial values:');
console.log('input:', input2()); // Should be 1
console.log('timesTwo:', timesTwo()); // Should be 2
console.log('timesThirty:', timesThirty()); // Should be 30
console.log('sum:', sum()); // Should be 32

console.log('\nAfter setting input to 3:');
setInput2(3);
console.log('input:', input2()); // Should be 3
console.log('timesTwo:', timesTwo()); // Should be 6
console.log('timesThirty:', timesThirty()); // Should be 90
console.log('sum:', sum()); // Should be 96

// Test 4: Callback test
console.log('\nTest 4: Callback test');
const [input3, setInput3] = createInput(1);
const output = createComputed(() => input3() + 1);
let value = 0;
createCallback(() => (value = output()));
console.log('Initial value in callback:', value); // Should be 2
setInput3(3);
console.log('After setting input to 3, value in callback:', value); // Should be 4

// Test 5: Callback unsubscribe test
console.log('\nTest 5: Callback unsubscribe test');
const [input4, setInput4] = createInput(11);
const output4 = createComputed(() => input4() + 1);

const values1 = [];
const unsubscribe1 = createCallback(() => values1.push(output4()));
const values2 = [];
createCallback(() => values2.push(output4()));

console.log('Before any changes:');
console.log('values1:', values1);
console.log('values2:', values2);

console.log('\nAfter setting input to 31:');
setInput4(31);
console.log('values1:', values1);
console.log('values2:', values2);

console.log('\nAfter unsubscribing first callback and setting input to 41:');
unsubscribe1();
setInput4(41);
console.log('values1:', values1);
console.log('values2:', values2);
console.log('values1.length:', values1.length);
console.log('values2.length:', values2.length);