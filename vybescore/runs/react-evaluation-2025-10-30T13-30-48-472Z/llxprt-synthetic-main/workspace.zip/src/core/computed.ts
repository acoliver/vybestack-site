/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // The _equal parameter is not currently used in this implementation
  // but kept for future enhancement and API consistency

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: []
  }
  
  const getter = (): T => {
    // First, check if there's an active observer (i.e., we're being called in another computed/callback)
    const observer = getActiveObserver()
    if (observer) {
      // We're being tracked by another observer
      // Ensure the observer is registered with this computed value
      if (!o.observers) {
        o.observers = []
      }
      if (o.observers.indexOf(observer) === -1) {
        o.observers.push(observer)
      }
    }
    
    // Recompute only if needed
    if (o.value === undefined) {
      updateObserver(o)
    }
    
    return o.value!
  }
  
  // Initialize the computed value if no initial value is provided
  if (value === undefined) {
    updateObserver(o)
  }
  
  return getter
}