/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      if (!s.observers) {
        s.observers = []
      }
      if (s.observers.indexOf(observer) === -1) {
        s.observers.push(observer)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers
    if (s.observers) {
      const observers = [...s.observers] // Copy to avoid issues during iteration
      for (const observer of observers) {
        // Force recomputation by setting value to undefined first
        const obsAsObserver = observer as Observer<T>
        obsAsObserver.value = undefined
        // Update the observer
        updateObserver(obsAsObserver)
      }
    }
    
    return s.value
  }

  return [read, write]
}