/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    observers: []
  }
  
  let disposed = false
  
  // Register observer to track dependencies and run once
  if (!disposed) {
    updateObserver(observer)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up all tracked dependencies
    if (observer.observers) {
      for (const subject of observer.observers) {
        if (subject.observers) {
          const index = subject.observers.indexOf(observer)
          if (index !== -1) {
            subject.observers.splice(index, 1)
          }
        }
      }
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}