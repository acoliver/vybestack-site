import { createInput, createComputed } from './dist/index.js';

console.log('Testing failing case...');
// Recreate exact case from failing test
const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => input() * 2);
const timesThirty = createComputed(() => input() * 30);
const sum = createComputed(() => {
  console.log('- sum recomputing, timesTwo:', timesTwo(), 'timesThirty:', timesThirty());
  return timesTwo() + timesThirty();
});

console.log('initials:');
console.log('-- input:', input());
console.log('-- timesTwo:', timesTwo()); 
console.log('-- timesThirty:', timesThirty());
console.log('-- sum:', sum());

console.log('\nafter setting input to 3:');
setInput(3);
console.log('-- input:', input());
console.log('-- timesTwo (should be 6):', timesTwo()); 
console.log('-- timesThirty (should be 90):', timesThirty());
console.log('-- sum (should be 96):', sum());

// Test what happens when we call all again explicitly
console.log('\nexplicit access:');
sum();
timesTwo();
timesThirty();
console.log('-- sum final:', sum());