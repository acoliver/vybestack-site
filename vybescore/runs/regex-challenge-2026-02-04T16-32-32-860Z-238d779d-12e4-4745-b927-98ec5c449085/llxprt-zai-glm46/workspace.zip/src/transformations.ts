/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries (.?!) and ensures proper spacing.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence endings, keeping the delimiters
  const parts = text.split(/([.!?])/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    
    // If this is a sentence ending punctuation
    if (/^[.!?]$/.test(part)) {
      result += part + ' ';
      capitalizeNext = true;
    } else {
      // This is text (sentence or text between punctuation)
      let sentence = part.trim();
      
      // Collapse multiple spaces within the sentence
      sentence = sentence.replace(/\s+/g, ' ');
      
      if (sentence.length > 0) {
        // Capitalize first character if needed
        if (capitalizeNext) {
          sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
          capitalizeNext = false;
        }
        
        result += sentence;
      }
    }
  }
  
  // Trim trailing space that might have been added
  return result.trim();
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex
  // Matches http://, https://, www. with common domain patterns
  const urlRegex = /(?:https?:\/\/|www\.)[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s\])"'}]*)?/gi;

  const matches = text.match(urlRegex) || [];

  // Remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters: .,!?;:')"] etc
    return url.replace(/[.,!?;:'"\]}]+$/, '');
  });
}

/**
 * Force all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://...
 * When path starts with /docs/, rewrite host to docs.example.com
 * Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const urlPattern = /(https?):\/\/(example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if we should skip host rewrite
    const skipRewrite = path.includes('cgi-bin') ||
                        path.includes('?') ||
                        path.includes('&') ||
                        path.includes('=') ||
                        /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    // If path starts with /docs/ and we're not skipping, rewrite host
    if (path.startsWith('/docs/') && !skipRewrite) {
      return `${newProtocol}://docs.example.com${path}`;
    }
    
    // Otherwise just upgrade the protocol
    return `${newProtocol}://${host}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
