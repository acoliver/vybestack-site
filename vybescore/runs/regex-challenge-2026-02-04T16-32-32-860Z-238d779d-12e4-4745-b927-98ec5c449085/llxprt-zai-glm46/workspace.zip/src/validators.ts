export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 * Accepts: user@tag@example.co.uk style addresses (subdomains allowed)
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Quick check for consecutive dots
  if (value.includes('..')) {
    return false;
  }

  // Check for exactly one @ sign (we need local@domain format)
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }

  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) {
    return false;
  }

  // Check for dot at start or end of local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  // Check for dot at start or end of domain
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }

  // Reject domains with underscores (invalid in domain names)
  if (domain.includes('_')) {
    return false;
  }

  // Check domain has at least one dot and valid TLD
  if (!domain.includes('.')) {
    return false;
  }

  const domainParts = domain.split('.');
  const tld = domainParts[domainParts.length - 1];
  
  // TLD should be at least 2 chars and only letters
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }

  // Validate local part: alphanumeric and common special chars, not starting/ending with dot
  // Allow alphanumeric, dots, hyphens, underscores, and common special chars
  const localRegex = /^[a-zA-Z0-9][a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*[a-zA-Z0-9]$/;
  const singleCharLocal = /^[a-zA-Z0-9]$/;
  
  if (!localRegex.test(localPart) && !singleCharLocal.test(localPart)) {
    return false;
  }

  // Validate domain: alphanumeric, dots, hyphens only (no underscores)
  const domainRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  if (!domainRegex.test(domain)) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    // If we have 11 digits and starts with 1 (no +), remove the leading 1
    digits = digits.substring(1);
  }

  // US phone numbers must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 (required when country code is omitted)
 * - Optional mobile indicator 9 (between country/trunk and area code)
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must start with optional +54, then optional 0 (if no +54), then optional 9, then area code, then subscriber
  // The trunk prefix 0 must come immediately before the area code when country code is omitted
  
  // First, let's check if country code is present
  const hasCountryCode = cleaned.startsWith('+54');
  
  // Remove country code for pattern matching
  let withoutCountry = cleaned;
  if (hasCountryCode) {
    withoutCountry = cleaned.substring(3); // Remove +54
  }
  
  // Now we should have: [0][9]areaCode[subscriber]
  // If no country code, 0 is required
  // If country code present, 0 is optional
  // 9 is optional in both cases
  
  // Match the pattern: optional 0, optional 9, area code (2-4 digits starting with 1-9), subscriber (6-8 digits)
  const mainPattern = /^(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = withoutCountry.match(mainPattern);
  
  if (!match) {
    // If main pattern doesn't match, try with explicit 0 required when no country code
    if (!hasCountryCode) {
      const requiredZeroPattern = /^0(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
      const requiredMatch = withoutCountry.match(requiredZeroPattern);
      if (!requiredMatch) {
        return false;
      }
    } else {
      return false;
    }
  }
  
  // Extract area code and subscriber from whichever pattern matched
  let areaCode: string, subscriber: string;
  
  if (match) {
    [, areaCode, subscriber] = match;
  } else {
    // Try the required zero pattern
    const requiredZeroPattern = /^0(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
    const requiredMatch = withoutCountry.match(requiredZeroPattern);
    if (requiredMatch) {
      [, areaCode, subscriber] = requiredMatch;
    } else {
      return false;
    }
  }
  
  // If country code is omitted, trunk prefix (0) must be present in original cleaned string
  if (!hasCountryCode) {
    if (!withoutCountry.startsWith('0')) {
      return false;
    }
  }
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }

  // Must not contain digits
  if (/\d/.test(value)) {
    return false;
  }

  // Check for invalid symbols (allow only letters, spaces, apostrophes, hyphens, accents)
  const validNameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!validNameRegex.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx).
 * Checks prefix, length, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7][0-9]{2})\d{12}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const isValidLength =
    (cleaned.length >= 13 && cleaned.length <= 19) ||
    (cleaned.length === 15) ||
    (cleaned.length === 16);

  if (!isValidLength) {
    return false;
  }

  const matchesPattern =
    visaRegex.test(cleaned) ||
    mastercardRegex.test(cleaned) ||
    amexRegex.test(cleaned);

  if (!matchesPattern) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
