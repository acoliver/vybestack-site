/**
 * Find words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  // Word boundary ensures we match whole words
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start.
 * Uses lookahead/lookbehind assertions.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match the token when preceded by a digit (not at string start)
  // Return the full match including the digit
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength.
 * Requirements: 10+ chars, uppercase, lowercase, digit, symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc, 1212)
  // Look for patterns where a sequence of 2-4 characters repeats immediately
  for (let len = 2; len <= 4; len++) {
    const repeatPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex (to exclude these)
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 regex patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand (double colon)
  // Can appear at start, end, or middle
  const ipv6Shorthand = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // IPv6 with IPv4 embedded (e.g., ::ffff:192.168.1.1)
  const ipv6Embedded = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*:?(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check if text contains IPv6 pattern
  const hasIPv6 = ipv6Full.test(value) || ipv6Shorthand.test(value) || ipv6Embedded.test(value);
  
  // Also check for standalone IPv6-like patterns that aren't IPv4
  if (hasIPv6) {
    // Make sure it's not actually an IPv4 address
    const lines = value.split(/\s+/);
    for (const line of lines) {
      // If this line matches IPv6 patterns and doesn't match IPv4
      if ((ipv6Full.test(line) || ipv6Shorthand.test(line) || ipv6Embedded.test(line)) &&
          !ipv4Regex.test(line)) {
        return true;
      }
    }
  }
  
  return false;
}
