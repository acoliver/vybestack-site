/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

const DEBUG = false

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      if (DEBUG) console.log(`[input ${s.name}] read: observer=${observer.name || 'anonymous'}`)
      // If there's already an observer, chain them
      if (s.observer && s.observer !== observer) {
        // The new observer should point to the old observer
        // But only if it doesn't already have an observer
        if (!observer.observer) {
          if (DEBUG) console.log(`[input ${s.name}] chaining: ${observer.name || 'anonymous'} -> ${s.observer.name || 'anonymous'}`)
          observer.observer = s.observer
        }
      }
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    if (DEBUG) console.log(`[input ${s.name}] write: ${oldValue} -> ${nextValue}`)
    
    // Only trigger updates if the value actually changed
    if (oldValue !== nextValue) {
      // Trigger update for the observer if one exists
      if (s.observer) {
        // Update all observers in the chain
        let current: ObserverR | undefined = s.observer
        const visited = new Set<ObserverR>()
        while (current && !visited.has(current)) {
          visited.add(current)
          if (DEBUG) console.log(`[input ${s.name}] updating: ${current.name || 'anonymous'}`)
          updateObserver(current as Observer<unknown>)
          current = current.observer
        }
      }
    }
    
    return s.value
  }

  return [read, write]
}
