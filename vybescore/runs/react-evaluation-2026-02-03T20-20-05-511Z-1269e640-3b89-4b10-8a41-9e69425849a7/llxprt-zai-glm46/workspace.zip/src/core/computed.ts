/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

const DEBUG = false

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | unknown,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  let isInitializing = true
  
  // Wrap the update function to propagate changes to dependents
  const originalUpdateFn = o.updateFn
  let isUpdating = false
  o.updateFn = (prevValue?: T) => {
    if (DEBUG) console.log(`[computed ${o.name}] updateFn called, isUpdating=${isUpdating}`)
    
    // Always compute the new value
    const newValue = originalUpdateFn(prevValue)
    
    if (DEBUG) console.log(`[computed ${o.name}] new value: ${newValue}`)
    
    // Only propagate if we're not already in an update cycle and not initializing
    // (to prevent infinite loops and circular dependencies during initialization)
    if (!isUpdating && !isInitializing) {
      isUpdating = true
      try {
        // After recomputing, propagate to any dependent observer
        if (o.observer) {
          if (DEBUG) console.log(`[computed ${o.name}] propagating to ${o.observer.name || 'anonymous'}`)
          updateObserver(o.observer as Observer<unknown>)
        }
      } finally {
        isUpdating = false
      }
    }
    
    return newValue
  }
  
  // Initial computation to establish dependencies
  if (DEBUG) console.log(`[computed ${o.name}] initial computation`)
  updateObserver(o)
  isInitializing = false
  
  const getter = (): T => {
    const currentObserver = getActiveObserver()
    // If there's an active observer (e.g., a callback or another computed),
    // register this computed as their dependency
    if (currentObserver) {
      // Chain observers if there's already one
      if (o.observer && o.observer !== currentObserver) {
        // The new observer should point to the old observer
        // But only if it doesn't already have an observer
        if (!currentObserver.observer) {
          if (DEBUG) console.log(`[computed ${o.name}] getter: chaining ${currentObserver.name || 'anonymous'} -> ${o.observer.name || 'anonymous'}`)
          currentObserver.observer = o.observer
        }
      }
      if (DEBUG) console.log(`[computed ${o.name}] getter: setting observer to ${currentObserver.name || 'anonymous'}`)
      o.observer = currentObserver
    }
    return o.value!
  }
  
  return getter
}
