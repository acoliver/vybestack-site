/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Base64 character validation regex.
 * Matches only valid Base64 characters: A-Z, a-z, 0-9, +, /, and optional padding =
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate the input format and character set
 */
function validateInput(input: string): void {
  // Check for correct padding format
  const paddingIndex = input.indexOf('=');
  
  if (paddingIndex !== -1) {
    // If padding exists, length must be divisible by 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
    
    // Padding must be at the end, and no non-padding characters after it
    if (paddingIndex !== input.length - input.slice(paddingIndex).length) {
      throw new Error('Invalid Base64 input: padding characters not at the end');
    }
    
    // If padding exists, make sure only '=' characters are present after the first '='
    if (!/^(=+)?$/.test(input.slice(paddingIndex))) {
      throw new Error('Invalid Base64 input: padding characters not at the end');
    }
  } else {
    // For unpadded Base64, check if adding padding would make length divisible by 4
    const remainder = input.length % 4;
    if (remainder === 1) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }
}

/**
 * Add proper padding to Base64 input for decoding
 */
function preparePaddedInput(input: string): string {
  // If input is already padded or properly formatted, return as is
  if (input.length % 4 === 0) return input;
  
  // Add the necessary padding
  const remainder = input.length % 4;
  const paddingNeeded = (4 - remainder) % 4;
  return input + '='.repeat(paddingNeeded);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64 strings.
 */
export function decode(input: string): string {
  // Reject empty strings
  if (!input) {
    throw new Error('Input is empty');
  }
  
  // Remove whitespace and validate character set
  const cleanInput = input.trim();
  if (!BASE64_REGEX.test(cleanInput)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Validate and prepare input
  validateInput(cleanInput);
  
  // Ensure proper padding for decoding
  const paddedInput = preparePaddedInput(cleanInput);
  
  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: decode failed');
  }
}