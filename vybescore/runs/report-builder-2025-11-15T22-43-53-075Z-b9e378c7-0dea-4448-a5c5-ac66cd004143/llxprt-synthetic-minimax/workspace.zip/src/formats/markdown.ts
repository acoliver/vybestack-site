import { ReportData, Formatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderMarkdown: Formatter = {
  render: (data: ReportData, includeTotals: boolean): string => {
    const lines: string[] = [];
    
    // Title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries section
    lines.push('## Entries');
    
    // Entry bullets
    data.entries.forEach(entry => {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    });
    
    // Total if requested
    if (includeTotals) {
      lines.push('');
      lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
    }
    
    return lines.join('\n');
  }
};