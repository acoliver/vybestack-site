import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): CliOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Parse other arguments
  let format: 'markdown' | 'text' | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format': {
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        const formatValue = args[i + 1];
        if (formatValue !== 'markdown' && formatValue !== 'text') {
          console.error(`Error: Unsupported format '${formatValue}'. Supported formats: markdown, text`);
          process.exit(1);
        }
        format = formatValue;
        i++; // Skip the next argument since we consumed it
        break;
      }
        
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputPath = args[i + 1];
        i++; // Skip the next argument since we consumed it
        break;
        
      case '--includeTotals':
        includeTotals = true;
        break;
        
      default:
        if (arg.startsWith('--')) {
          console.error(`Error: Unknown option '${arg}'`);
          process.exit(1);
        }
        break;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return {
    dataPath,
    format,
    outputPath,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: Missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: Missing or invalid "amount" field`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT')) {
        console.error(`Error: Cannot read file '${filePath}'`);
      } else if (error.message.includes('JSON')) {
        console.error(`Error: Invalid JSON in file '${filePath}'`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to load report data');
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to file '${outputPath}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  const options = parseArguments();
  const reportData = loadReportData(options.dataPath);
  
  let formatter;
  switch (options.format) {
    case 'markdown':
      formatter = renderMarkdown;
      break;
    case 'text':
      formatter = renderText;
      break;
    default:
      console.error(`Error: Unsupported format '${options.format}'`);
      process.exit(1);
  }
  
  const output = formatter.render(reportData, options.includeTotals);
  writeOutput(output, options.outputPath);
}

main();