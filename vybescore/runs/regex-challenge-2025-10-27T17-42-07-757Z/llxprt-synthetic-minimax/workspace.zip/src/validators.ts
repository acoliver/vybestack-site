export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Local part: letters, numbers, and special chars like + - _ . but no double dots or trailing dots
  // Domain: letters, numbers, hyphens, dots, but no underscores or double dots
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for problematic patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const domain = parts[1];
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Check that domain has at least one dot and proper TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for basic length requirements (at least 10 digits)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Extract country code if present
  let remainingDigits = digitsOnly;
  let hasCountryCode = false;
  
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    hasCountryCode = true;
    remainingDigits = digitsOnly.substring(1);
  } else if (digitsOnly.length > 11) {
    return false; // Too many digits
  }
  
  // Check area code (first 3 digits)
  const areaCode = remainingDigits.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check that we have exactly 10 digits when country code is handled
  if (!hasCountryCode && remainingDigits.length !== 10) {
    return false;
  }
  
  // Basic format validation for the original string
  const phoneRegex = /^\+?1?[\s\-\.]?\(?([2-9]\d{2})\)?[\s\-\.]?([2-9]\d{2})[\s\-\.]?(\d{4})$/;
  
  // If extensions are allowed, check for them
  if (options?.allowExtensions) {
    const extensionRegex = /(ext|x|extension)[\s\-\.]?\d+$/i;
    if (extensionRegex.test(value)) {
      return true;
    }
  }
  
  return phoneRegex.test(value);
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space, non-hyphen characters for initial validation
  const cleanValue = value.replace(/[^\d\s\-]/g, '');
  
  // Remove spaces and hyphens to work with digits
  const digitsOnly = cleanValue.replace(/[\s\-]/g, '');
  
  // Must have at least some digits to be valid
  if (digitsOnly.length < 8) {
    return false;
  }
  
  // Check for valid Argentina format
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, mobileIndicator, areaCode, subscriberNumber] = match;
  
  // When country code is omitted, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Validate area code: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || !areaCode.match(/^[1-9]\d{1,3}$/)) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Validate mobile indicator positioning
  if (mobileIndicator) {
    // Mobile indicator should be present between country/trunk and area code
    if (countryCode && !mobileIndicator) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  throw new Error('TODO: implement isValidName');
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  throw new Error('TODO: implement isValidCreditCard');
}
