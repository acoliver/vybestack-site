#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { parseArgs } from 'node:util';


import type { ReportData, RenderOutputOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  data: string;
  format: string;
  output?: string;
  includeTotals?: boolean;
}



function validateReportData(data: unknown): ReportData {
  if (
    typeof data !== 'object' || 
    data === null || 
    !('title' in data) || 
    !('summary' in data) || 
    !('entries' in data)
  ) {
    throw new Error(
      'Invalid report data: missing required fields (title, summary, entries)'
    );
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  const entries = reportData.entries.map((entry: unknown): { label: string; amount: number } => {
    if (
      typeof entry !== 'object' || 
      entry === null || 
      !('label' in entry) || 
      !('amount' in entry)
    ) {
      throw new Error('Invalid report data: each entry must have label and amount');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: entry label must be a string');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: entry amount must be a number');
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries,
  };
}

async function parseCliArguments(): Promise<CliArgs> {
  const { values, positionals } = parseArgs({
    args: process.argv.slice(2),
    options: {
      format: {
        type: 'string',
      },
      output: {
        type: 'string',
      },
      includeTotals: {
        type: 'boolean',
      },
      help: {
        type: 'boolean',
        short: 'h',
      },
    },
    strict: true,
    allowPositionals: true,
  });

  if (values.help) {
    console.log(`
Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]

Arguments:
  data.json    Path to the JSON file containing report data

Options:
  --format <format>      Output format (markdown, text)
  --output <path>        Path to write output (defaults to stdout)
  --includeTotals        Include a total of all amounts
  -h, --help             Show this help message
`);
    process.exit(0);
  }

  if (positionals.length < 1) {
    throw new Error('Missing data file path');
  }

  const dataPath = positionals[0];

  if (!values.format) {
    throw new Error('Missing required --format option');
  }

  return {
    data: dataPath,
    format: values.format,
    output: values.output as string | undefined,
    includeTotals: values.includeTotals as boolean | undefined,
  };
}

async function readJsonFile(filePath: string): Promise<unknown> {
  try {
    const fileContent = await readFile(filePath, 'utf8');
    return JSON.parse(fileContent);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to read or parse JSON file: ${errorMessage}`);
  }
}

async function main(): Promise<void> {
  try {
    const cliArgs = await parseCliArguments();

    const jsonData = await readJsonFile(cliArgs.data);
    const reportData = validateReportData(jsonData);

    const format = cliArgs.format as Format;
    if (format !== 'markdown' && format !== 'text') {
      throw new Error('Unsupported format');
    }

    const options: RenderOutputOptions = {
      format,
      includeTotals: cliArgs.includeTotals,
    };

    let output: string;
    if (format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else {
      output = renderText(reportData, options);
    }

    if (cliArgs.output) {
      await writeFile(cliArgs.output, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(errorMessage);
    process.exit(1);
  }
}

main().catch((error) => {
  const errorMessage = error instanceof Error ? error.message : String(error);
  console.error(errorMessage);
  process.exit(1);
});