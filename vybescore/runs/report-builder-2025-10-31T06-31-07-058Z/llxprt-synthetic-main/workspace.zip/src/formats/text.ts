import type { ReportData, ReportOptions } from '../types.js';

export function renderText(data: ReportData, options: ReportOptions = {}): string {
  const { title, summary, entries } = data;
  const { includeTotals = false } = options;

  const lines: string[] = [];

  lines.push(title);
  lines.push('');
  lines.push(summary);
  lines.push('');
  lines.push('Entries:');
  lines.push('');

  entries.forEach(({ label, amount }) => {
    lines.push(`- ${label}: $${amount.toFixed(2)}`);
  });

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push('');
    lines.push(`Total: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
}