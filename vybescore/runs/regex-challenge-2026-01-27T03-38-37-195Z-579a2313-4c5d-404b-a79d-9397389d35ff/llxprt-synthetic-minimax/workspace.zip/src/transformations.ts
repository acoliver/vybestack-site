/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, ensure proper spacing and trim
  text = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize first letter of the entire string
  text = text.replace(/^\w/, letter => letter.toUpperCase());
  
  // Capitalize first letter after sentence endings (.?!)
  text = text.replace(/([.!?]\s+)(\w)/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  return text;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https URLs - exclude sentence-ending punctuation but allow dots
  const urlPattern = /https?:\/\/[^\s"'<>()[\]{};:,!?]+/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove sentence-ending punctuation but keep domain structure
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only if it's not already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const httpUrlPattern = /http:\/\/([^/\s]+)(\/[^\s]*)/g;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
  // Check if path contains dynamic hints or legacy extensions
  const dynamicHints = /cgi-bin|[&?]=/;
  const legacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i;
    const hasDynamicHints = dynamicHints.test(path) || legacyExtensions.test(path);
    
    if (!hasDynamicHints && path.startsWith('/docs/')) {
      // Rewrite host to docs.example.com and upgrade scheme to https
      return `https://docs.example.com${path}`;
    } else {
      // Just upgrade scheme to https, keep original host
      return `https://${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day with reasonable bounds
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Basic year validation (reasonable range)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return year.toString();
}
