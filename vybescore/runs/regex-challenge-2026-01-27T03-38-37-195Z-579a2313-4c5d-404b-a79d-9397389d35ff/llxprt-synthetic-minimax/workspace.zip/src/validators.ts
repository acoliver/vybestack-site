export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation using regex
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for obvious invalid forms
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Domain can't have underscore
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const domain = parts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to normalize
  const digitsOnly = value.replace(/\D/g, '');
  
  // Too short validation
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let normalizedNumber = digitsOnly;
  if (normalizedNumber.startsWith('1') && normalizedNumber.length === 11) {
    normalizedNumber = normalizedNumber.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (normalizedNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits)
  const areaCode = parseInt(normalizedNumber.substring(0, 3), 10);
  
  // Area code cannot start with 0 or 1 (NPA validation rule)
  if (areaCode < 200 || areaCode > 999) {
    return false;
  }
  
  // If we get here, the number format is valid
  // Check if the input matches common US phone formats
  const usPhonePatterns = [
    /^\+?1?[\s.-]?\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/, // General pattern
    /^\+?1?\d{10}$/, //Digits only with optional +1
    /^\+?1?[\s.-]?\d{3}[\s.-]?\d{3}[\s.-]?\d{4}$/ // Separated pattern
  ];
  
  return usPhonePatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize by removing all non-digit characters except +
  const normalized = value.replace(/[^\d+]/g, '');
  
  // Remove + for digit count calculations
  const digitsOnly = normalized.replace(/\+/g, '');
  
  // Check total digit count
  if (digitsOnly.length < 10 || digitsOnly.length > 13) {
    return false;
  }
  
  // Pattern for Argentine phone numbers
  // +54 (country) optional, 9 (mobile) optional, 0 (trunk) optional
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: remaining 6-8 digits
  const argentinePattern = /^\+?54?9?0?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePattern.test(digitsOnly)) {
    return false;
  }
  
  // Additional validation for area code length
  // Remove country code (+54) and mobile indicator (9) if present
  let checkNumber = digitsOnly;
  
  if (checkNumber.startsWith('549')) {
    checkNumber = checkNumber.substring(3);
  } else if (checkNumber.startsWith('54')) {
    checkNumber = checkNumber.substring(2);
  }
  
  // Remove trunk prefix if present
  if (checkNumber.startsWith('0')) {
    checkNumber = checkNumber.substring(1);
  }
  
  // Now checkNumber should start with area code (2-4 digits)
  if (checkNumber.length < 8 || checkNumber.length > 12) {
    return false;
  }
  
  const areaCodeLength = Math.min(4, Math.max(2, checkNumber.length - 6));
  const areaCode = checkNumber.substring(0, areaCodeLength);
  const subscriber = checkNumber.substring(areaCodeLength);
  
  // Area code must start with 1-9 and be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (parseInt(areaCode.charAt(0), 10) < 1) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accents), apostrophes, hyphens, spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Ensure no digits or symbols are present
  const forbiddenPattern = /[\d!@#$%^&*()_+=[\]{};:"\\|,.<>?~`]/;
  
  if (forbiddenPattern.test(value)) {
    return false;
  }
  
  // Additional check: must not be empty and should have reasonable length
  if (value.length < 1 || value.length > 100) {
    return false;
  }
  
  // Must not start or end with space/hyphen/apostrophe inappropriately
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').reverse().map(num => parseInt(num, 10));
  
  let sum = 0;
  for (let i = 0; i < digits.length; i++) {
    let num = digits[i];
    if (i % 2 === 1) { // Every second digit
      num *= 2;
      if (num > 9) {
        num -= 9; // Sum digits for numbers > 9
      }
    }
    sum += num;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Must have reasonable length (13-19 digits)
  if (cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }
  
  // Check for valid card type patterns and lengths
  const cardTypes = [
    // Visa: starts with 4, length 13, 16, or 19
    { pattern: /^4/, lengths: [13, 16, 19] },
    // MasterCard: starts with 51-55 or 2221-2720, length 16
    { pattern: /^(5[1-5]|2[2-7])/, lengths: [16] },
    // American Express: starts with 34 or 37, length 15
    { pattern: /^(3[47])/, lengths: [15] },
    // Discover: starts with 6011 or 65, length 16
    { pattern: /^(6011|65)/, lengths: [16] }
  ];
  
  let isValidType = false;
  for (const cardType of cardTypes) {
    if (cardType.pattern.test(cardNumber) && cardType.lengths.includes(cardNumber.length)) {
      isValidType = true;
      break;
    }
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(cardNumber);
}
