/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words and find those starting with the prefix
  const words = text.split(/\s+/);
  const exceptionSet = new Set(exceptions.map(exc => exc.toLowerCase()));
  
  const result: string[] = [];
  
  for (const word of words) {
    // Clean word of punctuation for checking
    const cleanWord = word.replace(/[^\w]/g, '');
    
    // Check if word starts with prefix and is not in exceptions
    if (cleanWord.toLowerCase().startsWith(prefix.toLowerCase()) && 
        !exceptionSet.has(cleanWord.toLowerCase())) {
      // Add the original word (with punctuation if present) to results
      result.push(word);
    }
  }
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where the token appears after a digit and not at string start
  // Pattern: preceded by any character (digit + token), excluding start of string
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Return the full matches (digit + token)
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?~`/]/.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (like abab)
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern for IPv6 addresses including shorthand notation
  // Must not match pure IPv4 addresses (dotted decimal)
  
  // Strict IPv6 pattern: 8 groups of 1-4 hex digits
  const fullIPv6Pattern = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 shorthand pattern with ::
  const shorthandIPv6Pattern = /([0-9a-fA-F]{0,4}:){0,7}::([0-9a-fA-F]{0,4}:){0,7}[0-9a-fA-F]{0,4}/;
  
  // IPv6 with embedded IPv4 (like ::ffff:192.168.1.1)
  const ipv4EmbeddedPattern = /([0-9a-fA-F]{0,4}:){0,6}::([0-9a-fA-F]{0,4}:){0,5}([0-9]{1,3}\.){3}[0-9]{1,3}/;
  
  // Pure IPv4 pattern to exclude
  const pureIPv4Pattern = /(\d{1,3}\.){3}\d{1,3}/;
  
  // Check for pure IPv4 first - should return false
  if (pureIPv4Pattern.test(value)) {
    return false;
  }
  
  // Check for any of the IPv6 patterns
  return fullIPv6Pattern.test(value) || shorthandIPv6Pattern.test(value) || ipv4EmbeddedPattern.test(value);
}
