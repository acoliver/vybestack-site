/**
 * Report data model matching fixtures/data.json
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * CLI options
 */
export interface CliOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals?: boolean;
}

/**
 * Render options passed to format modules
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Report calculation result
 */
export interface ReportResult {
  total: number;
  formattedOutput: string;
}