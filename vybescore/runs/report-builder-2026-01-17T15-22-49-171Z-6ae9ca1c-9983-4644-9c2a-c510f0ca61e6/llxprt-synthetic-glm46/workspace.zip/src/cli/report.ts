#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import type { ReportData, CliOptions, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): CliOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const options: CliOptions = {
    format: 'markdown', // Default
  };
  
  let i = 1; // Skip the data file argument at index 0
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[i];
      if (format !== 'markdown' && format !== 'text') {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      options.format = format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument ${arg}`);
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
    
    i++;
  }
  
  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return options;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries field');
  }
  
  const entries = obj.entries as unknown[];
  for (const entry of entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid report data: invalid entry format');
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: invalid entry label');
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: invalid entry amount');
    }
  }
  
  return data as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContents = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContents);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Error parsing JSON file: ${error.message}`);
    }
    throw error;
  }
}

function main() {
  try {
    const args = process.argv.slice(2);
    if (args.length < 1) {
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
    
    const dataFilePath = args[0];
    const options = parseArguments();
    
    const data = loadReportData(dataFilePath);
    
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals || false,
    };
    
    let result: string;
    switch (options.format) {
      case 'markdown':
        result = renderMarkdown(data, renderOptions);
        break;
      case 'text':
        result = renderText(data, renderOptions);
        break;
      default:
        console.error('Error: Unsupported format');
        process.exit(1);
    }
    
    if (options.output) {
      writeFileSync(options.output, result, 'utf-8');
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
