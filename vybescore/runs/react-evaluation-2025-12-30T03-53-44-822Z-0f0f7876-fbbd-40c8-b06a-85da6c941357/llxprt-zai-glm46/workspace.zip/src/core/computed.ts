/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  setActiveObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track dependencies for this computed value
  const dependencies = new Set<ObserverR>()
  o.dependencies = dependencies
  
  // Track observers that depend on this computed value
  const observers = new Set<ObserverR>()
  ;(o as ObserverR & { observers: Set<ObserverR> }).observers = observers
  
  // Override updateObserver to use our tracked version
  const originalUpdateFn = updateFn
  
  // Wrapper function that tracks dependencies during execution
  const trackedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    dependencies.clear()
    
    // Set this observer as active before computing
    setActiveObserver(o)
    
    try {
      const result = originalUpdateFn(prevValue)
      return result
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Use the tracked update function
  o.updateFn = trackedUpdateFn
  
  // Initial computation
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // Register this computed as a dependency of the active observer
      const activeDeps = activeObserver.dependencies
      if (activeDeps) {
        activeDeps.add(o)
      }
      
      // Also register the active observer as observing this computed
      observers.add(activeObserver)
    }
    return o.value!
  }
  
  return getter
}
