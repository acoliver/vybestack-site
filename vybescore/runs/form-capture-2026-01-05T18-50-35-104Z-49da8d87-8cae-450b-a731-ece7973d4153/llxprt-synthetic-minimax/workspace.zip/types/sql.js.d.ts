// Type declarations for sql.js module
declare module 'sql.js' {
  interface Database {
    run(sql: string, params?: any[]): void;
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(params?: any[]): void;
    free(): void;
  }

  interface SqlJsModule {
    Database: new (buffer?: Uint8Array) => Database;
  }

  type InitSqlJsFunction = (options?: {
    locateFile?: (file: string) => string;
  }) => Promise<SqlJsModule>;
}

declare const initSqlJs: (options?: {
  locateFile?: (file: string) => string;
}) => Promise<{
  Database: new (buffer?: Uint8Array) => {
    run(sql: string, params?: any[]): void;
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  };
}>;

export = initSqlJs;