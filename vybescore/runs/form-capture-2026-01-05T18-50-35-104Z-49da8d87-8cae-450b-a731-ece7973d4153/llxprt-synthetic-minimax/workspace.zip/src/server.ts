import express, { Request, Response, Application } from 'express';
import path from 'path';
import * as fs from 'fs';
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

interface SqlJsDatabase {
  run(sql: string, params?: initSqlJs.BindParams): void;
  exec(sql: string): void;
  prepare(sql: string): initSqlJs.Statement;
  export(): Uint8Array;
  close(): void;
}

class ContactFormServer {
  private app: Application;
  private db: SqlJsDatabase | null = null;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3535', 10);
    
    this.setupMiddleware();
    this.setupRoutes();
    this.setupGracefulShutdown();
  }

  private setupMiddleware(): void {
    // Set view engine to EJS
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, '../views'));

    // Parse form data
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());

    // Serve static files
    this.app.use(express.static(path.join(__dirname, '../public')));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const dbPath = path.join(__dirname, '../data/submissions.sqlite');
      
      // Initialize sql.js properly
      const SqlJsModule = await initSqlJs({
        locateFile: (file: string) => path.join(__dirname, `../node_modules/sql.js/dist/${file}`)
      });
      
      let db: initSqlJs.Database;
      
      if (fs.existsSync(dbPath)) {
        // Load existing database
        const fileBuffer = fs.readFileSync(dbPath);
        db = new SqlJsModule.Database(fileBuffer);
      } else {
        // Create new database
        db = new SqlJsModule.Database();
        
        // Create submissions table from schema
        const schemaPath = path.join(__dirname, '../db/schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db.exec(schema);
      }
      
      this.db = db;
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (this.db) {
      try {
        const dataPath = path.join(__dirname, '../data/submissions.sqlite');
        const data = this.db.export();
        fs.writeFileSync(dataPath, Buffer.from(data));
      } catch (error) {
        console.error('Failed to save database:', error);
      }
    }
  }

  private validateFormData(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
    ];

    requiredFields.forEach(field => {
      if (!data[field] || data[field].trim() === '') {
        errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required` });
      }
    });

    // Email validation
    if (data.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.push({ field: 'email', message: 'Please enter a valid email address' });
      }
    }

    // Phone validation (accept international formats)
    if (data.phone) {
      const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
      if (!phoneRegex.test(data.phone)) {
        errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
      }
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode) {
      const postalRegex = /^[a-zA-Z0-9\s-]{3,10}$/;
      if (!postalRegex.test(data.postalCode)) {
        errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
      }
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET / - Show contact form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('contact-form', {
        errors: [],
        formData: {} as FormData,
        title: 'Contact Us'
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvinceRegion: req.body.stateProvinceRegion || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const errors = this.validateFormData(formData);

        if (errors.length > 0) {
          // Render form with errors
          res.status(400).render('contact-form', {
            errors,
            formData,
            title: 'Contact Us - Please Fix Errors'
          });
          return;
        }

        // Insert into database
        if (this.db) {
          const stmt = this.db.prepare(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province_region, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          
          stmt.run([
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvinceRegion,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);
          
          stmt.free();
          this.saveDatabase();
        }

        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Error processing form submission:', error);
        res.status(500).render('contact-form', {
          errors: [{ field: 'email', message: 'An error occurred. Please try again.' }],
          formData: {} as FormData,
          title: 'Contact Us - Error'
        });
      }
    });

    // GET /thank-you - Show thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', {
        title: 'Thank You!'
      });
    });
  }

  private setupGracefulShutdown(): void {
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      
      if (this.db) {
        this.saveDatabase();
        this.db.close();
      }
      
      process.exit(0);
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    return new Promise((resolve, reject) => {
      try {
        this.app.listen(this.port, '0.0.0.0', () => {
          console.log(`Server running on port ${this.port}`);
          resolve();
        });
      } catch (error) {
        reject(error);
      }
    });
  }
}

// Start the server
if (require.main === module) {
  const server = new ContactFormServer();
  server.start().catch(console.error);
}

export { ContactFormServer };
