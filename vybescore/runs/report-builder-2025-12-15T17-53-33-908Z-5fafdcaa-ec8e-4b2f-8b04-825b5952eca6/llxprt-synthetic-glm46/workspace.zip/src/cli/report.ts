#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const result: Partial<CliArgs> = {
    includeTotals: false
  };
  
  let i = 0;
  result.dataFile = args[i++];
  
  while (i < args.length) {
    const arg = args[i++];
    
    if (arg === '--format') {
      if (i >= args.length) {
        throw new Error('--format requires a format argument');
      }
      result.format = args[i++];
    } else if (arg === '--output') {
      if (i >= args.length) {
        throw new Error('--output requires a path argument');
      }
      result.outputPath = args[i++];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!result.format) {
    throw new Error('--format is required');
  }
  
  if (result.format !== 'markdown' && result.format !== 'text') {
    throw new Error('Unsupported format');
  }
  
  return result as CliArgs;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as unknown;
    
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: root must be an object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid title field');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid summary field');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Invalid JSON: missing or invalid entries field');
    }
    
    const entries = obj.entries as unknown[];
    for (const [index, entry] of entries.entries()) {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid JSON: entry ${index} must be an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid JSON: entry ${index} missing or invalid label field`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid JSON: entry ${index} missing or invalid amount field`);
      }
    }
    
    return {
      title: obj.title,
      summary: obj.summary,
      entries: entries.map(entry => {
        const entryObj = entry as Record<string, unknown>;
        return {
          label: entryObj.label as string,
          amount: entryObj.amount as number
        };
      })
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, options: ReportOptions): string {
  if (format === 'markdown') {
    return renderMarkdown(data, options);
  } else if (format === 'text') {
    return renderText(data, options);
  } else {
    throw new Error('Unsupported format');
  }
}

function main(): void {
  try {
    const args = parseArgs();
    const data = loadReportData(args.dataFile);
    const options: ReportOptions = {
      includeTotals: args.includeTotals
    };
    
    const output = renderReport(data, args.format, options);
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
