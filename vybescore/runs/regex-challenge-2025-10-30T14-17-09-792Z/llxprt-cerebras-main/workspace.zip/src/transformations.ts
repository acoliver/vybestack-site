/**
 * Capitalizes the first character of each sentence and normalizes spacing.
 * Preserves abbreviations when possible and collapses extra whitespace sensibly.
 */
export function capitalizeSentences(text: string): string {
  // First, trim extra whitespace and replace multiple spaces with single space
  let result = text.trim().replace(/\s+/g, ' ');
  
  // Match sentence boundaries (.?! followed by space and a letter) and capitalize next letter
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
  
  // Also handle the case where the text starts with a lowercase letter
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  return result;
}

/**
 * Extracts all URLs from a text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs (http or https) and exclude trailing punctuation
  // The pattern ensures we match full domain names with at least one dot
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s,.;:!?)\]"]*\.[^\s,.;:!?)\]"]*/gi;
  const matches = text.match(urlRegex);
  return matches ? Array.from(new Set(matches)) : [];
}

/**
 * Forces all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not if already https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites HTTP URLs to HTTPS.
 * For paths starting with /docs/, rewrites the host to docs.example.com.
 * Skips host rewrite for dynamic URLs (.jsp,.php,.asp,.aspx,.do,.cgi,.pl,.py,?,=,&)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([\w.-]+)(\/[^\s,.;:!?)\]"]*)/gi, (match, host, path) => {
    // Upgrade the scheme to HTTPS
    let secureUrl = `https://${host}${path}`;
    
    // Check if path starts with /docs/ and is not a dynamic URL
    if (path.startsWith('/docs/') && 
        !/\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(path) &&
        !/[?=&]/.test(path)) {
      // Rewrite host to docs.{host}
      secureUrl = secureUrl.replace(/^https:\/\/([\w.-]+)/, 'https://docs.$1');
    }
    
    return secureUrl;
  });
}

/**
 * Extracts the year from a date string in mm/dd/yyyy format.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}