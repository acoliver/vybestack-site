export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates if a string is a properly formatted email address.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Remove whitespace and convert to lowercase for standardization
  const trimmedValue = value.trim().toLowerCase();
  
  // Basic email format check with additional validations
  const emailRegex = /^[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?$/;
  
  // Check for double dots, trailing dots, and underscores in domain
  if (!emailRegex.test(trimmedValue) || 
      trimmedValue.includes('..') || 
      trimmedValue.endsWith('.') || 
      trimmedValue.split('@')[1].includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with various common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length and area code validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's too short
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check if it's now exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Check for impossible area codes (leading 0 or 1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for digit validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex patterns for different formats
  const patterns = [
    // +54 9 11 1234 5678 (mobile with country code)
    /^\+549\d{2}\d{6,8}$/,
    // +54 341 123 4567 (landline with country code)
    /^\+54\d{2,4}\d{6,8}$/,
    // 011 1234 5678 (landline with trunk code)
    /^0\d{2,4}\d{6,8}$/
  ];
  
  // Check if any pattern matches
  const isMatch = patterns.some(pattern => pattern.test(cleanValue));
  if (!isMatch) {
    return false;
  }
  
  // Find matched pattern to extract parts
  let digitsOnly: string;
  if (cleanValue.startsWith('+54')) {
    digitsOnly = cleanValue.substring(3); // Remove +54 prefix
  } else {
    digitsOnly = cleanValue; // Starts with 0
  }
  
  // Extract area code and subscriber number
  let areaCode: string;
  let subscriberNumber: string;
  
  if (digitsOnly.startsWith('9')) {
    // Mobile format (9 + area code)
    const areaCodeLength = digitsOnly.length === 11 ? 2 : 3; // Area code is 2-3 digits after 9
    areaCode = digitsOnly.substring(1, 1 + areaCodeLength);
    subscriberNumber = digitsOnly.substring(1 + areaCodeLength);
  } else {
    // Landline format (direct area code)
    const areaCodeLength = digitsOnly.length <= 10 ? 2 : 3; // Area code is 2-3 digits
    areaCode = digitsOnly.substring(0, areaCodeLength);
    subscriberNumber = digitsOnly.substring(areaCodeLength);
  }
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits total)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Check if the name is empty
  if (!value.trim()) {
    return false;
  }
  
  // Basic format check - allowing unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\s'\-]+$/u;
  
  // Ensure at least one letter is present
  const hasLetter = /[\p{L}]/u.test(value);
  
  // Ensure no digits or special symbols (except for allowed ones)
  const hasInvalidChars = /[0-9_]/.test(value);
  
  return nameRegex.test(value) && hasLetter && !hasInvalidChars;
}

/**
 * Helper function to validate credit card numbers using the Luhn algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers based on prefix and length, then runs Luhn check.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: starts with 4, 13 or 16 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 51-55 or 2221-2720, 16 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2(22[1-9]\d{12}|2[3-9]\d{13}|[3-6]\d{14}|7[0-1]\d{13}|720\d{12}))$/;
  
  // AmEx: starts with 34 or 37, 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the accepted patterns
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn algorithm
  return runLuhnCheck(cleanValue);
}