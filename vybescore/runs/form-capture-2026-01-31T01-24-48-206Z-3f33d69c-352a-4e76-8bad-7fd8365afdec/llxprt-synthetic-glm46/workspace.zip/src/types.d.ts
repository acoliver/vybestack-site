declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): {
      run(...params: unknown[]): void;
      free(): void;
    };
    export(): Uint8Array;
    close(): void;
  }
  
  const initSqlJs: () => Promise<{ Database: new(data?: Uint8Array) => Database }>;
  export default initSqlJs;
  export { initSqlJs };
}