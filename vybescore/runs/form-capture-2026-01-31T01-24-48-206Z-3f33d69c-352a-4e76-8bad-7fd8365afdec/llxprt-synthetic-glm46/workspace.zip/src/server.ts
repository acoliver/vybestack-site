import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, saveDatabase, closeDatabase } from './db.js';
import { validateForm } from './validation.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');
const templatesPath = path.join(projectRoot, 'src', 'templates');
const publicPath = path.join(projectRoot, 'public');

const app = express();
const port = process.env.PORT || '3535';

let server: ReturnType<typeof app.listen> | null = null;

async function startServer() {
  try {
    await initializeDatabase();
    
    app.use(express.json());
    app.use(express.urlencoded({ extended: true }));
    app.use('/public', express.static(publicPath));
    
    app.set('view engine', 'ejs');
    app.set('views', templatesPath);
    
    app.get('/', (req, res) => {
      res.render('form', { errors: [], values: {} });
    });
    
    app.post('/submit', async (req, res) => {
      const validationResult = validateForm(req.body);
      
      if (!validationResult.isValid) {
        return res.status(400).render('form', {
          errors: validationResult.errors,
          values: validationResult.values
        });
      }
      
      try {
        const { getDatabase } = await import('./db.js');
        const db = getDatabase();
        const stmt = db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          validationResult.values.firstName,
          validationResult.values.lastName,
          validationResult.values.streetAddress,
          validationResult.values.city,
          validationResult.values.stateProvince,
          validationResult.values.postalCode,
          validationResult.values.country,
          validationResult.values.email,
          validationResult.values.phone
        ]);
        stmt.free();
        
        saveDatabase();
        
        return res.redirect('/thank-you');
      } catch (error) {
        console.error('Database insertion error:', error);
        return res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: validationResult.values
        });
      }
    });
    
    app.get('/thank-you', (req, res) => {
      const firstName = req.query.firstName || 'friend';
      res.render('thank-you', { firstName });
    });
    
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

function gracefulShutdown() {
  if (server) {
    server.close((err?: Error) => {
      if (err) {
        console.error('Error during server shutdown:', err);
        process.exit(1);
      }
      
      closeDatabase();
      console.log('Server shut down gracefully');
      process.exit(0);
    });
  }
}

startServer();
