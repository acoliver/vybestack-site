export interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  values: FormValues;
}

function validateRequired(value: string, fieldName: string): string | null {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return null;
}

function validateEmail(email: string): string | null {
  if (!email || email.trim() === '') {
    return 'Email is required';
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.trim())) {
    return 'Email is not valid';
  }
  
  return null;
}

function validatePhone(phone: string): string | null {
  if (!phone || phone.trim() === '') {
    return 'Phone number is required';
  }
  
  const phoneRegex = /^[+]?[(]?[0-9]{1,4}[)]?[-\s.]?[(]?[0-9]{1,4}[)]?[-\s.]?[0-9]{1,9}$/;
  if (!phoneRegex.test(phone.trim())) {
    return 'Phone number is not valid. Accept international formats like +44 20 7946 0958';
  }
  
  return null;
}

function validatePostalCode(postalCode: string): string | null {
  if (!postalCode || postalCode.trim() === '') {
    return 'Postal code is required';
  }
  
  const postalCodeRegex = /^[a-zA-Z0-9\s-]{2,10}$/;
  if (!postalCodeRegex.test(postalCode.trim())) {
    return 'Postal code is not valid';
  }
  
  return null;
}

export function validateForm(formData: Record<string, string>): ValidationResult {
  const errors: string[] = [];
  const values: FormValues = {
    firstName: formData.firstName || '',
    lastName: formData.lastName || '',
    streetAddress: formData.streetAddress || '',
    city: formData.city || '',
    stateProvince: formData.stateProvince || '',
    postalCode: formData.postalCode || '',
    country: formData.country || '',
    email: formData.email || '',
    phone: formData.phone || ''
  };

  const firstNameError = validateRequired(values.firstName, 'First name');
  if (firstNameError) errors.push(firstNameError);

  const lastNameError = validateRequired(values.lastName, 'Last name');
  if (lastNameError) errors.push(lastNameError);

  const addressError = validateRequired(values.streetAddress, 'Street address');
  if (addressError) errors.push(addressError);

  const cityError = validateRequired(values.city, 'City');
  if (cityError) errors.push(cityError);

  const stateError = validateRequired(values.stateProvince, 'State / Province / Region');
  if (stateError) errors.push(stateError);

  const postalCodeError = validatePostalCode(values.postalCode);
  if (postalCodeError) errors.push(postalCodeError);

  const countryError = validateRequired(values.country, 'Country');
  if (countryError) errors.push(countryError);

  const emailError = validateEmail(values.email);
  if (emailError) errors.push(emailError);

  const phoneError = validatePhone(values.phone);
  if (phoneError) errors.push(phoneError);

  return {
    isValid: errors.length === 0,
    errors,
    values
  };
}