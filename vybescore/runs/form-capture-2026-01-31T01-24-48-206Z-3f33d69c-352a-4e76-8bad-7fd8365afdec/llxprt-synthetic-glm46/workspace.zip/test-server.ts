import { spawn, ChildProcess } from 'node:child_process';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname);

let server: ChildProcess | null = null;

function startServer(): void {
  const serverPath = path.join(projectRoot, 'dist', 'server.js');
  
  console.log('Starting server...');
  server = spawn('node', [serverPath], {
    stdio: 'inherit',
    env: {
      ...process.env,
      PORT: '3535'
    }
  });
  
  server.on('error', (error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
  
  server.on('exit', (code) => {
    console.log(`Server process exited with code ${code}`);
    if (code !== 0) {
      process.exit(code);
    }
  });
  
  process.on('SIGINT', () => {
    console.log('Received SIGINT, shutting down server...');
    if (server) {
      server.kill('SIGTERM');
      server = null;
    }
    process.exit(0);
  });
  
  console.log('Server should be running on http://localhost:3535');
  console.log('Press Ctrl+C to stop the server');
}

startServer();