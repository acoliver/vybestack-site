/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes first character after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences
 * - Collapses multiple spaces to one
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();

  // Ensure exactly one space after sentence-ending punctuation (but not at the end)
  result = result.replace(/([.!?])\s*(?!\s*$)/g, '$1 ');

  // Capitalize the first character of the entire string
  result = result.replace(/^[a-z]/, char => char.toUpperCase());

  // Capitalize first letter after sentence-ending punctuation (. ! ?)
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, punct, char) => {
    return punct + char.toUpperCase();
  });

  // Trim any trailing space
  return result.trim();
}

/**
 * Extracts all URLs from the given text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. domains
  // Excludes trailing punctuation
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]*(\.[a-zA-Z0-9][a-zA-Z0-9-]*)+(?:[/?][^\s.,!?;:)]]*)?(?<![.,!?;:)])/g;

  const matches = text.match(urlPattern);
  return matches || [];
}

/**
 * Forces all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... to https://...
 * When path begins with /docs/, rewrites host to docs.example.com
 * Skips host rewrite for paths with dynamic hints: cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  // We need to capture the scheme, domain, and path separately
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, scheme, domain, path) => {
    // Always upgrade scheme to https
    const newScheme = 'https://';

    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = [
      'cgi-bin',
      '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'
    ];

    const hasDynamicHint = dynamicHints.some(hint => path.toLowerCase().includes(hint));

    // Check for query strings
    const hasQueryString = /[?&=]/.test(path);

    // If no dynamic hints and path starts with /docs/, rewrite host
    if (!hasDynamicHint && !hasQueryString && path.toLowerCase().startsWith('/docs/')) {
      return newScheme + 'docs.' + domain + path;
    }

    // Otherwise, just upgrade the scheme
    return newScheme + domain + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' if the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Assume leap year for Feb
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
