/**
 * Finds words beginning with the specified prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create word boundary pattern - using string concatenation to avoid template literal issues
  const pattern = new RegExp('\\b(' + escapedPrefix + '\\w+)\\b', 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));

  return matches
    .filter(word => !exceptionsLower.has(word.toLowerCase()))
    .filter((word, index, self) => self.indexOf(word) === index); // Remove duplicates
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookbehind to ensure the token is preceded by a digit.
 * Returns the full match including the digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use positive lookbehind to match token only after a digit
  // Match the digit + token combination
  const pattern = new RegExp('\\d' + escapedToken, 'gi');

  const matches = text.match(pattern) || [];

  // Return unique occurrences
  return [...new Set(matches)];
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol/special character
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab', '123123')
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol/special character (not letter or digit)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, 123123, abcabc)
  // Look for patterns where a sequence of 2-4 characters repeats immediately
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation with ::)
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern (to exclude)
  // Simple dotted decimal with 4 octets
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

  // Check if it's an IPv4 address first - if so, return false
  if (ipv4Pattern.test(value)) {
    // But still check if there's also IPv6 in the string
    // We want to detect IPv6 even if IPv4 is also present
  }

  // IPv6 patterns
  // Full format: 8 groups of 1-4 hex digits separated by colons
  const ipv6FullPattern = /(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}/;

  // IPv6 with :: shorthand (compressed zeros)
  // Must have at least 2 colon-separated groups before and/or after ::
  const ipv6CompressedPattern = /(?:[a-fA-F0-9]{1,4}:)*::(?:[a-fA-F0-9]{1,4}:*)*/;

  // Check for IPv6
  if (ipv6FullPattern.test(value) || ipv6CompressedPattern.test(value)) {
    return true;
  }

  return false;
}
