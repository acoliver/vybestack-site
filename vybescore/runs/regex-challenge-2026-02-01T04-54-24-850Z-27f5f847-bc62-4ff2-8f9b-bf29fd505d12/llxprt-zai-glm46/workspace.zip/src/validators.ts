export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses like 'name@tag@example.co.uk' and 'user@example.com'.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for double dots, trailing dot, leading dot in local or domain
  if (/\.\./.test(value) || /\.$/.test(value) || /^\./.test(value)) {
    return false;
  }

  // Local part: letters, digits, dots, hyphens, underscores, plus signs
  // But no consecutive dots, leading/trailing dots
  // Domain part: letters, digits, hyphens (no underscores), dots
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for underscores in domain (not allowed)
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers supporting common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all spaces, parentheses, hyphens, dots
  const cleaned = value.replace(/[\s().-]/g, '');

  // Check for optional +1 or 1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1')) {
    digits = digits.slice(1);
  }

  // Must be exactly 10 digits
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  // Area code cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (middle 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Options parameter reserved for future extensions like allowing extensions
  void options;

  return true;
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens to get the raw digits
  const cleaned = value.replace(/[\s-]/g, '');

  // Pattern for Argentine phone:
  // Optional +54 (country code with plus)
  // OR starts with 0 (trunk prefix when no country code)
  // Optional 9 (mobile indicator)
  // Area code: 2-4 digits, starting with 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54|0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;

  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }

  // Extract parts after optional country code and mobile indicator
  let digits = cleaned;
  if (digits.startsWith('+54')) {
    digits = digits.slice(3);
  }

  // Check that without country code, it starts with 0 (trunk prefix)
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }

  // Remove trunk prefix and mobile indicator
  if (digits.startsWith('0')) {
    digits = digits.slice(1);
  }
  if (digits.startsWith('9')) {
    digits = digits.slice(1);
  }

  // Now digits should be area code + subscriber number
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  // Total should be 8-12 digits
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }

  // Validate area code (first 2-4 digits)
  const areaCodeLength = digits.length >= 11 ? 4 : digits.length >= 10 ? 3 : 2;
  const areaCode = digits.slice(0, areaCodeLength);
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }

  // Validate subscriber number (remaining digits)
  const subscriber = digits.slice(areaCodeLength);
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Allow unicode letters (including accented), apostrophes, hyphens, and spaces
  // Reject digits and other symbols
  const nameRegex = /^[\p{L}'-]+(?:\s[\p{L}'-]+)*$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Reject names with digits (like 'X Æ A-12')
  if (/\d/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) using prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check length and prefixes for Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4\d{12}(\d{3})?$/;
  // Check Mastercard (16 digits, starts with 51-55 or 2221-2720)
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7][0-9]{2})\d{12}$/;
  // Check AmEx (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;

  const validLength = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validLength) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn algorithm checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
