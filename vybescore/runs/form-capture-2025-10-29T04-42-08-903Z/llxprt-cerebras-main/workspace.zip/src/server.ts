import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Initialize express app
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use('/public', express.static(path.join(__dirname, '../public')));

// DB file path
const DB_FILE_PATH = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
let db: Database | null = null;

async function initializeDatabase() {
  const SQL = await initSqlJs({
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
  });
  
  // Load existing database or create new one
  let dbData: Uint8Array | null = null;
  if (fs.existsSync(DB_FILE_PATH)) {
    dbData = fs.readFileSync(DB_FILE_PATH);
  }
  
  db = new SQL.Database(dbData);
  
  // Create table if it doesn't exist
  const schemaSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
  db.run(schemaSql);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

type FormValues = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

app.post('/submit', (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors: string[] = [];

  // Check required fields
  Object.entries(values).forEach(([key, value]) => {
    if (!value && key !== 'phone') { // phone is not marked as required in the instructions
      errors.push(`${key.replace(/([A-Z])/g, ' $1')} is required`);
    }
  });

  // Validate email
  if (values.email && !validateEmail(values.email)) {
    errors.push('Email is invalid');
  }

  // Validate phone
  if (values.phone && !validatePhone(values.phone)) {
    errors.push('Phone number is invalid');
  }

  // Validate postal code
  if (values.postalCode && !validatePostalCode(values.postalCode)) {
    errors.push('Postal code is invalid');
  }

  // If there are validation errors, re-render the form with errors and values
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values });
  }

  // Insert into database
  if (db) {
    const statement = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    statement.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone,
    ]);
    
    statement.free();
    
    // Write database back to file
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_FILE_PATH, buffer);
  }

  // Redirect to thank-you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(values.firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;

function startServer() {
  server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

function closeServer() {
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db) {
    db.close();
    console.log('Database closed');
  }
}

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  closeServer();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  closeServer();
  process.exit(0);
});

// Initialize database and start server
initializeDatabase().then(() => {
  startServer();
}).catch((err) => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});