/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  dependents: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

const observerStack: ObserverR[] = []

export function getActiveObserver(): ObserverR | undefined {
  return observerStack[observerStack.length - 1]
}

export function pushActiveObserver(observer: ObserverR | undefined): void {
  if (observer) {
    observerStack.push(observer)
  }
}

export function popActiveObserver(): ObserverR | undefined {
  return observerStack.pop()
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = getActiveObserver()
  if (previous !== observer) {
    pushActiveObserver(observer)
  }
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    const current = getActiveObserver()
    if (current === observer && previous) {
      popActiveObserver()
      observerStack.push(previous)
    } else if (current === observer) {
      popActiveObserver()
    }
  }
}

export function addDependent(subject: Subject<unknown>, observer: ObserverR): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

export function removeDependent(subject: Subject<unknown>, observer: ObserverR): void {
  if (subject.dependents) {
    subject.dependents.delete(observer)
  }
}

export function notifyDependents<T>(subject: Subject<T>): void {
  if (!subject.dependents) return
  
  const dependents = Array.from(subject.dependents)
  for (const observer of dependents) {
    // Only update if it has the updateFn (complete observer)
    if ('updateFn' in observer && observer.updateFn) {
      // Cast to the complete observer type and update
      updateObserver(observer as Observer<unknown>)
    }
  }
}
