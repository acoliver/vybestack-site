/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  Subject,
  pushActiveObserver,
  popActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set()
  }
  
  const read: GetterFn<T> = () => {
    // Track dependencies by registering with any active observer
    const active = getActiveObserver()
    if (active) {
      // Register this computed observer as a dependent of the active observer
      if (!active.dependents) {
        active.dependents = new Set()
      }
      active.dependents.add(o)
    }
    
    // Use updateObserver for proper dependency tracking and recomputation
    updateObserver(o)
    
    return o.value!
  }
  
  return read
}
