/**
 * Encode plain text to Base64 using standard Base64 alphabet.
 * Returns output with proper padding when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Remove whitespace from input
  const cleanInput = input.replace(/\s/g, '');
  
  // Validate that input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(cleanInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Add missing padding to make length a multiple of 4
  let paddedInput = cleanInput;
  const remainder = paddedInput.length % 4;
  if (remainder === 2) {
    paddedInput += '==';
  } else if (remainder === 3) {
    paddedInput += '=';
  } else if (remainder !== 0) {
    throw new Error('Invalid Base64 input: length remainder must be 0, 2, or 3');
  }
  
  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch {
    throw new Error('Invalid Base64 input: decoding failed');
  }
}