import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Default values
    const defaultPage = 1;
    const defaultLimit = 5;
    const maxLimit = 100;

    // Parse and validate page parameter
    let page = defaultPage;
    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || !Number.isInteger(parsedPage) || parsedPage < 1) {
        return res.status(400).json({ 
          error: 'Invalid page parameter. Must be a positive integer.' 
        });
      }
      page = parsedPage;
    }

    // Parse and validate limit parameter
    let limit = defaultLimit;
    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || !Number.isInteger(parsedLimit) || parsedLimit < 1 || parsedLimit > maxLimit) {
        return res.status(400).json({ 
          error: `Invalid limit parameter. Must be a positive integer between 1 and ${maxLimit}.` 
        });
      }
      limit = parsedLimit;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
