/**
 * Input closure implementation for reactive primitives.
 */

import {
  ReactiveNode,
  getActiveNode,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Normalize equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'boolean') {
    equalFn = _equal ? (a, b) => a === b : undefined
  } else if (_equal) {
    equalFn = _equal
  }

  const node: ReactiveNode<T> = {
    value,
    dependencies: new Set(),
    dependents: new Set(),
    update: () => {
      // Input nodes don't auto-update, they are set explicitly
    },
  }

  const read: GetterFn<T> = () => {
    const active = getActiveNode()
    if (active && !node.dependents.has(active)) {
      node.dependents.add(active)
      active.dependencies.add(node)
    }
    return node.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (equalFn && equalFn(node.value, nextValue)) {
      return node.value
    }
    
    node.value = nextValue
    
    // Notify all dependents
    const dependentsCopy = Array.from(node.dependents)
    for (const dependent of dependentsCopy) {
      if (!dependent.disposed) {
        dependent.update()
      }
    }
    
    return node.value
  }

  return [read, write]
}
