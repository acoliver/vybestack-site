/**
 * Computed closure implementation for derived values.
 */

import { 
  ReactiveNode,
  getActiveNode,
  setActiveNode,
  GetterFn, 
  UpdateFn, 
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): GetterFn<T> {
  // Normalize equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'boolean') {
    equalFn = _equal ? (a, b) => a === b : undefined
  } else if (_equal) {
    equalFn = _equal
  }

  const node: ReactiveNode<T> = {
    value: value as T,
    dependencies: new Set(),
    dependents: new Set(),
    update: () => {
      const previous = getActiveNode()
      setActiveNode(node)
      
      try {
        // Clear previous dependencies
        for (const dep of node.dependencies) {
          dep.dependents.delete(node)
        }
        node.dependencies.clear()
        
        // Compute new value
        const newValue = updateFn(node.value)
        
        // Check if value actually changed
        if (!equalFn || node.value === undefined || !equalFn(node.value, newValue)) {
          node.value = newValue
          
          // Notify all dependents
          const dependentsCopy = Array.from(node.dependents)
          for (const dependent of dependentsCopy) {
            if (!dependent.disposed) {
              dependent.update()
            }
          }
        }
      } finally {
        setActiveNode(previous)
      }
    },
  }
  
  // Initial computation
  node.update()
  
  return (): T => {
    // When accessed, this node should be tracked as a dependency
    const active = getActiveNode()
    if (active && !node.dependents.has(active)) {
      node.dependents.add(active)
      active.dependencies.add(node)
    }
    return node.value
  }
}
