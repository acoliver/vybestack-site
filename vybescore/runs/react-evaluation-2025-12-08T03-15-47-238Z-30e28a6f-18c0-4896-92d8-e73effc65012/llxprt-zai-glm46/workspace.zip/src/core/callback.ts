/**
 * Callback closure implementation for reactive side effects.
 */

import { ReactiveNode, getActiveNode, setActiveNode, UpdateFn } from '../types/reactive.js'

export type UnsubscribeFn = () => void

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const node: ReactiveNode<T> = {
    value: value as T,
    dependencies: new Set(),
    dependents: new Set(),
    update: () => {
      if (node.disposed) return
      
      const previous = getActiveNode()
      setActiveNode(node)
      
      try {
        // Clear previous dependencies
        for (const dep of node.dependencies) {
          dep.dependents.delete(node)
        }
        node.dependencies.clear()
        
        // Execute side effect
        node.value = updateFn(node.value)
      } finally {
        setActiveNode(previous)
      }
    },
  }
  
  // Initial execution
  node.update()
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up dependencies
    for (const dependency of node.dependencies) {
      dependency.dependents.delete(node)
    }
    node.dependencies.clear()
    
    // Clean up from any dependents that reference this node
    for (const dependent of node.dependents) {
      dependent.dependencies.delete(node)
    }
    node.dependents.clear()
    
    node.disposed = true
  }
}
