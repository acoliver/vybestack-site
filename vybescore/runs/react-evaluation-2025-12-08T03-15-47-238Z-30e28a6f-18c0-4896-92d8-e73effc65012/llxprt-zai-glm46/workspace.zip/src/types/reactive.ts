/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ReactiveNode<T> {
  value: T
  dependencies: Set<ReactiveNode<unknown>>
  dependents: Set<ReactiveNode<unknown>>
  update: () => void
  disposed?: boolean
}

let activeNode: ReactiveNode<unknown> | undefined

export function getActiveNode(): ReactiveNode<unknown> | undefined {
  return activeNode
}

export function setActiveNode(node: ReactiveNode<unknown> | undefined): void {
  activeNode = node
}

export type ObserverR = {
  name?: string
  disposed?: boolean
  dependents?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR
  dependents?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>
