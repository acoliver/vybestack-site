#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters, supportedFormats } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: Unknown option ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid report data: must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${i} has missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${i} has missing or invalid "amount" field (expected number)`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries as Array<{ label: string; amount: number }>,
  };
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Validate format
  if (!supportedFormats.includes(args.format)) {
    console.error(`Unsupported format: ${args.format}`);
    console.error(`Supported formats: ${supportedFormats.join(', ')}`);
    process.exit(1);
  }

  // Read and parse JSON file
  let rawData: unknown;
  try {
    const content = fs.readFileSync(args.dataFile, 'utf-8');
    rawData = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${args.dataFile}`);
      console.error(`  ${error.message}`);
      process.exit(1);
    }
    const err = error as NodeJS.ErrnoException;
    if (err.code === 'ENOENT') {
      console.error(`Error: File not found: ${args.dataFile}`);
      process.exit(1);
    }
    console.error(`Error reading file ${args.dataFile}: ${error}`);
    process.exit(1);
  }

  // Validate report data
  let reportData: ReportData;
  try {
    reportData = validateReportData(rawData);
  } catch (error) {
    console.error(`${error}`);
    process.exit(1);
  }

  // Render report
  const formatter = formatters[args.format];
  const options: RenderOptions = { includeTotals: args.includeTotals };
  const output = formatter(reportData, options);

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error writing to file ${args.outputPath}: ${error}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
