import { test, expect, describe } from 'vitest';
import { createPaginatedComponent } from '../src/basic-client-pagination.js';
import { testCommonPaginationFeatures } from '../src/common-pagination-tests.js';

describe('basic-client pagination', () => {
  // Setup for tests
  const setupTest = () => {
    const mockData = Array.from({ length: 100 }, (_, i) => ({ id: i, name: `Item ${i}` }));
    const { pagination, refreshContent, navigateToPage } = createPaginatedComponent({
      data: mockData,
      currentPage: 1,
      total: mockData.length,
      visiblePages: 5,
      itemsPerPage: 10,
    });

    return { pagination, refreshContent, navigateToPage };
  };

  // Common pagination tests
  testCommonPaginationFeatures(setupTest, 'basic-client-pagination');

  // Basic client pagination specific tests
  describe('basic client pagination features', () => {
    test('should navigate pages correctly in client mode', async () => {
      const { navigateToPage } = setupTest();
      const updatedContent = await navigateToPage('client', 2);
      
      // Check second page content
      const items = updatedContent.querySelectorAll('.pagination-item');
      expect(items.length).toBe(10);
      expect(items[0].textContent).toContain('Item 10');
    });

    test('should update URL hash on client navigation', async () => {
      const { navigateToPage } = setupTest();
      await navigateToPage('client', 3);
      
      // Wait for microtask to complete
      await new Promise(resolve => setTimeout(resolve, 0));
      
      expect(window.location.hash).toBe('#page=3');
      
      // Clean up
      window.history.replaceState(null, '', window.location.pathname);
    });

    test('should show correct page numbers', async () => {
      const { pagination } = setupTest();
      
      // On page 1 with 5 visible pages, we should see 1 2 3 4 5
      const pageNumbers = pagination.querySelectorAll('.pagination-page-number');
      expect(pageNumbers.length).toBe(5);
      expect(pageNumbers[0].textContent).toBe('1');
      expect(pageNumbers[4].textContent).toBe('5');
      
      // Check that page 1 is current
      const currentPageNumber = pagination.querySelector('.pagination-page-number.current');
      expect(currentPageNumber.textContent).toBe('1');
    });

    test('should navigate to first page correctly', async () => {
      const { navigateToPage } = setupTest();
      
      // Navigate to page 5 first
      const page5Content = await navigateToPage('client', 5);
      const page5Current = page5Content.querySelector('.pagination-page-number.current');
      expect(page5Current.textContent).toBe('5');
      
      // Then navigate to first page
      const firstPageContent = await navigateToPage('client', 1);
      const firstPageCurrent = firstPageContent.querySelector('.pagination-page-number.current');
      expect(firstPageCurrent.textContent).toBe('1');
    });

    test('should show correct number of items per page', async () => {
      const { pagination, navigateToPage } = setupTest();
      
      // Check page count text
      const pageCount = pagination.querySelector('.pagination-page-count');
      expect(pageCount.textContent).toContain('Showing 1-10 of 100 items');
      
      // Navigate to last page (should have fewer items if not divisible by itemsPerPage)
      const lastPageContent = await navigateToPage('client', 10);
      const items = lastPageContent.querySelectorAll('.pagination-item');
      expect(items.length).toBe(10); // 100 items exactly = 10 pages * 10 items
      
      // Check page count text for last page
      const lastPageCount = lastPageContent.querySelector('.pagination-page-count');
      expect(lastPageCount.textContent).toContain('Showing 91-100 of 100 items');
    });

    test('should handle navigation elements correctly', async () => {
      const { pagination } = setupTest();
      
      // First page - prev should be disabled, next should be enabled
      const prevButton = pagination.querySelector('.pagination-prev');
      const nextButton = pagination.querySelector('.pagination-next');
      const firstButton = pagination.querySelector('.pagination-first');
      const lastButton = pagination.querySelector('.pagination-last');
      
      expect(prevButton.classList.contains('disabled')).toBe(false);
      expect(nextButton.classList.contains('disabled')).toBe(false);
      expect(firstButton.classList.contains('disabled')).toBe(false);
      expect(lastButton.classList.contains('disabled')).toBe(false);
    });
  });

  // Navigation tests
  describe('navigation', () => {
    test('should navigate correctly with page click', async () => {
      const { pagination, refreshContent } = setupTest();
      
      const page2Button = pagination.querySelectorAll('.pagination-page-number')[1];
      expect(page2Button.textContent).toBe('2');
      
      // Simulate click
      const mockEvent = new MouseEvent('click');
      const preventDefault = jest.fn();
      mockEvent.preventDefault = preventDefault;
      
      page2Button.dispatchEvent(mockEvent);
      
      // Wait for update
      await new Promise(resolve => setTimeout(resolve, 0));
      
      // Check that navigation occurred
      const updatedContent = refreshContent();
      const currentPage = updatedContent.querySelector('.pagination-page-number.current');
      expect(currentPage.textContent).toBe('2');
    });

    test('should update correctly with custom configuration', async () => {
      const mockData = Array.from({ length: 75 }, (_, i) => ({ id: i, name: `Item ${i}` }));
      const { pagination } = createPaginatedComponent({
        data: mockData,
        currentPage: 3,
        total: mockData.length,
        visiblePages: 3,
        itemsPerPage: 5,
      });
      
      // Should be on page 3
      const currentPage = pagination.querySelector('.pagination-page-number.current');
      expect(currentPage.textContent).toBe('3');
      
      // Should have 3 visible pages
      const pageNumbers = pagination.querySelectorAll('.pagination-page-number');
      expect(pageNumbers.length).toBe(3);
      
      // Check page count with custom items per page
      const pageCount = pagination.querySelector('.pagination-page-count');
      expect(pageCount.textContent).toContain('Showing 11-15 of 75 items');
    });
  });
});