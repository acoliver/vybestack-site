import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import { createRequest, createResponse } from 'node-mocks-http';
import { PaginationHandler } from '../../src/servers/pagination-handler';

describe('PaginationHandler', () => {
  let handler: PaginationHandler;

  beforeEach(() => {
    handler = new PaginationHandler();
  });

  afterEach(() => {
    handler.cleanup();
  });

  describe('request parsing', () => {
    it('should parse page and limit from query params', () => {
      const req = createRequest({
        method: 'GET',
        url: '/api/posts?page=2&limit=20'
      });
      const res = createResponse();

      handler.handleRequest(req, res);
      
      expect(res.locals.pagination).toBeDefined();
      expect(res.locals.pagination.page).toBe(2);
      expect(res.locals.pagination.limit).toBe(20);
    });

    it('should use default pagination when no params provided', () => {
      const req = createRequest({
        method: 'GET',
        url: '/api/posts'
      });
      const res = createResponse();

      handler.handleRequest(req, res);
      
      expect(res.locals.pagination).toBeDefined();
      expect(res.locals.pagination.page).toBe(1);
      expect(res.locals.pagination.limit).toBe(10);
    });

    it('should handle cursor-based pagination', () => {
      const req = createRequest({
        method: 'GET',
        url: '/api/posts?cursor=abc123&limit=15'
      });
      const res = createResponse();

      handler.handleRequest(req, res);
      
      expect(res.locals.pagination).toBeDefined();
      expect(res.locals.pagination.cursor).toBe('abc123');
      expect(res.locals.pagination.limit).toBe(15);
    });
  });
});