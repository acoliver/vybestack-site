// 添加性能测试
import { performance } from 'perf_hooks';

export function measurePaginationPerformance<T>(
  pageNumber: number,
  pageSize: number,
  totalItems: number,
  expectedItems: T[]
): Promise<{ responseTime: number; memoryUsage: number }> {
  return new Promise((resolve) => {
    const startTime = performance.now();
    
    // Simulate paginated processing
    const processedItems = paginatePage(expectedItems, pageNumber, pageSize);
    
    const endTime = performance.now();
    const responseTime = endTime - startTime;
    
    // Simulate memory usage calculation
    const memoryUsage = process.memoryUsage().heapUsed;
    
    resolve({
      responseTime,
      memoryUsage
    });
  });
}

export function validatePaginationPerformance(
  responseTime: number,
  memoryUsage: number,
  maxResponseTime: number = 100,
  maxMemoryUsage: number = 50000000
): boolean {
  return responseTime < maxResponseTime && memoryUsage < maxMemoryUsage;
}