# Pagination Integration Guide

## Overview

This guide explains how to integrate the pagination system into your VybeStack application.

## Quick Start

### 1. Install Dependencies

```bash
# If using PostgreSQL
npm install pg pg-pool2

# If using MongoDB
npm install mongodb
```

### 2. Configure Environment

```env
# PostgreSQL (optional)
PG_HOST=localhost
PG_PORT=5432
PG_USER=postgres
PG_PASSWORD=password
PG_DATABASE=vybestack

# Pagination Configuration
PAGINATION_DEFAULT_PAGE_SIZE=20
PAGINATION_MAX_PAGE_SIZE=100
```

### 3. Basic Usage

```typescript
import { usePagination, PaginatedResult } from '@/lib/pagination';

// In a React component
function MyComponent() {
  const { data, isLoading, currentPage, totalPages, nextPage, prevPage } = 
    usePagination<User>('/api/users', { pageSize: 10 });

  return (
    <div>
      {/* Render data */}
      {data?.items.map(item => <div key={item.id}>{item.name}</div>)}
      
      {/* Render pagination controls */}
      <div className="pagination">
        <button onClick={prevPage} disabled={currentPage === 1}>
          Previous
        </button>
        <span>{currentPage} of {totalPages}</span>
        <button onClick={nextPage} disabled={currentPage === totalPages}>
          Next
        </button>
      </div>
    </div>
  );
}
```

## Advanced Usage

### Custom Data Sources

#### REST API

```typescript
import { createRestDataSource } from '@/lib/pagination/data-sources';

const dataSource = createRestDataSource('/api/users');
const result = await dataSource.fetchPage(1, 20, { search: 'john' });
```

#### PostgreSQL

```typescript
import { PostgresDataSource, createPgPool } from '@/lib/pagination/data-sources';

const pool = createPgPool();
const dataSource = new PostgresDataSource(pool, 'users', ['name', 'email']);
const result = await dataSource.fetchPage(1, 20, { name: 'John' });
```

#### Mongo DB

```typescript
import { MongoDataSource, createMongoClient } from '@/lib/pagination/data-sources';

const client = createMongoClient();
const dataSource = new MongoDataSource(client, 'mydb', 'users');
const result = await dataSource.fetchPage(1, 20, { name: 'John' });
```

### Custom Filters

```typescript
// Define custom filters
interface UserFilters {
  name?: string;
  email?: string;
  role?: string;
}

// Use with pagination hook
const { data, currentPage, setFilters } = usePagination<User, UserFilters>(
  '/api/users',
  { pageSize: 10 }
);

// Update filters
setFilters({ name: 'john', role: 'admin' });
```

### Server-Side Usage

```typescript
import { PaginatedResult } from '@/lib/pagination/types';
import { NextApiRequest, NextApiResponse } from 'next';

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse<PaginatedResult<User>>
) {
  const { query, page = 1, pageSize = 10 } = parsePaginationParams(req.query);

  try {
    const result = await paginatedRoute(handler, { query: query });
    res.status(200).json(result);
  } catch (error) {
    res.status(500).json({ 
      status: 'error',
      message: 'Internal server error'
    });
  }
}
```

## Configuration

The pagination system can be customized via environment variables or configuration objects:

```typescript
import { config } from '@/lib/pagination';

// Update via environment
process.env.PAGINATION_MAX_PAGE_SIZE = '50';

// Update via code
config.defaultPageSize = 15;
config.maxPageSize = 50;
config.defaultSortOrder = 'asc';
```

## Architecture

The pagination system consists of several key components:

- **Core Types**: TypeScript interfaces for type safety
- **Data Sources**: Pluggable components for different data backends
- **Custom Hooks**: React hooks for easy integration
- **API Routes**: Ready-to-use Next.js API route handlers
- **Test Utilities**: Testing helpers for component and route tests
- **UI Components**: Accessible pagination controls

For detailed architecture information, see the [Architecture Documentation](./architecture.md).

## Contributing

To contribute to the pagination system:

1. Run `npm run test:coverage` to ensure all tests pass
2. Add tests for new features
3. Update documentation as needed
4. Use TypeScript for all development

## Testing

Run the full test suite:

```bash
npm run test:coverage
```

For specific test types:

```bash
npm run test:unit         # Core types and utilities
npm run test:integration  # Data sources
npm run test:e2e          # Components and API routes
```

## Support

For issues or questions:

1. Check the [API documentation](./docs/api-documentation.md)
2. Review the [troubleshooting guide](./docs/troubleshooting.md)
3. Open an issue in the VybeStack repository