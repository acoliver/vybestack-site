// Type definitions for the report data model

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface RenderOptions {
  includeTotals: boolean;
}

export interface Formatter {
  render: (data: ReportData, options: RenderOptions) => string;
}