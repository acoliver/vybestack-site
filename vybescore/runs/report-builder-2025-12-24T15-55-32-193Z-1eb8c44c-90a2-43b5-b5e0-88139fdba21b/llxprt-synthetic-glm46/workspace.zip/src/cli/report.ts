#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { join } from 'node:path';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map format names to render functions
const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

type Format = keyof typeof formatters;

interface CliArgs {
  dataPath: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: Partial<CliArgs> = {
    dataPath: args[0],
    includeTotals: false,
  };
  
  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg === '--format' && i + 1 < args.length) {
      const format = args[i + 1] as Format;
      if (!(format in formatters)) {
        console.error(`Error: Unsupported format: ${format}`);
        process.exit(1);
      }
      result.format = format;
      i++; // Skip next argument as we've consumed it
    } else if (arg === '--output' && i + 1 < args.length) {
      result.outputPath = args[i + 1];
      i++; // Skip next argument as we've consumed it
    }
  }
  
  if (!result.format) {
    console.error('Error: --format argument is required');
    console.error('Supported formats:', Object.keys(formatters).join(', '));
    process.exit(1);
  }
  
  return result as CliArgs;
}

function readJsonFile(path: string): unknown {
  try {
    const content = readFileSync(path, 'utf8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file: ${path}`);
      console.error('Please check that the file contains valid JSON');
    } else {
      console.error(`Error reading file: ${path}`);
      console.error(error);
    }
    process.exit(1);
  }
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    console.error('Error: Invalid data: not an object');
    console.error('Expected format: { "title": "", "summary": "", "entries": [] }');
    process.exit(1);
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string' || obj.title.trim() === '') {
    console.error('Error: "title" is required and must be a non-empty string');
    process.exit(1);
  }
  
  if (typeof obj.summary !== 'string') {
    console.error('Error: "summary" is required and must be a string');
    process.exit(1);
  }
  
  if (!Array.isArray(obj.entries)) {
    console.error('Error: "entries" is required and must be an array');
    process.exit(1);
  }
  
  obj.entries.forEach((entry: unknown, index: number) => {
    if (!entry || typeof entry !== 'object') {
      console.error(`Error: entry at index ${index} is not an object`);
      process.exit(1);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string' || entryObj.label.trim() === '') {
      console.error(`Error: entry at index ${index} has invalid or missing "label"`);
      process.exit(1);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      console.error(`Error: entry at index ${index} has invalid or missing "amount"`);
      process.exit(1);
    }
  });
}

async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArguments();
    
    // Read and validate the input JSON file
    const rawData = readJsonFile(dataPath);
    validateReportData(rawData);
    const reportData: ReportData = rawData;
    
    // Render the report
    const options: RenderOptions = { includeTotals };
    const formatter = formatters[format];
    const output = formatter(reportData, options);
    
    // Write output
    if (outputPath) {
      const outputPathAbsolute = outputPath.startsWith('/') ? outputPath : join(process.cwd(), outputPath);
      try {
        await import('node:fs/promises').then(fs => fs.writeFile(outputPathAbsolute, output));
        console.log(`Report written to: ${outputPathAbsolute}`);
      } catch (error) {
        console.error(`Error writing to file: ${outputPath}`);
        console.error(error);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error: unknown) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else if (typeof error === 'string') {
      console.error(`Error: ${error}`);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
