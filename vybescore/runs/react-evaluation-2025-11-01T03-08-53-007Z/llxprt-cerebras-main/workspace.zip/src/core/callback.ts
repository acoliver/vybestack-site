/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create the observer instance
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track dependencies by running updateFn within active observer context
  const previousObserver = getActiveObserver()
  updateObserver(observer)
  
  // Flag for tracking if callback is disposed
  let disposed = false
  
  // Return unsubscribe function
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies to prevent memory leaks
    if (observer.dependencies) {
      observer.dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}