/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine the equality function
  let actualEqualFn: EqualFn<T> | undefined;
  if (typeof equal === 'function') {
    actualEqualFn = equal;
  } else if (equal === true) {
    actualEqualFn = Object.is;
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    equalFn: actualEqualFn
  }

  // Track dependencies by running updateFn within active observer context
  const previousObserver = getActiveObserver()
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Add current observer to the dependencies list
      if (!o.dependencies) o.dependencies = new Set()
      o.dependencies.add(currentObserver)
    }
    return o.value!
  }

  return read
}