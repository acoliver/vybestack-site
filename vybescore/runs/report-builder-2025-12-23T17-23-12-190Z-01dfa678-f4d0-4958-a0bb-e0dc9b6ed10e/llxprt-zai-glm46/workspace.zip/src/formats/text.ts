/**
 * Plain text formatter for report data.
 */

import type { Formatter } from '../types.js';

const formatAmount = (amount: number): string => `$${amount.toFixed(2)}`;

export const renderText: Formatter = (data, options) => {
  const lines: string[] = [];

  lines.push(data.title);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('Entries:');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    lines.push('');
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
