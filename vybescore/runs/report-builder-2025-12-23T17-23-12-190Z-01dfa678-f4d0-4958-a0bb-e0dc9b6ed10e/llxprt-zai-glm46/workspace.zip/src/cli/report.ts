#!/usr/bin/env node

/**
 * Report Builder CLI
 * Renders reports from JSON input in various formats.
 */

import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { getFormatter, isSupportedFormat } from '../formatters.js';
import type { Format, ReportData } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const parsed: CliArgs = {
    inputFile: '',
    format: 'markdown',
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    switch (arg) {
      case '--format': {
        i++;
        if (i >= args.length) {
          throw new Error('--format requires a value');
        }
        const formatValue = args[i];
        if (!isSupportedFormat(formatValue)) {
          throw new Error(`Unsupported format: ${formatValue}`);
        }
        parsed.format = formatValue as Format;
        break;
      }

      case '--output': {
        i++;
        if (i >= args.length) {
          throw new Error('--output requires a value');
        }
        parsed.outputPath = args[i];
        break;
      }

      case '--includeTotals':
        parsed.includeTotals = true;
        break;

      default:
        if (arg.startsWith('--')) {
          throw new Error(`Unknown option: ${arg}`);
        }
        if (parsed.inputFile) {
          throw new Error(`Unexpected argument: ${arg}`);
        }
        parsed.inputFile = arg;
        break;
    }

    i++;
  }

  if (!parsed.inputFile) {
    throw new Error('Input file path is required');
  }

  return parsed;
}

async function readJsonFile(filePath: string): Promise<unknown> {
  const absolutePath = path.resolve(filePath);
  const content = await fs.readFile(absolutePath, 'utf-8');
  try {
    return JSON.parse(content);
  } catch {
    throw new Error(`Failed to parse JSON from ${filePath}`);
  }
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid report data: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error(
      'Invalid report data: missing or invalid "summary" field (expected string)'
    );
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

async function main(): Promise<void> {
  try {
    const args = parseArgs(process.argv.slice(2));

    const jsonData = await readJsonFile(args.inputFile);
    const reportData = validateReportData(jsonData);

    const formatter = getFormatter(args.format);
    const output = formatter(reportData, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      await fs.writeFile(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
