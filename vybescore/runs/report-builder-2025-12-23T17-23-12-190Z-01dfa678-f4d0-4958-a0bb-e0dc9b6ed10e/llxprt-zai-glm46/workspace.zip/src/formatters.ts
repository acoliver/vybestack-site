/**
 * Formatter registry mapping format names to their render functions.
 */

import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';
import type { Format, Formatter } from './types.js';

const formatters: Record<Format, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getFormatter(format: Format): Formatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

export function isSupportedFormat(format: string): format is Format {
  return Object.prototype.hasOwnProperty.call(formatters, format);
}
