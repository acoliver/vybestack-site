/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Reactive dependency tracking system
interface Dependency {
  track(): void
  invalidate(): void
}

interface Subscriber {
  invalidate(): void
}

let currentSubscriber: Subscriber | undefined = undefined

export function getCurrentSubscriber(): Subscriber | undefined {
  return currentSubscriber
}

export function runWithSubscriber<T>(subscriber: Subscriber, fn: () => T): T {
  const prev = currentSubscriber
  currentSubscriber = subscriber
  try {
    return fn()
  } finally {
    currentSubscriber = prev
  }
}

export class Signal<T> implements Dependency {
  private value: T
  private equalFn?: EqualFn<T>
  private subscribers = new Set<Subscriber>()
  
  constructor(value: T, equalFn?: EqualFn<T>) {
    this.value = value
    this.equalFn = equalFn
  }
  
  get(): T {
    this.track()
    return this.value
  }
  
  set(newValue: T): void {
    if (!this.equalFn || !this.equalFn(this.value, newValue)) {
      this.value = newValue
      this.invalidate()
    }
  }
  
  track(): void {
    const subscriber = getCurrentSubscriber()
    if (subscriber) {
      this.subscribers.add(subscriber)
    }
  }
  
  invalidate(): void {
    const subs = Array.from(this.subscribers)
    for (const sub of subs) {
      sub.invalidate()
    }
  }
}

export class Computed<T> implements Dependency, Subscriber {
  private value?: T
  private dirty = true
  private dependencies = new Set<Dependency>()
  private subscribers = new Set<Subscriber>()
  
  constructor(private computeFn: () => T, private initialValue?: T) {
    this.value = initialValue
  }
  
  get(): T {
    this.track()
    if (this.dirty) {
      this.recompute()
    }
    return this.value!
  }
  
  track(): void {
    const subscriber = getCurrentSubscriber()
    if (subscriber) {
      this.subscribers.add(subscriber)
    }
  }
  
  invalidate(): void {
    if (!this.dirty) {
      this.dirty = true
      const subs = Array.from(this.subscribers)
      for (const sub of subs) {
        sub.invalidate()
      }
    }
  }
  
  private recompute(): void {
    const oldDeps = this.dependencies
    this.dependencies = new Set()
    
    runWithSubscriber(this, () => {
      this.value = this.computeFn()
      this.dirty = false
    })
    
    // Clean up old dependencies
    for (const dep of oldDeps) {
      if (!this.dependencies.has(dep)) {
        if ('unsubscribe' in dep && typeof dep.unsubscribe === 'function') {
          dep.unsubscribe(this)
        }
      }
    }
  }
}

export class Effect implements Subscriber {
  private disposed = false
  private dependencies = new Set<Dependency>()
  
  constructor(private effectFn: () => void) {
    this.run()
  }
  
  run(): void {
    if (this.disposed) return
    
    const oldDeps = this.dependencies
    this.dependencies = new Set()
    
    runWithSubscriber(this, () => {
      this.effectFn()
    })
    
    // Clean up old dependencies
    for (const dep of oldDeps) {
      if (!this.dependencies.has(dep)) {
        if ('unsubscribe' in dep && typeof dep.unsubscribe === 'function') {
          dep.unsubscribe(this)
        }
      }
    }
  }
  
  invalidate(): void {
    if (!this.disposed) {
      this.run()
    }
  }
  
  dispose(): void {
    if (!this.disposed) {
      this.disposed = true
      for (const dep of this.dependencies) {
        if ('unsubscribe' in dep && typeof dep.unsubscribe === 'function') {
          dep.unsubscribe(this)
        }
      }
      this.dependencies.clear()
    }
  }
}