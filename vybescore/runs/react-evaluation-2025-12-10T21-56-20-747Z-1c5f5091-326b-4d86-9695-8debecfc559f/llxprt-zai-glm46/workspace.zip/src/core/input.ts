/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Signal
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : undefined
  const signal = new Signal(value, equalFn)

  const read: GetterFn<T> = () => signal.get()
  const write: SetterFn<T> = (nextValue) => {
    signal.set(nextValue)
    return signal.get()
  }

  return [read, write]
}