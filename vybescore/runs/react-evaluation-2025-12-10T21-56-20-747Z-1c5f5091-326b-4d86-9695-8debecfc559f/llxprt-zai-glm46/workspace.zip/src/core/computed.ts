/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Computed
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  // Convert UpdateFn to a pure compute function
  const computeFn = () => updateFn()
  const computed = new Computed(computeFn, value)
  
  return (): T => computed.get()
}