/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  Effect
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  // Convert UpdateFn to an effect function
  const effectFn = () => {
    updateFn()
  }
  const effect = new Effect(effectFn)
  
  return () => effect.dispose()
}