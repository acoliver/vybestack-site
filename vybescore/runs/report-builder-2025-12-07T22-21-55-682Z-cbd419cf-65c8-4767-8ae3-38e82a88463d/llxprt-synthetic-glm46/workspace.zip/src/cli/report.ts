#!/usr/bin/env node

import { promises as fs } from 'node:fs';
import type { Report, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions extends ReportOptions {
  format: string;
  output?: string;
  inputFile: string;
}

function parseArguments(args: string[]): CliOptions {
  if (args.length < 4) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  const format = args[formatIndex + 1];
  const includeTotalsIndex = args.indexOf('--includeTotals');
  const outputIndex = args.indexOf('--output');

  const options: CliOptions = {
    inputFile,
    format,
    includeTotals: includeTotalsIndex !== -1,
  };

  if (outputIndex !== -1 && outputIndex < args.length - 1) {
    options.output = args[outputIndex + 1];
  }

  return options;
}

async function loadReport(filePath: string): Promise<Report> {
  try {
    const content = await fs.readFile(filePath, 'utf8');
    const data = JSON.parse(content) as unknown;

    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected an object');
    }

    const report = data as Partial<Report>;

    if (!report.title || typeof report.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }

    if (!report.summary || typeof report.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }

    if (!Array.isArray(report.entries)) {
      throw new Error('Missing or invalid entries field');
    }

    for (const entry of report.entries) {
      if (!entry || typeof entry !== 'object') {
        throw new Error('Invalid entry: expected an object');
      }
      
      if (!('label' in entry) || typeof entry.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid label field');
      }
      
      if (!('amount' in entry) || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid amount field');
      }
    }

    return report as Report;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}`);
    }
    throw error;
  }
}

function renderReport(report: Report, format: string, options: ReportOptions): string {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown(report, options);
    case 'text':
      return renderText(report, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

async function main(): Promise<void> {
  try {
    const options = parseArguments(process.argv);
    const report = await loadReport(options.inputFile);
    const output = renderReport(report, options.format, options);

    if (options.output) {
      await fs.writeFile(options.output, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exit(1);
});