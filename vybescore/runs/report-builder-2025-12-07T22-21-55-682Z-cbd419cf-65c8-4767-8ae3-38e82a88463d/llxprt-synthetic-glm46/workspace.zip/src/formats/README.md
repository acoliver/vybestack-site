# Report Formats

This directory contains the format renderers used by the report CLI tool.

## Structure

Each format is a separate TypeScript module that exports a renderer function.

## Adding New Formats

To add a new format:

1. Create a new file (e.g., `newformat.ts`)
2. Export a renderer function that matches the `ReportRenderer` interface defined in `../types.ts`
3. Import and register the renderer in the formatters object in `../cli/report.ts`

## Interface

The renderer function should have the following signature:

```typescript
export const renderNewFormat: ReportRenderer = (
  data: ReportData,
  options: ReportOptions
): string => {
  // Implementation here
};
```

Where:
- `ReportData` contains the title, summary, and entries
- `ReportOptions` contains flags like `includeTotals`
- The function returns a string with the formatted output

## Implementation Guidelines

- Amounts should be formatted with two decimal places using `amount.toFixed(2)`
- Include headings and formatting appropriate for the target format
- Support the `includeTotals` option by calculating and displaying the total when enabled
- Maintain consistent spacing and line breaks for readability

## Existing Formats

- `markdown.ts`: Renders reports in Markdown format with headings and bold labels
- `text.ts`: Renders reports in plain text format with simple labels
