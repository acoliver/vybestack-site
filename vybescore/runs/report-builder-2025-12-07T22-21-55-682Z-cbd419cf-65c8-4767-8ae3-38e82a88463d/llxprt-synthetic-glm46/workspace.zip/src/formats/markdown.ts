import type { Report, ReportFormatter, ReportOptions } from '../types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: Report['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderMarkdown: ReportFormatter = (report: Report, options: ReportOptions = {}) => {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${report.title}`);
  lines.push('');
  
  // Summary
  lines.push(report.summary);
  lines.push('');
  
  // Entries heading
  lines.push('## Entries');
  
  // Entries list
  for (const entry of report.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  // Total if requested
  if (options.includeTotals && report.entries.length > 0) {
    const total = calculateTotal(report.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
};