export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant-ish email validation
  // Local part: letters, digits, and special characters !#$%&'*+/=?^_`{|}~-
  // Allows +tag format but restricts problematic patterns
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }

  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // Reject trailing dot in local or domain part
  if (value.endsWith('.')) {
    return false;
  }

  // Reject domain with underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }

  // Ensure TLD is at least 2 chars and doesn't start/end with hyphen
  const parts = domainPart?.split('.');
  const tld = parts?.[parts.length - 1];
  if (!tld || tld.length < 2 || tld.startsWith('-') || tld.endsWith('-')) {
    return false;
  }

  // Ensure local part doesn't start or end with dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + prefix
  const cleaned = value.replace(/[^\d+]/g, '');

  // Handle optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('+')) {
    // Invalid country code
    return false;
  }

  // Must be exactly 10 digits for US numbers
  if (digits.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Validate format: matches common US phone patterns
  const formatRegex = /^(?:\+1[\s-]?)?\(?(\d{3})\)?[\s-]?(\d{3})[\s-]?(\d{4})$/;
  if (!formatRegex.test(value.trim())) {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles such as:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, keep track of structure
  const normalized = value.replace(/[\s-]/g, '');

  // Match pattern with optional +54, optional 0 trunk, optional 9 mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentineRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = normalized.match(argentineRegex);
  if (!match) {
    return false;
  }

  const [, areaCode, subscriberNumber] = match;

  // Area code must be 2-4 digits (already enforced by regex)
  // Subscriber must be 6-8 digits (already enforced by regex)

  // If country code is omitted, must have trunk prefix 0
  const hasCountryCode = normalized.startsWith('+54');
  const hasTrunkPrefix = normalized.startsWith('0') && !normalized.startsWith('+54');

  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  // Total length checks
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Allow: unicode letters (including accents), apostrophes, hyphens, spaces
  // Reject: digits, special symbols (except allowed ones)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Reject names that are only spaces, hyphens, or apostrophes
  const trimmed = value.trim();
  if (!/^[\p{L}\p{M}]/u.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * Luhn algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check card type prefixes and lengths
  const patterns = [
    // Visa: starts with 4, length 13-16
    { regex: /^4\d{12}(\d{3})?$/, type: 'visa' },
    // Mastercard: starts with 51-55 or 2221-2720, length 16
    { regex: /^(5[1-5]\d{14}|2[2-7]\d{14})$/, type: 'mastercard' },
    // American Express: starts with 34 or 37, length 15
    { regex: /^3[47]\d{13}$/, type: 'amex' },
  ];

  const isValidFormat = patterns.some((pattern) => pattern.regex.test(cleaned));

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
