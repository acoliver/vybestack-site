/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences, collapse extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Split into sentences using regex that matches sentence endings
  // This keeps the delimiters for us to process
  const sentencePattern = /[^.!?]*[.!?]+/g;
  const sentences = text.match(sentencePattern) || [];

  // Process each sentence
  const processed = sentences.map((sentence) => {
    // Trim and capitalize first letter
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return '';

    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
  });

  // Join with single space
  let result = processed.join(' ');

  // Handle any remaining text after the last sentence
  const lastSentenceEnd = sentences.length > 0 ? sentences.join('').length : 0;
  const remaining = text.slice(lastSentenceEnd).trim();
  if (remaining.length > 0) {
    result += ' ' + remaining.charAt(0).toUpperCase() + remaining.slice(1);
  }

  // Clean up: ensure single spaces
  result = result.replace(/ +/g, ' ').trim();

  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. without protocol
  // Excludes trailing punctuation like .,;:)
  const urlPattern = /https?:\/\/[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,;:!?]|www\.[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,;:!?]/gi;

  const matches = text.match(urlPattern) || [];

  // Remove any trailing punctuation that might have been caught
  const cleaned = matches.map((url) => url.replace(/[.,;:!?]+$/, ''));

  return cleaned;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // We'll handle the scheme upgrade and docs path rewriting
  return text.replace(/http:\/\/example\.com(\/[^\s<>"{}|\\^`[\]]*)/gi, (match, path) => {
    // Always upgrade to https
    const securePath = 'https://example.com' + path;

    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should skip host rewrite
      const skipHostRewrite =
        path.includes('cgi-bin') ||
        path.includes('?') ||
        path.includes('&') ||
        path.includes('=') ||
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/.test(path);

      if (!skipHostRewrite) {
        return 'https://docs.example.com' + path;
      }
    }

    return securePath;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Feb includes leap year possibility
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  // For February, check actual leap year
  if (month === 2 && day === 29) {
    const year = parseInt(yearStr, 10);
    const isLeap = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    if (!isLeap) {
      return 'N/A';
    }
  }

  return yearStr;
}
