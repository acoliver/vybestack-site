/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match words starting with prefix
  // Word boundary \b ensures we match whole words
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions and return unique values
  const exceptionsLower = exceptions.map((e) => e.toLowerCase());
  const found = matches
    .map((m) => m.toLowerCase())
    .filter((word) => !exceptionsLower.includes(word))
    .filter((word, index, self) => self.indexOf(word) === index);

  return found;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use positive lookbehind to match token only when preceded by a digit
  // Return the full match including the digit prefix
  const pattern = new RegExp(`\\d${escapedToken}(?!\\d)`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase
 * - One lowercase
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) {
    return false;
  }

  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Must have at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must have at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must have at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (like abab, 123123, abcabc)
  // This catches patterns of 2+ characters that repeat immediately
  for (let i = 0; i < value.length - 3; i++) {
    for (let len = 2; len <= (value.length - i) / 2; len++) {
      const pattern = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + len * 2);

      if (pattern === nextSequence) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns:
  // 1. Full form: 8 groups of 1-4 hex digits separated by colons
  // 2. Compressed form with :: (double colon) for consecutive zero groups
  // 3. IPv4 embedded (e.g., ::ffff:192.168.1.1)

  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // IPv6 pattern - comprehensive matching including shorthand
  // Match:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed: 2001:db8::1
  // - Loopback: ::1
  // - All zeros: ::
  // - With embedded IPv4: ::ffff:192.168.1.1

  // Simpler approach: match IPv6 anywhere in the string
  // Look for patterns that are characteristic of IPv6
  const hasIPv6 = /(?:^|[\s[\]])([0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}(?:$|[\s[\]])/.test(value);

  // Also check for :: shorthand
  const hasShorthand = /::/.test(value);

  // Make sure it's not just random colons - must have hex digits around them
  if (hasIPv6 || hasShorthand) {
    // More specific check: extract potential IPv6 and validate
    const potentialIPv6 = value.match(/([0-9a-fA-F:]+)/g);

    if (potentialIPv6) {
      for (const candidate of potentialIPv6) {
        // Check if this looks like IPv6 (contains colons, not too many consecutive)
        if (candidate.includes(':') && !candidate.includes(':::')) {
          // Count colons - should be between 2 and 7 for valid IPv6
          const colonCount = (candidate.match(/:/g) || []).length;

          // Must have at least 2 colons and at least some hex digits
          if (colonCount >= 2 && colonCount <= 7 && /[0-9a-fA-F]/.test(candidate)) {
            // Additional check: ensure it's not malformed
            // Valid IPv6 has groups separated by colons
            const groups = candidate.split(':');

            // If using ::, it can represent multiple zero groups
            const hasDoubleColon = candidate.includes('::');

            // Valid if:
            // - No more than 8 groups total
            // - If :: present, groups can be fewer
            // - Each group (except possibly empty ones from ::) is 1-4 hex digits
            let validGroups = true;

            for (const group of groups) {
              if (group === '' && !hasDoubleColon) {
                validGroups = false;
                break;
              }

              if (group !== '' && group.length > 4) {
                validGroups = false;
                break;
              }

              if (group !== '' && !/^[0-9a-fA-F]+$/.test(group)) {
                validGroups = false;
                break;
              }
            }

            if (validGroups && groups.length <= 8) {
              return true;
            }
          }
        }
      }
    }
  }

  return false;
}
