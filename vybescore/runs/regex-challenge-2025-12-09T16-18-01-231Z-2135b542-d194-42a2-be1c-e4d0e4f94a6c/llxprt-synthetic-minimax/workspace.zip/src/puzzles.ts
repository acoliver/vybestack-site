/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words starting with prefix, excluding exceptions
  // Create regex pattern with prefix, capturing whole words
  const wordBoundary = '\\b';
  const pattern = new RegExp(wordBoundary + prefix + '[a-zA-Z]*' + wordBoundary, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at the start of string
  // Use pattern that captures digit followed by token
  const pattern = new RegExp(`(?<!^)(\\d)${token}`, 'g');
  return text.match(pattern) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check all requirements:
  // - At least 10 characters
  // - One uppercase, one lowercase, one digit, one symbol
  // - No whitespace
  // - No immediate repeated sequences (e.g., abab should fail)
  
  // Length check
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Character type requirements
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // Look for any 2-character sequence that repeats immediately
  const repeatPattern = /(..)\1/;
  if (repeatPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses don't trigger
  // IPv6 patterns:
  // 1. Standard IPv6: 8 groups of 1-4 hex digits separated by colons
  // 2. Compressed IPv6: uses :: to represent consecutive zero groups
  // 3. IPv4-mapped IPv6: ::ffff: followed by IPv4
  
  // First, check if this looks like an IPv4 address to exclude it
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns - test if they exist anywhere in the string
  const ipv6Patterns = [
    // Full IPv6: 8 groups of hex digits
    /(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}/i,
    // IPv6 with :: compression
    /([a-f0-9]{1,4}:)*::([a-f0-9]{1,4}:)*[a-f0-9]{1,4}/i,
    /([a-f0-9]{1,4}:)*::([a-f0-9]{1,4}:)*/i,
    /::([a-f0-9]{1,4}:)*[a-f0-9]{1,4}/i,
    /([a-f0-9]{1,4}:)*[a-f0-9]{1,4}::/i,
    // IPv4-mapped IPv6
    /::ffff:[a-f0-9:.]+/i,
  ];
  
  return ipv6Patterns.some(pattern => pattern.test(value));
}
