/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first character after sentence endings (.?!)
  // Insert exactly one space between sentences
  // Collapse extra spaces while preserving abbreviations
  
  return text
    // Replace periods, question marks, exclamation marks with sentence endings followed by space
    .replace(/([.?!])(\s*)([^\s])/g, (match, punctuation, spaces, nextChar) => {
      // Capitalize the next character
      return punctuation + ' ' + nextChar.toUpperCase();
    })
    // Handle multiple sentences in a row (multiple punctuation marks)
    .replace(/([.?!])\s*([.?!])/g, '$1 $2')
    // Clean up multiple spaces before the first sentence
    .replace(/^\s+/, '')
    // Capitalize the first character of the entire text
    .replace(/^([a-z])/, (match, firstChar) => firstChar.toUpperCase());
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Extract URLs without trailing punctuation - use \S+ to match non-whitespace
  const urlRegex = /https?:\/\/\S+/g;
  return text.match(urlRegex) || [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Find http:// URLs and rewrite them according to the rules
  // Use new RegExp to avoid escaping issues
  const regex = new RegExp('http://([^/\\s]+)([^\\s]*)', 'g');
  return text.replace(regex, (match, host, path) => {
    // Check if path contains dynamic hints that should skip host rewrite
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    // Always upgrade to https
    let newUrl = `https://${host}`;
    
    // If path starts with /docs/ and has no dynamic hints, rewrite host to docs.host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      newUrl = `https://docs.${host}${path}`;
    } else {
      newUrl += path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract year from mm/dd/yyyy format. Return N/A if format is invalid.
 */
export function extractYear(value: string): string {
  // Use new RegExp to avoid escaping issues
  const dateRegex = new RegExp('(\\d{1,2})/(\\d{1,2})/(\\d{4})');
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Basic validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return match[3];
}