export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that handles most common cases
  // Allows: letters, numbers, dots, underscores, percent, plus, hyphens in local part
  // Allows: letters, numbers, hyphens in domain part, but no underscores
  // Requires at least one dot in domain and validates no trailing dots or double dots
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to check length
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have 10 digits (11 if starts with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, first must be 1
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract the 10-digit number (remove country code if present)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check central office code (next 3 digits) - cannot start with 0 or 1
  const centralOfficeCode = phoneNumber.slice(3, 6);
  if (centralOfficeCode.startsWith('0') || centralOfficeCode.startsWith('1')) {
    return false;
  }
  
  // Now validate the original format matches common US patterns
  const phoneRegex = /^\+?1?[\s.-]?\(?([2-9][0-8][0-9])\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens to validate the structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phones:
  // Optional +54, optional 9, optional 0, then 2-4 digit area code, then 6-8 digit subscriber
  const pattern = /^(?:\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code validation: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Must have either country code (+54) or trunk prefix (0)
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Validate names allowing unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and unusual patterns like "X Æ A-12"
  
  // Check for digits - names should not contain numbers
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for unusual symbols - allow only letters, spaces, apostrophes, hyphens
  // Unicode property escapes for letters (including accents)
  const validNameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  return validNameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Helper function to calculate Luhn checksum
  function runLuhnCheck(digits: string): boolean {
    let sum = 0;
    let shouldDouble = false;
    
    // Process digits from right to left
    for (let i = digits.length - 1; i >= 0; i--) {
      let digit = parseInt(digits.charAt(i));
      
      if (shouldDouble) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }
      
      sum += digit;
      shouldDouble = !shouldDouble;
    }
    
    return (sum % 10) === 0;
  }
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Visa: starts with 4, 13 or 16 digits
  if (digitsOnly.match(/^4\d{12}(\d{3})?(\d{3})?$/)) {
    return digitsOnly.length === 13 || digitsOnly.length === 16 ? runLuhnCheck(digitsOnly) : false;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  if (digitsOnly.match(/^(5[1-5]\d{14}|2(2[2-9]\d|[3-6]\d{2}|7[01]\d|720)\d{12})$/)) {
    return digitsOnly.length === 16 ? runLuhnCheck(digitsOnly) : false;
  }
  
  // American Express: starts with 34 or 37, 15 digits
  if (digitsOnly.match(/^3[47]\d{13}$/)) {
    return digitsOnly.length === 15 ? runLuhnCheck(digitsOnly) : false;
  }
  
  return false;
}
