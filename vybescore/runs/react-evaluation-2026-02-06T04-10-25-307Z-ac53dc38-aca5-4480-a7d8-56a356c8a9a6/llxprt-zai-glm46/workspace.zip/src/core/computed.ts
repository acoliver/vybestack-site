/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  ObserverR,
  updateObserver,
  EqualFn,
  Options,
  getActiveObserver,
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  userUpdateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const observers: Set<Observer<unknown>> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: userUpdateFn,
  }
  
  // Wrap updateFn to notify this computed's observers after update
  const originalUpdateFn = o.updateFn
  
  o.updateFn = (prevValue?: T) => {
    // Call the original updateFn to get the new value
    const result = originalUpdateFn(prevValue)
    
    // Update the value directly
    o.value = result
    
    // Notify observers AFTER the value has been updated
    for (const obs of observers) {
      updateObserver(obs as Observer<unknown>)
    }
    
    return result
  }
  
  // Initial computation
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    // Check if this computed is being accessed by another observer (callback or computed)
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Register this computed as a dependency of the active observer
      (o as { observer?: ObserverR }).observer = activeObs
      observers.add(activeObs as Observer<unknown>)
      
      // Track this dependency for cleanup
      if (!activeObs.dependencies) {
        activeObs.dependencies = new Set()
      }
      activeObs.dependencies.add({
        removeObserver: (obs: Observer<unknown>) => {
          observers.delete(obs)
        }
      })
    }
    return o.value!
  }
  
  return getter
}
