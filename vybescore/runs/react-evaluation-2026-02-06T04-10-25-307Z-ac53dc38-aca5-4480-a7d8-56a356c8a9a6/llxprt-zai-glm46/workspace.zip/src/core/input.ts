/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const observers: Set<Observer<unknown>> = new Set()

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      observers.add(observer as Observer<unknown>)
      
      // Track this dependency for cleanup
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add({
        removeObserver: (obs: Observer<unknown>) => {
          observers.delete(obs)
        }
      })
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers
    for (const obs of observers) {
      updateObserver(obs as Observer<T>)
    }
    return s.value
  }

  return [read, write]
}
