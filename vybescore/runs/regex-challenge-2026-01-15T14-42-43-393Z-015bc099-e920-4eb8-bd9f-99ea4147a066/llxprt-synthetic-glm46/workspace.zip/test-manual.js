import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== Validating Functions ===');

console.log('Email validation:');
console.log(`  name+tag@example.co.uk: ${isValidEmail('name+tag@example.co.uk')}`);
console.log(`  name..tag@example.com: ${isValidEmail('name..tag@example.com')}`);
console.log(`  name@example_.com: ${isValidEmail('name@example_.com')}`);

console.log('\nUS Phone validation:');
console.log(`  (212) 555-7890: ${isValidUSPhone('(212) 555-7890')}`);
console.log(`  212-555-7890: ${isValidUSPhone('212-555-7890')}`);
console.log(`  +1 212-555-7890: ${isValidUSPhone('+1 212-555-7890')}`);

console.log('\nArgentine Phone validation:');
console.log(`  +54 9 11 1234 5678: ${isValidArgentinePhone('+54 9 11 1234 5678')}`);
console.log(`  011 1234 5678: ${isValidArgentinePhone('011 1234 5678')}`);
console.log(`  +54 341 123 4567: ${isValidArgentinePhone('+54 341 123 4567')}`);
console.log(`  0341 4234567: ${isValidArgentinePhone('0341 4234567')}`);
console.log(`  011 4234-5678: ${isValidArgentinePhone('011 4234-5678')}`);
console.log(`  +54-9-341-123-4567: ${isValidArgentinePhone('+54-9-341-123-4567')}`);

console.log('\n=== Transformation Functions ===');

console.log('Capitalize sentences:');
console.log(`  "${capitalizeSentences('hello world. how are you?')}"`);

console.log('\nRewrite docs URLs:');
console.log(`  "${rewriteDocsUrls('See http://example.com/docs/guide')}"`);

console.log('\n=== Puzzle Functions ===');

console.log('Embedded token search:');
console.log(`  'xfoo 1foo foo' with 'foo': ${JSON.stringify(findEmbeddedToken('xfoo 1foo foo', 'foo'))}`);

console.log('\nPassword strength:');
console.log(`  Abcdef!234: ${isStrongPassword('Abcdef!234')}`);
console.log(`  strongpassword123: ${isStrongPassword('strongpassword123')}`);