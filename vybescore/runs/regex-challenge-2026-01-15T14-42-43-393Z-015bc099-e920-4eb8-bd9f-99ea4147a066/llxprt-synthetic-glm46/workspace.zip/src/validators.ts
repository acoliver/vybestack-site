export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let doubleDigit = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with strict rules.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  const invalidPatterns = [
    /\.\./, 
    /^\./,
    /\.$/,
    /@.*_/, 
    /@.*\.\./, 
    /\._/,
    /_.*\./
  ];
  
  if (!value || typeof value !== 'string') return false;
  if (!emailRegex.test(value)) return false;
  
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with optional country code and common formats.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const digits = value.replace(/\D/g, '');
  
  if (digits.length < 10) return false;
  
  const withCountryCode = digits.length === 11 && digits.startsWith('1');
  const withoutCountryCode = digits.length === 10;
  
  const mainDigits = withCountryCode ? digits.slice(1) : digits;
  
  if (mainDigits[0] === '0' || mainDigits[0] === '1') {
    return false;
  }
  
  const usPhoneRegex = /^(?:\+1\s?)?(?:\(\s*(\d{3})\s*\)|(\d{3}))[.\s-]*(\d{3})[.\s-]*(\d{4})$/;
  if (!usPhoneRegex.test(value)) return false;
  
  return withCountryCode || withoutCountryCode;
}

/**
 * Validate Argentine phone numbers with optional country code and mobile prefixes.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have 10-14 digits
  if (digitsOnly.length < 10 || digitsOnly.length > 14) return false;
  
  let areaCode: string;
  let subscriber: string;
  
  // Parse based on format
  if (digitsOnly.startsWith('54')) {
    // With country code +54
    if (digitsOnly.length === 14 && digitsOnly[2] === '9') {
      // +54 9 11 1234 5678 format (country + mobile + area + 8-digit subscriber)
      areaCode = digitsOnly.substring(3, 5); // 2-digit area code (11)
      subscriber = digitsOnly.substring(5); // 8-digit subscriber
    } else if (digitsOnly.length === 12 && digitsOnly[2] !== '9') {
      // +54 11 1234 5678 format (country + 2-digit area + 6-digit subscriber)
      areaCode = digitsOnly.substring(2, 4); // 2-digit area code (11)
      subscriber = digitsOnly.substring(4); // 6-digit subscriber
    } else if (digitsOnly.length === 13 && digitsOnly[2] === '9') {
      // +54 9 341 123 4567 format (country + mobile + 3-digit area + 7-digit subscriber)
      areaCode = digitsOnly.substring(3, 6); // 3-digit area code (341)
      subscriber = digitsOnly.substring(6); // 7-digit subscriber
    } else if (digitsOnly.length === 11 && digitsOnly[2] !== '9') {
      // +54 341 123 4567 format (country + 3-digit area + 7-digit subscriber)
      areaCode = digitsOnly.substring(2, 5); // 3-digit area code (341)
      subscriber = digitsOnly.substring(5); // 7-digit subscriber
    } else {
      return false;
    }
  } else {
    // Without country code, must start with trunk prefix 0
    if (!digitsOnly.startsWith('0')) return false;
    
    if (digitsOnly.length === 11 && digitsOnly[1] === '9') {
      // 0 9 11 1234 5678 with mobile indicator 9
      areaCode = digitsOnly.substring(2, 4); // 2-digit area code (11)
      subscriber = digitsOnly.substring(4); // 6-digit subscriber
    } else if (digitsOnly.length === 10) {
      // 0 11 1234 5678 without mobile indicator
      areaCode = digitsOnly.substring(1, 3); // 2-digit area code (11)
      subscriber = digitsOnly.substring(3); // 6-digit subscriber
    } else if (digitsOnly.length === 12 && digitsOnly[1] === '9') {
      // 0 9 341 123 4567 with mobile indicator
      areaCode = digitsOnly.substring(2, 5); // 3-digit area code (341)
      subscriber = digitsOnly.substring(5); // 7-digit subscriber
    } else if (digitsOnly.length === 11 && digitsOnly.substring(1, 4) === '341') {
      // 0 341 123 4567 (special case for 341 area code)
      areaCode = digitsOnly.substring(1, 4); // 3-digit area code (341)
      subscriber = digitsOnly.substring(4); // 7-digit subscriber
    } else {
      return false;
    }
  }
  
  // Validate area code (2-4 digits, first digit not 0)
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
  
  // Validate subscriber number (6-8 digits)
  if (!subscriber || subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const nameRegex = /^[a-zA-Z\u00C0-\u00FF\u0100-\u017F\u0400-\u04FF\s\-\u0027]+$/;
  
  if (!nameRegex.test(value)) return false;
  
  if (/\d/.test(value)) return false;
  
  if (/[^a-zA-Z\u00C0-\u00FF\u0100-\u017F\u0400-\u04FF\s\-\u0027]/.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers based on prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const digits = value.replace(/\D/g, '');
  
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidPattern = visaRegex.test(digits) || 
                        mastercardRegex.test(digits) || 
                        amexRegex.test(digits);
  
  if (!isValidPattern) return false;
  
  return runLuhnCheck(digits);
}
