/**
 * Find words starting with the prefix but excluding the specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const allMatches = text.match(wordRegex) || [];
  
  const uniqueWords = new Set(allMatches);
  
  const filteredWords = Array.from(uniqueWords).filter(word => 
    !exceptions.includes(word)
  );
  
  return filteredWords.sort();
}

/**
 * Find token occurrences that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const tokenRegex = new RegExp(`\\d${escapedToken}(?=\\b|$)`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  return Array.from(new Set(matches));
}

/**
 * Validate password strength according to security requirements.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  if (value.length < 10) return false;
  
  const categories = [
    /[A-Z]/, 
    /[a-z]/, 
    /\d/, 
    /[!@#$%^&*()_+=[\]{};':"\\|,.<>\/?~]/
  ];
  
  const categoryMatches = categories.filter(regex => regex.test(value));
  if (categoryMatches.length < 4) return false;
  
  if (/\s/.test(value)) return false;
  
  for (let i = 0; i < value.length - 2; i++) {
    const seq = value.substring(i, i + 3);
    if (seq[0] === seq[1] && seq[1] === seq[2]) return false;
    
    if (value.indexOf(seq) !== value.lastIndexOf(seq)) return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  const ipv6Regex = /(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}|::|(?:[0-9a-f]{1,4}:){1,7}:|(?:[0-9a-f]{1,4}:){1,6}:[0-9a-f]{1,4}|(?:[0-9a-f]{1,4}:){1,5}(?::[0-9a-f]{1,4}){1,2}|(?:[0-9a-f]{1,4}:){1,4}(?::[0-9a-f]{1,4}){1,3}|(?:[0-9a-f]{1,4}:){1,3}(?::[0-9a-f]{1,4}){1,4}|(?:[0-9a-f]{1,4}:){1,2}(?::[0-9a-f]{1,4}){1,5}|[0-9a-f]{1,4}:(?:(?::[0-9a-f]{1,4}){1,6})|:(?:(?::[0-9a-f]{1,4}){1,7}|:)/i;
  
  const ipv6StrictRegex = new RegExp(`\\b(?:${ipv6Regex.source})\\b`);
  
  const ipv6Matches = value.match(ipv6StrictRegex);
  if (!ipv6Matches) return false;
  
  if (ipv4Regex.test(value)) return false;
  
  return true;
}
