/**
 * Capitalize the first character of each sentence while preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  let result = text.replace(/\s+/g, ' ').trim();
  
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  result = result.replace(/([.?!])(\s+)([a-z])/g, (match, punct, space, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * Extract all URLs from the given text.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  const urlRegex = /https?:\/\/[^\s)]+(?=[\s).,?!]|$)/g;
  
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => url.replace(/[.,?!]$/, '')).filter(Boolean);
}

/**
 * Replace all http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://docs.example.com/... for docs paths.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  const dynamicPatterns = [
    /cgi-bin/,
    /[?&=]/,
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i
  ];
  
  return text.replace(/https?:\/\/example\.com(\/[^\s]+)/g, (match, path) => {
    const isDynamic = dynamicPatterns.some(pattern => pattern.test(path));
    
    const secureUrl = match.replace(/^http:/, 'https:');
    
    if (!isDynamic && path.startsWith('/docs/')) {
      return `https://docs.example.com${path}`;
    }
    
    return secureUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  if (month === 2 && day > 29) return 'N/A';
  
  const shortMonths = [4, 6, 9, 11];
  if (shortMonths.includes(month) && day > 30) return 'N/A';
  
  if (!shortMonths.includes(month) && month !== 2 && day > 31) return 'N/A';
  
  return year;
}
