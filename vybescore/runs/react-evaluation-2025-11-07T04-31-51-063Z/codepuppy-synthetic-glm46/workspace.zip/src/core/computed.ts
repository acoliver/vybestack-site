/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  notifyObservers,
  EqualFn,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Default equality function using strict equality
 */
function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === false) {
    equalFn = undefined // Always trigger updates
  } else if (equal === true || equal === undefined) {
    equalFn = defaultEqual // Use default equality
  } else if (typeof equal === 'function') {
    equalFn = equal // Use custom equality function
  }

  // Create a mock subject to store computed value and observers
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      const newValue = updateFn(currentValue)
      
      // Check if value actually changed using equality function
      if (equalFn && subject.value !== undefined && equalFn(subject.value, newValue)) {
        return subject.value // No change needed
      }
      
      subject.value = newValue
      o.value = newValue
      
      // Notify dependent observers of this computed value
      notifyObservers(subject)
      
      return newValue
    },
  }
  
  // Initial computation to establish dependencies and get initial value
  updateObserver(o)
  
  // Return getter function that handles dependency tracking
  return (): T => {
    const observer = getActiveObserver()
    if (observer && !observer.disposed) {
      // Register this computed as a dependency of the current observer
      subject.observers.add(observer)
    }
    return subject.value
  }
}