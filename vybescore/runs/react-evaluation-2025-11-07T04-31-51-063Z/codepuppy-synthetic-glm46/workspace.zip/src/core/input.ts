/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Default equality function using strict equality
 */
function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === false) {
    equalFn = undefined // Always trigger updates
  } else if (equal === true || equal === undefined) {
    equalFn = defaultEqual // Use default equality
  } else if (typeof equal === 'function') {
    equalFn = equal // Use custom equality function
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observer.disposed) {
      // Register this subject as a dependency of the current observer
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value // No change needed
    }
    
    s.value = nextValue
    
    // Notify all dependent observers
    notifyObservers(s)
    
    return s.value
  }

  return [read, write]
}