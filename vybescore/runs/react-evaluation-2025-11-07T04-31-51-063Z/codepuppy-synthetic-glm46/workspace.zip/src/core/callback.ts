/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      // Execute the side effect
      const result = updateFn(currentValue)
      
      // Update the stored value with the result
      observer.value = result
      return result
    },
  }
  
  // Initial execution to establish dependencies
  updateObserver(observer)
  
  // Return unsubscribe function
  return () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Clear the observer to stop further updates
    // This effectively removes the subscription
    observer.value = undefined
    observer.updateFn = () => value as T // No-op function
  }
}