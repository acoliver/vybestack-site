import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const html = response.text;
    const $ = load(html);

    // Check that all form fields are present
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);

    // Check that form has correct action and method
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('form[method="POST"]').length).toBe(1);

    // Check title
    expect($('title').text()).toContain('Friendly Form');
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Test successful submission
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '90210',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(302); // Redirect after successful submission

    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created and contains data
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles validation errors', async () => {
    // Test submission with missing required fields
    const invalidData = {
      firstName: '', // Missing required field
      lastName: 'Doe',
      email: 'invalid-email' // Invalid email format
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400); // Bad request due to validation errors

    const html = response.text;
    const $ = load(html);

    // Check that form is re-rendered with errors
    expect($('.error-message').length).toBeGreaterThan(0);
    expect($('#firstName-error').text()).toContain('required');
    expect($('#email-error').text()).toContain('valid');
  });

  it('shows thank you page after successful submission', async () => {
    // First submit valid data
    const submissionData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Another City',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'jane.smith@example.com',
      phone: '@44 20 7946 0958' // International format
    };

    // Follow redirect to thank you page
    await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(302)
      .then((response) => {
        return request(app)
          .get(response.headers.location)
          .expect(200);
      })
      .then((thankYouResponse) => {
        const html = thankYouResponse.text;
        const $ = load(html);

        // Check thank you page content
        expect($('h1').text()).toContain('Thank You');
        expect($('.success-message').length).toBe(1);
        expect($('.home-link a[href="/"]').length).toBe(1);
      });
  });
});
