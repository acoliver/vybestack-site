import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
let db: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs({
    locateFile: (file) => path.resolve('node_modules', 'sql.js', 'dist', file),
  });

  const exists = fs.existsSync(DB_PATH);
  
  if (exists) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    // Create submissions table using the provided schema
    const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf-8');
    db.exec(schema);
  }

  return db;
}

export function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  const binarySql = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(binarySql));
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function insertSubmission(submission: Submission): void {
  const database = getDatabase();
  
  const stmt = database.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone,
  ]);

  stmt.free();
  saveDatabase();
}