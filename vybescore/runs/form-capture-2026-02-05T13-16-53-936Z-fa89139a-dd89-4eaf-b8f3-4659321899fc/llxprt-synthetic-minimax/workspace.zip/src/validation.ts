import { Request } from 'express';

export interface ValidationErrors {
  [key: string]: string;
}

export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  // Accept international formats with digits, spaces, parentheses, dashes, and leading @
  const phoneRegex = /^@?[\d\s\-() +]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

export function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handle UK "SW1A 1AA" and Argentine formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

export function validateRequiredField(value: string): boolean {
  return value.trim().length > 0;
}

export function parseFormData(req: Request): { data: ContactFormData; errors: ValidationErrors } {
  const data: ContactFormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors: ValidationErrors = {};

  if (!validateRequiredField(data.firstName)) {
    errors.firstName = 'First name is required';
  }

  if (!validateRequiredField(data.lastName)) {
    errors.lastName = 'Last name is required';
  }

  if (!validateRequiredField(data.streetAddress)) {
    errors.streetAddress = 'Street address is required';
  }

  if (!validateRequiredField(data.city)) {
    errors.city = 'City is required';
  }

  if (!validateRequiredField(data.stateProvince)) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!validateRequiredField(data.country)) {
    errors.country = 'Country is required';
  }

  if (!validateRequiredField(data.email)) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!validateRequiredField(data.phone)) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  if (!validateRequiredField(data.postalCode)) {
    errors.postalCode = 'Postal code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return { data, errors };
}

export function hasErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}