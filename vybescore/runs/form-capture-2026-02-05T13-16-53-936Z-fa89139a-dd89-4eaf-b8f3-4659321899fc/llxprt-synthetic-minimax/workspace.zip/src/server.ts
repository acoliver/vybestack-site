import express, { Request, Response } from 'express';
import path from 'node:path';
import { initializeDatabase, insertSubmission, closeDatabase } from './db.js';
import { parseFormData, hasErrors, ContactFormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;
let serverInstance: ReturnType<typeof app.listen> | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.resolve('public')));

// Set EJS as template engine
app.set('views', path.resolve('views'));
app.set('view engine', 'ejs');

// Initialize database on startup
initializeDatabase().catch((error) => {
  console.error('Failed to initialize database:', error);
  process.exit(1);
});

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    data: {} as ContactFormData,
    pageTitle: 'Contact Us - Friendly Form (Definitely Not A Scam)',
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const { data, errors } = parseFormData(req);

  if (hasErrors(errors)) {
    // Validation failed - re-render form with errors and previous values
    res.status(400).render('form', {
      errors,
      data,
      pageTitle: 'Contact Us - Please Fix Errors',
    });
    return;
  }

  // Validation passed - save to database and redirect
  try {
    insertSubmission({
      first_name: data.firstName,
      last_name: data.lastName,
      street_address: data.streetAddress,
      city: data.city,
      state_province: data.stateProvince,
      postal_code: data.postalCode,
      country: data.country,
      email: data.email,
      phone: data.phone,
    });

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: { general: 'Sorry, something went wrong. Please try again.' },
      data,
      pageTitle: 'Contact Us - Error',
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    pageTitle: 'Thank You - Your Information is Safe With Us!',
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  closeDatabase();
  
  if (serverInstance) {
    serverInstance.close(() => {
      console.log('Server closed successfully.');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }

  // Force exit if graceful shutdown takes too long
  setTimeout(() => {
    console.log('Forcing shutdown...');
    process.exit(0);
  }, 5000);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
function startServer() {
  serverInstance = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

// Only start server if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default app;
export { startServer };
