/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Decodes standard Base64 input and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate basic Base64 format
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }
  
  // Check if padding is correct
  const padLength = (input.match(/=/g) || []).length;
  if (padLength > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Check if padding appears in the wrong place
  if (padLength > 0 && !/={1,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: padding not at end');
  }
  
  // Make sure the input length is divisible by 4, or can be padded to be divisible by 4
  const inputLen = input.length;
  if (inputLen % 4 !== 0) {
    // For inputs without padding, we can pad them ourselves
    // This is valid for strings like 'aGVsbG8' (length 7)
    // which becomes 'aGVsbG8=' when padded
    const padLength = 4 - (inputLen % 4);
    input = input + '='.repeat(padLength);
  }
  
  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify the result by encoding it back
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    
    // Normalize both for comparison by removing padding
    const normalizedInput = input.replace(/=/g, '');
    const normalizedReencoded = reencoded.replace(/=/g, '');
    
    if (normalizedInput !== normalizedReencoded) {
      throw new Error('Invalid Base64 input: failed round-trip verification');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
