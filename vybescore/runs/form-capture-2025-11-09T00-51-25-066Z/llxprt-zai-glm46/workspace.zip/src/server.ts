import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have TypeScript definitions
import initSqlJs from 'sql.js';

interface Database {
  exec(sql: string): Array<{ columns: string[]; values: string[][] }>;
  prepare(sql: string): Statement;
  run(sql: string, ...params: (string | number)[]): void;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: (string | number)[]): void;
  free(): void;
}

interface Database {
  exec(sql: string): Array<{ columns: string[]; values: string[][] }>;
  prepare(sql: string): Statement;
  run(sql: string, ...params: (string | number)[]): void;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: (string | number)[]): void;
  free(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

const app = express();
const port = process.env.PORT || 3000;
let dbInstance: Database | null = null;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
};

const validatePostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric with spaces, dashes
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
};

const validateFormData = (data: FormData): ValidationResult => {
  const errors: string[] = [];

  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  }
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  }
  if (!data.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  if (!data.city?.trim()) {
    errors.push('City is required');
  }
  if (!data.stateProvince?.trim()) {
    errors.push('State/Province/Region is required');
  }
  if (!data.postalCode?.trim()) {
    errors.push('Postal code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, spaces, and dashes');
  }
  if (!data.country?.trim()) {
    errors.push('Country is required');
  }
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and optionally a leading +');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
};

// Initialize database
const initializeDatabase = async (): Promise<void> => {
  try {
    const SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      dbInstance = new SQL.Database(fileBuffer.buffer);
    } else {
      dbInstance = new SQL.Database();
      // Read and execute schema
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      if (dbInstance) {
        dbInstance.run(schema);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

// Save database to disk
const saveDatabase = (): void => {
  if (!dbInstance) return;
  
  try {
    const data = dbInstance.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    return res.render('form', {
      errors: validation.errors,
      values: formData
    });
  }

// Insert into database
  if (dbInstance) {
    const stmt = dbInstance.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
  }

  res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get first name from query parameter or use a default
  const firstName = (req.query.firstName as string) || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
const gracefulShutdown = (signal: string) => {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      if (dbInstance) {
        dbInstance.close();
        console.log('Database closed');
      }
      process.exit(0);
    });
  } else {
    if (dbInstance) {
      dbInstance.close();
    }
    process.exit(0);
  }
};

// Start server
let server: import('http').Server | null = null;

const startServer = async (): Promise<import('http').Server> => {
  try {
    await initializeDatabase();
    
    return new Promise<import('http').Server>((resolve, reject) => {
      server = app.listen(port, () => {
        console.log(`Server running on port ${port}`);
        resolve(server);
      });

      server.on('error', (error: Error) => {
        reject(error);
      });
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    throw error;
  }
};



// Set up signal handlers for standalone server
const setupSignalHandlers = (): void => {
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
};

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().then(() => {
    setupSignalHandlers();
  }).catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, startServer, gracefulShutdown };
