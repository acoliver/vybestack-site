import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';
import { app, gracefulShutdown } from '../../src/server.js';

const server: import('http').Server | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(async () => {
  if (server) {
    await gracefulShutdown('SIGTERM');
  }
  
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check for proper form structure
    expect($('form[method="post"][action="/submit"]')).toHaveLength(1);
    expect($('button[type="submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Ensure database doesn't exist before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Test Street',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'SW1A 1AA', // UK postal code
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958' // UK phone number
    };
    
    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database was created and contains data
    expect(fs.existsSync(dbPath)).toBe(true);
    
    const SQL = await initSqlJs();
    const dbBuffer = fs.readFileSync(dbPath);
    const db = new SQL.Database(dbBuffer);
    
    const result = db.exec('SELECT * FROM submissions ORDER BY id DESC LIMIT 1');
    expect(result).toHaveLength(1);
    expect(result[0].values).toHaveLength(1);
    
    const row = result[0].values[0];
    expect(row[1]).toBe(formData.firstName); // first_name
    expect(row[2]).toBe(formData.lastName); // last_name
    expect(row[7]).toBe(formData.email); // email
    expect(row[8]).toBe(formData.phone); // phone
    
    db.close();
  });

  it('shows validation errors for invalid data', async () => {
    const invalidData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: 'invalid-phone-#'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that errors are displayed
    expect($('.error-list')).toHaveLength(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
    
    // Check that form values are preserved
    expect($('input[name="email"]').val()).toBe(invalidData.email);
    expect($('input[name="phone"]').val()).toBe(invalidData.phone);
  });

  it('validates international postal codes and phone numbers', async () => {
    const internationalData = {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Calle Falsa 123',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000', // Argentine postal code
      country: 'Argentina',
      email: 'maria.garcia@example.com.ar',
      phone: '+54 9 11 1234-5678' // Argentine phone number
    };
    
    const response = await request(app)
      .post('/submit')
      .send(internationalData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });
});
