import { createInput, createComputed, createCallback } from './dist/index.js';

console.log('Testing reactive system:');

// Test 1: Basic computed dependency
console.log('\n=== Test 1: Basic computed dependency ===');
const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => {
  console.log('  Calling timesTwo with input value:', input());
  return input() * 2
});
const timesThirty = createComputed(() => {
  console.log('  Calling timesThirty with input value:', input());
  return input() * 30
});
const sum = createComputed(() => {
  console.log('  Calling sum with timesTwo:', timesTwo(), 'timesThirty:', timesThirty());
  return timesTwo() + timesThirty()
});

console.log('Initial sum:', sum());
console.log('Changing input to 3...');
setInput(3);
console.log('Final sum:', sum());