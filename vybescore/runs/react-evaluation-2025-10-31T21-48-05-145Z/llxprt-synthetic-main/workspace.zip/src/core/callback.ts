/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn } from '../types/reactive.js'

// Track callbacks for cascade updates
const allCallbacks = new Set<Observer<unknown>>()

// Also export via globalThis for computed.ts to access
if (!(globalThis as unknown as { __allCallbacks?: Set<Observer<unknown>> }).__allCallbacks) {
  (globalThis as unknown as { __allCallbacks?: Set<Observer<unknown>> }).__allCallbacks = allCallbacks
}

// Export for use by input.ts
export { allCallbacks }

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Convert to Observer<unknown> to avoid type issues
  const unknownObserver: Observer<unknown> = {
    value,
    updateFn: val => updateFn(val as T),
  }
  
  // Register this callback in the global set
  allCallbacks.add(unknownObserver)
  
  // Register observer to track dependencies and trigger initial execution
  try {
    unknownObserver.value = unknownObserver.updateFn(unknownObserver.value)
  } catch (e) {
    // Ignore errors during initialization
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from global set
    allCallbacks.delete(unknownObserver)
    
    // Clear the observer to stop further updates
    unknownObserver.value = undefined
    unknownObserver.updateFn = () => value as T
  }
}