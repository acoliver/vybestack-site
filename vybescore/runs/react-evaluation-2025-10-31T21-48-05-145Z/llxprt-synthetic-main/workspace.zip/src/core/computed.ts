/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process the equal parameter similarly to createInput
  const equalFn = equal === true ? ((a: T, b: T) => a === b) : (equal as EqualFn<T>)
  
  const o: Observer<unknown> = {
    name: options?.name,
    value,
    updateFn: value => updateFn(value as T),
  }
  
  // Store this computed observer globally
  const globalComputed = (globalThis as unknown as { __allComputedObservers?: Observer<unknown>[] })
  if (!globalComputed.__allComputedObservers) {
    globalComputed.__allComputedObservers = []
  }
  globalComputed.__allComputedObservers.push(o)
  
  // Override updateObserver to propagate updates to computed dependents
  if (!(globalThis as unknown as { __updateObserverWrapped?: boolean }).__updateObserverWrapped) {
    (globalThis as unknown as { __updateObserverWrapped?: boolean }).__updateObserverWrapped = true
    
    const originalUpdateObserver = updateObserver
    ;(globalThis as unknown as { updateObserver: (observer: Observer<unknown>) => void }).updateObserver = (observer: Observer<unknown>) => {
      // First update the specific observer
      const previousValue = observer.value
      originalUpdateObserver(observer)
      
      // Only cascade if value actually changed and we have an equality function
      const hasChanged = equalFn 
        ? !equalFn(previousValue as T, observer.value as T) 
        : previousValue !== observer.value
      
      if (hasChanged) {
        // Cascade: Update all computed observers to trigger recomputation
        const allComputed = (globalThis as unknown as { __allComputedObservers?: Observer<unknown>[] }).__allComputedObservers || []
        for (const computedObs of allComputed) {
          if (computedObs !== observer) {
            const prevComputedValue = computedObs.value
            originalUpdateObserver(computedObs)
            
            // Check if the computed value actually changed before cascading further
            const computedChanged = equalFn
              ? !equalFn(prevComputedValue as T, computedObs.value as T)
              : prevComputedValue !== computedObs.value
            
            // If this computed value changed, notify callbacks
            if (computedChanged) {
              const allCallbacks = (globalThis as unknown as { __allCallbacks?: Set<Observer<unknown>> }).__allCallbacks || new Set()
              for (const callback of allCallbacks) {
                originalUpdateObserver(callback)
              }
            }
          }
        }
      }
    }
  }
  
  // Initialize the computed value
  try {
    o.value = o.updateFn(o.value)
  } catch (e) {
    // Ignore errors during initialization
  }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = (globalThis as unknown as { __activeObserver?: Observer<unknown> }).__activeObserver
    if (activeObserver) {
      // Register this computed observer as a dependency
      const globalDeps = (globalThis as unknown as { __computedDependencies?: Map<Observer<unknown>, Set<Observer<unknown>>> })
      if (!globalDeps.__computedDependencies) {
        globalDeps.__computedDependencies = new Map()
      }
      
      if (!globalDeps.__computedDependencies.has(activeObserver)) {
        globalDeps.__computedDependencies.set(activeObserver, new Set())
      }
      globalDeps.__computedDependencies.get(activeObserver)!.add(o)
    }
    return o.value! as T
  }
  
  return getter
}