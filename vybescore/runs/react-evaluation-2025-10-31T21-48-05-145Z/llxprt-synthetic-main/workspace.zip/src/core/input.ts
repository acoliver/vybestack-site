/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Import callbacks from callback.ts
import { allCallbacks } from './callback.js'

// Also make it available globally
if (!(globalThis as unknown as { __allCallbacks?: typeof allCallbacks }).__allCallbacks) {
  (globalThis as unknown as { __allCallbacks?: typeof allCallbacks }).__allCallbacks = allCallbacks
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Store the observer type-specific to avoid type issues
  let typedObserver: Observer<T> | undefined
  
  const s: {
    name?: string
    observer?: Observer<unknown>
    value: T
    equalFn?: EqualFn<T>
  } = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: equal === true 
      ? ((a: unknown, b: unknown) => a === b) as EqualFn<T>
      : (equal as EqualFn<T>),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      typedObserver = observer as Observer<T>
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = s.equalFn 
      ? !s.equalFn(s.value, nextValue)
      : s.value !== nextValue
    
    if (shouldUpdate) {
      s.value = nextValue
      
      // Update primary observer using the typed copy
      if (typedObserver) {
        try {
          typedObserver.value = typedObserver.updateFn(typedObserver.value)
        } catch (e) {
          // Ignore errors in observer update
        }
      }
      
      // Cascade: Update all computed observers
      const allComputed = (globalThis as unknown as { __allComputedObservers?: Observer<unknown>[] }).__allComputedObservers || []
      for (const computedObs of allComputed) {
        updateObserver(computedObs)
      }
      
      // Cascade: Update all callbacks
      for (const callback of allCallbacks) {
        updateObserver(callback)
      }
    }
    
    return s.value
  }

  return [read, write]
}