const { createInput, createComputed, createCallback } = require('./src/index.js');

console.log('Testing reactive system:');

// Test 1: Basic computed dependency
console.log('\n=== Test 1: Basic computed dependency ===');
const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => {
  console.log('  Calling timesTwo with input value:', input());
  return input() * 2
});
const timesThirty = createComputed(() => {
  console.log('  Calling timesThirty with input value:', input());
  return input() * 30
});
const sum = createComputed(() => {
  console.log('  Calling sum with timesTwo:', timesTwo(), 'timesThirty:', timesThirty());
  return timesTwo() + timesThirty()
});

console.log('Initial sum:', sum());
console.log('Changing input to 3...');
setInput(3);
console.log('Final sum:', sum());

// Test 2: Callback triggering
console.log('\n=== Test 2: Callback triggering ===');
const [input2, setInput2] = createInput(1);
const output = createComputed(() => {
  console.log('  Computing output with input:', input2());
  return input2() + 1
});
let value = 0;
createCallback(() => {
  console.log('  Callback executed, setting value to output:', output());
  value = output()
});
console.log('Initial value:', value);
console.log('Changing input to 3...');
setInput2(3);
console.log('Final value:', value);