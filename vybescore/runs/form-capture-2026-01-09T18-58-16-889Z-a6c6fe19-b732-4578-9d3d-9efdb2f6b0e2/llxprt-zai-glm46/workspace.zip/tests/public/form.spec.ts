import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from '../../src/server';

let server: Awaited<ReturnType<typeof createServer>>['server'];
let app: Awaited<ReturnType<typeof createServer>>['app'];
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const result = await createServer();
  server = result.server;
  app = result.app;
});

afterAll(() => {
  if (server) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);

    // Check all form fields exist
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check labels are properly associated
    expect($('label[for="firstName"]').text()).toBe('First name');
    expect($('label[for="email"]').text()).toBe('Email');

    // Check form submits to /submit
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Database file should be created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid email', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email', // Invalid email
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(400);
    expect(response.text).toContain('Please enter a valid email address');
    expect(response.text).toContain('Jane'); // Preserves entered values
  });

  it('shows validation errors for invalid phone', async () => {
    const formData = {
      firstName: 'Bob',
      lastName: 'Johnson',
      streetAddress: '789 Pine Rd',
      city: 'Sydney',
      stateProvince: 'NSW',
      postalCode: '2000',
      country: 'Australia',
      email: 'bob@example.com',
      phone: 'invalid@phone!', // Invalid phone (contains @ and !)
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number can only contain digits');
  });

  it('accepts various international phone formats', async () => {
    // Clean database first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '+61 2 9876 5432',
    ];

    for (const phone of testPhones) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: 'Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: 'T35T',
        country: 'Test Country',
        email: `test${phone.replace(/\D/g, '')}@example.com`,
        phone,
      };

      const response = await request(app).post('/submit').send(formData);
      expect(response.status).toBe(302);
    }
  });

  it('accepts various international postal formats', async () => {
    // Clean database first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testPostalCodes = [
      'SW1A 1AA', // UK
      'C1000', // Argentina
      'B1675', // Argentina
      '12345', // US
      'H0H 0H0', // Canada
    ];

    for (const postalCode of testPostalCodes) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: 'Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode,
        country: 'Test Country',
        email: `test${postalCode.replace(/\s/g, '')}@example.com`,
        phone: '+1 555-123-4567',
      };

      const response = await request(app).post('/submit').send(formData);
      expect(response.status).toBe(302);
    }
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you?firstName=Alice');

    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you, Alice!');
    expect(response.text).toContain('stranger on the internet');
    expect(response.text).toContain('href="/"');
  });

  it('requires all fields', async () => {
    const response = await request(app).post('/submit').send({});

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Email is required');
  });
});
