import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database as SqlDatabase, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface Submission extends FormValues {
  id?: number;
  created_at?: string;
}

class Database {
  private db: SqlDatabase | null = null;
  private SQL: SqlJsStatic | null = null;

  async init(): Promise<void> {
    this.SQL = await initSqlJs();
    await this.loadDatabase();
  }

  private async loadDatabase(): Promise<void> {
    if (!this.SQL) {
      throw new Error('SQL.js not initialized');
    }

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    if (fs.existsSync(DB_PATH)) {
      // Load existing database
      const buffer = fs.readFileSync(DB_PATH);
      this.db = new this.SQL.Database(buffer);
    } else {
      // Create new database and run schema
      this.db = new this.SQL.Database();
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      this.db.run(schema);
      await this.save();
    }
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }

  insertSubmission(submission: Submission): number {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );

    stmt.bind([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.step();
    stmt.free();

    // Get the last inserted row ID
    const result = this.db.exec('SELECT last_insert_rowid() as id');
    const id = result[0]?.values[0]?.[0] as number;
    return id;
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric characters with spaces, dashes
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateForm(values: FormValues): { errors: string[]; valid: boolean } {
  const errors: string[] = [];

  if (!validateRequired(values.firstName)) {
    errors.push('First name is required');
  }

  if (!validateRequired(values.lastName)) {
    errors.push('Last name is required');
  }

  if (!validateRequired(values.streetAddress)) {
    errors.push('Street address is required');
  }

  if (!validateRequired(values.city)) {
    errors.push('City is required');
  }

  if (!validateRequired(values.stateProvince)) {
    errors.push('State / Province / Region is required');
  }

  if (!validateRequired(values.postalCode)) {
    errors.push('Postal code is required');
  } else if (!validatePostalCode(values.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, spaces, and dashes');
  }

  if (!validateRequired(values.country)) {
    errors.push('Country is required');
  }

  if (!validateRequired(values.email)) {
    errors.push('Email is required');
  } else if (!validateEmail(values.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!validateRequired(values.phone)) {
    errors.push('Phone number is required');
  } else if (!validatePhone(values.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  return { errors, valid: errors.length === 0 };
}

// Server setup
async function createServer() {
  const app = express();
  const db = new Database();

  // Initialize database
  await db.init();

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

  // Set EJS as view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));

  // Routes
  app.get('/', (_req, res) => {
    res.render('form', { errors: [], values: {} });
  });

  app.post('/submit', (req, res) => {
    const values: FormValues = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const validation = validateForm(values);

    if (!validation.valid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        values,
      });
    }

    // Insert into database
    db.insertSubmission(values);
    db.save();

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req, res) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  });

  // Graceful shutdown
  const server = app.listen(process.env.PORT || 3535, () => {
    console.log(`Server listening on port ${process.env.PORT || 3535}`);
  });

  // Handle SIGTERM for graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      db.close();
      process.exit(0);
    });
  });

  return { app, server, db };
}

// Start server if this file is run directly
const isMainModule = process.argv[1] === fileURLToPath(import.meta.url);
if (isMainModule) {
  createServer();
}

export { createServer, validateForm, type FormValues, type Submission };
