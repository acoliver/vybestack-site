// Type definitions for sql.js
declare module 'sql.js' {
  interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  interface Statement {
    bind(values: unknown[]): void;
    step(): boolean;
    get(params?: unknown[]): unknown[] | null;
    getColumnNames(): string[];
    getAsObject(params?: unknown): unknown;
    free(): void;
  }

  const initSqlJs: (config?: { locateFile?: (filename: string) => string }) => Promise<SqlJsStatic>;

  export { Database, Statement, QueryExecResult, SqlJsStatic, initSqlJs };
  export default initSqlJs;
}
