/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Accepts inputs with or without padding.
 */
export function decode(input: string): string {
  // Validate the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for proper padding - only allowed at the end
  const paddingStart = input.indexOf('=');
  if (paddingStart !== -1) {
    const paddingSection = input.substring(paddingStart);
    if (!/^=+$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input: padding characters not at the end');
    }
  }

  // Normalize the input - add padding if missing (Buffer will work correctly with or without it)
  let normalizedInput = input;
  if (paddingStart === -1 && input.length % 4 !== 0) {
    // Pad with '=' to make length a multiple of 4
    normalizedInput = input + '='.repeat(4 - (input.length % 4));
  }

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
