/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries (.?!), inserts proper spacing, and preserves abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize multiple spaces to single space (but preserve structure)
  let normalized = text.replace(/\s+/g, ' ');
  
  // Insert space after sentence endings if missing
  normalized = normalized.replace(/([.?!])([^\s])/g, '$1 $2');
  
  // Split into sentences while preserving punctuation
  const sentences = normalized.split(/(?<=[.?!])\s+/);
  
  const capitalizedSentences = sentences.map(sentence => {
    if (!sentence) return sentence;
    
    // Find first letter character (skip initial punctuation/quotes)
    const match = sentence.match(/^[^\p{L}\p{M}]*([\p{L}\p{M}])/u);
    if (!match) return sentence;
    
    const firstLetterPos = sentence.indexOf(match[1]);
    const beforeFirstLetter = sentence.substring(0, firstLetterPos);
    const firstLetter = sentence[firstLetterPos].toUpperCase();
    const restOfSentence = sentence.substring(firstLetterPos + 1);
    
    return beforeFirstLetter + firstLetter + restOfSentence;
  });
  
  // Join sentences back together with single spaces
  return capitalizedSentences.join(' ');
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http/https protocols
  const urlRegex = /(https?:\/\/[^\s\)\]\}\<\>"]+[^\s\)\]\}\<\>"\.\,\!\?\;\:])/g;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[1];
    
    // Remove trailing punctuation that's not part of the URL
    url = url.replace(/[\.\,\!\?\;\:]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Match https://example.com/docs/... and rewrite to https://docs.example.com/...
  // But exclude if contains cgi-bin, query strings, or legacy extensions
  const docsRewriteRegex = /(https:\/\/)([^\s\/?#]+)(\/docs\/[^\s?#]*?)(?=\s|$|[?#])/g;
  
  result = result.replace(docsRewriteRegex, (match, protocol, host, pathAndQuery) => {
    // Extract just the path part before any query string
    const [pathPart, ...queryParts] = pathAndQuery.split(/[?#]/);
    const hasQueryOrDynamic = queryParts.length > 0 || 
      /cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)/.test(pathPart);
    
    // If there are dynamic hints or query strings, just return with upgraded scheme
    if (hasQueryOrDynamic) {
      return match;
    }
    
    // Rewrite host to docs.example.com
    return `${protocol}docs.${host}${pathAndQuery}`;
  });
  
  return result;
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month (basic validation, not accounting for leap years in detail)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // February set to 29 for simplicity
  
  if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}
