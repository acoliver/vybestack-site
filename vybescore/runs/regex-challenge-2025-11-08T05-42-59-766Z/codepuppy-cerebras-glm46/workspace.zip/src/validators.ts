export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that follows RFC standards with practical constraints
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for common issues
  // No consecutive dots
  if (value.includes('..')) return false;
  
  // No dot at start or end of local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // No dot at start or end of domain
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Domain segments must be valid
  const domainSegments = domain.split('.');
  for (const segment of domainSegments) {
    if (segment.length === 0) return false;
    if (segment.startsWith('-') || segment.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all separators and spaces
  const cleanNumber = value.replace(/[\s\-\(\)]/g, '');
  
  // Must be at least 10 digits after cleaning
  if (cleanNumber.length < 10) return false;
  
  // Handle optional +1 prefix
  let numberWithoutCountry;
  if (cleanNumber.startsWith('+1')) {
    numberWithoutCountry = cleanNumber.substring(2);
  } else if (cleanNumber.startsWith('1') && cleanNumber.length > 10) {
    numberWithoutCountry = cleanNumber.substring(1);
  } else {
    numberWithoutCountry = cleanNumber;
  }
  
  // Must be exactly 10 digits for US number
  if (numberWithoutCountry.length !== 10) return false;
  
  // Check if all are digits
  if (!/^\d{10}$/.test(numberWithoutCountry)) return false;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = numberWithoutCountry.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = numberWithoutCountry.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers supporting landlines and mobiles.
 * Handles formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for pattern matching
  const cleanNumber = value.replace(/[\s\-]/g, '');
  
  // Main regex pattern for Argentine phone numbers
  // Optional +54 country code, optional 0 trunk prefix, optional 9 for mobile, area code (2-4 digits), subscriber (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0?)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanNumber.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits, leading digit 1-9 (already enforced by regex)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits (already enforced by regex)
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  // If no country code, must start with trunk prefix 0
  if (!cleanNumber.startsWith('+54') && !cleanNumber.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmedName = value.trim();
  
  // Cannot be empty
  if (trimmedName.length === 0) return false;
  
  // Name regex: allows unicode letters (including accents), apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}’'\-\s]+$/u;
  
  if (!nameRegex.test(trimmedName)) return false;
  
  // Reject names with consecutive spaces or hyphens/apostrophes
  if (trimmedName.includes('  ') || trimmedName.includes('--') || trimmedName.includes("''") || trimmedName.includes("’’")) {
    return false;
  }
  
  // Cannot start or end with space, hyphen, or apostrophe
  if (/^[\s\-'’]/.test(trimmedName) || /[\s\-'’]$/.test(trimmedName)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(trimmedName)) return false;
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx with prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanCard = value.replace(/[\s\-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanCard)) return false;
  
  // Check Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{14})|(2[2-7]\d{13})|(222[1-9]\d{12})|(22[3-9]\d{13})|(2[3-6]\d{14})|(27[01]\d{13})|(2720\d{12}))$/;
  
  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card type
  if (!visaRegex.test(cleanCard) && !mastercardRegex.test(cleanCard) && !amexRegex.test(cleanCard)) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleanCard);
}
