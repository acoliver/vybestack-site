/**
 * Finds words starting with the prefix but excluding the exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape any special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'g');
  
  // Find all words with the prefix
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => word.toLowerCase() === exception.toLowerCase())
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token after a digit using positive lookbehind
  const tokenPattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches = [...text.matchAll(tokenPattern)];
  
  // Return the full match with the digit included
  return matches.map(match => {
    const index = match.index || 0;
    // Go back one character to include the digit
    return index > 0 ? text.slice(index - 1, index + match[0].length) : match[0];
  });
}

/**
 * Validates passwords according to the policy.
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab)
  if (/(.{2,})\1+/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern (including shorthand with ::)
  // Comprehensive pattern that handles full IPv6, compressed, and mixed formats
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|::|(?:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::(?:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?/;
  
  return ipv6Pattern.test(value);
}