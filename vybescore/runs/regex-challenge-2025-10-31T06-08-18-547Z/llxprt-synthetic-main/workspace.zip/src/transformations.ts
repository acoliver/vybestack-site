/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split text into sentences while preserving delimiters
  const parts = text.split(/([.?!])/);
  
  let result = '';
  
  for (let i = 0; i < parts.length; i += 2) {
    // Sentence part
    const sentence = parts[i];
    // Delimiter part
    const delimiter = parts[i + 1];
    
    if (sentence && sentence.length > 0) {
      // Get the first character and capitalize it
      // Make sure to preserve the original spacing within the sentence
      const sentenceTrimmed = sentence.trim();
      if (sentenceTrimmed.length > 0) {
        const capitalized = sentenceTrimmed[0].toUpperCase() + sentenceTrimmed.slice(1);
        
        // Add the whitespace that was originally at the start
        const leadingWhitespace = sentence.match(/^\s*/)?.[0] || '';
        result += leadingWhitespace + capitalized;
      } else {
        result += sentence;
      }
    }
    
    // Add the delimiter if it exists
    if (delimiter) {
      result += delimiter;
      
      // Add a single space between sentences if there's another sentence
      if (i + 2 < parts.length) {
        // Check if the next sentence already starts with whitespace
        const nextSentence = parts[i + 2];
        if (nextSentence && !nextSentence.match(/^\s/)) {
          result += ' ';
        }
      }
    }
  }
  
  return result;
}

/**
 * Finds URLs in the text, returning them as an array.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern to match http/https URLs
  const urlPattern = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs to use https and moves docs paths to docs.example.com.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs and their path
  const exampleUrlPattern = /(http:\/\/example\.com)(\/\S*)?/g;
  
  return text.replace(exampleUrlPattern, (match, domain, path = '') => {
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      return `https://docs.example.com${path}`;
    }
    
    // Check for dynamic hints or legacy extensions in the path
    if (path.match(/\/(cgi-bin|\?.*=.*|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/)) {
      // Skip host rewrite, just upgrade protocol
      return `https://example.com${path}`;
    }
    
    // Default: just upgrade the protocol
    return `https://example.com${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 */
export function extractYear(value: string): string {
  // Check if the value matches mm/dd/yyyy pattern
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (match) {
    return match[3]; // Return the year part
  }
  
  return 'N/A';
}