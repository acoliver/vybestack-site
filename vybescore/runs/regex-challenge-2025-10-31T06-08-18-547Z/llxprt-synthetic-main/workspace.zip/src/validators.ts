export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // - Allows standard characters in local part including + for tags
  // - Rejects double dots, trailing dots
  // - Domain cannot start or end with hyphen, cannot contain underscores
  // - Top-level domain must be at least 2 characters
  const emailRegex = /^(?!\.)(?!.*\.\.)[a-zA-Z0-9+._%+-]+(?<!\.)@[a-zA-Z0-9](?:(?!-)[a-zA-Z0-9-]*[^-])?\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits without country code, 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false;
  }
  
  // Extract area code (first 3 digits after removing country code if present)
  const areaCode = digitsOnly.length === 11 ? digitsOnly.substring(1, 4) : digitsOnly.substring(0, 4);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check for valid phone number pattern
  const phonePattern = /^\+?1?\s*\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/;
  
  return phonePattern.test(value);
}

/**
 * Validates Argentine phone numbers.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except the leading + for country code
  const digitsOnly = value.replace(/[^\d+]/g, '');
  
  // Basic regex for Argentine phone numbers
  // Optional +54 prefix, optional 0 trunk prefix, optional 9 for mobile
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  
  return argentinePhoneRegex.test(digitsOnly);
}

/**
 * Validates personal names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}''’-]+(?:\s[\p{L}\p{M}''’-]+)*$/u;
  
  return nameRegex.test(value);
}

/**
 * Helper function for Luhn algorithm.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Starting from the rightmost digit, double every second digit
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check card prefixes and lengths
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card number matches any of the valid patterns
  const isValidFormat = visaRegex.test(digitsOnly) || 
                        mastercardRegex.test(digitsOnly) || 
                        amexRegex.test(digitsOnly);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn algorithm to validate the checksum
  return runLuhnCheck(digitsOnly);
}
