/**
 * Validate Base64 input according to the canonical Base64 alphabet.
 * Throws an error if the input contains invalid characters.
 * Accepts valid Base64 with or without padding.
 */
function validateBase64Input(input: string): void {
  // Remove padding for validation
  const unpadded = input.replace(/=+$/, '');

  // Check if the string is empty after removing padding
  if (unpadded.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Check length: with proper padding, total length must be multiple of 4
  if (input.includes('=') && input.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: invalid length with padding');
  }
  // For unpadded input, the character validation and round-trip validation in decode()
  // are sufficient to detect invalid payloads

  // Canonical Base64 alphabet: A-Z, a-z, 0-9, +, /
  // Also allow padding '=' at the end
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;

  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for invalid padding placement
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const afterPadding = input.slice(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: padding characters in wrong position');
    }
    // Valid padding is 1 or 2 '=' characters
    if (afterPadding.length > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }
}

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  // Use standard 'base64' encoding which includes proper padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the input before attempting to decode
  validateBase64Input(trimmed);

  try {
    // Use standard 'base64' encoding for decoding
    const buffer = Buffer.from(trimmed, 'base64');

    // Check if the decode actually succeeded by verifying the buffer is not empty
    // for non-empty input
    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    // Additional validation: verify that re-encoding produces valid base64
    // This catches cases where input looks like base64 but decodes to garbage
    const reEncoded = buffer.toString('base64');
    // Compare after normalizing padding
    const normalizedInput = trimmed.replace(/=+$/, '');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReEncoded && trimmed.length >= 4) {
      // If round-trip fails, the input was likely invalid
      throw new Error('Invalid Base64 input: failed round-trip validation');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
