/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<Subject<unknown>>
  cleanup?: UnsubscribeFn
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: Observer<any> | undefined
  observers?: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Clear existing dependencies before tracking new ones
    if (observer.dependencies) {
      observer.dependencies.clear()
    }
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: Subject<unknown>): void {
  if (subject.observer) {
    updateObserver(subject.observer as Observer<any>)
  }
  
  if (subject.observers) {
    const observers = [...subject.observers]
    for (const observer of observers) {
      updateObserver(observer as Observer<any>)
    }
  }
}

export function addObserver<T>(subject: Subject<T>, observer: Observer<any>): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function removeObserver<T>(subject: Subject<T>, observer: Observer<any>): void {
  if (subject.observers) {
    subject.observers.delete(observer)
  }
}
