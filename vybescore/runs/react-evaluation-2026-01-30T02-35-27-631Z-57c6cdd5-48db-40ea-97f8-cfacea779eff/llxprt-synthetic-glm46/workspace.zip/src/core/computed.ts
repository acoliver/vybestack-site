/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  addObserver,
  removeObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Set up this computed as an observer
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Create the subject that represents this computed value
  const subject: Subject<T> = {
    name: options?.name,
    observer,
    value: value || updateFn(value),
    equalFn: equal === true ? (a: T, b: T) => a === b : 
             equal === false ? undefined :
             typeof equal === 'function' ? equal : undefined,
  }
  
  // Track computed dependencies when they're accessed
  let computing = false
  
  // Create a getter that registers dependencies when accessed
  const getter: GetterFn<T> = () => {
    // If there's an active observer, add this computed as a dependency
    const currentObserver = getActiveObserver()
    if (currentObserver && !computing) {
      // Add this computed as a dependency to the current observer
      if (currentObserver.dependencies) {
        currentObserver.dependencies.add(subject)
      }
    }
    
    return subject.value
  }
  
  // Wrap the update function to track dependencies and notify changes
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    if (computing) return subject.value
    computing = true
    
    try {
      // Clear existing dependencies before tracking new ones
      if (observer.dependencies) {
        // Remove from existing dependencies
        observer.dependencies.forEach(dep => {
          removeObserver(dep, observer as Observer<unknown>)
        })
        observer.dependencies.clear()
      }
      
      // Run the original update function
      const newValue = originalUpdateFn(prevValue)
      
      // Check if the value actually changed
      const hasChanged = subject.equalFn ? !subject.equalFn(subject.value!, newValue) : true
      if (hasChanged) {
        subject.value = newValue
        
        // Notify observers of this computed value
        if (subject.observers) {
          const observers = [...subject.observers]
          for (const obs of observers) {
            updateObserver(obs as Observer<unknown>)
          }
        }
      }
      
      return newValue
    } finally {
      computing = false
    }
  }
  
  // Register as observer to track dependencies
  updateObserver(observer)
  
  // Register as observer of dependencies found during initialization
  if (observer.dependencies) {
    observer.dependencies.forEach(dep => {
      addObserver(dep, observer as Observer<unknown>)
    })
  }
  
  return getter
}
