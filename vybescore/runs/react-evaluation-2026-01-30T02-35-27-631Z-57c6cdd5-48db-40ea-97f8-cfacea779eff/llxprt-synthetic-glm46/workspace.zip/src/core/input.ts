/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(s, observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = equalFn ? !equalFn(s.value, nextValue) : true
    if (hasChanged) {
      s.value = nextValue
      if (s.observer) updateObserver(s.observer as Observer<unknown>)
      
      // Use notifyObservers to propagate changes
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
