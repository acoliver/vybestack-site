/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, removeObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Execute the callback to track dependencies
  updateObserver(observer)
  
  let disposed = false
  const unsubscribes: UnsubscribeFn[] = []
  
  // Keep track of cleanup functions
  const cleanup = () => {
    unsubscribes.forEach(unsub => unsub())
    unsubscribes.length = 0
  }
  
  // Store cleanup function
  observer.cleanup = cleanup
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Cleanup all related subscriptions and observers
    if (observer.cleanup) {
      observer.cleanup()
    }
    
    // Remove from all dependencies
    if (observer.dependencies) {
      observer.dependencies.forEach(subject => {
        removeObserver(subject, observer as Observer<unknown>)
      })
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    observer.cleanup = undefined
  }
  
  // Store this cleanup for later
  unsubscribes.push(unsubscribe)
  
  // Add this callback as an observer to all its dependencies
  if (observer.dependencies) {
    observer.dependencies.forEach(subject => {
      if (!subject.observers) {
        subject.observers = new Set()
      }
      subject.observers.add(observer as Observer<unknown>)
    })
  }
  
  return unsubscribe
}
