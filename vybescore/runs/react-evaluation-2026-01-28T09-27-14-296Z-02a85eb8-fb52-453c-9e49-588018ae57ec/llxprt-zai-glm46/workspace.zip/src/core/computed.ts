/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  updateObserver(o)
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of the active observer
      o.observers = o.observers || []
      if (!o.observers.includes(observer)) {
        o.observers.push(observer)
      }
    }
    return o.value!
  }
  
  return getter
}
