/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle line breaks first - treat them as sentence boundaries
  let processedText = text.replace(/([.!?])\s*\n\s*/g, '$1 ');
  
  // Collapse multiple spaces into single spaces
  processedText = processedText.replace(/\s+/g, ' ');
  
  // Capitalize first letter of sentences
  processedText = processedText.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize first character of the whole text
  if (processedText.length > 0) {
    processedText = processedText[0].toUpperCase() + processedText.slice(1);
  }
  
  return processedText.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s]+/gi;
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  return matches.map(match => {
    // Remove trailing punctuation but keep query parameters
    return match.replace(/[,.!?;:)(]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  const httpRegex = /http:\/\//gi;
  return text.replace(httpRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  let result = text.replace(/http:\/\//gi, 'https://');
  
  // Simple regex to replace docs URLs
  result = result.replace(
    /https:\/\/example\.com(\/docs\/[^?&\s]*)/g,
    'https://docs.example.com$1'
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(value);
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // More specific day validation based on month
  if (month === 2 && day > 29) return 'N/A'; // February
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) return 'N/A'; // 30-day months
  
  return year;
}
