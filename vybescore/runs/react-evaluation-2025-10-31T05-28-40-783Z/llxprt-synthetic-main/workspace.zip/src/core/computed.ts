/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  GetterFn, 
  UpdateFn,
  EqualFn,
  registerSubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> = equal === true
    ? (lhs, rhs) => {
      try {
        return JSON.stringify(lhs) === JSON.stringify(rhs)
      } catch {
        return lhs === rhs
      }
    }
    : equal === false || equal === undefined
    ? (lhs, rhs) => lhs === rhs
    : equal

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  }

  // Register the subject globally
  registerSubject(s)

  // Observer that recalculates the computed value
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev) => {
      // Recalculate value based on dependencies
      const nextValue = updateFn(prev)
      const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
      if (shouldUpdate) {
        s.value = nextValue
      }
      return nextValue
    },
  }

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
    }
    
    return s.value
  }

  // Initial computation to track dependencies
  updateObserver(o)

  return getter
}