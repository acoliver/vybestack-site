/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerSubject,
  subjects
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> = equal === true
    ? (lhs, rhs) => {
      try {
        return JSON.stringify(lhs) === JSON.stringify(rhs)
      } catch {
        return lhs === rhs
      }
    }
    : equal === false || equal === undefined
    ? (lhs, rhs) => lhs === rhs
    : equal

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Register the subject globally
  registerSubject(s)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (!shouldUpdate) return s.value
    
    s.value = nextValue
    
    // Notify all dependent observers
    notifyObservers(s as Subject<unknown>)
    
    return s.value
  }

  return [read, write]
}

// Function to notify all dependent observers
function notifyObservers(subject: Subject<unknown>): void {
  // Direct observer notification
  if (subject.observer) {
    updateObserver(subject.observer)
  }
  
  // Find all computed subjects that depend on this subject
  subjects.forEach(s => {
    if (s !== subject && s.observer) {
      updateObserver(s.observer)
    }
  })
}