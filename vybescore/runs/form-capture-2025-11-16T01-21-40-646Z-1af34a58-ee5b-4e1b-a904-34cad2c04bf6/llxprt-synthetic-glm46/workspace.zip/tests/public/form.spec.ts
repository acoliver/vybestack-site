import { describe, expect, it, afterAll, beforeAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { exec } from 'child_process';
import { promisify } from 'util';

const execAsync = promisify(exec);
const dbPath = path.resolve('data', 'submissions.sqlite');

let serverProcess: ReturnType<typeof exec> | null = null;

beforeAll(async () => {
  // Ensure the database directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Copy templates to the dist directory for the test server
  await execAsync('cp -r src/templates dist/');
  
  // Copy CSS to the dist directory for the test server
  await execAsync('cp public/styles.css dist/');
  
  // Start the server
  serverProcess = exec('node dist/server.js');
  
  // Wait for server to start
  await new Promise(resolve => setTimeout(resolve, 3000));
});

afterAll(() => {
  if (serverProcess) {
    serverProcess.kill();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});
describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      first_name: 'John',
      last_name: 'Doe', 
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567'
    };
    
    // Submit the form and debug response if it fails
    try {
      await request('http://localhost:3535')
        .post('/submit')
        .type('form')
        .send(formData)
        .expect(302);
    } catch (error: unknown) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      console.error('Form submission failed:', errorMessage);
      // Try to get error details
      const response = await request('http://localhost:3535')
        .post('/submit')
        .type('form')
        .send(formData);
      
      console.log('Response status:', response.status);
      console.log('Response text:', response.text);
      throw error;
    }
    
    // Check that the thank-you page is accessible
    const response = await request('http://localhost:3535')
      .get('/thank-you')
      .expect(200);
    
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('friendly messages');
  });
});

afterAll(() => {
  if (serverProcess) {
    serverProcess.kill();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});
