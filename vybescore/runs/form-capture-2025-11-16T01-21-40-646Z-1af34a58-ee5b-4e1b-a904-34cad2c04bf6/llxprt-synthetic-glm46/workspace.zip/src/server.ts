import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any = null;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const sqljsModule: any = await import('sql.js');
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const initSqlJs: any = sqljsModule.default;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SQL: any = await initSqlJs();
    
    let dbBuffer: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(dbFile);
    }
    
    db = new SQL.Database(dbBuffer || undefined);
    
    if (!dbBuffer) {
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
      db.run(schema);
      console.log('Database initialized with schema');
    } else {
      console.log('Database loaded from existing file');
    }
    
    saveDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateForm(formData: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!formData.first_name?.trim()) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }
  
  if (!formData.last_name?.trim()) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }
  
  if (!formData.street_address?.trim()) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }
  
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!formData.state_province?.trim()) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }
  
  if (!formData.postal_code?.trim()) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  }
  
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^[+]?\d[\d\s\-()]*$/.test(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  return errors;
}

function insertSubmission(formData: FormData): void {
  if (!db) throw new Error('Database not initialized');
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const stmt: any = db.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.first_name,
    formData.last_name,
    formData.street_address,
    formData.city,
    formData.state_province,
    formData.postal_code,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();
  saveDatabase();
}

app.use(express.urlencoded({ extended: true }));

app.use(express.static(path.join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

app.get('/', (req, res) => {
  res.render('form', { error: null, formData: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    first_name: req.body.first_name,
    last_name: req.body.last_name,
    street_address: req.body.street_address,
    city: req.body.city,
    state_province: req.body.state_province,
    postal_code: req.body.postal_code,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    res.status(400).render('form', { 
      error: errors, 
      formData: req.body 
    });
    return;
  }
  
  try {
    insertSubmission(formData);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to insert submission:', error);
    res.status(500).render('form', { 
      error: [{ field: 'general', message: 'Server error. Please try again.' }], 
      formData: req.body 
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (db) {
    db.close();
  }
  process.exit(0);
});

async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (db) {
    console.log('Closing database');
    db.close();
  }
  process.exit(0);
});

startServer().catch(console.error);
