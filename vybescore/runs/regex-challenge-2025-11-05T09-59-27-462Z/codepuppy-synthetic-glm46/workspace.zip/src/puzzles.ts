/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary pattern for prefixed words
  const wordRegex = new RegExp(`\\b${escapedPrefix}[\\w-]*`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and duplicates
  const filteredMatches = matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => exception.toLowerCase() === lowerMatch);
  });
  
  // Return unique matches only
  return Array.from(new Set(filteredMatches));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\\\\]/g, '\\$&');
  
  // Match digit followed by token, but not at the beginning
  // Return the full match including the digit  
  const tokenRegex = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  // Return unique matches
  return Array.from(new Set(matches));
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, aaaa, etc.)
  // Look for patterns of 2+ characters repeated immediately
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that handles various formats including shorthand ::
  // This is comprehensive but not overly complex
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b|\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b|\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b|\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})\b|\b:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)\b/;
  
  // IPv4 regex pattern to exclude
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // First check if there's an IPv4 address - if so, don't count it as IPv6
  if (ipv4Regex.test(value)) {
    // Check if there are IPv6 addresses that are not part of IPv4-mapped IPv6
    const ipv6Matches = value.match(ipv6Regex) || [];
    const ipv4Matches = value.match(ipv4Regex) || [];
    
    // Filter out any IPv6 matches that might actually be IPv4-mapped
    const pureIPv6Matches = ipv6Matches.filter(ipv6 => {
      return !ipv4Matches.some(ipv4 => ipv6.includes(ipv4));
    });
    
    return pureIPv6Matches.length > 0;
  }
  
  // No IPv4 found, just check for IPv6
  return ipv6Regex.test(value);
}