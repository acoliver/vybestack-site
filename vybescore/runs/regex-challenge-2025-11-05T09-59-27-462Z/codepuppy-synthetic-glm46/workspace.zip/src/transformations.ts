/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Split text by sentence endings (. ? !) followed by optional spaces
  // Keep the delimiters for reconstruction
  const sentences = text.split(/([.?!]\s*)/);
  
  let result = '';
  let capitalizeNext = true; // Start with capitalizing the first character
  
  for (let i = 0; i < sentences.length; i++) {
    let part = sentences[i];
    
    if (part.match(/^[.?!]\s*$/)) {
      // This is just punctuation and spaces, add as-is and capitalize next character
      result += part;
      capitalizeNext = true;
    } else if (part.trim()) {
      // This is content that needs processing
      if (capitalizeNext) {
        // Capitalize first character and lowercase the rest of the first word
        part = part.charAt(0).toUpperCase() + part.slice(1).toLowerCase();
        capitalizeNext = false;
      }
      result += part;
    } else {
      // This is just spaces, add as-is
      result += part;
      capitalizeNext = true;
    }
  }
  
  // Normalize spaces: ensure exactly one space after sentences if there are spaces
  result = result.replace(/([.?!])\s+/g, '$1 ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern that matches http(s), ftp, and other common protocols
  // Also matches www domains without protocol
  const urlRegex = /\b((?:https?|ftp):\/\/[^\s/$.?#].[^\s]*)|\b(?:www\.)[^\s/$.?#].[^\s]*/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation but not part of the URL
  return matches.map(url => {
    // Remove trailing punctuation like .,;:!? but keep characters that can be part of URLs
    return url.replace(/[.,;:!?\]\)}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// but don't touch https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Pattern to match URLs from example.com
  // Captures: 1=protocol, 2=path
  const exampleUrlRegex = /\b(http:\/\/example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(exampleUrlRegex, (match, protocol, path = '') => {
    // Always upgrade protocol to https
    const secureProtocol = protocol.replace('http://', 'https://');
    
    if (!path) {
      // No path, just upgrade protocol
      return secureProtocol;
    }
    
    // Check if this path should NOT have host rewritten (dynamic content)
    const shouldSkipHostRewrite = /(?:cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path);
    
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      // Rewrite host to docs.example.com
      return `https://docs.example.com${path}`;
    } else {
      // Just upgrade the protocol
      return secureProtocol + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy pattern exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (simple validation, not accounting for leap years in detail)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Special check for February 29 on non-leap years
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    //Leap year if divisible by 4, except centuries not divisible by 400
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return year;
}