export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to run Luhn checksum validation on credit card numbers.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that accepts typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for disallowed patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  const localPart = value.split('@')[0];
  const domain = value.split('@').slice(1).join('@');
  
  // Domain cannot contain underscores or start/end with hyphen
  if (domain.includes('_') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Local part cannot end with dot
  if (localPart.endsWith('.')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check length constraints
  if (digits.length < 10) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Must be exactly 10 digits for US number
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Valid separators: spaces, hyphens, parentheses
  const validFormat = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return validFormat.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all separators (spaces and hyphens)
  const clean = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Optional +54, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentineRegex = /^(\+54)?(9)?(0)?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentineRegex.test(clean)) return false;
  
  // If no country code, must start with trunk prefix 0
  if (!clean.startsWith('+54') && !clean.startsWith('0')) return false;
  
  // Extract parts for validation
  let numericPart = clean;
  
  if (numericPart.startsWith('+54')) {
    numericPart = numericPart.slice(3); // Remove +54
  }
  
  if (numericPart.startsWith('0')) {
    numericPart = numericPart.slice(1); // Remove 0
  }
  
  if (numericPart.startsWith('9')) {
    numericPart = numericPart.slice(1); // Remove 9
  }
  
  // Find area code by trying different lengths (2-4 digits)
  let areaCodeEnd = 2;
  for (let i = 2; i <= 4; i++) {
    if (numericPart.length - i >= 6 && numericPart.length - i <= 8) {
      areaCodeEnd = i;
      break;
    }
  }
  
  const areaCode = numericPart.substring(0, areaCodeEnd);
  const subscriberNumber = numericPart.substring(areaCodeEnd);
  
  // Area code validation
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  return nameRegex.test(value) && hasLetter;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length based on card type
  if (digits.length !== 13 && digits.length !== 15 && digits.length !== 16) {
    return false;
  }
  
  // Check prefixes for different card types
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  let validPrefix = false;
  
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16)) {
    validPrefix = true; // Visa
  } else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    validPrefix = true; // American Express
  } else if (digits.length === 16) {
    // Mastercard
    const firstTwo = parseInt(digits.substring(0, 2), 10);
    const firstFour = parseInt(digits.substring(0, 4), 10);
    
    if ((firstTwo >= 51 && firstTwo <= 55) || (firstFour >= 2221 && firstFour <= 2720)) {
      validPrefix = true;
    }
  }
  
  if (!validPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}