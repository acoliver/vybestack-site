#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { type ReportData, type RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): { inputFile: string; options: CliOptions } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const options: CliOptions = {
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        options.format = args[++i];
        break;
      case '--output':
        options.outputPath = args[++i];
        break;
      case '--includeTotals':
        options.includeTotals = true;
        break;
    }
  }
  
  if (!options.format) {
    console.error('Missing required argument: --format');
    process.exit(1);
  }
  
  return { inputFile, options };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON data structure');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid title field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid entries field');
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: not an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Missing or invalid entry label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Missing or invalid entry amount');
    }
  }
  
  return data as ReportData;
}

function main() {
  try {
    const { inputFile, options } = parseArguments();
    
    let data;
    try {
      const fileContent = readFileSync(inputFile, { encoding: 'utf8' });
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof Error && error.message.includes('ENOENT')) {
        console.error(`File not found: ${inputFile}`);
        process.exit(1);
      } else if (error instanceof SyntaxError) {
        console.error(`Invalid JSON in file: ${inputFile}`);
        process.exit(1);
      } else {
        throw error;
      }
    }
    
    const reportData = validateReportData(data);
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals,
    };
    
    let output: string;
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(reportData, renderOptions);
        break;
      case 'text':
        output = renderText(reportData, renderOptions);
        break;
      default:
        console.error(`Unsupported format: ${options.format}`);
        process.exit(1);
    }
    
    if (options.outputPath) {
      writeFileSync(options.outputPath, output, { encoding: 'utf8' });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
