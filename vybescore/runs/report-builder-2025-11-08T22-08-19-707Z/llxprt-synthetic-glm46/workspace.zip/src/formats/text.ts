import { type ReportData, type RenderOptions, type ReportFormatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export const renderText: ReportFormatter = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  
  // List entries
  data.entries.forEach((entry) => {
    const formattedAmount = formatAmount(entry.amount);
    lines.push(`- ${entry.label}: ${formattedAmount}`);
  });

  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = formatAmount(total);
    lines.push(`\nTotal: ${formattedTotal}`);
  }

  return lines.join('\n');
};