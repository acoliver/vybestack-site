import express from 'express';
import { readFileSync, writeFileSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// Get __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

// Type definitions for sql.js
interface Database {
  export: () => Uint8Array;
  run: (sql: string, params?: unknown[]) => void;
  prepare: (sql: string) => Statement;
  close: () => void;
}

interface Statement {
  run: (...params: unknown[]) => void;
  get: (...params: unknown[]) => unknown;
  all: (...params: unknown[]) => unknown[];
  free: () => void;
}

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Set up middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, '../public')));

// Set EJS as rendering engine
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));
let db: Database | null = null;

// Initialize database
async function initDatabase(): Promise<Database> {
  const dbPath = join(__dirname, '../../data/submissions.sqlite');
  let dbBuffer: Uint8Array;

  try {
    const dbFile = readFileSync(dbPath);
    dbBuffer = new Uint8Array(dbFile);
  } catch (error) {
    // File doesn't exist, create empty buffer
    dbBuffer = new Uint8Array(0);
  }

  // Use sql.js dynamically import
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const initSqlJs = await import('sql.js') as any;
  const SQL = await initSqlJs.default();
  const database = new SQL.Database(dbBuffer) as Database;
  
  // Create the submissions table if it doesn't exist
  database.run(`
    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT,
      last_name TEXT,
      street_address TEXT,
      city TEXT,
      state_province TEXT,
      postal_code TEXT,
      country TEXT,
      email TEXT,
      phone TEXT,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    )
  `);

  return database;

  return database;
}

// Save database to disk
function saveDatabase(database: Database): void {
  const dbPath = join(__dirname, '../../data/submissions.sqlite');
  const dbBuffer = database.export();
  
  try {
    writeFileSync(dbPath, Buffer.from(dbBuffer));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Form validation function
function validateForm(formData: Record<string, string>): { errors: Record<string, string>; valid: boolean } {
  const errors: Record<string, string> = {};

  // Check required fields
  const required = [
    'first_name', 'last_name', 'street_address', 
    'city', 'state_province', 'postal_code', 'country', 
    'email', 'phone'
  ];

  for (const field of required) {
    if (!formData[field] || formData[field].trim() === '') {
      errors[field] = `${field.replace('_', ' ')} is required`;
    }
  }

  // Email validation (simple regex)
  if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (can contain digits, spaces, parentheses, dashes, and a leading @)
  if (formData.phone && !/^(@|\+)?[0-9\-\s()]+$/.test(formData.phone)) {
    errors.phone = 'Phone number may contain digits, spaces, parentheses, dashes, and a leading @';
  }

  // Postal code validation (can contain letters and numbers)
  if (formData.postal_code && !/^[a-zA-Z0-9\s]+$/.test(formData.postal_code)) {
    errors.postal_code = 'Postal code may contain letters and numbers';
  }

  return {
    errors,
    valid: Object.keys(errors).length === 0,
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {},
    formData: {},
    submitted: false
  });
});

app.post('/submit', (req, res) => {
  const validationResult = validateForm(req.body);
  
  if (!validationResult.valid) {
    return res.status(400).render('form', {
      errors: validationResult.errors,
      formData: req.body,
      submitted: false
    });
  }

  // Insert into database
  const stmt = db!.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  if (!db) {
    throw new Error('Database is not initialized');
  }
  
  // Debug what we're inserting
  const values = [
    req.body.first_name || '(empty)',
    req.body.last_name || '(empty)',
    req.body.street_address || '(empty)',
    req.body.city || '(empty)',
    req.body.state_province || '(empty)',
    req.body.postal_code || '(empty)',
    req.body.country || '(empty)',
    req.body.email || '(empty)',
    req.body.phone || '(empty)'
  ];
  console.log('Values to insert:', values);
  
  stmt.run(values);
  stmt.free();

  // Save database
  saveDatabase(db!);

  // Redirect to thank you page
  return res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Start server
async function startServer() {
  db = await initDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  function shutdown() {
    console.log('Shutting down gracefully...');
    if (db) {
      db.close();
      db = null;
    }
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  }

  // Handle process signals
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return server;
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
