declare module 'sql.js' {
  export interface Database {
    export: () => Uint8Array;
    run: (sql: string, params?: unknown[]) => void;
    prepare: (sql: string) => Statement;
    close: () => void;
  }

  export interface Statement {
    run: (...params: unknown[]) => void;
    get: (...params: unknown[]) => unknown;
    all: (...params: unknown[]) => unknown[];
    free: () => void;
  }

  export function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<{
    Database: new (data?: Uint8Array) => Database;
    STATEMENT: StatementConstructor;
  }>;

  export interface StatementConstructor {
    new (database: Database, sql: string): Statement;
  }

  export default function(options?: { locateFile?: (file: string) => string }): Promise<{
    Database: new (data?: Uint8Array) => Database;
    STATEMENT: StatementConstructor;
  }>;
}