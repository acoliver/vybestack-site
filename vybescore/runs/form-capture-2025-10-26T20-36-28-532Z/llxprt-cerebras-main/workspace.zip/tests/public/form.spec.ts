import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../src/server';
import { Server } from 'http';

let server: Server | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  server = app.listen(0); // 0 lets the OS choose an available port
});

afterAll(() => {
  if (server) {
    server.close();
  }
  
  // Clean up the database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(server).get('/');
    expect(res.status).toBe(200);
    
    const $ = cheerio.load(res.text);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'Anystate',
        postalCode: 'A1B 2C3',
        country: 'Canada',
        email: 'jane.doe@example.com',
        phone: '+1 (555) 123-4567'
      });
    
    expect(res.status).toBe(302);
    expect(res.header.location).toBe('/thank-you?firstName=Jane');
  });
});