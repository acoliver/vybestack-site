import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Database setup
let db: Database;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

const initDB = async () => {
  const SQL = await initSqlJs();
  try {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(new Uint8Array(fileBuffer));
  } catch (error) {
    // Database file doesn't exist, create a new one
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
  }
};

// Form validation
const validateForm = (formData: { 
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}) => {
  const errors: string[] = [];
  
  if (!formData.firstName?.trim()) {
    errors.push('First name is required');
  }
  
  if (!formData.lastName?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  
  if (!formData.city?.trim()) {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push('Postal code is required');
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
    errors.push('Postal code contains invalid characters');
  }
  
  if (!formData.country?.trim()) {
    errors.push('Country is required');
  }
  
  if (!formData.email?.trim()) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push('Email format is invalid');
  }
  
  if (!formData.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!/^[+]?[\d\s\-()]+$/.test(formData.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  return errors;
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: formData });
  }
  
  // Insert into database
  const stmt = db.prepare(
    'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  stmt.free();
  
  // Write database to file
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(formData.firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;
const startServer = async () => {
  await initDB();
  server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
};

process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      // Write database to file before closing
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(dbPath, buffer);
      db.close();
      console.log('Database closed');
      process.exit(0);
    });
  }
});

startServer();

export default app;