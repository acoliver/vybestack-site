import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// sql.js is imported as default export
// @ts-expect-error to resolve compatibility issue
import initSqlJs from 'sql.js';

// Type definitions for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string | undefined;
}

// Type definitions for the database
interface Database {
  run(sql: string, params?: unknown[]): void;
  prepare(sql: string): {
    run(params: unknown[]): void;
    free(): void;
  };
  exec(sql: string): { values: unknown[][] }[];
  export(): Uint8Array;
  close(): void;
}

// Get the current directory for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

class AppServer {
  private app: express.Application;
  private server: ReturnType<typeof this.app.listen> | null = null;
  private db: Database | null = null;
  private isShuttingDown = false;
  private readonly port = process.env.PORT || 3000;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
      
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create a new one
      if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath);
        this.db = new SQL.Database(fileBuffer) as Database;
      } else {
        this.db = new SQL.Database() as Database;
        
        // Create the table using the schema
        const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        this.db!.run(schema);
        
        // Initial save to create the file
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    try {
      const data = this.db!.export();
      const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    
    // Serve static files
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    
    // Set EJS as the view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private validateForm(formData: FormData): FormErrors {
    const errors: FormErrors = {};
    
    // Required field validation
    if (!formData.firstName.trim()) {
      errors.firstName = 'First name is required';
    }
    
    if (!formData.lastName.trim()) {
      errors.lastName = 'Last name is required';
    }
    
    if (!formData.streetAddress.trim()) {
      errors.streetAddress = 'Street address is required';
    }
    
    if (!formData.city.trim()) {
      errors.city = 'City is required';
    }
    
    if (!formData.stateProvince.trim()) {
      errors.stateProvince = 'State / Province / Region is required';
    }
    
    if (!formData.postalCode.trim()) {
      errors.postalCode = 'Postal / Zip code is required';
    }
    
    if (!formData.country.trim()) {
      errors.country = 'Country is required';
    }
    
    // Email validation - simple regex is sufficient
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    } else if (!emailRegex.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }
    
    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!formData.phone.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!phoneRegex.test(formData.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
    
    return errors;
  }

  private setupRoutes(): void {
    // Home route - display the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        title: 'Friendly Contact Form',
        errors: [],
        values: {},
      });
    });

    // Submit route - process form data
    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || '',
      };

      const errors = this.validateForm(formData);
      const hasErrors = Object.keys(errors).length > 0;

      if (hasErrors) {
        return res.status(400).render('form', {
          title: 'Friendly Contact Form',
          errors: Object.values(errors),
          values: formData,
        });
      }

      try {
        // Insert into database
        const stmt = this.db!.prepare(`
          INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone,
        ]);

        stmt.free();
        
        // Save the database to disk
        this.saveDatabase();
        
        // Redirect to thank you page
        return res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        return res.status(500).render('form', {
          title: 'Friendly Contact Form',
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData,
        });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // Get the most recent submission to extract the first name
      try {
        const result = this.db!.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
        let firstName = 'friend';
        
        if (result[0] && result[0].values && result[0].values[0] && result[0].values[0][0]) {
          firstName = result[0].values[0][0] as string;
        }
        
        res.render('thank-you', {
          title: 'Thank You!',
          firstName,
        });
      } catch (error) {
        console.error('Database error:', error);
        res.render('thank-you', {
          title: 'Thank You!',
          firstName: 'friend',
        });
      }
    });

    // Handle 404
    this.app.use((req: Request, res: Response) => {
      res.status(404).send('Page not found');
    });

    // Error handling middleware
    this.app.use((err: Error, _req: Request, res: Response) => {
      console.error(err.stack);
      res.status(500).send('Something went wrong!');
    });
  }

  public async start(): Promise<void> {
    try {
      await this.initializeDatabase();
      this.server = this.app.listen(this.port, () => {
        console.log(`Server running on port ${this.port}`);
      });

      // Graceful shutdown handlers
      process.on('SIGTERM', () => this.shutdown());
      process.on('SIGINT', () => this.shutdown());
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  private shutdown(): void {
    if (this.isShuttingDown) return;
    this.isShuttingDown = true;

    console.log('Shutting down server...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
        
        if (this.db) {
          this.db.close();
          console.log('Database connection closed');
        }
        
        process.exit(0);
      });
    }
  }
}

// Start the server
const server = new AppServer();
server.start().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
