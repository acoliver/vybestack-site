#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData } from '../types/interfaces.js';

interface ParsedArgs {
  _: string[];
  format?: string;
  output?: string;
  includeTotals?: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  const parsed: ParsedArgs = { _: [] };
  
  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      const [key] = arg.split('=');
      
      switch (key) {
        case '--format':
          parsed.format = args[++i];
          break;
        case '--output':
          parsed.output = args[++i];
          break;
        case '--includeTotals':
          parsed.includeTotals = true;
          break;
        default:
          // Unknown option, ignore it for now
          break;
      }
    } else {
      parsed._.push(arg);
    }
  }
  
  return parsed;
}

function validateInput(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON input');
  }
  
  const objData = data as Record<string, unknown>;
  
  if (!objData.title || typeof objData.title !== 'string') {
    throw new Error('Missing or invalid "title" field');
  }
  
  if (!objData.summary || typeof objData.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field');
  }
  
  if (!objData.entries || !Array.isArray(objData.entries)) {
    throw new Error('Missing or invalid "entries" field');
  }
  
  for (let i = 0; i < objData.entries.length; i++) {
    const entry = objData.entries[i] as Record<string, unknown>;
    
    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error(`Entry ${i + 1}: missing or invalid "label" field`);
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error(`Entry ${i + 1}: missing or invalid "amount" field`);
    }
  }
  
  return true;
}

function main(): void {
  const args = process.argv;
  const parsed = parseArgs(args);
  
  // Validate required arguments
  if (parsed._.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = parsed._[0];
  
  if (!parsed.format) {
    console.error('Error: --format parameter is required');
    process.exit(1);
  }
  
  if (parsed.format !== 'markdown' && parsed.format !== 'text') {
    console.error(`Error: Unsupported format "${parsed.format}". Supported formats: markdown, text`);
    process.exit(1);
  }
  
  let data: ReportData;
  
  try {
    const rawData = readFileSync(inputFile, 'utf-8');
    const jsonData = JSON.parse(rawData);
    
    if (!validateInput(jsonData)) {
      process.exit(1);
    }
    
    data = jsonData;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading JSON file: ${error.message}`);
    } else {
      console.error('Error reading JSON file: Invalid JSON format');
    }
    process.exit(1);
  }
  
  let output: string;
  
  if (parsed.format === 'markdown') {
    output = renderMarkdown(data, parsed.includeTotals || false);
  } else {
    output = renderText(data, parsed.includeTotals || false);
  }
  
  if (parsed.output) {
    // Write to file (using synchronous writeFileSync)
    try {
      writeFileSync(parsed.output, output, 'utf-8');
    } catch (writeError) {
      if (writeError instanceof Error) {
        console.error(`Error writing output file: ${writeError.message}`);
      } else {
        console.error('Error writing output file');
      }
      process.exit(1);
    }
  } else {
    // Write to stdout
    process.stdout.write(output);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
