import { ReportData } from '../types/interfaces.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  let output = `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;

  for (const entry of data.entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    output += `- ${entry.label}: ${formattedAmount}\n`;
  }

  if (includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `Total: $${total.toFixed(2)}`;
  }

  return output;
}