import type { ReportData, RenderOptions } from '../types.js';

export function renderText(data: ReportData, options: RenderOptions = {}): string {
  const { includeTotals = false } = options;
  const { title, summary, entries } = data;

  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);

  const lines: string[] = [];
  
  // Title
  lines.push(title);
  lines.push('');
  
  // Summary
  lines.push(summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Entries list
  for (const entry of entries) {
    const amount = `$${entry.amount.toFixed(2)}`;
    lines.push(`- ${entry.label}: ${amount}`);
  }
  
  // Total if requested
  if (includeTotals) {
    const totalAmount = `$${total.toFixed(2)}`;
    lines.push(`Total: ${totalAmount}`);
  }
  
  return lines.join('\n');
}