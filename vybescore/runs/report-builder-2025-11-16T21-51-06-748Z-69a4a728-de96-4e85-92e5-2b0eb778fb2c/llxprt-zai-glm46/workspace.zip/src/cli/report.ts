#!/usr/bin/env node

import fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals?: boolean;
}

function parseArguments(): ParsedArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1];
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format. Supported formats: markdown, text');
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    return false;
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    return false;
  }
  
  if (typeof obj.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(obj.entries)) {
    return false;
  }
  
  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      return false;
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      return false;
    }
  }
  
  return true;
}

function main(): void {
  try {
    const args = parseArguments();
    
    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading or parsing JSON file "${args.dataFile}":`);
      if (error instanceof SyntaxError) {
        console.error('Invalid JSON syntax');
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error('File not found');
      } else {
        console.error(error instanceof Error ? error.message : String(error));
      }
      process.exit(1);
    }
    
    // Validate report data
    if (!validateReportData(jsonData)) {
      console.error('Error: Invalid report data structure');
      console.error('Expected format: { title: string, summary: string, entries: { label: string, amount: number }[] }');
      process.exit(1);
    }
    
    const reportData: ReportData = jsonData;
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };
    
    // Render report
    let output: string;
    if (args.format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else {
      output = renderText(reportData, options);
    }
    
    // Write output
    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
        console.log(`Report written to ${args.outputPath}`);
  } catch (error) {
      console.error(`Error writing to output file "${args.outputPath}":`);
      if (error instanceof Error) {
        console.error(error.message);
      } else {
        console.error(String(error));
      }
      process.exit(1);
    }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error('An unexpected error occurred:');
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error(String(error));
    }
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}