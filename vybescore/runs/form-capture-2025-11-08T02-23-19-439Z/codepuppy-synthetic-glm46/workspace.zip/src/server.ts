import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initDatabase from './db-wrapper.js';

const __filename = fileURLToPath(import.meta.url);

// Database interfaces
interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): any;
  export(): Uint8Array;
  close(): void;
}
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private server: import('http').Server | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    
    // Serve static files from public directory
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    
    // Set EJS as view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private setupRoutes(): void {
    // Home route - display the form
    this.app.get('/', (req: Request, res: Response) => {
      const errors = req.query.errors ? (req.query.errors as string).split('|') : [];
      const values = req.query.values ? JSON.parse(req.query.values as string) : {};
      
      res.render('form', {
        errors,
        values
      });
    });

    // Form submission route
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData = req.body as FormData;
        const validationErrors = this.validateForm(formData);
        
        if (validationErrors.length > 0) {
          const errorMessages = validationErrors.map(e => e.message);
          return res.redirect(`/?errors=${encodeURIComponent(errorMessages.join('|'))}&values=${encodeURIComponent(JSON.stringify(formData))}`);
        }

        // Save to database
        await this.saveSubmission(formData);
        
        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error during form submission:', error);
        const errorMessages = ['An unexpected error occurred. Please try again.'];
        res.redirect(`/?errors=${encodeURIComponent(errorMessages.join('|'))}&values=${encodeURIComponent(JSON.stringify(req.body))}`);
      }
    });

    // Thank you page route
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // Get the most recent submission for personalized message
      const recentSubmission = this.getMostRecentSubmission();
      const firstName = recentSubmission?.first_name || 'Friend';
      
      res.render('thank-you', {
        firstName
      });
    });
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field].trim() === '') {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    }

    // Email validation
    if (data.email && data.email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation - allows international formats
    if (data.phone && data.phone.trim()) {
      const phoneRegex = /^[+]?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({
          field: 'phone',
          message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +'
        });
      }
    }

    // Postal code validation - alphanumeric
    if (data.postalCode && data.postalCode.trim()) {
      const postalRegex: RegExp = /^[\w\s-]+$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({
          field: 'postalCode',
          message: 'Postal code can contain letters, numbers, spaces, and dashes'
        });
      }
    }

    return errors;
  }

  private getFieldDisplayName(field: string): string {
    const displayNames: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return displayNames[field] || field;
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initDatabase();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
        
        // Read and execute schema
        const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf-8');
        this.db!.run(schema);
        
        // Save the newly created database
        this.saveDatabaseToFile();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        data.firstName.trim(),
        data.lastName.trim(),
        data.streetAddress.trim(),
        data.city.trim(),
        data.stateProvince.trim(),
        data.postalCode.trim(),
        data.country.trim(),
        data.email.trim(),
        data.phone.trim()
      ]);
      
      // Save database after each insertion
      this.saveDatabaseToFile();
    } finally {
      stmt.free();
    }
  }

  private getMostRecentSubmission(): { first_name?: string } | null {
    if (!this.db) {
      return null;
    }

    try {
      if (!this.db) return null;
      const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY created_at DESC LIMIT 1');
      const result = stmt.getAsObject([]);
      stmt.free();
      return result;
    } catch (error) {
      console.error('Error fetching recent submission:', error);
      return null;
    }
  }

  private saveDatabaseToFile(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private closeDatabase(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  public async start(): Promise<void> {
    try {
      await this.initializeDatabase();
      
      const port = process.env.PORT || 3000;
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });

      // Handle graceful shutdown
      process.on('SIGTERM', () => this.shutdown());
      process.on('SIGINT', () => this.shutdown());
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  private shutdown(): void {
    console.log('Shutting down server...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('HTTP server closed');
        this.closeDatabase();
        process.exit(0);
      });
    } else {
      this.closeDatabase();
      process.exit(0);
    }
  }

  public getApp(): express.Application {
    return this.app;
  }

  public async initializeDatabaseForTest(): Promise<void> {
    return this.initializeDatabase();
  }
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  server.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default FormServer;