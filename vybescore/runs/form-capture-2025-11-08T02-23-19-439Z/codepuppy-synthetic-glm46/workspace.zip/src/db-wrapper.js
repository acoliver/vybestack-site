/* eslint-disable @typescript-eslint/no-var-requires */
const initSqlJs = require('sql.js');

export async function initDatabase() {
  const SQL = await initSqlJs();
  return SQL;
}