declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): void;
    getAsObject(params?: unknown[]): Record<string, unknown>;
    free(): void;
  }

  export function initSqlJs(): Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;
}