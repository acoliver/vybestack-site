import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import FormServer from '../../src/server.js';

let server: { close(): void };
let app: express.Application;
let formServer: FormServer;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Create and initialize the server
  formServer = new FormServer();
  
  // Manually initialize the database for testing
  await formServer.initializeDatabaseForTest();
  
  app = formServer.getApp();
  server = {
    close: () => {
      // Simulate server close for tests
    }
  };
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    // Debug: check if response has text property
    expect(response.text).toBeDefined();
    const $ = cheerio.load(response.text);
    
    // Check that all required fields are present
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];
    
    for (const field of requiredFields) {
      const input = $(`#${field}`);
      expect(input.length).toBe(1);
      expect(input.attr('name')).toBe(field);
      
      const label = $(`label[for="${field}"]`);
      expect(label.length).toBe(1);
    }
    
    // Check form action and method
    const form = $('form');
    expect(form.attr('action')).toBe('/submit');
    expect(form.attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'Capital Federal',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(submissionData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check thank you page loads
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John');
  });

  it('handles validation errors', async () => {
    const invalidData = {
      firstName: '',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'Capital Federal',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/?errors=');
    
    // Follow redirect to see error messages
    const errorPage = await request(app).get(response.headers.location);
    expect(errorPage.status).toBe(200);
    const $ = cheerio.load(errorPage.text);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list').text()).toContain('First name is required');
    expect($('.error-list').text()).toContain('valid email address');
  });

  it('accepts international postal codes and phone numbers', async () => {
    const internationalData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane@example.co.uk',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(internationalData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
