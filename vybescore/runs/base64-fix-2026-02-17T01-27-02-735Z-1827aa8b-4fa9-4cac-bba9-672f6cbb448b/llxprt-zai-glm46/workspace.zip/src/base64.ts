/**
 * Validate a Base64 string.
 * Checks that the input only contains valid Base64 characters and has proper padding.
 */
function validateBase64(input: string): void {
  // Remove padding for validation
  const unpadded = input.replace(/=+$/, '');
  
  // Check for invalid characters (only A-Z, a-z, 0-9, +, / are allowed)
  if (!/^[A-Za-z0-9+/]*$/.test(unpadded)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check padding length (must be 0, 1, or 2 padding characters)
  const paddingLength = input.length - unpadded.length;
  if (paddingLength > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Check that unpadded length is a multiple of 4 (when including padding)
  if (input.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: incorrect length');
  }
}

/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate input before decoding
  validateBase64(trimmed);
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding succeeded (Node's Buffer.from is lenient)
    // Verify by re-encoding and comparing
    const reencoded = buffer.toString('base64').replace(/=+$/, '');
    const normalizedInput = trimmed.replace(/=+$/, '');
    
    if (normalizedInput !== reencoded) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
