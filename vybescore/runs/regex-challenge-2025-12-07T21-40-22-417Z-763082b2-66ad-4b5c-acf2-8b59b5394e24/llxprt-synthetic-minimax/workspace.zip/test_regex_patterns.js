// Test various URL regex patterns
const patterns = [
  /\b(?:https?:\/\/|www\.)[^\s<>"]|^`\[]+/gi,  // Current pattern (broken)
  /\b(?:https?:\/\/|www\.)[^\s<>\"']|^`\[]+/gi, // Added apostrophe
  /\b(?:https?:\/\/|www\.)[^\s<>"'()]/gi,       // Broader character set
  /\b(?:https?:\/\/|www\.)[^\s<>"'()]+/gi,      // Explicit +
  /\b(?:https?:\/\/|www\.)[^\s<>"'()]*/gi       // * quantifier
];

const text = 'Visit http://example.com today';

patterns.forEach((regex, i) => {
  const urls = text.match(regex);
  console.log(`Pattern ${i + 1}:`, urls);
});

// Test with more complex URL
const complexText = 'Visit http://example.com/path?query=value, and also check https://www.test-site.org/page.html for more info.';
patterns.forEach((regex, i) => {
  const urls = complexText.match(regex);
  console.log(`Complex Pattern ${i + 1}:`, urls);
});