const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"]|^`\[]+/gi;
const text = 'Visit http://example.com today';
const urls = text.match(urlRegex);
console.log('Result:', urls);