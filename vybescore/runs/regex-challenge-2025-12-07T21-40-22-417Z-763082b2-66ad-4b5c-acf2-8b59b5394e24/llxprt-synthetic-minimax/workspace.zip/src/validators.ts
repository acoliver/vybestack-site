export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Regex to validate email addresses
  // Local part: letters, numbers, + _ . (no double dots, no starting/ending dots)
  // Domain part: letters, numbers, hyphens, dots (no underscores, no starting/ending dots)
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9]+(?:[._+][a-zA-Z0-9]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  let cleaned = value.trim();
  
  // Handle optional +1 prefix first
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  }
  
  // If extensions are not allowed, check if the number has an extension
  if (!options?.allowExtensions && /ext\.?\s*\d+$/i.test(cleaned)) {
    return false;
  }
  
  // Remove extension if present
  cleaned = cleaned.replace(/\s*(ext\.?\s*\d+)$/i, '');
  
  // Remove all non-digit characters
  cleaned = cleaned.replace(/\D/g, '');
  
  // Must be 10 digits for a valid US phone number
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = parseInt(cleaned.substring(0, 3), 10);
  if (areaCode < 200 || areaCode > 999) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators for validation
  let cleaned = value.replace(/[\s-]/g, '');
  
  // Check for optional country code +54
  let hasCountryCode = false;
  if (cleaned.startsWith('+54')) {
    hasCountryCode = true;
    cleaned = cleaned.substring(3);
  }
  
  // Check for mobile indicator '9' 
  if (cleaned.startsWith('9')) {
    cleaned = cleaned.substring(1);
  }
  
  // Check for trunk prefix '0'
  let hasTrunkPrefix = false;
  if (cleaned.startsWith('0')) {
    hasTrunkPrefix = true;
    cleaned = cleaned.substring(1);
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Area code validation (2-4 digits, first digit 1-9)
  if (cleaned.length < 8) {
    return false; // Need at least 2-digit area code + 6-digit subscriber
  }
  
  const areaCodeLength = Math.min(4, Math.max(2, cleaned.length - 6));
  const areaCode = parseInt(cleaned.substring(0, areaCodeLength), 10);
  
  // Area code must be 2-4 digits and first digit cannot be 0
  if (areaCodeLength < 2 || areaCodeLength > 4 || areaCode < 10) {
    return false;
  }
  
  // Remaining digits should be 6-8 (subscriber number)
  const subscriberDigits = cleaned.substring(areaCodeLength);
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, hyphens, apostrophes
  // Reject digits, symbols, and unusual patterns
  
  // More comprehensive regex that allows:
  // - Unicode letters and marks (accents, etc.)
  // - Spaces between words
  // - Hyphens within words
  // - Apostrophes within words
  // But rejects digits and unusual symbols
  const validNameRegex = /^[\p{L}\p{M}]+(?:[\s'-][\p{L}\p{M}]+)*$/u;
  
  // Must not be empty and must match the pattern
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check for digits - if any digits found, reject
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for unusual symbols (reject if contains symbols other than ', -, space)
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }
  
  // Must have at least some letters
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  return validNameRegex.test(value.trim());
}

/**
 * TODO: Validate credit card numbers using Luhn algorithm.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits, starts with 4
  // MasterCard: 16 digits, starts with 51-55 or 2221-2720
  // American Express: 15 digits, starts with 34 or 37
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Luhn algorithm
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}