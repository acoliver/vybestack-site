export function capitalizeSentences(text: string): string {
  // Split text into sentences (end with . ? !)
  const sentences = text.split(/(?<=[.!?])\s+/);
  
  // Capitalize first letter of each sentence
  const capitalized = sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return sentence;
    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
  });
  
  // Join sentences with single space
  return capitalized.join(' ');
}

export function extractUrls(text: string): string[] {
  // URL regex pattern that captures URLs without trailing punctuation
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"'()]+/gi;
  
  const urls = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  return urls.map(url => {
    return url.replace(/[.,!?;:]+$/, '');
  });
}

export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /https?:\/\/example\.com(\/docs\/[^?]*)/gi,
    (match, path) => {
      // Check if the path contains dynamic hints or legacy extensions
      const hasDynamicHints = /cgi-bin|\?.*=|&.*=|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)$/i.test(path);
      
      if (hasDynamicHints) {
        // Only upgrade the scheme, keep original host
        return match.replace(/^https?:\/\//, 'https://');
      } else {
        // Upgrade scheme and rewrite host
        return 'https://docs.example.com' + path;
      }
    }
  );
}

export function extractYear(value: string): string {
  const match = value.match(/\b(\d{1,2})\/(\d{1,2})\/(\d{4})\b/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Basic validation of month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return match[3]; // Return the year
}