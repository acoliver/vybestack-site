/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with prefix
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => {
    const normalizedMatch = match.toLowerCase();
    return !exceptions.some(exception => normalizedMatch === exception.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use regex with lookaheads/lookbehinds:
  // (?<!^) - not at the start of the string
  // (?<=\d) - preceded by a digit
  // The token itself
  
  // Need to return the token with its preceding digit, not just the token
  const result: string[] = [];
  let match;
  const searchRegex = new RegExp(`(?<!^)(?<=\\d)${token}`, 'gi');
  
  while ((match = searchRegex.exec(text)) !== null) {
    // Get the digit before the match
    const beforeMatch = text.substring(0, match.index);
    const digitMatch = beforeMatch.match(/(\d)(?!.*\d)/);
    if (digitMatch) {
      result.push(digitMatch[1] + token);
    }
  }
  
  return result;
}

/**
 * TODO: Validate strong passwords with comprehensive criteria.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // This checks for patterns that repeat immediately
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses while ensuring IPv4 addresses don't trigger false positives.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses can be in various forms:
  // - Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed form: 2001:db8:85a3::8a2e:370:7334
  // - IPv4-mapped: ::ffff:192.0.2.1
  
  // Pattern for IPv6 addresses
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/;
  
  // Pattern for IPv4 addresses (to exclude them)
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if string contains IPv4 - if so, return false
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Check if string contains IPv6 pattern
  return ipv6Regex.test(value);
}