import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import fs from 'fs';

// Define types for sql.js to avoid using 'any'
type StatementParams = string | number | null | undefined;

interface Database {
  run: (sql: string, ...params: StatementParams[]) => void;
  prepare: (sql: string) => Statement;
  export: () => Uint8Array;
  close: () => void;
}

interface Statement {
  run: (...params: StatementParams[] | StatementParams[][]) => void;
  free: () => void;
}

interface SQLModule {
  Database: (data?: Uint8Array) => Database;
}


interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Import type definitions for sql.js dynamically to avoid static type issues


class FormCaptureServer {
  private app: express.Application;
  private server: unknown;
  private db: Database | null = null;
  private require: NodeRequire;

  constructor() {
    this.app = express();
    this.require = createRequire(import.meta.url);
    
    // View engine setup
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(path.dirname(fileURLToPath(import.meta.url)), 'views'));
    
    // Middleware
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'public')));
    
    // Initialize database asynchronously
    this.initializeDatabase().then(() => {
      // Setup routes after database is ready
      this.setupRoutes();
      // Setup graceful shutdown
      this.setupGracefulShutdown();
    }).catch(error => {
      console.error('Failed to initialize database:', error);
      process.exit(1);
    });
  }

  private async initializeDatabase(): Promise<void> {
    const SQL = this.require('sql.js');
    const dbPath = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
    
    // Create data directory if it doesn't exist
    if (!fs.existsSync(dbPath)) {
      fs.mkdirSync(dbPath, { recursive: true });
    }
    
    const dbFilePath = path.join(dbPath, 'submissions.sqlite');
    
    // Initialize database
    if (fs.existsSync(dbFilePath)) {
      // Load existing database
      const fileBuffer = fs.readFileSync(dbFilePath);
      const SQLModule = await SQL() as SQLModule;
      // Using type assertion to work with sql.js library that has dynamic typing
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.db = new (SQLModule.Database as any)(fileBuffer);
    } else {
      // Create new database
      const SQLModule = await SQL() as SQLModule;
      // Using type assertion to work with sql.js library that has dynamic typing
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      this.db = new (SQLModule.Database as any)();
      
      // Read and execute schema
      const schemaPath = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      this.db!.run(schema);
      
      // Save initial database
      this.saveDatabase();
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    const dataPath = path.join(path.dirname(fileURLToPath(import.meta.url)), '..', 'data');
    const dbFilePath = path.join(dataPath, 'submissions.sqlite');
    
    const data = this.db.export();
    fs.writeFileSync(dbFilePath, Buffer.from(data));
  }

  private validateForm(formData: FormData): string[] {
    const errors: string[] = [];
    
    // Basic required field validation
    if (!formData.firstName || formData.firstName.trim() === '') {
      errors.push('First name is required');
    }
    
    if (!formData.lastName || formData.lastName.trim() === '') {
      errors.push('Last name is required');
    }
    
    if (!formData.streetAddress || formData.streetAddress.trim() === '') {
      errors.push('Street address is required');
    }
    
    if (!formData.city || formData.city.trim() === '') {
      errors.push('City is required');
    }
    
    if (!formData.stateProvince || formData.stateProvince.trim() === '') {
      errors.push('State/Province/Region is required');
    }
    
    if (!formData.postalCode || formData.postalCode.trim() === '') {
      errors.push('Postal code is required');
    } else if (!/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
      errors.push('Postal code can only contain letters, digits, and spaces');
    }
    
    if (!formData.country || formData.country.trim() === '') {
      errors.push('Country is required');
    }
    
    if (!formData.email || formData.email.trim() === '') {
      errors.push('Email is required');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.push('Valid email is required');
    }
    
    if (!formData.phone || formData.phone.trim() === '') {
      errors.push('Phone number is required');
    } else if (!/^[+]?\d[\d\s\-()]*$/.test(formData.phone)) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading +');
    }
    
    return errors;
  }

  private setupRoutes(): void {
    // GET / - serve the form
    this.app.get('/', (req: express.Request, res: express.Response) => {
      res.render('form', { errors: [], formData: null });
    });

    // POST /submit - handle form submission
    this.app.post('/submit', (req: express.Request, res: express.Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);
      
      if (errors.length > 0) {
        res.status(400).render('form', { errors, formData });
        return;
      }

      // Insert into database
      if (!this.db) {
        console.error('Database not initialized');
        res.status(500).send('Internal server error');
        return;
      }
      
      const stmt = this.db!.prepare(`
        INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database after insert
      this.saveDatabase();
      
      // Redirect to thank-you page
      res.redirect('/thank-you');
    });

    // GET /thank-you - serve the thank-you page
    this.app.get('/thank-you', (req: express.Request, res: express.Response) => {
      res.render('thank-you');
    });
  }

  private setupGracefulShutdown(): void {
    const handleShutdown = () => {
      console.log('Received shutdown signal, gracefully shutting down...');
      
      if (this.server) {
        (this.server as { close: (callback?: () => void) => void }).close(() => {
          console.log('HTTP server closed');
        });
      }
      
      if (this.db) {
        this.db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    };

    process.on('SIGTERM', handleShutdown);
    process.on('SIGINT', handleShutdown);
  }

  public start(): void {
    const port = process.env.PORT || 3535;
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }

  public stop(): void {
    if (this.server) {
      (this.server as { close: () => void }).close();
    }
    if (this.db) {
      this.db.close();
    }
  }
}

// Create and start the server
const server = new FormCaptureServer();
server.start();

export default FormCaptureServer;
