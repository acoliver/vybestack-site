import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

const INVALID_BASE64_ERROR = 'Invalid Base64 input';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('decodes Base64 text without padding', () => {
    const result = decode('aGVsbG8');
    expect(result).toBe('hello');
  });

  it('encodes non-ASCII Unicode text', () => {
    const result = encode('hello 世界');
    expect(result).toBe('aGVsbG8g5LiW55WM');
  });

  it('decodes non-ASCII Unicode text', () => {
    const result = decode('aGVsbG8g5LiW55WM');
    expect(result).toBe('hello 世界');
  });

  it('rejects invalid Base64 characters', () => {
    expect(() => decode('aGVsbG8!')).toThrow(INVALID_BASE64_ERROR);
  });

  it('rejects invalid Base64 padding position', () => {
    expect(() => decode('aGVsbG=x')).toThrow(INVALID_BASE64_ERROR);
  });

  it('rejects invalid Base64 padding amount', () => {
    expect(() => decode('aGVsbG8===')).toThrow(INVALID_BASE64_ERROR);
  });
});
