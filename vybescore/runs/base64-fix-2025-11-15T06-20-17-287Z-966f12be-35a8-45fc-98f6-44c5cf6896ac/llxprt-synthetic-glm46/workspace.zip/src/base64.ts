

/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Check if input contains valid Base64 characters only
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check if padding is valid (if present)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.slice(paddingIndex);
    // Padding can only be '=', '==', or '===' and must be at the end
    if (!/^(={1,2})$/.test(padding) || paddingIndex < input.length - 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
