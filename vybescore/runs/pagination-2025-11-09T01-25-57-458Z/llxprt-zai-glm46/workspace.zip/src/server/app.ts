import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function validateQueryParams(pageParam: string | undefined, limitParam: string | undefined) {
  let page = 1;
  let limit = 5;

  // Validate page parameter
  if (pageParam !== undefined) {
    if (pageParam === '' || isNaN(Number(pageParam))) {
      return { error: 'Page parameter must be a valid number' };
    }
    page = Number(pageParam);
    if (page <= 0) {
      return { error: 'Page parameter must be greater than 0' };
    }
  }

  // Validate limit parameter
  if (limitParam !== undefined) {
    if (limitParam === '' || isNaN(Number(limitParam))) {
      return { error: 'Limit parameter must be a valid number' };
    }
    limit = Number(limitParam);
    if (limit <= 0) {
      return { error: 'Limit parameter must be greater than 0' };
    }
    if (limit > MAX_LIMIT) {
      return { error: `Limit parameter cannot exceed ${MAX_LIMIT}` };
    }
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validateQueryParams(pageParam, limitParam);
    
    if ('error' in validation) {
      res.status(400).json({ message: validation.error });
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
