export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with support for common formats including +tags and international domains.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex with strict validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check if it matches the basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation rules
  // No consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // No leading or trailing dots
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Local part cannot start or end with dot
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot contain underscores
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Domain cannot start or end with dot or hyphen
  if (domainPart.startsWith('.') || domainPart.endsWith('.') || 
      domainPart.startsWith('-') || domainPart.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must have exactly 10 digits for a valid US phone number
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate the format with regex for specific patterns
  const phonePatterns = [
    /^\+?1?\s*\(\s*\d{3}\s*\)\s*\d{3}\s*[-.\s]?\s*\d{4}$/, // (212) 555-7890
    /^\+?1?\s*\d{3}\s*[-.\s]?\s*\d{3}\s*[-.\s]?\s*\d{4}$/, // 212-555-7890
    /^\+?1?\s*\d{10}$/, // 2125557890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value.trim()));
}

/**
 * Validate Argentine phone numbers supporting both landlines and mobiles.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // ^(\+54)? - Optional country code
  // (0)? - Optional trunk prefix
  // (9)? - Optional mobile indicator
  // (\d{2,4}) - Area code (2-4 digits, leading 1-9)
  // (\d{6,8}) - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // Area code validation: 2-4 digits, leading digit must be 1-9
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (!subscriberNumber || subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, number must begin with trunk prefix 0
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Additional validation: mobile indicator should only be present for mobile numbers
  // (This is a basic check - in reality, some area codes have specific patterns)
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name validation regex:
  // ^[\p{L}\p{M}'\-\s]+$ - Allows:
  // \p{L} - Unicode letters (including accented characters)
  // \p{M} - Unicode marks (combining diacritical marks)
  // ' - Apostrophes
  // \- - Hyphens
  // \s - Whitespace (primarily spaces)
  // Also ensures at least one character and doesn't allow only whitespace
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if it matches the pattern
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Additional validation to reject obviously invalid patterns
  
  // Check for multiple consecutive special characters
  if (value.includes("'''") || value.includes('---')) {
    return false;
  }
  
  // Check for leading or trailing apostrophes/hyphens
  const trimmed = value.trim();
  if (trimmed.startsWith("'") || trimmed.endsWith("'") || 
      trimmed.startsWith('-') || trimmed.endsWith('-')) {
    return false;
  }
  
  // Reject names that look like codes or contain excessive special characters
  const specialCharCount = (value.match(/['-]/g) || []).length;
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  
  // If special characters are more than 30% of the name, it's likely invalid
  if (letterCount > 0 && specialCharCount / letterCount > 0.3) {
    return false;
  }
  
  // Must contain at least one letter
  if (letterCount === 0) {
    return false;
  }
  
  // Reject names that contain numbers (digits should be caught by regex, but double-check)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names that contain obviously invalid characters
  if (/[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and American Express using Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check length based on card type
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  // Check if it matches any supported card type
  const isValidLength = visaRegex.test(cleanValue) || 
                       mastercardRegex.test(cleanValue) || 
                       amexRegex.test(cleanValue);
  
  if (!isValidLength) {
    return false;
  }
  
  // Luhn algorithm implementation
  function runLuhnCheck(cardNumber: string): boolean {
    let sum = 0;
    let isEven = false;
    
    // Process digits from right to left
    for (let i = cardNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cardNumber[i], 10);
      
      if (isEven) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }
      
      sum += digit;
      isEven = !isEven;
    }
    
    return sum % 10 === 0;
  }
  
  return runLuhnCheck(cleanValue);
}
