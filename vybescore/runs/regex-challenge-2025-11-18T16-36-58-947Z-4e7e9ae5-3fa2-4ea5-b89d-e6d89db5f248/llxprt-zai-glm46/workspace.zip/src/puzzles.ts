/**
 * Find words beginning with the specified prefix but excluding the listed exceptions.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions?: string[]): string[] {
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find words starting with the prefix
  // \b ensures we're at word boundary
  // [a-zA-Z]* matches the rest of the word characters
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, "g");
  
  
  // Default to empty array if exceptions is not provided
  const exceptionsList = exceptions || [];
  // Find all matching words
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptionsList (case-insensitive)
  const filteredWords = matches.filter(word => {
    return !exceptionsList.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  // Remove duplicates and return
  return [...new Set(filteredWords)];
}

/**
 * Find occurrences of a token that appear after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex to handle special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to ensure token is preceded by a digit
  // and positive lookahead to ensure we're not at the start of the string
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * Validate password strength according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
// Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (pattern repetition)
  // This checks for patterns like abab, abcabc, etc.
  for (let i = 0; i <= value.length - 4; i++) {
    const segment = value.substring(i, i + 2);
    const nextSegment = value.substring(i + 2, i + 4);
    if (segment === nextSegment) {
      return false;
    }
  }
  
  // Check for longer repeated sequences (3-character patterns)
  for (let i = 0; i <= value.length - 6; i++) {
    const segment = value.substring(i, i + 3);
    const nextSegment = value.substring(i + 3, i + 6);
    if (segment === nextSegment) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand :: notation) while excluding IPv4 addresses.
 * Returns true if IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern (to exclude)
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 address patterns
  
  // Full IPv6 format: 8 groups of 1-4 hex digits separated by colons
  const fullIpv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (compressed zeros)
  const compressedIpv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with leading/trailing ::
  const edgeCompressedRegex = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::\b|\b::\b/;
  
  // IPv4-mapped IPv6 addresses
  const ipv4MappedRegex = /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if any IPv6 patterns match
  const hasIpv6 = fullIpv6Regex.test(value) || 
                  compressedIpv6Regex.test(value) || 
                  edgeCompressedRegex.test(value) || 
                  ipv4MappedRegex.test(value);
  
  // If no IPv6 found, return false
  if (!hasIpv6) {
    return false;
  }
  
  // Extract potential IPv6 matches
  const allIpv6Matches = value.match(new RegExp(
    `${fullIpv6Regex.source}|${compressedIpv6Regex.source}|${edgeCompressedRegex.source}|${ipv4MappedRegex.source}`, 
    'g'
  )) || [];
  
  // Check if any of the matches are NOT IPv4 addresses
  for (const match of allIpv6Matches) {
    // Only consider it a valid IPv6 if it's not a pure IPv4 address
    if (!ipv4Regex.test(match)) {
      return true;
    }
  }
  
  return false;
}
