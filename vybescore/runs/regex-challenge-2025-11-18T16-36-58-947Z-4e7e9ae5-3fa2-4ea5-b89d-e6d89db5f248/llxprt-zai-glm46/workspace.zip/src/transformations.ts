/**
 * Capitalize the first character of each sentence after .!? punctuation marks.
 * Insert exactly one space between sentences and collapse extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces into one
  const result = text.replace(/\s+/g, ' ').trim();
  
  // Split into sentences using a more reliable approach
  // Find sentence boundaries and process them
  const sentences = [];
  let start = 0;
  
  for (let i = 0; i < result.length; i++) {
    const char = result[i];
    if (char === '.' || char === '!' || char === '?') {
      // Found end of sentence
      const sentence = result.substring(start, i + 1).trim();
      if (sentence) {
        sentences.push(sentence);
      }
      start = i + 1;
    }
  }
  
  // Add any remaining text
  if (start < result.length) {
    const remaining = result.substring(start).trim();
    if (remaining) {
      sentences.push(remaining);
    }
  }
  
  // Capitalize first letter of each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return sentence;
    const firstChar = sentence.charAt(0);
    const rest = sentence.slice(1);
    return firstChar.toUpperCase() + rest;
  });
  
  // Join sentences with single spaces
  return capitalizedSentences.join(' ');
}

/**
 * Extract URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches:
  // - http://, https://, ftp://, or www.
  // - domain names with subdomains
  // - IP addresses
  // - ports
  // - paths, query strings, fragments
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;
  
  // Find all potential URLs
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?)\]}>]+$/g, '');
  }).filter(url => {
    // Filter out false positives
    // Must have at least one dot after protocol/www or in domain
    const hasDomain = url.includes('.') && !url.endsWith('.');
    
    // Must have valid TLD or be a valid URL format
    const validFormat = /^https?:\/\/|^ftp:\/\/|^www\.|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/.test(url);
    
    return hasDomain && validFormat;
  });
  
  return cleanUrls;
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but be careful not to affect https://
  // This regex matches http:// that is not followed by another s (to avoid matching https://)
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to upgrade scheme and move docs paths to docs.example.com.
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // URL pattern to match http://example.com/... URLs
  const urlPattern = /(http:\/\/)([^/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Skip host rewrite if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /\/cgi-bin\/|[?&=]/.test(path) ||
                           /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Extract the base domain (remove subdomains like www)
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const baseDomain = domainParts.slice(-2).join('.'); // e.g., example.com
        const newHost = `docs.${baseDomain}`;
        return `${newProtocol}${newHost}${path}`;
      }
    }
    
    // Just upgrade the scheme
    return `${newProtocol}${host}${path}`;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.trim().match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (day < 1 || day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else {
    // For other months, check against standard days
    if (day < 1 || day > daysInMonth[month - 1]) {
      return 'N/A';
    }
  }
  
  // Return the year as string
  return yearStr;
}
