export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to validate credit card using Luhn algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects common invalid patterns
  // Accepts: typical addresses like name+tag@example.co.uk
  // Rejects: double dots, trailing dots, domains with underscores
  
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Check for obviously invalid patterns
  if (email.includes('..') || email.endsWith('.') || email.includes('@.') || email.includes('.@')) {
    return false;
  }
  
  // Enhanced email regex
  // Local part: letters, digits, and .+-_ but not starting/ending with dot
  // Domain part: letters, digits, hyphens, dots (no underscores), must have TLD
  
  // Check if there's exactly one @ symbol
  const atCount = (email.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }
  
  const [localPart, domainPart] = email.split('@');
  
  // Local part validation
  if (!localPart || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain part validation - no underscores allowed
  if (!domainPart || domainPart.includes('_') || domainPart.startsWith('-') || domainPart.endsWith('-')) {
    return false;
  }
  
  // Must have at least one dot in domain and TLD after last dot
  const domainParts = domainPart.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  const tld = domainParts[domainParts.length - 1];
  if (!tld || tld.length < 2) {
    return false;
  }
  
  // Check for consecutive dots in domain
  if (domainPart.includes('..')) {
    return false;
  }
  
  // Check for valid characters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return emailRegex.test(email);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and whitespace
  const cleanNumber = value.replace(/[\s\-\.\(\)]/g, '');
  
  // Check for optional +1 prefix
  let number = cleanNumber;
  if (number.startsWith('+1')) {
    number = number.substring(2);
  }
  
  // Must be exactly 10 digits
  if (!/^\d{10}$/.test(number)) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit, non-space, non-hyphen characters for validation
  const cleanNumber = value.replace(/[^\d\s\-]/g, '');
  
  // Extract just the digits for easier processing
  const digits = cleanNumber.replace(/[\s\-]/g, '');
  
  // Must have at least 10 digits (minimum for Argentina)
  if (digits.length < 10) {
    return false;
  }
  
  // Check for country code +54
  let remainingDigits = digits;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  
  if (value.trim().startsWith('+54')) {
    hasCountryCode = true;
    if (!digits.startsWith('54')) {
      return false;
    }
    remainingDigits = digits.substring(2);
  }
  
  // Check for trunk prefix 0 (when no country code)
  if (!hasCountryCode && remainingDigits.startsWith('0')) {
    hasTrunkPrefix = true;
    remainingDigits = remainingDigits.substring(1);
  } else if (hasCountryCode && remainingDigits.startsWith('0')) {
    hasTrunkPrefix = true;
    remainingDigits = remainingDigits.substring(1);
  }
  
  // Check for mobile indicator 9 (only after country code or trunk prefix)
  if ((hasCountryCode || hasTrunkPrefix) && remainingDigits.startsWith('9')) {
    remainingDigits = remainingDigits.substring(1);
  }
  
  // If no country code or trunk prefix, the number must start with area code
  // This means it should not start with 0 in this position
  if (!hasCountryCode && !hasTrunkPrefix && digits.startsWith('0')) {
    return false;
  }
  
  // Extract area code (2-4 digits, first digit 1-9)
  if (remainingDigits.length < 2) {
    return false;
  }
  
  let areaCodeLength = 0;
  for (let i = 1; i <= 4 && i < remainingDigits.length; i++) {
    const digit = parseInt(remainingDigits.charAt(i - 1), 10);
    if (i === 1 && (digit < 1 || digit > 9)) {
      return false;
    }
    areaCodeLength = i;
  }
  
  const areaCode = remainingDigits.substring(0, areaCodeLength);
  const subscriberNumber = remainingDigits.substring(areaCodeLength);
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const name = value.trim();
  
  if (!name) {
    return false;
  }
  
  // Must not contain digits
  if (/\d/.test(name)) {
    return false;
  }
  
  // Must not contain symbols except apostrophes, hyphens, and spaces
  // Allow unicode letters including accents and special characters
  // Reject X Æ A-12 style names (which would have digits or special symbols)
  
  // Check for invalid symbols (anything that's not a letter, space, apostrophe, or hyphen)
  const invalidPattern = /[^\p{L}\s'\-]/u;
  if (invalidPattern.test(name)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(name);
  if (!hasLetter) {
    return false;
  }
  
  // Check for patterns like "X Æ A-12" - these should fail
  // This is already covered by the digit check above
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must have between 13-19 digits (typical for major credit cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid card type prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // MasterCard: starts with 51-55, or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  
  let isValidType = false;
  
  // Visa
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidType = true;
  }
  // MasterCard
  else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
             digits.startsWith('54') || digits.startsWith('55')) && digits.length === 16) {
    isValidType = true;
  }
  // MasterCard 2221-2720 range
  else if (digits.length === 16) {
    const prefix4 = parseInt(digits.substring(0, 4), 10);
    if (prefix4 >= 2221 && prefix4 <= 2720) {
      isValidType = true;
    }
  }
  // American Express
  else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}