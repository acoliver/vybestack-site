/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with the prefix
  // Use word boundaries to ensure we match complete words
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    return !exceptions.some(exc => 
      match.toLowerCase() === exc.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match the digit followed by the token
  // This ensures the token appears after a digit
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Return array of matched tokens (with the preceding digit)
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol (non-alphanumeric, non-space)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // This pattern looks for any 2+ character sequence that repeats immediately
  // For example: abab, 1212, abcabc, etc.
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, ensure we don't match IPv4 addresses
  // IPv4 pattern: 4 sets of 1-3 digits separated by dots
  // If this matches, it's IPv4, not IPv6
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 address patterns to match:
  // Standard IPv6: 8 groups of 4 hex digits separated by colons
  // Compressed: uses :: to represent multiple groups of zeros
  // Examples: 2001:0db8:0000:0000:0000:ff00:0042:8329, 2001:db8::ff00:42:8329
  
  // Pattern for full IPv6 (8 groups of 1-4 hex digits)
  const fullIpv6 = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/;
  
  // Pattern for compressed IPv6 with ::
  // This is more complex as :: can represent 1-7 groups of zeros
  // We need to match patterns like:
  // ::1 (loopback)
  // 2001:db8::8a2e:370:7334 (compressed in the middle)
  // ::ffff:192.0.2.1 (IPv4-mapped)
  
  // Match compressed IPv6 addresses
  // This pattern handles various compression cases
  const compressedIpv6 = /\b(?:(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{0,4})?::(?:(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{0,4})?\b/;
  
  // Also match standalone :: (all zeros)
  const allZeros = /\b::\b/;
  
  if (fullIpv6.test(value) || compressedIpv6.test(value) || allZeros.test(value)) {
    return true;
  }
  
  return false;
}