/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // Find sentence boundaries (period, question mark, exclamation mark followed by space/end)
  // We'll capitalize after these delimiters
  
  // First, collapse multiple spaces into single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Pattern to match sentence endings followed by optional spaces
  // We need to capture the ending punctuation and any following spaces
  result = result.replace(/([.?!])(?:\s*)([^\s])/g, (match, punctuation, nextChar) => {
    // Capitalize the first character after sentence ending
    return punctuation + ' ' + nextChar.toUpperCase();
  });
  
  // Capitalize the first character of the entire text if it's a letter
  if (result.length > 0 && /[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.substring(1);
  }
  
  // Fix multiple spaces that might have been introduced
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - matches http://, https://, www., and domain names
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"'\)]*[^\s<>"'\.,\)?]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation while preserving the URL
    return url.replace(/[.,!?:;]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Use word boundary to ensure we don't match inside longer words
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const httpUrlRegex = /\bhttp:\/\/([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should skip the host rewrite
      const hasDynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)\b|cgi-bin)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com format
        newUrl += 'docs.' + host;
      } else {
        // Keep original host
        newUrl += host;
      }
    } else {
      // Not a docs path, keep original host
      newUrl += host;
    }
    
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, checking for different month lengths)
  const daysInMonth = new Date(parseInt(year, 10), month, 0).getDate();
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }
  
  return year;
}