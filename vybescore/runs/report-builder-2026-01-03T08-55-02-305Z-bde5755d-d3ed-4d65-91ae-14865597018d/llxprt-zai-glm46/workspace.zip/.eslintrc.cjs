const fs = require('node:fs');
const path = require('node:path');

const workspaceRoot = __dirname;

module.exports = {
  root: true,
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 'latest',
    sourceType: 'module'
  },
  plugins: ['@typescript-eslint'],
  extends: [
    'eslint:recommended',
    'plugin:@typescript-eslint/recommended',
    'prettier'
  ],
  env: {
    node: true,
    es2021: true
  },
  ignorePatterns: [],
  overrides: [
    {
      files: ['src/**/*.ts'],
      parserOptions: {
        project: path.join(workspaceRoot, 'tsconfig.json'),
        tsconfigRootDir: workspaceRoot
      }
    }
  ]
};
