#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

type Format = 'markdown' | 'text';

interface RenderFn {
  (data: ReportData, options: RenderOptions): string;
}

const FORMATS: Record<Format, RenderFn> = {
  markdown: renderMarkdown,
  text: renderText
};

function parseArgs(args: string[]): {
  inputFile: string;
  format: Format;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  let inputFile = '';
  let format: Format = 'markdown';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatArg = args[i + 1];
      if (!formatArg) {
        throw new Error('--format requires a value');
      }
      if (formatArg !== 'markdown' && formatArg !== 'text') {
        throw new Error(`Unsupported format: ${formatArg}`);
      }
      format = formatArg;
      i++;
    } else if (arg === '--output') {
      const outputArg = args[i + 1];
      if (!outputArg) {
        throw new Error('--output requires a value');
      }
      outputPath = outputArg;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!inputFile) {
    throw new Error('Input file path is required');
  }

  return { inputFile, format, outputPath, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  const content = fs.readFileSync(filePath, 'utf-8');
  let data: unknown;

  try {
    data = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }

  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: must be a JSON object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid entry at index ${i}: missing or invalid "label" field (must be a string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid entry at index ${i}: missing or invalid "amount" field (must be a number)`
      );
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const { inputFile, format, outputPath, includeTotals } = parseArgs(args);

    const data = loadReportData(inputFile);
    const renderer = FORMATS[format];
    const output = renderer(data, { includeTotals });

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
