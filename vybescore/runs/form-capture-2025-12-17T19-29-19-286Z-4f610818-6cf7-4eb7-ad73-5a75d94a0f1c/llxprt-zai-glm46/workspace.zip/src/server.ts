import express, { Request, Response } from 'express';
import { fileURLToPath } from 'node:url';
import * as path from 'node:path';
import * as http from 'node:http';
import { FormData, validateFormData } from './validation.js';
import { insertSubmission, closeDatabase } from './database.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(__dirname, '..');
const TEMPLATES_PATH = path.join(PROJECT_ROOT, 'src', 'templates');
const PUBLIC_PATH = path.join(PROJECT_ROOT, 'public');

const app = express();
const PORT = process.env.PORT || 3535;

app.set('view engine', 'ejs');
app.set('views', TEMPLATES_PATH);

app.use('/public', express.static(PUBLIC_PATH));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    return res.render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  try {
    await insertSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

let server: http.Server;

export async function startServer(): Promise<http.Server> {
  server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  server.on('error', (error: NodeJS.ErrnoException) => {
    if (error.syscall !== 'listen') {
      throw error;
    }

    const bind = typeof PORT === 'string' ? 'Pipe ' + PORT : 'Port ' + PORT;

    switch (error.code) {
      case 'EACCES':
        console.error(`${bind} requires elevated privileges`);
        process.exit(1);
        break;
      case 'EADDRINUSE':
        console.error(`${bind} is already in use`);
        process.exit(1);
        break;
      default:
        throw error;
    }
  });

  return server;
}

export async function stopServer(): Promise<void> {
  if (server) {
    await new Promise<void>((resolve, reject) => {
      server.close((err: Error | undefined) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
  }

  await closeDatabase();
  console.log('Server stopped gracefully');
}

process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await stopServer();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await stopServer();
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
