declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: typeof Database;
    initSqlJs: (options?: { locateFile?: (file: string) => string }) => Promise<SqlJsStatic>;
  }

  export class Database {
    constructor(data?: ArrayBuffer | Uint8Array);
    
    run(sql: string, ...params: unknown[]): void;
    exec(sql: string): QueryResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface QueryResult {
    columns: string[];
    values: unknown[][];
  }

  export class Statement {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }

  const initSqlJs: SqlJsStatic['initSqlJs'];
  export default initSqlJs;
  export { initSqlJs };
}