export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

function validateRequired(value: string, fieldName: string): string | null {
  if (!value || value.trim().length === 0) {
    return `${fieldName} is required`;
  }
  return null;
}

function validateEmail(email: string): string | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
}

function validatePhone(phone: string): string | null {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return 'Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading +';
  }
  return null;
}

function validatePostalCode(postalCode: string): string | null {
  // Allow alphanumeric postal codes (handles UK, Argentina, etc.)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  if (!postalCodeRegex.test(postalCode)) {
    return 'Postal code can only contain letters, digits, spaces, and dashes';
  }
  return null;
}

export function validateFormData(data: FormData): ValidationResult {
  const errors: string[] = [];

  const requiredFields: Array<{ key: keyof FormData; name: string }> = [
    { key: 'firstName', name: 'First name' },
    { key: 'lastName', name: 'Last name' },
    { key: 'streetAddress', name: 'Street address' },
    { key: 'city', name: 'City' },
    { key: 'stateProvince', name: 'State / Province / Region' },
    { key: 'postalCode', name: 'Postal / Zip code' },
    { key: 'country', name: 'Country' },
    { key: 'email', name: 'Email' },
    { key: 'phone', name: 'Phone number' }
  ];

  for (const { key, name } of requiredFields) {
    const error = validateRequired(data[key], name);
    if (error) {
      errors.push(error);
    }
  }

  if (data.email && errors.filter(e => e.includes('Email')).length === 0) {
    const emailError = validateEmail(data.email);
    if (emailError) {
      errors.push(emailError);
    }
  }

  if (data.phone && errors.filter(e => e.includes('Phone')).length === 0) {
    const phoneError = validatePhone(data.phone);
    if (phoneError) {
      errors.push(phoneError);
    }
  }

  if (data.postalCode && errors.filter(e => e.includes('Postal')).length === 0) {
    const postalError = validatePostalCode(data.postalCode);
    if (postalError) {
      errors.push(postalError);
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}