import * as fs from 'node:fs/promises';
import * as path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database as SqlJsDatabase } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(__dirname, '..');
const DB_PATH = path.join(PROJECT_ROOT, 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(PROJECT_ROOT, 'db', 'schema.sql');

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  createdAt?: string;
}

let db: SqlJsDatabase | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({ locateFile: () => 'node_modules/sql.js/dist/sql-wasm.wasm' });
    
    let dbBuffer: ArrayBuffer | null = null;
    try {
      const dbFile = await fs.readFile(DB_PATH);
      dbBuffer = dbFile.buffer.slice(dbFile.byteOffset, dbFile.byteOffset + dbFile.byteLength) as ArrayBuffer;
    } catch {
      console.log('Database file not found, creating new database');
    }
    
    db = new SQL.Database(dbBuffer || undefined);
    
    const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    const data = db.export();
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    await fs.writeFile(DB_PATH, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

export async function insertSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Promise<number> {
  if (!db) {
    await initializeDatabase();
  }
  
  if (!db) {
    throw new Error('Failed to initialize database');
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);
    
    stmt.free();
    
    const result = db.exec('SELECT last_insert_rowid() as id');
    const id = result[0].values[0][0] as number;
    
    await saveDatabase();
    
    return id;
  } catch (error) {
    console.error('Failed to insert submission:', error);
    throw error;
  }
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
    console.log('Database connection closed');
  }
}

export async function getDatabase(): Promise<SqlJsDatabase> {
  if (!db) {
    await initializeDatabase();
  }
  
  if (!db) {
    throw new Error('Failed to initialize database');
  }
  
  return db;
}