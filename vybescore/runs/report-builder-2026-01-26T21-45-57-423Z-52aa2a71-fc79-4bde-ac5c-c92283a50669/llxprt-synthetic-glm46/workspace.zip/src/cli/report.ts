import { readFileSync, writeFileSync } from 'node:fs';
import { exit } from 'node:process';
import type { ReportData, FormatType, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const renderers = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

function parseArgs(): {
  dataFile: string;
  format: FormatType;
  outputPath?: string;
  options: RenderOptions;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    exit(1);
  }

  const dataFile = args[0];
  const formatFlag = args[1];

  if (formatFlag !== '--format') {
    console.error('Expected --format flag');
    exit(1);
  }

  const format = args[2] as FormatType;

  if (!['markdown', 'text'].includes(format)) {
    console.error('Error: Unsupported format');
    exit(1);
  }

  const options: RenderOptions = {
    includeTotals: false,
  };

  let outputPath: string | undefined;

  // Parse remaining arguments
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the output path argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return { dataFile, format, outputPath, options };
}

function loadDataAndValidate(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: must be an object');
    }

    const reportData = data as Partial<ReportData>;

    if (!reportData.title || typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid "title" field');
    }

    if (!reportData.summary || typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid "summary" field');
    }

    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: missing or invalid "entries" field');
    }

    for (const entry of reportData.entries) {
      if (
        !entry ||
        typeof entry !== 'object' ||
        typeof entry.label !== 'string' ||
        typeof entry.amount !== 'number'
      ) {
        throw new Error(
          'Invalid report data: each entry must have a string "label" and number "amount"'
        );
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error parsing JSON file: ${error.message}`);
      exit(1);
    }

    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      exit(1);
    }

    console.error('Unknown error occurred while reading data file');
    exit(1);
  }
}

function main(): void {
  const { dataFile, format, outputPath, options } = parseArgs();
  const data = loadDataAndValidate(dataFile);

  const renderer = renderers[format];
  const result = renderer(data, options);

  try {
    if (outputPath) {
      writeFileSync(outputPath, result);
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error('Error writing output:', error);
    exit(1);
  }
}

main();
