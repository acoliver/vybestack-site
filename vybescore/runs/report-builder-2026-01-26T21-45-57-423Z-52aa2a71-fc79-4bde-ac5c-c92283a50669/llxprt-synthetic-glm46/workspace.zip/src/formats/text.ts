import type { FormatRenderer, ReportData, RenderOptions } from '../types.js';

export const renderText: FormatRenderer['render'] = (
  data: ReportData,
  options: RenderOptions
): string => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  const entries = data.entries
    .map((entry) => `- ${entry.label}: $${entry.amount.toFixed(2)}`)
    .join('\n');

  let result = `${data.title}\n${data.summary}\n\n`;

  if (data.entries.length > 0) {
    result += `Entries:\n${entries}`;
  }

  if (options.includeTotals && data.entries.length > 0) {
    result += `\nTotal: $${total.toFixed(2)}`;
  }

  return result;
};