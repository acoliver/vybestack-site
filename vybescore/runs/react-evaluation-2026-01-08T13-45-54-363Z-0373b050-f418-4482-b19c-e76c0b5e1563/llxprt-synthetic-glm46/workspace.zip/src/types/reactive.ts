/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const observerDependencies = new Map<ObserverR, Set<ObserverR>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Only call updateFn if the observer has one (subjects don't)
    if (observer.updateFn) {
      observer.value = observer.updateFn(observer.value)
    }
    // Notify dependent observers after update
    notifyDependents(observer)
  } finally {
    activeObserver = previous
  }
}

export function notifyDependents(observer: ObserverR): void {
  const dependents = observerDependencies.get(observer)
  if (dependents) {
    for (const dependent of dependents) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
}

export function addDependency(observer: ObserverR, dependency: ObserverR): void {
  if (!observerDependencies.has(dependency)) {
    observerDependencies.set(dependency, new Set())
  }
  observerDependencies.get(dependency)!.add(observer)
}

export function removeDependency(observer: ObserverR, dependency: ObserverR): void {
  const dependents = observerDependencies.get(dependency)
  if (dependents) {
    dependents.delete(observer)
    if (dependents.size === 0) {
      observerDependencies.delete(dependency)
    }
  }
}
