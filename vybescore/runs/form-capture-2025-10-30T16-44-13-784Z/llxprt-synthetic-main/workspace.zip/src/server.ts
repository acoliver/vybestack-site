import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
// @ts-expect-error - sql.js doesn't have TypeScript declarations
import initSqlJs from 'sql.js';

// Define Database interface based on sql.js behavior
interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(args?: unknown[]): void;
  free(): void;
}

// Define the constructor type for SQL Database
interface SQLiteDatabaseConstructor {
  new(data?: Uint8Array): Database;
}

// Set __dirname equivalent for ESM
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.dirname(__dirname);

interface ServerState {
  db: Database | null;
  server: express.Application | null;
  httpServer: unknown | null;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  data?: FormData;
}

const serverState: ServerState = {
  db: null,
  server: null,
  httpServer: null,
};

/**
 * Initialize SQLite database with schema
 */
async function initializeDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `./node_modules/sql.js/dist/${file}`,
    }) as unknown;;
    
    let db: Database;
    const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Try to load existing database, create new if not exists
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new (SQL as SQLiteDatabaseConstructor)(fileBuffer);
    } else {
      db = new (SQL as SQLiteDatabaseConstructor)();
    }
    
    // Initialize schema
    const schemaFile = path.join(projectRoot, 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaFile, 'utf8');
    db.exec(schema);
    
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

/**
 * Save database to disk
 */
function saveDatabase(db: Database): void {
  try {
    const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

/**
 * Validate form data
 */
function validateForm(body: Record<string, string>): ValidationResult {
  const errors: string[] = [];
  
  const firstName = body.firstName?.trim() || '';
  const lastName = body.lastName?.trim() || '';
  const streetAddress = body.streetAddress?.trim() || '';
  const city = body.city?.trim() || '';
  const stateProvince = body.stateProvince?.trim() || '';
  const postalCode = body.postalCode?.trim() || '';
  const country = body.country?.trim() || '';
  const email = body.email?.trim() || '';
  const phone = body.phone?.trim() || '';
  
  // Required fields validation
  if (!firstName) errors.push('First name is required');
  if (!lastName) errors.push('Last name is required');
  if (!streetAddress) errors.push('Street address is required');
  if (!city) errors.push('City is required');
  if (!stateProvince) errors.push('State/Province/Region is required');
  if (!postalCode) errors.push('Postal/Zip code is required');
  if (!country) errors.push('Country is required');
  if (!email) errors.push('Email is required');
  if (!phone) errors.push('Phone number is required');
  
  // Email validation - simple regex for clarity
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (email && !emailRegex.test(email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation - allow digits, spaces, parentheses, dashes, and leading + for international format
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (phone && !phoneRegex.test(phone)) {
    errors.push('Phone number can contain digits, spaces, parentheses, dashes, and optional leading +');
  }
  
  // Postal code validation - allow alphanumeric characters, spaces, dashes
  // This covers UK "SW1A 1AA" and Argentine formats like "C1000" or "B1675"
  if (postalCode && !/^[\w\s-]+$/.test(postalCode)) {
    errors.push('Postal/Zip code contains invalid characters');
  }
  
  const formData: FormData = {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone,
  };
  
  return {
    isValid: errors.length === 0,
    errors,
    data: formData,
  };
}

/**
 * Create Express application
 */
function createApp(): express.Application {
  const app = express();
  
  // Middleware for parsing form data
  app.use(express.urlencoded({ extended: true }));
  
  // Serve static files
  app.use('/public', express.static(path.join(projectRoot, 'public')));
  
  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  return app;
}

/**
 * Setup Express routes
 */
function setupRoutes(app: express.Application): void {
  // GET / - Render the form
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      values: {},
      errors: [],
    });
  });
  
  // POST /submit - Process form submission
  app.post('/submit', (req: Request, res: Response) => {
    const validation = validateForm(req.body);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        values: req.body,
        errors: validation.errors,
      });
    }
    
    // Save to database if we have a valid form
    if (serverState.db && validation.data) {
      try {
        const stmt = serverState.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          validation.data.firstName,
          validation.data.lastName,
          validation.data.streetAddress,
          validation.data.city,
          validation.data.stateProvince,
          validation.data.postalCode,
          validation.data.country,
          validation.data.email,
          validation.data.phone,
        ]);
        
        stmt.free();
        saveDatabase(serverState.db);
        
        // Redirect to thank you page with first name
        res.redirect(`/thank-you?firstName=${encodeURIComponent(validation.data.firstName)}`);
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          values: req.body,
          errors: ['An error occurred while saving your information. Please try again.'],
        });
      }
    } else {
      res.status(500).render('form', {
        values: req.body,
        errors: ['Database not available. Please try again later.'],
      });
    }
  });
  
  // GET /thank-you - Render thank you page
  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  });
}

/**
 * Start the server
 */
async function startServer() {
  try {
    // Initialize database
    const db = await initializeDatabase();
    serverState.db = db;
    
    // Create and configure Express app
    const app = createApp();
    setupRoutes(app);
    
    serverState.server = app;
    
    // Get port from environment or use default
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    // Start listening
    serverState.httpServer = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Graceful shutdown handlers
    const gracefulShutdown = () => {
      console.log('Received shutdown signal, closing server gracefully...');
      if (serverState.httpServer) {
        (serverState.httpServer as { close: (cb: () => void) => void }).close(() => {
          console.log('Express server closed');
          
          // Close database
          if (serverState.db) {
            serverState.db.close();
            console.log('Database connection closed');
          }
          
          process.exit(0);
        });
      } else {
        process.exit(0);
      }
    };
    
    // Handle process termination signals
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
    // Handle uncaught exceptions
    process.on('uncaughtException', (error) => {
      console.error('Uncaught Exception:', error);
      gracefulShutdown();
    });
    
    process.on('unhandledRejection', (reason, promise) => {
      console.error('Unhandled Rejection at:', promise, 'reason:', reason);
      gracefulShutdown();
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();