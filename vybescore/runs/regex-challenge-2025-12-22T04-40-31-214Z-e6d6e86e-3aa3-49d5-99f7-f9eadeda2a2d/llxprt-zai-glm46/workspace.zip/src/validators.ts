export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex with comprehensive validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject leading or trailing dots in domain
  const domain = value.split('@')[1];
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain (not allowed in DNS)
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for easier processing
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number without country code)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.slice(1); // Remove the country code
  } else if (digitsOnly.length > 11) {
    return false; // Too many digits
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate the overall format using regex
  // This matches formats like:
  // - (212) 555-7890
  // - 212-555-7890  
  // - 2125557890
  // - +1 212-555-7890
  const phoneRegex = /^\+?1?\s*\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Supports formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Remove all separators (spaces, hyphens) for easier processing
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Simple approach: check if it matches common Argentine phone patterns
  // +54 9 11 1234 5678 -> +5491112345678
  // 011 1234 5678 -> 01112345678
  // +54 341 123 4567 -> +543411234567
  const argentinePhoneRegex = /^(\+54)?(0?9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanNumber.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // Area code validation: 2-4 digits, cannot start with 0
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Additional validation: if no country code, must start with trunk prefix 0
  const hasCountryCode = cleanNumber.startsWith('+54');
  if (!hasCountryCode && !cleanNumber.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Check if name is empty or just whitespace
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Regex for valid names: unicode letters, spaces, hyphens, apostrophes
  // \p{L} matches any kind of letter from any language
  // \p{M} matches combining marks (accents)
  const nameRegex = /^[\p{L}\p{M}''\-\s]+$/u;
  
  // Basic format validation
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with obvious symbols (except allowed hyphens and apostrophes)
  if (/[^a-zA-ZÀ-ž\u0400-\u04FF'-\s]/.test(value)) {
    return false;
  }
  
  // Reject consecutive non-letter characters (like "--" or "''")
  if (/[-']{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start or end with hyphen or apostrophe
  if (/^[-']|[-']$/.test(value.trim())) {
    return false;
  }
  
  // Reject names that are just a single character repeated (like "aaa")
  const trimmedName = value.trim();
  if (trimmedName.length > 2 && /^([^\s])\1+$/.test(trimmedName.replace(/[-']/g, ''))) {
    return false;
  }
  
  // Reject obviously strange names like "X Æ A-12"
  // This catches names with too many non-letter characters relative to letters
  const nonLetterChars = (trimmedName.match(/[^\p{L}\p{M}]/gu) || []).length;
  const letterChars = (trimmedName.match(/[\p{L}\p{M}]/gu) || []).length;
  
  if (letterChars === 0 || (nonLetterChars > letterChars && letterChars < 3)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using Luhn checksum.
 * Accepts proper prefixes and lengths for major card types.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have any digits
  if (!digitsOnly || digitsOnly.length === 0) {
    return false;
  }
  
  // Visa: 13-19 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4\d{12,18}$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if card matches any of the accepted formats
  const isValidFormat = visaRegex.test(digitsOnly) || 
                        mastercardRegex.test(digitsOnly) || 
                        amexRegex.test(digitsOnly);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
