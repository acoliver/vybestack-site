/* eslint-disable no-useless-escape */

/**
 * Capitalizes the first character of each sentence while preserving abbreviations.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // First, collapse multiple spaces and normalize spacing around punctuation
  const cleaned = text
    .replace(/\s+/g, ' ')  // Collapse multiple spaces to single space
    .replace(/\s*([.!?])\s*/g, '$1 ')  // Ensure exactly one space after punctuation
    .trim();  // Remove leading/trailing spaces
  
  // Simple approach: split on sentence-ending punctuation and capitalize each part
  const sentences = cleaned.split(/([.!?])/);
  const result = [];
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    const punctuation = sentences[i + 1];
    
    if (sentence && sentence.trim()) {
      // Find the first alphabetic character and capitalize it
      const firstCharIndex = sentence.search(/[a-zA-Z]/);
      if (firstCharIndex !== -1) {
        const capitalized = sentence.substring(0, firstCharIndex) + 
                           sentence[firstCharIndex].toUpperCase() + 
                           sentence.substring(firstCharIndex + 1);
        result.push(capitalized.trim());
      } else {
        result.push(sentence.trim());
      }
    }
    
    if (punctuation) {
      result.push(punctuation);
      // Add space after punctuation unless it's the last character
      if (i + 1 < sentences.length - 1) {
        result.push(' ');
      }
    }
  }
  
  return result.join('').trim();
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // Comprehensive URL regex that matches:
  // - http://, https://
  // - www. (without explicit protocol)
  // - domain names with various TLDs
  // - IP addresses
  // - Ports, paths, query strings, fragments
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<">]+|[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(?:\.[a-zA-Z]{2,})(?:\/[^\s<">]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters that are unlikely to be part of the URL
    return url.replace(/[.,;!?)[\]']+$/g, '');
  }).filter(url => {
    // Filter out empty strings and obviously invalid URLs
    if (!url || url.length < 3) return false;
    
    // Basic validation: must contain at least one dot or be a valid protocol
    return url.includes('.') || url.startsWith('http://') || url.startsWith('https://') || url.startsWith('www.');
  });
}

/**
 * Forces all http URLs to use https while leaving already secure URLs untouched.
 * Replaces http:// with https:// in the provided text.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Regex to match http URLs but not https URLs
  const httpUrlRegex = /\bhttp:\/\//g;
  
  // Replace all http:// with https://
  return text.replace(httpUrlRegex, 'https://');
}

/**
 * Rewrites documentation URLs by upgrading scheme and moving docs paths to docs.example.com.
 * - Always upgrades http:// to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // First upgrade all http:// to https://
  const upgradedText = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Then rewrite docs URLs - match patterns like https://example.com/docs/...
  return upgradedText.replace(/https:\/\/([^\/\s:]+)(\/docs\/[^?\s]*)/g, (match, hostname, path) => {
    // Check if this should be excluded (dynamic content)
    const excludePatterns = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const shouldExclude = excludePatterns.some(pattern => path.includes(pattern)) || path.includes('?');
    
    if (shouldExclude) {
      return match; // Don't change the host, just keep the upgraded https
    }
    
    // Extract the domain from the original hostname for the docs subdomain
    const domainParts = hostname.split('.');
    if (domainParts.length >= 2) {
      const domain = domainParts.slice(-2).join('.');
      return `https://docs.${domain}${path}`;
    } else {
      return `https://docs.${hostname}${path}`;
    }
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Regex to match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string to preserve leading zeros if any
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year for February
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  
  if (month === 2 && isLeapYear) {
    if (day < 1 || day > 29) {
      return 'N/A';
    }
  } else {
    if (day < 1 || day > daysInMonth[month - 1]) {
      return 'N/A';
    }
  }
  
  // If we get here, the date is valid
  return year;
}
