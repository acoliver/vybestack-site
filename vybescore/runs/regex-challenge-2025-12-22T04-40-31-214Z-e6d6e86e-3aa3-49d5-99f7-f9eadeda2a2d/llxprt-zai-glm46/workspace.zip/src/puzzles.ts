/**
 * Finds words starting with the given prefix but excludes words in the exceptions list.
 * Returns an array of matched word strings.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape the prefix for regex and create a pattern to match words starting with it
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches
    .filter(word => !exceptionSet.has(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Find all occurrences where token is preceded by a digit and not at string start
  const results: string[] = [];
  
  // Manual approach to find token occurrences
  const tokenLength = token.length;
  for (let i = 0; i < text.length - tokenLength + 1; i++) {
    const substring = text.substring(i, i + tokenLength);
    if (substring === token) {
      // Check if preceded by a digit and not at the start
      if (i > 0 && /\d/.test(text[i - 1])) {
        results.push(text[i - 1] + token);
      }
    }
  }
  
  return results;
}

/**
 * Validates password strength according to comprehensive security policy:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter  
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace characters
 * - No immediate repeated sequences (e.g., abab, 123123)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Minimum length requirement
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This catches patterns like abab, 123123, abcabc, etc.
  for (let i = 0; i < value.length / 2; i++) {
    const firstHalf = value.substring(i, i + value.length / 2);
    const secondHalf = value.substring(i + value.length / 2, i + value.length);
    
    if (firstHalf === secondHalf) {
      return false;
    }
  }
  
  // Check for shorter repeated patterns (2-4 character sequences)
  for (let patternLength = 2; patternLength <= 4; patternLength++) {
    for (let i = 0; i <= value.length - (patternLength * 2); i++) {
      const pattern = value.substring(i, i + patternLength);
      const nextPattern = value.substring(i + patternLength, i + (patternLength * 2));
      
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation) while excluding IPv4 addresses.
 * Returns true if IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv4 regex to exclude IPv4 addresses
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // IPv6 regex patterns for various formats
  
  // Full IPv6: 8 groups of 4 hex digits
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: compression (can replace 1 or more groups of zeros)
  const compressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/; 
  
  // IPv6 starting with :: (leading zeros compressed)
  const leadingCompressedIPv6Regex = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 ending with :: (trailing zeros compressed)
  const trailingCompressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){1,7}::\b/;
  
  // IPv6 with embedded IPv4: ::ffff:192.168.1.1
  const embeddedIPv4Regex = /\b(?:[0-9a-fA-F]{1,4}:)*:(?:[0-9a-fA-F]{1,4}:)*:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if any IPv6 patterns match
  const hasIPv6 = fullIPv6Regex.test(value) ||
                 compressedIPv6Regex.test(value) ||
                 leadingCompressedIPv6Regex.test(value) ||
                 trailingCompressedIPv6Regex.test(value) ||
                 embeddedIPv4Regex.test(value);
  
  if (!hasIPv6) {
    return false;
  }
  
  // Extract potential IPv6 addresses to verify they're not IPv4
  const potentialIPv6s = value.match(/\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/g) || [];
  const potentialCompressed = value.match(/\b[0-9a-fA-F]*::[0-9a-fA-F]*\b/g) || [];
  const potentialLeading = value.match(/\b::[0-9a-fA-F:]+\b/g) || [];
  const potentialTrailing = value.match(/\b[0-9a-fA-F:]+::\b/g) || [];
  
  const allCandidates = [...potentialIPv6s, ...potentialCompressed, ...potentialLeading, ...potentialTrailing];
  
  // Filter out any matches that are actually IPv4 addresses
  const ipv6Candidates = allCandidates.filter(candidate => !ipv4Regex.test(candidate));
  
  return ipv6Candidates.length > 0;
}
