/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  value?: unknown
  updateFn: (value?: unknown) => unknown
  isDisposed?: boolean
  observers?: Set<Observer>
}

export interface Subject<T> {
  name?: string
  value: T
  equalFn?: EqualFn<T> | boolean
  observers: Set<Observer>
}

// Global observer registry for dependency tracking
const observerRegistry = new WeakMap<Observer, Set<Observer>>()

export function registerDependency(observer: Observer, dependency: Observer): void {
  if (!observerRegistry.has(observer)) {
    observerRegistry.set(observer, new Set())
  }
  const dependencies = observerRegistry.get(observer)!
  dependencies.add(dependency)
}

export function unregisterDependency(observer: Observer, dependency: Observer): void {
  const dependencies = observerRegistry.get(observer)
  if (dependencies) {
    dependencies.delete(dependency)
    if (dependencies.size === 0) {
      observerRegistry.delete(observer)
    }
  }
}

export function notifyDependencies(observer: Observer): void {
  const dependents = observerRegistry.get(observer)
  if (dependents) {
    const dependentsCopy = Array.from(dependents)
    for (const dependent of dependentsCopy) {
      try {
        updateObserver(dependent)
      } catch (error) {
        // Clean up failed observers
        unregisterDependency(observer, dependent)
      }
    }
  }
}

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): Observer | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver(observer: Observer): void {
  if (!observer.updateFn || observer.isDisposed) return
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}
