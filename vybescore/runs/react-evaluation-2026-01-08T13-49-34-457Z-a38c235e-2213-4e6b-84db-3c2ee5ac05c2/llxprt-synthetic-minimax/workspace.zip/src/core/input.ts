/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: _equal,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this subject to the observer's dependencies (observers list)
      if (!observer.observers) {
        observer.observers = new Set()
      }
      observer.observers.add(observer) // self-reference to track
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (s.equalFn && typeof s.equalFn === 'function') {
      if (s.equalFn(s.value, nextValue)) {
        return s.value // value hasn't changed
      }
    } else if (s.equalFn === true) {
      if (s.value === nextValue) {
        return s.value // value hasn't changed
      }
    }

    s.value = nextValue
    
    // Notify all observers of the change
    const observersCopy = Array.from(s.observers)
    for (const observer of observersCopy) {
      try {
        updateObserver(observer)
      } catch (error) {
        // Remove failed observer
        s.observers.delete(observer)
      }
    }
    
    return s.value
  }

  return [read, write]
}
