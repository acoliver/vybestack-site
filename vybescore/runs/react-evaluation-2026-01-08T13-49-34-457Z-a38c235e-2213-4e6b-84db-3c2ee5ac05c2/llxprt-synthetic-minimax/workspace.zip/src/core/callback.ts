/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, getActiveObserver, setActiveObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer = {
    value,
    updateFn: updateFn as UpdateFn<unknown>,
    observers: new Set()
  }
  
  let disposed = false
  
  const executeCallback = () => {
    if (disposed || !updateFn) return
    
    const previous = getActiveObserver()
    try {
      // Set this observer as active so dependencies can track it
      setActiveObserver(observer)
      const result = updateFn(observer.value as T)
      observer.value = result as unknown
    } finally {
      setActiveObserver(previous)
    }
  }
  
  // Execute the callback to establish dependencies and perform side effects
  executeCallback()
  
  // Set up dependency tracking by adding this callback to current dependencies
  const activeObserver = getActiveObserver()
  if (activeObserver) {
    // Register this callback as a dependent of the current active observer
    if (!activeObserver.observers) {
      activeObserver.observers = new Set()
    }
    activeObserver.observers.add(observer)
  }
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    observer.isDisposed = true
    
    // Remove this callback from all observer dependency lists
    if (activeObserver) {
      activeObserver.observers?.delete(observer)
    }
  }
  
  return unsubscribe
}
