/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer = {
    name: options?.name,
    value,
    updateFn: updateFn as UpdateFn<unknown>,
  }

  const getter: GetterFn<T> = () => {
    // Save the current active observer
    const previous = getActiveObserver()
    
    // Set this computed observer as active
    setActiveObserver(o)
    
    try {
      // Execute the update function to compute the new value
      const newValue = updateFn(o.value as T)
      
      // Check if value actually changed
      if (o.value !== undefined && _equal) {
        if (typeof _equal === 'function') {
          if (_equal(o.value as T, newValue)) {
            return newValue // value hasn't changed
          }
        } else if (_equal === true) {
          if (o.value === newValue) {
            return newValue // value hasn't changed
          }
        }
      }
      
      o.value = newValue as unknown
      
      // Notify all observers of this computed value
      if (o.observers) {
        const observersCopy = Array.from(o.observers)
        for (const observer of observersCopy) {
          try {
            updateObserver(observer)
          } catch (error) {
            // Remove failed observer
            o.observers?.delete(observer)
          }
        }
      }
      
      return newValue
    } finally {
      // Restore the previous active observer
      setActiveObserver(previous)
    }
  }

  return getter
}
