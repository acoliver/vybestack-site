import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase } from '../../src/server.js';

let server: {
  close: () => void;
} | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await initializeDatabase();
  // Start server on a random port for testing
  server = app.listen(0);
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '123 Baker Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({});

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 234 567 8900',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Email must be valid');
  });

  it('validates international phone formats', async () => {
    // Test valid international formats
    const validPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '+86 138 0013 8000',
    ];

    for (const phone of validPhones) {
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: '12345',
          country: 'Test Country',
          email: `test${phone.replace(/[^a-z0-9]/gi, '')}@example.com`,
          phone,
        });

      expect(response.status).toBe(302);
    }
  });

  it('accepts international postal codes', async () => {
    const validPostalCodes = ['SW1A 1AA', 'C1000', 'B1675', '12345'];

    for (const postalCode of validPostalCodes) {
      if (fs.existsSync(dbPath)) {
        fs.unlinkSync(dbPath);
      }

      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode,
          country: 'Test Country',
          email: `test${postalCode.replace(/[^a-z0-9]/gi, '')}@example.com`,
          phone: '+1 234 567 8900',
        });

      expect(response.status).toBe(302);
    }
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('stranger on the internet');
  });
});
