#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, CLIOptions, Formatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): { dataFile: string; options: CLIOptions } {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const options: CLIOptions = { format: 'markdown', includeTotals: false };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const format = args[++i];
      if (format === 'markdown' || format === 'text') {
        options.format = format;
      } else {
        console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
        process.exit(1);
      }
    } else if (arg === '--output') {
      options.output = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return { dataFile, options };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  const entries = report.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${index}] is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}] missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${index}] missing or invalid "amount" field (expected number)`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: report.title,
    summary: report.summary,
    entries,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid JSON:')) {
        console.error(`Error: ${error.message}`);
        process.exit(1);
      } else if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        console.error(`Error: File '${filePath}' not found`);
        process.exit(1);
      }
    }
    console.error(`Error: Failed to read or parse '${filePath}'`);
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to '${outputPath}'`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

// Main execution
const args = process.argv.slice(2);
const { dataFile, options } = parseArgs(args);
const reportData = loadReportData(dataFile);

const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

const formatter = formatters[options.format];
const output = formatter(reportData, options);
writeOutput(output, options.output);
