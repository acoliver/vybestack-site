/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverBase {
  name?: string
  // Track which subjects this observer depends on
  dependencies: Set<SubjectBase>
}

export interface ObserverValue<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverBase & ObserverValue<T>

export interface SubjectBase {
  name?: string
  // Track which observers depend on this subject
  observers: Set<ObserverBase>
}

export interface SubjectValue<T> {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectBase & SubjectValue<T>

let activeObserver: ObserverBase | undefined

export function getActiveObserver(): ObserverBase | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverBase | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObserver(observer: ObserverBase): void {
  updateObserver(observer as Observer<unknown>)
}

export function markDependency<T>(observer: ObserverBase, subject: Subject<T>): void {
  if (!observer.dependencies.has(subject as unknown as SubjectBase)) {
    observer.dependencies.add(subject as unknown as SubjectBase)
    subject.observers.add(observer)
  }
}
