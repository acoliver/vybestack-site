/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  markDependency,
  notifyObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverBase
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      markDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers that depend on this subject
    // Use Array.from to create a snapshot to avoid issues during iteration
    const observers = Array.from(s.observers)
    observers.forEach(observer => {
      notifyObserver(observer as ObserverBase)
    })
    
    return s.value
  }

  return [read, write]
}
