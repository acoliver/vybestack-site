/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Trigger initial computation and dependency tracking
  compute(o)
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer && o.observers) o.observers.add(observer)
    return o.value!
  }
}

// Helper function to compute and update an observer
function compute<T>(observer: Observer<T>): void {
  updateObserver(observer)
}