function enforceHttps(text) {
  if (!text) return text;
  
  // Replace http:// with https:// but don't touch existing https://
  return text.replace(/http:\/\/([^\/\s]+)(\/[^\s]*)?/g, 'https://$1$2');
}

console.log(enforceHttps('http://example.com'));