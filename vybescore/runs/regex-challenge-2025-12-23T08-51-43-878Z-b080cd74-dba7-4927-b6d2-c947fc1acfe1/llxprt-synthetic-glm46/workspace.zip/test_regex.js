console.log('Testing: +54 341 123 4567');
const phone = '+54 341 123 4567';
const cleanPhone = phone.replace(/[-\s]/g, '');
console.log('Clean:', cleanPhone);

const pattern = /^\+54(9)?([2-9]\d{1,3})(\d{6,8})$/;
console.log('Pattern test:', pattern.test(cleanPhone));
console.log('Match:', cleanPhone.match(pattern));
const match = cleanPhone.match(pattern);
if (match) {
  console.log('Area code:', match[2], 'length:', match[2].length);
  console.log('Subscriber:', match[3], 'length:', match[3].length);
}