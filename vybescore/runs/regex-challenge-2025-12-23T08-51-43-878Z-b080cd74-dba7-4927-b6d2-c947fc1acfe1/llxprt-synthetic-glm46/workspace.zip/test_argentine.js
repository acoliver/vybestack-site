// Test current implementation
function isValidArgentinePhoneCurrent(value) {
  const phone = value.trim();
  const cleanPhone = phone.replace(/[-\s]/g, '');

  let pattern;
  if (cleanPhone.startsWith('+54')) {
    pattern = /^\+54(9)?([2-9]\d{1,3})(\d{6,8})$/;
  } else {
    pattern = /^0(9)?([2-9]\d{1,3})(\d{6,8})$/;
  }

  if (!pattern.test(cleanPhone)) {
    return false;
  }

  const match = cleanPhone.match(pattern);
  if (!match) {
    return false;
  }

  const areaCode = match[2];
  const subscriberNumber = match[3];

  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  if (phone !== cleanPhone) {
    const separatorPattern = /^(\+54)?[ -]?0?[ -]?9?[ -]?[2-9]\d{1,3}[ -]?\d{6,8}$/;
    if (!separatorPattern.test(phone)) {
      return false;
    }
  }

  return true;
}

console.log('Testing current implementation:');
console.log('+54 341 123 4567:', isValidArgentinePhoneCurrent('+54 341 123 4567')); // Should be true, but is false

// Test with a simpler implementation
function isValidArgentinePhoneNew(value) {
  const phone = value.trim();
  const cleanPhone = phone.replace(/[-\s]/g, '');

  // Pattern should allow for the structure: +54 [9] area-code subscriber
  const pattern = /^\+54(9)?([2-9]\d{1,3})(\d{6,8})$/;
  
  if (!pattern.test(cleanPhone)) {
    return false;
  }

  const match = cleanPhone.match(pattern);
  const areaCode = match[2];
  const subscriberNumber = match[3];
  
  // Area code must be 2-4 digits, leading 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // Check separator pattern if needed
  if (phone !== cleanPhone) {
    const separatorPattern = /^\+54[ -]?9?[ -]?[2-9]\d{1,3}[ -]?\d{6,8}$/;
    if (!separatorPattern.test(phone)) {
      return false;
    }
  }

  return true;
}

console.log('+54 341 123 4567 (new):', isValidArgentinePhoneNew('+54 341 123 4567'));
console.log('Pattern check: ', /^\+54(9)?([2-9]\d{1,3})(\d{6,8})$/.test('+543411234567'));