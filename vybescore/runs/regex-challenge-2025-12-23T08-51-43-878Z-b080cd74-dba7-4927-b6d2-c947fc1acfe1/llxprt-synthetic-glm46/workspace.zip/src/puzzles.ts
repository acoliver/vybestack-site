/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${prefix}[\\w-]*`, 'gi');
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches
    .map(word => word.trim())
    .filter(word => {
      // Check if the full word is in the exceptions list
      const lowerWord = word.toLowerCase();
      return !exceptionSet.has(lowerWord);
    })
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind to match token only when preceded by a digit
  // and not at the start of the string, but return the digit + token
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches.filter((match, index, arr) => arr.indexOf(match) === index); // Remove duplicates
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., "abab")
  // Check for any 2-char pattern repeated immediately
  if (/([^\s]{2})\1/.test(value)) {
    return false;
  }
  
  // Check for repeated characters (3 or more in a row)
  if (/([^\s])\1\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex patterns
  // Full IPv6 with 8 groups: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  const ipv6Full = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: (shorthand)
  const ipv6Shorthand = /([0-9a-fA-F]{1,4}:){0,7}::([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with IPv4 embedded: xxxx::xxxx:xxxx:xxxx:xxxx:xxxx:xxx.xxx.xxx.xxx
  const ipv6WithIPv4 = /([0-9a-fA-F]{1,4}:){1,6}:(\d{1,3}\.){3}\d{1,3}/;
  
  // IPv6 loopback and link-local addresses
  const ipv6Special = /::1|::ffff:/;
  
  // First, ensure it's not just an IPv4 address
  const ipv4Pattern = /(\d{1,3}\.){3}\d{1,3}/;
  if (ipv4Pattern.test(value)) {
    // Check if there are IPv6 components as well
    return ipv6Full.test(value) || ipv6Shorthand.test(value) || 
           ipv6WithIPv4.test(value) || ipv6Special.test(value);
  }
  
  // Test for IPv6 patterns
  return ipv6Full.test(value) || ipv6Shorthand.test(value) || 
         ipv6WithIPv4.test(value) || ipv6Special.test(value);
}
