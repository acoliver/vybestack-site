/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 * Capitalize the first character of each sentence (after `.?!`), insert exactly one space 
 * between sentences even if the input omitted it, and collapse extra spaces sensibly 
 * while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing: ensure exactly one space after sentence terminators
  const normalized = text.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Split into sentences
  const sentences = normalized.split(/([.?!]\s*)/);
  
  const resultSentences: string[] = [];
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // If this is a sentence terminator, preserve it and set flag to capitalize next
    if (/^[.?!]\s*$/.test(part)) {
      resultSentences.push(part);
      capitalizeNext = true;
      continue;
    }
    
    // If this is empty or just whitespace, just add it
    if (!part.trim()) {
      resultSentences.push(part);
      continue;
    }
    
    // Capitalize the first character if this is the start of a sentence
    if (capitalizeNext) {
      const capitalized = part.charAt(0).toUpperCase() + part.slice(1);
      resultSentences.push(capitalized);
      capitalizeNext = false;
    } else {
      resultSentences.push(part);
    }
  }
  
  // Join and normalize final spacing
  return resultSentences.join('').replace(/\s{2,}/g, ' ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern loosely following RFC 3986
  // Matches http/https, www, ftp protocols and domain names
  const urlRegex = /(https?:\/\/|www\.|ftp:\/\/)[^\s<>"']+|[\w.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Filter and clean URLs
  return matches
    .filter(url => {
      // Avoid trailing punctuation
      const cleaned = url.replace(/[.,;:!?'"")]$/g, '');
      // Basic validation - must have domain with at least 2 chars TLD
      return /[\w.-]+\.[a-zA-Z]{2,}/.test(cleaned) || /^(https?:\/\/|www\.|ftp:\/\/)/.test(cleaned);
    })
    .map(url => url.replace(/[.,;:!?'"")]$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but don't touch existing https://
  return text.replace(/http:\/\/([^\/\s]+)(\/[^\s]*)?/g, 'https://$1$2');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  return text.replace(/https?:\/\/([^\/\s]+)(\/[^\s]*)/g, (match, domain, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if this should be rewritten to docs.[domain]
    // Rewrite when path begins with /docs/ unless it contains dynamic hints
    if (path && path.startsWith('/docs/') && 
        !path.match(/\/(cgi-bin|.*\.jsp|.*\.php|.*\.asp|.*\.aspx|.*\.do|.*\.cgi|.*\.pl|.*\.py)/) &&
        !path.includes('?')) {
      // Rewrite host to docs.[domain]
      return newScheme + 'docs.' + domain + path;
    } else {
      // Just upgrade the scheme
      return newScheme + domain + (path || '');
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const year = match[3];
  return year;
}
