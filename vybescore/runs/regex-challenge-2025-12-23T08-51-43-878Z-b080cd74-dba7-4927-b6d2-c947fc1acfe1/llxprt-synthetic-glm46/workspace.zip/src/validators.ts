export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
* Email validation using regex with strict requirements
* Accept typical addresses such as name+tag@example.co.uk
* Reject double dots, trailing dots, domains with underscores, and other obviously invalid forms
*/
export function isValidEmail(value: string): boolean {
  // Clean up the input
  const email = value.trim();
  
  // Basic email regex that covers the requirements
  // Local part: letters, numbers, dots, hyphens, plus, apostrophes
  // Domain: letters, numbers, hyphens, dots but no underscores
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check if it matches basic pattern
  if (!emailRegex.test(email)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // Reject double dots
  if (email.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in local part
  const [localPart] = email.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscore in domain
  const domain = email.substring(email.indexOf('@') + 1);
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject invalid TLD patterns
  const parts = domain.split('.');
  const tld = parts[parts.length - 1];
  if (tld.length < 2 || !/^[a-zA-Z]+$/.test(tld)) {
    return false;
  }
  
  return true;
}

/**
* US phone number validation with regex
* Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
* Disallow impossible area codes (leading 0/1) and too short inputs
*/
export function isValidUSPhone(value: string): boolean {
  // Clean up the input
  const phone = value.trim();
  
  // Remove all non-numeric characters except + for validation
  const digitsOnly = phone.replace(/[^\d+]/g, '');
  
  // Check if it has enough digits (10 or 11 with country code)
  if (digitsOnly.length === 10) {
    // Standard 10-digit number
    if (!/^[2-9]\d{9}$/.test(digitsOnly)) {
      return false; // Invalid area code (0/1 not allowed)
    }
  } else if (digitsOnly.length === 11 && digitsOnly.startsWith('+1')) {
    // 11-digit with country code
    const afterCountry = digitsOnly.substring(2);
    if (!/^[2-9]\d{9}$/.test(afterCountry)) {
      return false; // Invalid area code (0/1 not allowed)
    }
  } else if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // 11-digit with leading 1
    const afterCountry = digitsOnly.substring(1);
    if (!/^[2-9]\d{9}$/.test(afterCountry)) {
      return false; // Invalid area code (0/1 not allowed)
    }
  } else {
    return false; // Wrong length
  }
  
  // Check against the full format patterns
  // Accept formats: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890, 1-212-555-7890, etc.
  const phonePattern = /^(\+1[\s\-.]?)?(1[\s\-.]?)?(\(\d{3}\)|\d{3})[\s\-.]?\d{3}[\s\-.]?\d{4}$/;
  return phonePattern.test(phone);
}

/**
* Argentine phone number validation with regex
* Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
* Rules:
* - Optional country code +54
* - Optional trunk prefix 0 immediately before the area code
* - Optional mobile indicator 9 between country/trunk and the area code
* - Area code must be 2–4 digits (leading digit 1–9)
* - Subscriber number must contain 6–8 digits in total
* - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
* - Allow single spaces or hyphens as separators; ignore punctuation when validating
*/
export function isValidArgentinePhone(value: string): boolean {
  // Clean up the input
  const phone = value.trim();
  
  // Remove spaces and hyphens for validation
  const cleanPhone = phone.replace(/[-\s]/g, '');
  
  // Main Argentine phone regex pattern
  // Pattern breakdown:
  // ^(\+54)? - Optional +54 country code
  // (0)? - Optional 0 trunk prefix (only if no +54)
  // (9)? - Optional 9 mobile indicator
  // ([2-9]\d{1,3}) - Area code (2-4 digits, leading 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  
  let pattern;
  if (cleanPhone.startsWith('+54')) {
    // With country code
    pattern = /^\+54(9)?([2-9]\d{1,3})(\d{6,8})$/;
  } else {
    // Without country code - must start with 0
    pattern = /^0(9)?([2-9]\d{1,3})(\d{6,8})$/;
  }
  
  if (!pattern.test(cleanPhone)) {
    return false;
  }
  
  // Extract parts for additional validation
  const match = cleanPhone.match(pattern);
  if (!match) {
    return false;
  }
  
  const areaCode = match[2]; // The area code is in group 2
  const subscriberNumber = match[3]; // Subscriber number is in group 3
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Additional validation: check if the format with separators is valid
  // Allow single spaces or hyphens as separators only
  if (phone !== cleanPhone) {
    // More lenient separator pattern - just check no double separators
    if (/[ -]{2,}/.test(phone) || /[ -]$/.test(phone) || /^[ -]/.test(phone)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Permit unicode letters, accents, apostrophes, hyphens, spaces. Reject digits, symbols.
 */
export function isValidName(value: string): boolean {
  // Remove surrounding whitespace
  const name = value.trim();
  
  // Must have at least 2 characters
  if (name.length < 2) {
    return false;
  }
  
  // Name pattern: unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols (except allowed apostrophes and hyphens)
  const namePattern = /^[\p{L}\p{M}'’\- ]+$/u;
  
  if (!namePattern.test(name)) {
    return false;
  }
  
  // Reject names with only special characters
  const hasLetter = /[\p{L}]/u.test(name);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with consecutive apostrophes or hyphens
  if ( /['’\-]{2,}/.test(name)) {
    return false;
  }
  
  // Reject names starting or ending with apostrophe or hyphen
  if (/^['’\−] |['’\-]$/.test(name)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanCard = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanCard)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaPattern = /^4(\d{12}|\d{15})$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardPattern = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;
  
  if (!visaPattern.test(cleanCard) && !mastercardPattern.test(cleanCard) && !amexPattern.test(cleanCard)) {
    return false;
  }
  
  // Luhn checksum
  return runLuhnCheck(cleanCard);
}

/**
 * Helper function to perform Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
