/**
 * Encode plain text to Base64.
 * Uses standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses standard Base64 decoding and throws error for invalid input.
 */
export function decode(input: string): string {
  // Validate input: should only contain valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Validate length should be multiple of 4 when padded
  const paddedLength = Math.ceil(input.length / 4) * 4;
  if (paddedLength - input.length > 2) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
