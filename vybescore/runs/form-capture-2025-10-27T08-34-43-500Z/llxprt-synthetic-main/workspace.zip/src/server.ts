import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';

interface Database {
  exec(sql: string): void;
  run(sql: string, ...params: unknown[]): unknown;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  getAsObject(params?: string[]): Record<string, unknown>;
  free(): void;
}

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database;
const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

// Initialize SQLite database
function initializeDatabase(): Database {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Read schema
    const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');

    const SQL = require('sql.js') as { Database: new (data?: Buffer | ArrayBuffer | Uint8Array) => Database };
    
    // Initialize database
    let fileBuffer: Buffer | null = null;
    if (fs.existsSync(dbPath)) {
      fileBuffer = fs.readFileSync(dbPath);
    }

    db = new SQL.Database(fileBuffer || undefined);
    
    // Create tables if they don't exist
    db.exec(schema);

    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate phone number (international formats)
function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  return phoneRegex.test(phone);
}

// Validate email
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Validate postal code (alphanumeric)
function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postalCode);
}

// Validate form submission
function validateSubmission(submission: Submission): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!submission.first_name.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!submission.last_name.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!submission.street_address.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!submission.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!submission.state_province.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!submission.postal_code.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(submission.postal_code)) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code must be alphanumeric' });
  }

  if (!submission.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!submission.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(submission.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!submission.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(submission.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return errors;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;

  const submission: Submission = {
    first_name: firstName,
    last_name: lastName,
    street_address: streetAddress,
    city,
    state_province: stateProvince,
    postal_code: postalCode,
    country,
    email,
    phone
  };

  const validationErrors = validateSubmission(submission);

  if (validationErrors.length > 0) {
    // Return form with errors and entered values
    const errorMessages = validationErrors.map(error => error.message);
    return res.status(400).render('form', {
      errors: errorMessages,
      values: req.body
    });
  }

  // Insert into database
  db.run(
    `INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]
  );

  // Save database
  saveDatabase();

  // Redirect to thank you page
  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // We need to get the first name from the last submission for the thank you page
  try {
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1') as Statement;
    const result = stmt.getAsObject(['first_name']) as { first_name: string };
    stmt.free();

    const firstName = result?.first_name || 'friend';
    res.render('thank-you', { firstName });
  } catch (error) {
    res.render('thank-you', { firstName: 'friend' });
  }
});

// Start server
function startServer() {
  try {
    db = initializeDatabase();
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      if (db) db.close();
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
