declare module 'sql.js' {
  export class Database {
    constructor(data?: Buffer | ArrayBuffer | Uint8Array);
    exec(sql: string): void;
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface Statement {
    getAsObject(params?: string[]): Record<string, unknown>;
    free(): void;
  }
  
  export default interface SqlJs {
    Database: new (data?: Buffer | ArrayBuffer | Uint8Array) => Database;
  }
  
  function createSqlJs(options?: { locateFile: (file: string) => string }): Promise<SqlJs>;
}