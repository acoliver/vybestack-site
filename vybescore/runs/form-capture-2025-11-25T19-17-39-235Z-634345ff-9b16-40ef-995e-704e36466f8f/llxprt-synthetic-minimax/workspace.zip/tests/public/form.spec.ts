import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../src/server.js';
import { dbManager } from '../../src/database.js';

let server: ReturnType<typeof app.listen>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Initialize database
  await dbManager.initialize();
  
  // Start server on a test port
  return new Promise((resolve) => {
    server = app.listen(0, () => {
      resolve();
    });
  });
});

afterAll(async () => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close the database connection
  await dbManager.close();
  
  // Close server
  if (server) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('Contact Us');
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Street Address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State/Province/Region');
    expect(response.text).toContain('Postal/ZIP Code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email Address');
    expect(response.text).toContain('Phone Number');
  });

  it('validates form submission and redirects on success', async () => {
    const submissionData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });

  it('re-renders form with errors on validation failure', async () => {
    const invalidData = {
      first_name: 'John',
      last_name: 'Doe',
      // Missing required fields
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'United States',
      email: 'invalid-email',
      phone: '123'
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);
    
    expect(response.text).toContain('Contact Us - Please Correct Errors');
    expect(response.text).toContain('required');
  });

  it('serves thank you page after successful submission', async () => {
    const response = await request(app)
      .get('/thank-you')
      .expect(200);
    
    expect(response.text).toContain('Thank You!');
    expect(response.text).toContain('Why did you just give your personal information');
  });
});
