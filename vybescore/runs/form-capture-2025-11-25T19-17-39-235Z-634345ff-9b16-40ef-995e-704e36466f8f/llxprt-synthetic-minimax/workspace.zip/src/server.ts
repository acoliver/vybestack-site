import express, { Request, Response } from 'express';
import path from 'path';
import { dbManager, FormSubmission } from './database.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Validation interfaces
interface ValidationErrors {
  [key: string]: string;
}

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 10;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric postal codes like UK "SW1A 1AA" and others
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3 && postalCode.length <= 10;
}

function validateForm(data: Partial<FormData>): ValidationErrors {
  const errors: ValidationErrors = {};

  if (!data.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }

  if (!data.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }

  if (!data.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }

  if (!data.postal_code?.trim()) {
    errors.postal_code = 'Postal/ZIP code is required';
  } else if (!validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    formData: {},
    pageTitle: 'Contact Us'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: Partial<FormData> = {
      first_name: req.body.first_name?.trim(),
      last_name: req.body.last_name?.trim(),
      street_address: req.body.street_address?.trim(),
      city: req.body.city?.trim(),
      state_province: req.body.state_province?.trim(),
      postal_code: req.body.postal_code?.trim(),
      country: req.body.country?.trim(),
      email: req.body.email?.trim(),
      phone: req.body.phone?.trim()
    };

    const errors = validateForm(formData);

    if (Object.keys(errors).length > 0) {
      return res.status(400).render('form', {
        errors,
        formData,
        pageTitle: 'Contact Us - Please Correct Errors'
      });
    }

    // Insert into database
    await dbManager.insertSubmission(formData as Omit<FormSubmission, 'id' | 'created_at'>);

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    return res.status(500).render('form', {
      errors: { general: 'An error occurred while processing your request. Please try again.' },
      formData: req.body,
      pageTitle: 'Contact Us - Error'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    pageTitle: 'Thank You'
  });
});

// Graceful shutdown
async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    await dbManager.close();
    console.log('Database closed successfully.');
    
    server.close(() => {
      console.log('HTTP server closed.');
      process.exit(0);
    });
  } catch (error) {
    console.error('Error during graceful shutdown:', error);
    process.exit(1);
  }
}

// Initialize database and start server
let server: ReturnType<typeof app.listen>;

async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully.');

    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to view the application`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
if (process.env.NODE_ENV !== 'test' && import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default app;
export { startServer };