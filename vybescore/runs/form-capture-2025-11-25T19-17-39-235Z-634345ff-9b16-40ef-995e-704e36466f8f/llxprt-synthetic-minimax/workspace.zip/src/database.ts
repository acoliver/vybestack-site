import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import type { Database } from 'sql.js';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

export interface FormSubmission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sql: import('sql.js').SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      const sqlInstance = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });
      this.sql = sqlInstance;

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(DB_PATH)) {
        const dbBuffer = fs.readFileSync(DB_PATH);
        this.db = new this.sql.Database(dbBuffer);
      } else {
        this.db = new this.sql.Database();
      }

      // Initialize schema
      await this.initializeSchema();
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async initializeSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
      this.db.exec(schema);
    } catch (error) {
      console.error('Failed to load schema:', error);
      throw error;
    }
  }

  async insertSubmission(submission: Omit<FormSubmission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    
    // Get the last insert row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0]?.values[0]?.[0] as number;
    
    await this.save();
    return id;
  }

  async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const data = this.db.export();
    const buffer = Buffer.from(data);
    
    // Ensure directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(DB_PATH, buffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();