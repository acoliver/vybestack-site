/**
 * Report entry data structure
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Formatting options for report rendering
 */
export interface ReportOptions {
  includeTotals?: boolean;
}

/**
 * Report formatter interface
 */
export interface ReportFormatter {
  format(data: ReportData, options: ReportOptions): string;
}

/**
 * CLI argument parsing result
 */
export interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}