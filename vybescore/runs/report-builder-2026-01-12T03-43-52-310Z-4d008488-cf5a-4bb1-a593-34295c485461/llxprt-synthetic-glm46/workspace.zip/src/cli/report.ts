#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { exit } from 'node:process';

import type { ReportData, CliArgs, ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Map of format names to their formatter implementations
 */
const formatters: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Parses CLI arguments using Node's standard library
 */
function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const result: CliArgs = {
    dataFile: '',
    format: 'markdown',
    includeTotals: false,
  };

  // Parse arguments
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (i === 0 && !arg.startsWith('--')) {
      // First positional argument is the data file
      result.dataFile = arg;
    } else if (arg === '--format' && i + 1 < args.length) {
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Error: Unsupported format: ${format}`);
        exit(1);
      }
      result.format = format;
      i++; // Skip the next argument since we consumed it
    } else if (arg === '--output' && i + 1 < args.length) {
      result.output = args[i + 1];
      i++; // Skip the next argument since we consumed it
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('--')) {
      console.error(`Error: Unknown option: ${arg}`);
      exit(1);
    }
  }

  if (!result.dataFile) {
    console.error('Error: Data file is required');
    exit(1);
  }

  if (!result.format) {
    console.error('Error: Format is required');
    exit(1);
  }

  return result;
}

/**
 * Validates report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  const entries = reportData.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field`);
    }
  }

  return reportData as unknown as ReportData;
}

/**
 * Main function
 */
async function main(): Promise<void> {
  try {
    // Parse CLI arguments
    const args = parseArgs();

    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const fileContent = await readFile(args.dataFile, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${args.dataFile}: ${error.message}`);
      } else if (error instanceof Error && 'code' in error) {
        console.error(`Error reading file ${args.dataFile}: ${error.message}`);
      } else {
        console.error(`Error: ${error}`);
      }
      exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Get the appropriate formatter
    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Error: Unsupported format: ${args.format}`);
      exit(1);
    }

    // Render the report
    const output = formatter.format(reportData, { includeTotals: args.includeTotals });

    // Write output
    if (args.output) {
      try {
        await writeFile(args.output, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file ${args.output}: ${error}`);
        exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error}`);
    exit(1);
  }
}

// Run main function
main().catch((error) => {
  console.error(`Unexpected error: ${error}`);
  exit(1);
});
