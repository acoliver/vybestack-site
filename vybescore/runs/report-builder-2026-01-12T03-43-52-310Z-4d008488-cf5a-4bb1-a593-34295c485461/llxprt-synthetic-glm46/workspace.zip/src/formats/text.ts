import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

/**
 * Formats amount as currency with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates total from report entries
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((total, entry) => total + entry.amount, 0);
}

/**
 * Text formatter implementation
 */
export const renderText: ReportFormatter = {
  format(data: ReportData, options: ReportOptions = {}): string {
    const { includeTotals = false } = options;
    const lines: string[] = [];

    // Title
    lines.push(data.title);
    lines.push('');

    // Summary
    lines.push(data.summary);
    lines.push('');

    // Entries heading
    lines.push('Entries:');

    // Entries list
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }

    // Total if requested
    if (includeTotals) {
      const total = calculateTotal(data);
      lines.push(`\nTotal: ${formatAmount(total)}`);
    }

    return lines.join('\n');
  }
};