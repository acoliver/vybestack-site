/**
 * Validates email addresses using regex patterns
 * @param value - The email string to validate
 * @returns true if valid email, false otherwise
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern that rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@.')) {
    return false;
  }
  
  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers
 * @param value - The phone number string to validate
 * @param options - Optional configuration (not used in current implementation)
 * @returns true if valid US phone, false otherwise
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if it starts with country code
  let remainingDigits = digits;
  let hasCountryCode = false;
  
  if (digits.startsWith('1')) {
    remainingDigits = digits.substring(1);
    hasCountryCode = true;
  }
  
  // Check area code (first 3 digits)
  if (remainingDigits.length < 10) {
    return false;
  }
  
  const areaCode = remainingDigits.substring(0, 3);
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // If we have a country code, total should be 11 digits
  // Otherwise should be 10 digits
  if (hasCountryCode && digits.length !== 11) {
    return false;
  }
  if (!hasCountryCode && digits.length !== 10) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers
 * @param value - The phone number string to validate
 * @returns true if valid Argentine phone, false otherwise
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space, non-hyphen characters for initial validation
  const cleanValue = value.replace(/[^\d\s-]/g, '');
  const digits = cleanValue.replace(/[\s-]/g, '');
  
  // Argentina country code is +54
  let remainingDigits = digits;
  let hasCountryCode = false;
  
  // Check for optional country code +54
  if (remainingDigits.startsWith('54')) {
    hasCountryCode = true;
    remainingDigits = remainingDigits.substring(2);
  }
  
  // Check for optional mobile indicator '9'
  if (remainingDigits.startsWith('9')) {
    remainingDigits = remainingDigits.substring(1);
  }
  
  // Check for trunk prefix '0' before area code
  // When country code is omitted, trunk prefix '0' is required
  // When country code is present, trunk prefix '0' is optional
  if (!hasCountryCode && !remainingDigits.startsWith('0')) {
    return false;
  }
  
  // Remove the trunk prefix if present to get to area code
  if (remainingDigits.startsWith('0')) {
    remainingDigits = remainingDigits.substring(1);
  }
  
  // Area code should be 2-4 digits, first digit must be 1-9
  if (remainingDigits.length < 8) {
    return false; // Need at least 2 digit area code + 6 digit subscriber
  }
  
  const areaCodeLength = Math.min(4, remainingDigits.length - 6); // Area code max 4 digits
  if (areaCodeLength < 2) {
    return false;
  }
  
  const areaCode = remainingDigits.substring(0, areaCodeLength);
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // First digit of area code must be 1-9
  if (!/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  const subscriberNumber = remainingDigits.substring(areaCodeLength);
  
  // Subscriber number should be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates names allowing unicode letters, accents, apostrophes, hyphens, spaces
 * @param value - The name string to validate
 * @returns true if valid name, false otherwise
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accents), apostrophes, hyphens, spaces
  // Reject digits and other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least some alphabetic characters
  const hasAlpha = /[\p{L}\p{M}]/u.test(value);
  if (!hasAlpha) {
    return false;
  }
  
  return true;
}

/**
 * Runs Luhn checksum algorithm for credit card validation
 * @param cardNumber - The card number string (digits only)
 * @returns true if Luhn checksum passes, false otherwise
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}

/**
 * Validates credit card numbers using prefix checks and Luhn algorithm
 * @param value - The credit card string to validate
 * @returns true if valid credit card, false otherwise
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths for major card types
  // Visa: starts with 4, 13, 16, or 19 digits
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    return runLuhnCheck(digits);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
       digits.startsWith('54') || digits.startsWith('55') || 
       (digits.startsWith('222') && parseInt(digits.substring(0, 4)) <= 2720 && parseInt(digits.substring(0, 4)) >= 2221)) &&
      digits.length === 16) {
    return runLuhnCheck(digits);
  }
  
  // American Express: starts with 34 or 37, 15 digits
  if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    return runLuhnCheck(digits);
  }
  
  return false;
}