/**
 * Capitalizes the first character of each sentence and normalizes spacing
 * @param text - The text to process
 * @returns Text with properly capitalized sentences and normalized spacing
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split on sentence endings but keep the delimiters
  const sentenceRegex = /([.!?]+)\s*/g;
  const parts = text.split(sentenceRegex);
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    // If this part ends with sentence punctuation, capitalize the next non-empty part
    if (/^[.!?]+$/.test(part)) {
      // Find the next non-empty part to capitalize
      for (let j = i + 1; j < parts.length; j++) {
        if (parts[j].trim()) {
          parts[j] = parts[j].charAt(0).toUpperCase() + parts[j].slice(1);
          break;
        }
      }
    }
  }
  
  // Join parts back together, ensuring exactly one space after sentence endings
  let result = '';
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    if (/^[.!?]+$/.test(part)) {
      result += part + ' ';
    } else {
      result += part;
    }
  }
  
  // Clean up multiple spaces
  result = result.replace(/\s+/g, ' ').trim();
  
  // Capitalize the first character of the entire text if not already capitalized
  if (result && /^[a-z]/.test(result)) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * Extracts all URLs from text, removing trailing punctuation
 * @param text - The text to search for URLs
 * @returns Array of URLs found in the text
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https URLs
  const urlRegex = /https?:\/\/[^\s<>"]+[^\s<>".!?]/gi;
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * Converts HTTP URLs to HTTPS
 * @param text - The text to process
 * @returns Text with HTTP URLs converted to HTTPS
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites docs URLs by upgrading to HTTPS and modifying host for /docs/ paths
 * @param text - The text to process
 * @returns Text with rewritten docs URLs
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http:// scheme and capture host and path
  const urlRegex = /http:\/\/([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlRegex, (match, host, path = '') => {
    let result = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|\?|&|=/.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints && !hasLegacyExtensions) {
      // Rewrite host to docs.hostname.com
      const docHost = `docs.${host}`;
      result += docHost + path;
    } else {
      // Just upgrade scheme, keep original host
      result += host + path;
    }
    
    return result;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format
 * @param value - The date string to process
 * @returns Four-digit year or 'N/A' if invalid
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, with some basic month checks)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic validation for specific months (30 days in Apr, Jun, Sep, Nov; 28/29 in Feb)
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  return year;
}