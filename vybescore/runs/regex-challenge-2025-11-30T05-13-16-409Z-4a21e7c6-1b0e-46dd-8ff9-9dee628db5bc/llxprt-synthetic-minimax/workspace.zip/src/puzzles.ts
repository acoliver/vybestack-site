/**
 * Finds words that begin with the specified prefix, excluding exceptions
 * @param text - The text to search
 * @param prefix - The prefix to search for
 * @param exceptions - Array of words to exclude from results
 * @returns Array of words that start with prefix (excluding exceptions)
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to find words starting with the prefix
  // \b ensures we match whole words only
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * Finds occurrences where token appears after a digit and not at the start of string
 * @param text - The text to search
 * @param token - The token to find
 * @returns Array of tokens that appear after digits (not at string start)
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all positions where token appears after a digit
  const allMatches = [];
  
  // Create pattern to find token that comes after a digit
  const regex = new RegExp(`(\\d)${token}`, 'gi');
  
  let match;
  while ((match = regex.exec(text)) !== null) {
    allMatches.push(match[0]);
  }
  
  return allMatches;
}

/**
 * Validates password strength based on multiple criteria
 * @param value - The password to validate
 * @returns true if password meets all strength requirements, false otherwise
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (e.g., "abab", "1212", "abcabc")
  // This pattern looks for any 2+ character sequence that repeats immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation) and ensures IPv4 doesn't match
 * @param value - The text to search for IPv6 addresses
 * @returns true if IPv6 address is found, false otherwise
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern that handles shorthand notation
  // IPv6 addresses can be written in various forms:
  // - Full: 2001:0db8:0000:0000:0000:ff00:0042:8329
  // - Compressed: 2001:db8::ff00:42:8329
  // - IPv4-mapped: ::ffff:192.0.2.1
  
  const ipv6Pattern = /(^|[\s:])(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}$)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}$)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,2}$)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,3}$)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,4}$)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,5}$)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,6}$)|(^[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}:$)|(^:[0-9a-fA-F]{1,4}:$)|(^:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}$)|(^:[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,2}$)|(^:[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,3}$)|(^:[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,4}$)|(^:[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,5}$)|(^:[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,6}$))(?=[\s:]|$)/i;
  
  // IPv4 pattern to exclude (IPv4 should not match IPv6)
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // First check if there are any IPv4 addresses - if so, return false
  if (ipv4Pattern.test(value)) {
    // But also check if it's part of an IPv6 address (IPv4-mapped)
    const ipv4MappedPattern = /::ffff:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i;
    if (!ipv4MappedPattern.test(value)) {
      return false;
    }
  }
  
  // Now check for IPv6 addresses
  return ipv6Pattern.test(value);
}