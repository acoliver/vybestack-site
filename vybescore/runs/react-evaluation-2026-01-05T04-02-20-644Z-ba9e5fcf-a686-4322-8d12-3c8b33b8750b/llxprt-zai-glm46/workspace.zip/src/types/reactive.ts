/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Set<Subject<unknown>>
  observers?: Set<ObserverR>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<ObserverR>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let updateDepth = 0
const updateQueue: Observer<unknown>[] = []

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer

  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }

  // Queue observers that need to be updated (if not already queued)
  if (observer.subjects && observer.subjects.size > 0) {
    observer.subjects.forEach(subject => {
      const observers = subject.observers
      if (observers) {
        observers.forEach((obs: ObserverR) => {
          if (obs !== observer && !updateQueue.includes(obs as Observer<unknown>)) {
            updateQueue.push(obs as Observer<unknown>)
          }
        })
      }
    })
  }

  // Process queued updates if we're at the top level
  if (updateDepth === 0 && updateQueue.length > 0) {
    updateDepth++
    try {
      while (updateQueue.length > 0) {
        const queuedObserver = updateQueue.shift()!
        updateObserver(queuedObserver)
      }
    } finally {
      updateDepth--
    }
  }
}
