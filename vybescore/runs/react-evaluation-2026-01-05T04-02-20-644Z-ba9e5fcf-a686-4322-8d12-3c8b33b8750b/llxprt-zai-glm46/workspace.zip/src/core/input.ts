/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    observers: new Set<ObserverR>(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer

      // Track this subject in the observer's dependency set
      const obs = observer as Observer<unknown>
      if (!obs.subjects) {
        obs.subjects = new Set<Subject<unknown>>()
      }
      obs.subjects!.add(s as Subject<unknown>)

      // Add observer to this subject's observer set
      s.observers!.add(observer)

      // Also track this observer in the subject's observers set
      const subjectObservers = s.observers
      if (subjectObservers && !subjectObservers.has(observer)) {
        subjectObservers.add(observer)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers
    s.observers!.forEach((obs) => updateObserver(obs as Observer<unknown>))
    return s.value
  }

  return [read, write]
}
