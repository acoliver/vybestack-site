/**
 * Computed closure implementation for derived values.
 */

import type { Subject } from '../types/reactive.js'
import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  ObserverR,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set<Subject<unknown>>(),
  }

  const getter: GetterFn<T> = () => {
    const active = getActiveObserver()
    if (active) {
      // Track this computed as a dependency
      const obs = active as Observer<unknown> & { prevActiveObserver?: Set<ObserverR> }
      if (!obs.prevActiveObserver || !obs.prevActiveObserver.has(o)) {
        if (!obs.prevActiveObserver) {
          obs.prevActiveObserver = new Set<ObserverR>()
        }
        obs.prevActiveObserver.add(o)
      }
    }
    return o.value!
  }

  // Wrap the update function to track dependencies
  const wrappedUpdateFn: UpdateFn<T> = (prev?: T) => {
    // Clear previous subjects and prepare for new dependency tracking
    o.subjects!.clear()
    const obs = o as Observer<unknown> & { prevActiveObserver?: Set<ObserverR> }
    obs.prevActiveObserver = new Set<ObserverR>()

    // Execute the update function (this will register dependencies)
    const result = updateFn(prev)

    obs.prevActiveObserver = undefined

    return result
  }

  o.updateFn = wrappedUpdateFn

  // Initialize the value
  updateObserver(o)

  return getter
}
