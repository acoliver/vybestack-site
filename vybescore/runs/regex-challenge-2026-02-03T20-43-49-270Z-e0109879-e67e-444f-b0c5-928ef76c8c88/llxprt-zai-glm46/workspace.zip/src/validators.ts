export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for edge cases
  if (!emailRegex.test(value)) return false;
  
  const [local, domain] = value.split('@');
  
  // No trailing dots in local or domain
  if (local.endsWith('.') || domain.endsWith('.')) return false;
  
  // No consecutive dots
  if (local.includes('..') || domain.includes('..')) return false;
  
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // Domain parts must be valid
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.length === 0) return false;
    if (part.startsWith('-') || part.endsWith('-')) return false;
    if (!/^[a-zA-Z0-9-]+$/.test(part)) return false;
  }
  
  // TLD must be at least 2 chars
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length
  if (cleaned.length < 10) return false;
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format with regex to ensure proper structure
  const phoneRegex = /^(?:\+1[-.\s]?)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex breakdown:
  // ^(?:\+54)? - Optional country code +54
  // (?:0)? - Optional trunk prefix 0 (required if no country code)
  // (?:9)? - Optional mobile indicator 9
  // (\d{2,4}) - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, areaCode, subscriber] = match;
  
  // If country code is omitted, trunk prefix 0 must be present
  const normalized = value.replace(/[\s-]/g, '');
  if (!normalized.startsWith('+54') && !normalized.startsWith('0')) {
    return false;
  }
  
  // Area code must be 2-4 digits with leading 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  // No digits, no symbols (except apostrophe, hyphen, space)
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject names with digits
  if (/\d/.test(value)) return false;
  
  // Reject special symbols except allowed ones
  const allowedChars = /^[\p{L}\p{M}'\s-]+$/u;
  if (!allowedChars.test(value)) return false;
  
  // Not just spaces/hyphens/apostrophes
  const trimmed = value.trim();
  if (trimmed.length === 0) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length and prefix for different card types
  const cardPatterns = [
    // Visa: 13-19 digits, starts with 4
    { regex: /^4\d{12}(\d{3,6})?$/, name: 'Visa' },
    // Mastercard: 16 digits, starts with 51-55 or 2221-2720
    { regex: /^(5[1-5]\d{14}|2[2-7]\d{14})$/, name: 'Mastercard' },
    // AmEx: 15 digits, starts with 34 or 37
    { regex: /^3[47]\d{13}$/, name: 'AmEx' }
  ];
  
  let isValid = false;
  for (const pattern of cardPatterns) {
    if (pattern.regex.test(cleaned)) {
      isValid = true;
      break;
    }
  }
  
  if (!isValid) return false;
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
