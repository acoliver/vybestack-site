/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences if needed.
 * Collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Insert space after sentence endings if missing (before next word)
  normalized = normalized.replace(/([.!?])([a-z])/g, '$1 $2');
  
  // Split into sentences, capitalize first letter, and rejoin
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  const capitalized = sentences.map(sentence => {
    if (sentence.length === 0) return '';
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  return capitalized.join(' ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Removes trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlRegex = /https?:\/\/[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,!?;:]/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, schemeAndHost, path) => {
    // Always upgrade to https
    const newScheme = 'https://example.com';
    
    // Check if we should skip host rewrite
    const skipHostRewrite = /\/cgi-bin\/|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py)(\b|$))/.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    if (isDocsPath && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    } else {
      // Just upgrade scheme
      return `${newScheme}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) return 'N/A';
  
  return year;
}
