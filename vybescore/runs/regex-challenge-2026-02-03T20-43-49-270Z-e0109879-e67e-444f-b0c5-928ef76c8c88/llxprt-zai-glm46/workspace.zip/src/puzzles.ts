/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  const result = matches.filter(word => 
    !exceptions.includes(word) &&
    word.toLowerCase() !== prefix.toLowerCase() || word.length > prefix.length
  );
  
  // Remove duplicates and return
  return [...new Set(result)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the full match including the digit and token.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token (not at start of string)
  // We want to return the full match (digit + token)
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // Pattern: find any substring of length 2-4 that repeats immediately
  for (let len = 2; len <= 4; len++) {
    const repeatPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatPattern.test(value)) return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that handles shorthand ::
  
  // IPv6 can be:
  // - Full: 8 groups of 1-4 hex digits (e.g., 2001:0db8:85a3:0000:0000:8a2e:0370:7334)
  // - Compressed with :: (e.g., 2001:db8::1, ::1, 2001::)
  // - Mixed with IPv4 at end (e.g., ::ffff:192.0.2.1) - but we exclude these
  
  // Match full IPv6 (8 groups of hex)
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Match compressed IPv6 with ::
  // This can appear at start, middle, or end
  const compressedIPv6 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:?)*/;
  
  // Match just ::
  const doubleColon = /::/;
  
  // Match compressed at end (e.g., 2001:db8::)
  const compressedEnd = /(?:[0-9a-fA-F]{1,4}:)+::/;
  
  // Match compressed at start (e.g., ::1)
  const compressedStart = /::(?:[0-9a-fA-F]{1,4})+/;
  
  // Check for any IPv6 pattern
  if (fullIPv6.test(value) || compressedIPv6.test(value) || 
      doubleColon.test(value) || compressedEnd.test(value) || 
      compressedStart.test(value)) {
    
    // Make sure it's not just an IPv4 address
    // IPv4: 1-3 digits.1-3 digits.1-3 digits.1-3 digits
    const ipv4Pattern = /^(?:(?:\d{1,3}\.){3}\d{1,3})(?:$|\s)/;
    
    // If the entire value (trimmed) is just an IPv4, return false
    const trimmed = value.trim();
    if (ipv4Pattern.test(trimmed)) {
      return false;
    }
    
    return true;
  }
  
  return false;
}
