/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate a Base64 string.
 * Throws an error if the input is not valid Base64.
 */
function validateBase64(input: string): void {
  // Remove padding for validation
  const unpadded = input.replace(/=+$/, '');
  
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /)
  if (!/^[A-Za-z0-9+/]*$/.test(unpadded)) {
    throw new Error('Invalid Base64: contains characters outside the Base64 alphabet');
  }
  
  // Check for correct padding length
  const paddingLength = input.length - unpadded.length;
  if (paddingLength > 2) {
    throw new Error('Invalid Base64: too much padding');
  }
  
  // Check for valid length (must be multiple of 4 with padding, or unpadded length must be valid)
  if (unpadded.length % 4 !== 0 && paddingLength === 0) {
    // Allow unpadded input as long as the unpadded length could be valid
    // But check that adding appropriate padding would make it valid
    const neededPadding = (4 - (unpadded.length % 4)) % 4;
    if (neededPadding > 2) {
      throw new Error('Invalid Base64: incorrect length');
    }
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with or without padding.
 * Throws an error for invalid input.
 */
export function decode(input: string): string {
  // Validate input first
  validateBase64(input);
  
  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding was successful
    if (buffer.length === 0 && input.length > 0) {
      throw new Error('Invalid Base64: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
