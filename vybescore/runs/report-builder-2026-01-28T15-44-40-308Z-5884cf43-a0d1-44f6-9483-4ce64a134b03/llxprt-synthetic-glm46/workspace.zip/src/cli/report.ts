#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { exit } from 'process';

import type { ReportData, RenderOptions, FormatType } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

// Map format strings to their respective renderers
const renderers = {
  markdown: markdownRenderer,
  text: textRenderer,
};

// Parse command line arguments
function parseArgs(): { dataFile: string; format: FormatType; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }
  
  const dataFile = args[0];
  
  let format: FormatType | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Simple argument parser
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      const formatStr = args[i + 1];
      if (formatStr !== 'markdown' && formatStr !== 'text') {
        console.error(`Unsupported format: ${formatStr}`);
        exit(1);
      }
      format = formatStr as FormatType;
      i++; // Skip next argument since we processed it
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next argument since we processed it
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Missing required --format argument');
    exit(1);
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

// Validate the report data structure
function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }
  
  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    throw new Error('Validation error: missing or invalid title');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Validation error: missing or invalid summary');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Validation error: missing or invalid entries array');
  }
  
  for (const entry of report.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Validation error: entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Validation error: entry missing or invalid label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Validation error: entry missing or invalid amount');
    }
  }
}

// Load and parse JSON data
function loadData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    
    validateReportData(data);
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Malformed JSON in ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

// Main function
function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArgs();
    
    // Load and validate data
    const data = loadData(dataFile);
    
    // Get the appropriate renderer
    const renderer = renderers[format];
    if (!renderer) {
      console.error(`Unsupported format: ${format}`);
      exit(1);
    }
    
    // Render the report
    const options: RenderOptions = { includeTotals };
    const output = renderer.render(data, options);
    
    // Output to file or stdout
    if (outputPath) {
      writeFileSync(outputPath, output);
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    exit(1);
  }
}

// Run the CLI
main();
