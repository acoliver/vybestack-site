/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> {
  if (equal === false) return () => false
  if (equal === true || equal === undefined) {
    return (a: T, b: T) => a === b
  }
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // This subject will be both the result and can be observed by others
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }
  
  // This observer will recompute when dependencies change
  const observer: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: (currentValue?: T): T => {
      // Compute new value by calling the user's updateFn
      // During this computation, any accessed dependencies will register this observer
      const newComputedValue = updateFn(currentValue)
      
      // Check if value actually changed
      if (currentValue !== undefined && equalFn(currentValue, newComputedValue)) {
        return currentValue
      }
      
      // Update the subject's value
      subject.value = newComputedValue
      
      // Notify all observers who are watching this computed value
      for (const obs of subject.observers) {
        updateObserver(obs as Observer<unknown>)
      }
      
      return newComputedValue
    },
  }
  
  const read: GetterFn<T> = () => {
    // If another observer is accessing this computed value, register it
    const activeObs = getActiveObserver()
    if (activeObs) {
      subject.observers.add(activeObs)
    }
    return subject.value
  }
  
  // Initial computation - this will track dependencies and set the initial value
  updateObserver(observer)
  
  return read
}