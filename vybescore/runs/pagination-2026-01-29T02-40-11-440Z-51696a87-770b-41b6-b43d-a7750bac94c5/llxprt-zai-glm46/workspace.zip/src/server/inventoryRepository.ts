import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

export interface ValidationError {
  field: 'page' | 'limit';
  message: string;
  value: string;
}

export interface ValidationResult {
  valid: boolean;
  errors?: ValidationError[];
}

const MAX_LIMIT = 100;

export function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): ValidationResult {
  const errors: ValidationError[] = [];

  if (pageParam !== undefined) {
    if (pageParam.trim() === '') {
      errors.push({ field: 'page', message: 'Page parameter cannot be empty', value: pageParam });
    } else if (!/^[0-9]+$/.test(pageParam.trim())) {
      errors.push({ field: 'page', message: 'Page must be a positive integer', value: pageParam });
    } else {
      const pageValue = Number(pageParam.trim());
      if (pageValue < 1) {
        errors.push({ field: 'page', message: 'Page must be at least 1', value: pageParam });
      }
    }
  }

  if (limitParam !== undefined) {
    if (limitParam.trim() === '') {
      errors.push({ field: 'limit', message: 'Limit parameter cannot be empty', value: limitParam });
    } else if (!/^[0-9]+$/.test(limitParam.trim())) {
      errors.push({ field: 'limit', message: 'Limit must be a positive integer', value: limitParam });
    } else {
      const limitValue = Number(limitParam.trim());
      if (limitValue < 1) {
        errors.push({ field: 'limit', message: 'Limit must be at least 1', value: limitParam });
      } else if (limitValue > MAX_LIMIT) {
        errors.push({ field: 'limit', message: `Limit cannot exceed ${MAX_LIMIT}`, value: limitParam });
      }
    }
  }

  return {
    valid: errors.length === 0,
    errors: errors.length > 0 ? errors : undefined
  };
}


function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = offset + limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
