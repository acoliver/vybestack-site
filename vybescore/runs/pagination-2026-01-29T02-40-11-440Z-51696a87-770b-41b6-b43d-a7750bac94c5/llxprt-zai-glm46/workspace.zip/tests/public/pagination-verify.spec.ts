import { describe, it, expect, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Database } from 'sql.js';

describe('Pagination verification', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('should return page 1 with default limit of 5', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBeGreaterThan(0);
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('should return correct slice for page 1 with limit 3', async () => {
    const response = await request(app).get('/inventory?page=1&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(3);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(3);
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[2].id).toBe(3);
  });

  it('should return correct slice for page 2 with limit 3', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(3);
    expect(response.body.page).toBe(2);
    expect(response.body.items[0].id).toBe(4);
    expect(response.body.items[2].id).toBe(6);
  });

  it('should reject non-numeric page parameter', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid pagination parameters');
    expect(response.body.details).toBeDefined();
  });

  it('should reject negative page parameter', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid pagination parameters');
  });

  it('should reject zero limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid pagination parameters');
  });

  it('should reject limit exceeding maximum', async () => {
    const response = await request(app).get('/inventory?limit=200');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid pagination parameters');
  });

  it('should reject zero page parameter', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid pagination parameters');
  });

  it('should return correct hasNext flag', async () => {
    const response1 = await request(app).get('/inventory?page=1&limit=5');
    expect(response1.status).toBe(200);
    expect(response1.body.hasNext).toBe(true);

    const lastPage = Math.ceil(response1.body.total / response1.body.limit);
    const responseLast = await request(app).get(`/inventory?page=${lastPage}&limit=5`);
    expect(responseLast.status).toBe(200);
    expect(responseLast.body.hasNext).toBe(false);
  });
});
