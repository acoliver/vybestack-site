/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  notifySubject,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject to represent this computed value
  const subject = {
    name: options?.name,
    observer: o,
    value: undefined as T,
    observers: new Set<Observer<unknown>>()
  }
  
  const getter: GetterFn<T> = () => {
    // Update the observer and return the value
    updateObserver(o)
    return o.value!
  }
  
  // Initialize the observer
  updateObserver(o)
  
  return getter
}