/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, trackObserver, untrackObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  const trackedSubjects = new Set()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear all tracked dependencies
    for (const subject of trackedSubjects) {
      untrackObserver(observer, subject)
    }
  }
}