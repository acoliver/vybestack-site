declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface Statement {
    run(...params: unknown[]): { lastInsertRowid: number };
    free(): void;
  }
  
  export interface SqlJsStatic {
    Database: new (data?: ArrayBuffer) => Database;
  }
  
  export function initSqlJs(): Promise<SqlJsStatic>;
  export default initSqlJs;
}