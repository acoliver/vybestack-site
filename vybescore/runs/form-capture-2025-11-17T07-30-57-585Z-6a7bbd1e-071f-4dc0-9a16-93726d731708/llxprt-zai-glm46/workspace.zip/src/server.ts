import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

let db: import('sql.js').Database | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    const { createRequire } = await import('module');
    const require = createRequire(import.meta.url);
    const initSqlJs = require('sql.js') as () => Promise<import('sql.js').SqlJsStatic>;
    
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const dataDir = path.dirname(dbPath);
    
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    let dbData: ArrayBuffer | undefined;
    
    if (fs.existsSync(dbPath)) {
      const fileContent = fs.readFileSync(dbPath);
      const uint8Array = new Uint8Array(fileContent);
      dbData = uint8Array.buffer;
    }
    
    const SQL = await initSqlJs();
    db = new SQL.Database(dbData);
    
    // Initialize schema if needed
    if (!fs.existsSync(dbPath)) {
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf-8');
        db.exec(schema);
      } else {
        // Create a basic schema if schema.sql doesn't exist
        db.exec(`
          CREATE TABLE IF NOT EXISTS submissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            first_name TEXT NOT NULL,
            last_name TEXT NOT NULL,
            street_address TEXT,
            city TEXT,
            state_province TEXT,
            postal_code TEXT,
            country TEXT,
            email TEXT NOT NULL,
            phone TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
          )
        `);
      }
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

function validateForm(data: FormData): string[] {
  const errors: string[] = [];
  
  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  }
  
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  if (data.phone && !/^[+]?[\d\s\-()]+$/.test(data.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  return errors;
}

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} as FormData,
    submitted: false 
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body as FormData;
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    res.render('form', { errors, values: formData, submitted: false });
    return;
  }
  
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run(
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    );
    
    stmt.free();
    saveDatabase();
  }
  
  res.redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const port = process.env.PORT || 3535;
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('Received SIGTERM, shutting down gracefully');
    server.close(() => {
      if (db) {
        db.close();
      }
      process.exit(0);
    });
  });
}

// Start the server
startServer().catch(console.error);