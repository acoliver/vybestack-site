import { readFile, writeFile } from 'fs/promises';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
function parseArgs(): { 
  dataFile: string; 
  format: string; 
  outputFile?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  const parsedArgs: {
    dataFile: string;
    format: string;
    outputFile?: string;
    includeTotals: boolean;
  } = {
    dataFile: '',
    format: '',
    outputFile: undefined,
    includeTotals: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsedArgs.format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      parsedArgs.outputFile = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      parsedArgs.includeTotals = true;
    } else if (!parsedArgs.dataFile) {
      parsedArgs.dataFile = arg;
    }
  }

  if (!parsedArgs.dataFile) {
    throw new Error('Missing data file argument');
  }

  if (!parsedArgs.format) {
    throw new Error('Missing --format argument');
  }

  if (!['markdown', 'text'].includes(parsedArgs.format)) {
    throw new Error(`Unsupported format: ${parsedArgs.format}`);
  }

  return parsedArgs;
}

// Validate report data
function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: not an object');
  }

  if (!('title' in data) || typeof data.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title');
  }

  if (!('summary' in data) || typeof data.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary');
  }

  if (!('entries' in data) || !Array.isArray(data.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  for (const entry of data.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid report data: entry must be an object');
    }
    
    if (!('label' in entry) || typeof entry.label !== 'string') {
      throw new Error('Invalid report data: missing or invalid entry label');
    }
    
    if (!('amount' in entry) || typeof entry.amount !== 'number') {
      throw new Error('Invalid report data: entry amount must be a number');
    }
  }
}

// Render report based on format
function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  const options = { includeTotals };
  
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

// Main function
async function main() {
  try {
    const args = parseArgs();
    
    // Read and parse JSON data
    const dataString = await readFile(args.dataFile, 'utf-8');
    const data = JSON.parse(dataString);
    
    // Validate data
    validateReportData(data);
    
    // Render report
    const output = renderReport(data, args.format, args.includeTotals);
    
    // Output to file or stdout
    if (args.outputFile) {
      await writeFile(args.outputFile, output);
      console.log(`Report written to ${args.outputFile}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'An unknown error occurred');
    process.exit(1);
  }
}

main();