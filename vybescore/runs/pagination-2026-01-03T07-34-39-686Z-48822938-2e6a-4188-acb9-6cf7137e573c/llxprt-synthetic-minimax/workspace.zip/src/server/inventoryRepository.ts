import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationOptions(options: { page?: number; limit?: number }): { page: number; limit: number } {
  let validatedPage = DEFAULT_PAGE;
  let validatedLimit = DEFAULT_LIMIT;

  // Validate and sanitize page parameter
  if (options.page !== undefined && options.page !== null && !Number.isNaN(options.page)) {
    if (!Number.isFinite(options.page) || options.page <= 0 || options.page > 10000) {
      throw new Error('Invalid page parameter: must be a positive number <= 10000');
    }
    validatedPage = Math.floor(options.page);
  }

  // Validate and sanitize limit parameter
  if (options.limit !== undefined && options.limit !== null && !Number.isNaN(options.limit)) {
    if (!Number.isFinite(options.limit) || options.limit <= 0 || options.limit > MAX_LIMIT) {
      throw new Error(`Invalid limit parameter: must be a positive number <= ${MAX_LIMIT}`);
    }
    validatedLimit = Math.floor(options.limit);
  }

  return { page: validatedPage, limit: validatedLimit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const { page, limit } = validatePaginationOptions(options);

  // Get total count of inventory items
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // Calculate offset for pagination: (page - 1) * limit
  const offset = (page - 1) * limit;

  // Query the inventory items with proper pagination
  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  // Calculate if there's a next page
  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
