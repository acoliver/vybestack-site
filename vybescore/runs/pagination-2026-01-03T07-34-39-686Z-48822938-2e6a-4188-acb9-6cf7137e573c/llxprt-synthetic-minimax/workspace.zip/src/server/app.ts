import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;
const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;

function validateQueryParams(page: unknown, limit: unknown): { page: number; limit: number } {
  let validatedPage = DEFAULT_PAGE;
  let validatedLimit = DEFAULT_LIMIT;

  // Validate page parameter
  if (page !== undefined && page !== null && page !== '') {
    const pageNum = Number(page);
    if (Number.isNaN(pageNum) || !Number.isFinite(pageNum) || pageNum <= 0 || pageNum > 10000) {
      throw new Error('Invalid page parameter: must be a positive number <= 10000');
    }
    validatedPage = Math.floor(pageNum);
  }

  // Validate limit parameter
  if (limit !== undefined && limit !== null && limit !== '') {
    const limitNum = Number(limit);
    if (Number.isNaN(limitNum) || !Number.isFinite(limitNum) || limitNum <= 0 || limitNum > MAX_LIMIT) {
      throw new Error(`Invalid limit parameter: must be a positive number <= ${MAX_LIMIT}`);
    }
    validatedLimit = Math.floor(limitNum);
  }

  return { page: validatedPage, limit: validatedLimit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const { page, limit } = validateQueryParams(req.query.page, req.query.limit);
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(400).json({ 
        error: error instanceof Error ? error.message : 'Invalid query parameters' 
      });
    }
  });

  return app;
}
