import { describe, expect, it } from 'vitest';
import { renderMarkdown } from '../../src/formats/markdown.js';
import { renderText } from '../../src/formats/text.js';
import type { ReportData, ReportOptions } from '../../src/types/report.js';

const normalize = (content: string): string => {
  return content.trim().replace(/\n\s*\n/g, '\n');
};

const sampleData: ReportData = {
  title: 'Quarterly Financial Summary',
  summary: 'Highlights include record revenue...',
  entries: [
    { label: 'North Region', amount: 12345.67 },
    { label: 'South Region', amount: 23456.78 },
    { label: 'West Region', amount: 34567.89 }
  ]
};

describe('report CLI (public smoke)', () => {
  it('renders markdown format without totals', () => {
    const options: ReportOptions = { includeTotals: false };
    const result = renderMarkdown.render(sampleData, options);
    const expectedMarkdown = `# Quarterly Financial Summary

Highlights include record revenue...

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89`;
    expect(normalize(result)).toBe(normalize(expectedMarkdown));
  });

  it('renders markdown format with totals', () => {
    const options: ReportOptions = { includeTotals: true };
    const result = renderMarkdown.render(sampleData, options);
    const expectedMarkdown = `# Quarterly Financial Summary

Highlights include record revenue...

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89

**Total:** $70370.34`;
    expect(normalize(result)).toBe(normalize(expectedMarkdown));
  });

  it('renders text format without totals', () => {
    const options: ReportOptions = { includeTotals: false };
    const result = renderText.render(sampleData, options);
    const expectedText = `Quarterly Financial Summary

Highlights include record revenue...

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89`;
    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('renders text format with totals', () => {
    const options: ReportOptions = { includeTotals: true };
    const result = renderText.render(sampleData, options);
    const expectedText = `Quarterly Financial Summary

Highlights include record revenue...

Entries:
- North Region: $12345.67
- South Region: $23456.78
- West Region: $34567.89

Total: $70370.34`;
    expect(normalize(result)).toBe(normalize(expectedText));
  });

  it('calculates totals correctly', () => {
    const options: ReportOptions = { includeTotals: true };
    const result = renderText.render(sampleData, options);
    expect(result).toContain('Total: $70370.34');
  });

  it('formats amounts with two decimal places', () => {
    const options: ReportOptions = { includeTotals: false };
    const result = renderMarkdown.render(sampleData, options);
    expect(result).toContain('$12345.67');
    expect(result).toContain('$23456.78');
    expect(result).toContain('$34567.89');
  });
});
