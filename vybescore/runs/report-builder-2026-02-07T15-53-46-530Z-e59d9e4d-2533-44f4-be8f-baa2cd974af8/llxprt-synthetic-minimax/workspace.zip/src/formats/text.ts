import type { ReportData, ReportOptions, Formatter } from '../types/report.js';

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

const calculateTotal = (entries: readonly { amount: number }[]): number => {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
};

export const renderText: Formatter = {
  render(data: ReportData, options: ReportOptions): string {
    const parts: string[] = [];

    parts.push(data.title);
    parts.push('');
    parts.push(data.summary);
    parts.push('');
    parts.push('Entries:');

    for (const entry of data.entries) {
      const formattedAmount = formatAmount(entry.amount);
      parts.push(`- ${entry.label}: ${formattedAmount}`);
    }

    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      const formattedTotal = formatAmount(total);
      parts.push('');
      parts.push(`Total: ${formattedTotal}`);
    }

    return parts.join('\n');
  }
};