export interface ReportEntry {
  readonly label: string;
  readonly amount: number;
}

export interface ReportData {
  readonly title: string;
  readonly summary: string;
  readonly entries: readonly ReportEntry[];
}

export interface ReportOptions {
  readonly includeTotals: boolean;
}

export type Format = 'markdown' | 'text';

export interface Formatter {
  render(data: ReportData, options: ReportOptions): string;
}