import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportOptions, Format } from '../types/report.js';

interface ParsedArguments {
  readonly dataPath: string;
  readonly format: Format;
  readonly outputPath?: string;
  readonly includeTotals: boolean;
}

interface ParsedOptions {
  ['--output']?: string;
  ['--includeTotals']?: boolean;
}

const SUPPORTED_FORMATS: readonly Format[] = ['markdown', 'text'];

function parseArguments(argv: readonly string[]): ParsedArguments {
  if (argv.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = argv[2];
  const options: ParsedOptions = {};

  let formatIndex = -1;
  let outputIndex = -1;
  let includeTotals = false;

  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];

    if (arg === '--format') {
      formatIndex = i + 1;
    } else if (arg === '--output') {
      outputIndex = i + 1;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (formatIndex === -1 || formatIndex >= argv.length) {
    throw new Error('--format parameter is required');
  }

  const format = argv[formatIndex] as Format;

  if (!SUPPORTED_FORMATS.includes(format)) {
    throw new Error(`Unsupported format: ${format}`);
  }

  if (outputIndex !== -1 && outputIndex < argv.length) {
    options['--output'] = argv[outputIndex];
  }

  options['--includeTotals'] = includeTotals;

  return {
    dataPath,
    format,
    outputPath: options['--output'],
    includeTotals: options['--includeTotals']
  };
}

function loadReportData(dataPath: string): ReportData {
  try {
    const filePath = join(process.cwd(), dataPath);
    const fileContent = readFileSync(filePath, 'utf8');
    const jsonData = JSON.parse(fileContent);

    const { title, summary, entries } = jsonData;

    if (!title || !summary || !Array.isArray(entries)) {
      throw new Error('Invalid report data: missing required fields (title, summary, entries)');
    }

    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error(`Invalid report data: entries[${i}] must have 'label' (string) and 'amount' (number)`);
      }
    }

    return {
      title,
      summary,
      entries: entries.map((entry: { label: string; amount: number }) => ({
        label: entry.label,
        amount: entry.amount
      }))
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON file');
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${dataPath}`);
    }
    throw error;
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    const filePath = join(process.cwd(), outputPath);
    writeFileSync(filePath, content, 'utf8');
  } else {
    process.stdout.write(content + '\n');
  }
}

function renderReport(
  data: ReportData,
  format: Format,
  options: ReportOptions
): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown.render(data, options);
    case 'text':
      return renderText.render(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArguments(process.argv);
    const reportData = loadReportData(args.dataPath);

    const options: ReportOptions = {
      includeTotals: args.includeTotals
    };

    const renderedContent = renderReport(reportData, args.format, options);
    writeOutput(renderedContent, args.outputPath);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
