const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validates a Base64 string according to the standard specification.
 * Checks for:
 * - Valid Base64 characters (A-Z, a-z, 0-9, +, /)
 * - Proper padding (0-2 = characters at the end only)
 * - Correct length (multiple of 4 when including padding)
 */
function isValidBase64(input: string): boolean {
  // Check for valid characters
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }

  // Check for proper padding placement and length
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end
    const afterPadding = input.substring(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      return false;
    }
    // Total length must be multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
    // Maximum 2 padding characters
    // paddingIndex must be at least input.length - 2 (i.e., padding starts in last 2 positions)
    if (paddingIndex < input.length - 2) {
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding).
 * Rejects invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  // Validate the input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  // Add padding if missing (Buffer.from requires proper padding)
  let normalized = input;
  const paddingNeeded = (4 - (input.length % 4)) % 4;
  if (paddingNeeded > 0) {
    normalized = input + '='.repeat(paddingNeeded);
  }

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if the decoded result is valid UTF-8
    // If the buffer contains invalid UTF-8 sequences, this will throw
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
