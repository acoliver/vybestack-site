import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import { Server } from 'node:http';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

export class FormServer {
  public app: express.Application;
  private db: unknown;
  private dbPath: string;
  private server: Server | null;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.server = null;
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbFile);
      } else {
        this.db = new SQL.Database();
        const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        (this.db as { run: (sql: string) => void }).run(schema);
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (this.db) {
      const data = (this.db as { export: () => Uint8Array }).export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation (simple regex)
    if (data.email && ! /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation (international format)
    if (data.phone && ! /^[+]?[\d\s\-()]+$/.test(data.phone.trim())) {
      errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && ! /^[A-Za-z0-9\s-]+$/.test(data.postalCode.trim())) {
      errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and dashes' });
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET / - Render form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {
          firstName: '',
          lastName: '',
          streetAddress: '',
          city: '',
          stateProvince: '',
          postalCode: '',
          country: '',
          email: '',
          phone: ''
        }
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        // Return form with errors
        const errorMessages = errors.map(e => e.message);
        res.render('form', {
          errors: errorMessages,
          values: formData
        });
        return;
      }

      try {
        // Insert into database
        if (this.db) {
          const stmt = (this.db as { prepare: (sql: string) => unknown }).prepare(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          
          (stmt as { run: (...params: unknown[]) => void }).run(
            formData.firstName.trim(),
            formData.lastName.trim(),
            formData.streetAddress.trim(),
            formData.city.trim(),
            formData.stateProvince.trim(),
            formData.postalCode.trim(),
            formData.country.trim(),
            formData.email.trim(),
            formData.phone.trim()
          );
          
          (stmt as { free: () => void }).free();
          this.saveDatabase();
        } else {
          throw new Error('Database not initialized');
        }

        // Redirect to thank you page
        res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData
        });
      }
    });

    // GET /thank-you - Render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    }) as Server;

    // Graceful shutdown
    const shutdown = (signal: string) => {
      console.log(`\n${signal} received, shutting down gracefully...`);
      
      if (this.server) {
        this.server.close(() => {
          console.log('HTTP server closed');
        });
      }
      
      if (this.db) {
        (this.db as { close: () => void }).close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));
  }
  
  public close(): void {
    if (this.server) {
      this.server.close();
    }
    if (this.db) {
      (this.db as { close: () => void }).close();
    }
  }
}

// Start the server only if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  server.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}