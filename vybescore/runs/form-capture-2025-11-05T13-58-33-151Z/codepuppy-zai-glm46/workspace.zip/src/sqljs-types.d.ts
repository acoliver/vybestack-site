declare module 'sql.js' {
  function initSqlJs(): Promise<{ Database: new (data?: Uint8Array) => unknown }>;
  export default initSqlJs;
}