import { describe, expect, it, beforeAll, afterAll, vi } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

// Mock sql.js for testing - fix the export structure
const mockDatabase = {
  run: vi.fn(),
  prepare: vi.fn(() => ({
    run: vi.fn(),
    free: vi.fn()
  })),
  export: vi.fn(() => new Uint8Array()),
  close: vi.fn()
};

vi.mock('sql.js', () => ({
  default: vi.fn().mockResolvedValue({
    Database: vi.fn(() => mockDatabase)
  })
}));

// Import the server class
import { FormServer } from '../../src/server.js';

let serverInstance: FormServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Create a new server instance 
  serverInstance = new FormServer();
  app = serverInstance.app;
  
  // Manually initialize database for testing
  await (serverInstance as { initializeDatabase(): Promise<void> }).initializeDatabase();
});

afterAll(() => {
  // Clean up the database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close the server connection
  if (serverInstance) {
    serverInstance.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with 200 status', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    // Check that response is text/html
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    // Check that response contains form elements
    expect(response.text).toContain('form');
    expect(response.text).toContain('firstName');
    expect(response.text).toContain('lastName');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    // Should redirect to thank you page (302)
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=/);
  });
  
  it('shows thank you page with first name', async () => {
    const response = await request(app)
      .get('/thank-you?firstName=Alice')
      .expect(200);
    
    // Check that response is text/html
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    // Check for first name in the thank you message
    expect(response.text).toContain('Alice');
    
    // Check for the cheeky scam warning text
    expect(response.text).toMatch(/stranger|internet|identity|spam/i);
  });
  
  it('validates international postal codes', async () => {
    // Test UK postcode
    const ukFormData = {
      firstName: 'James',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'james.smith@example.co.uk',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(ukFormData);
    
    // Should succeed with valid UK postal code
    expect(response.status).toBe(302);
  });
  
  it('rejects invalid email', async () => {
    const invalidFormData = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '456 Oak Ave',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'USA',
      email: 'invalid-email',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(invalidFormData)
      .expect(200); // Should return form with errors, not redirect
    
    // Should show error message
    expect(response.text).toMatch(/valid email/i);
  });
  
  it('handles empty required fields', async () => {
    const emptyFormData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    };
    
    const response = await request(app)
      .post('/submit')
      .send(emptyFormData)
      .expect(200); // Should return form with errors, not redirect
    
    // Should show multiple error messages
    expect(response.text).toMatch(/First name is required/);
    expect(response.text).toMatch(/Last name is required/);
    expect(response.text).toMatch(/Email is required/);
  });
});