import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Get __dirname equivalent in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Database initialization
let db: initSqlJs.Database;
let SQL: initSqlJs.SqlJsStatic | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

async function initDatabase() {
  SQL = await initSqlJs({
    locateFile: (file) => `node_modules/sql.js/dist/${file}`
  });
  
  // Load existing database or create new one
  try {
    const dbFile = fs.readFileSync(dbPath);
    db = new SQL.Database(dbFile);
  } catch (err) {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Alphanumeric postal codes with optional spaces and dashes
  const postalRegex = /^[\d\w\s-]+$/;
  return postalRegex.test(postalCode);
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: {}, data: {} });
});

app.post('/submit', (req, res) => {
  const data = req.body;
  const errors: { [key: string]: string } = {};
  
  // Required field validation
  const requiredFields = ['first_name', 'last_name', 'street_address', 'city', 
                          'state_province', 'postal_code', 'country', 'email', 'phone'];
  
  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  }
  
  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation
  if (data.postal_code && !validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }
  
  // If there are validation errors, re-render the form with errors and data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, data });
  }
  
  // Insert submission into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    
    stmt.run([
      data.first_name, 
      data.last_name, 
      data.street_address, 
      data.city, 
      data.state_province, 
      data.postal_code, 
      data.country, 
      data.email, 
      data.phone
    ]);
    
    stmt.free();
    
    // Export database to file
    const dataBuffer = db.export();
    fs.writeFileSync(dbPath, dataBuffer);
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Initialize database and start server
async function startServer() {
  await initDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      if (db) {
        const dataBuffer = db.export();
        fs.writeFileSync(dbPath, dataBuffer);
        db.close();
      }
      console.log('Process terminated');
    });
  });
  
  process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    server.close(() => {
      if (db) {
        const dataBuffer = db.export();
        fs.writeFileSync(dbPath, dataBuffer);
        db.close();
      }
      console.log('Process terminated');
    });
  });
}

startServer();