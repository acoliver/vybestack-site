/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string.
 */
function isValidBase64(input: string): boolean {
  // Check for valid Base64 characters (standard alphabet + padding)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check for correct padding
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    
    // Padding must be at the end
    if (!input.slice(paddingIndex).split('').every(char => char === '=')) {
      return false;
    }
    
    // Padding can only be 1 or 2 characters and the total length must be a multiple of 4
    const paddingLength = input.length - paddingIndex;
    if (paddingLength > 2 || (input.length % 4) !== 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input.trim()) {
    throw new Error('Input is empty');
  }
  
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
