import { createInput, createComputed, createCallback } from './src/index.js'

// Test computed dependencies tracking
console.log('=== Debugging computed dependencies ===')

const [input, setInput] = createInput(1)
console.log('Input created')

const output = createComputed(() => {
  console.log('Computed function executing')
  return input() + 1
})
console.log('Computed created')

console.log('Setting up callback...')
createCallback(() => {
  console.log('Callback executing')
})

console.log('Changing input value to 3...')
setInput(3)