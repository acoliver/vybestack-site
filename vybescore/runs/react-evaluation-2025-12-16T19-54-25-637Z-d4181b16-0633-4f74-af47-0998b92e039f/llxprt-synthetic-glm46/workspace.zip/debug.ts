import { createInput, createComputed, createCallback } from './src/index.js'

// Manual test to debug the issue
console.log('=== Debugging reactive system ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => {
  console.log('Computed function called, input value:', input())
  return input() + 1
})

let value = 0

console.log('Initial input:', input())
console.log('Initial output:', output())
console.log('Initial value:', value)

createCallback(() => {
  console.log('Callback triggered')
  value = output()
  console.log('New value in callback:', value)
})

console.log('After callback setup:')
console.log('Input:', input())
console.log('Output:', output())
console.log('Value:', value)

console.log('Setting input to 3...')
setInput(3)

console.log('After setInput(3):')
console.log('Input:', input())
console.log('Output:', output())
console.log('Final value:', value)