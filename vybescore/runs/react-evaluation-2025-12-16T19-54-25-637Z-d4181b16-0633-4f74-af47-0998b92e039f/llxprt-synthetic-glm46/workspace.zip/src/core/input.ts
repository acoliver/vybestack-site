import type { EqualFn, GetterFn, InputPair, Options, SetterFn, Subject, Observer } from '../types/reactive.js'
import { updateObserver, setActiveObserver, getActiveObserver, addDependent } from '../types/reactive.js'

const defaultEqual = <T>(lhs: T, rhs: T): boolean => lhs === rhs

export function createInput<T>(value: T, equal?: EqualFn<T>, options?: Options): InputPair<T> {
  // Create a hidden observer for this input
  const observer: Observer<T> = {
    name: options?.name ? `${options?.name}_input` : 'input_observer',
    updateFn: () => subject.value,
    dependents: new Set()
  }
  
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: equal ?? defaultEqual
  }

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addDependent(observer, activeObserver)
    }
    return subject.value
  }

  const setter: SetterFn<T> = (newValue: T): T => {
    if (subject.equalFn?.(subject.value, newValue)) {
      return subject.value
    }
    subject.value = newValue
    
    // Notify all dependents
    if (observer.dependents) {
      observer.dependents.forEach(dep => updateObserver(dep))
    }

    return subject.value
  }

  return [getter, setter]
}