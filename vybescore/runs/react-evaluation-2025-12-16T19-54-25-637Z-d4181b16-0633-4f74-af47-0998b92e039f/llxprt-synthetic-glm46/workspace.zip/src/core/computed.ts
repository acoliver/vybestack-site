import type { EqualFn, GetterFn, Options, UpdateFn, Observer } from '../types/reactive.js'
import { getActiveObserver, updateObserver, addDependent, setActiveObserver } from '../types/reactive.js'

const defaultEqual = <T>(lhs: T, rhs: T): boolean => lhs === rhs

export function createComputed<T>(updateFn: UpdateFn<T>, value?: T, equal?: EqualFn<T>, options?: Options): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    updateFn,
    value
  }

  const getter: GetterFn<T> = () => {
    // Track dependencies
    const parent = getActiveObserver()
    if (parent) {
      addDependent(parent, observer)
    }
    
    // Update value
    setActiveObserver(observer)
    try {
      observer.value = observer.updateFn(observer.value)
    } finally {
      setActiveObserver(parent)
    }
    return observer.value as T
  }

  return getter
}