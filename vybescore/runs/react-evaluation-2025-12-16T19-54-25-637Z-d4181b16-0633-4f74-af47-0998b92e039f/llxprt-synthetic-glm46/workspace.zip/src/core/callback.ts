import type { UnsubscribeFn, UpdateFn, Observer } from '../types/reactive.js'
import { getActiveObserver, updateObserver, addDependent, setActiveObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    updateFn,
    value
  }

  // Wrap the updateFn to track dependencies properly
  const wrappedUpdateFn = (val?: T): T => {
    const parent = getActiveObserver()
    if (parent) {
      addDependent(parent, observer)
    }
    return updateFn(val)
  }
  
  observer.updateFn = wrappedUpdateFn

  // Execute the callback once to set up dependencies and initial value
  setActiveObserver(observer)
  try {
    observer.value = wrappedUpdateFn()
  } finally {
    setActiveObserver(undefined)
  }

  // Simple cleanup - remove from any dependents lists
  return (): void => {
    observer.dependents?.clear()
  }
}