/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface Observer<T> extends ObserverR, ObserverV<T> {
  observer?: Observer<T> | undefined
  dependents?: Set<Observer<T>>
}

export interface SubjectR<T> {
  name?: string
  observer?: Observer<T> | undefined
}

export interface SubjectV<T> {
  value: T
  equalFn: EqualFn<T>
}

export interface Subject<T> extends SubjectR<T>, SubjectV<T> {
  equalFn: EqualFn<T>
}

let rootObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return rootObserver
}

export function addDependent<T>(observer: Observer<T>, dependent: Observer<T>) {
  if (!observer.dependents) {
    observer.dependents = new Set()
  }
  observer.dependents.add(dependent)
}

export function removeDependent<T>(observer: Observer<T>, dependent: Observer<T>) {
  if (observer.dependents) {
    observer.dependents.delete(dependent)
  }
}

export function setActiveObserver<T>(observer?: Observer<T>): void {
  rootObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite loops
  let prev = observer.value
  observer.value = observer.updateFn(prev)
  
  // Notify dependents only if value changed
  if (prev !== observer.value && observer.dependents) {
    observer.dependents.forEach(dep => {
      updateObserver(dep)
    })
  }
}