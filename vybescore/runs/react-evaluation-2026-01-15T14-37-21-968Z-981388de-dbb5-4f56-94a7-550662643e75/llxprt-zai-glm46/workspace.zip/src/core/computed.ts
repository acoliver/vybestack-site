/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> = 
    typeof _equal === 'function' ? _equal : 
    _equal === false ? () => false : 
    defaultEqual

  const observers: (Observer<unknown>)[] = []
  let currentValue: T | undefined = value
  let initialized = false
  
  const o: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (prev?: T) => {
      const newValue = updateFn(prev)
      if (!initialized) {
        initialized = true
        currentValue = newValue
        o.value = newValue
        return newValue
      }
      if (prev !== undefined && equalFn(prev, newValue)) {
        return prev
      }
      currentValue = newValue
      o.value = newValue
      
      // Notify all dependent observers when this computed value changes
      for (const observer of observers) {
        updateObserver(observer)
      }
      
      return newValue
    },
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver && !observers.includes(activeObserver as Observer<unknown>)) {
      observers.push(activeObserver as Observer<unknown>)
    }
    
    // Return the current value without recomputing
    return o.value!
  }
  
  return getter
}
