/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observers: (Observer<unknown>)[] = []
  
  const observer: Observer<T> = {
    value,
    updateFn: (prev?: T) => {
      const newValue = updateFn(prev)
      // Notify all dependent observers when this callback's dependencies change
      for (const obs of observers) {
        updateObserver(obs)
      }
      return newValue
    },
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  // Track this callback as an observer
  const getter = getActiveObserver()
  if (getter && !observers.includes(getter as Observer<unknown>)) {
    observers.push(getter as Observer<unknown>)
  }
  
  return unsubscribe
}
