export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to RFC 5322 with additional restrictions.
 * Accepts typical addresses like name+tag@example.co.uk but rejects
 * double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace first
  value = value.trim();
  
  // Basic structural validation
  if (!value.includes('@') || value.startsWith('@') || value.endsWith('@')) {
    return false;
  }
  
  // Email validation regex with proper constraints
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional validation: no consecutive dots, no domains with underscores
  if (value.includes('..') || value.includes('.@') || value.includes('@.') || value.match(/_/)) {
    return false;
  }
  
  // Leading or trailing dots in local part are invalid
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain should not start or end with hyphen
  const domain = value.substring(localPart.length + 1);
  if (domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (starting with 0 or 1) and invalid lengths.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Trim whitespace first
  const phone = value.trim();
  
  // Check for minimum length
  if (phone.length < 10) {
    return false;
  }
  
  // Check if extensions are allowed and remove them
  const allowExtensions = options?.allowExtensions || false;
  
  if (!allowExtensions) {
    // Reject if extension patterns are found
    const extensionPattern = /\b(ext\.?|x)\s*\d+/i;
    if (extensionPattern.test(phone)) {
      return false;
    }
  }
  
  // Remove all non-digit characters for validation
  const digitsOnly = phone.replace(/\D/g, '');
  
  // Should be 10 digits (local) or 11 digits (with country code)
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false;
  }
  
  // Extract the relevant 10 digits for validation
  const phoneDigits = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneDigits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Pattern match for proper formatting
  const phoneRegex = /^(?:\+1[\s-]*)?\(?([2-9]\d{2})\)?[\s-]*([2-9]\d{2})[\s-]*(\d{4})$/;
  return phoneRegex.test(phone);
}

/**
 * Validates Argentine phone numbers covering both mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code (required if no country code)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber: 6-8 digits total after area code
 * - Separators: single spaces or hyphens allowed
 */
export function isValidArgentinePhone(value: string): boolean {
  // Trim whitespace first
  const phone = value.trim();
  
  // Check for basic format patterns
  const patterns = [
    /^\+54[ -]?\d{3}[ -]\d{3}[ -]\d{4}$/, // +54 341 123 4567
    /^\+54[ -]?\d{2}[ -]\d{4}[ -]\d{4}$/, // +54 11 1234 5678
    /^\d{3}[ -]\d{4}[ -]\d{4}$/,          // 011 1234 5678
    /^\d{4}[ -]\d{4}[ -]\d{4}$/,          // 0341 4234 567
    /^\+54 \d{3} \d{3} \d{4}$/,           // With spaces
    /^\+54-\d{3}-\d{3}-\d{4}$/,           // With hyphens
  ];
  
  // Check if the phone matches any of the expected formats first
  const isKnownFormat = patterns.some(pattern => pattern.test(phone));
  if (isKnownFormat) {
    return true;
  }
  
  // Remove all separators for validation
  const digitsAndPlus = phone.replace(/[ -]/g, '');
  
  // Check if it starts with +54
  const hasCountryCode = digitsAndPlus.startsWith('+54');
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !phone.startsWith('0') && !digitsAndPlus.startsWith('0')) {
    return false;
  }
  
  // Match pattern with country code and optional mobile prefix
  const withCountryCode = /^\+54(?:9)?(\d{2,4})(\d{6,8})$/;
  const withouCountryCode = /^0(?:9)?(\d{2,4})(\d{6,8})$/;
  
  const match = hasCountryCode 
    ? digitsAndPlus.match(withCountryCode)
    : digitsAndPlus.match(withouCountryCode);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Area code validation: 2-4 digits, leading digit 1-9 (not 0)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unconventional naming patterns.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const name = value.trim();
  
  // Must have at least one character and not be empty
  if (!name || name.length === 0) {
    return false;
  }
  
  // Allow unicode letters (including accents), apostrophes, hyphens, and spaces
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if it matches the allowed pattern
  if (!nameRegex.test(name)) {
    return false;
  }
  
  // Additional checks for edge cases
  // No consecutive spaces or special characters at beginning/end
  if (name.includes('  ') || name.startsWith("'") || name.endsWith("'") || 
      name.startsWith('-') || name.endsWith('-')) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(name)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;

  // Start from the rightmost digit and move left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    doubleDigit = !doubleDigit;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx.
 * Checks length, prefix patterns, and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Check common credit card patterns
  // Visa: 4, 13-19 digits
  // Mastercard: 51-55 or 2221-2720, 16 digits
  // AmEx: 34 or 37, 15 digits
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex1 = /^5[1-5]\d{14}$/;
  const mastercardRegex2 = /^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type pattern
  const isValidFormat = visaRegex.test(cardNumber) ||
                        mastercardRegex1.test(cardNumber) ||
                        mastercardRegex2.test(cardNumber) ||
                        amexRegex.test(cardNumber);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}
