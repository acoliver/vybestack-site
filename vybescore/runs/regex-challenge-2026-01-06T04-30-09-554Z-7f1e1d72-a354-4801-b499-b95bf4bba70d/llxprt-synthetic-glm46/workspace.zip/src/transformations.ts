/**
 * Capitalizes the first character of each sentence after .!? punctuation.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Trim start/end and normalize whitespace
  const processed = text.trim().replace(/\s+/g, ' ');
  
  // Define common abbreviations to avoid splitting sentences at
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs'];
  const abbrevPattern = new RegExp(`\\b(?:${abbreviations.join('|')})\\.$`, 'i');
  
  // Split on sentence boundaries, preserving punctuation
  const sentences = processed.split(/([.?!]+)/);
  let result = '';
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i]?.trim() || '';
    const punctuation = sentences[i + 1] || '';
    
    if (sentence) {
      // Find the first non-punctuation character to capitalize
      const firstAlphaIndex = sentence.search(/[a-zA-Z\u00C0-\u017F]/);
      if (firstAlphaIndex >= 0) {
        const firstChar = sentence[firstAlphaIndex];
        const upperChar = firstChar.toUpperCase();
        
        // Capitalize and rebuild
        const beforeCap = sentence.substring(0, firstAlphaIndex);
        const afterCap = sentence.substring(firstAlphaIndex + 1);
        const capitalizedSentence = beforeCap + upperChar + afterCap;
        
        result += capitalizedSentence;
      } else {
        result += sentence;
      }
      
      // Add punctuation and single space
      if (punctuation) {
        result += punctuation;
        // Check if this is likely an abbreviation
        const trimmedSentence = sentence.trim();
        if (!abbrevPattern.test(trimmedSentence)) {
          result += ' ';
        }
      }
    }
  }
  
  // Remove trailing space and return
  return result.trim().replace(/\s{2,}/g, ' ');
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns all detected URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern to match URLs
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s)\]},;"]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => url.replace(/[)\]}.,;']+$/g, ''));
}

/**
 * Converts all http:// URL schemes to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https:// (to avoid double replacement)
  return text.replace(/https?:\/\//g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... following specific rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, queries, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlRegex = /https?:\/\/example\.com(\/[^\s)]*)/gi;
  
  return text.replace(urlRegex, (fullUrl, path) => {
    // Check if URL should skip host rewrite (dynamic content)
    const skipPatterns = [
      /\/cgi-bin/i,
      /[?&]/,  // Query strings
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i,  // Legacy extensions
    ];
    
    const shouldSkip = skipPatterns.some(pattern => pattern.test(path));
    
    if (shouldSkip) {
      // Keep original host but upgrade to https
      return fullUrl.replace('http://', 'https://');
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return 'https://docs.example.com' + path;
    }
    
    // Keep original host but ensure https
    return 'https://example.com' + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted dates.
 * Returns the four-digit year for valid dates, or 'N/A' for invalid format or invalid dates.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = parseInt(dateMatch[3], 10);
  
  // Basic date validation (check for valid days in each month)
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (February can have 29 days)
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > maxDays[month - 1]) {
    return 'N/A';
  }
  
  return year.toString();
}
