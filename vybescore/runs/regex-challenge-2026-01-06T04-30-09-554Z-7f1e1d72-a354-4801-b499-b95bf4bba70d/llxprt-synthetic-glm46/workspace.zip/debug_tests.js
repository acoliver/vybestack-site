// This script will help test edge cases for our validation functions

function runTest(name, testFn) {
  try {
    console.log(`Testing ${name}:`, testFn());
  } catch (e) {
    console.log(`Testing ${name}: ERROR - ${e.message}`);
  }
}

// Test email validation edge cases
function testEmailValidation() {
  console.log("\n=== EMAIL VALIDATION TESTS ===");
  
  runTest("Valid email with subdomain", () => isValidEmail("user@mail.example.co.uk"));
  runTest("Valid email with + tag", () => isValidEmail("user+tag@example.com"));
  runTest("Valid email with dots", () => isValidEmail("first.last@example.com"));
  runTest("Invalid email with trailing @", () => isValidEmail("user@"));
  runTest("Invalid email with consecutive dots", () => isValidEmail("user..name@example.com"));
  runTest("Invalid email with domain underscore", () => isValidEmail("user@example_domain.com"));
  runTest("Invalid email leading dot", () => isValidEmail(".user@example.com"));
  runTest("Invalid email trailing dot", () => isValidEmail("user.@example.com"));
}

// Test US phone validation edge cases
function testUSPhoneValidation() {
  console.log("\n=== US PHONE VALIDATION TESTS ===");
  
  runTest("Valid phone with parentheses", () => isValidUSPhone("(212) 555-7890"));
  runTest("Valid phone with hyphens", () => isValidUSPhone("212-555-7890"));
  runTest("Valid phone with spaces", () => isValidUSPhone("212 555 7890"));
  runTest("Valid phone with +1", () => isValidUSPhone("+1 212-555-7890"));
  runTest("Invalid area code starting 0", () => isValidUSPhone("(012) 555-7890"));
  runTest("Invalid area code starting 1", () => isValidUSPhone("(112) 555-7890"));
  runTest("Too short", () => isValidUSPhone("212-555"));
  runTest("Invalid with letters", () => isValidUSPhone("212-555-abcd"));
}

// Test Argentine phone validation edge cases
function testArgentinePhoneValidation() {
  console.log("\n=== ARGENTINE PHONE VALIDATION TESTS ===");
  
  runTest("Valid mobile with country code", () => isValidArgentinePhone("+54 9 11 1234 5678"));
  runTest("Valid landline without country code", () => isValidArgentinePhone("011 1234 5678"));
  runTest("Valid with country code and hyphens", () => isValidArgentinePhone("+54-341-123-4567"));
  runTest("Valid area code 4 digits", () => isValidArgentinePhone("+54 0343 123 456"));
  runTest("Invalid area code starting 0 with country code", () => isValidArgentinePhone("+54 011 1234 5678"));
  runTest("Invalid without trunk prefix", () => isValidArgentinePhone("11 1234 5678"));
  runTest("Invalid too many digits", () => isValidArgentinePhone("+54 9 11 1234 56789"));
}

 console.log("Test script ready to run with our functions");