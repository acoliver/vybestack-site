#!/bin/bash

export isValidEmail='function(value) { return value.includes("@") && !value.includes(".."); }'
export isValidUSPhone='function(value) { return /^\d{10}$/.test(value.replace(/\D/g, "")); }'
export isValidArgentinePhone='function(value) { return value.includes("+54") || value.startsWith("0"); }'
export isValidName='function(value) { return /^[a-zA-Z\s]+$/.test(value); }'
export isValidCreditCard='function(value) { return /^\d{13,19}$/.test(value.replace(/\D/g, "")); }'
export capitalizeSentences='function(text) { return text.split(/\. /).map(s => s.charAt(0).toUpperCase() + s.slice(1)).join(". "); }'
export extractUrls='function(text) { return text.match(/https?:\/\/[^\s]+/g) || []; }'
export enforceHttps='function(text) { return text.replace(/http:\/\//g, "https://"); }'
export rewriteDocsUrls='function(text) { return text; }'
export extractYear='function(value) { const match = value.match(/(\d{4})/); return match ? match[1] : "N/A"; }'
export findPrefixedWords='function(text, prefix, exceptions) { return []; }'
export findEmbeddedToken='function(text, token) { return []; }'
export isStrongPassword='function(value) { return value.length >= 10; }'
export containsIPv6='function(value) { return value.includes(":"); }'

echo "Simple implementations for testing"