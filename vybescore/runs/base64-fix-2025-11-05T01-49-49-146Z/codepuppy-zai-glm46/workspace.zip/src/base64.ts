/**
 * Encode plain text to Base64 using canonical RFC 4648 Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using canonical RFC 4648 Base64.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Validate Base64 format - only allow canonical Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for invalid padding placement
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    if (paddingIndex !== input.length - 1 && paddingIndex !== input.length - 2) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
    // No non-padding characters after padding starts
    const paddingSection = input.slice(paddingIndex);
    if (!/^(=+)?$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    // Padded inputs must have a length that's a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
