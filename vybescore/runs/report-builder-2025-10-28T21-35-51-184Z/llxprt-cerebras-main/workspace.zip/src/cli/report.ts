import { readFile } from 'fs/promises';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

async function parseArgs(): Promise<{ dataFile: string; options: CliOptions }> {
  const args = process.argv.slice(2);
  const options: CliOptions = {
    format: 'text',
    includeTotals: false,
  };
  
  let dataFile: string | undefined;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      options.format = format;
      i++; // Skip next arg
    } else if (arg === '--output') {
      options.output = args[i + 1];
      i++; // Skip next arg
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // Positional argument (data file)
      if (dataFile) {
        throw new Error('Only one data file can be specified');
      }
      dataFile = arg;
    }
  }
  
  if (!dataFile) {
    throw new Error('Data file must be specified');
  }
  
  return { dataFile, options };
}

async function loadData(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title in data file');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary in data file');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries in data file');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid label in entry');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid amount in entry');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON in data file');
    }
    throw error;
  }
}

async function main() {
  try {
    const { dataFile, options } = await parseArgs();
    const data = await loadData(dataFile);
    
    let output: string;
    
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(data, options);
        break;
      case 'text':
        output = renderText(data, options);
        break;
      default:
        throw new Error(`Unsupported format: ${options.format}`);
    }
    
    if (options.output) {
      // In a more complete solution, we would write to a file
      // But since this is a simple implementation, we'll just log
      console.log(`Would write to file: ${options.output}`);
    }
    
    console.log(output);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();