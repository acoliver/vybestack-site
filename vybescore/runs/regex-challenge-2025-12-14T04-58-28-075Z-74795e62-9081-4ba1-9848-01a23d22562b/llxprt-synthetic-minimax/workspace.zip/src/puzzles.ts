/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary pattern
  const wordPattern = `\\b${escapedPrefix}\\w*\\b`;
  const regex = new RegExp(wordPattern, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const cleanMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      cleanMatch === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by the token (but not at start of string)
  // This captures the digit before the token as part of the match
  const pattern = `(?!^)(\\d)${escapedToken}`;
  const regex = new RegExp(pattern, 'gi');
  
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (e.g., abab should fail)
  // This regex looks for any 2+ character sequence repeated immediately
  if (/(\w{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 with :: shorthand (can appear in different positions)
  const shorthandIPv6 = /(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}/;
  
  // Full IPv6 addresses
  const fullIPv6 = /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/;
  
  // IPv6 with mixed notation (some segments with less than 4 hex digits)
  const mixedIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv4-mapped IPv6 addresses
  const ipv4MappedIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}::(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check for IPv4 patterns and exclude them
  const ipv4Pattern = /(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // If it matches pure IPv4, it's not IPv6
  if (ipv4Pattern.test(value) && !/:/.test(value)) {
    return false;
  }
  
  // Test against various IPv6 patterns
  return shorthandIPv6.test(value) || 
         fullIPv6.test(value) || 
         mixedIPv6.test(value) || 
         ipv4MappedIPv6.test(value);
}