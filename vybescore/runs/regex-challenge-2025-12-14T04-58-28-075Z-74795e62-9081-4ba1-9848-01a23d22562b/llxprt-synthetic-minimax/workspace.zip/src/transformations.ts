/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure proper spacing
  let result = text.trim();
  
  // Find sentence boundaries - after .?! followed by optional whitespace and a new sentence
  // Use a regex that looks for sentence terminators followed by whitespace and a letter
  const sentenceBoundary = /([.!?]+)\s*([a-zA-ZÀ-ÿ0-9])/g;
  
  // Replace function to capitalize the first letter of each sentence
  result = result.replace(sentenceBoundary, (match, terminator, nextChar) => {
    return terminator + ' ' + nextChar.toUpperCase();
  });
  
  // Additional fix for consecutive spaces after sentence terminators
  result = result.replace(/([.!?]+)\s{2,}/g, '$1 ');
  
  // Capitalize the very first character if it's a letter
  if (result.length > 0 && /[a-zA-ZÀ-ÿ]/.test(result[0])) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern to match http/https URLs
  // Matches: http://example.com, https://example.com/path, etc.
  const urlRegex = /\b(?:https?):\/\/[^\s"']+/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up trailing punctuation from URLs
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation characters that are likely not part of the URL
    return url.replace(/[.,;!?)]+$/, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs - using RegExp constructor to avoid escape issues
  const urlPattern = new RegExp('http://([^/\\s]+)(/[^\\s]*)?', 'gi');
  
  return text.replace(urlPattern, (match, hostname, path = '') => {
    let url = 'https://' + hostname + path;
    
    // Check if this is a docs path that should be rewritten
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewriting
      const hasDynamicHints = /(\?.*)|(&.*)|(=.*)|(\.jsp)|(\.php)|(\.asp)|(\.aspx)|(\.do)|(\.cgi)|(\.pl)|(\.py)|(cgi-bin)/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.hostname
        url = 'https://docs.' + hostname + path;
      }
    }
    
    return url;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with validation for month and day
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = new Date(parseInt(year, 10), month, 0).getDate();
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }
  
  return year;
}