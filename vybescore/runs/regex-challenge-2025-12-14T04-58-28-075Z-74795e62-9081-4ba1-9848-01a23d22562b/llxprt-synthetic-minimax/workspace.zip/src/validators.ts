export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern:
  // - Local part: letters, numbers, dots, underscores, hyphens, plus signs
  // - No consecutive dots or trailing dot in local part
  // - Domain: letters, numbers, dots, hyphens
  // - No underscores in domain
  // - No consecutive dots or trailing dot in domain
  // - Domain must have at least one dot
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  
  // Additional validation for double dots
  const hasDoubleDots = /\.\./;
  const hasDomainUnderscore = /@.*\..*_/;
  
  return !hasDoubleDots.test(value) && 
         !hasDomainUnderscore.test(value) && 
         emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except the leading +
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Remove leading + if present to normalize
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('+')) {
    cleaned = cleaned.substring(1);
  }
  
  // If starts with 1 (without +), remove it
  if (cleaned.startsWith('1')) {
    cleaned = cleaned.substring(1);
  }
  
  // Check if we have exactly 10 digits
  if (!/^\d{10}$/.test(cleaned)) {
    return false;
  }
  
  // Validate area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = cleaned.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // For now, extensions are not validated in the core logic
  // The options parameter is available for future extension validation
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  void options;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters to normalize the input
  const digits = value.replace(/\D/g, '');
  
  // Argentine phone number validation logic:
  // 1. If starts with 54 (country code), handle international format
  // 2. If starts with 0 (trunk prefix), handle domestic format
  // 3. Area code: 2-4 digits starting with 1-9
  // 4. Subscriber number: 6-8 digits total
  // 5. Mobile indicator '9' should appear after country code or before area code
  
  if (digits.startsWith('54')) {
    // International format: +54 ...
    const withoutCountry = digits.substring(2);
    
    if (withoutCountry.length < 8 || withoutCountry.length > 12) {
      return false;
    }
    
    // Check for mobile indicator (9) and area code
    let remaining = withoutCountry;
    if (remaining.startsWith('9')) {
      remaining = remaining.substring(1);
    }
    
    // Area code validation (2-4 digits, first digit 1-9)
    if (remaining.length < 2) {
      return false;
    }
    
    const areaCode = remaining.substring(0, Math.min(4, remaining.length - 6));
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    if (!/^[1-9]/.test(areaCode)) {
      return false;
    }
    
    const subscriber = remaining.substring(areaCode.length);
    return subscriber.length >= 6 && subscriber.length <= 8;
    
  } else if (digits.startsWith('0')) {
    // Domestic format: 0... (trunk prefix required)
    const withoutTrunk = digits.substring(1);
    
    if (withoutTrunk.length < 7 || withoutTrunk.length > 11) {
      return false;
    }
    
    // Area code validation (2-4 digits, first digit 1-9)
    if (withoutTrunk.length < 2) {
      return false;
    }
    
    const areaCode = withoutTrunk.substring(0, Math.min(4, withoutTrunk.length - 6));
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    if (!/^[1-9]/.test(areaCode)) {
      return false;
    }
    
    const subscriber = withoutTrunk.substring(areaCode.length);
    return subscriber.length >= 6 && subscriber.length <= 8;
    
  } else {
    // Invalid format (must have either +54 or 0 trunk prefix)
    return false;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and unusual patterns
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  // Check if it matches the basic pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation to reject unusual patterns like "X Æ A-12"
  const hasUnusualSymbols = /[^\p{L}\s'-]/u.test(value);
  const hasDigits = /\d/.test(value);
  const hasStrangeCombinations = /[ÆØÅ]|[A-Z]\s*[A-Z]\s*[A-Z]-[A-Z]\d/.test(value);
  
  return !hasUnusualSymbols && !hasDigits && !hasStrangeCombinations;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Validate card number length and format
  // Visa: 13-19 digits, starts with 4
  // MasterCard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4\d{12}(\d{3})?(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{13}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  let isValidFormat = false;
  
  if (visaRegex.test(cardNumber)) {
    isValidFormat = true;
  } else if (mastercardRegex.test(cardNumber)) {
    isValidFormat = true;
  } else if (amexRegex.test(cardNumber)) {
    isValidFormat = true;
  }
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cardNumber);
}