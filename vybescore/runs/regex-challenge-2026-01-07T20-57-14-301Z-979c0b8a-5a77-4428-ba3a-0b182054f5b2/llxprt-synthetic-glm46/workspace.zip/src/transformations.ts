/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Insert a single space after sentence endings when missing
  result = result.replace(/([.?!])([^\s])/g, '$1 $2');
  
  // Find all sentence boundaries and capitalize the first letter after them
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex pattern to find URLs
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*/gi;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Pattern to match URLs from example.com (using a specific pattern for later replacements)
  
  // First, convert all to https
  let result = text.replace(/http:\/\/example\.com/gi, 'https://example.com');
  
  // Then handle the specific case for docs paths
  // Include the path starting with /docs/ but exclude paths with cgi-bin, query strings, or specific extensions
  result = result.replace(
    /(https:\/\/example\.com(\/docs\/[^?\s&#\n]*)(?!\.(jsp|php|asp|aspx|do|cgi|pl|py)|\?|cgi-bin))/gi,
    'https://docs.example.com$2'
  );
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format and extract year
  const dateMatch = value.match(/^([0]?[1-9]|1[0-2])\/([0]?[1-9]|[12][0-9]|3[01])\/(\d{4})$/);
  
  if (dateMatch) {
    const month = parseInt(dateMatch[1], 10);
    const day = parseInt(dateMatch[2], 10);
    const year = dateMatch[3];
    
    // Basic validation for month/day
    const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    
    // Adjust for leap year
    if ((parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0) {
      daysInMonth[1] = 29; // February
    }
    
    if (month > 0 && month <= 12 && day <= daysInMonth[month - 1]) {
      return year;
    }
  }
  
  return 'N/A';
}
