/**
 * Find words starting with the given prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Find words that start with the prefix
  const prefixPattern = new RegExp(`\\b${prefix}\\w+\\b`, 'g');
  const matches = text.match(prefixPattern) || [];
  
  // Filter words that match but are not in the exceptions list
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Find the token with a preceding digit
  const pattern = new RegExp(`(\\d+)${token}`, 'g');
  const matches = [...text.matchAll(pattern)].map(match => match[0]);
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length: 10 characters
  if (value.length < 10) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one special character/symbol
  if (!/[!@#$%^&*()_+\-=\\[\]{};':"\\|,.<>\\/?~`]/.test(value)) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., 'abab' should fail)
  // Check for any 2-character sequence that repeats immediately
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 address patterns, including shorthand (::)
  // Standard IPv6 (8 groups of 1-4 hex digits)
  const ipv6Standard = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand (e.g., ::1, 2001:db8::1)
  const ipv6Shorthand = /(?:[0-9a-fA-F]{1,4}:){0,7}:(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 in IPv4-mapped format (e.g., ::ffff:192.0.2.128)
  const ipv6IPv4Mapped = /::ffff:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check if any IPv6 pattern matches and IPv4 doesn't
  const hasIPv6 = ipv6Standard.test(value) || ipv6Shorthand.test(value) || ipv6IPv4Mapped.test(value);
  
  // Exclude IPv4 addresses (simple pattern)
  const isIPv4Only = /^(?:\d{1,3}\.){3}\d{1,3}$/.test(value) && !/::/.test(value);
  
  return hasIPv6 && !isIPv4Only;
}
