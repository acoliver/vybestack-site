/**
 * Validate email addresses according to typical RFC rules.
 * Accept typical addresses such as name+tag@example.co.uk.
 * Reject double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic validation: must contain @ and not start/end with special chars
  const atPos = value.indexOf('@');
  if (atPos <= 0 || atPos === value.length - 1) return false;
  
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject trailing dots in local part
  const localPart = value.substring(0, atPos);
  if (localPart.endsWith('.')) return false;
  
  // Reject domains with underscores
  const domain = value.substring(atPos + 1);
  if (domain.includes('_')) return false;
  
  // Check overall structure
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common formats and optional +1 country code.
 * Accept formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Reject impossible area codes (leading 0/1) and inputs that are too short.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Strip whitespace to normalize
  const cleanValue = value.replace(/\s/g, '');
  
  // Optional country code +1
  const cleanPhoneNumber = cleanValue.startsWith('+1') ? cleanValue.substring(2) : cleanValue;
  
  // After removing country code, should have 10 digits for standard US format
  const digitPattern = /^\+?1?[\s-]?(\(?[2-9]\d{2}\)?[\s-]?)?[2-9]\d{2}[\s-]?\d{4}$/;
  
  // Test against overall pattern
  if (!digitPattern.test(cleanValue)) return false;
  
  // Extract just digits for validation
  const digits = cleanPhoneNumber.replace(/\D/g, '');
  
  // Must have exactly 10 digits for US phone numbers
  if (digits.length !== 10) return false;
  
  // Area code must not start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 * Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54.
 * - Optional trunk prefix 0 immediately before the area code.
 * - Optional mobile indicator 9 between country/trunk and the area code.
 * - Area code must be 2-4 digits (leading digit 1-9).
 * - Subscriber number (after the area code) must contain 6-8 digits in total.
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * - Allow single spaces or hyphens as separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Extract digit groups for validation
  let digits = cleanValue.replace(/\D/g, '');
  
  // If no country code, must start with 0 (trunk prefix)
  if (!cleanValue.includes('+54') && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Remove country code and trunk prefix for validation
  if (cleanValue.startsWith('+54')) {
    digits = digits.substring(2);
    if (cleanValue.charAt(3) === '0') {
      digits = digits.substring(1);
    }
  } else if (cleanValue.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Remove mobile prefix if present
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Area code must be 2-4 digits, leading digit 1-9
  if (!/^([1-9]\d{1,3})/.test(digits)) {
    return false;
  }
  
  // Extract area code and subscriber number
  let subscriberDigits;
  for (let i = 2; i <= 4 && i <= digits.length; i++) {
    digits.substring(0, i); // areaCode (unused but required for position calculation)
    subscriberDigits = digits.substring(i);
    
    // Subscriber number must be 6-8 digits
    if (subscriberDigits.length >= 6 && subscriberDigits.length <= 8) {
      return true;
    }
  }
  
  return false;
}
  

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Simplified pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes, hyphens, spaces
  // - No digits
  // - At least one letter
  const nameRegex = /^[\p{L}][\p{L}'’-]*(?:\s[\p{L}'’-]+)*[\p{L}'’-]*$/u;
  
  // Additional check: reject names with digits
  if (/\d/.test(value)) return false;
  
  // Make sure it's not empty
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter character
  return /[\p{L}]/u.test(value);
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx using length, prefix and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digits
  const digits = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55, 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[1-9]\d{3}|0\d{4})\d{10}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the credit card patterns
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}

/**
 * Helper function to run the Luhn algorithm check on a credit card number
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit and work left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1; // Sum the digits of the product
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
