import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');
const dbDir = path.resolve(projectRoot, 'data');
const dbPath = path.resolve(dbDir, 'submissions.sqlite');
const schemaPath = path.resolve(projectRoot, 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
let server: express.Express | null = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(data: Partial<FormData>): string[] {
  const errors: string[] = [];

  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  }
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  }
  if (!data.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  if (!data.city?.trim()) {
    errors.push('City is required');
  }
  if (!data.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  if (!data.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and hyphens');
  }
  if (!data.country?.trim()) {
    errors.push('Country is required');
  }
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Email must be valid');
  }
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return errors;
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  let dbInstance: Database;
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(dbInstance: Database): void {
  const data = dbInstance.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

async function createServer(): Promise<express.Express> {
  const app = express();

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  app.set('views', path.resolve(projectRoot, 'src', 'templates'));
  app.set('view engine', 'ejs');

  app.get('/', (req: Request, res: Response) => {
    res.render('form', { errors: [], values: {} });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const errors = validateForm(formData);

    if (errors.length > 0) {
      res.status(400);
      return res.render('form', { errors, values: formData });
    }

    if (!db) {
      throw new Error('Database not initialized');
    }

    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim(),
      ]
    );

    saveDatabase(db);

    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  });

  app.use((err: Error, _req: Request, res: Response) => {
    console.error('Server error:', err);
    res.status(500).send('Internal server error');
  });

  return app;
}

export async function start(): Promise<{ app: express.Express; close: () => Promise<void> }> {
  db = await initializeDatabase();
  const app = await createServer();
  server = app;

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

  return new Promise((resolve) => {
    const listener = app.listen(port, '127.0.0.1', () => {
      console.log(`Server listening on port ${port}`);
      resolve({
        app,
        close: async () => {
          return new Promise<void>((closeResolve) => {
            listener.close(() => {
              if (db) {
                db.close();
                db = null;
              }
              closeResolve();
            });
          });
        },
      });
    });
  });
}

export async function stop(): Promise<void> {
  if (server) {
    return new Promise<void>((resolve, reject) => {
      try {
        if (db) {
          db.close();
          db = null;
        }
        resolve();
      } catch (err) {
        reject(err);
      }
    });
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  start().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });

  process.on('SIGTERM', async () => {
    console.log('SIGTERM received, shutting down gracefully');
    await stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.log('SIGINT received, shutting down gracefully');
    await stop();
    process.exit(0);
  });
}
