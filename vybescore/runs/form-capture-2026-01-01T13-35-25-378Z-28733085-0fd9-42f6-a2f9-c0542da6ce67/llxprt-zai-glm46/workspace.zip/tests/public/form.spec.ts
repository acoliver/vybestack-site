import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { start } from '../../src/server.js';

let serverInstance: { app: express.Application; close: () => Promise<void> } | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  serverInstance = await start();
});

afterAll(async () => {
  if (serverInstance) {
    await serverInstance.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(serverInstance!.app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    expect($('label[for="firstName"]').text().trim()).toBe('First name');
    expect($('label[for="email"]').text().trim()).toBe('Email');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    expect(fs.existsSync(dbPath)).toBe(true);

    const thankYouResponse = await request(serverInstance!.app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
  });

  it('validates required fields', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({});

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list li')).toHaveLength(9);
    expect(response.text).toContain('First name is required');
  });

  it('validates email format', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Email must be valid');
  });

  it('validates phone format', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: 'invalid-phone!',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number must contain only');
  });

  it('validates postal code format', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: 'invalid@postal',
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Postal / Zip code must contain only');
  });

  it('accepts international phone numbers', async () => {
    const formData = {
      firstName: 'Carlos',
      lastName: 'Garcia',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
  });

  it('preserves form values on validation error', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('Test');
    expect($('input[name="city"]').val()).toBe('Test City');
  });
});
