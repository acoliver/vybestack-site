/**
 * Encode plain text to Base64 using the standard alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 text.
 * Accepts padding optional and standard Base64 characters only.
 */
export function decode(input: string): string {
  // Validate basic Base64 format
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: re-encode the decoded data and compare
    // This ensures the input was properly formed
    const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    const normalizedInput = input.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReEncoded) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
