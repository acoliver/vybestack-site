// Debug script to understand reactive behavior
import { createInput, createComputed, createCallback } from './src/index.js'

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const output = createComputed(() => input() + 1)
console.log('Initial computed:', output())

let value = 0
const unsubscribe = createCallback(() => {
  console.log('Callback triggered with input:', input(), 'computed:', output())
  value = output()
})

console.log('Before setting input, callback value:', value)
setInput(3)
console.log('After setting input, callback value:', value)