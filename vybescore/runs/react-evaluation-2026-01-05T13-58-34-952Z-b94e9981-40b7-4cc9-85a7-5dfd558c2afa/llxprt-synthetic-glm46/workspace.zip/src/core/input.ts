/**
 * Input closure implementation for reactive primitives.
 */

import{
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addObserverToSubject,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Default equality function
  let equalFn: EqualFn<T>
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (typeof equal === 'boolean' && equal) {
    equalFn = (a, b) => a === b
  } else {
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserverToSubject(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed to avoid unnecessary updates
    if (!equalFn || !equalFn(s.value, nextValue)) {
      s.value = nextValue
      // Notify all observers to update
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
