/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  removeObserverFromSubject,
  observerToSubjects
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it depends on
    const subjects = observerToSubjects.get(observer)
    if (subjects) {
      for (const subject of subjects) {
        removeObserverFromSubject(subject, observer)
      }
    }
  }
}
