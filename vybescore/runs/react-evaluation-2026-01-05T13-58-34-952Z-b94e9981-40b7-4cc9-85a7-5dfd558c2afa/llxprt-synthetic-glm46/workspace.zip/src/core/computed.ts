/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  notifyObservers,
  addObserverToSubject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Default equality function
  let equalFn: EqualFn<T>
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = (a, b) => a === b
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
// Initialize computed value if not explicitly provided
  if (o.value === undefined) {
    updateObserver(o)
  }
  
  // Create the computed getter function
  const computedGetter = (): T => {
    // Register this computed as a dependency for the current observer
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      addObserverToSubject(computedGetter, currentObserver)
    }
    
    // Store the current value to check for changes later
    const currentValue = o.value
    
    // Update the computed value by evaluating its dependencies
    updateObserver(o)
    
    // If the computed value changed, notify dependent observers
    if (currentValue === undefined || currentValue === null || !equalFn(currentValue, o.value!)) {
      notifyObservers(computedGetter)
    }
    
    return o.value!
  }
  
  return computedGetter
}
