/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Map to store subjects and their observers for dependency tracking
const subjectToObservers = new WeakMap<object, Set<ObserverR>>()
const observerToSubjects = new WeakMap<ObserverR, Set<object>>()

export let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Check if this is a computed function with default parameters
    // If the current value is undefined, try calling without arguments first
    let newValue: T
    if (observer.value === undefined && observer.updateFn.length === 1) {
      try {
        // Try calling without arguments to trigger default parameter
        newValue = (observer.updateFn as () => T)()
      } catch (e) {
        // Fall back to normal behavior
        newValue = observer.updateFn(observer.value)
      }
    } else {
      newValue = observer.updateFn(observer.value)
    }
    // Always set the new value
    observer.value = newValue
  } finally {
    activeObserver = previous
  }
}

// Helper functions for dependency tracking
export function addObserverToSubject(subject: object, observer: ObserverR): void {
  // Only track functions and objects with observers
  if (typeof subject === 'function' || (typeof subject === 'object' && subject !== null)) {
    if (!subjectToObservers.has(subject)) {
      subjectToObservers.set(subject, new Set())
    }
    subjectToObservers.get(subject)!.add(observer)
    
    if (!observerToSubjects.has(observer)) {
      observerToSubjects.set(observer, new Set())
    }
    observerToSubjects.get(observer)!.add(subject)
  }
}

export function removeObserverFromSubject(subject: object, observer: ObserverR): void {
  const observers = subjectToObservers.get(subject)
  if (observers) {
    observers.delete(observer)
  }
  
  const subjects = observerToSubjects.get(observer)
  if (subjects) {
    subjects.delete(subject)
  }
}

export function notifyObservers(subject: object): void {
  const observers = subjectToObservers.get(subject)
  if (observers) {
    // Create a copy of the observers set to avoid issues with modifications during iteration
    const observersCopy = new Set(observers)
    // Convert to array to ensure notification order is consistent
    const observersArray = Array.from(observersCopy)
    for (const observer of observersArray) {
      try {
        updateObserver(observer as Observer<unknown>)
      } catch (e) {
        // Ignore errors during observer updates
      }
    }
  }
}

// Export the WeakMap for use in other modules
export { observerToSubjects }
