const INVALID_CHARS_REGEX = /[^A-Za-z0-9+/=]/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes padding as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input is required for decoding');
  }

  // Check for characters outside the Base64 alphabet (excluding padding)
  if (INVALID_CHARS_REGEX.test(input.replace(/=/g, ''))) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for proper structure (valid padding position)
  let normalized = input;
  
  // Accept URL-safe Base64 by converting to standard Base64
  normalized = normalized.replace(/-/g, '+').replace(/_/g, '/');

  try {
    const decoded = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Verify that decoding was successful by checking if the decoded string is valid UTF-8
    // and re-encoding it to see if it matches the input (modulo padding)
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64').replace(/=+$/, '');
    const normalizedForCompare = normalized.replace(/=+$/, '');
    
    if (reencoded !== normalizedForCompare) {
      throw new Error('Failed to decode Base64 input');
    }
    
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
