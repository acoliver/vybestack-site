/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace
  const normalized = input.trim();
  
  // Validate that input contains only valid Base64 characters
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    const result = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Additional validation: if we got empty output but had non-empty input,
    // it might have been invalid (e.g., just padding chars)
    if (result === '' && normalized.replace(/=+$/, '').length > 0) {
      // Try encoding back to see if it matches
      const reEncoded = Buffer.from(result, 'utf8').toString('base64');
      if (reEncoded === '') {
        throw new Error('Invalid Base64 input: failed to decode');
      }
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
