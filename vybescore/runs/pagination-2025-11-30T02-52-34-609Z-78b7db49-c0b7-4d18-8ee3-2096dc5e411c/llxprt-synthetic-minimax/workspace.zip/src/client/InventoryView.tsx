import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No items found.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  hasNext, 
  onPrevious, 
  onNext 
}: { 
  page: number; 
  hasNext: boolean; 
  onPrevious: () => void; 
  onNext: () => void; 
}): JSX.Element {
  return (
    <div style={{ marginTop: '1rem' }}>
      <button 
        onClick={onPrevious} 
        disabled={page <= 1}
        style={{ marginRight: '0.5rem' }}
      >
        Previous
      </button>
      <span style={{ margin: '0 1rem' }}>Page {page}</span>
      <button 
        onClick={onNext} 
        disabled={!hasNext}
        style={{ marginLeft: '0.5rem' }}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePrevious = (): void => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = (): void => {
    if (data && data.hasNext) {
      setCurrentPage(currentPage + 1);
    }
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error') {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert" style={{ color: 'red' }}>
          {error ?? 'Unable to load inventory.'}
        </p>
      </section>
    );
  }

  if (!data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>Unable to load inventory data.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        page={data.page}
        hasNext={data.hasNext}
        onPrevious={handlePrevious}
        onNext={handleNext}
      />
      <div style={{ marginTop: '0.5rem', fontSize: '0.9rem', color: '#666' }}>
        Total items: {data.total}
      </div>
    </section>
  );
}
