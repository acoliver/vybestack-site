import * as fs from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { formatMarkdown } from '../formats/markdown.js';
import { formatText } from '../formats/text.js';

function parseArguments(args: string[]): { dataFile: string; options: CLIOptions } {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    throw new Error('Missing --format option');
  }
  
  if (formatIndex + 1 >= args.length) {
    throw new Error('Missing format value after --format');
  }
  
  const format = args[formatIndex + 1] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  const outputIndex = args.indexOf('--output');
  const includeTotalsIndex = args.indexOf('--includeTotals');
  
  let output: string | undefined;
  if (outputIndex !== -1) {
    if (outputIndex + 1 >= args.length) {
      throw new Error('Missing output path after --output');
    }
    output = args[outputIndex + 1];
  }
  
  const options: CLIOptions = {
    format,
    output,
    includeTotals: includeTotalsIndex !== -1
  };
  
  return { dataFile, options };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid "label" in entry at index ${i}`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid "amount" in entry at index ${i}`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Unknown error reading file');
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  switch (options.format) {
    case 'markdown':
      return formatMarkdown(data, options);
    case 'text':
      return formatText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    fs.writeFileSync(outputPath, content, 'utf-8');
  } else {
    process.stdout.write(content);
  }
}

// Main execution
try {
  const { dataFile, options } = parseArguments(process.argv);
  
  // Validate data file exists
  if (!fs.existsSync(dataFile)) {
    throw new Error(`File not found: ${dataFile}`);
  }
  
  const reportData = loadReportData(dataFile);
  const renderedReport = renderReport(reportData, options);
  
  writeOutput(renderedReport, options.output);
} catch (error) {
  const message = error instanceof Error ? error.message : 'Unknown error';
  console.error(`Error: ${message}`);
  process.exit(1);
}