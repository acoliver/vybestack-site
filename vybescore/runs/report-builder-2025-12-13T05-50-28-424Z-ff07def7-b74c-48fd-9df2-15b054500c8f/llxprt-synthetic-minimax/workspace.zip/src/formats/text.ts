import { ReportData, CLIOptions } from '../types.js';

export function formatText(data: ReportData, options: CLIOptions): string {
  const { title, summary, entries } = data;
  
  let output = `${title}\n\n`;
  output += `${summary}\n\n`;
  output += `Entries:\n`;
  
  for (const entry of entries) {
    const amount = entry.amount.toFixed(2);
    output += `- ${entry.label}: $${amount}\n`;
  }
  
  if (options.includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\nTotal: $${total.toFixed(2)}`;
  }
  
  return output;
}