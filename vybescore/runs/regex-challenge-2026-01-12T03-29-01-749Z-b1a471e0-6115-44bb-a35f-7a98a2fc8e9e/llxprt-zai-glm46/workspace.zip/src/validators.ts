export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Luhn checksum helper for credit card validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map((d) => parseInt(d, 10));
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Email validation accepting addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Leading/trailing whitespace check
  const trimmed = value.trim();
  if (trimmed !== value) {
    return false;
  }

  // Basic structure: local@domain.tld
  // Local part: alphanumeric + allowed special chars, no leading/trailing dots, no consecutive dots
  // Domain: alphanumeric labels with hyphens (but not at start/end), no underscores
  // TLD: at least 2 letters, can have multiple parts (co.uk)
  const emailRegex = /^(?![.])[A-Za-z0-9!#$%&'*+/=?^_`{|}~+-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~+-]+)*@(?![-])[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)*\.[A-Za-z]{2,}(?<![-])$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for disallowed patterns
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // No underscore in domain
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }

  // Domain labels can't start or end with hyphen
  const labels = domainPart.split('.');
  for (const label of labels) {
    if (label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
  }

  // TLD must be only letters (no digits or hyphens in the final part)
  const tld = labels[labels.length - 1];
  if (!/^[A-Za-z]+$/.test(tld)) {
    return false;
  }

  return true;
}

/**
 * US phone number validation supporting common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const trimmed = value.trim();

  // Extract digits only
  const digitsOnly = trimmed.replace(/\D/g, '');

  // With optional +1, we should have 11 digits (with country code) or 10 digits (without)
  // Minimum 10 digits required
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }

  // If 11 digits, must start with 1 (country code)
  let mainDigits = digitsOnly;
  if (digitsOnly.length === 11) {
    if (digitsOnly[0] !== '1') {
      return false;
    }
    mainDigits = digitsOnly.slice(1);
  }

  // Now mainDigits should be exactly 10 digits
  if (mainDigits.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = mainDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = mainDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Check format matches common patterns
  // Accepts: +1XXXXXXXXXX, +1 XXX-XXX-XXXX, +1 (XXX) XXX-XXXX, (XXX) XXX-XXXX, XXX-XXX-XXXX, XXXXXXXXXX
  const formatRegex = /^(\+1\s*)?(\(\d{3}\)\s*|\d{3}[-\s]?)?\d{3}[-\s]?\d{4}$/;
  return formatRegex.test(trimmed);
}

/**
 * Argentine phone number validation covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  const trimmed = value.trim();

  // Remove spaces and hyphens for validation
  const cleaned = trimmed.replace(/[\s-]/g, '');

  // Pattern breakdown:
  // Optional +54 country code, or 0 trunk prefix required if no country code
  // Optional mobile indicator 9 between country/trunk and area code
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits total (may include additional trunk prefix digits)
  const argPhoneRegex = /^(?:\+54)?(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;

  if (!argPhoneRegex.test(cleaned)) {
    return false;
  }

  // When country code is omitted, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }

  // Extract area code (after optional +54, optional 0, optional 9)
  const mainPart = cleaned.replace(/^\+54/, '').replace(/^0/, '').replace(/^9/, '');

  // Area code should be 2-4 digits starting with 1-9
  // We need to determine where area code ends and subscriber begins
  // Total length of mainPart should be between 8 (2+6) and 12 (4+8)

  // Try to extract area code (2-4 digits) and subscriber (6-8 digits)
  let found = false;
  for (let areaLen = 2; areaLen <= 4; areaLen++) {
    const subscriberLen = mainPart.length - areaLen;
    if (subscriberLen >= 6 && subscriberLen <= 8) {
      const areaCode = mainPart.slice(0, areaLen);
      if (/^[1-9]\d*$/.test(areaCode)) {
        found = true;
        break;
      }
    }
  }

  return found;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  const trimmed = value.trim();

  // Must have at least one character
  if (trimmed.length === 0) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // \p{L} matches any unicode letter, \p{M} matches marks (accents)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(trimmed)) {
    return false;
  }

  // Check for digits specifically
  if (/\d/.test(trimmed)) {
    return false;
  }

  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) {
    return false;
  }

  // Reject obviously problematic patterns like Æ (if it's combined with digits/symbols)
  // The X Æ A-12 case would be caught by the digit check above

  // Check for repeated special characters that look suspicious
  if (/--|''/.test(trimmed)) {
    return false;
  }

  // Cannot start or end with special chars (apostrophe, hyphen)
  if (/^['\-\s]|['\-\s]$/.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa (starts with 4, 13-19 digits), Mastercard (starts with 51-55 or 2221-2720, 16 digits),
 * and AmEx (starts with 34 or 37, 15 digits).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Check length and prefix patterns
  // Visa: 13-19 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37

  const visaRegex = /^4\d{12,18}$/; // 13-19 digits total
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7][0-2]\d{13})$/; // 16 digits, 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits

  const isValidLength = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!isValidLength) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
