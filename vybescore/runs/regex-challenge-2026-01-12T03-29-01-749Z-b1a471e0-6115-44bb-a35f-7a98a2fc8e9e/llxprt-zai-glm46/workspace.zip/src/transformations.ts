/**
 * Capitalize the first character of each sentence.
 * - Capitalize after sentence-ending punctuation (.?!)
 * - Insert exactly one space between sentences if input omitted it
 * - Collapse extra spaces while preserving sensible spacing
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces and tabs into one
  let normalized = text.replace(/\s+/g, ' ');

  // Ensure one space after sentence-ending punctuation if missing
  // Look for punctuation followed by a lowercase letter (no space in between)
  normalized = normalized.replace(/([.!?])([a-z])/g, '$1 $2');

  // Capitalize first character of the string
  normalized = normalized.replace(/^[a-z]/, (c) => c.toUpperCase());

  // Capitalize after sentence-ending punctuation, being careful about abbreviations
  // Common abbreviations to check for (not exhaustive)
  const abbreviations = [
    'Mr',
    'Mrs',
    'Ms',
    'Dr',
    'Prof',
    'Sr',
    'Jr',
    'vs',
    'etc',
    'eg',
    'ie',
    'approx',
    'dept',
    'univ',
    'assn',
    'ave',
    'blvd',
    'st',
    'rd',
    'mt'
  ];

  // Build regex to avoid capitalizing after abbreviations
  // Pattern: punctuation followed by space, then (not an abbreviation + capital letter)
  const abbrPattern = abbreviations.join('|');
  const abbrRegex = new RegExp('\\b(' + abbrPattern + ')\\.$', 'i');

  // Split into sentences and process
  const sentences: string[] = [];
  let currentSentence = '';

  for (let i = 0; i < normalized.length; i++) {
    currentSentence += normalized[i];

    // Check if we're at sentence-ending punctuation
    if (/[.!?]/.test(normalized[i])) {
      // Look ahead to see if this is really the end of a sentence
      // (next char is space, end of string, or capital letter)
      const nextChar = normalized[i + 1];
      if (!nextChar || nextChar === ' ' || (nextChar === nextChar.toUpperCase() && nextChar !== nextChar.toLowerCase())) {
        // Check if current sentence ends with an abbreviation
        const trimmed = currentSentence.trim();
        const words = trimmed.split(' ');
        const lastWord = words[words.length - 1].replace(/[.!?]/g, '');

        if (!abbrRegex.test(lastWord + '.')) {
          // This is a sentence boundary
          sentences.push(currentSentence);
          currentSentence = '';
        }
      }
    }
  }

  if (currentSentence) {
    sentences.push(currentSentence);
  }

  // Capitalize first letter after sentence boundaries
  const result = sentences.join('').split('').map((char, index, arr) => {
    // First char
    if (index === 0) {
      return char.toUpperCase();
    }
    // After .!? followed by space
    if (index >= 2 && /[.!?]/.test(arr[index - 2]) && arr[index - 1] === ' ') {
      return char.toUpperCase();
    }
    return char;
  }).join('');

  return result;
}

/**
 * Find URLs in the text and return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching:
  // - Protocol: http://, https://, www. (implicit http://)
  // - Domain: alphanumeric with hyphens and dots
  // - Optional port
  // - Path, query, fragment
  // - Exclude trailing punctuation (.,;!?)
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"{}|^`[\]]+[^\s<>"{}|^`[\].,;!?:]/gi;

  const matches = text.match(urlRegex) || [];

  // For each match, also strip any trailing punctuation that might have been included
  return matches.map(url => {
    // Remove trailing characters that aren't part of URL
    return url.replace(/[,;.!?]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, ?, &, =, .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Still upgrade scheme for those dynamic URLs
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  // We need to be specific about the domain since the spec mentions example.com
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;

  // Dynamic hints that should prevent host rewrite
  const dynamicHints = [
    'cgi-bin',
    '\\?',
    '&',
    '=',
    '\\.jsp',
    '\\.php',
    '\\.asp',
    '\\.aspx',
    '\\.do',
    '\\.cgi',
    '\\.pl',
    '\\.py'
  ];
  const dynamicPattern = new RegExp(dynamicHints.join('|'));

  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';

    // Check if path has dynamic hints or starts with /docs/
    const hasDynamicHints = dynamicPattern.test(path);
    const isDocsPath = path.startsWith('/docs/');

    if (isDocsPath && !hasDynamicHints) {
      // Rewrite to docs.example.com
      return `${newProtocol}docs.${domain}${path}`;
    } else {
      // Just upgrade protocol
      return `${newProtocol}${domain}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31,
    2: 29, // Leap year considered valid
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31
  };

  const maxDay = daysInMonth[month];
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }

  return year;
}
