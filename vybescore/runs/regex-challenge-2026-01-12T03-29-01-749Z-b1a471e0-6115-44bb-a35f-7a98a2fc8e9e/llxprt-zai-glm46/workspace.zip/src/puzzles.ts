/**
 * Match words starting with the prefix but excluding banned words.
 * Uses regex with word boundaries.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with the prefix
  // \b ensures word boundary, [a-zA-Z]* matches the rest of the word
  const pattern = new RegExp('\\b' + escapedPrefix + '[a-zA-Z]*\\b', 'g');

  const matches = text.match(pattern) || [];

  // Filter out exceptions and duplicates
  const filtered = matches.filter(word => !exceptions.includes(word));

  // Return unique words
  return [...new Set(filtered)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern: match digit+token combination when token appears after a digit
  // Use \b to ensure word boundary after the token
  const pattern = new RegExp('\\d' + escapedToken + '(?![a-zA-Z0-9])', 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Length check
  if (value.length < 10) {
    return false;
  }

  // Whitespace check
  if (/\s/.test(value)) {
    return false;
  }

  // Uppercase check
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Lowercase check
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Digit check
  if (!/\d/.test(value)) {
    return false;
  }

  // Symbol check (any non-alphanumeric character)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (abab, abcabc, 1212, etc.)
  // We look for patterns of length 2-5 that repeat immediately
  for (let len = 2; len <= 5; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.slice(i, i + len);
      const nextSegment = value.slice(i + len, i + len * 2);
      if (segment === nextSegment) {
        return false;
      }
    }
  }

  // Check for repeated characters (3 or more same chars in a row)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * IPv6 format: 8 groups of 1-4 hex digits separated by colons, with :: shorthand for consecutive zero groups.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern (to exclude)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;

  // IPv6 pattern - need to handle both full and shorthand notation
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can replace consecutive zero groups
  const ipv6Pattern = /^(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(?:ffff(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(?:25[0-5]|(?:2[0-4]|1{0,1}[0-9]){0,1}[0-9]))$/;

  // Find potential IPv6 addresses in the text
  // We'll extract segments that look like IPv6 and test them
  const potentialIpv6 = value.match(/(?:(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})|(?::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})|::/g);

  if (!potentialIpv6) {
    return false;
  }

  // Check each potential match
  for (const match of potentialIpv6) {
    // First verify it's not just an IPv4
    if (ipv4Pattern.test(match)) {
      continue;
    }

    // Test if it's a valid IPv6 address
    if (ipv6Pattern.test(match)) {
      return true;
    }
  }

  return false;
}
