import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');
const ROOT_DIR = path.resolve(__dirname, '..');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(ROOT_DIR, 'public')));

// EJS setup - check if we're in development or production
const isDev = fs.existsSync(path.resolve(__dirname, 'templates'));
app.set('view engine', 'ejs');
app.set('views', isDev 
  ? path.resolve(__dirname, 'templates')
  : path.resolve(ROOT_DIR, 'src', 'templates')
);

// Ensure database is initialized middleware
app.use(async (req, res, next) => {
  if (!db) {
    db = await initializeDatabase();
  }
  next();
});

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading + or @
  const phoneRegex = /^[+@]?[\d\s()-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase().trim()} is required`,
      });
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number can contain digits, spaces, parentheses, dashes, and a leading @',
    });
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code must contain only letters and numbers',
    });
  }

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let database: Database;

  if (fs.existsSync(DB_PATH)) {
    // Load existing database
    const buffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(buffer);
  } else {
    // Create new database
    database = new SQL.Database();
    
    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);
    
    // Save to disk
    saveDatabase(database);
  }

  return database;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {} as Partial<FormData>,
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    // Validation failed - re-render form with errors
    const errorMessages = errors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
    return;
  }

  // Insert into database
  if (!db) {
    throw new Error('Database not initialized');
  }

  db.run(
    `INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]
  );

  // Save database to disk
  saveDatabase(db);

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req, res) => {
  // Get the most recent submission for personalization
  let firstName = 'friend';
  
  if (db) {
    const result = db.exec(
      'SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1'
    );
    if (result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  }

  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen> | null = null;

function shutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    db.close();
    db = null;
  }
  
  if (server) {
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    console.log('Initializing database...');
    db = await initializeDatabase();
    console.log('Database initialized');

    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, start, shutdown };

// Auto-start if this is the main module
start();
