import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../../src/server.js';

let closeServer: (() => void) | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Start the server in the background
  const PORT = 3536; // Use a different port for testing
  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const s = app.listen(PORT, () => resolve(s));
  });
  
  closeServer = () => {
    server.close();
  };
});

afterAll(() => {
  if (closeServer) {
    closeServer();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required fields
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check form action
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify we can access the thank you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    expect($('body').text()).toContain('John');
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBe(1);
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'not-an-email',
        phone: '+54 9 11 1234-5678',
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('email');
  });

  it('accepts international phone formats', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Maria',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria@example.com',
        phone: '@54 9 11 1234-5678',
      });
    
    expect(response.status).toBe(302);
  });

  it('accepts various postal code formats', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formats = [
      { postal: 'SW1A 1AA', country: 'UK' },
      { postal: 'C1000', country: 'Argentina' },
      { postal: 'B1675', country: 'Argentina' },
      { postal: '12345', country: 'US' },
    ];

    for (const format of formats) {
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: 'Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: format.postal,
          country: format.country,
          email: `test${format.postal.replace(/\s+/g, '')}@example.com`,
          phone: '+1 234 567-8900',
        });

      expect(response.status).toBe(302);
    }
  });
});
