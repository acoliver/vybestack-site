#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Interface for CLI arguments
 */
interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command line arguments
 */
function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    process.exit(1);
  }

  const result: CliArgs = {
    dataFile: args[0],
    format: '',
    includeTotals: false,
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Missing format value after --format');
        process.exit(1);
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Missing path value after --output');
        process.exit(1);
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!result.format) {
    console.error('--format is required');
    process.exit(1);
  }

  return result;
}

/**
 * Validates and parses the report data from JSON
 */
function parseReportData(filePath: string): ReportData {
  let fileContent: string;
  try {
    fileContent = fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    console.error(`Failed to read file: ${filePath}`);
    console.error((error as Error).message);
    process.exit(1);
  }

  let data: unknown;
  try {
    data = JSON.parse(fileContent);
  } catch (error) {
    console.error(`Failed to parse JSON in file: ${filePath}`);
    console.error((error as Error).message);
    process.exit(1);
  }

  // Validate the structure
  if (!data || typeof data !== 'object') {
    console.error('Invalid JSON: Expected an object');
    process.exit(1);
  }

  const obj = data as Record<string, unknown>;

  if (!('title' in obj) || typeof obj.title !== 'string') {
    console.error('Invalid JSON: Missing or invalid "title" property (string expected)');
    process.exit(1);
  }

  if (!('summary' in obj) || typeof obj.summary !== 'string') {
    console.error('Invalid JSON: Missing or invalid "summary" property (string expected)');
    process.exit(1);
  }

  if (!('entries' in obj) || !Array.isArray(obj.entries)) {
    console.error('Invalid JSON: Missing or invalid "entries" property (array expected)');
    process.exit(1);
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      console.error(`Invalid entry at index ${i}: Expected an object`);
      process.exit(1);
    }

    const entryObj = entry as Record<string, unknown>;
    if (!('label' in entryObj) || typeof entryObj.label !== 'string') {
      console.error(`Invalid entry at index ${i}: Missing or invalid "label" property (string expected)`);
      process.exit(1);
    }

    if (!('amount' in entryObj) || typeof entryObj.amount !== 'number') {
      console.error(`Invalid entry at index ${i}: Missing or invalid "amount" property (number expected)`);
      process.exit(1);
    }
  }

  return data as ReportData;
}

/**
 * Gets the appropriate formatter for the requested format
 */
function getFormatter(format: string): ReportFormatter {
  const formatters: Record<string, ReportFormatter> = {
    markdown: renderMarkdown,
    text: renderText,
  };

  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return formatter;
}

/**
 * Writes content to either stdout or a file
 */
function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      const dir = path.dirname(outputPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
      fs.writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Failed to write output to: ${outputPath}`);
      console.error((error as Error).message);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

/**
 * Main function
 */
function main(): void {
  try {
    const args = parseArgs();

    const data = parseReportData(args.dataFile);

    const formatter = getFormatter(args.format);

    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    const report = formatter(data, options);

    writeOutput(report, args.outputPath);
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

// Run the main function if this module is executed directly
if (process.argv[1] === import.meta.url.replace('file://', '')) {
  main();
}
