/**
 * Interface for a report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering reports
 */
export interface ReportOptions {
  includeTotals?: boolean;
}

/**
 * Function signature for report formatters
 */
export type ReportFormatter = (data: ReportData, options: ReportOptions) => string;