import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

/**
 * Formats a number as a USD amount with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total amount from all entries
 */
function calculateTotal(entries: Array<{ label: string; amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Renders report data in plain text format
 */
export const renderText: ReportFormatter = (
  data: ReportData,
  options: ReportOptions = {}
): string => {
  const lines: string[] = [];

  // Add title
  lines.push(data.title);
  lines.push('');

  // Add summary
  lines.push(data.summary);
  lines.push('');

  // Add entries section
  lines.push('Entries:');

  // Add each entry
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Add total if requested
  if (options.includeTotals && data.entries.length > 0) {
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};