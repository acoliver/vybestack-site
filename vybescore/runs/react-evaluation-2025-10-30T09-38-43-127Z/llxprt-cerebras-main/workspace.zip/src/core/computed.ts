/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine the equality function
  const _equalFn: EqualFn<T> = typeof equal === 'function' ? equal : 
                             equal === true ? Object.is : 
                             (lhs: T, rhs: T) => lhs === rhs;
  
  // Create observer for computed value
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track dependencies by running update function once
  updateObserver(observer)
  
  // Create getter function that returns computed value
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // In computed values, we're tracking dependencies, not creating observer chains
      // We don't need to assign currentObserver to observer.observer here
    }
    return observer.value as T
  }
  
  return getter
}