import { ReportData, RenderOptions, ReportRenderer } from '../types.js';

export const renderText: ReportRenderer = (
  data: ReportData,
  options: RenderOptions,
): string => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  const formattedTotal = total.toFixed(2);

  let result = `${data.title}\n${data.summary}\nEntries:\n`;
  
  for (const entry of data.entries) {
    const formattedAmount = entry.amount.toFixed(2);
    result += `- ${entry.label}: $${formattedAmount}\n`;
  }

  if (options.includeTotals) {
    result += `Total: $${formattedTotal}\n`;
  }

  return result;
};