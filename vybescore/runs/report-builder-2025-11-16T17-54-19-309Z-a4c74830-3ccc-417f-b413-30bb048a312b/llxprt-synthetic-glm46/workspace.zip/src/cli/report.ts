#!/usr/bin/env node

import { readFile, writeFile } from 'fs/promises';
import { ReportData, RenderOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const renderers: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

async function parseArgs(): Promise<{
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}> {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  
  if (!args.includes('--format')) {
    throw new Error('Missing required --format argument');
  }
  
  const formatIndex = args.indexOf('--format');
  const format = args[formatIndex + 1];
  
  if (!format) {
    throw new Error('Missing value for --format');
  }
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

async function loadReportData(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(filePath, 'utf8');
    const data = JSON.parse(content) as unknown;
    
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (!reportData.title || typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid title field');
    }
    
    if (!reportData.summary || typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid summary field');
    }
    
    if (!reportData.entries || !Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: missing or invalid entries field');
    }
    
    const entries = reportData.entries.map(entry => {
      if (!entry || typeof entry !== 'object') {
        throw new Error('Invalid entry: expected an object');
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (!entryObj.label || typeof entryObj.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid label field');
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid amount field');
      }
      
      return { label: entryObj.label, amount: entryObj.amount };
    });
    
    return {
      title: reportData.title,
      summary: reportData.summary,
      entries,
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    throw error;
  }
}

async function main(): Promise<void> {
  try {
    const { dataFile, format, outputPath, includeTotals } = await parseArgs();
    
    if (!renderers[format]) {
      throw new Error(`Unsupported format: ${format}. Supported formats: ${Object.keys(renderers).join(', ')}`);
    }
    
    const reportData = await loadReportData(dataFile);
    const options: RenderOptions = { includeTotals };
    const renderer = renderers[format];
    const output = renderer(reportData, options);
    
    if (outputPath) {
      await writeFile(outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
