import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Default to page 1 if not provided
      const page = pageParam ? Number(pageParam) : 1;
      // Default to limit 5 if not provided
      const limit = limitParam ? Number(limitParam) : 5;

      // Validate page and limit parameters
      if (isNaN(page) || !Number.isInteger(page) || page < 1) {
        return res.status(400).json({ error: 'page must be a positive integer' });
      }

      if (isNaN(limit) || !Number.isInteger(limit) || limit < 1 || limit > 100) {
        return res.status(400).json({ error: 'limit must be a positive integer not exceeding 100' });
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error in /inventory endpoint:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
