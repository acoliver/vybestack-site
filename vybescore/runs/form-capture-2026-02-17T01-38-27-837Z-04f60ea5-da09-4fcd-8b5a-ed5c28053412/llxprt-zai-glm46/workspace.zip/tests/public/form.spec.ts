import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app, { startServer, stopServer } from '../../src/server.js';

let serverClose: (() => Promise<void>) | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server
  await startServer(0); // Use random port
  serverClose = stopServer;
});

afterAll(async () => {
  if (serverClose) {
    await serverClose();
  }
  
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    
    const $ = cheerio.load(response.text);
    
    // Check for all input fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check that labels are properly associated
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file exists
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow redirect to thank you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'invalid-phone!@#',
      });
    
    // Should re-render form with errors
    expect(response.status).toBe(400);
    expect(response.text).toContain('Tell us who you are');
    
    const $ = cheerio.load(response.text);
    
    // Should have error messages
    expect($('.error-list').length).toBeGreaterThan(0);
  });

  it('accepts international phone and postal formats', async () => {
    const formData = {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria.garcia@example.com',
      phone: '+54 9 11 1234-5678',
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts phone with leading @', async () => {
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: 'Test Street',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'test@example.com',
      phone: '@1 234 567-8900',
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
  });

  it('rejects invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: 'Test Street',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'not-an-email',
        phone: '1234567890',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email');
  });
});
