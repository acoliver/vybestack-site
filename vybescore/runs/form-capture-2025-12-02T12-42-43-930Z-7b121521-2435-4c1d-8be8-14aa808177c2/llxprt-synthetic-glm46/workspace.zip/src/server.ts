import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// @ts-expect-error - sql.js types are not available
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const port = process.env.PORT || 3535;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [field: string]: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function initializeDatabase(): Promise<any> {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let db: any;
    
    try {
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(filebuffer);
      console.log('Database loaded from file');
    } catch (err) {
      const dbDir = path.dirname(dbPath);
      if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
      }
      
      db = new SQL.Database();
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      db.run(schema);
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Database created and initialized from schema');
    }
    
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
function saveDatabase(db: any): void {
  try {
    const data = db.export();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal/ZIP code is required';
  } else {
    // eslint-disable-next-line no-useless-escape
    if (!/^[A-Za-z0-9\s\-]+$/.test(data.postalCode)) {
      errors.postalCode = 'Postal code may only contain letters, numbers, spaces, and hyphens';
    }
  }
  
  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else {
    // eslint-disable-next-line no-useless-escape
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // eslint-disable-next-line no-useless-escape
    if (!/^\+[0-9\s()\-]+$/.test(data.phone)) {
      errors.phone = 'Phone number may only contain digits, spaces, parentheses, hyphens, and a leading +';
    }
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function createServer(db?: any) {
  const app = express();
  
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, '..', 'public')));
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: {}, 
      formData: {}
    });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        formData
      });
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase(db);
    
    res.redirect('/thank-you');
  });
  
  app.get('/thank-you', (req, res) => {
    res.render('thank-you');
  });
  
  return app;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
async function closeDatabase(db: any): Promise<void> {
  if (db && db.close) {
    db.close();
  }
}

// Export for testing purposes
export { closeDatabase };

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  // Import startServer function for direct execution
  (async () => {
    await initializeAndStartServer();
  })();
}

async function initializeAndStartServer() {
  try {
    const db = await initializeDatabase();
    const app = createServer(db);
    
    const serverInstance = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      saveDatabase(db);
      serverInstance.close(() => {
        console.log('Express server closed');
        db.close();
        console.log('Database closed');
        process.exit(0);
      });
    });
    
    process.on('SIGINT', () => {
      console.log('SIGINT received, shutting down gracefully');
      saveDatabase(db);
      serverInstance.close(() => {
        console.log('Express server closed');
        db.close();
        console.log('Database closed');
        process.exit(0);
      });
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}