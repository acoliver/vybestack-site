/**
 * Capitalize the first character of each sentence, preserving spacing rules
 * Insert exactly one space between sentences even if the input omitted it
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, insert a space after sentence-ending punctuation if missing
  // This regex finds punctuation followed by a non-space character and adds a space
  let result = text.replace(/([.?!])(\S)/g, '$1 $2');
  
  // Then capitalize the first letter of each sentence
  // This regex matches the first letter after sentence-ending punctuation or at the beginning of the text
  result = result.replace(/(^[a-z]|(?<=[.?!]\s)[a-z])/g, (match) => match.toUpperCase());
  
  // Collapse extra spaces (more than one) into single spaces
  result = result.replace(/\s+/g, ' ');
  
  // Trim leading and trailing whitespace
  return result.trim();
}

/**
 * Extract all URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - matches http/https URLs
  // This pattern handles various URL formats and strips trailing punctuation
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[^\s,.!?;:]/gi;
  const matches = text.match(urlRegex);
  
  // Return matched URLs or empty array if none found
  return matches ? matches : [];
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://, but don't modify already secure URLs
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable
 * Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // Regex to match URLs with docs path but without dynamic elements
  // Captures the protocol, host, and path portions separately
  const docsUrlRegex = /http:\/\/([a-zA-Z0-9.-]+)(\/docs\/[^?\s]*)(?![?&=]*\S*\.(jsp|php|asp|aspx|do|cgi|pl|py))/gi;
  
  // Replace matching URLs with https://docs.host/path format
  return text.replace(docsUrlRegex, 'https://docs.$1$2');
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format and extract the year
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  // If no match, return 'N/A'
  if (!match) {
    return 'N/A';
  }
  
  // Extract components
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
