/**
 * Match words starting with the prefix but excluding banned words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words beginning with the prefix but excluding exceptions
  // Use word boundaries to ensure we match complete words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  
  // If there are exceptions, create a negative lookahead to exclude them
  const exceptionPattern = exceptions.length > 0 ? `(?!${escapedExceptions})` : '';
  
  // Regex pattern to match words with the prefix that are not in exceptions list
  const pattern = new RegExp(`\\b${exceptionPattern}${escapedPrefix}\\w*`, 'gi');
  
  // Find all matches and filter out duplicates
  const matches = text.match(pattern);
  if (!matches) {
    return [];
  }
  
  // Convert to lowercase and remove duplicates
  return [...new Set(matches.map(word => word.toLowerCase()))];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern to find token after a digit
  // Pattern matches a digit followed by the token
  // Returns only the token part by using capturing groups
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\d(${escapedToken})`, 'g');
  
  // Collect all matches
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]); // Return the whole match (digit + token)
  }
  
  return matches;
}

/**
 * Validate passwords according to policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol
 * No whitespace, no immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This regex looks for any sequence of 2 or more characters that immediately repeats
  if (/(\S{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern - matches full and shorthand IPv6 addresses
  // This pattern is simplified but should match the requirements
  const ipv6Regex = /(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=$|(?=\s))/g;
  
  // Check if the string contains an IPv6 address
  return ipv6Regex.test(value);
}