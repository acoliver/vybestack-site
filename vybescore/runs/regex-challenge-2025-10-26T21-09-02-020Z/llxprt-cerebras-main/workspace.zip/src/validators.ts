export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns
 * Accepts typical addresses such as name+tag @example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // - Local part can contain letters, digits, and special characters like +, -, _
  // - Must have @ symbol
  // - Domain part can contain letters, digits, dots, and hyphens
  // - TLD must be at least 2 characters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check basic format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for edge cases
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  const [localPart, domainPart] = value.split('@');
  if (localPart.endsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with support for common formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length/validity checking
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid length (10 digits or 11 digits with +1 prefix)
  if (digitsOnly.length !== 10 && !(digitsOnly.length === 11 && digitsOnly.startsWith('1'))) {
    return false;
  }
  
  // Extract area code (first 3 digits after optional country code)
  const startIndex = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(startIndex, startIndex + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Regex patterns for various US phone number formats
  const phoneRegex = /^(\+?1[-.\s]?)?\(?([2-9][0-9]{2})\)?[-.\s]?([2-9][0-9]{2})[-.\s]?([0-9]{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers
  // Supports formats:
  // - +54 9 11 1234 5678 (mobile with country code)
  // - +54 341 123 4567 (landline with country code)
  // - 011 1234 5678 (mobile/landline with trunk code)
  // - 0341 4234567 (landline with trunk code)
  const argentinePhoneRegex = /^(\+54)?(0?)(9?)([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  // Extract components from match
  const hasCountryCode = !!match[1];
  const hasTrunkCode = !!match[2];
  // const hasMobileIndicator = !!match[3]; // Not used in current implementation
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // When country code is omitted, the number must begin with trunk prefix '0'
  if (!hasCountryCode && !hasTrunkCode) {
    return false;
  }
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must contain 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Name validation regex
  // - Allows unicode letters, spaces, hyphens, and apostrophes
  // - Disallows digits and most symbols
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Check basic format
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check to reject names like "X Æ A-12" (containing digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Must not be empty after trimming
  if (value.trim() === '') {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn algorithm check on credit card numbers
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum)
 * Supports Visa, Mastercard, and AmEx
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 5, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15}|\d{18})$/;
  const mastercardRegex = /^5\d{15}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the card patterns
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanValue);
}
