/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate that the input is valid Base64 format.
 * Only allows characters from the standard Base64 alphabet.
 */
function isValidBase64(input: string): boolean {
  // Check for non-base64 characters (allow padding)
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Pattern.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    // Check if the error is due to malformed padding or invalid base64
    if (error instanceof Error && error.message.includes('Invalid')) {
      throw new Error('Failed to decode Base64 input: malformed data');
    }
    throw new Error('Failed to decode Base64 input');
  }
}
