/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track the subjects this computed depends on
  const trackedSubjects = new Set<Subject<any>>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Before computing, clear old dependencies
      trackedSubjects.clear()
      // Compute new value (this will register dependencies via getActiveObserver)
      const newValue = updateFn(prevValue)
      
      // After computing, ensure we're registered as an observer of all tracked subjects
      for (const subject of trackedSubjects) {
        if (!subject.observers.has(o)) {
          subject.observers.add(o)
        }
      }
      
      return newValue
    },
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  // Return getter function
  const getter = (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== o) {
      // When this computed is read while another observer is active,
      // that observer needs to depend on all the subjects we depend on.
      // We temporarily set the current observer as active so that when
      // we call the updateFn, it will register the dependencies.
      setActiveObserver(currentObserver)
      try {
        // Re-run updateFn to re-register dependencies under the current observer
        const prevValue = o.value
        o.value = o.updateFn(prevValue)
      } finally {
        setActiveObserver(currentObserver)
      }
    }
    return o.value!
  }
  
  return getter
}
