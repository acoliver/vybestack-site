/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Track the subjects this callback depends on
  const trackedSubjects = new Set<any>()
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      const newValue = updateFn(prevValue)
      return newValue
    },
  }
  
  // Wrap updateFn to track dependencies
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    trackedSubjects.clear()
    const result = originalUpdateFn(prevValue)
    
    // Register as observer of all tracked subjects
    for (const subject of trackedSubjects) {
      if (!subject.observers.has(observer)) {
        subject.observers.add(observer)
      }
    }
    
    return result
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up: remove this observer from all tracked subjects
    for (const subject of trackedSubjects) {
      subject.observers.delete(observer)
    }
    trackedSubjects.clear()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // No-op function to prevent errors if updateObserver is called after disposal
    observer.updateFn = () => value as T
  }
}
