/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates Base64 input format.
 */
function validateBase64(input: string): void {
  // Validate Base64 input - check for invalid characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for invalid padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding character must only appear at the end
    if (input.slice(paddingIndex + 1).match(/[^=]/)) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
    
    // Check if padding length is correct (multiple of 4)
    if ((input.length % 4) !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64.
 */
export function decode(input: string): string {
  validateBase64(input);

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
