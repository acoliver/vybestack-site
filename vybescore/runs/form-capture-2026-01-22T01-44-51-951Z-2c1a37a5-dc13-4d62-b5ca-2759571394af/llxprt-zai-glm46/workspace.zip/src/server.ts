import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, closeDatabase, insertSubmission } from './database.js';
import { validateForm, FormData } from './validator.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS as the template engine
// Use src/templates for templates regardless of where server runs from
const projectRoot = path.resolve(__dirname, '..');
const templatesDir = path.resolve(projectRoot, 'src', 'templates');
app.set('view engine', 'ejs');
app.set('views', templatesDir);

// Routes
app.get('/', (_req: Request, res: Response): void => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response): void => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Validation failed - re-render form with errors and values
    const errorMessages = errors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
    return;
  }

  // Validation successful - insert into database
  try {
    insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone,
    });

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    const errorMessages = ['An error occurred while saving your submission. Please try again.'];
    res.status(500).render('form', {
      errors: errorMessages,
      values: formData,
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response): void => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, _req: Request, res: Response): void => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Graceful shutdown handlers
let server: ReturnType<typeof app.listen>;

async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  await closeDatabase();
  console.log('Database closed');
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized');

    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

start();

export { app, shutdown };
