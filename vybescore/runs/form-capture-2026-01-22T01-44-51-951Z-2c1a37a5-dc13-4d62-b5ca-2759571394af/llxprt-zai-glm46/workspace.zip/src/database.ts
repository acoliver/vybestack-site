import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

export interface SubmissionRecord {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

let dbInstance: Database | null = null;
let SQL: SqlJsStatic | null = null;

export async function initializeDatabase(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  // Initialize SQL.js
  SQL = await initSqlJs();

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const dbBuffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(dbBuffer);
  } else {
    dbInstance = new SQL.Database();
    // Initialize schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    persistDatabase();
  }

  return dbInstance;
}

export function persistDatabase(): void {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const data = dbInstance.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export function insertSubmission(submission: SubmissionRecord): number {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const stmt = dbInstance.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city,
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone,
  ]);

  stmt.free();

  const rowId = dbInstance.exec('SELECT last_insert_rowid() as id');
  const insertedId = (rowId[0].values[0] as unknown[])[0] as number;

  // Persist after each insert
  persistDatabase();

  return insertedId;
}

export function getAllSubmissions(): SubmissionRecord[] {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const result = dbInstance.exec('SELECT * FROM submissions ORDER BY created_at DESC');

  if (result.length === 0) {
    return [];
  }

  const columns = result[0].columns;
  const values = result[0].values;

  return values.map((row: unknown[]) => {
    const obj: Record<string, unknown> = {};
    columns.forEach((col: string, index: number) => {
      obj[col] = row[index];
    });
    return obj as unknown as SubmissionRecord;
  });
}

export async function closeDatabase(): Promise<void> {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
    SQL = null;
  }
}
