export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Luhn checksum helper function
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isSecond = false;
  
  // Start from the rightmost digit and move left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isSecond) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isSecond = !isSecond;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  // Basic structure check
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots in local part or domain
  if (value.includes('..')) return false;
  
  // Reject trailing dots in local part or domain
  if (value.endsWith('.')) return false;
  
  // Domain cannot have underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) return false;
  
  // Domain must have at least one dot
  if (!domain.includes('.')) return false;
  
  // Check top-level domain is at least 2 characters
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // If extensions are allowed, we could add additional validation here
  // For now, options is kept for future extensibility but not used
  void options;
  // Remove all non-digit characters to get just the numbers
  const digits = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits (10 digits for US number, 11 with country code)
  if (digits.length !== 10 && digits.length !== 11) return false;
  
  // If we have 11 digits, the first must be '1' for US country code
  if (digits.length === 11 && digits[0] !== '1') return false;
  
  // Extract the area code (last 10 digits, or first 3 if 10 digits)
  const areaCode = digits.length === 10 ? digits.substring(0, 3) : digits.substring(1, 4);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check the overall format matches common US phone patterns
  const phoneRegex = /^(\+?1[\s-.]*)?\(?([2-9]\d{2})\)?[\s-.]*([2-9]\d{2})[\s-.]*(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep track of structure
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Regex to match Argentine phone numbers:
  // Optional +54 country code
  // Optional 0 trunk prefix before area code (required if no country code)
  // Optional 9 mobile prefix
  // Area code (2-4 digits, first digit 1-9)
  // Subscriber number (6-8 digits)
  // Accept spaces or hyphens as separators
  const argentianPhoneRegex = /^(?:\+?54)?(?:0?|0?9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentianPhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no country code, must start with trunk prefix 0 before area code
  if (!value.startsWith('+54') && !value.startsWith('54')) {
    if (!cleaned.startsWith('0')) return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[^\d\s][\p{L}\p{M}'\-·\s]+[^\d\s]$/u;
  
  // Test with the regex
  if (!nameRegex.test(value)) return false;
  
  // Additional check: reject if there are 2+ non-letter characters in a row
  const invalidSequenceRegex = /[^a-zA-Z\p{L}\p{M}\s]{2,}/u;
  if (invalidSequenceRegex.test(value)) return false;
  
  // Ensure at least one letter
  const hasLetter = /\p{L}/u;
  if (!hasLetter.test(value)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Check if the input contains only digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check for known card prefixes and lengths
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  if (visaRegex.test(cleaned)) return runLuhnCheck(cleaned);
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mcRegex1 = /^5[1-5]\d{14}$/;
  const mcRegex2 = /^2(2[2-9]\d|3[0-5]\d|4[0-9]\d|5[01]\d|6[0-9]\d|7[01]\d|720)\d{12}$/;
  if (mcRegex1.test(cleaned) || mcRegex2.test(cleaned)) return runLuhnCheck(cleaned);
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleaned)) return runLuhnCheck(cleaned);
  
  // If none of the patterns match, then it's invalid
  return false;
}
