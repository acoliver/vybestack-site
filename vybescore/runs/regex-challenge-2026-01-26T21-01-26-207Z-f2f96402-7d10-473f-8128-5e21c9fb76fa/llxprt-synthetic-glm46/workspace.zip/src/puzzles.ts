/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex to match words starting with the prefix
  // Word boundaries handle punctuation and whitespace
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => 
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '\\$&');
  
  // Create a regex to match digit + token combination
  // Not at start of string, but specifically after a digit
  const tokenRegex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches and return them
  const matches = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol
  const symbolRegex = /[!@#$%^&*()_\-=[\]{};':"|,.<>?]/;
  if (!symbolRegex.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  // This regex captures any 2-character sequence repeated immediately
  const repeatedSequenceRegex = /(.{2})\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  // Check for repetitive patterns (aaaa, 1111, etc.)
  const repetitivePatternRegex = /(.)\1{3,}/;
  if (repetitivePatternRegex.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if the string contains an IPv6 address
  // IPv6 addresses are sequences of hexadecimal digits separated by colons
  // and may include :: for zero compression
  
  // First check if the string contains only an IPv4 address
  // IPv4 addresses should not trigger a positive result
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value) && !/:/.test(value)) return false;
  
  // Regex patterns to match various IPv6 formats
  const ipv6Patterns = [
    // Standard IPv6 format with 8 groups of 1-4 hex digits
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // Compressed format with :: (one or more groups replaced)
    /(?:[0-9a-fA-F]{1,4}:){0,6}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/,
    // Starts with :: (compression at start)
    /::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/,
    // Ends with :: (compression at end)
    /(?:[0-9a-fA-F]{1,4}:){0,7}::/,
    // Just :: (all zeros)
    /::/,
    // IPv4-mapped IPv6
    /(?:[0-9a-fA-F]{1,4}:){6}:(?:[0-9]{1,3}\.){3}[0-9]{1,3}/,
    // IPv4-compatible IPv6
    /::(?:[0-9]{1,3}\.){3}[0-9]{1,3}/
  ];
  
  // Check if the string contains any IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  // If no match, return false
  return false;
}
