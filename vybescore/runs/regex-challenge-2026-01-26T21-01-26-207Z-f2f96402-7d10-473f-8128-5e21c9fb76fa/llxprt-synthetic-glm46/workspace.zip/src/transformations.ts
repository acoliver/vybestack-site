/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences based on sentence terminators (.?!)
  // Consider abbreviations (simplified approach for basic functionality)
  const terminatorRegex = /([.?!])(?=\s|$)/g;
  
  // Split the text at each terminator, keeping the terminator
  const parts = text.split(terminatorRegex);
  
  // Reconstruct sentences and process them
  const sentences = [];
  for (let i = 0; i < parts.length; i += 2) {
    const content = parts[i] || '';
    const terminator = parts[i + 1] || '';
    
    sentences.push(content + terminator);
  }
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Trim leading spaces but keep track of them
    const leadingSpaces = sentence.match(/^\s+/)?.[0] || '';
    const trimmed = sentence.trimStart();
    
    // If the sentence is empty or just spaces, return as is
    if (!trimmed) return leadingSpaces;
    
    // Capitalize first letter if it's a letter
    const firstChar = trimmed.charAt(0);
    if (/[a-z]/.test(firstChar)) {
      return leadingSpaces + firstChar.toUpperCase() + trimmed.substring(1);
    }
    
    return leadingSpaces + trimmed;
  });
  
  // Join sentences back together with a single space between them
  // Remove extra spaces between sentences
  const result = processedSentences.join(' ').replace(/  +/g, ' ');
  
  // Trim trailing spaces
  return result.trimEnd();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches common URL formats
  const urlRegex = /\bhttps?:\/\/(?:[-a-zA-Z0-9@:%._+~#=]{1,256}\.)+[a-zA-Z]{2,6}\b(?:[-a-zA-Z0-9@:%_+~#?&//=]*)/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Match http:// URLs but not https:// URLs
  const httpUrlRegex = /\bhttp:\/\/([^\s]+)\b/gi;
  
  return text.replace(httpUrlRegex, 'https://$1');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  const upgradedText = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Match example.com URLs and check for excluded patterns
  const exampleUrlRegex = /\b(https:\/\/example\.com(\/[^?\s]*)?)/g;
  
  // Process each match
  const rewrittenText = upgradedText.replace(exampleUrlRegex, (match, fullUrl, path) => {
    // If no path, return as is
    if (!path) return fullUrl;
    
    // Check for excluded patterns (cgi-bin, query strings, legacy extensions)
    const excludedPatterns = [/\/cgi-bin/i, /\?/, /\.jsp$/, /\.php$/, /\.asp$/, /\.aspx$/, /\.do$/, /\.cgi$/, /\.pl$/, /\.py$/];
    
    // If any excluded pattern matches, don't rewrite host
    for (const pattern of excludedPatterns) {
      if (path.match(pattern)) {
        return fullUrl;
      }
    }
    
    // If path starts with /docs/, rewrite host
    if (path.startsWith('/docs/')) {
      return `https://docs.example.com${path}`;
    } else if (path === '/docs') {
      return 'https://docs.example.com/docs';
    }
    
    // Otherwise, keep the original
    return fullUrl;
  });
  
  return rewrittenText;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and capture the year
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  // If the format is invalid or doesn't match, return 'N/A'
  if (!match) return 'N/A';
  
  // Extract the year
  const year = match[3];
  return year;
}
