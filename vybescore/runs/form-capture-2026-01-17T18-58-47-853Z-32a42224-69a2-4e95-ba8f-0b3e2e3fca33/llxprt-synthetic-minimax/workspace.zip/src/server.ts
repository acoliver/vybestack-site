import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Database configuration
let db: Database | null = null;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '../db/schema.sql');

// Type definitions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Remove common formatting characters
  const cleanPhone = phone.replace(/[\s-+()]/g, '');
  // Check if it contains at least some digits and valid characters
  const phoneRegex = /^[\d\s-+()]{7,}$/;
  return phoneRegex.test(phone) && /\d/.test(cleanPhone);
}

function validatePostalCode(postalCode: string): boolean {
  // Support alphanumeric postal codes (UK, Argentina, etc.)
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field].trim();
    if (!value) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  });

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Database functions
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(__dirname, `../node_modules/sql.js/dist/${file}`)
  });

  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    
    // Load and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    db.exec(schema);
  }
}

async function saveSubmission(data: FormData): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.firstName.trim(),
    data.lastName.trim(),
    data.streetAddress.trim(),
    data.city.trim(),
    data.stateProvince.trim(),
    data.postalCode.trim(),
    data.country.trim(),
    data.email.trim(),
    data.phone.trim()
  ]);

  stmt.free();

  // Save database to file
  const dataBuffer = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(dataBuffer));
}

async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: [],
    formData: {} as FormData,
    submitted: false
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateFormData(formData);

    if (!validation.isValid) {
      return res.status(400).render('index', {
        errors: validation.errors,
        formData,
        submitted: false
      });
    }

    await saveSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('index', {
      errors: [{ field: 'general', message: 'An error occurred while processing your request. Please try again.' }],
      formData: req.body,
      submitted: false
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await closeDatabase();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await closeDatabase();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });

    // Store server reference for shutdown
    const globalObj = globalThis as typeof globalThis & { server?: unknown };
    globalObj.server = server;
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
