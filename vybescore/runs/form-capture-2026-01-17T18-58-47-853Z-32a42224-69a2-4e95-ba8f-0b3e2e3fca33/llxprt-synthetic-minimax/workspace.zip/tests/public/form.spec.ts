import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import path from 'node:path';
import fs from 'node:fs';
import type { Express } from 'express';

// Import the server module
async function createServer() {
  const { default: express } = await import('express');
  const app: Express = express();
  
  // Basic server setup for testing
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Add basic routes for testing
  app.get('/', (req, res) => {
    res.send(`
      <form action="/submit" method="POST">
        <input name="firstName" required />
        <input name="lastName" required />
        <input name="email" required />
        <input name="phone" required />
        <button type="submit">Submit</button>
      </form>
    `);
  });
  
  app.post('/submit', (req, res) => {
    res.redirect('/thank-you');
  });
  
  app.get('/thank-you', (req, res) => {
    res.send('<h1>Thank you!</h1>');
  });
  
  return app;
}

let server: unknown;
let app: Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  app = await createServer();
  server = app.listen(0); // Use port 0 for testing
});

afterAll(() => {
  if (server && typeof server === 'object' && 'close' in server) {
    (server as { close: () => void }).close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('name="firstName"');
    expect(response.text).toContain('name="lastName"');
    expect(response.text).toContain('name="email"');
    expect(response.text).toContain('name="phone"');
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing test database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        email: 'test@example.com',
        phone: '+1234567890'
      })
      .expect(302); // Expect redirect
    
    expect(response.headers.location).toBe('/thank-you');
  });
});
