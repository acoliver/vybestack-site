/**
 * Encode plain text to Base64.
 * Uses standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses standard Base64 decoding and throws errors for invalid input.
 */
export function decode(input: string): string {
  // Normalize input: handle URL-safe base64 by converting back to standard
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  // Check for proper padding if input length is not divisible by 4
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  const paddedInput = paddingNeeded > 0 ? normalized + '='.repeat(paddingNeeded) : normalized;

  // Validate the padded input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(paddedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
