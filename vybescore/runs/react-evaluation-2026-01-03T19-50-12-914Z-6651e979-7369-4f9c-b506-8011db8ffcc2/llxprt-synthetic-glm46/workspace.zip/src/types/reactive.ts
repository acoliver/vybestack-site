/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  __dependencies?: Set<Observer<any>>
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const globalObservers: Set<Observer<any>> = new Set()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function addObserver<T>(observer: Observer<T>): void {
  globalObservers.add(observer)
}

export function removeObserver<T>(observer: Observer<T>): void {
  globalObservers.delete(observer)
}

export { globalObservers }

export function updateObserver<T>(observer: Observer<T>): void {
  // Initialize dependencies tracking if not present
  if (!observer.__dependencies) {
    observer.__dependencies = new Set<Observer<any>>()
  }
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}
