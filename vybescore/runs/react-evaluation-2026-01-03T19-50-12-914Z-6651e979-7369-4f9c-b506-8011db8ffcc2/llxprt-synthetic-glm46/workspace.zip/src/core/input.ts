/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  globalObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Set up equality function
  let equalFn: EqualFn<T>
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = () => false
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    equalFn = (a: T, b: T) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value is different according to equality function
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Update all global observers to trigger computed values and callbacks
      for (const observer of globalObservers) {
        updateObserver(observer)
      }
    }
    
    return s.value
  }

  return [read, write]
}
