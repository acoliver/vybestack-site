import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const pageNum = pageParam ? Number(pageParam) : 1;
    const limitNum = limitParam ? Number(limitParam) : 5;

    // Validate inputs
    if (pageParam && (isNaN(pageNum) || pageNum <= 0 || pageNum > 10000)) {
      return res.status(400).json({ error: 'Page must be a positive number between 1 and 10000' });
    }
    if (limitParam && (isNaN(limitNum) || limitNum <= 0 || limitNum > 1000)) {
      return res.status(400).json({ error: 'Limit must be a positive number between 1 and 1000' });
    }
    if (!pageParam && !limitParam) {
      // Use defaults
      const payload = listInventory(db, { page: 1, limit: 5 });
      return res.json(payload);
    }

    const payload = listInventory(db, { page: pageNum, limit: limitNum });
    res.json(payload);
  });

  return app;
}
