export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper RFC compliance.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  if (typeof value !== 'string' || !value.trim()) {
    return false;
  }

  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }

  // Check for consecutive dots in local part or domain
  const localPart = value.split('@')[0];
  if (localPart.includes('..')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers with various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (typeof value !== 'string' || !value.trim()) {
    return false;
  }

  // Remove all non-digit characters except leading +
  let cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length > 10) {
    cleaned = cleaned.substring(1);
  }

  // After removing country code and separators, we should have exactly 10 digits
  if (cleaned.length !== 10) {
    return false;
  }

  // Area code cannot start with 0 or 1
  const areaCode = cleaned.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  // Check if it's a valid US phone number pattern
  const usPhoneRegex = /^[2-9]\d{2}[2-9]\d{2}\d{4}$/;
  return usPhoneRegex.test(cleaned);
}

/**
 * Validate Argentine phone numbers with country code, trunk prefix, mobile indicator, area code, and subscriber number.
 * Handles formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (typeof value !== 'string' || !value.trim()) {
    return false;
  }

  // Remove spaces and hyphens for validation, but preserve structure
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check basic pattern: optional +54, optional 0 (trunk), optional 9 (mobile), 
  // area code (2-4 digits starting with 1-9), subscriber number (6-8 digits)
  const basicPattern = /^(\+54)?(9?)([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(basicPattern);
  if (!match) {
    return false;
  }
  
  const [, countryCode, , , subscriber] = match;
  
  // When country code is present, we don't require trunk prefix 0
  // When country code is absent, we must have trunk prefix 0 at the start
  if (!countryCode && !normalized.startsWith('0')) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (typeof value !== 'string' || !value.trim()) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and multiple consecutive special characters
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}'\s-]*[\p{L}\p{M}'-]$/u;
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }

  // Reject names with consecutive special characters (like "''" or "--")
  if (value.includes("''") || value.includes("--") || value.includes("' ") || value.includes("- ")) {
    return false;
  }

  // Reject names that are just special characters or have too many special characters
  const trimmedValue = value.trim();
  const specialCharCount = (trimmedValue.match(/['-\s]/g) || []).length;
  const letterCount = (trimmedValue.match(/[\p{L}\p{M}]/gu) || []).length;
  
  if (letterCount === 0 || specialCharCount > letterCount) {
    return false;
  }

  // Reject obviously problematic patterns
  if (/^[Xx]\s*[Ææ]\s*[Aa]\s*[-–—]\s*\d+/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(digits: number[]): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and American Express.
 * Accepts proper prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (typeof value !== 'string' || !value.trim()) {
    return false;
  }

  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (!/^\d+$/.test(digits)) {
    return false;
  }

  // Validate length based on card type
  const visaRegex = /^4\d{12}(\d{3})?$/;           // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$/;         // 16 digits, starts with 51-55
  const amexRegex = /^3[47]\d{13}$/;                // 15 digits, starts with 34 or 37
  
  let isValidFormat = false;
  
  if (visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits)) {
    isValidFormat = true;
  }
  
  if (!isValidFormat) {
    return false;
  }

  // Convert string digits to number array for Luhn check
  const digitArray = digits.split('').map(d => parseInt(d, 10));
  
  // Run Luhn checksum
  return runLuhnCheck(digitArray);
}