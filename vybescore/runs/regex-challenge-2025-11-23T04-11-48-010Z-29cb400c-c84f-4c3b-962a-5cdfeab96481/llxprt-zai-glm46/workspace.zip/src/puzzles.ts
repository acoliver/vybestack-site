/**
 * Find words that start with a given prefix but exclude specified exceptions.
 * Returns an array of matching words without duplicates.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (typeof text !== 'string' || typeof prefix !== 'string' || !Array.isArray(exceptions)) {
    return [];
  }

  // Create a Set of exceptions for faster lookup (case insensitive)
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Find all words in the text
  const allWords = text.match(/\b[a-zA-Z]+\b/g) || [];
  
  // Filter words that start with the prefix and are not exceptions
  const filteredWords = allWords.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerPrefix = prefix.toLowerCase();
    return lowerWord.startsWith(lowerPrefix) && !exceptionSet.has(lowerWord);
  });
  
  // Remove duplicates
  return [...new Set(filteredWords)];
}

/**
 * Find occurrences of a token that appear after a digit but not at the start of the string.
 * Uses lookaheads and lookbehinds to find embedded tokens.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Find all occurrences of the token that are preceded by a digit
  const matches = [];
  
  // Find all positions where the token appears
  let searchIndex = 0;
  while (searchIndex <= text.length - token.length) {
    const foundIndex = text.indexOf(token, searchIndex);
    if (foundIndex === -1) break;
    
    // Check if the token is preceded by a digit and not at the start
    if (foundIndex > 0 && /\d/.test(text[foundIndex - 1])) {
      // Include the preceding digit in the result
      matches.push(text.substring(foundIndex - 1, foundIndex + token.length));
    }
    
    searchIndex = foundIndex + 1;
  }
  
  return matches;
}

/**
 * Validate password strength according to security requirements.
 * Requirements: At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences (like abab).
 */
export function isStrongPassword(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

// Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // This regex detects patterns where a sequence of 2+ characters repeats immediately
  const repeatedSequenceRegex = /(.{2,})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }

  // Additional check for character repetition patterns
  // Detect if the same character appears 3 or more times consecutively
  if (/(.)\1\1/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand :: notation) while excluding IPv4 addresses.
 * Returns true if a valid IPv6 address is found in the text.
 */
export function containsIPv6(value: string): boolean {
  if (typeof value !== 'string') {
    return false;
  }

  // IPv6 regex patterns
  // Full IPv6: eight groups of four hex digits separated by colons
  const ipv6FullRegex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand
  const ipv6ShorthandRegex = /(?:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::(?:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?/;
  
  // IPv6 with embedded IPv4
  const ipv6WithIPv4Regex = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check for any IPv6 pattern
  if (ipv6FullRegex.test(value) || ipv6ShorthandRegex.test(value) || ipv6WithIPv4Regex.test(value)) {
    // Make sure it's not an IPv4 address
    const ipv4Regex = /^(?:\d{1,3}\.){3}\d{1,3}$/;
    
    // Extract potential IPv6 matches and verify they're not IPv4
    const ipv6Matches = value.match(/\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/g) || [];
    
    return ipv6Matches.some(match => !ipv4Regex.test(match.trim()));
  }
  
  return false;
}