/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries after .!? and preserves spacing.
 * Attempts to leave abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  if (!text.trim()) {
    return text;
  }

  // Common abbreviations that shouldn't trigger sentence boundaries
  const abbreviations = ['mr', 'mrs', 'dr', 'prof', 'sr', 'jr', 'st', 'ave', 'blvd', 'rd', 'etc', 'e.g', 'i.e', 'vs', 'vol', 'no', 'p', 'pp', 'ed', 'eds', 'trans', 'dept', 'univ', 'assn', 'rev', 'est', 'b.c', 'a.d', 'b.c.e', 'c.e'];
  
  // Split into sentences using more sophisticated logic
  let result = text;
  
  // Process sentence boundaries
  result = result.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, nextChar) => {
    // Look back to see if this might be an abbreviation
    const beforePunctuation = result.substring(0, result.indexOf(match));
    const words = beforePunctuation.split(/\s+/);
    const lastWord = words[words.length - 1]?.toLowerCase().replace(/[.,!?]$/, '');
    
    // If the last word is a common abbreviation, don't capitalize
    if (abbreviations.includes(lastWord)) {
      return match;
    }
    
    return punctuation + ' ' + nextChar.toUpperCase();
  });

  // Capitalize the very first character
  result = result.replace(/^([a-z])/, (match, firstChar) => firstChar.toUpperCase());

  // Clean up spacing - collapse multiple spaces to single space
  result = result.replace(/\s{2,}/g, ' ');

  // Remove space after punctuation if already there
  result = result.replace(/([.!?])\s+/g, '$1 ');

  return result.trim();
}

/**
 * Extract all URLs from the given text without trailing punctuation.
 * Supports http, https, and www URLs with various domain formats.
 */
export function extractUrls(text: string): string[] {
  if (typeof text !== 'string') {
    return [];
  }

  // URL regex pattern that matches most common URL formats
  // Captures the full URL but excludes trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?|www\.(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation marks that commonly follow URLs
    return url.replace(/[.,;:!?)\]'"»]+$/g, '');
  });
}

/**
 * Replace all http:// URLs with https:// while leaving existing https:// URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  // Replace http:// with https://, but only when followed by a valid URL structure
  return text.replace(/http:\/\/(?=[\w-]+\.[\w-])/g, 'https://');
}

/**
 * Rewrite documentation URLs according to specific rules:
 * - Always upgrade http to https
 * - For URLs starting with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (typeof text !== 'string') {
    return '';
  }

  return text.replace(/https?:\/\/(example\.com)(\/[^\s]*)/g, (match, host, path) => {
    // Check for dynamic content that should skip host rewrite
    const dynamicPatterns = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/
    ];
    
    const shouldSkipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));
    
    if (path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    } else {
      // Just upgrade to https
      return `https://${host}${path}`;
    }
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (typeof value !== 'string') {
    return 'N/A';
  }

  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.trim().match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic validation for days in specific months (not considering leap years for simplicity)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}