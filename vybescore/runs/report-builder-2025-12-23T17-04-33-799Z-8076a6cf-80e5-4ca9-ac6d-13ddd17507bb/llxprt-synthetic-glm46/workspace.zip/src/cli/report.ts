#!/usr/bin/env node

import { readFile } from 'fs/promises';
import { writeFileSync } from 'fs';
import { resolve } from 'path';

import type { ReportData, CliOptions, Formatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(args: string[]): { inputFile: string; options: CliOptions } {
  let inputFile: string | undefined;
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg || !['markdown', 'text'].includes(nextArg)) {
        console.error('Error: --format must be either "markdown" or "text"');
        process.exit(1);
      }
      format = nextArg as 'markdown' | 'text';
      i++; // Skip next argument
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --output requires a file path');
        process.exit(1);
      }
      output = nextArg;
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      console.error(`Error: Unexpected argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!inputFile) {
    console.error('Error: Input file is required');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: --format is required and must be either "markdown" or "text"');
    process.exit(1);
  }

  return { inputFile: inputFile!, options: { format, output, includeTotals } };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: "title" field is required and must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" field is required and must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: "entries" field is required and must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field`);
    }
  }

  return obj as unknown as ReportData;
}

function getFormatter(format: 'markdown' | 'text'): Formatter {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

async function main() {
  try {
    const args = process.argv.slice(2);
    const { inputFile, options } = parseArguments(args);

    // Read and parse input file
    const filePath = resolve(options.output ? '.' : '', inputFile);
    const fileContent = await readFile(filePath, 'utf-8');
    let data: unknown;
    
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file ${filePath}: ${error}`);
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(data);

    // Get appropriate formatter
    const formatter = getFormatter(options.format);

    // Render report
    const output = formatter(reportData, options.includeTotals);

    // Write output
    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }

  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

main();
