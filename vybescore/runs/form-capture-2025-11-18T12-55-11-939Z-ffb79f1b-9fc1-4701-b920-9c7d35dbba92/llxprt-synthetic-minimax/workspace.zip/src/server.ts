import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// SQL.js module type
interface SqlJsModule {
  Database: new (data?: ArrayLike<number>) => Database;
  Statement: new () => unknown;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// SQL.js setup
let db: Database | null = null;
let sqlJs: SqlJsModule | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    sqlJs = await initSqlJs({
      locateFile: (file) => path.join(__dirname, '../node_modules/sql.js/dist', file)
    });

    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const fs = await import('fs');
    
    let dbData: Uint8Array | null = null;
    
    if (fs.existsSync(dbPath)) {
      try {
        const buffer = fs.readFileSync(dbPath);
        dbData = new Uint8Array(buffer);
      } catch (error) {
        console.warn('Could not read existing database file, starting fresh:', error);
      }
    }

    db = dbData ? new sqlJs.Database(dbData) : new sqlJs.Database();
    
    // Execute schema
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    db!.exec(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Database initialization failed:', error);
    throw error;
  }
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalCode', 'country', 'email', 'phoneNumber'
  ];
  
  for (const field of requiredFields) {
    if (!data[field].trim()) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }
  
  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  // Phone validation
  if (data.phoneNumber && !validatePhoneNumber(data.phoneNumber)) {
    errors.push({ field: 'phoneNumber', message: 'Please enter a valid phone number' });
  }
  
  // Postal code validation (allow alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }
  
  return errors;
}

async function saveDatabase(): Promise<void> {
  if (!db || !sqlJs) return;
  
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  const fs = await import('fs');
  
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

async function insertSubmission(data: FormData): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province_region, postal_code, country, email, phone_number
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    data.firstName.trim(),
    data.lastName.trim(),
    data.streetAddress.trim(),
    data.city.trim(),
    data.stateProvinceRegion.trim(),
    data.postalCode.trim(),
    data.country.trim(),
    data.email.trim(),
    data.phoneNumber.trim()
  ]);
  
  stmt.free();
  await saveDatabase();
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database immediately when module is loaded
initializeDatabase().catch(error => {
  console.error('Failed to initialize database on module load:', error);
});

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    formData: {} as FormData,
    title: 'Contact Us - Friendly Form'
  });
});

app.post('/submit', async (req, res, next) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phoneNumber || ''
    };

    const errors = validateFormData(formData);
    
    if (errors.length > 0) {
      return res.status(400).render('form', {
        errors,
        formData,
        title: 'Contact Us - Please Fix Errors'
      });
    }

    await insertSubmission(formData);
    return res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Submission error:', error);
    next(error);
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { 
    title: 'Thank You - We will Be In Touch!'
  });
});

// Error handling middleware
app.use((err: Error, req: express.Request, res: express.Response) => {
  console.error('Error:', err);
  res.status(500).send('Something went wrong! Please try again later.');
});

// Export app for testing
export { app };

// Graceful shutdown
async function shutdown() {
  console.log('Shutting down gracefully...');
  
  if (db) {
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server only if this file is run directly
async function startServer() {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Only start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}