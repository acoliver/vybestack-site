import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import express from 'express';
import { createServer } from 'http';

const dbPath = path.resolve('data', 'submissions.sqlite');

let server: ReturnType<typeof createServer>;
let testApp: express.Express;

beforeAll(async () => {
  // Import the server module without starting it
  const serverModule = await import('../../dist/server.js');
  testApp = serverModule.app;
  
  const httpServer = createServer(testApp);
  server = httpServer;
  await new Promise<void>((resolve) => {
    server.listen(0, resolve);
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Get In Touch');
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Street Address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State/Province/Region');
    expect(response.text).toContain('Postal/Zip Code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email Address');
    expect(response.text).toContain('Phone Number');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvinceRegion: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phoneNumber: '+1234567890'
    };

    const response = await request(server)
      .post('/submit')
      .send(testData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('shows validation errors for missing fields', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe'
        // Missing other required fields
      })
      .expect(400);

    expect(response.text).toContain('Please fix the following errors');
    expect(response.text).toContain('is required');
  });
});
