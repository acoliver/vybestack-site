import type { EqualFn, InputPair, Options } from '../types/reactive.js'
import { getActiveObserver } from '../types/reactive.js'

export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const observers = new Set<() => void>()
  
  const equalFn: EqualFn<T> = equal || ((a: T, b: T) => a === b)
  let currentValue = value

  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver && 'updateFn' in activeObserver) {
      const observerUpdateFn = (activeObserver as { updateFn: () => void }).updateFn
      observers.add(observerUpdateFn)
    }
    return currentValue
  }

  const setter = (newValue: T): T => {
    if (!equalFn(currentValue, newValue)) {
      currentValue = newValue
      
      // Notify all observers with the new value
      const observersToNotify: Array<() => void> = Array.from(observers)
      observersToNotify.forEach(observer => {
        try {
          observer()
        } catch {
          // Ignore observer errors
        }
      })
    }
    return currentValue
  }

  return [getter, setter]
}