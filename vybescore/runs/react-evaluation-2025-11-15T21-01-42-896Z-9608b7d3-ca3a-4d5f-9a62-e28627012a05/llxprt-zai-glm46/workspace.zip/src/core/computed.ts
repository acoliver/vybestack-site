import type { EqualFn, GetterFn, Options, UpdateFn } from '../types/reactive.js'
import { getActiveObserver, setActiveObserver } from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: EqualFn<T>,
  options?: Options
): GetterFn<T> {
  let computedValue: T
  let isDirty = true
  const dependencies = new Set<() => void>()
  const observers = new Set<() => void>()
  
  

  if (value !== undefined) {
    computedValue = value
    isDirty = false
  }

  const compute = (): T => {
    if (isDirty) {
      dependencies.clear()
      
      // Set this computed as the active observer to track dependencies
      const computedObserver = {
        name: `computed-${options?.name || 'anonymous'}`,
        updateFn: () => {
          isDirty = true
          // Notify observers that this computed value has changed
          observers.forEach(observer => {
            try {
              observer()
            } catch {
              // Ignore observer errors
            }
          })
        }
      }
      
      const previousObserver = getActiveObserver()
      setActiveObserver(computedObserver)
      
      try {
        computedValue = updateFn()
        isDirty = false
      } finally {
        setActiveObserver(previousObserver)
      }
    }
    return computedValue
  }

  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver && 'updateFn' in activeObserver) {
      // Register this computed's update function with the active observer
      const observerUpdateFn = (activeObserver as { updateFn: () => void }).updateFn
      observers.add(observerUpdateFn)
    }
    return compute()
  }

  return getter
}