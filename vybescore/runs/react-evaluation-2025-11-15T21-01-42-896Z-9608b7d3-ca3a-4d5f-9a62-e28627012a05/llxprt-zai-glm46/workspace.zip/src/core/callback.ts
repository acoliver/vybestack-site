import type { UnsubscribeFn, UpdateFn } from '../types/reactive.js'
import { getActiveObserver, setActiveObserver } from '../types/reactive.js'

export function createCallback<T>(
  updateFn: UpdateFn<T>,
  _value?: T
): UnsubscribeFn {
  let isActive = true
  
  const callbackObserver = {
    name: 'callback',
    updateFn: () => {
      if (isActive) {
        try {
          updateFn()
        } catch {
          // Ignore callback errors
        }
      }
    }
  }
  
  // Set up the callback observer to track dependencies
  const previousObserver = getActiveObserver()
  setActiveObserver(callbackObserver)
  
  try {
    // Initial execution to track dependencies
    updateFn()
  } finally {
    setActiveObserver(previousObserver)
  }
  
  const unsubscribe = (): void => {
    isActive = false
  }
  
  return unsubscribe
}