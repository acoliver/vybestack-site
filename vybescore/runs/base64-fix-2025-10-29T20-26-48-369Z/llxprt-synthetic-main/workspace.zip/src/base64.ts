/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet (+, /) and includes proper padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and rejects invalid data according to RFC 4648.
 */
export function decode(input: string): string {
  // Validate the Base64 input format
  const base64Pattern = /^[A-Za-z0-9+/]+={0,2}$/;
  
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }

  // Check if padding is valid and length is correct
  const length = input.length;
  const paddingIndex = input.indexOf('=');
  
  if (paddingIndex !== -1) {
    // If padding exists, it must only be at the end
    const padding = input.substring(paddingIndex);
    if (!/^(=|==)$/.test(padding) || input.slice(0, paddingIndex).includes('=')) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
  }
  
  // Total length must be a multiple of 4
  if (length % 4 !== 0) {
    throw new Error('Invalid Base64 input: incorrect length (must be multiple of 4)');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify the result by encoding it back and comparing with the input
    // (ignoring padding differences)
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const inputWithoutPadding = input.replace(/=+$/, '');
    const reencodedWithoutPadding = reencoded.replace(/=+$/, '');
    
    if (inputWithoutPadding !== reencodedWithoutPadding) {
      throw new Error('Invalid Base64 input: failed to decode to valid UTF-8');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}
