/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet with required padding.
 */
export function encode(input: string): string {
  // Special case: empty string should encode to empty string
  if (input === '') {
    return '';
  }
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode RFC 4648 standard Base64 text back to plain UTF-8.
 * Validates input and throws error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Empty input is valid
  if (input === '') {
    return '';
  }

  // Basic validation: check for valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check padding: padding can only appear at the end and at most 2 padding chars
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding found, ensure it's only at the end
    const paddingPart = input.substring(paddingIndex);
    if (!/==?/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Check if valid length considering padding
    const unpaddedLength = paddingIndex;
    const remainder = unpaddedLength % 4;
    if (paddingPart.length === 1 && remainder !== 3) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
    if (paddingPart.length === 2 && remainder !== 2) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
  }
  // Remove the length check for unpadded input - Node.js Buffer can handle these cases

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if the resulting buffer has a valid length
    // This helps catch cases where Buffer.from silently errors
    if (input.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
