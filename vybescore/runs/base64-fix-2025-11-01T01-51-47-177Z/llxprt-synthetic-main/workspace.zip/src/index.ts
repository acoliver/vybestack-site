#!/usr/bin/env node
import { decode, encode } from './base64.js';

type Command = 'encode' | 'decode';

function parseArgs(argv: string[]): { command: Command; value: string } {
  if (argv.length < 1) {
    throw new Error('Usage: --encode <text> | --decode <base64>');
  }

  // Special case: empty command (user just passed --encode without arguments)
  if (argv.length === 1) {
    throw new Error('Provide a value to encode or decode.');
  }

  const [flag, ...rest] = argv;
  const value = rest.join(' ');

  if (flag === '--encode') {
    return { command: 'encode', value };
  }

  if (flag === '--decode') {
    return { command: 'decode', value };
  }

  throw new Error(`Unknown flag: ${flag}`);
}

export function run(argv: string[]): number {
  try {
    const { command, value } = parseArgs(argv);
    const result = command === 'encode' ? encode(value) : decode(value);
    process.stdout.write(`${result}\n`);
    return 0;
  } catch (error) {
    const message =
      error instanceof Error && error.message ? error.message : 'Unexpected error';
    process.stderr.write(`${message}\n`);
    return 1;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const exitCode = run(process.argv.slice(2));
  process.exitCode = exitCode;
}
