const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_CHARS_REGEX = /[^A-Za-z0-9+/=]/;

/**
 * Encode plain text to Base64 using canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 with proper validation.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate input format
  if (typeof input !== 'string' || input.length === 0) {
    throw new Error('Invalid Base64 input: empty or not a string');
  }

  // Remove whitespace from input
  const trimmedInput = input.replace(/\s+/g, '');

  // Check for invalid characters
  if (INVALID_CHARS_REGEX.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check basic Base64 format (allows missing padding)
  const normalizedInput = trimmedInput.padEnd(Math.ceil(trimmedInput.length / 4) * 4, '=');
  
  if (!BASE64_REGEX.test(normalizedInput)) {
    throw new Error('Invalid Base64 input: malformed format');
  }

  try {
    const result = Buffer.from(normalizedInput, 'base64').toString('utf8');
    
    // Verify that the encoded result matches the original (ignoring padding)
    const reencoded = Buffer.from(result, 'utf8').toString('base64').replace(/=+$/, '');
    const originalWithoutPadding = trimmedInput.replace(/=+$/, '');
    
    if (reencoded !== originalWithoutPadding) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
