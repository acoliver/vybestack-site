/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const observers = new Set<Observer<unknown | never>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Track observers for dependency management
export function addObserver<T>(observer: Observer<T>): void {
  (observers as Set<Observer<T>>).add(observer)
}

export function removeObserver<T>(observer: Observer<T>): void {
  (observers as Set<Observer<T>>).delete(observer)
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(): void {
  // Update all observers in proper dependency order
  const updated = new Set<Observer<unknown | never>>()
  const toUpdate = new Set(observers as Set<Observer<unknown>>)
  
  function updateAndNotify(observer: Observer<unknown | never>) {
    if (updated.has(observer)) return
    updated.add(observer)
    updateObserver(observer)
  }
  
  // Simple breadth-first update to handle dependencies
  let changed: boolean
  do {
    changed = false
    toUpdate.forEach(observer => {
      const previousValue = observer.value
      updateAndNotify(observer)
      if (previousValue !== observer.value) {
        changed = true
      }
    })
  } while (changed)
}
