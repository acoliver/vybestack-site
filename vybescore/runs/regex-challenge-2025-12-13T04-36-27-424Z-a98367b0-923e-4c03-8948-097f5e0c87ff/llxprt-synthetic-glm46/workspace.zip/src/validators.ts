export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  // Remove any non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Luhn algorithm implementation
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses with the following constraints:
 * - Accept typical addresses such as name+tag@example.co.uk
 * - Reject double dots, trailing dots, domains with underscores
 * - Reject other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Extract local part and domain
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject starting dots in local part or domain
  if (localPart.startsWith('.') || domain.startsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Ensure domain has at least one valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2 || domainParts[domainParts.length - 1].length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with the following formats:
 * - (212) 555-7890
 * - 212-555-7890
 * - 2125557890
 * - Optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Clean the input by removing common separators
  const cleanedValue = value.replace(/[\s()-]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleanedValue;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }
  
  // US phone numbers should have 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Check that we have only digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format with regex for more comprehensive check
  // Since we've already validated the digits, just check that the original format is reasonable
  return /^\+?1?[\s\-.]?(\([2-9]\d{2}\)[\s\-.]?|[2-9]\d{2})[\s\-.]?[2-9]\d{2}[\s\-.]?\d{4}$/.test(value);
}

/**
 * Validates Argentine phone numbers with the following constraints:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must be 6-8 digits
 * - When country code is omitted, number must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Comprehensive regex for Argentine phone numbers
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?0?\d{2,4}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract parts for more detailed validation
  let remaining = cleaned;
  let hasCountryCode = false;
  
  // Check for country code
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
  }
  
  // Skip mobile indicator if present
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Check for trunk prefix
  if (remaining.startsWith('0')) {
    remaining = remaining.substring(1);
  } else if (!hasCountryCode) {
    // If no country code, must have trunk prefix
    return false;
  }
  
  // Extract area code (2-4 digits starting with 1-9)
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  remaining = remaining.substring(areaCode.length);
  
  // Remaining is the subscriber number (6-8 digits)
  const subscriberNumber = remaining;
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // All digits should be numbers
  if (!/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names with the following constraints:
 * - Permit unicode letters, accents, apostrophes, hyphens, spaces
 * - Reject digits, symbols, and "X Æ A-12" style names
 */
export function isValidName(value: string): boolean {
  // Check if the string is empty
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // This regex matches names like José, O'Connor, Mary-Jane, 王建国
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that start or end with apostrophes, hyphens, or spaces
  if (/^['\s-]|['\s-]$/.test(value)) {
    return false;
  }
  
  // Reject names with consecutive apostrophes, hyphens, or spaces
  if (/'{2,}|-{2,}|\s{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers with the following constraints:
 * - Accept Visa/Mastercard/AmEx prefixes and lengths
 * - Run a Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any non-digit characters (spaces, hyphens, etc.)
  const digits = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits for major card types
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|4[0-1]\d|52[0-8]|5[2-9]\d|6[0-3]\d|64[0-3]|65[0-2]\d|73[0-1])\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the digits match any supported card format
  const isCardFormat = visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
  
  if (!isCardFormat) {
    return false;
  }
  
  // Validate using Luhn algorithm
  return runLuhnCheck(digits);
}