/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special characters in the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find words starting with the prefix (with word boundaries)
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[a-zA-Z0-9_-]*)\\b`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Skip if the word is in the exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

// Alternative implementation for findEmbeddedToken that doesn't use lookbehind
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special characters in the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of the token preceded by a digit
  const matches = [];
  const tokenPattern = new RegExp(`${escapedToken}`, 'g');
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    const tokenIndex = match.index;
    
    // Check if this occurrence is not at the start of the string
    if (tokenIndex > 0) {
      // Check if the character before the token is a digit
      const prevChar = text[tokenIndex - 1];
      if (/\d/.test(prevChar)) {
        // Return the digit plus the token (the expected behavior)
        matches.push(prevChar + match[0]);
      }
    }
  }
  
  return matches;
}

/**
 * Validates passwords with the following policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (anything that's not alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences of length 2 or more
  // This will detect patterns like "abab", "123123", "abcabc", etc.
  for (let i = 0; i < value.length / 2; i++) {
    for (let len = 2; len <= value.length / 2; len++) {
      if (i + len * 2 <= value.length) {
        const segment1 = value.substring(i, i + len);
        const segment2 = value.substring(i + len, i + len * 2);
        if (segment1 === segment2) {
          return false;
        }
      }
    }
  }
  
  // Also check for immediate character repetition (e.g., "aa", "111")
  if (/(.)\1{1,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Simple regex to check for IPv6 with colon
  const hasColon = /:/.test(value);
  
  // If no colon, it's not IPv6
  if (!hasColon) {
    return false;
  }
  
  // This regex matches IPv6 addresses in various formats:
  // - Standard form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Shorthand with :: compression
  // - IPv4-mapped IPv6 addresses (e.g., ::ffff:192.0.2.128)
  const ipv6Regex = /(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))(?:$|(?=\s))/;
  
  // This regex matches IPv4 addresses
  const ipv4Regex = /(?:^|(?<=\s))(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:$|(?=\s))/;
  
  // Check if IPv4 is present
  const hasIPv4 = ipv4Regex.test(value);
  
  // Check if IPv6 is present
  const hasIPv6 = ipv6Regex.test(value);
  
  // Return true only if IPv6 is detected and IPv4 is not detected
  return hasIPv6 && !hasIPv4;
}