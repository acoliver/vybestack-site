/**
 * Capitalizes the first character of each sentence with the following rules:
 * - Capitalize the first character after . ? !
 * - Insert exactly one space between sentences even if input omitted it
 * - Collapse extra spaces sensibly
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // If text is empty or already properly capitalized, return as is
  if (!text) return text;
  
// First, ensure there's space after sentence terminators
  const result = text.replace(/([.?!])(?=\\S)/g, '$1 ');
  
  // Process text character by character to capitalize sentences properly
  const chars = result.split('');
  let capitalizeNext = true; // First character should be capitalized
  
  for (let i = 0; i < chars.length; i++) {
    const char = chars[i];
    
    // If we encounter a sentence terminator, next character should be capitalized
    if (char === '.' || char === '?' || char === '!') {
      capitalizeNext = true;
    } 
    // If it's a non-space character and we need to capitalize, do it
    else if (capitalizeNext && /\S/.test(char)) {
      // Find the start of the word and capitalize it
      let wordStart = i;
      while (wordStart < chars.length && /[\s]/.test(chars[wordStart])) {
        wordStart++;
      }
      
      if (wordStart < chars.length) {
        chars[wordStart] = chars[wordStart].toUpperCase();
        capitalizeNext = false;
        i = wordStart;
      }
    }
  }
  
  return chars.join('');
}

/**
 * Extracts all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs
  // Matches http:// or https:// protocols followed by domain names
  const urlRegex = /https?:\/\/([a-zA-Z0-9\-._~:/?#[\]@!$&'()*+,;=%]|(?!\s)[^\u0020-\u007F])+/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation but keep it if it's part of the URL (like query parameters)
    return url.replace(/[.,;:!?]+$/g, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs with the following rules:
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for paths with dynamic hints (cgi-bin, query strings, or legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade to HTTPS
  const result = enforceHttps(text);
  
  // Process each URL in the text
  return result.replace(/https:\/\/([a-zA-Z0-9\-._~]+)(\/[^\s]*)?/g, (match, hostname, path = '') => {
    // If no path or path doesn't start with /docs/, just return as is
    if (!path || !path.startsWith('/docs/')) {
      return match;
    }
    
    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHint = /\/cgi-bin|(\?|&|=)|\/\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=\/|$)/i.test(path);
    
    if (hasDynamicHint) {
      // Has dynamic hint, only ensure HTTPS
      return match;
    }
    
    // This is a docs path without dynamic hints, rewrite host
    // Default case: assume example.com and replace with docs.example.com
    if (hostname === 'example.com') {
      return `https://docs.example.com${path}`;
    }
    
    // Handle other domains by prefixing with docs.
    return `https://docs.${hostname}${path}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match the mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Adjust February for leap years
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  if (month === 2 && isLeapYear) {
    maxDays[1] = 29;
  }
  
  if (day < 1 || day > maxDays[month - 1]) {
    return 'N/A';
  }
  
  return yearStr;
}