export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Local part: allow letters, digits, dots, hyphens, underscores, plus signs
  // But reject: consecutive dots, leading/trailing dot, double @, invalid domain chars
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;

  // Check for invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for specific invalid patterns
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // No trailing dot in local or domain part
  if (value.endsWith('.')) {
    return false;
  }

  // Domain should not contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('+')) {
    // Invalid country code
    return false;
  }

  // US phone numbers must have exactly 10 digits (or more if extensions allowed)
  if (digits.length < 10) {
    return false;
  }

  if (options?.allowExtensions && digits.length > 10) {
    // With extensions, we need at least 10 digits for the main number
    // The rest could be extension digits
  } else if (digits.length > 10) {
    // Too long without extension option
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) also cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like:
 * +54 9 11 1234 5678 (mobile with country code)
 * 011 1234 5678 (Buenos Aires landline with trunk prefix)
 * +54 341 123 4567 (landline with country code)
 * 0341 4234567 (landline with trunk prefix)
 *
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits, leading digit 1-9
 * - Subscriber number must be 6-8 digits
 * - When country code is omitted, must begin with trunk prefix 0
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Handle two main cases:
  // 1. With country code +54: +54[0][9]XXXXXXXXXX
  // 2. Without country code: 0[9]XXXXXXXXXX (must start with 0)
  
  // Check if it starts with +54
  if (cleaned.startsWith('+54')) {
    const afterCountry = cleaned.slice(3);
    // Pattern: [0][9]XXXXXXXXXX
    // - Optional 0 (trunk prefix)
    // - Optional 9 (mobile indicator)
    // - Area code: 2-4 digits starting with 1-9
    // - Subscriber: 6-8 digits
    const withCountryPattern = /^0?9?([1-9]\d{1,3})(\d{6,8})$/;
    const match = afterCountry.match(withCountryPattern);
    if (!match) {
      return false;
    }
    const areaCode = match[1];
    return areaCode.length >= 2 && areaCode.length <= 4;
  } else {
    // Must start with 0 (trunk prefix) when no country code
    if (!cleaned.startsWith('0')) {
      return false;
    }
    const afterTrunk = cleaned.slice(1);
    // Pattern: [9]XXXXXXXXXX
    // - Optional 9 (mobile indicator)
    // - Area code: 2-4 digits starting with 1-9
    // - Subscriber: 6-8 digits
    const withoutCountryPattern = /^9?([1-9]\d{1,3})(\d{6,8})$/;
    const match = afterTrunk.match(withoutCountryPattern);
    if (!match) {
      return false;
    }
    const areaCode = match[1];
    return areaCode.length >= 2 && areaCode.length <= 4;
  }
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Must have at least one letter
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one unicode letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Additional check: reject names that contain digits
  if (/\d/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Luhn algorithm for credit card checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be 13-19 digits (typical credit card lengths)
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }

  // Check card type prefixes and lengths
  const isVisa = /^4\d{12}(?:\d{3})?(?:\d{3})?$/.test(cleaned) && [13, 16, 19].includes(cleaned.length);
  const isMastercard = /^5[1-5]\d{14}$/.test(cleaned) && cleaned.length === 16;
  const isMastercard2 = /^2[2-7]\d{14}$/.test(cleaned) && cleaned.length === 16;
  const isAmEx = /^3[47]\d{13}$/.test(cleaned) && cleaned.length === 15;

  const validPrefix = isVisa || isMastercard || isMastercard2 || isAmEx;

  if (!validPrefix) {
    return false;
  }

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
