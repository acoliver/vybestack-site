/**
 * Capitalize the first character of each sentence.
 * - Capitalizes first character after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences if missing
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible (simple heuristic: doesn't capitalize single letters)
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: collapse multiple spaces into one
  let normalized = text.replace(/[ \t]+/g, ' ');

  // Fix missing space after sentence-ending punctuation
  // Look for punctuation followed by lowercase letter without space
  normalized = normalized.replace(/([.!?])([a-z])/g, '$1 $2');

  // Now capitalize first letter of each sentence
  // A sentence starts at the beginning of string or after .!?
  // We need to be careful not to capitalize after abbreviations like "Mr." or "Dr."
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St'];
  const abbrPattern = new RegExp(`\\b(?:${abbreviations.join('|')})\\.`, 'g');

  // Find positions of abbreviations to avoid capitalizing after them
  const abbrPositions: number[] = [];
  let match;
  while ((match = abbrPattern.exec(normalized)) !== null) {
    abbrPositions.push(match.index + match[0].length);
  }

  // Process the string character by character
  let result = '';
  let capitalizeNext = true; // Start of string should be capitalized

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];

    // Check if we're at an abbreviation end
    const isAbbrEnd = abbrPositions.includes(i);

    if (capitalizeNext && /[a-z]/.test(char)) {
      result += char.toUpperCase();
      capitalizeNext = false;
    } else {
      result += char;
    }

    // After sentence-ending punctuation, capitalize next letter
    // But not if we're at an abbreviation end
    if (/[.!?]/.test(char) && !isAbbrEnd) {
      // Skip any closing quotes or parentheses
      let j = i + 1;
      while (j < normalized.length && /["'")]/.test(normalized[j])) {
        j++;
      }
      capitalizeNext = true;
    }
  }

  // Trim leading/trailing whitespace
  return result.trim();
}

/**
 * Extract all URLs from the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. prefixes
  // Excludes trailing punctuation
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"'(){}[\]]+(?:\/[^\s<>"'(){}[\]]*)?/gi;

  const matches = text.match(urlPattern) || [];

  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation: .,;:?! but not if it's part of the URL
    return url.replace(/[,.;:!?]+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Convert all http:// URLs to https://
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite URLs from http://example.com/... to https://...
 * Special handling for /docs/ paths:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  // Matches http://example.com or https://example.com
  const urlPattern = /(https?):\/\/example\.com(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, protocol, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https';

    // Check if we should rewrite to docs.example.com
    let shouldRewriteHost = false;

    if (path && path.startsWith('/docs/')) {
      // Check for exclusion patterns
      const hasCgiBin = path.includes('/cgi-bin/');
      const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
      const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(path);

      if (!hasCgiBin && !hasQueryString && !hasLegacyExtension) {
        shouldRewriteHost = true;
      }
    }

    if (shouldRewriteHost) {
      return `${newProtocol}://docs.example.com${path}`;
    } else {
      return `${newProtocol}://example.com${path || ''}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted dates.
 * Returns 'N/A' when format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  // Basic year validation (reasonable years)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }

  return year;
}
