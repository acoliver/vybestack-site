/**
 * Find words starting with the given prefix, excluding specified exceptions.
 * Returns array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with prefix
  // \b ensures we match word boundaries
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(e => e.toLowerCase());

  return matches
    .map(word => word) // Normalize case for filtering
    .filter(word => !lowerExceptions.includes(word.toLowerCase()))
    .filter((word, index, self) => self.indexOf(word) === index); // Remove duplicates
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds as specified.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to find token preceded by a digit
  // Return the full match including the digit
  const fullMatchPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const fullMatches = text.match(fullMatchPattern) || [];

  return fullMatches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }

  // Check for repeated sequences of length 2 or more
  // e.g., "abab", "123123", "abcabc"
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.slice(i, i + len);
      const nextSegment = value.slice(i + len, i + len * 2);
      if (segment === nextSegment) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses in the text.
 * - Supports shorthand notation with ::
 * - Ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (various formats)
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can appear once to replace consecutive zeros

  // Check for IPv6 address patterns anywhere in the text
  // This pattern matches:
  // - Full IPv6: 8 groups of hex digits
  // - Shorthand IPv6: :: for zero compression
  // - Must have at least 3 colons to be a valid IPv6

  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}/;

  return ipv6Pattern.test(value);
}
