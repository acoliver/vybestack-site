/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // If this observer has its own observers (computed values), notify them
  const computedObserver = observer as Observer<T> & { observers?: Set<ObserverR> }
  if (computedObserver.observers && computedObserver.observers.size > 0) {
    const observers = Array.from(computedObserver.observers)
    observers.forEach((obs: ObserverR) => {
      updateObserver(obs as Observer<T>)
    })
  }
}

export function addObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.add(observer)
}

export function removeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.delete(observer)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Create a copy to avoid issues with observers being added/removed during iteration
  const observers = Array.from(subject.observers)
  observers.forEach(observer => {
    updateObserver(observer as Observer<T>)
  })
}

export function trackDependency<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer) {
    addObserver(subject, observer)
  }
}

export function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}
