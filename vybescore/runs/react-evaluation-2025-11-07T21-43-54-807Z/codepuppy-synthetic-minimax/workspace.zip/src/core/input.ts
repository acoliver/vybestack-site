/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  ObserverR,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  defaultEqual,
  trackDependency,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle the equal parameter
  let equalFn: EqualFn<T>
  if (equal === undefined || equal === true) {
    equalFn = defaultEqual
  } else if (equal === false) {
    equalFn = () => false // Always false, always notify
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    trackDependency(s)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
