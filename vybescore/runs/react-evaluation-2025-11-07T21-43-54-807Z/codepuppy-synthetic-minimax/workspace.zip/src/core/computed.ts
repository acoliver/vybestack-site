/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  updateObserver,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  // Make the computed value both an observer and a subject
  const observer: Observer<T> & { observers: Set<ObserverR> } = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set<ObserverR>()
  }
  
  // Set this as the active observer and compute the initial value
  updateObserver(observer)
  
  // Return getter function that returns the current value
  // and registers this computed as a dependency when accessed
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== observer) {
      // Another observer is accessing this computed value - add it as observer
      observer.observers.add(currentObserver)
      
      // Set this computed as the active observer to track its dependencies
      const prevObserver = getActiveObserver()
      setActiveObserver(observer as ObserverR)
      try {
        return observer.value!
      } finally {
        setActiveObserver(prevObserver)
      }
    }
    return observer.value!
  }
  
  return getter
}

