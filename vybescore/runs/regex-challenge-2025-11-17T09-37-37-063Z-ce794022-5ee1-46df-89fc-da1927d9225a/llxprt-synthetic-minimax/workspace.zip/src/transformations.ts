/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, clean up multiple spaces but preserve sentence structure
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to find sentence endings followed by text
  // Look for .!? followed by any whitespace and then a letter
  result = result.replace(/([.!?])\s*([A-Za-z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Handle the first sentence (no preceding punctuation)
  result = result.replace(/^([A-Za-z])/, (match, letter) => letter.toUpperCase());
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches common URL formats
  const urlRegex = /https?:\/\/[^\s<>"'()]+|www\.[^\s<>"'()]+/gi;
  
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return urls.map(url => {
    // Remove trailing punctuation that commonly follows URLs
    return url.replace(/[.,!?;:"')\]]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing https:// untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs with paths
  const urlRegex = /http:\/\/example\.com(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, path) => {
    let newUrl = 'https://';
    
    // Check if path contains dynamic hints that should prevent host rewrite
    const hasDynamicHints = /cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.example.com';
      // Keep the rest of the path, including /docs/
      newUrl += path;
    } else {
      // Keep the original host (example.com) but upgrade scheme
      newUrl += 'example.com';
      newUrl += path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (1000-9999, already ensured by regex)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  return year.toString();
}