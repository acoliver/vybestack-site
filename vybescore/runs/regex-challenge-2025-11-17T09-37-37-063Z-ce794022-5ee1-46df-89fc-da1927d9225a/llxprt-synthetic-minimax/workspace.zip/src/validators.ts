export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject obviously invalid patterns first
  if (value.includes('..') || value.includes('@.') || value.endsWith('.')) {
    return false;
  }
  
  // Basic email validation with regex
  // Reject double @, domains with underscores, and trailing dots
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Too short
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Check for area code (first 3 digits)
  if (digitsOnly.length === 11) {
    // Should start with 1 for 11-digit numbers
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
    const areaCode = digitsOnly.substring(1, 4);
    // Area code cannot start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
  } else if (digitsOnly.length === 10) {
    const areaCode = digitsOnly.substring(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean up the input - normalize whitespace
  const cleanValue = value.trim().replace(/\s+/g, ' ');
  
  // Remove all separators and spaces to get digits only
  const digitsOnly = cleanValue.replace(/\D/g, '');
  
  // Must have valid length (country code + area code + subscriber number)
  if (digitsOnly.length < 8 || digitsOnly.length > 15) {
    return false;
  }
  
  // Pattern that matches valid formats
  // This pattern will capture the area code that starts with the first non-zero digit
  // but may include the trunk prefix "0" when no country code is present
  const phoneRegex = /^(?:\+54\s*)?(?:9\s*)?(?:0\s*)?([1-9]\d{1,3})\s+(.+)$/;
  const match = cleanValue.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
const areaCode = match[1];
  const subscriberPart = match[2];
  
  // Extract digits from subscriber part
  const subscriberDigits = subscriberPart.replace(/\D/g, '');
  
  // Calculate expected total length based on what components are present
  let expectedLength = 0;
  let hasCountryCode = false;
  
  // Check country code
  if (cleanValue.includes('+54')) {
    expectedLength += 2; // "+54" = 2 digits
    hasCountryCode = true;
    
    // Check for mobile indicator after country code
    if (cleanValue.match(/\+54\s*9/)) {
      expectedLength += 1; // "9" = 1 digit
    }
  }
  
  // Check for trunk prefix (when no country code)
  if (!hasCountryCode && cleanValue.startsWith('0')) {
    expectedLength += 1; // "0" = 1 digit
    
    // Check for mobile indicator after trunk prefix
    if (cleanValue.match(/^0\s*9/)) {
      expectedLength += 1; // "9" = 1 digit
    }
  }
  
  // Add area code and subscriber
  expectedLength += areaCode.length;
  expectedLength += subscriberDigits.length;
  
  if (digitsOnly.length !== expectedLength) {
    return false;
  }
  
  // When country code is omitted, number must begin with trunk prefix 0
  if (!hasCountryCode && !cleanValue.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation
  // Pattern allows:
  // - Unicode letters (including accented characters)
  // - Spaces between parts
  // - Apostrophes
  // - Hyphens
  // Must have at least one letter
  
  // Check if it contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for invalid symbols (anything that's not letter, space, apostrophe, or hyphen)
  const validPattern = /^[\p{L}\s'-]+$/u;
  if (!validPattern.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement credit card validation with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for reasonable length (credit cards are typically 13-19 digits)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for common credit card patterns
  // Visa: starts with 4, 13, 16, or 19 digits
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  // American Express: starts with 34 or 37, 15 digits
  
  const visaPattern = /^4\d{12}(\d{3})?(\d{3})?$/;
  const mastercardPattern = /^(5[1-5]\d{14}|2(2[2-9]\d{2}|[3-6]\d{3}|7[01]\d{2}|720\d)\d{12})$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  const isValidType = visaPattern.test(digitsOnly) || 
                      mastercardPattern.test(digitsOnly) || 
                      amexPattern.test(digitsOnly);
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to run the Luhn checksum validation
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}