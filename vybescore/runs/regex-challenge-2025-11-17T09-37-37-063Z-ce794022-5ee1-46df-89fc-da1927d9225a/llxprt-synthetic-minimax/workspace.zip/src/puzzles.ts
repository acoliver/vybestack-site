/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with the prefix
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token occurrences that appear after a digit (lookbehind) and not at the start of string
  const matches: string[] = [];
  const regex = new RegExp(`(?<!^)(?<=\\d)${token}`, 'g');
  
  let match;
  while ((match = regex.exec(text)) !== null) {
    // Get the position of the match and include the preceding digit
    const matchPos = match.index;
    if (matchPos > 0) {
      const digitBefore = text.charAt(matchPos - 1);
      if (/\d/.test(digitBefore)) {
        matches.push(digitBefore + match[0]);
      }
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9\s]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "cdcd", "1212")
  // Pattern looks for any 2+ character sequence that repeats immediately
  const repeatedPattern = /(..+)\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes:
  // - Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // - Shortened IPv6 with :: (compressed zeros)
  // - IPv4-mapped IPv6 (::ffff:192.168.1.1)
  // Excludes pure IPv4 patterns
  
  // First check if it's purely IPv4 format (to reject pure IPv4)
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns (without anchors since IPv6 can be part of larger text)
  // Full format: 2001:0db8:0000:0000:0000:ff00:0042:8329
  const fullIpv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Compressed format with :: (various positions)
  const compressedIpv6 = /::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{0,4}/;
  const compressedIpv6Start = /[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{0,4}/;
  const compressedIpv6Middle = /(?:[0-9a-fA-F]{1,4}:){1,5}::(?:[0-9a-fA-F]{1,4}:){0,4}[0-9a-fA-F]{0,4}/;
  
  // IPv4-mapped IPv6: ::ffff:192.168.1.1
  const ipv4MappedIpv6 = /::ffff:(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)/;
  
  // Use test method which only returns true/false
  return fullIpv6.test(value) || 
         compressedIpv6.test(value) || 
         compressedIpv6Start.test(value) || 
         compressedIpv6Middle.test(value) || 
         ipv4MappedIpv6.test(value);
}