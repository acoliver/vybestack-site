/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ReactiveNode,
  updateObserver,
  notifyObservers,
  setActiveObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'function') return equal
  if (equal === true) return (lhs: T, rhs: T) => lhs === rhs
  return undefined
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // Create observer for this computed value
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Set this observer as active so dependencies can track it
      setActiveObserver(observer)
      try {
        const newValue = updateFn(prevValue)
        // Check if value actually changed using equalFn if provided
        if (equalFn && observer.value !== undefined && equalFn(observer.value, newValue)) {
          return observer.value
        }
        observer.value = newValue
        return newValue
      } finally {
        setActiveObserver(undefined)
      }
    },
  }
  
  // Create reactive node for this computed value so others can observe it
  const node: ReactiveNode<T> = {
    name: options?.name,
    value: value as T,
    equalFn,
    observers: new Set(),
  }
  
  // Initialize the computed value by running the update function
  updateObserver(observer)
  node.value = observer.value as T
  
  // When the computed value updates, notify its own observers
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    node.value = result as T
    notifyObservers(node)
    return result
  }
  
  return (): T => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      node.observers.add(activeObs)
    }
    return node.value
  }
}