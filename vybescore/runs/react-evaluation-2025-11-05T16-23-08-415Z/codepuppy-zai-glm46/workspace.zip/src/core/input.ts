/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  ReactiveNode,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'function') return equal
  if (equal === true) return (lhs, rhs) => lhs === rhs
  return undefined
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const node: ReactiveNode<T> = {
    name: options?.name,
    value,
    equalFn: createEqualFn(equal),
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      node.observers.add(observer)
    }
    return node.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equalFn if provided
    if (node.equalFn && node.equalFn(node.value, nextValue)) {
      return node.value
    }
    
    node.value = nextValue
    notifyObservers(node)
    return node.value
  }

  return [read, write]
}
