/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

// Base observer type for tracking dependencies
export type BaseObserver = ObserverR & {
  value?: unknown
  updateFn: (value?: unknown) => unknown
}

// We'll use a global tracking system instead of per-subject observers
export type ReactiveNode<T> = {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<BaseObserver>
}

let activeObserver: BaseObserver | undefined

export function getActiveObserver(): BaseObserver | undefined {
  return activeObserver
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): void {
  activeObserver = observer as BaseObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as BaseObserver
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(node: ReactiveNode<T>): void {
  node.observers.forEach(observer => {
    updateObserver(observer as Observer<T>)
  })
}
