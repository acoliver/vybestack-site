/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

// Helper to convert boolean or EqualFn to EqualFn
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function toEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    if (equal) {
      return (a: T, b: T) => a === b
    } else {
      return undefined
    }
  }
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  
  
  const getter = (): T => {
    // Register this computed as a dependency for the current active observer
    const currentObserver = getActiveObserver()
    if (currentObserver && !o.dependencies?.includes(currentObserver)) {
      // This computed is being accessed by another observer
      // Track it so it gets updated when dependencies change
      if (!o.dependencies) o.dependencies = []
      o.dependencies.push(currentObserver)
    }
    
    return o.value!
  }
  
  // Initial computation
  updateObserver(o)
  
  return getter
}
