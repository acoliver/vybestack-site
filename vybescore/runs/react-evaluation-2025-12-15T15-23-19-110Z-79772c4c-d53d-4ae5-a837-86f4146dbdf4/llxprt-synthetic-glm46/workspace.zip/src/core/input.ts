/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Helper to convert boolean or EqualFn to EqualFn
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function toEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    if (equal) {
      return (a: T, b: T) => a === b
    } else {
      return undefined
    }
  }
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: [],
    value,
    equalFn: toEqualFn(_equal),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && s.observers && !s.observers.includes(observer)) {
      s.observers!.push(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed (if equality function provided)
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    // Update all registered observers
    if (s.observers) {
      for (const observer of s.observers) {
        updateObserver(observer as Observer<unknown>)
      }
    }
    return s.value
  }

  return [read, write]
}
