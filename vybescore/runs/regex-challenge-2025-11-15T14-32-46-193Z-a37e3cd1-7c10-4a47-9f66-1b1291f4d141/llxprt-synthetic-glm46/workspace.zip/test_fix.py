#!/usr/bin/env python3

import os

# Read transformations.ts line 74
with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()
    line74 = lines[73]  # 0-indexed
    print(f"Transformations line 74: {repr(line74)}")
    
# Replace line 74 with fixed version
lines[73] = '    return url.replace(/[.!?,;:)\}]+$/, \'\');\n'

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

# Read validators.ts line 69
with open('src/validators.ts', 'r') as f:
    lines = f.readlines()
    line69 = lines[68]  # 0-indexed
    print(f"Validators line 69: {repr(line69)}")
    
# Replace line 69 with fixed version
lines[68] = '  const cleanedValue = value.replace(/[\\s\\-\\(\\)]/g, \'\');\n'

with open('src/validators.ts', 'w') as f:
    f.writelines(lines)

print("Fixed regex escaping issues")