/**
 * Capitalizes the first character of each sentence with these requirements:
 * - Capitalize the first character of each sentence (after `?!.`)
 * - Insert exactly one space between sentences even if the input omitted it  
 * - Collapse extra spaces while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Step 1: Normalize spacing around sentence terminators (.?!)
  // Ensure there's exactly one space after each sentence terminator
  let processed = text.replace(/([.!?])([^ \t\n\f\r])/g, '$1 $2');
  
  // Step 2: Collapse multiple spaces to single spaces
  processed = processed.replace(/[ \t]+/g, ' ');
  
  // Step 3: Trim leading and trailing spaces
  processed = processed.trim();
  
  // Step 4: Handle capitalization
  // This is complex because we need to preserve abbreviations like "Mr. Smith"
  // We'll use a regex that looks for sentence beginnings with some heuristics
  
  // Common abbreviations that don't end a sentence
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K', 'U.N'];
  
  // First capitalize the very first character
  if (processed.length > 0) {
    processed = processed[0].toUpperCase() + processed.slice(1);
  }
  
  // Then find legitimate sentence boundaries and capitalize
  // A sentence boundary is a terminator (.?!) followed by whitespace and then a lowercase letter
  // We need to make sure we're not inside an abbreviation
  processed = processed.replace(/([.!?]\s+)([a-záéíóúñü])/g, (match, p1, p2) => {
    // Check if this might be an abbreviation by looking back
    const beforeMatch = processed.substring(0, processed.indexOf(match));
    
    // Get the word before the punctuation
    const wordBeforePunc = beforeMatch.match(/([a-zA-Z.]+)\s*$/);
    if (wordBeforePunc && wordBeforePunc[1]) {
      // Check if it matches our abbreviation patterns
      const word = wordBeforePunc[1].replace(/\.$/, ''); // Remove trailing dot if exists
      if (abbreviations.includes(word)) {
        return match; // Don't capitalize after an abbreviation
      }
    }
    
    return p1 + p2.toUpperCase();
  });
  
  // Also handle cases where there's no space after the terminator but we added one in step 1
  // This handles scenarios where we need to capitalize after punctuation
  // but also handle potential abbreviations
  return processed;
}

/**
 * Extracts all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern that captures various URL formats
  // Matches http://, https://, or protocol-less URLs
  // Accepts domains, IP addresses, and various path formats
  const urlRegex = /\b((?:https?:\/\/|www\.)[^\s<>"']+)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.!?,;:)}]+$/, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Use global replace to find all http:// URLs
  // The negative lookahead ensures we don't match https:// URLs
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs with these rules:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Pattern to match http://example.com/... URLs
  // Captures: 1 Protocol, 2 Host, 3 Path
  const urlRegex = /(https?):\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, host, path) => {
    // First, always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if we need to rewrite the host for docs paths
    // Skip dynamic hints: cgi-bin, query strings (?), legacy extensions
    const hasDynamicHint = 
      path.includes('/cgi-bin') || 
      path.includes('?') ||
      path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/);
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite the host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      // Transform host from example.com to docs.example.com
      const docsHost = host.replace(/^(?:www\.)?([^.]+)/, 'docs.$1');
      return secureProtocol + docsHost + path;
    }
    
    // Otherwise, just upgrade the protocol
    return secureProtocol + host + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string for return
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    (year => (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? 29 : 28)(parseInt(year, 10)), // February (leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31, // December
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}