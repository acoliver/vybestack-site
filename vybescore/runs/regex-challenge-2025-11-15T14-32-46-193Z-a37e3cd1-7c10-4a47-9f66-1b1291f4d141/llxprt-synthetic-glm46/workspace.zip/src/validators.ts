export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address based on these requirements:
 * - Accept typical addresses such as name+tag@example.co.uk
 * - Reject double dots, trailing dots, domains with underscores
 * - Reject other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic structure check
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(value)) return false;
  
  // Split into local and domain parts
  const [localPart, domain] = value.split('@');
  
  // Reject if local part starts or ends with dot or has consecutive dots
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) return false;
  
  // Reject if domain starts or ends with dot or has consecutive dots
  if (domain.startsWith('.') || domain.endsWith('.') || domain.includes('..')) return false;
  
  // Reject if domain contains underscores
  if (domain.includes('_')) return false;
  
  // Reject if TLD is too short or invalid
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2 || tld.length > 63) return false;
  
  // Check that each domain label is valid
  const domainLabels = domain.split('.');
  for (const label of domainLabels) {
    // Each label must start and end with alphanumeric
    const labelRegex = /^[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]$/;
    if (label.length === 1) {
      // Single character labels must be alphanumeric
      if (!/^[a-zA-Z0-9]$/.test(label)) return false;
    } else {
      if (!labelRegex.test(label)) return false;
      // Hyphens cannot appear at the start or end (handled by regex)
      // but also not be consecutive
      if (label.includes('--')) return false;
    }
  }
  
  // Check if local part is valid
  // Allow alphanumeric characters and these special characters: ._%+-
  const localRegex = /^[a-zA-Z0-9._%+-]+$/;
  if (!localRegex.test(localPart)) return false;
  
  return true;
}

/**
 * Validates US phone numbers with these requirements:
 * - Support formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallow impossible area codes (leading 0/1)
 * - Reject too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove common separators and spaces for cleaner validation
  const cleanedValue = value.replace(/[\s\-()]/g, '');
  
  // Basic regex pattern for US phone numbers
  // Optional +1 country code (11 digits total) or just 10 digits
  let phoneMatch;
  if (cleanedValue.startsWith('+1')) {
    // With country code, should be 12 digits (including + but not counting it)
    phoneMatch = cleanedValue.match(/^\+1([2-9]\d{9})$/);
  } else if (cleanedValue.length === 11 && cleanedValue.startsWith('1')) {
    // With 1 prefix, should be 11 digits
    phoneMatch = cleanedValue.match(/^1([2-9]\d{9})$/);
  } else {
    // Without country code, should be 10 digits
    phoneMatch = cleanedValue.match(/^([2-9]\d{9})$/);
  }
  
  if (!phoneMatch) return false;
  
  // Extract the 10-digit phone number part
  const phoneNumber = phoneMatch[1];
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate format-specific patterns
  if (value.includes('(') || value.includes(')')) {
    // If parentheses are used, they must be correctly placed around area code
    const parenRegex = /^\+?\d?[\s\-()]*\(\d{3}\)[-.]?\s?\d{3}[-.]?\s?\d{4}$/;
    if (!parenRegex.test(value)) return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers with these requirements:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2–4 digits (leading digit 1–9)
 * - Subscriber number (after the area code) must contain 6–8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all spaces and hyphens for validation
  const cleanedValue = value.replace(/[\s\-()]/g, '');
  
  // Try different regex patterns based on format variations
  // Pattern 1: With country code +54
  // +54 (optional) 9 (optional for mobile) area code (2-4 digits, no leading 0) subscriber number (6-8 digits)
  const withCountryCodeRegex = /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Pattern 2: Without country code (must start with 0 trunk prefix)
  // 0 (required) 9 (optional for mobile) area code (2-4 digits, no leading 0) subscriber number (6-8 digits)
  const withoutCountryCodeRegex = /^0(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  let match;
  if (cleanedValue.startsWith('+54')) {
    match = cleanedValue.match(withCountryCodeRegex);
  } else {
    match = cleanedValue.match(withoutCountryCodeRegex);
  }
  
  if (!match) return false;
  
  // Extract components
  // Extract components
  // Disabled: const hasMobilePrefix = match[1] !== undefined; // Has 9 prefix (mobile)
  const areaCode = match[2];
  const subscriberNumber = match[3];
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4) return false;
  if (!/^[1-9]/.test(areaCode)) return false;
  
  // Validate subscriber number (6-8 digits)
  if (!subscriberNumber || subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If the original input had separators, ensure they're valid (single spaces or hyphens)
  if (value !== cleanedValue) {
    const onlySpaces = value.replace(/[0-9+]/g, '');
    if (!/^[\s\-()]*$/.test(onlySpaces)) return false;
    
    // Check that we don't have consecutive spaces/hyphens
    if (value.includes('  ') || value.includes('--') || value.includes(' -') || value.includes('- ')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates personal names with these requirements:
 * - Permit unicode letters, accents, apostrophes, hyphens, spaces
 * - Reject digits, symbols
 * - Reject "X Æ A-12" style names (excessive symbols)
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check if the name has at least one character
  if (value.length === 0) return false;
  
  // Define valid characters: unicode letters, apostrophes, hyphens, spaces
  // And invalid ones: digits and most symbols
  const invalidChars = /[0-9!"#$%&()*+,./:;<=>?@[\]^_`{|}~]/;
  if (invalidChars.test(value)) return false;
  
  // Check if the name contains at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Check for consecutive special characters
  const consecutiveSpecialsRegex = /([-']{2,})/;
  if (consecutiveSpecialsRegex.test(value)) return false;
  
  // Check for valid structure: can't start or end with space, apostrophe, or hyphen
  const invalidStartEnd = /^[\s'-']-|[\s'-']+$/;
  if (invalidStartEnd.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers with these requirements:
 * - Accept Visa/Mastercard/AmEx prefixes and lengths
 * - Run a Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens (common formatting)
  const cleanedValue = value.replace(/[\s\-()]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanedValue)) return false;
  
  // Basic length check (typically 13-19 digits)
  if (cleanedValue.length < 13 || cleanedValue.length > 19) return false;
  
  // Check card type prefixes and lengths
  let isValidCardType = false;
  
  if (/^4/.test(cleanedValue)) {
    // Visa: starts with 4, length 13 or 16
    if (cleanedValue.length === 13 || cleanedValue.length === 16) {
      isValidCardType = true;
    }
  } else if (/^5[1-5]/.test(cleanedValue)) {
    // Mastercard: starts with 51-55, length 16
    if (cleanedValue.length === 16) {
      isValidCardType = true;
    }
  } else if (/^222[1-9]|^22[3-9]|^2[3-6]|^27[01]|^2720/.test(cleanedValue)) {
    // Mastercard: new range 2221-2720, length 16
    if (cleanedValue.length === 16) {
      isValidCardType = true;
    }
  } else if (/^3[47]/.test(cleanedValue)) {
    // American Express: starts with 34 or 37, length 15
    if (cleanedValue.length === 15) {
      isValidCardType = true;
    }
  }
  
  if (!isValidCardType) return false;
  
  // Perform Luhn check
  return runLuhnCheck(cleanedValue);
}

/**
 * Helper function to perform the Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + 1; // Sum the digits of the product
      }
    }
    
    sum += digit;
    isDouble = !isDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}