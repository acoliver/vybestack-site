/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  if (!Array.isArray(exceptions)) return [];
  
  // Build a regex pattern that matches words starting with the prefix
  // \b matches word boundaries, \w+ matches word characters
  // The pattern uses case-insensitive matching
  const wordBoundary = '\\b';
  const prefixPattern = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // Escape special regex chars
  const wordPattern = '\\w+';
  const regex = new RegExp(`${wordBoundary}${prefixPattern}${wordPattern}`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  return matches.filter(match => !exceptionSet.has(match.toLowerCase()));
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds as required.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a regex to match the token only when it follows a digit and is not at the start
  // This regex captures the digit along with the token
  const regex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Return unique matches (deduplicate)
  return [...new Set(matches)];
}

/**
 * Validates passwords according to these requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{}~]/.test(value)) return false;
  
  // Check for immediate repeated sequences
  // This pattern matches sequences where a substring is immediately repeated
  // like abab, abcabc, 123123, etc.
  const repeatedSequenceRegex = /(.{2,})\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  // Additional check for alternating characters
  // Matches ababab patterns where a and b are consecutive or alternating characters
  // Only check for very specific patterns that indicate weak passwords
  const alternatingCharsRegex = /(.)(.)\1\2/;
  // Only fail if it's a clear alternating pattern that's not part of a larger complex password
  if (alternatingCharsRegex.test(value) && value.length <= 8) return false;
  
  // Additional check for simple patterns like qwerty, 12345, etc.
  // Only reject if the password is exactly these patterns, not if they're part of a stronger password
  const commonPatterns = ['qwerty', '12345', 'password', 'qwertyuiop', 'asdfghjkl'];
  const lcValue = value.toLowerCase();
  
  // Only reject if the password is exactly a common pattern
  if (commonPatterns.includes(lcValue)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // First, isolate potential IP addresses by looking for patterns with colons and digits
  // IPv4 addresses contain periods and numbers but no colons
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    // If we found a pure IPv4 address, we need to check if it's part of an IPv6 address
    // For IPv4-mapped IPv6 addresses like ::ffff:192.168.1.1
    const ipv6WithIPv4Regex = /\b(?:\[?)?(?:[0-9a-fA-F]{1,4}:){1,7}:(?:\d{1,3}\.){3}\d{1,3}\b/;
    if (ipv6WithIPv4Regex.test(value)) {
      return true; // It's an IPv6 address with an IPv4 component
    }
  }
  
  // IPv6 addressing patterns:
  // 1. Standard format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. Shortened with :: (consecutive zeros)
  // 3. Mixed with letters and numbers
  
  // More specific IPv6 regex that won't mistake IPv4 addresses
  
  // More specific IPv6 regex that won't mistake IPv4 addresses
  const ipv6SpecificRegex = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){0,6}:[0-9a-fA-F]{1,4}\b|\b::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Test for IPv6 pattern
  return ipv6SpecificRegex.test(value);
}