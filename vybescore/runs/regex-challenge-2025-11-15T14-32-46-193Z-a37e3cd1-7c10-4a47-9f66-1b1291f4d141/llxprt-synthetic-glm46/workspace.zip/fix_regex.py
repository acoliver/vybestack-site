import re

# Fix transformations.ts
with open('src/transformations.ts', 'r') as f:
    content = f.read()
    
# Replace the problematic line
content = re.sub(r'url\.replace\(/\[\.!?,;:\)\\\}\]\+\$/', "url.replace(/[.!?,;:)\}]+$/", content)

with open('src/transformations.ts', 'w') as f:
    f.write(content)

# Fix validators.ts
with open('src/validators.ts', 'r') as f:
    content = f.read()
    
# Replace the problematic line
content = re.sub(r'cleanedValue = value\.replace\(/\[\\\s\-\(\)\]/g', "cleanedValue = value.replace(/[\\s\\-\\(\\)]/g", content)

with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed regex escaping issues")