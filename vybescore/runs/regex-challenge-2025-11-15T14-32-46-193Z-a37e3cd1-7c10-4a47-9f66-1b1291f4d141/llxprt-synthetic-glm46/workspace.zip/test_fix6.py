#!/usr/bin/env python3

# Read transformations.ts
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Replace the problematic string with literal values
content = content.replace('\\}+', '}+')

# Write back to transformations.ts
with open('src/transformations.ts', 'w') as f:
    f.write(content)

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Replace the problematic string with literal values
content = content.replace('\\s\\-\\(', '\\s\\-\\(')
content = content.replace('\\)\\]', ')]')

# Write back to validators.ts
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed regex escaping issues using simple string replacement")