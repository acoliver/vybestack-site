#!/usr/bin/env python3

import re

# Read transformations.ts
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Replace using character-by-character approach
lines = content.split('\n')
for i, line in enumerate(lines):
    if 'return url.replace(' in line and '],' in line and ');' in line:
        # Replace this line
        lines[i] = '    return url.replace(/[.!?,;:)\}]+$/, \'\');'
        break

content = '\n'.join(lines)

# Write back
with open('src/transformations.ts', 'w') as f:
    f.write(content)

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Replace using character-by-character approach
lines = content.split('\n')
for i, line in enumerate(lines):
    if 'cleanedValue = value.replace(' in line and '[\\s' in line:
        # Replace this line
        lines[i] = '  const cleanedValue = value.replace(/[\\s\\-\\(\\)]/g, \'\');'
        break

content = '\n'.join(lines)

# Write back
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed regex escaping issues using line-based replacement")