#!/usr/bin/env python3

# Read transformations.ts
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Replace the problematic string with literal values
content = content.replace('\\}+', '}+')

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    content = content.replace('\\s\\-\\(', '\\s\\-\\(')

print("Fixed regex escaping issues using simple string replacement")