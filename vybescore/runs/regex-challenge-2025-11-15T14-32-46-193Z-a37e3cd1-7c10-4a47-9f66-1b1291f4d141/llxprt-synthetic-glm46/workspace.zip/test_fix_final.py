#!/usr/bin/env python3

# Read transformations.ts
with open('src/transformations.ts', 'rb') as f:
    content_bytes = f.read()

# Convert bytes to string for processing and examine the actual bytes at line 74
content = content_bytes.decode('utf-8')
lines = content.split('\n')
line74 = lines[73]  # 0-indexed
print(f"Line 74 length: {len(line74)}")
print(f"Line 74 hex: {[hex(ord(c)) for c in line74]}")

# The issue is that even though we're removing double backslashes, there must be a literal backslash in the file
# Let's check what we're actually dealing with
if '\\\\}' in line74:
    print("Found double backslash before }")
    line74 = line74.replace('\\\\}', '}')
elif '\\}' in line74:
    print("Found single backslash before }")
    line74 = line74.replace('\\}', '}')

print(f"Fixed line 74: {line74}")
lines[73] = line74
content = '\n'.join(lines)

# Write back to transformations.ts
with open('src/transformations.ts', 'wb') as f:
    f.write(content.encode('utf-8'))

# Read validators.ts
with open('src/validators.ts', 'rb') as f:
    content_bytes = f.read()

content = content_bytes.decode('utf-8')
lines = content.split('\n')
line69 = lines[68]  # 0-indexed
print(f"Line 69 length: {len(line69)}")
print(f"Line 69 hex: {[hex(ord(c)) for c in line69]}")

# Check for literal backslashes
if '\\\\(' in line69:
    print("Found double backslash before (")
    line69 = line69.replace('\\\\(', '(')
elif '\\(' in line69:
    print("Found single backslash before (")
    line69 = line69.replace('\\(', '(')

if '\\\\)' in line69:
    print("Found double backslash before )")
    line69 = line69.replace('\\\\)', ')')
elif '\\)' in line69:
    print("Found single backslash before )")
    line69 = line69.replace('\\)', ')')

print(f"Fixed line 69: {line69}")
lines[68] = line69
content = '\n'.join(lines)

# Write back to validators.ts
with open('src/validators.ts', 'wb') as f:
    f.write(content.encode('utf-8'))

print("Fixed regex escaping issues by removing literal backslashes")