#!/usr/bin/env python3

# Read transformations.ts
with open('src/transformations.ts', 'r') as f:
    content = f.read()
    print("Found \\} characters:", content.count('\\}'))

# Replace ALL escaped backslashes with single backslashes
content = content.replace('\\\\', '\\')

# Write back to transformations.ts
with open('src/transformations.ts', 'w') as f:
    f.write(content)

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    content = f.read()
    print("Found \\( characters:", content.count('\\('))
    print("Found \\) characters:", content.count('\\)'))

# Replace ALL escaped backslashes with single backslashes
content = content.replace('\\\\', '\\')

# Write back to validators.ts
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed regex escaping issues by removing all double backslashes")