#!/usr/bin/env python3

import re

# Read transformations.ts
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Replace the problematic line using a more robust regex pattern
# Match the exact line and replace it
content = re.sub(
    r'return url\.replace\(/\[\.!?,;:\)\\\\\}]\+\$/, \'\'\);',
    'return url.replace(/[.!?,;:)\}]+$/, \'\');',
    content
)

# Also try in case there are escaped quotes
content = re.sub(
    r'return url\.replace\(/\[\.!?,;:\)\\\\\}]\+\$/, \\"\\");',
    'return url.replace(/[.!?,;:)\}]+$/, \'\');',
    content
)

# Write back
with open('src/transformations.ts', 'w') as f:
    f.write(content)

# Read validators.ts
with open('src/validators.ts', 'r') as f:
    content = f.read()

# Replace the problematic line using regex pattern
content = re.sub(
    r'cleanedValue = value\.replace\(/\[\\\\s\-\(\)\]/g, \'\'\);',
    'cleanedValue = value.replace(/[\\s\\-\\(\\)]/g, \'\');',
    content
)

# Write back
with open('src/validators.ts', 'w') as f:
    f.write(content)

print("Fixed regex escaping issues using patterns")