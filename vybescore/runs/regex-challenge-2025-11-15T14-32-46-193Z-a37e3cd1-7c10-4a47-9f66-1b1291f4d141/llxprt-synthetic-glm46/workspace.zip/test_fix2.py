#!/usr/bin/env python3

import re
import os

# Read and print transformations.ts line 74 in character detail
with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()
    line74 = lines[73]  # 0-indexed
    print(f"Transformations line 74 length: {len(line74)}")
    print(f"Transformations line 74 chars: {[c for c in line74]}")
    print(f"Transformations line 74 hex: {[hex(ord(c)) for c in line74]}")
    
# Create a completely new line with proper format
new_line74 = '    return url.replace(/[.!?,;:)\}]+$/, \'\');\n'
print(f"New line: {new_line74}")
print(f"New line hex: {[hex(ord(c)) for c in new_line74]}")

lines[73] = new_line74

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

# Same for validators.ts
with open('src/validators.ts', 'r') as f:
    lines = f.readlines()
    line69 = lines[68]  # 0-indexed
    print(f"Validators line 69 length: {len(line69)}")
    print(f"Validators line 69 chars: {[c for c in line69]}")
    print(f"Validators line 69 hex: {[hex(ord(c)) for c in line69]}")
    
# Create a completely new line with proper format
new_line69 = '  const cleanedValue = value.replace(/[\\s\\-\\(\\)]/g, \'\');\n'
print(f"New line: {new_line69}")
print(f"New line hex: {[hex(ord(c)) for c in new_line69]}")

lines[68] = new_line69

with open('src/validators.ts', 'w') as f:
    f.writelines(lines)

print("Fixed regex escaping issues with complete line replacement")