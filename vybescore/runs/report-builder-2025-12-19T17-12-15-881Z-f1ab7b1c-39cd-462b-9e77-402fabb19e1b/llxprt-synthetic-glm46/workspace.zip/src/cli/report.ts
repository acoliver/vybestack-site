#!/usr/bin/env node

import { readFileSync, writeFileSync } from "node:fs";
import { ReportData, RenderOptions, Format } from "../types.js";
import { markdownRenderer } from "../formats/markdown.js";
import { textRenderer } from "../formats/text.js";

function parseArguments(): {
  filePath: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      "Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]"
    );
    process.exit(1);
  }

  const filePath = args[0];
  const formatIndex = args.indexOf("--format");

  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error("Error: --format flag is required");
    process.exit(1);
  }

  const formatValue = args[formatIndex + 1] as Format;

  if (formatValue !== "markdown" && formatValue !== "text") {
    console.error("Error: Unsupported format");
    process.exit(1);
  }

  const outputIndex = args.indexOf("--output");
  const outputPath =
    outputIndex !== -1 && outputIndex < args.length - 1
      ? args[outputIndex + 1]
      : undefined;

  const includeTotals = args.includes("--includeTotals");

  return {
    filePath,
    format: formatValue,
    outputPath,
    includeTotals,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, "utf8");
    const data = JSON.parse(content) as ReportData;

    // Validate data structure
    if (
      !data ||
      typeof data.title !== "string" ||
      typeof data.summary !== "string" ||
      !Array.isArray(data.entries) ||
      !data.entries.every(
        (entry) =>
          typeof entry === "object" &&
          entry !== null &&
          typeof entry.label === "string" &&
          typeof entry.amount === "number"
      )
    ) {
      throw new Error("Invalid report data structure");
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}`);
    } else {
      console.error(`Error: ${(error as Error).message}`);
    }
    process.exit(1);
  }
}

function renderReport(
  data: ReportData,
  format: Format,
  options: RenderOptions
): string {
  switch (format) {
    case "markdown":
      return markdownRenderer.render(data, options);
    case "text":
      return textRenderer.render(data, options);
    default:
      console.error("Error: Unsupported format");
      process.exit(1);
  }
}

function main() {
  try {
    const { filePath, format, outputPath, includeTotals } = parseArguments();

    const data = loadReportData(filePath);
    const options: RenderOptions = { includeTotals };
    const output = renderReport(data, format, options);

    if (outputPath) {
      writeFileSync(outputPath, output, "utf8");
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }
}

main();