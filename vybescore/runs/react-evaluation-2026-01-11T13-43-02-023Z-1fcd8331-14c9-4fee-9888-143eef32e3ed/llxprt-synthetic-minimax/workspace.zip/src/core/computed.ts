/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  setActiveComputation,
  executeComputation,
  Signal,
  Computation
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean,
  _options?: { name?: string }
): GetterFn<T> {
  const computation: Computation = {
    fn: updateFn as any,
    value,
    signals: new Set<Signal<unknown>>(),
    read: function() {
      return executeComputation(computation)
    },
    execute: function() {
      const previous = setActiveComputation(this)
      try {
        const result = this.fn(this.value)
        this.value = result
        return result
      } finally {
        setActiveComputation(previous)
      }
    },
    unsubscribe: function() {
      if (this.signals) {
        this.signals.forEach(signal => {
          signal.removeComputation(this)
        })
        this.signals.clear()
      }
    }
  }

  const getter: GetterFn<T> = () => {
    // Establish dependency tracking context
    const result = executeComputation(computation)
    return result as T
  }

  return getter
}
