/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getActiveComputation,
  executeComputation,
  linkSignalAndComputation,
  Signal,
  Computation
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value
  
  const signal: Signal<T> = {
    value: currentValue,
    computations: new Set<Computation>(),
    read: function() {
      const computation = getActiveComputation()
      if (computation) {
        this.computations.add(computation)
        linkSignalAndComputation(this, computation)
        // Track signal in computation for cleanup
        computation.signals.add(this)
      }
      return this.value
    },
    write: function(newValue: T) {
      if (this.value === newValue) {
        return this.value
      }
      this.value = newValue
      currentValue = newValue
      
      // Notify all computations that depend on this signal
      this.computations.forEach(computation => {
        executeComputation(computation)
      })
      
      return this.value
    },
    addComputation: function(computation: Computation) {
      this.computations.add(computation)
    },
    removeComputation: function(computation: Computation) {
      this.computations.delete(computation)
    },
    notify: function() {
      this.computations.forEach(computation => {
        executeComputation(computation)
      })
    }
  }

  const read: GetterFn<T> = () => {
    return signal.read()
  }

  const write: SetterFn<T> = (nextValue) => {
    return signal.write(nextValue)
  }

  return [read, write]
}
