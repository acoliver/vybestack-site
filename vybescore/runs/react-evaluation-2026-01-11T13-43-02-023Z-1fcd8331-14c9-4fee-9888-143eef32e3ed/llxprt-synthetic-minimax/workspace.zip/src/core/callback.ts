/**
 * Callback closure implementation for reactive side effects.
 */

import {
  UnsubscribeFn,
  UpdateFn,
  setActiveComputation,
  executeComputation,
  Signal,
  Computation
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const computation: Computation = {
    fn: updateFn as any,
    value,
    signals: new Set<Signal<unknown>>(),
    read: function() {
      return executeComputation(computation)
    },
    execute: function() {
      const previous = setActiveComputation(this)
      try {
        const result = this.fn(this.value)
        this.value = result
        return result
      } finally {
        setActiveComputation(previous)
      }
    },
    unsubscribe: function() {
      this.signals.forEach(signal => {
        signal.removeComputation(this)
      })
      this.signals.clear()
    }
  }

  // Execute to establish dependencies and get initial value
  computation.execute()

  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear dependencies to prevent memory leaks
    computation.unsubscribe()
  }
}
