/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export interface Options {
  name?: string // for debugging
}

// Core reactive system
let activeComputation: Computation | null = null

export function getActiveComputation(): Computation | null {
  return activeComputation
}

export function setActiveComputation(computation: Computation | null): Computation | null {
  const previous = activeComputation
  activeComputation = computation
  return previous
}

export interface Signal<T> {
  value: T
  computations: Set<Computation>
  read(): T
  write(value: T): T
  addComputation(computation: Computation): void
  removeComputation(computation: Computation): void
  notify(): void
}

export interface Computation {
  fn: UpdateFn<unknown>
  value?: unknown
  signal?: Signal<unknown>
  signals: Set<Signal<unknown>>
  read(): unknown
  execute(): unknown
  unsubscribe(): void
}

export function executeComputation(computation: Computation): unknown {
  const previous = setActiveComputation(computation)
  try {
    const result = computation.fn(computation.value)
    computation.value = result
    return result
  } finally {
    setActiveComputation(previous)
  }
}

export function linkSignalAndComputation<T>(signal: Signal<T>, computation: Computation): void {
  signal.addComputation(computation)
}

export function notifySignal<T>(signal: Signal<T>): void {
  signal.notify()
}
