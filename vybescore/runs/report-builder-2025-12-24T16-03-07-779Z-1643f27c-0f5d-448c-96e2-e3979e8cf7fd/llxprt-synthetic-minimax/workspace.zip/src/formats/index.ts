import { renderMarkdown } from "./markdown.js";
import { renderText } from "./text.js";

export const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

export type FormatName = keyof typeof formatters;
