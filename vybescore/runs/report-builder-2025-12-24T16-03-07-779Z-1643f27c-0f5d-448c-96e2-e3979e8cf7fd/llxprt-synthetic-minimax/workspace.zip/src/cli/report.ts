import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CliOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): { dataFile: string; options: CliOptions } {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  const options: CliOptions = {
    format: 'markdown',
    includeTotals: false,
  };

  // Parse remaining arguments
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const format = args[i + 1];
      if (!format || (format !== 'markdown' && format !== 'text')) {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      options.format = format as 'markdown' | 'text';
      i++; // Skip next argument since it's the format value
    } else if (arg === '--output') {
      const outputPath = args[i + 1];
      if (!outputPath) {
        console.error('Error: --output requires a file path');
        process.exit(1);
      }
      options.output = outputPath;
      i++; // Skip next argument since it's the output path
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument "${arg}"`);
      process.exit(1);
    }
  }

  return { dataFile, options };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Report data must be a valid JSON object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be a string)');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i] as Record<string, unknown>;
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Entry ${i} must be a valid object`);
    }

    if (typeof entry.label !== 'string') {
      throw new Error(`Entry ${i} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
      throw new Error(`Entry ${i} missing or invalid "amount" field (must be a number)`);
    }
  }

  return true;
}

function formatReport(data: ReportData, options: CliOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv);
    
    // Read and parse JSON data file
    let rawData: unknown;
    try {
      const fileContent = readFileSync(dataFile, 'utf-8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${dataFile}": ${error.message}`);
      } else if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        console.error(`Error: File "${dataFile}" not found`);
      } else {
        console.error(`Error reading file "${dataFile}": ${error}`);
      }
      process.exit(1);
    }

    // Validate report data
    try {
      validateReportData(rawData);
    } catch (error) {
      console.error(`Error: ${error}`);
      process.exit(1);
    }

    const reportData = rawData as ReportData;

    // Generate formatted report
    let formattedOutput: string;
    try {
      formattedOutput = formatReport(reportData, options);
    } catch (error) {
      console.error(`Error: ${error}`);
      process.exit(1);
    }

    // Write output
    if (options.output) {
      try {
        writeFileSync(options.output, formattedOutput, 'utf-8');
      } catch (error) {
        console.error(`Error writing to file "${options.output}": ${error}`);
        process.exit(1);
      }
    } else {
      console.log(formattedOutput);
    }

  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

main();
