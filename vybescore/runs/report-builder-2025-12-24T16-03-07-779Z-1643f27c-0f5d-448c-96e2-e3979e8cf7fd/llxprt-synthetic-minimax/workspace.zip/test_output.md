# Quarterly Financial Summary

Highlights include record revenue growth across all regions with Q4 showing exceptional performance.

## Entries
- **North Region** — $12345.67
- **South Region** — $23456.78
- **West Region** — $34567.89