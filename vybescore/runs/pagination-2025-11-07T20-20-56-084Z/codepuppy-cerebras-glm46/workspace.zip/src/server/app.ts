import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      if (pageParam === '' || isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'Page parameter must be a valid number' });
      }
      page = Number(pageParam);
      if (page <= 0) {
        return res.status(400).json({ error: 'Page parameter must be greater than 0' });
      }
      if (page > 1000) {
        return res.status(400).json({ error: 'Page parameter cannot exceed 1000' });
      }
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      if (limitParam === '' || isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'Limit parameter must be a valid number' });
      }
      limit = Number(limitParam);
      if (limit <= 0) {
        return res.status(400).json({ error: 'Limit parameter must be greater than 0' });
      }
      if (limit > 100) {
        return res.status(400).json({ error: 'Limit parameter cannot exceed 100' });
      }
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
