import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Database } from 'sql.js';
import type { Express } from 'express';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns pagination metadata', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('defaults to page 1 and limit 5', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items[0].id).toBe(1);
  });

  it('respects custom page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(3);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items[0].id).toBe(4);
  });

  it('calculates hasNext correctly', async () => {
    const response1 = await request(app).get('/inventory?page=3&limit=5');
    expect(response1.status).toBe(200);
    expect(response1.body.hasNext).toBe(false);

    const response2 = await request(app).get('/inventory?page=2&limit=5');
    expect(response2.status).toBe(200);
    expect(response2.body.hasNext).toBe(true);
  });

  it('rejects non-numeric page parameter', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page parameter must be a valid number');
  });

  it('rejects non-numeric limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit parameter must be a valid number');
  });

  it('rejects zero or negative page parameter', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page parameter must be greater than 0');
  });

  it('rejects zero or negative limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit parameter must be greater than 0');
  });

  it('rejects excessive page parameter', async () => {
    const response = await request(app).get('/inventory?page=1001');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Page parameter cannot exceed 1000');
  });

  it('rejects excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Limit parameter cannot exceed 100');
  });

  it('returns empty items for page beyond data', async () => {
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.hasNext).toBe(false);
  });

  it('handles pagination with different limits', async () => {
    // Test with limit 10
    const response1 = await request(app).get('/inventory?limit=10');
    expect(response1.status).toBe(200);
    expect(response1.body.items.length).toBe(10);
    expect(response1.body.page).toBe(1);
    expect(response1.body.hasNext).toBe(true);

    // Test second page with limit 10
    const response2 = await request(app).get('/inventory?page=2&limit=10');
    expect(response2.status).toBe(200);
    expect(response2.body.items.length).toBe(5);
    expect(response2.body.page).toBe(2);
    expect(response2.body.hasNext).toBe(false);
  });
});
