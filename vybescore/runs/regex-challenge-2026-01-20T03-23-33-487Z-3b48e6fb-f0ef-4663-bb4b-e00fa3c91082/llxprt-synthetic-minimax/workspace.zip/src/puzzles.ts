// Regex puzzle functions

export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // We'll match whole words using word boundaries
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const filtered = matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseMatch === exception.toLowerCase()
    );
  });
  
  // Remove duplicates and return
  return [...new Set(filtered)];
}

export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token occurrences after a digit:
  // - Capture digit followed by token (using capturing groups)
  // - Match whole tokens using word boundaries
  const pattern = new RegExp(`(\\d)(${token}\\b)`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  // Use regex to find all positions where digit+token occurs
  while ((match = pattern.exec(text)) !== null) {
    // match[0] contains the full digit+token string (e.g., "1foo")
    matches.push(match[0]);
  }
  
  return matches;
}

export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol - test individual character first
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':"\\|,.<>?]/.test(value);
  if (!hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 123123)
  // Look for patterns that repeat immediately
  for (let i = 0; i < value.length - 3; i++) {
    const sequence = value.substring(i, i + 2);
    const nextSequence = value.substring(i + 2, i + 4);
    
    if (sequence === nextSequence) {
      return false;
    }
  }
  
  // Also check for any 4-character pattern that repeats immediately
  for (let i = 0; i < value.length - 5; i++) {
    const pattern = value.substring(i, i + 4);
    const nextPattern = value.substring(i + 4, i + 8);
    
    if (pattern === nextPattern) {
      return false;
    }
  }
  
  return true;
}

export function containsIPv6(value: string): boolean {
  // Pattern to match IPv6 addresses (including shorthand ::)
  // This is a simplified pattern that catches most IPv6 formats
  
  // IPv6 addresses contain colons and hex digits
  // They can use shorthand notation with ::
  // We'll exclude pure IPv4 patterns
  
  // First check if it's a pure IPv4 address
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // IPv6 patterns:
  // 1. Standard IPv6 with hex digits and colons
  // 2. IPv6 with shorthand notation (::)
  // 3. IPv6 with embedded IPv4 (less common but valid)
  
  const ipv6Patterns = [
    // Standard IPv6 format (8 groups of 4 hex digits)
    /\b[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}\b/,
    
    // IPv6 with shorthand notation (::)
    /\b[0-9a-fA-F]*::[0-9a-fA-F]*\b/,
    
    // IPv6 with mixed notation
    /\b[0-9a-fA-F:]+::[0-9a-fA-F:]+\b/,
    
    // IPv6 with abbreviated groups (variable length)
    /\b[0-9a-fA-F]{0,4}(:[0-9a-fA-F]{0,4}){2,7}\b/
  ];
  
  // Check if it's purely IPv4 (and not mixed IPv6/IPv4)
  if (ipv4Pattern.test(value)) {
    // If it's purely IPv4 (no colons in the address part), return false
    const ipv4Only = value.match(/^[\d.]+$/);
    if (ipv4Only) {
      return false;
    }
  }
  
  // Check for IPv6 patterns
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  // Additional check: IPv6 addresses contain colons and hex digits
  // But not pure IPv4 patterns
  const hasColons = value.includes(':');
  const hasHexDigits = /[0-9a-fA-F]/.test(value);
  const isPureIPv4 = /^[\d.]+$/.test(value);
  
  if (hasColons && hasHexDigits && !isPureIPv4) {
    return true;
  }
  
  return false;
}
