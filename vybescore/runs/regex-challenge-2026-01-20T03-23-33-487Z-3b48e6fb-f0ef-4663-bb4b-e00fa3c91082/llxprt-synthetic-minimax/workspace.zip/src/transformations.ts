// Text transformation functions using regex patterns

export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // Split on sentence endings, but be smart about abbreviations
  // We'll capitalize after sentence endings and collapse extra spaces
  
  // First, normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Capitalize first character of the string
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence endings (.?!)
  // Use regex to find sentence endings followed by any amount of whitespace
  normalized = normalized.replace(/([.?!])([\s]*)([a-z])/g, (match, sentenceEnd, whitespace, letter) => {
    return sentenceEnd + whitespace + letter.toUpperCase();
  });
  
  return normalized;
}

export function extractUrls(text: string): string[] {
  // Pattern to match URLs without trailing punctuation
  // Basic HTTP/HTTPS URLs with optional paths
  const urlPattern = /(https?:\/\/[^\s.,;:!?)]*\.[^\s.,;:!?)]*(?=\s|$|[.,;:!?)]))/gi;
  
  const matches = text.match(urlPattern);
  return matches || [];
}

export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave existing https:// untouched
  const pattern = /http:\/\//gi;
  return text.replace(pattern, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with http scheme - capture host and path
  const urlPattern = /http:\/\/([a-zA-Z0-9.-]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    let result = 'https://';
    
    // Default rewritten host
    let rewrittenHost = host;
    
    // Default path
    const pathname = path || '';
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (pathname && pathname.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /[?&=]/.test(pathname) || /cgi-bin/.test(pathname);
      const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(pathname);
      
      if (!hasDynamicHints && !hasLegacyExtensions) {
        // Rewrite host to docs.domain
        rewrittenHost = `docs.${host}`;
      }
    }
    
    result += rewrittenHost;
    result += pathname;
    
    return result;
  });
}

export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^([01]?[0-9])\/([0-3]?[0-9])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  // Basic check for impossible dates
  if ((monthNum === 4 || monthNum === 6 || monthNum === 9 || monthNum === 11) && dayNum > 30) {
    return 'N/A';
  }
  
  if (monthNum === 2 && dayNum > 29) {
    return 'N/A';
  }
  
  // Return the four-digit year
  return year;
}
