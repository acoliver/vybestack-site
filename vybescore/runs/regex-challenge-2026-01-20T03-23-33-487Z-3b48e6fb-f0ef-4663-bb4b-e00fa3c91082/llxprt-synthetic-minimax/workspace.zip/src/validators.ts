// Validation functions using regex patterns

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}

export function isValidEmail(value: string): boolean {
  // Pattern for valid email addresses
  // Local part: letters, numbers, underscores, dots, hyphens, plus signs
  // Domain part: letters, numbers, dots, hyphens
  // No double dots, no trailing dots, no domains with underscores
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Additional validation to reject specific invalid cases
  const invalidPatterns = [
    /\.\./,           // Double dots
    /\.@/,            // Dot before @ at local part
    /@.*\.\./,        // Double dots after @
    /@.*\.$/,         // Trailing dot
    /@.*__/,          // Underscores in domain
    /\.$/,            // Trailing dot
    /\.\./            // Double dots anywhere
  ];
  
  // Must match basic pattern first
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Must not contain any invalid patterns
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  // Split to check for underscores in domain
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const domain = parts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must not start or end with dot
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

export function isValidUSPhone(value: string): boolean {
  // Remove all non-numeric characters except potential leading +
  const clean = value.trim();
  
  // Pattern for US phone numbers
  // Optional +1, various separators, area code cannot start with 0 or 1
  const phonePattern = /^(?:\+1\s*)?(?:\(?([2-9][0-8][0-9])\)?[-\s.]?)?([2-9][0-9]{2})[-\s.]?([0-9]{4})$/;
  
  const match = clean.match(phonePattern);
  
  if (!match) {
    return false;
  }
  
  // Extract the three parts of the number
  const [, areaCode] = match;
  
  // Area code cannot be empty and must be 3 digits starting 2-9
  if (!areaCode || areaCode.length !== 3) {
    return false;
  }
  
  // Area code first digit must be 2-9 (not 0 or 1)
  if (areaCode.charAt(0) < '2' || areaCode.charAt(0) > '9') {
    return false;
  }
  
  // Total length should be reasonable (10 digits excluding country code)
  const digitsOnly = clean.replace(/\D/g, '');
  
  // Allow with or without country code
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // With country code
    return true;
  } else if (digitsOnly.length === 10) {
    // Without country code
    return true;
  }
  
  return false;
}

export function isValidArgentinePhone(value: string): boolean {
  const clean = value.trim().replace(/[\s().-]/g, '');
  
  // Pattern to match Argentine phone numbers
  // Optional +54, optional 9 (mobile), area code 2-4 digits, subscriber 6-8 digits
  const pattern = /^(?:\+54)?(?:0)?(?:9)?([2-9][0-9]{1,3})([0-9]{6,8})$/;
  
  const match = clean.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (areaCode.charAt(0) < '1' || areaCode.charAt(0) > '9') {
    return false;
  }
  
  // Validate subscriber number (total 6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must have trunk prefix 0
  if (!clean.startsWith('+54') && !clean.startsWith('54')) {
    // No country code - should have trunk prefix 0
    if (!value.trim().startsWith('0')) {
      return false;
    }
  }
  
  return true;
}

export function isValidName(value: string): boolean {
  // Pattern for valid names
  // Unicode letters (including accents), apostrophes, hyphens, spaces
  // Reject digits and symbols
  const namePattern = /^[\p{L}][\p{L}\p{M}'\-\s]*[\p{L}\p{M}]$/u;
  
  // Must not contain digits or special symbols (except apostrophes, hyphens, spaces)
  const invalidPattern = /[\d!@#$%^&*()_+=[\]{}|;:'",.<>?/`~]/;
  
  // Must start and end with a letter
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Check for invalid characters
  if (invalidPattern.test(value)) {
    return false;
  }
  
  // Must not be empty or just spaces
  if (value.trim().length === 0) {
    return false;
  }
  
  // Should not be a futuristic name like "X Æ A-12"
  const futuristicPattern = /[ÆØÅ]/;
  if (futuristicPattern.test(value)) {
    return false;
  }
  
  return true;
}

export function isValidCreditCard(value: string): boolean {
  const clean = value.replace(/\s/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(clean)) {
    return false;
  }
  
  // Check length patterns (Visa: 13/16, MasterCard: 16, AmEx: 15)
  const patterns = [
    /^4\d{12}(\d{3})?$/,        // Visa
    /^5[1-5]\d{14}$/,           // MasterCard
    /^3[47]\d{13}$/             // AmEx
  ];
  
  let validFormat = false;
  for (const pattern of patterns) {
    if (pattern.test(clean)) {
      validFormat = true;
      break;
    }
  }
  
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(clean);
}
