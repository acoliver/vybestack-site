#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { Formatter, ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataPath: '',
    format: '',
    includeTotals: false
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      args.format = argv[i + 1] || '';
      i++;
    } else if (arg === '--output') {
      args.outputPath = argv[i + 1] || '';
      i++;
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      args.dataPath = arg;
    }
  }

  return args;
}

function validateData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const typedData = data as Record<string, unknown>;
  
  if (typeof typedData.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }
  
  if (typeof typedData.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }
  
  if (!Array.isArray(typedData.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }
  
  for (let i = 0; i < typedData.entries.length; i++) {
    const entry = typedData.entries[i] as Record<string, unknown>;
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
  
  return true;
}

function loadData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    validateData(data);
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        throw new Error(`File not found: ${filePath}`);
      }
      if (error.message.startsWith('Invalid JSON')) {
        throw error;
      }
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw new Error(`Failed to parse JSON: ${String(error)}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    if (!args.dataPath) {
      throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    }
    
    if (!args.format) {
      throw new Error('Usage: --format option is required (markdown or text)');
    }
    
    if (args.format !== 'markdown' && args.format !== 'text') {
      throw new Error(`Unsupported format: ${args.format}`);
    }
    
    const data = loadData(args.dataPath);
    
    const formatters: Record<string, Formatter> = {
      markdown: renderMarkdown,
      text: renderText
    };
    
    const formatter = formatters[args.format];
    const output = formatter.format(data, args.includeTotals);
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
