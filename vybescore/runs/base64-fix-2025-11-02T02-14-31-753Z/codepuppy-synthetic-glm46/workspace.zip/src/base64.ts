/**
 * Encode plain text to canonical Base64 (RFC 4648).
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode canonical Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws errors for invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove any whitespace characters (common in multi-line Base64)
  const cleanedInput = input.replace(/\s/g, '');

  // Validate Base64 format - only allow characters A-Z, a-z, 0-9, +, /, =
  const validBase64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!validBase64Regex.test(cleanedInput)) {
    // Check if it's just too much padding vs truly invalid characters
    if (/^[A-Za-z0-9+/]+=*$/.test(cleanedInput)) {
      throw new Error('Invalid Base64 input: too many padding characters');
    } else {
      throw new Error('Invalid Base64 input: contains illegal characters');
    }
  }

  // Check padding validity
  const paddingIndex = cleanedInput.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingPart = cleanedInput.substring(paddingIndex);
    if (!/^=+$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: padding characters not at the end');
    }
    
    // Check if padding length is valid (1 or 2 characters) - this is redundant due to regex but kept for clarity
    const paddingLength = paddingPart.length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // The total length (including padding) must be a multiple of 4
    if ((cleanedInput.length) % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length for padding');
    }
  } else {
    // No padding - length must be a multiple of 4, or we can add padding
    if (cleanedInput.length % 4 !== 0) {
      // Add missing padding for decoding
      const paddedInput = cleanedInput + '='.repeat(4 - (cleanedInput.length % 4));
      try {
        return Buffer.from(paddedInput, 'base64').toString('utf8');
      } catch (error) {
        throw new Error('Failed to decode Base64 input: invalid format');
      }
    }
  }

  try {
    return Buffer.from(cleanedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
