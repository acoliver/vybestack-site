export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: Array<keyof FormData> = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const value = (data[field] || '').trim();
    if (!value) {
      errors.push({
        field,
        message: `${field.replace('_', ' ').replace(/\b\w/g, l => l.toUpperCase())} is required`
      });
    }
  });

  // Email validation
  if (data.email && data.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone validation
  if (data.phone && data.phone.trim()) {
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation (allow alphanumeric)
  if (data.postal_code && data.postal_code.trim()) {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(data.postal_code.trim())) {
      errors.push({
        field: 'postal_code',
        message: 'Please enter a valid postal code'
      });
    }
  }

  return errors;
}

export function hasErrors(errors: ValidationError[], field: string): boolean {
  return errors.some(error => error.field === field);
}

export function getErrorMessage(errors: ValidationError[], field: string): string | null {
  const error = errors.find(error => error.field === field);
  return error ? error.message : null;
}