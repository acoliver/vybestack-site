import initSqlJs, { Database as SqlJsDatabase } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

export class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private dbPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      let sqlBuffer: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        sqlBuffer = new Uint8Array(fileBuffer);
      }

      this.db = sqlBuffer 
        ? new SQL.Database(sqlBuffer)
        : new SQL.Database();

      // Initialize schema if needed
      this.initializeSchema();
      
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private initializeSchema(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      this.db.exec(schema);
    }
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone
      ]);

      // Get the last insert ID
      const result = this.db.exec("SELECT last_insert_rowid() as id");
      const id = result[0]?.values[0]?.[0] as number || 0;

      await this.save();
      return id;
    } finally {
      stmt.free();
    }
  }

  async getSubmission(id: number): Promise<Submission | null> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      SELECT id, first_name, last_name, street_address, city, state_province,
             postal_code, country, email, phone, created_at
      FROM submissions WHERE id = ?
    `);

    try {
      stmt.run([id]);
      
      if (stmt.step()) {
        const row = stmt.getAsObject();
        return {
          id: row.id as number,
          first_name: row.first_name as string,
          last_name: row.last_name as string,
          street_address: row.street_address as string,
          city: row.city as string,
          state_province: row.state_province as string,
          postal_code: row.postal_code as string,
          country: row.country as string,
          email: row.email as string,
          phone: row.phone as string,
          created_at: row.created_at as string
        };
      }
      
      return null;
    } finally {
      stmt.free();
    }
  }

  async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}