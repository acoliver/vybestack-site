import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { DatabaseManager } from './database.js';
import { validateForm, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
const db = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Us - Friendly International Form',
    errors: [],
    formData: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);

    if (errors.length > 0) {
      // Validation failed - redisplay form with errors
      return res.status(400).render('form', {
        title: 'Contact Us - Please Fix Errors',
        errors,
        formData
      });
    }

    // Validation successful - insert into database
    await db.initialize(); // Ensure DB is initialized
    const submissionId = await db.insertSubmission(formData);
    
    console.log(`Successfully stored submission #${submissionId}`);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
    
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      title: 'Contact Us - Error',
      errors: [{ field: 'general', message: 'An error occurred while processing your submission. Please try again.' }],
      formData: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You - Definitely Not A Scam!'
  });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('Unhandled error:', err);
  try {
    res.status(500).send('Internal Server Error');
  } catch (sendError) {
    console.error('Failed to send error response:', sendError);
  }
});

// Graceful shutdown handling
const gracefulShutdown = async () => {
  console.log('Received shutdown signal, closing server...');
  
  try {
    await db.close();
    console.log('Database closed successfully');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer() {
  try {
    await db.initialize();
    
    app.listen(PORT, () => {
      console.log(` Friendly Form Capture server running on port ${PORT}`);
      console.log(` Visit http://localhost:${PORT} to access the contact form`);
      console.log(` Database will be saved to data/submissions.sqlite`);
      console.log(' Press Ctrl+C for graceful shutdown');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
