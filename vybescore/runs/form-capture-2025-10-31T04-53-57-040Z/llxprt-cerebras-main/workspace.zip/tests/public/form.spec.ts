import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

// Create paths relative to project root
const projectRoot = path.resolve(__dirname, '../');
const dbPath = path.resolve(projectRoot, 'data/submissions.sqlite');

let server: any;

beforeAll(async () => {
  // Import and start the actual server
  server = (await import('../../src/server')).default;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(server).get('/');
    expect(res.status).toBe(200);
    
    // Check that all form fields are present in the response
    expect(res.text).toContain('name="firstName"');
    expect(res.text).toContain('name="lastName"');
    expect(res.text).toContain('name="streetAddress"');
    expect(res.text).toContain('name="city"');
    expect(res.text).toContain('name="stateProvince"');
    expect(res.text).toContain('name="postalCode"');
    expect(res.text).toContain('name="country"');
    expect(res.text).toContain('name="email"');
    expect(res.text).toContain('name="phone"');
  });

  it('persists submission and redirects', async () => {
    const res = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'john@example.com',
        phone: '+1234567890'
      });
    
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/thank-you?firstName=John');
  });
});