import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
const dbPath = path.resolve(__dirname, '../data/submissions.sqlite');
let db: Database;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Initialize database
async function initDatabase() {
  const SQL = await initSqlJs();
  let dbData: Uint8Array | null = null;
  
  if (fs.existsSync(dbPath)) {
    dbData = fs.readFileSync(dbPath);
  }
  
  db = new SQL.Database(dbData);
  
  // Create table if not exists
  const schema = fs.readFileSync(path.resolve(__dirname, '../db/schema.sql'), 'utf8');
  db.run(schema);
}

// Form validation
function validateForm(data: FormData) {
  const errors: string[] = [];
  
  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1')} is required`);
    }
  });
  
  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Email must be valid');
  }
  
  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  if (data.phone && !/^[+]?[\d\s\-()]+$/.test(data.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  // Postal code validation (allow alphanumeric strings)
  if (data.postalCode && !/^[a-zA-Z0-9\s\-]+$/.test(data.postalCode)) {
    errors.push('Postal code format is invalid');
  }
  
  return errors;
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const errors = validateForm(req.body as FormData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: req.body
    });
  }
  
  // Insert into database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    req.body.firstName,
    req.body.lastName,
    req.body.streetAddress,
    req.body.city,
    req.body.stateProvince,
    req.body.postalCode,
    req.body.country,
    req.body.email,
    req.body.phone
  ]);
  
  // Write database back to file
  const data = db.export();
  fs.writeFileSync(dbPath, data);
  
  // Redirect to thank-you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(req.body.firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Initialize and start server
async function startServer() {
  await initDatabase();
  const server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  
  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    server.close(() => {
      // Close database connection
      if (db) {
        const data = db.export();
        fs.writeFileSync(dbPath, data);
        db.close();
      }
      console.log('Server closed');
      process.exit(0);
    });
  });
  
  return server;
}

// Start the server
const server = await startServer();

export default server;