import express from 'express';
import fs from 'fs';
import path from 'path';
import initSqlJs from 'sql.js';

// Define a proper interface for the SQL.js Database
interface Database {
  export(): Uint8Array;
  run(query: string, params?: unknown[]): void;
  exec(query: string): void;
  close(): void;
}

// Define a type for SQL value to fix database parameter errors
type SqlValue = string | number | boolean | null | undefined;

// Define a type for the SQL.js static
interface SqlJsStatic {
  Database: new (data?: Uint8Array) => Database;
}

// Import type for Request and Response
import { Request, Response } from 'express';

const app = express();
const port = process.env.PORT || 3535;
let db: Database | null = null;
const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
const publicPath = path.resolve(process.cwd(), 'public');
app.use(express.static(publicPath));

// Set up EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

// Initialize SQLite database
async function initializeDatabase(): Promise<Database> {
  try {
    const SQL: SqlJsStatic = await initSqlJs();
    
    let dbBuffer: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(dbFile);
    }
    
    const database = new SQL.Database(dbBuffer!);
    
    // Create the submissions table if it doesn't exist
    const schema = fs.readFileSync(path.resolve(process.cwd(), 'db', 'schema.sql'), 'utf8');
    database.exec(schema);
    
    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(database: Database): void {
  try {
    const data = database.export();
    const buffer = Buffer.from(data);
    
    if (!fs.existsSync(path.dirname(dbPath))) {
      fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    }
    
    fs.writeFileSync(dbPath, buffer);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Define interface for form data
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Validation functions
function validateFormData(formData: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields
  if (!formData.firstName?.trim()) errors.push('First name is required');
  if (!formData.lastName?.trim()) errors.push('Last name is required');
  if (!formData.streetAddress?.trim()) errors.push('Street address is required');
  if (!formData.city?.trim()) errors.push('City is required');
  if (!formData.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!formData.country?.trim()) errors.push('Country is required');
  if (!formData.email?.trim()) errors.push('Email is required');
  if (!formData.phone?.trim()) errors.push('Phone number is required');
  
  // Email validation
  if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone number validation (allow +, digits, spaces, parentheses, dashes)
  if (formData.phone && !/^\+?[0-9\s()-]+$/.test(formData.phone.trim())) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation (allow alphanumeric)
  if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode.trim())) {
    errors.push('Postal code can only contain letters and numbers');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Define routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validationResult = validateFormData(req.body);
  
  if (!validationResult.isValid) {
    return res.render('form', {
      errors: validationResult.errors,
      values: req.body
    });
  }
  
  // Insert into database
  const query = `
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (
      ?, ?, ?, ?, ?, ?, ?, ?, ?
    )
  `;
  
  try {
    if (db) {
      const params: SqlValue[] = [
        req.body.firstName?.trim() || '',
        req.body.lastName?.trim() || '',
        req.body.streetAddress?.trim() || '',
        req.body.city?.trim() || '',
        req.body.stateProvince?.trim() || '',
        req.body.postalCode?.trim() || '',
        req.body.country?.trim() || '',
        req.body.email?.trim() || '',
        req.body.phone?.trim() || ''
      ];
      
      db.run(query, params);
      saveDatabase(db);
    }
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  // For this simple app, we'll just render the thank you page without specific user data
  // In a real app, you might want to look up the most recent submission
  res.render('thank-you', { firstName: 'Friend' });
});

// Start server
async function startServer() {
  try {
    db = await initializeDatabase();
    
    const server = app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      server.close(() => {
        try {
          if (db) {
            db.close();
          }
        } catch (error) {
          console.error('Error closing database:', error);
        }
        process.exit(0);
      });
    });
    
    process.on('SIGINT', () => {
      console.log('SIGINT received, shutting down gracefully');
      server.close(() => {
        try {
          if (db) {
            db.close();
          }
        } catch (error) {
          console.error('Error closing database:', error);
        }
        process.exit(0);
      });
    });
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
