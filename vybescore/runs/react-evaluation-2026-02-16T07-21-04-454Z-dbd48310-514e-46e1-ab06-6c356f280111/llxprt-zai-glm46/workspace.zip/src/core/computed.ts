/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Store observer reference for dependency tracking
  const computedObserver = o
  
  // Wrap the updateFn to notify dependent observers after update
  const wrappedUpdateFn: UpdateFn<T> = (val?: T) => {
    const result = updateFn(val)
    // Update the value immediately
    computedObserver.value = result
    // After updating, notify all dependent observers
    if (computedObserver.observers) {
      computedObserver.observers.forEach(depObserver => {
        updateObserver(depObserver as Observer<unknown>)
      })
    }
    return result
  }
  o.updateFn = wrappedUpdateFn
  
  // Initial computation to establish dependencies
  // console.log(`[Computed ${computedObserver.name || 'unnamed'}] Initial computation`)
  updateObserver(o)
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && observer !== computedObserver) {
      // If this computed is being accessed by another observer,
      // register the dependency
      if (!computedObserver.observers) {
        computedObserver.observers = new Set()
      }
      computedObserver.observers.add(observer)
    }
    // Simply return the cached value
    return computedObserver.value!
  }
  
  return getter
}
