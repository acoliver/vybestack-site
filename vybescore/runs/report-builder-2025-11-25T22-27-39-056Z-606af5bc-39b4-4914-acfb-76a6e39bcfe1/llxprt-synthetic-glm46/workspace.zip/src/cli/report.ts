#!/usr/bin/env node

import fs from 'fs';
import { ReportData, ReportOptions } from '../report/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: CliArgs = {
    inputFile: '',
    format: '',
    includeTotals: false
  };
  
  // Parse input file (first argument)
  if (args[0] && !args[0].startsWith('--')) {
    result.inputFile = args[0];
    args.shift();
  }
  
  // Parse options
  for (let i = 0; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        result.format = args[i];
        break;
      case '--output':
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        result.output = args[i];
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        if (args[i].startsWith('--')) {
          console.error(`Error: Unknown option ${args[i]}`);
          process.exit(1);
        }
    }
  }
  
  if (!result.inputFile) {
    console.error('Error: Input file is required');
    process.exit(1);
  }
  
  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: Expected an object');
  }
  
  const obj = data as { title?: unknown; summary?: unknown; entries?: unknown };
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "title" field (string expected)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "summary" field (string expected)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: Missing or invalid "entries" field (array expected)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: Entry at index ${i} is not an object`);
    }
    
    const entryObj = entry as { label?: unknown; amount?: unknown };
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: Entry at index ${i} has invalid "label" field (string expected)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: Entry at index ${i} has invalid "amount" field (number expected)`);
    }
  }
  
  return data as ReportData;
}

function main() {
  try {
    const args = parseArgs();
    
    // Read and parse input file
    let inputData: string;
    try {
      inputData = fs.readFileSync(args.inputFile, 'utf8');
    } catch (error) {
      console.error(`Error: Cannot read file ${args.inputFile}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    let data: unknown;
    try {
      data = JSON.parse(inputData);
    } catch (error) {
      console.error(`Error: Invalid JSON in file ${args.inputFile}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    
    const reportData = validateReportData(data);
    const options: ReportOptions = {
      includeTotals: args.includeTotals
    };
    
    let output: string;
    
    // Render based on format
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        console.error(`Error: Unsupported format "${args.format}"`);
        process.exit(1);
    }
    
    // Write output
    if (args.output) {
      try {
        fs.writeFileSync(args.output, output, 'utf8');
        console.log(`Report written to ${args.output}`);
    } catch (error) {
      console.error(`Error: Cannot write to output file ${args.output}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();