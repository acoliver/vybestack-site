import { ReportData, ReportOptions } from '../report/types.js';

export function renderMarkdown(data: ReportData, options: ReportOptions): string {
  const lines = [
    `# ${data.title}`,
    '',
    data.summary,
    '',
    '## Entries',
    ''
  ];
  
  // Add entries
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }
  
  // Add total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push('');
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}