export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that supports common formats while rejecting obvious invalid ones
  // Local part: letters, numbers, dots, hyphens, plus, apostrophes
  // No consecutive dots, no leading/trailing dots
  // Domain: letters, numbers, hyphens, dots, no underscores
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (value.includes('..')) return false; // Double dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // Leading/trailing dots
  if (value.includes('@.') || value.includes('.@')) return false; // Invalid dot placement
  if (value.includes('_@') || value.includes('@_')) return false; // Underscores in domain
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check basic length constraints
  if (digits.length < 10 || digits.length > 11) return false;
  
  // Handle optional +1 country code
  if (digits.length === 11) {
    if (!digits.startsWith('1')) return false; // Must start with 1 for US
  }
  
  // Extract last 10 digits for area code and number validation
  const last10 = digits.slice(-10);
  const areaCode = last10.substring(0, 3);
  const exchange = last10.substring(3, 6);
  // const subscriber = last10.substring(6, 10); // Not used in validation logic
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  if (exchange[0] === '0' || exchange[0] === '1') return false;
  
  // Validate format patterns
  const formats = [
    /^\+?1?[\s-]?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/, // (212) 555-7890, 212-555-7890, +1 212 555 7890
    /^\+?1?\d{10}$/, // 2125557890
  ];
  
  return formats.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove separators for validation while keeping structure
  const clean = value.replace(/[\s-]/g, '');
  
  // Argentine phone patterns:
  // [+54][0][9]AreaCode[Subscriber]
  // +54 341 123 4567
  // 011 1234 5678
  // +54 9 11 1234 5678
  // 0341 4234567
  
  // Regex pattern:
  // ^\+54 - optional country code
  // 0? - optional trunk prefix
  // 9? - optional mobile indicator
  // [1-9]\d{1,3} - area code (2-4 digits, leading 1-9)
  // \d{6,8} - subscriber number (6-8 digits)
  const pattern1 = /^\+540?[1-9]\d{1,3}\d{6,8}$/; // +54 0 area subscriber
  const pattern2 = /^\+549[1-9]\d{1,3}\d{6,8}$/; // +54 9 area subscriber
  const pattern3 = /^\+54[1-9]\d{1,3}\d{6,8}$/; // +54 area subscriber
  const pattern4 = /^0[1-9]\d{1,3}\d{6,8}$/; // 0 area subscriber (no country code)
  
  // Original validation with separators
  const withSeparators1 = /^\+54\s*0?\s*[1-9]\d{1,3}\s*\d{6,8}$/;
  const withSeparators2 = /^\+54\s*9\s*[1-9]\d{1,3}\s*\d{6,8}$/;
  const withSeparators3 = /^\+54\s*[1-9]\d{1,3}\s*\d{6,8}$/;
  const withSeparators4 = /^0\s*[1-9]\d{1,3}\s*\d{6,8}$/;
  
  return (
    pattern1.test(clean) || pattern2.test(clean) || pattern3.test(clean) || pattern4.test(clean) ||
    withSeparators1.test(value) || withSeparators2.test(value) || withSeparators3.test(value) || withSeparators4.test(value)
  );
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const name = value.trim();
  if (!name) return false;
  
  // Unicode letter regex includes:
  // \p{L} - any letter (including accented characters)
  // ' - apostrophe
  // - - hyphen  
  // \s - spaces
  const nameRegex = /^(\p{L}|['\s-])+$/u;
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(name)) return false;
  
  // No digits, no special symbols except allowed ones
  if (/\d/.test(name)) return false;
  if (/[^\p{L}'\s-]/u.test(name)) return false;
  
  // Not too short (at least 2 characters after removing spaces/hyphens/apostrophes)
  const meaningfulChars = name.replace(/[\s'-]/g, '');
  if (meaningfulChars.length < 2) return false;
  
  return nameRegex.test(name);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cardNumber)) return false;
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  const isValidLength = cardNumber.length === 13 || cardNumber.length === 15 || cardNumber.length === 16;
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!isValidLength) return false;
  
  const isValidPrefix = visaRegex.test(cardNumber) || mastercardRegex.test(cardNumber) || amexRegex.test(cardNumber);
  if (!isValidPrefix) return false;
  
  return luhnCheck(cardNumber);
}

function luhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
