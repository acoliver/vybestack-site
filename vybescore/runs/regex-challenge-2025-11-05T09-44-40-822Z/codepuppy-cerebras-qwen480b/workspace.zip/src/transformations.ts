/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, collapse multiple spaces into single spaces, but keep sentence delimiters
  let result = text.replace(/\s+/g, ' ');
  
  // Capitalize after sentence delimiters (. ! ?) followed by any number of spaces
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, delimiter, letter) => {
    return delimiter + letter.toUpperCase();
  });
  
  // Capitalize the very first character
  result = result.replace(/^\s*([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Ensure single space after sentence delimiters
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern
  // Matches http(s)://, www., and domains
  // Captures the full URL without trailing punctuation
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"]+[^\s<>")\.!,;:]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each match
  return matches.map(url => {
    return url.replace(/[\).!,;:]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// using regex
  // Use word boundary to avoid matching within other text
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // This is a complex transformation, let's handle it step by step
  // First upgrade all http to https
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Then handle docs.example.com rewriting
  // Pattern: https://example.com/docs/...
  // Exclusions: cgi-bin, query strings, legacy extensions
  result = result.replace(
    /https:\/\/([a-zA-Z0-9.-]+\.com)\/docs\/([^\s"'>]*?)(?=\s|["'>]|$)/g,
    (match, domain, path) => {
      // Check for exclusions
      const excludes = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
      const hasExclusion = excludes.some(exclude => path.includes(exclude));
      
      if (hasExclusion) {
        // Keep as is, just ensure https
        return match;
      } else {
        // Move to docs.example.com
        return `https://docs.${domain}/docs/${path}`;
      }
    }
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy pattern
  const dateMatch = value.match(/^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate day range for the month (basic validation)
  const daysInMonth = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day > daysInMonth[month as keyof typeof daysInMonth]) {
    return 'N/A';
  }
  
  return year;
}
