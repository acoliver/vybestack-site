/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create regex to find words starting with the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Convert to lowercase for case-insensitive comparison and filter
  const filtered = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerPrefix = prefix.toLowerCase();
    
    // Check if word starts with prefix (case-insensitive)
    if (!lowerWord.startsWith(lowerPrefix)) return false;
    
    // Check if word is in exceptions (case-insensitive)
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowerWord
    );
  });
  
  // Remove duplicates and return
  return [...new Set(filtered)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Create regex for token that:
  // 1. Is preceded by a digit and includes that digit
  // 2. Is NOT at the start of the string
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const tokenRegex = new RegExp(`(?<!^)(\\d)${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // Contains at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Contains at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Contains at least one digit
  if (!/\d/.test(value)) return false;
  
  // Contains at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (like abab, testtest)
  // Check for patterns where a sequence of 2+ characters repeats immediately
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 patterns:
  // 1. Full format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. With :: shorthand
  // 3. With embedded IPv4
  
  // First, make sure we don't match pure IPv4 addresses
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value)) return false;
  
  // IPv6 regex patterns
  const ipv6Patterns = [
    // Full IPv6 (8 groups of 1-4 hex digits)
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // IPv6 with :: (compressed)
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/,
    /::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/,
    // IPv6 with :: at start or end
    /^::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$/,
    // IPv6 with embedded IPv4
    /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}/
  ];
  
  // Check if any IPv6 pattern matches
  return ipv6Patterns.some(pattern => pattern.test(value));
}
