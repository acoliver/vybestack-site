/**
 * Encode plain text to Base64 using the canonical RFC 4648 alphabet.
 * Includes required padding ('=') characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects invalid Base64 input by throwing an error.
 */
export function decode(input: string): string {
  // Validate input is proper Base64 format
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for invalid padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingPart = input.substring(paddingIndex);
    if (!/^(=|==)$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Check overall length is valid for base64
    const totalLength = input.length;
    // Base64 length must be a multiple of 4
    if (totalLength % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
