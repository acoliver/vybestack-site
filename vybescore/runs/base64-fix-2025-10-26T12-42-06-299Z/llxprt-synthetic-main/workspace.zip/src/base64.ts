const BASE64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

export function encode(text: string): string {
  try {
    const bytes = new TextEncoder().encode(text);
    let result = '';

    for (let i = 0; i < bytes.length; i += 3) {
      const a = bytes[i];
      const b = bytes[i + 1];
      const c = bytes[i + 2];

      const bitmap = (a << 16) | (b << 8) | c;

      result += BASE64_ALPHABET[(bitmap >> 18) & 0x3f] +
                BASE64_ALPHABET[(bitmap >> 12) & 0x3f];

      if (i + 1 < bytes.length) {
        result += BASE64_ALPHABET[(bitmap >> 6) & 0x3f];
      } else {
        result += '=';
      }

      if (i + 2 < bytes.length) {
        result += BASE64_ALPHABET[bitmap & 0x3f];
      } else {
        result += '=';
      }
    }

    return result;
  } catch (error) {
    throw new Error(`Encoding failed: ${error}`);
  }
}

export function decode(text: string): string {
  try {
    // Strip padding
    const stripped = text.replace(/=+$/g, '');
    let buffer = 0, 
        bufferBits = 0;
    const bytes: number[] = [];

    for (let i = 0; i < stripped.length; i++) {
      const char = stripped[i];
      const index = BASE64_ALPHABET.indexOf(char);
      
      if (index === -1) {
        throw new Error('Invalid Base64 input');
      }

      buffer = (buffer << 6) | index;
      bufferBits += 6;

      if (bufferBits >= 8) {
        bufferBits -= 8;
        bytes.push((buffer >> bufferBits) & 0xff);
      }
    }

    // Properly decode UTF-8 bytes
    const decoder = new TextDecoder();
    return decoder.decode(new Uint8Array(bytes));
  } catch (error) {
    throw new Error(`Decoding failed: ${error}`);
  }
}