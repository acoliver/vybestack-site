declare module 'sql.js' {
  export default class SqlJs {
    static Database: new (
      data?: Uint8Array
    ) => {
      exec(sql: string): void;
      run(sql: string, params?: unknown[]): { changes: number; lastInsertRowid: number };
      close(): void;
      export(): Uint8Array;
    };
  }

  export default function initSqlJs(): Promise<SqlJs>;
}