import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeDatabase, closeDatabase, getDatabase } from './db.js';
import { validateForm, formatErrors } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', { formData: null, errors: null });
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.render('index', { formData, errors: formatErrors(validation.errors) });
  }

  // Insert into database
  try {
    const db = getDatabase();
    const insertQuery = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    db.run(insertQuery, [
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    
    // Save the database to disk after inserting
    const { saveDatabase } = await import('./db.js');
    saveDatabase(db);
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('index', { 
      formData, 
      errors: { general: 'An error occurred while saving your submission. Please try again.' }
    });
  }
});

// Handle server startup when not in test mode
function startServer() {
  // Only start the server if not in test environment
  if (process.env.NODE_ENV !== 'test') {
    // Initialize database
    initializeDatabase().then(() => {
      app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });
    });
  } else {
    // In test mode, just initialize the database without starting the server
    initializeDatabase().catch(error => {
      console.error('Failed to initialize database in test mode:', error);
    });
  }
}

// Graceful shutdown
const gracefulShutdown = () => {
  console.log('SIGTERM received, shutting down gracefully');
  closeDatabase();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Export a function to start the server
async function initializeServer(): Promise<void> {
  await initializeDatabase();
}

// Export the initialization function for tests
export { initializeServer };

// Start the server if not in test mode
startServer();

export default app;
