// Form data interface
export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Validation errors interface
export interface ValidationError {
  field: string;
  message: string;
}

// Validation result interface
export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

// Email validation regex
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Phone validation regex (allows international formats)
const phoneRegex = /^\+?[\d\s\-()]+$/;

// Postal code validation regex (allows alphanumeric with spaces)
const postalCodeRegex = /^[\dA-Za-z\s-]+$/;

export function validateForm(formData: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Required fields
  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  }

  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!postalCodeRegex.test(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code (letters and numbers allowed)' });
  }

  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!emailRegex.test(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!phoneRegex.test(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

export function formatErrors(errors: ValidationError[]): Record<string, string> {
  const formattedErrors: Record<string, string> = {};
  
  for (const error of errors) {
    formattedErrors[error.field] = error.message;
  }
  
  return formattedErrors;
}