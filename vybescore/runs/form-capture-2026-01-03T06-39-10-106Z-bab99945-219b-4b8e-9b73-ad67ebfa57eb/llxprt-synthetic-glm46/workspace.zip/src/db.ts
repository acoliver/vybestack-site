import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Read schema SQL
const schemaPath = path.join(__dirname, '../db/schema.sql');
const schema = fs.readFileSync(schemaPath, 'utf8');

// Database interface
export interface Database {
  run(sql: string, params?: unknown[]): { changes: number; lastInsertRowid: number };
  exec(sql: string): void;
  close(): void;
  export(): Uint8Array;
}

let db: Database | null = null;

// Initialize database
export async function initializeDatabase(): Promise<Database> {
  const initSqlJs = (await import('sql.js')).default;
  const SQL = await initSqlJs();
  
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  try {
    // Load existing database file
    const filebuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(filebuffer);
  } catch (error) {
    // Create new database if file doesn't exist
    const newDb = new SQL.Database();
    db = newDb;
    if (!db) {
      throw new Error('Failed to create database');
    }
    // Create tables
    db.exec(schema);
    // Save to disk
    saveDatabase(db);
  }
  
  if (!db) {
    throw new Error('Failed to initialize database');
  }
  
  return db;
}

// Save database to disk
export function saveDatabase(database: Database): void {
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  const data = database.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

// Get database instance
export function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

// Close database
export function closeDatabase(): void {
  if (db) {
    saveDatabase(db);
    db.close();
    db = null;
  }
}