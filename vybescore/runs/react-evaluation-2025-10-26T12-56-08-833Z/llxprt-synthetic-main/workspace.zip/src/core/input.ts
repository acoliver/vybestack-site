/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type UnknownObserver = Observer<any>

function defaultEquals<T>(a: T, b: T): boolean {
  return a === b
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine equality function
  let equalsFn: EqualFn<T>
  if (equal === true) {
    equalsFn = defaultEquals
  } else if (equal === false || equal === undefined) {
    equalsFn = () => false // Never equal, always update
  } else {
    equalsFn = equal
  }

  // Create a subject to hold the input value and observers
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined, // Backward compatibility
    observers: new Set(),
    value,
    equalFn: equalsFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // For backward compatibility, handle both single observer and array of observers
      if (!s.observer) {
        s.observer = observer
      } else if (Array.isArray(s.observer)) {
        s.observer.push(observer)
      } else {
        s.observer = [s.observer, observer]
      }
      
      // Also add to the new observers Set (only if observer has updateFn)
      if ('updateFn' in observer) {
        s.observers!.add(observer as UnknownObserver)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed according to equality function
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify old-style observers (single or array)
      if (s.observer) {
        if (Array.isArray(s.observer)) {
          s.observer.forEach(observer => {
            // Only notify observers that have updateFn
            if ('updateFn' in observer) {
              try {
                updateObserver(observer as UnknownObserver)
              } catch (e) {
                // Continue
              }
            }
          })
        } else {
          // Only notify observer if it has updateFn
          if ('updateFn' in s.observer) {
            try {
              updateObserver(s.observer as UnknownObserver)
            } catch (e) {
              // Continue
            }
          }
        }
      }
      
      // Notify all new-style observers
      if (s.observers) {
        s.observers.forEach(observer => {
          try {
            // Skip if already notified above to avoid duplicate notifications
            const isOldObserver = Array.isArray(s.observer) 
              ? s.observer.includes(observer as ObserverR)
              : s.observer === observer
              
            if (!isOldObserver) {
              updateObserver(observer)
            }
          } catch (e) {
            // Continue notifying others even if one throws
          }
        })
      }
    }
    return s.value
  }

  return [read, write]
}
