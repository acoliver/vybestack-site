/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

// eslint-disable-next-line @typescript-eslint/no-explicit-any
type UnknownObserver = Observer<any>

function defaultEquals<T>(a: T, b: T): boolean {
  return a === b
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Determine equality function
  let equalsFn: EqualFn<T>
  if (equal === true) {
    equalsFn = defaultEquals
  } else if (equal === false || equal === undefined) {
    equalsFn = () => false // Never equal, always update
  } else {
    equalsFn = equal
  }

  // Track all observers that depend on this computed value
  const dependents = new Set<UnknownObserver>()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      // Run the actual update function
      const result = updateFn(currentValue)
      o.value = result
      return result
    },
  }
  
  // Initialize the value by executing the update function
  updateObserver(o)
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && o !== observer) {
      // Ensure observer is a full Observer with updateFn
      if ('updateFn' in observer) {
        const fullObserver = observer as UnknownObserver
        
        // Register this observer as a dependent of this computed value
        dependents.add(fullObserver)
        
        // Hook into the observer's update process
        const originalUpdate = fullObserver.updateFn
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        fullObserver.updateFn = (currentValue?: any) => {
          // Execute the original update function
          const result = originalUpdate(currentValue)
          
          // Then update this computed value
          const prevComputedValue = o.value
          updateObserver(o)
          
          // If this computed value changed, update all its dependents
          if (o.value === undefined || !equalsFn(prevComputedValue!, o.value!)) {
            dependents.forEach(dependent => {
              if (dependent !== fullObserver) {
                updateObserver(dependent)
              }
            })
          }
          
          return result
        }
      } else {
        // For ObserverR only, add to dependents but can't hook into update
        dependents.add(observer as UnknownObserver)
      }
    }
    
    return o.value!
  }
  
  // Hook the computed value's own update function to notify its dependents
  const originalComputedUpdate = o.updateFn
  o.updateFn = (currentValue?: T) => {
    const prevValue = o.value
    const result = originalComputedUpdate(currentValue)
    
    // If the computed value changed, notify all dependents
    if (o.value === undefined || !equalsFn(prevValue!, o.value)) {
      dependents.forEach(dependent => {
        updateObserver(dependent)
      })
    }
    
    return result
  }
  
  return getter
}