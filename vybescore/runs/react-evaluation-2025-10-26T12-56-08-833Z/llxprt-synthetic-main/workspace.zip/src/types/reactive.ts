/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | ObserverR[] // For backward compatibility, support multiple observers
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  observers?: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const subjects = new Set<Subject<any>>()

export function registerSubject<T>(subject: Subject<T>): void {
  subjects.add(subject)
}

export function unregisterSubject<T>(subject: Subject<T>): void {
  subjects.delete(subject)
}

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // When this observer is updated, track which subjects it accesses
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}


