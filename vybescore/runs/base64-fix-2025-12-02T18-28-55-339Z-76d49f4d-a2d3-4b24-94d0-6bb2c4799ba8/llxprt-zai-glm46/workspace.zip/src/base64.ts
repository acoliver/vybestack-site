/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Returns properly padded Base64 output according to RFC 4648.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates Base64 input according to RFC 4648.
 * Throws an error for invalid Base64 strings.
 */
function validateBase64(input: string): void {
  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, = for padding)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check that padding only appears at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingOnly = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingOnly)) {
      throw new Error('Invalid Base64 input: padding characters not at the end');
    }
  }
  
  // Check that the total length is a multiple of 4 after adding padding
  const unpadded = input.replace(/=+$/, '');
  if (unpadded.length % 4 === 1) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding and rejects invalid input.
 */
export function decode(input: string): string {
  try {
    validateBase64(input);
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
