import type { ReportData, ReportFormatter, RenderOptions } from '../types.js';

/**
 * Format amount as currency with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate total of all entries
 */
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report in Markdown format
 */
export const renderMarkdown: ReportFormatter['render'] = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Title as H1
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
