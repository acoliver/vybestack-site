import * as fs from 'node:fs';
import type { ReportData } from './types.js';

/**
 * Validate and parse report data from JSON file
 */
export function loadReportData(filePath: string): ReportData {
  let content: string;
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file: ${filePath}`);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error('Invalid JSON: Failed to parse input file');
  }

  // Validate structure
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid report data: must be an object');
  }

  const report = data as Partial<ReportData>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }

    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label"`);
    }

    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount"`);
    }
  }

  return report as ReportData;
}
