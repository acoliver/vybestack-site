#!/usr/bin/env node

import * as fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { RenderOptions } from '../types.js';
import { loadReportData } from '../utils.js';

/**
 * Parse command-line arguments
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */
function parseArgs(args: string[]): {
  dataFile: string;
  format: string;
  outputPath: string | null;
  options: RenderOptions;
} {
  const dataFile = args[0];
  if (!dataFile) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  let format: string | null = null;
  let outputPath: string | null = null;
  const options: RenderOptions = { includeTotals: false };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    if (arg === '--format') {
      if (!nextArg) {
        throw new Error('--format requires a value');
      }
      format = nextArg;
      i++;
    } else if (arg === '--output') {
      if (!nextArg) {
        throw new Error('--output requires a value');
      }
      outputPath = nextArg;
      i++;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataFile, format, outputPath, options };
}

/**
 * Get formatter for the specified format
 */
function getFormatter(format: string) {
  const normalizedFormat = format.toLowerCase();

  switch (normalizedFormat) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

/**
 * Main CLI execution
 */
function main(): void {
  try {
    const { dataFile, format, outputPath, options } = parseArgs(process.argv.slice(2));

    // Load and validate data
    const data = loadReportData(dataFile);

    // Get formatter and render report
    const formatter = getFormatter(format);
    const output = formatter(data, options);

    // Write output
    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();

