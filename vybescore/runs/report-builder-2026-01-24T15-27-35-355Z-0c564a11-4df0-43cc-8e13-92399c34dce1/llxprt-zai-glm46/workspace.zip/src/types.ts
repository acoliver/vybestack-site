/**
 * Report data model matching fixtures/data.json structure
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report rendering
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Formatter interface for consistent report rendering
 */
export interface ReportFormatter {
  render(data: ReportData, options: RenderOptions): string;
}
