import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { request as httpRequest } from 'node:http';
import { request as httpsRequest } from 'node:https';

let serverProcess: ReturnType<typeof spawn> | null = null;
const baseUrl = 'http://localhost:3001';

function makeRequest(url: string, options: Record<string, unknown> = {}): Promise<{ 
  status: number; 
  headers: Record<string, string | string[] | undefined>; 
  text: () => Promise<string> 
}> {
  return new Promise((resolve, reject) => {
    const urlObj = new URL(url);
    const lib = urlObj.protocol === 'https:' ? httpsRequest : httpRequest;
    
    const reqOptions = {
      hostname: urlObj.hostname,
      port: urlObj.port,
      path: urlObj.pathname + urlObj.search,
      method: options.method || 'GET',
      headers: options.headers || {}
    };

    const req = lib(reqOptions, (res) => {
      let data = '';
      res.on('data', (chunk) => { data += chunk; });
      res.on('end', () => {
        resolve({
          status: res.statusCode || 0,
          headers: res.headers,
          text: async () => data
        });
      });
    });

    req.on('error', reject);

    if (options.body) {
      req.write(options.body);
    }

    req.end();
  });
}

beforeAll(async () => {
  const serverPath = path.resolve('dist', 'server.js');
  
  if (fs.existsSync(serverPath)) {
    return new Promise<void>((resolve) => {
      serverProcess = spawn('node', [serverPath], {
        env: { ...process.env, PORT: '3001' },
        stdio: 'pipe'
      });
      
      serverProcess.stdout.on('data', (data: Buffer) => {
        if (data.toString().includes('Server is running')) {
          resolve();
        }
      });
      
      setTimeout(() => resolve(), 2000);
    });
  }
});

afterAll(() => {
  if (serverProcess) {
    serverProcess.kill();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await makeRequest(`${baseUrl}/`);
    const html = await response.text();
    
    expect(response.status).toBe(200);
    expect(html).toContain('First Name');
    expect(html).toContain('Last Name');
    expect(html).toContain('Street Address');
    expect(html).toContain('City');
    expect(html).toContain('State / Province / Region');
    expect(html).toContain('Postal / ZIP Code');
    expect(html).toContain('Country');
    expect(html).toContain('Email');
    expect(html).toContain('Phone Number');
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = new URLSearchParams();
    formData.append('firstName', 'John');
    formData.append('lastName', 'Doe');
    formData.append('streetAddress', '123 Main St');
    formData.append('city', 'Anytown');
    formData.append('stateProvince', 'State');
    formData.append('postalCode', '12345');
    formData.append('country', 'USA');
    formData.append('email', 'john@example.com');
    formData.append('phone', '+1 555 123 4567');

    const response = await makeRequest(`${baseUrl}/submit`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      },
      body: formData.toString()
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you?firstName=John');

    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      expect(dbBuffer.length).toBeGreaterThan(0);
    }
  });
});
