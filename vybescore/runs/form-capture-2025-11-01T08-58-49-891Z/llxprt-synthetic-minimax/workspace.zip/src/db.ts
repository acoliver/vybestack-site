import initSqlJs from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface SqlJsDatabase {
  exec(sql: string): void;
  prepare(sql: string): SqlJsStatement;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsStatement {
  run(params: unknown[]): void;
  free(): void;
}

let dbInstance: SqlJsDatabase | null = null;
let SqlJs: { Database: new (buffer?: Uint8Array) => SqlJsDatabase } | null = null;

export async function initDatabase(): Promise<SqlJsDatabase> {
  if (dbInstance) {
    return dbInstance;
  }

  if (!SqlJs) {
    // Locate the sql-wasm.wasm file for sql.js
    SqlJs = await initSqlJs({
      locateFile: () => {
        const wasmPath = require.resolve('sql.js/dist/sql-wasm.wasm');
        return wasmPath;
      }
    });
  }

  let buffer: Uint8Array | undefined;
  
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    buffer = new Uint8Array(fileBuffer);
  }

  dbInstance = new SqlJs.Database(buffer);

  if (!fs.existsSync(DB_PATH)) {
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.exec(schema);
    await saveDatabase();
  }

  return dbInstance;
}

export async function saveDatabase(): Promise<void> {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const data = dbInstance.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

export function getDatabase(): SqlJsDatabase {
  if (!dbInstance) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return dbInstance;
}

export async function closeDatabase(): Promise<void> {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}