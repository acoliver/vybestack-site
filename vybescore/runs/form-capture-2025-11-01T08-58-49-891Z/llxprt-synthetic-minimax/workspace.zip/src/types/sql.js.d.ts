declare module 'sql.js' {
  interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(params: unknown[]): void;
    free(): void;
  }

  export function initSqlJs(config: {
    locateFile: (file: string) => string;
  }): Promise<{ Database: new (buffer?: Uint8Array) => Database }>;

  export default initSqlJs;
}