/**
 * Base64 alphabet validation regex
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validates if input string is a valid Base64 string
 */
function isValidBase64(input: string): boolean {
  // Check for invalid characters
  if (!BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Base64 length must always be multiple of 4
  if (input.length % 4 !== 0) {
    return false;
  }
  
  // Check padding rules
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be at the end and must be '=' or '=='
    const padding = input.slice(paddingIndex);
    if (padding !== '=' && padding !== '==') {
      return false;
    }
    
    // Padding can only appear at the end of valid base64 strings
    const paddingLength = padding.length;
    const totalLength = input.length;
    
    // For valid Base64 with padding:
    // - Double padding (==): must be at the end (position length-2)
    // - Single padding (=): must be at the end (position length-1)
    
    if (paddingLength === 2 && paddingIndex !== totalLength - 2) {
      return false;
    }
    if (paddingLength === 1 && paddingIndex !== totalLength - 1) {
      return false;
    }
    

  }
  
  return true;
}

/**
 * Encode plain text to Base64 using canonical RFC 4648 alphabet.
 * Includes required padding characters.
 */
export function encode(input: string): string {
  try {
    return Buffer.from(input, 'utf8').toString('base64');
  } catch (error) {
    throw new Error('Failed to encode input to Base64');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and validates
 * the input before attempting to decode.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }
  
  // Validate the Base64 input
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
