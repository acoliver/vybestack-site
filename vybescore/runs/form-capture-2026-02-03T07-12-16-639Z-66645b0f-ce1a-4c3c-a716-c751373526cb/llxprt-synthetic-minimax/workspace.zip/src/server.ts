import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define interface for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Define interface for validation errors
interface ValidationErrors {
  [key: string]: string;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Serve static files from public directory
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set view engine to EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Initialize SQLite database
let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    const dbDir = path.join(__dirname, '../data');
    const dbPath = path.join(dbDir, 'submissions.sqlite');
    
    // Create data directory if it doesn't exist
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }

    // Load existing database or create new one
    let databaseContent: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      databaseContent = fs.readFileSync(dbPath);
    }

    db = new SQL.Database(databaseContent);
    
    // Create submissions table if it doesn't exist
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);

  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (db) {
    const dbDir = path.join(__dirname, '../data');
    const dbPath = path.join(dbDir, 'submissions.sqlite');
    
    try {
      const binaryData = db.export();
      fs.writeFileSync(dbPath, Buffer.from(binaryData));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

function validateForm(formData: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Check required fields
  if (!formData.firstName.trim()) errors.firstName = 'First name is required';
  if (!formData.lastName.trim()) errors.lastName = 'Last name is required';
  if (!formData.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!formData.city.trim()) errors.city = 'City is required';
  if (!formData.stateProvince.trim()) errors.stateProvince = 'State/Province/Region is required';
  if (!formData.postalCode.trim()) errors.postalCode = 'Postal code is required';
  if (!formData.country.trim()) errors.country = 'Country is required';
  if (!formData.email.trim()) errors.email = 'Email is required';

  // Validate email format
  if (formData.email && formData.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Validate phone format (digits, spaces, parentheses, dashes, leading +)
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  if (formData.phone && formData.phone.trim()) {
    if (!phoneRegex.test(formData.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  return errors;
}

// Route to serve the contact form
app.get('/', (_req, res) => {
  res.render('form', { 
    errors: {},
    formData: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

// Route to handle form submission
app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    // Return to form with errors
    res.status(400).render('form', { errors, formData });
    return;
  }

  // Insert form data into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect('/thank-you');
});

// Route to serve thank you page
app.get('/thank-you', (_req, res) => {
  res.render('thank-you');
});

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    process.on('SIGTERM', () => {
      console.log('Received SIGTERM. Starting graceful shutdown...');
      
      if (server) {
        server.close(() => {
          console.log('HTTP server closed');
        });
      }
      
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });

    process.on('SIGINT', () => {
      console.log('Received SIGINT. Starting graceful shutdown...');
      
      if (server) {
        server.close(() => {
          console.log('HTTP server closed');
        });
      }
      
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
