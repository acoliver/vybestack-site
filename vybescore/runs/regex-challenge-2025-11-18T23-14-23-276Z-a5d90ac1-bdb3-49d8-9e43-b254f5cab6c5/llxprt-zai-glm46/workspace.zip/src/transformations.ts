/**
 * Capitalizes the first character of each sentence.
 * After sentence-ending punctuation (.?!), inserts exactly one space and capitalizes the next character.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, handle sentence boundaries by looking for . ? ! followed by whitespace and then lowercase
  const processed = text
    // Replace multiple spaces with single space (but preserve line breaks for now)
    .replace(/[ \t]+/g, ' ')
    // Ensure proper spacing after sentence punctuation
    .replace(/([.!?])(?=[A-Za-z])/g, '$1 ')
    // Remove spaces before punctuation
    .replace(/\s+([.!?])/g, '$1')
    // Ensure single space after punctuation (unless followed by newline)
    .replace(/([.!?])\s+/g, (match, punctuation) => {
      // Check if there's a newline after the punctuation
      if (match.includes('\n')) {
        return punctuation + '\n';
      }
      return punctuation + ' ';
    });
  
  // Now capitalize sentences
  let result = processed;
  
  // Capitalize first letter of the entire string
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Capitalize after sentence-ending punctuation, considering common abbreviations
  const abbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Mt|vs|etc|e\.g|i\.e|No|Fig|Fig|al|et|Jan|Feb|Mar|Apr|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Mon|Tue|Wed|Thu|Fri|Sat|Sun)\.?$/i;
  
  result = result.replace(/([.!?])\s+([a-z])/g, (match, punctuation, letter) => {
    // Get the text before the punctuation to check for abbreviations
    const beforeMatch = result.substring(0, result.indexOf(match));
    const lastSentence = beforeMatch.split(/[.!?]/).pop()?.trim();
    
    // If the last "sentence" looks like an abbreviation, don't capitalize
    if (lastSentence && abbreviations.test(lastSentence)) {
      return punctuation + ' ' + letter;
    }
    
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Handle capitalization after newlines
  result = result.replace(/\n\s*([a-z])/g, (match, letter) => '\n' + letter.toUpperCase());
  
  // Clean up any extra spacing
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Extracts URLs from text, returning an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Enhanced URL regex that matches various URL patterns
  const urlRegex = /\b((?:https?:\/\/|ftp:\/\/|www.)[^\s/$.?#][^\s]*)(?=[\s)\]\}\.,;:!?'"`]|$)/gi;
  
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[1];
    
    // Remove trailing punctuation that shouldn't be part of the URL
    url = url.replace(/[.,;!?)\]\}'"<>]+$/g, '');
    
    // If URL starts with www., add https://
    if (url.startsWith('www.')) {
      url = 'https://' + url;
    } else if (!url.startsWith('http')) {
      // For URLs that don't have a protocol, add http:// first
      url = 'http://' + url;
    }
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to specific rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/(http:\/\/)(example\.com)(\/[^\s]*)/g, (match, protocol, domain, path) => {
    // First, upgrade to https
    let newUrl = 'https://' + domain + path;
    
    // Check if we should rewrite the host to docs.example.com
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !shouldSkipHostRewrite(path);
    
    if (shouldRewriteHost) {
      newUrl = 'https://docs.example.com' + path;
    } else {
      // Just upgrade the scheme
      newUrl = 'https://' + domain + path;
    }
    
    return newUrl;
  });
}

/**
 * Determines if host rewrite should be skipped based on path characteristics
 */
function shouldSkipHostRewrite(path: string): boolean {
  // Check for dynamic hints in path
  const skipPatterns = [
    /\/cgi-bin\//,           // CGI scripts
    /\?|&|=/,               // Query strings
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i  // Legacy extensions
  ];
  
  return skipPatterns.some(pattern => pattern.test(path));
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format doesn't match or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format where mm and dd are 1-2 digits, yyyy is 4 digits
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // More specific day validation based on month
  const maxDay = getMaxDayForMonth(month, year);
  if (day > maxDay) return 'N/A';
  
  return yearStr;
}

/**
 * Gets the maximum number of days for a given month and year
 */
function getMaxDayForMonth(month: number, year: number): number {
  switch (month) {
    case 2: // February - account for leap years
      return (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? 29 : 28;
    case 4: case 6: case 9: case 11: // April, June, September, November
      return 30;
    default: // All other months
      return 31;
  }
}