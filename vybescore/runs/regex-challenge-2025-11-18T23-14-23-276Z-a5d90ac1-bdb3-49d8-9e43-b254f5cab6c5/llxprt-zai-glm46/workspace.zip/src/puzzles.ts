/**
 * Finds words beginning with the specified prefix, excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create a Set for efficient exception checking
  const exceptionsSet = new Set(exceptions || []);
  
  // Create regex pattern for words starting with the prefix
  // Use word boundaries to match whole words
  const regex = new RegExp(`\\b${escapeRegex(prefix)}\\w*`, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions and remove duplicates
  const uniqueWords = new Set<string>();
  
  for (const word of matches) {
    const normalizedWord = word.toLowerCase();
    if (!exceptionsSet.has(normalizedWord) && !exceptionsSet.has(word)) {
      uniqueWords.add(word);
    }
  }
  
  return Array.from(uniqueWords);
}

/**
 * Escapes special regex characters in a string
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds to position the token correctly.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = escapeRegex(token);
  
  // Use a simpler approach without lookbehind to ensure better compatibility
  // Find the token that appears after a digit and not at the beginning
  const digitTokenRegex = new RegExp(`\\d+${escapedToken}`, 'g');
  
  const matches = text.match(digitTokenRegex) || [];
  
  // Return unique matches that include the digit
  return [...new Set(matches)];
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Character class checks
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (like abab, 1212, xyxy)
  // Look for patterns of 2-4 characters that repeat immediately
  const repeatedPattern = /(.{2,4})\1/;
  if (repeatedPattern.test(value)) return false;
  
  // Additional check for character repetition (like aaa, bbb)
  const charRepetition = /(.)\1\1/;
  if (charRepetition.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand :: notation) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that matches various IPv6 formats
  // Including full notation, shorthand with ::, and embedded IPv4 addresses
  const ipv6Pattern = /(?:^|(?<=\s))(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}|(?:[0-9a-fA-F]{1,4}:){0,5}:(?:\d{1,3}\.){3}\d{1,3}|::(?:\d{1,3}\.){3}\d{1,3}(?::|$)/;
  
  // First check if there are any potential IPv6 patterns
  const potentialMatches = value.match(ipv6Pattern);
  if (!potentialMatches) return false;
  
  // For each potential match, verify it's actually IPv6 and not IPv4
  for (const match of potentialMatches) {
    // Clean up the match (remove surrounding whitespace if any)
    const cleanedMatch = match.trim();
    
    // Check if this is actually IPv4 and should be excluded
    if (isIPv4Address(cleanedMatch)) {
      continue;
    }
    
    // If it's not IPv4 and matches our pattern, it's IPv6
    return true;
  }
  
  return false;
}

/**
 * Helper function to check if a string is an IPv4 address
 */
function isIPv4Address(str: string): boolean {
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  return ipv4Pattern.test(str);
}