export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common standards.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  const [localPart, domain] = value.split('@');
  
  // Reject double dots anywhere in the email
  if (value.includes('..')) return false;
  
  // Reject leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject leading or trailing dots in domain parts
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  // Reject consecutive dots in domain
  if (domain.includes('..')) return false;
  
  // Check that domain has at least one dot and doesn't start/end with dot
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  // Check that each domain part is valid
  for (const part of domainParts) {
    if (!part) return false; // empty part (consecutive dots)
    if (part.startsWith('-') || part.endsWith('-')) return false; // leading/trailing hyphens
  }
  
  // Check that TLD is at least 2 characters
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits
  // 10 digits for standard US numbers, 11 digits if including country code +1
  if (digits.length === 11 && digits.startsWith('1')) {
    // Remove the leading 1 for validation
    const phoneDigits = digits.slice(1);
    return validateUSPhoneDigits(phoneDigits);
  } else if (digits.length === 10) {
    return validateUSPhoneDigits(digits);
  }
  
  return false;
}

/**
 * Helper function to validate 10-digit US phone number
 */
function validateUSPhoneDigits(digits: string): boolean {
  if (digits.length !== 10) return false;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - When country code is omitted, number must begin with trunk prefix 0
 * - Allows single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for easier processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for country code +54
  let hasCountryCode = false;
  let processed = cleaned;
  
  if (processed.startsWith('+54')) {
    hasCountryCode = true;
    processed = processed.slice(3);
  }
  
  // Check for trunk prefix 0
  let hasTrunkPrefix = false;
  if (processed.startsWith('0')) {
    hasTrunkPrefix = true;
    processed = processed.slice(1);
  }
  
  // Check for mobile indicator 9
  if (processed.startsWith('9')) {
    processed = processed.slice(1);
  }
  
  // Validate rules:
  // 1. If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // 2. At this point, processed should contain area code + subscriber number
  if (processed.length < 8 || processed.length > 12) return false;
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCodeLength = 2;
  
  // Try different area code lengths (2-4 digits)
  for (let len = 2; len <= 4; len++) {
    if (processed.length - len >= 6 && processed.length - len <= 8) {
      areaCodeLength = len;
      break;
    }
  }
  
  const areaCode = processed.slice(0, areaCodeLength);
  const subscriberNumber = processed.slice(areaCodeLength);
  
  // Validate area code: 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Validate subscriber number: 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Check length - names should be reasonable
  if (trimmed.length < 1 || trimmed.length > 100) return false;
  
  // Use a more conservative approach with basic character classes
  // Allow basic letters, spaces, apostrophes, and hyphens
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\s'-]+$/;
  
  // Quick check for basic allowed characters
  if (!nameRegex.test(trimmed)) return false;
  
  // Additional checks for obviously invalid names:
  
  // Check for digits (not allowed)
  if (/\d/.test(trimmed)) return false;
  
  // Check for multiple consecutive special characters
  if (/['\s-]{2,}/.test(trimmed)) return false;
  
  // Check for names with too many special characters compared to letters
  const letters = trimmed.replace(/[^a-zA-Z\u00C0-\u017F]/g, '').length;
  const specialChars = trimmed.replace(/[a-zA-Z\u00C0-\u017F]/g, '').length;
  if (specialChars > letters / 2) return false;
  
  // Check for obviously problematic character combinations
  if (/Æ|Ø|Å|×|÷/.test(trimmed)) return false;
  
  return true;
}

/**
 * Validates major credit card numbers (Visa, Mastercard, Amex) using Luhn checksum.
 * Accepts Visa (13 or 16 digits, starts with 4), 
 * Mastercard (16 digits, starts with 51-55 or 2221-2720),
 * and American Express (15 digits, starts with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length and prefix for different card types
  if (!isValidCardFormat(digits)) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}

/**
 * Validates card format (length and prefix) for supported card types
 */
function isValidCardFormat(digits: string): boolean {
  // Visa: 13 or 16 digits, starts with 4
  if (/^4(\d{12}|\d{15})$/.test(digits)) return true;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (/^(5[1-5]\d{14})$/.test(digits)) return true;
  if (/^(2(2[2-9][1-9]|2[3-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/.test(digits)) return true;
  
  // American Express: 15 digits, starts with 34 or 37
  if (/^3[47]\d{13}$/.test(digits)) return true;
  
  return false;
}

/**
 * Runs Luhn checksum validation
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}