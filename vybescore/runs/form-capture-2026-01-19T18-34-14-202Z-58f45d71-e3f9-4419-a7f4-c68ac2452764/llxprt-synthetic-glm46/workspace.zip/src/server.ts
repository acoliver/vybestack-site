import express from 'express';
import { join } from 'path';
import { DatabaseService, Submission } from './database.js';
import { validateForm, FormData, ValidationError } from './validation.js';

const app = express();
const port = process.env.PORT || 3535;
const dbService = new DatabaseService();

app.set('view engine', 'ejs');
app.set('views', join(process.cwd(), 'src', 'views'));

app.use(express.static(join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));

const formatErrors = (errors: ValidationError[]): Record<string, string> => {
  return errors.reduce((acc, error) => {
    acc[error.field] = error.message;
    return acc;
  }, {} as Record<string, string>);
};

app.get('/', (req, res) => {
  res.render('form', { 
    errors: {}, 
    data: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);

    if (errors.length > 0) {
      res.status(400).render('form', {
        errors: formatErrors(errors),
        data: formData,
        title: 'Friendly Contact Form - Error'
      });
      return;
    }

    await dbService.insertSubmission(formData as Submission);
    res.redirect('/thank-you');

  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      errors: { general: 'An unexpected error occurred. Please try again.' },
      data: req.body,
      title: 'Friendly Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

const gracefulShutdown = async () => {
  console.log('Shutting down gracefully...');
  await dbService.close();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

const startServer = async () => {
  try {
    await dbService.initialize();
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
      console.log(`Visit http://localhost:${port} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
