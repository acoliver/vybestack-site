export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export const validateForm = (data: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];

  if (!data.first_name?.trim()) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  if (!data.last_name?.trim()) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  if (!data.street_address?.trim()) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }

  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.state_province?.trim()) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }

  if (!data.postal_code?.trim()) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  } else {
    if (!/^[a-zA-Z0-9\s-]+$/.test(data.postal_code)) {
      errors.push({ field: 'postal_code', message: 'Postal code contains invalid characters' });
    }
  }

  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }

  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.push({ 
        field: 'phone', 
        message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' 
      });
    }
  }

  return errors;
};