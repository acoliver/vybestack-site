import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';
import initSqlJs, { Database } from 'sql.js';

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

export class DatabaseService {
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    const SQL = await initSqlJs();
    
    let databaseBuffer: Uint8Array;
    
    if (existsSync(this.dbPath)) {
      const fileData = readFileSync(this.dbPath);
      databaseBuffer = new Uint8Array(fileData);
    } else {
      databaseBuffer = new Uint8Array(0);
    }
    
    this.db = new SQL.Database(databaseBuffer);
    
    const schema = readFileSync(join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    this.db.run(schema);
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    try {
      stmt.run([
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone
      ]);
      
      const result = this.db.exec('SELECT last_insert_rowid() as id');
      const id = result[0].values[0][0] as number;
      
      this.saveDatabase();
      
      return id;
    } finally {
      stmt.free();
    }
  }

  private saveDatabase(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    const data = this.db.export();
    writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.saveDatabase();
      this.db.close();
      this.db = null;
    }
  }
}