interface SqlJsDatabase {
  run(sql: string, ...params: unknown[]): void;
  exec(sql: string): DatabaseResult[];
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  free(): void;
}

interface DatabaseResult {
  values: unknown[][];
  columns: string[];
}

interface SqlJsExports {
  Database: new (data?: Uint8Array | number[]) => SqlJsDatabase;
}

declare module 'sql.js' {
  export default function initSqlJs(): Promise<SqlJsExports>;
  export type Database = SqlJsDatabase;
  export type Statement = Statement;
}