/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getActiveObserver,
  addDependent,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: equal === true ? ((a: T, b: T) => a === b) : 
             typeof equal === 'function' ? equal : undefined,
    dependents: new Set()
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      addDependent(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = s.equalFn
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    
    if (shouldUpdate) {
      s.value = nextValue
      notifyDependents(s)
    }
    return s.value
  }

  return [read, write]
}
