/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    if (activeObserver) {
      // We have dependencies, use the complex update logic
      const newValue = o.updateFn(o.value)
      
      // Check if we need to update based on equality
      const shouldUpdate = o.value === undefined || 
        !equal || 
        (equal === true ? o.value !== newValue : !equal(o.value, newValue))
      
      if (shouldUpdate) {
        o.value = newValue
        updateObserver(o)
      }
    } else {
      // No dependencies, just compute the value
      o.value = o.updateFn(o.value)
    }
    
    return o.value!
  }
  
  return getter
}
