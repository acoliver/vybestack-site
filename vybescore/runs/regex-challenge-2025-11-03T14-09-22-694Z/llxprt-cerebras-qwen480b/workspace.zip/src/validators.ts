export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure and reject obviously invalid forms
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for specific invalid patterns
  if (!value || value.includes('..') || value.endsWith('.') || value.endsWith('@')) {
    return false;
  }
  
  // Check for underscore in domain part
  const parts = value.split('@');
  const domainPart = parts[parts.length - 1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Use regex to validate basic structure
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers with support for common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleaned = value.replace(/(^\+)|[^\d]/g, '');
  
  // Check if country code +1 is present
  const hasCountryCode = value.startsWith('+1');
  const digitsOnly = hasCountryCode ? cleaned.substring(1) : cleaned;
  
  // Validate length (should be 10 digits after removing formatting)
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Check area code (first digit cannot be 0 or 1)
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex to match Argentine phone number patterns
  const argentinePhoneRegex = /^(\+54|0)(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check if the format matches
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  // Extract parts
  const hasCountryCode = match[1] === '+54';
  // const hasMobileIndicator = !!match[2]; // Not used but kept for completeness
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, number must start with trunk prefix 0
  if (!hasCountryCode && !value.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Disallow digits and most symbols
  const nameRegex = /^[\\p{L}\\p{M}'\\-\\s]+$/u;
  
  // Check for obviously invalid names (like X Æ A-12)
  const invalidNameRegex = /\d/;
  
  if (!value || !nameRegex.test(value)) {
    return false;
  }
  
  return !invalidNameRegex.test(value);
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accept Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check for basic structure and known card types
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2(2[1-9]|[3-9]\d)|[3-6]\d{2}|7([01]\d|20))\d{12}$/; // 16 digits, starts with 5[1-5] or 222[1-9] through 2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check card type
  if (!(visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned))) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn algorithm
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}