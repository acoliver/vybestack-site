/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Insert exactly one space between sentences even if the input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split text into sentences by punctuation marks: ., !, ?
  // Include lookbehind to preserve the punctuation
  const sentences = text.split(/(?<=[.!?])\s*/);
  
  // Process each sentence
  return sentences.map((sentence, index) => {
    if (!sentence) return sentence;
    
    // Trim whitespace
    sentence = sentence.trim();
    
    // Capitalize first letter if it's a word character
    if (/\w/.test(sentence.charAt(0))) {
      sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    // Add exactly one space between sentences (except for the first one)
    return index > 0 ? ' ' + sentence : sentence;
  }).join('');
}

/**
 * Extract URLs from text.
 * Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // This regex pattern matches URLs starting with http:// or https://
  // It allows for various characters in the URL but excludes trailing punctuation
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s,.;:!?)\]}]*/gi;
  const matches = text.match(urlRegex);
  return matches ? Array.from(new Set(matches)) : []; // Deduplicate results
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skip host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs with http scheme, extract components for rewriting
  return text.replace(/http:\/\/([^\s/$.?#].[^\s]*)\/(docs\/[^\s,.;:!?)\]}]*)/gi, (match, host, path) => {
    // Check for dynamic hints that would prevent host rewriting
    const hasDynamicHints = /[?&=]|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
    
    if (hasDynamicHints) {
      // Just upgrade to https without changing host
      return `https://${host}/${path}`;
    } else {
      // Rewrite host to docs.example.com and upgrade to https
      return `https://docs.${host}/${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regular expression to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}