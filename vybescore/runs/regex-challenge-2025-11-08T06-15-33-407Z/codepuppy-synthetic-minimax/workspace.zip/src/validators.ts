export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses with strict rules.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex that: 
  // - Disallows consecutive dots
  // - Disallows leading/trailing dots
  // - Disallows underscores in domain
  // - Allows + in local part
  // - Allows subdomains and various TLDs
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?<!\.|\.)@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/; 
  
  // Check if it matches the basic pattern
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for problematic patterns
  if (value.includes('..')) return false; // Double dots
  if (value.includes('@.') || value.includes('.@')) return false; // Invalid positioning
  if (/^\./.test(value) || /\.$/.test(value)) return false; // Leading/trailing dots
  if (value.includes('_') && value.split('@')[1].includes('_')) return false; // Underscores in domain
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, 11 with country code)
  if (digits.length < 10 || digits.length > 11) return false;
  
  // If 11 digits, must start with 1 (US country code)
  let phoneNumber = digits;
  if (digits.length === 11) {
    if (!digits.startsWith('1')) return false;
    phoneNumber = digits.slice(1); // Remove country code
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  // Validate the format matches one of the accepted patterns
  const patterns = [
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/, // (212) 555-7890
    /^\+?1?\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/,    // 212-555-7890 or 212 555 7890
    /^\+?1?\s*\d{10}$/,                           // 2125557890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers covering landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation, but keep the structure
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern explanation:
  // ^\+54?: Optional country code +54
  // 9?: Optional mobile indicator 9
  // 0?: Optional trunk prefix 0
  // \d{2,4}: Area code (2-4 digits, leading 1-9)
  // \d{6,8}: Subscriber number (6-8 digits)
  // Alternative patterns for when country code is omitted (must start with 0)
  const argentinianPhoneRegex = /^(?:\+54)?(?:9)?0?\d{2,4}\d{6,8}$|^0\d{2,4}\d{6,8}$/;
  
  if (!argentinianPhoneRegex.test(cleanValue)) return false;
  
  // Extract components for detailed validation
  const hasCountryCode = cleanValue.startsWith('+54');
  let workingValue = cleanValue;
  
  // Remove country code if present
  if (hasCountryCode) {
    workingValue = workingValue.slice(3);
  }
  
  // Remove mobile indicator if present
  if (workingValue.startsWith('9')) {
    workingValue = workingValue.slice(1);
  }
  
  // Remove trunk prefix if present
  let hasTrunkPrefix = false;
  if (workingValue.startsWith('0')) {
    hasTrunkPrefix = true;
    workingValue = workingValue.slice(1);
  }
  
  // At this point, workingValue should be: areaCode + subscriberNumber
  // Area code: 2-4 digits, must start with 1-9
  // Subscriber number: 6-8 digits
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // Find area code (2-4 digits starting with 1-9)
  
  // Try different area code lengths (2-4)
  for (let len = 2; len <= 4; len++) {
    if (workingValue.length > len) {
      const potentialAreaCode = workingValue.substring(0, len);
      const potentialSubscriber = workingValue.substring(len);
      
      // Area code must start with 1-9 and be 2-4 digits
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode) && 
          potentialSubscriber.length >= 6 && 
          potentialSubscriber.length <= 8 &&
          /^\d+$/.test(potentialSubscriber)) {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like 'X Æ A-12' style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const trimmedValue = value.trim();
  if (!trimmedValue) return false;
  
  // Allow: unicode letters (including accents), apostrophes, hyphens, spaces
  // Disallow: digits, most symbols, multiple consecutive apostrophes/hyphens
  // This pattern matches characters that are allowed in names
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(trimmedValue)) return false;
  
  // Additional validation rules
  // No consecutive apostrophes or hyphens
  if (/--['-]-/u.test(trimmedValue)) return false;
  
  // Can't start or end with apostrophe or hyphen
  if (/^[\'-]|[\'-]$/.test(trimmedValue)) return false;
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(trimmedValue)) return false;
  
  // Reject names that are just symbols or have too many special characters
  const letterCount = (trimmedValue.match(/\p{L}/gu) || []).length;
  const totalChars = trimmedValue.length;
  
  // Letters should make up at least 50% of the name
  if (letterCount / totalChars < 0.5) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Accepts correct prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(?:\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type pattern
  const isValidFormat = visaRegex.test(cleanValue) || 
                       mastercardRegex.test(cleanValue) || 
                       amexRegex.test(cleanValue);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
