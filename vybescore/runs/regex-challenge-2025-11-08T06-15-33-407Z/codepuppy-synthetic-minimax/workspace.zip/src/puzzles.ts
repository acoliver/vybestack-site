/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary pattern for the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Convert to lowercase for comparison, but preserve original case in result
  const result: string[] = [];
  const seen = new Set<string>();
  
  for (const match of matches) {
    const lowerMatch = match.toLowerCase();
    
    // Check if it's in the exceptions list (case-insensitive)
    const isException = exceptions.some(exception => 
      exception.toLowerCase() === lowerMatch
    );
    
    if (!isException && !seen.has(lowerMatch)) {
      result.push(match);
      seen.add(lowerMatch);
    }
  }
  
  return result;
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds to find embedded tokens.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Debug: Let's check the actual input
  // text: 'xfoo 1foo foo', token: 'foo'
  // We need to find 'foo' after a digit but NOT at start
  
  // Simple approach: split by spaces and check each part
  const words = text.split(/\s+/);
  const result: string[] = [];
  
  for (const word of words) {
    // Check if word starts with digit followed by token
    if (/^\d+/.test(word) && word.includes(token)) {
      result.push(word);
    }
  }
  
  // Return unique occurrences only
  return [...new Set(result)];
}

/**
 * Validates password strength according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // This pattern catches any 2+ character sequence that repeats immediately
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  // Alternative regex approach for catching repeated patterns like abab, abcabc
  const repeatedPatternRegex = /(..+?)\1+/;
  if (repeatedPatternRegex.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns - match various IPv6 formats
  const ipv6Patterns = [
    // Full standard IPv6
    /\b(?:[0-9a-f]{1,4}:){7}[0-9a-f]{1,4}\b/gi,
    // IPv6 with :: compression
    /\b(?:[0-9a-f]{1,4}:){1,6}:\b/gi,
    /\b(?:[0-9a-f]{1,4}:){1,5}(?::[0-9a-f]{1,4}){1,2}\b/gi,
    /\b(?:[0-9a-f]{1,4}:){1,4}(?::[0-9a-f]{1,4}){1,3}\b/gi,
    /\b(?:[0-9a-f]{1,4}:){1,3}(?::[0-9a-f]{1,4}){1,4}\b/gi,
    /\b(?:[0-9a-f]{1,4}:){1,2}(?::[0-9a-f]{1,4}){1,5}\b/gi,
    /\b[0-9a-f]{1,4}:(?:(?::[0-9a-f]{1,4}){1,6})\b/gi,
    // IPv6 with :: at start or end
    /\b::(?:(?:[0-9a-f]{1,4}:){0,5}[0-9a-f]{1,4})?\b/gi,
    // Special IPv6 addresses
    /\b::1\b/gi,
    /\b::\b/gi
  ];
  
  // Check if any IPv6 pattern matches
  let hasIPv6Match = false;
  for (const pattern of ipv6Patterns) {
    pattern.lastIndex = 0; // Reset regex state
    if (pattern.test(value)) {
      hasIPv6Match = true;
      break;
    }
  }
  
  if (!hasIPv6Match) return false;
  
  // Make sure it's not actually an IPv4 address
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  const trimmedValue = value.trim();
  
  // If it's pure IPv4, return false
  if (ipv4Regex.test(trimmedValue)) return false;
  
  // If it contained IPv6 patterns, return true
  return hasIPv6Match;
}