/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences, collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, normalize spacing - collapse multiple spaces to single space
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Insert single space after sentence endings
  let withProperSpacing = normalized.replace(/([.!?])(["'|»\]}]\s*)([A-Z])/g, '$1$2 $3');
  withProperSpacing = withProperSpacing.replace(/([.!?])\s*([A-Z])/g, '$1 $2');
  
  // Now capitalize first letter after sentence boundaries
  const result = withProperSpacing.replace(/([.!?]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize the very first character
  if (result.length > 0) {
    return result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL pattern that matches:
  // - http://, https://, ftp:// protocols
  // - www. without protocol
  // - domain names with various TLDs
  // - IP addresses
  // - ports, paths, query strings, fragments
  // - Common URL characters but excludes trailing punctuation
  
  const urlRegex = /\b(?:(?:https?|ftp):\/\/|www\.)[^\s<>"'`{}|\^`\[\](),]+(?:\.[a-zA-Z]{2,})+(?:\/[^\s<>"'`{}|\^`\[\](),.,;:!?]*)?\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove common trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?\)'"\]\}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https:// but be careful not to affect https://
  // Use word boundary or lookbehind to ensure we don't match within https://
  return text.replace(/\bhttps?:\/\//gi, (match) => {
    // If it's already https, don't change it
    if (match.toLowerCase() === 'https://') {
      return 'https://';
    }
    // If it's http, upgrade to https
    return 'https://';
  });
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https. Rewrites host when path begins with /docs/ unless path contains
 * dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Pattern to match URLs (including the upgrade and host rewrite)
  const urlPattern = /(https?:\/\/)([^\s\/]+)(\/[^\s]*)?/gi;
  
  const result = text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Only process example.com and its subdomains
    if (!host.includes('example.com')) {
      return secureProtocol + host + path;
    }
    
    // If the original protocol was http, we want to rewrite to docs.example.com for docs paths
    if (protocol === 'http://' && path.startsWith('/docs/')) {
      // Check if we should skip host rewrite due to dynamic content
      // Look for cgi-bin, query strings, or legacy extensions
      const dynamicPatterns = [
        /cgi-bin/i,
        /[?&]/,  // Query strings
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i  // Legacy extensions
      ];
      
      const shouldSkipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));
      
      if (!shouldSkipHostRewrite) {
        // Change example.com to docs.example.com
        if (host === 'example.com') {
          host = 'docs.example.com';
        } else if (host.endsWith('.example.com')) {
          // For subdomains, convert sub.example.com to sub.docs.example.com
          const subdomain = host.split('.')[0];
          host = `${subdomain}.docs.example.com`;
        }
      }
    }
    
    return secureProtocol + host + path;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day range based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  
  const maxDays = month === 2 ? (isLeapYear ? 29 : 28) : daysInMonth[month - 1];
  
  if (day > maxDays) return 'N/A';
  
  return year;
}
