#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  // Skip 'node' and script path
  const flags = argv.slice(2);

  if (flags.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  // First arg should be the data file
  args.dataFile = flags[0];

  // Parse remaining flags
  let i = 1;
  while (i < flags.length) {
    const flag = flags[i];
    
    if (flag === '--format') {
      if (i + 1 >= flags.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      args.format = flags[i + 1];
      i += 2;
    } else if (flag === '--output') {
      if (i + 1 >= flags.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      args.output = flags[i + 1];
      i += 2;
    } else if (flag === '--includeTotals') {
      args.includeTotals = true;
      i += 1;
    } else {
      console.error(`Error: Unknown flag: ${flag}`);
      process.exit(1);
    }
  }

  if (!args.dataFile) {
    console.error('Error: Data file is required');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return args;
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf8');
    const data = JSON.parse(rawData) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label"');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry "${entry.label}": missing or invalid "amount"`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error.message.includes('JSON.parse')) {
        console.error('Error: Invalid JSON file');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to load data file');
    }
    process.exit(1);
  }
}

function getFormatter(format: string) {
  switch (format.toLowerCase()) {
    case 'markdown':
      return markdownFormatter;
    case 'text':
      return textFormatter;
    default:
      console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
      process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  const data = loadReportData(args.dataFile);
  const formatter = getFormatter(args.format);
  
  const options: RenderOptions = {
    includeTotals: args.includeTotals
  };
  
  const output = formatter.render(data, options);
  
  if (args.output) {
    try {
      writeFileSync(args.output, output);
    } catch (error) {
      console.error(`Error: Failed to write output file: ${args.output}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();