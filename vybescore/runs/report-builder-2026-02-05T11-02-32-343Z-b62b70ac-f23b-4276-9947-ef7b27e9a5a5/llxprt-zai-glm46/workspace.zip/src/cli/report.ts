#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData } from '../types.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  filePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2);
  let filePath = '';
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!filePath) {
      filePath = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!filePath) {
    throw new Error('Input file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { filePath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${i} has missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${i} has missing or invalid "amount" field (expected number)`
      );
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Validate format
    if (!(args.format in formatters)) {
      console.error(`Unsupported format: ${args.format}`);
      process.exit(1);
    }

    // Read and parse input file
    let content: string;
    try {
      content = fs.readFileSync(args.filePath, 'utf-8');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        console.error(`Error: File not found: ${args.filePath}`);
        process.exit(1);
      }
      throw error;
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(content);
    } catch (error) {
      console.error(`Error: Invalid JSON in file ${args.filePath}`);
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Render report
    const renderer = formatters[args.format];
    const output = renderer(reportData, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
