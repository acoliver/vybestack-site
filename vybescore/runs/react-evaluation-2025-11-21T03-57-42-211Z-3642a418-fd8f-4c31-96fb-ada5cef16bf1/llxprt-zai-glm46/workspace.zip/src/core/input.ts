/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

const allObservers: Set<Observer<unknown>> = new Set()

export function addObserver<T>(observer: Observer<T>): void {
  allObservers.add(observer as Observer<unknown>)
}

export function removeObserver<T>(observer: Observer<T>): void {
  allObservers.delete(observer as Observer<unknown>)
}

export function notifyObservers(): void {
  for (const observer of allObservers) {
    updateObserver(observer as Observer<unknown>)
  }
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof _equal === 'function' ? _equal : undefined
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    if (s.observer) updateObserver(s.observer as Observer<T>)
    notifyObservers()
    return s.value
  }

  return [read, write]
}