/**
 * Encode plain text to Base64.
 * Uses canonical RFC 4648 Base64 alphabet with required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if input contains only valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  // Check for valid Base64 characters: A-Z, a-z, 0-9, +, /, and =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Remove whitespace to handle inputs with spaces or newlines
  const cleanedInput = input.replace(/\s/g, '');
  
  if (!cleanedInput.length) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  if (!isValidBase64(cleanedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Normalize padding if missing
  let normalizedInput = cleanedInput;
  const padLength = normalizedInput.length % 4;
  if (padLength > 0) {
    normalizedInput = normalizedInput.padEnd(normalizedInput.length + (4 - padLength), '=');
  }

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
