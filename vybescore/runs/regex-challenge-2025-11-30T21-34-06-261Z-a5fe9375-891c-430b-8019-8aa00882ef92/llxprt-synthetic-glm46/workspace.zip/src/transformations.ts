/* eslint-disable no-useless-escape */
export function capitalizeSentences(text: string): string {
  // Early return for empty or single character text
  if (!text || text.length <= 1) {
    return text;
  }
  
  // First, ensure there's exactly one space after each sentence ending punctuation
  let processed = text.replace(/([.!?])(?=[^\s])/g, '$1 ');
  
  // Collapse multiple spaces into single spaces
  processed = processed.replace(/\s+/g, ' ');
  
  // Trim leading and trailing spaces
  processed = processed.trim();
  
  // Capitalize the first character of the first sentence
  processed = processed.charAt(0).toUpperCase() + processed.slice(1);
  
  // Capitalize after sentence endings, being careful about abbreviations
  // Split by sentence ending punctuation followed by space
  const sentences = processed.split(/([.!?]\s)/);
  
  for (let i = 0; i < sentences.length; i++) {
    // Check if this is a text part (not a punctuation part)
    if (i % 2 === 0) {
      continue;
    }
    
    // The next part is the start of a new sentence
    if (i + 1 < sentences.length && sentences[i + 1]) {
      sentences[i + 1] = sentences[i + 1].charAt(0).toUpperCase() + sentences[i + 1].slice(1);
    }
  }
  
  return sentences.join('');
}

export function extractUrls(text: string): string[] {
  // URL matching regex
  // Matches http(s):// followed by domain and optional path
  const urlPattern = /https?:\/\/([^\s/.\-]+\.[^\s/.\-]+)(\/[^\s]*)?/g;
  
  const matches = text.match(urlPattern);
  
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation like .,?! etc.
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.!?,'"\)\]\}]+$/, '');
  });
}

export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Negative lookahead to avoid double-converting https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  const processed = enforceHttps(text);
  
  // Pattern to match URLs
  const urlPattern = /(https?:\/\/)([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/[^\s]*)?/g;
  
  return processed.replace(urlPattern, (match, protocol, host, path) => {
    if (!path) {
      // No path, just upgrade protocol
      return `https://${host}`;
    }
    
const skipPaths = /(?:cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|\.html?|[?&=])/i;
    
    if (skipPaths.test(path)) {
      // Skip host rewrite, but still upgrade protocol
      return `https://${host}${path}`;
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite host to docs.domain.com
      const docsHost = host.startsWith('www.') ? 
        host.replace('www.', 'docs.') : 
        `docs.${host}`;
      return `https://${docsHost}${path}`;
    }
    
    // Just upgrade protocol
    return `https://${host}${path}`;
  });
}

export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Return as string
  
  // Validate month/day combinations
  const monthDays = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year in February
  if (month === 2) {
    const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
    const maxDays = isLeapYear ? 29 : 28;
    
    if (day < 1 || day > maxDays) {
      return 'N/A';
    }
  } else if (day < 1 || day > monthDays[month]) {
    return 'N/A';
  }
  
  return year;
}
