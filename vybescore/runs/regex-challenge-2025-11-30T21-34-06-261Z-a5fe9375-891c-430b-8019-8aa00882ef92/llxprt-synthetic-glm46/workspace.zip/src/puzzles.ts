/* eslint-disable no-useless-escape */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words starting with the prefix
  // \b ensures we're matching whole words
  // \w* matches the rest of the word
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'g');
  
  // Find all matches
  const matches = text.match(wordPattern);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions and return unique words
  return Array.from(new Set(
    matches.filter(word => !exceptions.includes(word))
  ));
}

export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find occurrences of the token that appear after a digit
  // The token should be preceded by a digit directly (no space)
  // Not at the start of the string (must have something before it)
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  return text.match(tokenPattern) || [];
}

export function isStrongPassword(value: string): boolean {
  // Check minimum length: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':``,.<>\/]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab", "abcabc"
  // This checks for any repeating sequence of 2 or more characters
  const repeatedSequenceRegex = /(.{2,})\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  // Also check for specific case of repeating characters (like "aa", "bbb")
  const repeatingCharsRegex = /(.)\1{1,}/;
  if (repeatingCharsRegex.test(value)) {
    return false;
  }
  
  return true;
}

export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6Regex = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Compressed format with :: shorthand
  const compressedIPv6Regex = /^([0-9a-fA-F]{1,4}:){0,7}:([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}$/;
  
  // More precise patterns for IPv6 with :: shorthand
  const ipv6WithShorthandRegex = /(([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
  
  // Pattern that finds IPv6 within text
  const anyIPv6Regex = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}(?:::[0-9a-fA-F]{1,4})?/;
  
  // First, check if the string contains IPv6
  const hasIPv6 = anyIPv6Regex.test(value);
  if (!hasIPv6) {
    return false;
  }
  
  // Create a simplified check to avoid overly complex regex
  // Check if it's a valid IPv6 address but not an IPv4
  const isIPv6 = fullIPv6Regex.test(value) || 
                 compressedIPv6Regex.test(value) ||
                 ipv6WithShorthandRegex.test(value) ||
                 value.includes('::'); // Simplified check for shorthand notation
  
  // IPv4 detection
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  const hasIPv4 = ipv4Regex.test(value);
  
  // If it has IPv4, it might be an IPv4-mapped IPv6 address
  // For this challenge, we'll return true for IPv6-mapped IPv4 addresses
  // but not for pure IPv4 addresses
  if (hasIPv4 && !isIPv6) {
    return false;
  }
  
  return isIPv6 || value.includes('::');
}
