/* eslint-disable no-useless-escape */
export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

export function isValidEmail(value: string): boolean {
  // RFC 5322 email validation with some practical limitations
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@(?!\.)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,63}$/;
  
  // Early rejection for common invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US phone)
  if (digits.length < 10) {
    return false;
  }
  
  // Extract area code (first 3 digits), considering optional +1 country code
  const withoutCountryCode = digits.startsWith('1') ? digits.slice(1) : digits;
  
  // Check area code (first 3 digits), area codes can't start with 0 or 1
  const areaCode = withoutCountryCode.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if the number has valid length (10 digits, possibly with country code)
  const hasCountryCode = digits.length === 11 && digits.startsWith('1');
  const isStandardLength = digits.length === 10;
  
  if (!isStandardLength && !hasCountryCode) {
    return false;
  }
  
  // Check extensions if allowed
  if (options?.allowExtensions) {
    const extensionPattern = /\d+/;
    return extensionPattern.test(value);
  }
  
  return true;
}

export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for country code +54
  const hasCountryCode = digits.startsWith('54');
  const withoutCountryCode = hasCountryCode ? digits.slice(2) : digits;
  
  // Check for trunk prefix 0
  const hasTrunkPrefix = withoutCountryCode.startsWith('0');
  const digitsWithoutPrefix = hasTrunkPrefix ? withoutCountryCode.slice(1) : withoutCountryCode;
  
  // Check for mobile indicator 9 (only if trunk prefix was present or country code was present)
  const remainingDigits = digitsWithoutPrefix;
  const hasMobileIndicator = hasTrunkPrefix && digitsWithoutPrefix.startsWith('9') ||
                            hasCountryCode && !hasTrunkPrefix && withoutCountryCode.startsWith('9');
  
  // Validate mobile pattern - ensure mobile indicator is correctly positioned
  if (hasMobileIndicator && !hasTrunkPrefix && !hasCountryCode) {
    return false;
  }
  
  // Area code must be 2-4 digits (leading digit 1-9)
  if (remainingDigits.length < 2) {
    return false;
  }
  
  let areaCode = '';
  let subscriberNumber = '';
  
  // Try 4-digit area code first
  if (remainingDigits.length >= 6 && remainingDigits.length <= 12) {
    // Valid subscriber number length is 6-8 digits
    for (let i = 2; i <= 4; i++) {
      const potentialAreaCode = remainingDigits.slice(0, i);
      if (/^[1-9]/.test(potentialAreaCode)) { // Area code starts with 1-9
        const potentialSubscriber = remainingDigits.slice(i);
        if (potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
          areaCode = potentialAreaCode;
          subscriberNumber = potentialSubscriber;
          break;
        }
      }
    }
    
    if (areaCode && subscriberNumber) {
      return true;
    }
  }
  
  return false;
}

export function isValidName(value: string): boolean {
  // Allow Unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and unconventional names
  const nameRegex = /^[a-zA-Z\u00C0-\u017F-'\s]+$/;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for digits or unusual symbols
  if (/\d|[^\w\s\'\-\u00C0-\u017F]/.test(value)) {
    return false;
  }
  
  return true;
}

// Helper function for Luhn checksum validation
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.substring(i, i + 1), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = 1 + (digit % 10);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Check if input is in a valid format
  const digits = value.replace(/\D/g, '');
  
  // Check length: Visa/Mastercard typically 13-19 digits, AmEx is 15 digits
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check prefixes
  // Visa: starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  // Mastercard: starts with 51-55, or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:22(?:[2-9]\d|[3-6]\d\d|7(?:[01]\d|20)))\d{12}$/;
  // AmEx: starts with 34 or 37 and is 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  const isVisa = visaRegex.test(digits);
  const isMastercard = mastercardRegex.test(digits);
  const isAmex = amexRegex.test(digits);
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(value);
}