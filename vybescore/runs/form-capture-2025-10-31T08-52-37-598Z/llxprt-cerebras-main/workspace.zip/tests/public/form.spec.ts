import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { app, server } from '../../src/server.js';
import { initDatabase } from '../../src/db.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Ensure database is initialized before tests
  await initDatabase();
  
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(app).get('/');
    expect(res.status).toBe(200);
    
    // Simple check for form elements without using cheerio
    expect(res.text).toContain('firstName');
    expect(res.text).toContain('lastName');
    expect(res.text).toContain('streetAddress');
    expect(res.text).toContain('city');
    expect(res.text).toContain('stateProvince');
    expect(res.text).toContain('postalCode');
    expect(res.text).toContain('country');
    expect(res.text).toContain('email');
    expect(res.text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    const res = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: 'SW1A 1AA', // UK postal code format
        country: 'United Kingdom',
        email: 'john.doe@example.com',
        phone: '+44 20 7946 0958' // UK phone format
      });
    
    expect(res.status).toBe(302);
    expect(res.header.location).toBe('/thank-you');
    
    // Verify data was saved to database
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});