import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get __dirname in ES module scope
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Ensure data directory exists
const dataDir = path.resolve(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

// Database file path
const dbPath = path.resolve(dataDir, 'submissions.sqlite');

// Initialize database
let db: Database | null = null;

export async function initDatabase() {
  // Use local WASM file instead of CDN for testing compatibility
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.resolve(__dirname, '../node_modules/sql.js/dist/', file)
  });

  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    db.run(`CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      street_address TEXT NOT NULL,
      city TEXT NOT NULL,
      state_province TEXT NOT NULL,
      postal_code TEXT NOT NULL,
      country TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );`);
    saveDatabase();
  }
  
  return db;
}

export function saveDatabase() {
  if (db) {
    const buffer = db.export();
    fs.writeFileSync(dbPath, buffer);
  }
}

export function closeDatabase() {
  if (db) {
    db.close();
    db = null;
  }
}

export { db };