import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase, saveDatabase, closeDatabase, db } from './db.js';

// Initialize database
await initDatabase();

const app = express();
const port = process.env.PORT || 3000;

// Get __dirname in ES module scope
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates')); // Point to src/templates instead of dist

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

// Validation function
function validateFields(body: { [key: string]: string }) {
  const errors: string[] = [];
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!body[field] || body[field].trim() === '') {
      errors.push(`${field.replace(/([A-Z])/g, ' $1')} is required`);
    }
  });

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (body.email && !emailRegex.test(body.email)) {
    errors.push('Email must be valid');
  }

  // Phone validation (allow international formats)
  const phoneRegex = /^[+\d\s\-()]+$/;
  if (body.phone && !phoneRegex.test(body.phone)) {
    errors.push('Phone number format is invalid');
  }

  // Postal code validation (allow alphanumeric formats with dash and space)
  const postalCodeRegex = /^[A-Za-z\d\s-]+$/;
  if (body.postalCode && !postalCodeRegex.test(body.postalCode)) {
    errors.push('Postal code format is invalid');
  }

  return errors;
}

app.post('/submit', (req: Request, res: Response) => {
  const errors = validateFields(req.body);

  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: req.body
    });
  }

  // Insert into database
  const stmt = db!.prepare(`INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);
  
  stmt.run([
    req.body.firstName,
    req.body.lastName,
    req.body.streetAddress,
    req.body.city,
    req.body.stateProvince,
    req.body.postalCode,
    req.body.country,
    req.body.email,
    req.body.phone
  ]);
  
  stmt.free();
  saveDatabase();

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Fetch the most recent submission to get the user's first name
  const result = db!.exec("SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1");
  const firstName = result.length > 0 ? result[0].values[0][0] as string : 'Friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, closing server...');
  closeDatabase();
  process.exit(0);
});

const server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});

export { app, server };