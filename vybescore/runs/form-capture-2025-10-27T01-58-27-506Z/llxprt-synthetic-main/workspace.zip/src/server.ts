import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database as SQLiteDatabase } from 'sql.js';

declare interface Statement {
  run(...params: unknown[]): unknown;
  free(): void;
}

// Augment the sql.js module with type definitions since @types/sql.js is not available
declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: new(data?: ArrayBuffer) => Database;
  }

  export default function initSqlJs(options?: Record<string, unknown>): Promise<SqlJsStatic>;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Initialize SQLite database
let db: SQLiteDatabase | null = null;
const initializeDatabase = async (): Promise<SQLiteDatabase> => {
  const SQL = await initSqlJs();
  
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Load existing database or create a new one
  let dbInit: SQLiteDatabase;
  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    dbInit = new SQL.Database(fileBuffer.buffer);
    console.log('Loaded existing database');
  } else {
    dbInit = new SQL.Database();
    console.log('Created new database');
    
    // Read and execute the schema
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    dbInit.run(schema);
  }
  
  return dbInit;
};

// Helper function to save the database
const saveDatabase = (): void => {
  if (db) {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  }
};

// Helper function to validate email
const isValidEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

// Helper function to validate phone number
const isValidPhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[0-9\s()\-.]+$/;
  return phoneRegex.test(phone);
};

// Helper function to validate postal code
const isValidPostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
};

// Helper function to validate form data
const validateFormData = (data: Record<string, string>): { errors: string[]; valid: boolean } => {
  const errors: string[] = [];
  
  // Check required fields
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
      errors.push(`${fieldName} is required`);
    }
  }
  
  // Validate email
  if (data.email && !isValidEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Validate phone number
  if (data.phone && !isValidPhone(data.phone)) {
    errors.push('Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading +)');
  }
  
  // Validate postal code
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  return {
    errors,
    valid: errors.length === 0
  };
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const { errors, valid } = validateFormData(req.body as Record<string, string>);
  
  if (!valid) {
    return res.render('form', {
      errors,
      values: req.body
    });
  }
  
  if (!db) {
    return res.status(500).send('Database not initialized');
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    ]);
    
    stmt.free();
    
    // Save the database
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(req.body.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('An error occurred while saving your submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName || 'friend';
  res.render('thank-you', { firstName });
});

// Initialize and start the server
const startServer = async (): Promise<void> => {
  try {
    db = await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle graceful shutdown
    const gracefulShutdown = (signal: string): void => {
      console.log(`Received ${signal}. Shutting down gracefully.`);
      server.close(() => {
        console.log('Express server closed.');
        if (db) {
          db.close();
          console.log('Database connection closed.');
        }
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
