declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...params: unknown[]): unknown;
    free(): void;
  }

  export interface SqlJsStatic {
    Database: new(data?: ArrayBuffer) => Database;
  }

  export default function initSqlJs(options?: Record<string, unknown>): Promise<SqlJsStatic>;
}