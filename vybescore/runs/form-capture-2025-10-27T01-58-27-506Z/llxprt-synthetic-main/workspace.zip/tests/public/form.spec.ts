import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import { exec } from 'child_process';
import { promisify } from 'util';
import fs from 'node:fs';
import path from 'node:path';

const execAsync = promisify(exec);
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server by importing the compiled server
  try {
    const { stdout, stderr } = await execAsync('npm run build');
    console.log('Build output:', stdout);
    if (stderr) console.error('Build error:', stderr);
    
    // Import the compiled server
    await import('../../dist/server.js');
    // The server is started in the module automatically
  } catch (error) {
    console.error('Failed to start server:', error);
  }
});

afterAll(async () => {
  // The server should be closed automatically by SIGTERM
  try {
    await execAsync('pkill -f "node.*dist/server.js"');
  } catch (error) {
    console.error('Error stopping server:', error);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
