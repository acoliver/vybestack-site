/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  addDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Set up equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    // Always consider values different if equal === false
    equalFn = () => false
  }
  // If equal === true or undefined, use default equality (Object.is)
  
  const s: Subject<T> = {
    name: options?.name,
    observers: [], // Track multiple observers
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this observer as a dependent of this input
      addDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    // Check equality
    const isSame = s.equalFn ? s.equalFn(oldValue, s.value) : Object.is(oldValue, s.value)
    if (isSame) {
      return s.value
    }
    // Notify all observers
    if (s.observers) {
      for (const observer of s.observers) {
        // Re-execute the update function for each observer
        updateObserver(observer as Observer<unknown>)
      }
    }
    return s.value
  }

  return [read, write]
}