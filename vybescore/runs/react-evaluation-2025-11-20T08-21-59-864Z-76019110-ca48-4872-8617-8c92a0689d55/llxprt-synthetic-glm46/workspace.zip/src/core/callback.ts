/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver, removeObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false,
  }
  
  // Execute the callback function to establish dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    observer.disposed = true
    
    // Remove observer from all dependencies
    if (observer.dependencies) {
      for (const dependency of observer.dependencies) {
        removeObserver(dependency, observer as ObserverR)
      }
    }
  }
}