/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  getActiveObserver,
  setActiveObserver,
  addDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
  }
  
  // Don't initialize value here - wait for first read
  
  // Return getter function that tracks dependencies
  const getter: GetterFn<T> = (): T => {
    if (o.disposed && o.value !== undefined) return o.value
    
    const observer = getActiveObserver()
    if (observer) {
      // This computed is a dependency of another observer
      // Add this computed as a dependency
      addDependency(observer as Observer<unknown>, o as ObserverR)
      
      // If value hasn't been computed yet, compute it now
      if (o.value === undefined) {
        const previousObserver = getActiveObserver()
        setActiveObserver(o as ObserverR)
        try {
          o.value = o.updateFn(o.value)
        } finally {
          setActiveObserver(previousObserver)
        }
      }
      
      return o.value!
    } else {
      // When computed is read directly, execute it to update dependencies
      const previousObserver = getActiveObserver()
      // Set this computed as the active observer to track its dependencies
      setActiveObserver(o as ObserverR)
      try {
        o.value = o.updateFn(o.value)
      } finally {
        // Restore previous observer
        setActiveObserver(previousObserver)
      }
      return o.value!
    }
  }
  
  return getter
}