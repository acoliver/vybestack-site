/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observers?: ObserverR[] // Track observers of this observer
  dependencies?: ObserverR[] // Track dependencies of this observer
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  disposed?: boolean // Flag for cleanup
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: ObserverR[] // Track observers of this subject
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.disposed) return
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Notify all observers of this observer
  if (observer.observers) {
    for (const dependent of observer.observers) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
}

// Function to add a dependency relationship
export function addDependency(observer: ObserverR, dependency: ObserverR): void {
  if (!dependency.observers) {
    dependency.observers = []
  }
  if (!dependency.observers.includes(observer)) {
    dependency.observers.push(observer)
  }
  
  if (!observer.dependencies) {
    observer.dependencies = []
  }
  if (!observer.dependencies.includes(dependency)) {
    observer.dependencies.push(dependency)
  }
}

// Function to remove an observer
export function removeObserver(observer: ObserverR, dependent: ObserverR): void {
  if (observer.observers) {
    const index = observer.observers.indexOf(dependent)
    if (index !== -1) {
      observer.observers.splice(index, 1)
    }
  }
  
  if (dependent.dependencies) {
    const index = dependent.dependencies.indexOf(observer)
    if (index !== -1) {
      dependent.dependencies.splice(index, 1)
    }
  }
}