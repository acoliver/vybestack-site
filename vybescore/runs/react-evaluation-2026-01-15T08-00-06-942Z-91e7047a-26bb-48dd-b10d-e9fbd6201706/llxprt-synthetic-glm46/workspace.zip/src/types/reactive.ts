/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers?: Set<ObserverR>  // Support multiple observers
  
  // Add global tracking for callback cleanup
  trackedCallbacks?: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global registry for tracking when a value changes
export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observers) {
    // Create a copy of the observers to iterate over
    // But we only need to trigger updates if the value changed
    for (const observer of subject.observers) {
      // Use type assertion to bypass strict type checking for this internal API
      updateObserver(observer as Observer<unknown>)
    }
  } else if (subject.observer) {
    // Use type assertion to bypass strict type checking for this internal API
    updateObserver(subject.observer as Observer<unknown>)
  }
}

// Global registry for callbacks to enable unsubscribe functionality
const callbackRegistry = new Map<Observer<unknown>, Set<Subject<unknown>>>()

// Track dependencies for callbacks
export function trackCallback<T>(callback: Observer<T>, subject: Subject<T>): void {
  if (!callbackRegistry.has(callback as Observer<unknown>)) {
    callbackRegistry.set(callback as Observer<unknown>, new Set())
  }
  callbackRegistry.get(callback as Observer<unknown>)!.add(subject as Subject<unknown>)
}

// Remove callback from all tracked subjects
export function untrackCallback<T>(callback: Observer<T>): void {
  const subjects = callbackRegistry.get(callback as Observer<unknown>)
  if (subjects) {
    for (const subject of subjects) {
      if (subject.observers) {
        subject.observers.delete(callback as Observer<unknown>)
        if (subject.observers.size === 0) {
          delete subject.observers
        }
      }
    }
    callbackRegistry.delete(callback as Observer<unknown>)
  }
}
