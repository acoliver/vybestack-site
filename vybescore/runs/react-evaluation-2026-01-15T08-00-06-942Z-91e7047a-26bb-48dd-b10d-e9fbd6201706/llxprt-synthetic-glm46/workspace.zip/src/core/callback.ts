/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, untrackCallback } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
  }
  
  // Initialize the callback by tracking any dependencies
  // The callback's update function will execute when any dependency changes
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this callback from all tracked subjects
    untrackCallback(observer)
    
    // Clear references to prevent memory leaks
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
