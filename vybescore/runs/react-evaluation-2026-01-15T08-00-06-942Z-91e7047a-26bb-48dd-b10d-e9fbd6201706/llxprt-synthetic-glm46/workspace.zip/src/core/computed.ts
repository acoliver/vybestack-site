/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  notifyObservers,
  getActiveObserver,
  ObserverR,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Store dependencies that this computed observer depends on
  const subjectDependencies = new Set<Subject<unknown>>()
  
  const o: Observer<T> = {
    name: options?.name || 'computed',
    value,
    updateFn: (currentVal?: T) => {
      // When computed needs to update, mark all its dependencies as watching this computed
      subjectDependencies.clear()
      
      // Set this observer as active so dependencies will track it
      const result = updateFn(currentVal)
      
      // Update the stored value
      o.value = result
      
      // Notify all observers of this computed value that it changed
      notifyObservers(computedSubject)
      
      return result
    },
  }
  
  // Create a subject for this computed value so other observers can depend on it
  const computedSubject = {
    value: o.value,
    observers: new Set<ObserverR>(),
    observer: undefined,
  }
  
  // Initialize computed value (this will register dependencies)
  updateObserver(o)
  
  // Return getter function that recomputes if needed and allows tracking
  return (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      if (!computedSubject.observers) {
        computedSubject.observers = new Set<ObserverR>()
      }
      computedSubject.observers.add(activeObserver)
    }
    
    return o.value!
  }
}
