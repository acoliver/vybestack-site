/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  trackCallback,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR,
  Observer
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Parse equal parameter
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false || _equal === undefined) {
    equalFn = undefined
  } else {
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
// Support multiple observers using a Set
      if (!s.observers) {
        s.observers = new Set<ObserverR>()
      }
      s.observers.add(activeObserver)
      // Also track the observer for update notifications
      s.observer = activeObserver
      
      if (activeObserver.name === 'callback') {
        trackCallback(activeObserver as Observer<T>, s)
      }
      
      
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if the value should be updated
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Trigger observer updates through the notification system
    // This ensures reactive updates propagate through the system
    notifyObservers(s)
    
    return s.value
  }

  return [read, write]
}
