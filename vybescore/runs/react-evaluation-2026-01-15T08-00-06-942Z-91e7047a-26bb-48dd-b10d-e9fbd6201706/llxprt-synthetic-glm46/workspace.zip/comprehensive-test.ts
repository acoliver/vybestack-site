// Simulate the comprehensive test step by step
import { createInput, createComputed, createCallback } from './src/index.js'

// Test: compute cells can depend on other compute cells
console.log('=== Test 1: compute cells can depend on other compute cells ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  console.log('timesTwo recomputing, input=' + input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('timesThirty recomputing, input=' + input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('sum recomputing: timesTwo=' + timesTwo() + ', timesThirty=' + timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial sum:', sum()) // Should be 32
console.log('Setting input to 3...')
setInput(3)
console.log('After setInput, sum should be 96, actual:', sum()) // Should be 96 but likely not

// Test: compute cells fire callbacks
console.log('\n=== Test 2: compute cells fire callbacks ===')
const [input2, setInput2] = createInput(1)
console.log('Initial input2:', input2())

const output = createComputed(() => {
  console.log('output recomputing, input2=' + input2())
  return input2() + 1
})

let value = 0
let callbackCalled = false
createCallback(() => {
  callbackCalled = true
  value = output()
  console.log('callback fired, set value to', value)
})

console.log('Initial callback result:', value) // Should be 2
console.log('Setting input2 to 3...')
setInput2(3)
console.log('After setInput2, expected value=4, actual value=' + value) // Should be 4 but likely 2

// Test: callbacks can be added and removed
console.log('\n=== Test 3: callbacks can be added and removed ===')
const [input3, setInput3] = createInput(11)
console.log('Initial input3:', input3())

const output3 = createComputed(() => {
  console.log('output3 recomputing, input3=' + input3())
  return input3() + 1
})

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log('callback1 fired, value=' + output3())
  values1.push(output3())
})

const values2 = []
createCallback(() => {
  console.log('callback2 fired, value=' + output3())
  values2.push(output3())
})

console.log('Before setInput3(31), values1.length=' + values1.length + ', values2.length=' + values2.length)
setInput3(31)
console.log('After setInput3(31), values1.length=' + values1.length + ', values2.length=' + values2.length)

unsubscribe1()
console.log('Unsubscribed callback1')
setInput3(41)
console.log('After second setInput3(41), values1.length=' + values1.length + ', values2.length=' + values2.length)