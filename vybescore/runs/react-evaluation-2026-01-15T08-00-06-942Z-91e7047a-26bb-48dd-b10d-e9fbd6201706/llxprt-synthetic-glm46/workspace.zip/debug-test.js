/**
 * Simple reactive programming system test with manual tracking
 */

import { createInput, createComputed, createCallback } from '../src/index.js'

// Test 1: compute cells can depend on other compute cells
console.log('Test 1: compute cells can depend on other compute cells')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum: ' + sum() + ' (expected: 32)')
setInput(3)
console.log('Updated sum: ' + sum() + ' (expected: 96)')

// Test 2: compute cells fire callbacks
console.log('\nTest 2: compute cells fire callbacks')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => (value = output()))

console.log('Initial: ' + value + ' (expected: 2)')
setInput2(3)
console.log('After setInput2(3): ' + value + ' (expected: 4)')

// Test 3: callbacks can be added and removed
console.log('\nTest 3: callbacks can be added and removed')
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => values1.push(output3()))
const values2: number[] = []
createCallback(() => values2.push(output3()))

console.log('Before setInput3(31): values1=' + values1.length + ', values2=' + values2.length + ' (expected: >0, >0)')
setInput3(31)
console.log('After setInput3(31): values1=' + values1.length + ', values2=' + values2.length + ' (expected: >0, >0)')

unsubscribe1()
console.log('After unsubscribe1(): values1=' + values1.length + ', values2=' + values2.length + ' (values1 count should not change)')

setInput3(41)
console.log('After setInput3(41): values1=' + values1.length + ', values2=' + values2.length + ' (values1 should equal before, values2 should increase)')