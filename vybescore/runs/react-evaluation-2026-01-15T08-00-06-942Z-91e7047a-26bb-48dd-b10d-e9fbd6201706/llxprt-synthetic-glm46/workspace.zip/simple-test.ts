/**
 * Simple reactive programming system test with manual tracking
 */

import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing manual dependency tracking...')

// Test basic reactive flow
const [input, setInput] = createInput(1)

// Add console.log to track when computed updates
const sum = createComputed(() => {
  console.log('sum recomputing: input=' + input())
  return input() + 1
})

console.log('Initial sum:', sum()) // Should be 2

let callbackCount = 0
const unsubscribe = createCallback(() => {
  callbackCount++
  console.log('callback executed, count=' + callbackCount + ', sum=' + sum())
})

console.log('Before setInput(3): callback count=' + callbackCount)
setInput(3)
console.log('After setInput(3): callback count=' + callbackCount + ', sum=' + sum())

console.log('\nTesting unsubscribe...')
unsubscribe()
callbackCount = 0
console.log('After unsubscribe, resetting...')
setInput(5)
console.log('After setInput(5): callback count=' + callbackCount)