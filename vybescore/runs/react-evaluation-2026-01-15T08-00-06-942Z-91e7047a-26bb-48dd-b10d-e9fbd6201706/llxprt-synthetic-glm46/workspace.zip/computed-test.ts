/**
 * Test with proper reactive pattern - computed depends on computed
 */

import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing computed dependency chain...')
const [input, setInput] = createInput(1)

// Track when each computed recomputes
const timesTwo = createComputed(() => {
  console.log('timesTwo recomputing: input=' + input())
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('timesThirty recomputing: input=' + input())
  return input() * 30
})

const sum = createComputed(() => {
  console.log('sum recomputing: timesTwo=' + timesTwo() + ', timesThirty=' + timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial sum:', sum()) // Should show all recomputing once, result 32
console.log('\nCalling setInput(3):')
setInput(3) // Should trigger cascade of updates
console.log('Final sum:', sum()) // Should be 96

// Test callback reactivity
console.log('\nTesting callback reactivity...')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => {
  console.log('output recomputing: input2=' + input2())
  return input2() + 1
})

let callbackCalled = false
createCallback(() => {
  callbackCalled = true
  console.log('callback executed, output=' + output())
})

console.log('Calling setInput2(3):')
setInput2(3)
console.log('Callback was called:', callbackCalled)