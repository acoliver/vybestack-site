/**
 * Test with explicit recompute pattern
 */

import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing with manual recompute...')

// Track what should be computed when input changes
const [input, setInput] = createInput(1)

// Basic computed that should react to input changes
const doubling = createComputed(() => {
  console.log('doubling recomputing: input=' + input())
  return input() * 2
})

console.log('Initial doubling:', doubling()) // Should be 2

// The issue is that when we call setInput, the computed doesn't automatically recompute
// We need to force recompute when dependencies change
console.log('Calling setInput(3):')
setInput(3)
console.log('After setInput, doubling value:', doubling()) // Should be 6 but is likely 2

// If the value didn't change, it confirms our recompute notification is broken