import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';

describe('friendly form (public smoke)', () => {
  let server: http.Server;
  let baseUrl: string;

  beforeAll(async () => {
    // Clean up any existing test databases
    const dbPath = path.resolve('data', 'submissions.sqlite');
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Import the app and create a test server
    const { default: app } = await import('../../src/server.js');
    
    // Create test server
    server = http.createServer(app);
    
    // Start server on 127.0.0.1 to avoid IPv6 issues
    await new Promise<void>((resolve, reject) => {
      server.listen(0, '127.0.0.1', (err?: Error) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    });
    
    // Get the actual port assigned
    const address = server.address();
    baseUrl = `http://127.0.0.1:${address.port}`;
    
    console.log('Test server started successfully');
  }, 10000);

  afterAll(async () => {
    // Close server
    if (server) {
      server.close();
    }
    
    // Clean up any test databases
    const cleanupPaths = [path.resolve('data', 'submissions.sqlite')];
    for (const dbFile of cleanupPaths) {
      if (fs.existsSync(dbFile)) {
        fs.unlinkSync(dbFile);
        console.log(`Cleaned up: ${dbFile}`);
      }
    }
  });

  it('renders the form with all fields', async () => {
    try {
      const response = await request(baseUrl)
        .get('/')
        .expect(200);
      
      const responseText = response.text;
      
      // Check for form fields with flexible matching
      expect(responseText).toContain('name="firstName"');
      expect(responseText).toContain('name="lastName"');
      expect(responseText).toContain('name="streetAddress"');
      expect(responseText).toContain('name="city"');
      expect(responseText).toContain('name="stateProvinceRegion"');
      expect(responseText).toContain('name="postalCode"');
      expect(responseText).toContain('name="country"');
      expect(responseText).toContain('name="email"');
      expect(responseText).toContain('name="phoneNumber"');
      
      // Check that form method is POST (case insensitive)
      expect(responseText).toMatch(/method\s*=\s*["']POST["']/i);
      expect(responseText).toContain('action="/submit"');
    } catch (error) {
      console.error('Form rendering test failed:', error);
      throw error;
    }
  });

  it('persists submission and redirects', async () => {
    try {
      const submissionData = {
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvinceRegion: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phoneNumber: '+1 555-123-4567'
      };
      
      const response = await request(baseUrl)
        .post('/submit')
        .send(submissionData)
        .expect(302);
      
      expect(response.headers.location).toBe('/thank-you');
      
      // Check that database file was created
      const dbPath = path.resolve('data', 'submissions.sqlite');
      expect(fs.existsSync(dbPath)).toBe(true);
    } catch (error) {
      console.error('Submission test failed:', error);
      throw error;
    }
  });

  it('shows thank-you page after submission', async () => {
    try {
      const response = await request(baseUrl)
        .get('/thank-you')
        .expect(200);
      
      const responseText = response.text;
      
      // Check for thank-you content
      expect(responseText).toContain('Thank You!');
      expect(responseText).toContain('Did you really just give your personal information to a stranger on the internet?');
    } catch (error) {
      console.error('Thank you page test failed:', error);
      throw error;
    }
  });

  it('validates required fields', async () => {
    try {
      const response = await request(baseUrl)
        .post('/submit')
        .send({
          firstName: '',
          lastName: 'Doe'
        })
        .expect(400);
      
      const responseText = response.text;
      
      // Should show form again with errors
      expect(responseText).toContain('name="firstName"');
      expect(responseText).toContain('error-message');
      expect(responseText).toContain('is required');
    } catch (error) {
      console.error('Validation test failed:', error);
      throw error;
    }
  });
});
