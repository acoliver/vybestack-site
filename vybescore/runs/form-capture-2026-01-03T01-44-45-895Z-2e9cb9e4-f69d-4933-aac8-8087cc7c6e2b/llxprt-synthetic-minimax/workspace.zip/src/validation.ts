export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvinceRegion?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phoneNumber?: string;
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const phoneRegex = /^\+?[\d\s\-()]+$/;

const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;

export function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvinceRegion.trim()) {
    errors.stateProvinceRegion = 'State/Province/Region is required';
  }

  if (!data.postalCode.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!postalCodeRegex.test(data.postalCode.trim())) {
    errors.postalCode = 'Postal code must contain only letters, numbers, spaces, and dashes';
  }

  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email.trim()) {
    errors.email = 'Email is required';
  } else if (!emailRegex.test(data.email.trim())) {
    errors.email = 'Email format is invalid';
  }

  if (!data.phoneNumber.trim()) {
    errors.phoneNumber = 'Phone number is required';
  } else if (!phoneRegex.test(data.phoneNumber.trim())) {
    errors.phoneNumber = 'Phone number format is invalid';
  }

  return errors;
}

export function hasValidationErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}