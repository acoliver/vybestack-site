import express, { Request, Response } from 'express';
import * as path from 'path';
import DatabaseManager from './database';
import { validateForm, hasValidationErrors, FormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Initialize database
const dbManager = new DatabaseManager();

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Us',
    errors: {},
    values: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phoneNumber || ''
    };

    // Validate form data
    const errors = validateForm(formData);

    if (hasValidationErrors(errors)) {
      // Re-render form with errors and values
      res.status(400).render('form', {
        title: 'Contact Us',
        errors,
        values: formData
      });
      return;
    }

    // Save to database
    await dbManager.saveSubmission(formData);

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      title: 'Contact Us',
      errors: { general: 'An error occurred while processing your request. Please try again.' },
      values: req.body
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Function to start server (exported for testing)
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start server only if this file is run directly (not imported)
if (require.main === module) {
  startServer();
}

export default app;
export { startServer };
