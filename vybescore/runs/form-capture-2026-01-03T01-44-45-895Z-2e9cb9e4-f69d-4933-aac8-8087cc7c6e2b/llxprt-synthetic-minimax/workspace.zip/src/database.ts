import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface ContactSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private readonly dbPath: string;
  private readonly schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      this.sqlJs = await initSqlJs();
      
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const fileContents = fs.readFileSync(this.dbPath);
        this.db = new this.sqlJs.Database(fileContents);
      } else {
        this.db = new this.sqlJs.Database();
        await this.createSchema();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const schemaSql = fs.readFileSync(this.schemaPath, 'utf8');
      this.db.exec(schemaSql);
      console.log('Database schema created successfully');
    } catch (error) {
      console.error('Failed to create database schema:', error);
      throw error;
    }
  }

  async saveSubmission(submission: ContactSubmission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province_region, postal_code, country, email, phone_number
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        submission.firstName,
        submission.lastName,
        submission.streetAddress,
        submission.city,
        submission.stateProvinceRegion,
        submission.postalCode,
        submission.country,
        submission.email,
        submission.phoneNumber
      ]);

      stmt.free();
      
      // Get the last inserted row ID
      const result = this.db.exec("SELECT last_insert_rowid() as id");
      const rowId = result[0].values[0][0] as number;
      
      // Save the database to file
      await this.saveToFile();
      
      console.log(`Submission saved with ID: ${rowId}`);
      return rowId;
    } catch (error) {
      console.error('Failed to save submission:', error);
      throw error;
    }
  }

  async saveToFile(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database to file:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
      console.log('Database connection closed');
    }
  }
}

export default DatabaseManager;