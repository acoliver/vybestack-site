import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationOptions(options: { page?: number; limit?: number }): { page: number; limit: number } {
  const { page, limit } = options;

  if (page !== undefined) {
    if (isNaN(page) || !Number.isInteger(page)) {
      throw new ValidationError('Invalid page: must be an integer');
    }
    if (page < 1) {
      throw new ValidationError('Invalid page: must be greater than 0');
    }
  }

  if (limit !== undefined) {
    if (isNaN(limit) || !Number.isInteger(limit)) {
      throw new ValidationError('Invalid limit: must be an integer');
    }
    if (limit < 1) {
      throw new ValidationError('Invalid limit: must be greater than 0');
    }
    if (limit > MAX_LIMIT) {
      throw new ValidationError(`Invalid limit: must not exceed ${MAX_LIMIT}`);
    }
  }

  return {
    page: page && page > 0 ? Math.floor(page) : 1,
    limit: limit && limit > 0 ? Math.floor(limit) : DEFAULT_LIMIT
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const validated = validatePaginationOptions(options);
  const { page, limit } = validated;

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
