/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Basic validation: check for invalid Base64 characters
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Additional validation: check for proper padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If padding exists, it must be at the end
    const padding = input.slice(paddingIndex);
    // Padding must be 1 or 2 '=' characters
    if (padding.length > 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }

  // Check if length is valid for Base64 (must be multiple of 4, or can be made so by padding)
  const remainder = input.length % 4;
  if (remainder !== 0 && remainder !== 2 && remainder !== 3) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
