import fs from 'fs';
import path from 'path';

const files = [
  'src/puzzles.ts',
  'src/transformations.ts',
  'src/validators.ts'
];

files.forEach(file => {
  const filePath = path.join(file);
  if (fs.existsSync(filePath)) {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Fix common issues
    content = content.replace(/\\d/g, 'd');
    content = content.replace(/\\\[/g, '[');
    content = content.replace(/\\\]/g, ']');
    content = content.replace(/\\\//g, '/');
    content = content.replace(/\\\}/g, '}');
    
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Fixed ${file}`);
  }
});