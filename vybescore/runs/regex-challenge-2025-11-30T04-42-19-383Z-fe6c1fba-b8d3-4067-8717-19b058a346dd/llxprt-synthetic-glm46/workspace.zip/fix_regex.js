// Fix regex escapes using string replacement in Node.js
import { readFileSync, writeFileSync } from 'fs';

// Fix puzzles.ts
let puzzlesContent = readFileSync('src/puzzles.ts', 'utf8');
puzzlesContent = puzzlesContent.replace(/\\\[\\]/g, '[]');
puzzlesContent = puzzlesContent.replace(/\\\\?\|/g, '|');
writeFileSync('src/puzzles.ts', puzzlesContent);

// Fix transformations.ts
let transContent = readFileSync('src/transformations.ts', 'utf8');
transContent = transContent.replace(/\\\\?\}/g, '}');
transContent = transContent.replace(/\\\\?\//g, '/');
writeFileSync('src/transformations.ts', transContent);

console.log('Fixed escaping issues');