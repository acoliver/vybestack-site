#!/bin/bash
# Fix the regex escape issues in transformations.ts
sed -i '28s/\\\[\\\]/\[\]/g' src/transformations.ts