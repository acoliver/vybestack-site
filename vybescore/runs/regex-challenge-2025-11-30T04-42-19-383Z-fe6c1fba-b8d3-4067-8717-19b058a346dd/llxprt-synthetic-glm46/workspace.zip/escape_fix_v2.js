import fs from 'fs';
import path from 'path';

const files = [
  'src/puzzles.ts',
  'src/transformations.ts',
  'src/validators.ts'
];

files.forEach(file => {
  const filePath = path.join(file);
  if (fs.existsSync(filePath)) {
    let content = fs.readFileSync(filePath, 'utf8');
    
    // Only fix escapes that are truly unnecessary in regex character classes
    // \d should stay as \d (digit escape should remain)
    // But others like \[ \] \/ in character classes are unnecessary
    content = content.replace(/\\\[/g, '[');
    content = content.replace(/\\\]/g, ']');
    content = content.replace(/\\\//g, '/');
    content = content.replace(/\\\}/g, '}');
    
    fs.writeFileSync(filePath, content, 'utf8');
    console.log(`Fixed ${file}`);
  }
});