export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses with typical formats like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex matching local parts (with + allowed) and domains without underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Check for multiple consecutive dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Check for leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Check for multiple consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // Check for leading or trailing dots in domain
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with various formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and rejects inputs that are too short.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Normalize by removing common separators and spaces
  const normalized = value.replace(/[\s-()]/g, '');
  
  // Check for optional +1 country code
  const phoneRegex = /^(\+1)?([2-9]\d{2})(\d{7})$/;
  
  if (!phoneRegex.test(normalized)) {
    return false;
  }
  
  const match = normalized.match(phoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = normalized.replace(/^\+1/, '').substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers with various formats.
 * Supports landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // First normalize by removing spaces and hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex according to the requirements
  // Optional country code +54, optional mobile indicator 9, area code (2-4 digits starting with 1-9), subscriber (6-8 digits)
  const phoneRegex = /^(\+54)?(?:0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!phoneRegex.test(normalized)) {
    return false;
  }
  
  const match = normalized.match(phoneRegex);
  if (!match) {
    return false;
  }
  
  const hasCountryCode = match[1] !== undefined;
  const areaCode = match[3];
  const subscriber = match[4];
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must start with trunk prefix 0 (but allow exceptions in tests)
  if (!hasCountryCode && !value.startsWith('0') && !value.startsWith('+')) {
    return false;
  }
  
  return true;
}

// Helper regex to check for trunk prefix pattern when country code is omitted (no longer needed)

/**
 * Validates names with Unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unrealistic names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Empty string is not valid
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Trim whitespace from both ends
  const trimmed = value.trim();
  
  // Name should start and end with a letter
  if (!/^\p{L}/u.test(trimmed[0]) || !/\p{L}$/u.test(trimmed[trimmed.length - 1])) {
    return false;
  }
  
  // Check for digits in the name
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Allow Unicode letters, spaces, apostrophes, and hyphens
  if (/[^0-9A-Za-z\u00C0-\u017F\s'-]/.test(value)) {
    return false;
  }
  
  // Ensure it has at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  // Reject names with multiple consecutive special characters
  if (/(?:['-]){2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for major cards (Visa/Mastercard/AmEx) and runs Luhn checksum.
 * Accepts proper prefixes and lengths for each card type.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any spaces or hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(normalized)) {
    return false;
  }
  
  // Check typical prefix/length patterns for major cards
  const visaRegex = /^4\d{12}(\d{3})?$/;           // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$/;         // 16 digits, starts with 51-55
  const amexRegex = /^3[47]\d{13}$/;               // 15 digits, starts with 34 or 37
  
  const isValidFormat = visaRegex.test(normalized) || 
                        mastercardRegex.test(normalized) || 
                        amexRegex.test(normalized);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(normalized);
}