/**
 * Capitalizes the first character of each sentence (after .?!), inserts exactly one space 
 * between sentences even if the input omitted it, and collapses extra spaces sensibly 
 * while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure proper spacing after sentence-ending punctuation
  // This handles cases where there might not be a space after a sentence
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Now capitalize the first letter of each sentence
  // We'll use a regex that finds the first letter after either start of string or a period followed by whitespace
  return normalized.replace(/(?:^|[.!?]\s)([a-z])/g, (match) => match.toUpperCase());
}

/**
 * Returns all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Basic URL matching regex
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation characters
  return urls.map(url => url.replace(/[.,!?;:)\}\'\"]+$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only if it's not already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * For URLs http://example.com/...:
 * - Always upgrades the scheme to https://
 * - When the path begins with /docs/, rewrites the host to docs.example.com 
 * - Skips the host rewrite when the path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  const urlRegex = /(https?:\/\/(?:[^\/]+))(\/[^ \n]*)/g;
  
  return text.replace(urlRegex, (match, host, path) => {
    // Always upgrade to HTTPS
    let newHost = host.replace(/^http:\/\//, 'https://');
    
    // Check if we should avoid rewriting the host
    const skipPatterns = [
      /\/cgi-bin\//i,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[/?#]|$)/i
    ];
    
    // If any skip pattern matches, just return the upgraded URL
    if (skipPatterns.some(pattern => pattern.test(path))) {
      return newHost + path;
    }
    
    // If path starts with /docs/, rewrite to docs.example.com host
    if (/^\/docs\//.test(path)) {
      // Extract the base domain without any subdomains
      const domainMatch = newHost.match(/^https:\/\/(?:www\.)?([^\/]+)/);
      if (domainMatch) {
        newHost = `https://docs.${domainMatch[1]}`;
      }
    }
    
    return newHost + path;
  });
}

/**
 * Returns the four-digit year for mm/dd/yyyy format.
 * If the string doesn't match that format or month/day are invalid, returns "N/A".
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return "N/A";
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = parseInt(dateMatch[3], 10);
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return "N/A";
  }
  
  // Additional validation for specific months
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    if (day > (isLeapYear ? 29 : 28)) {
      return "N/A";
    }
  } else if (day > daysInMonth[month - 1]) {
    return "N/A";
  }
  
  return year.toString();
}