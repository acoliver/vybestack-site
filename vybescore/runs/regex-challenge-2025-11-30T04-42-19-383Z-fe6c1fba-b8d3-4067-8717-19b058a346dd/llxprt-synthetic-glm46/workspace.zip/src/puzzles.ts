/**
 * Finds words in the text that begin with the given prefix, excluding any words in the exceptions list.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Match words that start with the prefix
  // Use word boundary after the prefix to ensure whole words
  const wordRegex = new RegExp(`\\b${prefix}[a-zA-Z0-9]*\\b`, 'g');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => {
    return !exceptions.some(exception => {
      return word.toLowerCase() === exception.toLowerCase();
    });
  });
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds as required.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of digit followed by token
  // This is a manual approach to avoid lookbehind issues
  const results: string[] = [];
  let pos = 0;
  
  while (pos < text.length) {
    // Find the token position
    const tokenPos = text.indexOf(token, pos);
    if (tokenPos === -1) break;
    
    // Check if there's a digit immediately before the token
    const prevCharPos = tokenPos - 1;
    if (prevCharPos >= 0 && /\d/.test(text.charAt(prevCharPos))) {
      // Make sure token is not at start of string
      if (tokenPos > 0) {
        // Include the digit plus token in the result
        results.push(text.substring(prevCharPos, tokenPos + token.length));
      }
    }
    
    // Move past this token
    pos = tokenPos + 1;
  }
  
  return results;
}

/**
 * Validates password strength with specific requirements.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace,
 * and no immediate repeated sequences (like "abab").
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character classes
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=[\]{};':"|,.<>\/?-]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This looks for patterns like "abab", "123123", "!!!!", etc.
  for (let i = 0; i < value.length - 3; i++) {
    const chunk1 = value.substring(i, i + 2);
    const chunk2 = value.substring(i + 2, i + 4);
    
    if (chunk1 === chunk2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses in strings, including shorthand with ::.
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Basic IPv6 pattern - includes shorthand with ::
  // This regex is simplified but catches most common IPv6 formats
  const ipv6Regex = /(?:^|[^0-9])((?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}::|::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:[0-9a-fA-F]{1,4}:){0,3}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,3}:(?:[0-9a-fA-F]{1,4}:){0,4}[0-9a-fA-F]{1,4})(?:[^0-9a-fA-F]|$)/;
  
  // First check if it contains an IPv6 pattern
  if (!ipv6Regex.test(value)) {
    return false;
  }
  
  // Additional check to avoid false positives with IPv4 addresses
  // A simple check for IPv4 patterns to exclude
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value) && !/:/.test(value)) {
    return false;
  }
  
  return true;
}