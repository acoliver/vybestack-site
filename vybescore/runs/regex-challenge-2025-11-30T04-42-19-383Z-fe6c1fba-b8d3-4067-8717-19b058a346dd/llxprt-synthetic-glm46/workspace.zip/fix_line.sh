#!/bin/bash
# Replace line 74 with the correct regex
sed -i '74s/.*/const hasSymbol = \/[!@#$%^&*()_+=\[\\\]{};'"'"':"'"'\\\|,.<>\\\?-]\/.test(value);/' src/puzzles.ts