import { ReportData, Formatter } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderText: Formatter = {
  render(data: ReportData, includeTotals: boolean): string {
    const total = calculateTotal(data.entries);
    const totalLine = includeTotals ? `\nTotal: ${formatAmount(total)}` : '';

    const entries = data.entries
      .map(entry => `- ${entry.label}: ${formatAmount(entry.amount)}`)
      .join('\n');

    return `${data.title}

${data.summary}

Entries:
${entries}${totalLine}`;
  }
};