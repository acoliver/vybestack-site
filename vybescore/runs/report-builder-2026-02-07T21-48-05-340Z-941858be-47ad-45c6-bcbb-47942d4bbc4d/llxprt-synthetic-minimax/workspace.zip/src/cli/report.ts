import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): CLIOptions {
  const args = argv.slice(2); // Remove node and script path

  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    throw new Error('Missing required --format argument');
  }

  const format = args[formatIndex + 1];
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    dataPath,
    format: format as 'markdown' | 'text',
    outputPath,
    includeTotals
  };
}

function readAndValidateData(dataPath: string): ReportData {
  try {
    const content = readFileSync(dataPath, 'utf8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}] missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entries[${i}] missing or invalid "amount" field`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }
}

function getFormatter(format: CLIOptions['format']) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    const data = readAndValidateData(options.dataPath);
    const formatter = getFormatter(options.format);
    
    const output = formatter.render(data, options.includeTotals);

    if (options.outputPath) {
      writeFileSync(options.outputPath, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    process.stderr.write(`Error: ${error instanceof Error ? error.message : error}\n`);
    process.exit(1);
  }
}

main();
