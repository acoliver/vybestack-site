
import fs from 'fs';
let content = fs.readFileSync('src/transformations.ts', 'utf8');
content = content.replace(/http:\/\//g, 'http:/');
content = content.replace(/https:\/\//g, 'https:/');
fs.writeFileSync('src/transformations.ts', content);
console.log('Fixed escaped slashes');
