
import fs from 'fs';
let content = fs.readFileSync('src/transformations.ts', 'utf8');
content = content.replace(/http:\//g, 'http:\/\//g');
content = content.replace(/https:\//g, 'https:\/\//g');
fs.writeFileSync('src/transformations.ts', content);
console.log('Corrected URL patterns');
