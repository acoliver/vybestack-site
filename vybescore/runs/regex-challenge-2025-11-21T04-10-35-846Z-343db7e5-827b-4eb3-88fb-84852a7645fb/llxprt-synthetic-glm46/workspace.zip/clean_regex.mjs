import fs from 'fs';

let content = fs.readFileSync('src/transformations.ts', 'utf8');
console.log('Before fix:');
console.log(content.includes('(https?:\\\\/\\\\/') ? 'Found double escapes' : 'No double escapes');

// Fix the escaped slashes - use string replacement instead of regex
content = content.split('\\\\/\\\\/').join('/');

console.log('After fix:');
console.log(content.includes('(https?:\\\\/') ? 'Found escaped slashes' : 'No escaped slashes');

fs.writeFileSync('src/transformations.ts', content);
console.log('Fixed escaped slashes');