/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around punctuation
  let result = text.trim();
  
  // Replace multiple spaces with single space (but not within sentences)
  result = result.replace(/\s+/g, ' ');
  
  // Ensure there's exactly one space after ., ?, ! if not followed by a space
  result = result.replace(/([.?!])(?=[^\s])/g, '$1 ');
  
  // Split into sentences and capitalize first letter of each
  const sentences = result.split(/([.?!]\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    if (sentences[i] && sentences[i].length > 0) {
      // Capitalize first letter
      sentences[i] = sentences[i].charAt(0).toUpperCase() + sentences[i].slice(1).toLowerCase();
    }
  }
  
  // Join sentences back together
  result = sentences.join('');
  
  // Handle abbreviations like "e.g." to avoid incorrect capitalization
  const abbreviations = ['e.g', 'i.e', 'Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'vs', 'al'];
  
  abbreviations.forEach(abbr => {
    const pattern = new RegExp(`\\b(${abbr}\\.)(\\s)([a-z])`, 'g');
    result = result.replace(pattern, (match, p1, p2, p3) => {
      return p1 + p2 + p3.toLowerCase();
    });
  });
  
  return result;
}

/**
 * TODO: Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  const urlRegex = /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/gi;
  
  // Find all URLs
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation (.,!?;:)
  return matches.map(url => url.replace(/[.,!?;:)]+$/, ''));
}

/**
 * TODO: Replace http:// with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// only for http URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite docs URLs according to the rules described in problem.md.
 */
export function rewriteDocsUrls(text: string): string {
  // This function handles multiple rewriting rules:
  // 1. Always upgrade scheme to https://
  // 2. For /docs/ paths, rewrite host to docs.example.com
  // 3. Skip host rewrite for cgi-bin, query params, or legacy extensions
  // 4. Preserve nested paths
  
  let result = text;
  
  // First, upgrade all http to https
  result = result.replace(/http:\/\//g, 'https://');
  
  // Process URLs with specific rules
  return result.replace(/(https?:\/\/)([^/]+)(\/[^\s]*)/g, (match, protocol, host, path) => {
    // Check if path contains /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should trigger skipping host rewrite
      const skipHostRewrite = /cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
      
      if (!skipHostRewrite) {
        // Rewrite host to docs.example.com
        return `https://docs.example.com${path}`;
      }
    }
    
    // Default behavior: keep the original host but ensure https
    return `https://${host}${path}`;
  });
}

/**
 * TODO: Extract a four-digit year from mm/dd/yyyy format, returning N/A for invalid formats.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with validation of month/day ranges
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  // Extract year
  return match[3];
}