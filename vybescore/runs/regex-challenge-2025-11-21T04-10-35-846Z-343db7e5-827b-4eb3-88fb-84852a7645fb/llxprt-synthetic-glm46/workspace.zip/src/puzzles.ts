/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  const regex = new RegExp(`\\b(${prefix}[a-zA-Z]*)\\b`, 'g');
  const matches = [...text.matchAll(regex)].map(match => match[1]);
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
  
  // Return unique matches
  return [...new Set(filteredMatches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all matches with one or more digits followed by the token
  const regex = new RegExp(`\\d+${escapedToken}`, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out matches at the very beginning of the string
  const filteredMatches = [];
  for (const match of matches) {
    const index = text.indexOf(match);
    // Only include if not at the start (index > 0)
    if (index > 0) {
      filteredMatches.push(match);
    }
    // For case with multiple same matches, find next occurrence
    if (text.indexOf(match, index + 1) > 0) {
      // Update index to find next occurrence
      text = text.substring(index + 1);
    }
  }
  
  return filteredMatches;
}

/**
 * TODO: Enforce a strong password policy.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character classes
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':",.<>]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for repeated sequences (like abab)
  for (let i = 0; i < value.length - 3; i++) {
    const seq1 = value.substring(i, i + 2);
    const seq2 = value.substring(i + 2, i + 4);
    
    if (seq1 === seq2) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses while ensuring IPv4 addresses don't trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles various formats including shorthand :: notation
  const ipv6Regex = /((?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  // IPv4 regex to filter out
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if the value contains IPv6 pattern
  const hasIPv6 = ipv6Regex.test(value);
  
  // Make sure it doesn't contain IPv4 pattern
  const hasIPv4 = ipv4Regex.test(value);
  
  return hasIPv6 && !hasIPv4;
}