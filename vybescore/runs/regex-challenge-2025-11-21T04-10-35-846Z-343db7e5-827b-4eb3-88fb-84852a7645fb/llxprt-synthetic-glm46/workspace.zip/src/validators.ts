export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for invalid patterns first
  if (value.includes('..') || 
      value.startsWith('.') || 
      value.endsWith('.') ||
      value.includes('@.') ||
      value.endsWith('@') ||
      value.split('@').length !== 2) {
    return false;
  }
  
  // Split into local and domain parts
  const [localPart, domain] = value.split('@');
  
  // Local part validation
  // Allow alphanumeric characters, dots, hyphens, plus, and underscores
  // But no consecutive dots
  if (!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(localPart)) {
    return false;
  }
  
  // Domain validation
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Basic domain structure validation - allows subdomains
  const domainRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return domainRegex.test(domain);
}

/**
 * TODO: Implement US phone number validation.
 * Requirements are described in problem.md.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for valid length (10 digits or 11 with country code)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // Check for impossible area codes (leading 0 or 1)
  if (digits.length === 10) {
    const areaCode = digits.substring(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
  } else if (digits.length === 11) {
    // If 11 digits, must start with +1 (country code)
    if (!digits.startsWith('1')) {
      return false;
    }
    const areaCode = digits.substring(1, 4);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
  }
  
  // If extensions are allowed, handle them
  if (options?.allowExtensions) {
    // Check if the string contains extension indicators
    if (/ext\.?|x|#/.test(value.toLowerCase())) {
      const beforeExtension = value.split(/ext\.?|x|#/i)[0].trim();
      const beforeDigits = beforeExtension.replace(/\D/g, '');
      
      // Validate the number part before the extension
      if (beforeDigits.length < 10 || beforeDigits.length > 11) {
        return false;
      }
      
      if (beforeDigits.length === 10) {
        const areaCode = beforeDigits.substring(0, 3);
        if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
          return false;
        }
      } else if (beforeDigits.length === 11 && !beforeDigits.startsWith('1')) {
        return false;
      }
      
      return true;
    }
  }
  
  // Standard format validation
  const phoneRegex = /^(\+?1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation.
 * Requirements are described in problem.md.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // +54: Optional country code
  // 9: Optional mobile indicator
  // 0: Optional trunk prefix (required if country code is missing)
  // Area code: 2-4 digits, cannot start with 0
  // Subscriber: 6-8 digits
  
  const argentinePhoneRegex = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanValue.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const hasCountryCode = !!match[1];
const hasMobilePrefix = !!match[2]; // Mark as used to avoid lint error
  void hasMobilePrefix;
  const hasTrunkPrefix = !!match[3];
  const areaCode = match[4];
  const subscriber = match[5];
  
  // Validate area code (2-4 digits, leading digit 1-9)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriber)) {
    return false;
  }
  
  // When country code is omitted, must begin with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check if the structure is valid for the combination of prefixes
  const totalLength = cleanValue.length;
  
  // Simplified validation: just check if the regex matched and valid structure
  // The specific format is already enforced by the regex pattern
  
  // If has country code (+54)
  if (hasCountryCode) {
    return totalLength >= 11 && totalLength <= 13; // Accept all valid +54 formats
  } 
  // If no country code
  else {
    return totalLength >= 8 && totalLength <= 11; // Accept all valid local formats
  }
}

/**
 * TODO: Implement name validation with Unicode support.
 * Requirements are described in problem.md.
 */
export function isValidName(value: string): boolean {
  // Names should allow:
  // - Unicode letters (including accented characters)
  // - Apostrophes
  // - Hyphens
  // - Spaces
  // But reject:
  // - Digits
  // - Most special symbols
  // - Names like "X Æ A-12"
  
  // Check for digits first
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for special symbols that shouldn't be in names
  if (/[!"#$%&()*+,./:;<=>?@[\\\]^_`{|}~]/.test(value)) {
    return false;
  }
  
  // Allow Unicode letters, apostrophes, hyphens, and spaces
  // Also allow some accented characters
  const nameRegex = /^[\p{L}'\-\p{M}\s]+$/u;
  return nameRegex.test(value);
}

/**
 * Helper function to run Luhn checksum for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement credit card validation with Luhn checksum.
 * Requirements are described in problem.md.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check length (13-19 digits typical for credit cards)
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check prefix patterns for major brands
  let isValidBrand = false;
  
  // Visa: starts with 4, length 13 or 16
  if (/^4\d{12}(?:\d{3})?$/.test(cleanValue)) {
    isValidBrand = true;
  }
  
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  if (/^5[1-5]\d{14}$/.test(cleanValue) || /^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/.test(cleanValue)) {
    isValidBrand = true;
  }
  
  // American Express: starts with 34 or 37, length 15
  if (/^3[47]\d{13}$/.test(cleanValue)) {
    isValidBrand = true;
  }
  
  if (!isValidBrand) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}