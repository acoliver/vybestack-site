
import fs from 'fs';
let content = fs.readFileSync('src/transformations.ts', 'utf8');
console.log('=== BEFORE ===');
const lines = content.split('
');
lines.forEach((line, i) => {
  if (line.includes('https?')) {
    console.log(`${i+1}: ${line}`);
  }
});
