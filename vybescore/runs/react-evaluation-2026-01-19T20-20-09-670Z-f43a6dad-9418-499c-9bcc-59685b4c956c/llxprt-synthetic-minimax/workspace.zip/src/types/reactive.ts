/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export { activeObserver }

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

const observers: Map<ObserverR, boolean> = new Map()
const dependencies: Map<ObserverR, Set<ObserverR>> = new Map()
const dependents: Map<ObserverR, Set<ObserverR>> = new Map()

export function registerObserver(observer: ObserverR): void {
  observers.set(observer, false)
  if (!dependencies.has(observer)) {
    dependencies.set(observer, new Set())
  }
  if (!dependents.has(observer)) {
    dependents.set(observer, new Set())
  }
}

export function unregisterObserver(observer: ObserverR): void {
  observers.delete(observer)
  dependencies.delete(observer)
  dependents.delete(observer)
  
  // Remove this observer from all dependents' dependency sets
  for (const [, deps] of dependencies.entries()) {
    deps.delete(observer)
  }
  
  // Remove this observer from all dependencies' dependent sets  
  for (const [, deps] of dependents.entries()) {
    deps.delete(observer)
  }
}

export function trackDependency(dependent: ObserverR): void {
  const current = getActiveObserver()
  if (current && current !== dependent) {
    // Register dependency relationship: dependent depends on current
    if (!dependencies.has(dependent)) {
      dependencies.set(dependent, new Set())
    }
    if (!dependents.has(current)) {
      dependents.set(current, new Set())
    }
    
    dependencies.get(dependent)!.add(current)
    dependents.get(current)!.add(dependent)
  }
}

export function clearDependencies(observer: ObserverR): void {
  if (dependencies.has(observer)) {
    const deps = dependencies.get(observer)!
    // Remove this observer from all its dependencies' dependents sets
    deps.forEach((_dep: ObserverR) => {
      if (_dep && dependents.has(_dep)) {
        dependents.get(_dep)!.delete(observer)
      }
    })
    // Clear the dependencies
    deps.clear()
  }
}

export function notifyDependents(observer: ObserverR): void {
  const visited = new Set<ObserverR>()
  const toNotify = new Set(dependents.get(observer) || [])
  
  while (toNotify.size > 0) {
    const dependent = Array.from(toNotify)[0]
    toNotify.delete(dependent)
    
    if (visited.has(dependent)) continue
    visited.add(dependent)
    
    // Only update if the dependent has an updateFn (it's a proper Observer)
    if ('updateFn' in dependent) {
      updateObserver(dependent as Observer<unknown>)
      
      // Add this dependent's dependents to the notification queue
      const dependentDependents = dependents.get(dependent)
      if (dependentDependents) {
        for (const dep of dependentDependents) {
          if (!visited.has(dep)) {
            toNotify.add(dep)
          }
        }
      }
    }
  }
}
