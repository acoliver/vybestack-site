/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerObserver, unregisterObserver, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies
  registerObserver(observer)
  
  let disposed = false
  
  const wrappedUpdateFn: UpdateFn<T> = () => {
    if (disposed) return observer.value!
    
    // Execute the user's callback function which establishes dependencies
    const result = updateFn(observer.value)
    
    // Store the result for next time
    observer.value = result
    
    return result
  }
  
  // Replace the update function with our wrapped version
  observer.updateFn = wrappedUpdateFn
  
  // Execute immediately to establish initial state and dependencies
  const previous = getActiveObserver()
  setActiveObserver(observer)
  try {
    updateObserver(observer)
  } finally {
    setActiveObserver(previous)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Unregister this observer to break dependency relationships
    unregisterObserver(observer)
  }
}
