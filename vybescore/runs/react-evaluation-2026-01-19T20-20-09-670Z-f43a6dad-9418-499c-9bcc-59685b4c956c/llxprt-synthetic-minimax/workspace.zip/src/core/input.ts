/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ObserverR,
  getActiveObserver,
  trackDependency,
  notifyDependents,
  registerObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  // Register this as an observer for dependency tracking
  registerObserver(s)

  const read: GetterFn<T> = () => {
    // When reading, track that the current active observer depends on this input
    const observer = getActiveObserver()
    if (observer && observer !== s) {
      trackDependency(observer)
    }
    
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const previousValue = s.value
    s.value = nextValue
    
    // Notify dependents when value changes
    if (previousValue !== nextValue) {
      notifyDependents(s as ObserverR)
    }
    
    return s.value
  }

  return [read, write]
}
