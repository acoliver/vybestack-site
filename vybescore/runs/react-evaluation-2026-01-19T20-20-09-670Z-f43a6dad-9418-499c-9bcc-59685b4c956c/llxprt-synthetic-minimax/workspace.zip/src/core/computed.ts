/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  trackDependency,
  notifyDependents,
  registerObserver,
  clearDependencies,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Register observer for dependency tracking
  registerObserver(o)
  
  const getter: GetterFn<T> = () => {
    // Set this as the active observer during computation to track dependencies
    const previous = getActiveObserver()
    
    // Clear old dependencies when recomputing
    clearDependencies(o)
    
    setActiveObserver(o)
    try {
      // Execute the update function to compute new value and track dependencies
      const newValue = updateFn(o.value)
      const previousValue = o.value
      o.value = newValue
      
      // Notify dependents if value changed
      if (previousValue !== newValue) {
        notifyDependents(o)
      }
    } finally {
      setActiveObserver(previous)
    }
    
    // When other observers read this computed value, establish dependency
    const current = getActiveObserver()
    if (current && current !== o) {
      trackDependency(o)
    }
    
    return o.value!
  }
  
  return getter
}
