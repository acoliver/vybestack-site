import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

export interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  private sql: initSqlJs.SqlJsStatic | null = null;
  private db: Database | null = null;
  private dbFilePath: string;

  constructor() {
    this.dbFilePath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    this.sql = await initSqlJs({
      locateFile: (file: string) => {
        if (file === 'sql-wasm.wasm') {
          // Use the absolute path to the WASM file
          return path.resolve(process.cwd(), 'node_modules/sql.js/dist/sql-wasm.wasm');
        }
        return file;
      }
    });

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbFilePath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbFilePath)) {
      const fileBuffer = fs.readFileSync(this.dbFilePath);
      this.db = new this.sql!.Database(fileBuffer);
    } else {
      this.db = new this.sql!.Database();
      await this.createTables();
    }
  }

  private async createTables(): Promise<void> {
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    this.db!.exec(schema);
  }

  async insertSubmission(data: SubmissionData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.step();
    stmt.free();
    
    // Save to disk
    await this.saveToDisk();
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbFilePath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      await this.saveToDisk();
      this.db.close();
      this.db = null;
    }
  }
}