import express, { Request, Response } from 'express';
import path from 'path';
import { DatabaseManager } from './db/database.js';
import { validateSubmission } from './validation/validator.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
const dbManager = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src/templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    oldData: {},
    title: 'Contact Us - Definitely Not Suspicious'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const submissionData = {
      firstName: req.body.firstName?.trim(),
      lastName: req.body.lastName?.trim(),
      streetAddress: req.body.streetAddress?.trim(),
      city: req.body.city?.trim(),
      stateProvince: req.body.stateProvince?.trim(),
      postalCode: req.body.postalCode?.trim(),
      country: req.body.country?.trim(),
      email: req.body.email?.trim(),
      phone: req.body.phone?.trim()
    };

    // Validate submission
    const validationResult = validateSubmission(submissionData);
    
    if (!validationResult.isValid) {
      // Return validation errors
      return res.status(400).render('form', {
        errors: validationResult.errors,
        oldData: submissionData,
        title: 'Contact Us - Please Fix Errors'
      });
    }

    // Insert into database
    await dbManager.insertSubmission(submissionData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).send('Something went wrong!');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    title: 'Thank You! ',
    message: 'We\'ll be in touch... permanently.'
  });
});

// Error handling middleware
app.use((error: Error, req: Request, res: Response) => {
  console.error('Server error:', error);
  res.status(500).send('Something went wrong!');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    await dbManager.initialize();
    app.listen(PORT, () => {
      console.log(` Server running on http://localhost:${PORT}`);
      console.log('Ready to capture your data! (Totally legitimate, we promise)');
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();