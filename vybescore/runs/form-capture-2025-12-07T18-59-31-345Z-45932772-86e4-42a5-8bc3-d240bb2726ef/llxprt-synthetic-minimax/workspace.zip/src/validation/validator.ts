export interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: { [key: string]: string };
}

export class ValidationError extends Error {
  constructor(message: string, public field: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export function validateSubmission(data: SubmissionData): ValidationResult {
  const errors: { [key: string]: string } = {};

  // Validate required fields
  validateRequiredField(data.firstName, 'firstName', errors, 'First name');
  validateRequiredField(data.lastName, 'lastName', errors, 'Last name');
  validateRequiredField(data.streetAddress, 'streetAddress', errors, 'Street address');
  validateRequiredField(data.city, 'city', errors, 'City');
  validateRequiredField(data.stateProvince, 'stateProvince', errors, 'State/Province/Region');
  validateRequiredField(data.postalCode, 'postalCode', errors, 'Postal/Zip code');
  validateRequiredField(data.country, 'country', errors, 'Country');
  validateRequiredField(data.email, 'email', errors, 'Email');
  validateRequiredField(data.phone, 'phone', errors, 'Phone number');

  // Validate email format
  if (data.email && !isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Validate phone number format
  if (data.phone && !isValidPhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and leading + are allowed)';
  }

  // Validate postal code format
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal/ZIP code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function validateRequiredField(
  value: string,
  fieldName: string,
  errors: { [key: string]: string },
  fieldDisplayName: string
): void {
  if (!value || value.trim().length === 0) {
    errors[fieldName] = `${fieldDisplayName} is required`;
  }
}

function isValidEmail(email: string): boolean {
  // Simple but effective email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Phone number can contain digits, spaces, parentheses, dashes, and a leading +
  // Must have at least one digit
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && /\d/.test(phone);
}

function isValidPostalCode(postalCode: string): boolean {
  // Must be alphanumeric, at least 3 characters (handles US ZIP, UK, Argentina, etc.)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.replace(/\s/g, '').length >= 3;
}