/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern that matches words starting with prefix
  // Use word boundaries to match whole words only
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(match => {
    return !exceptionsLower.includes(match.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token that appears after a digit and not at start of string
  // Capture digit and token separately
  const pattern = new RegExp(`(?<!^)(\\d)(${escapedToken})`, 'g');
  
  const result = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // match[0] is the full match, match[1] is the digit, match[2] is the token
    result.push(match[0]);
  }
  
  return result;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // Check for any 2-character sequence repeated immediately
  for (let i = 0; i < value.length - 3; i++) {
    const seq = value.substring(i, i + 2);
    const nextSeq = value.substring(i + 2, i + 4);
    if (seq === nextSeq) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if there are any IPv4 addresses
  // IPv4 pattern: 0-255.0-255.0-255.0-255
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b/;
  
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns
  // Standard IPv6 with colons (including shorthand ::)
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b::1\b|\b::\b/;
  
  if (ipv6Pattern.test(value)) {
    return true;
  }
  
  // More flexible IPv6 pattern that handles various formats including ::
  const flexiblePattern = /^(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:((?::[0-9a-fA-F]{1,4}){1,7}|:)/i;
  
  if (flexiblePattern.test(value)) {
    return true;
  }
  
  return false;
}