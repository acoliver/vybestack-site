export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // Check basic format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in the email
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (should be 10 or 11 with +1)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Valid US number with country code
    const areaCode = digits.substring(1, 4);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  } else if (digits.length === 10) {
    // Valid 10-digit number
    const areaCode = digits.substring(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Match Argentine phone number pattern
  // Country code: +54 (optional)
  // Mobile indicator: 9 (optional)
  // Area code: 2-4 digits (first digit 1-9)
  // Subscriber: 6-8 digits
  const pattern = /^\+?54\s*9?\s*([1-9]\d{1,3})\s*(\d{6,8})$/;
  const match = value.replace(/[\s-]/g, '').match(pattern);
  
  if (!match) {
    return false;
  }
  
  // Extract components
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject X Æ A-12 style names
  if (/[Æ]/.test(value) || /[×]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any Unicode letter character
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if we have a valid length (13-19 digits)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid card type prefixes
  // Visa: starts with 4, length 13, 16, 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  let isValidType = false;
  
  // Visa
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidType = true;
  }
  // Mastercard
  else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
            digits.startsWith('54') || digits.startsWith('55') ||
            (digits.startsWith('222') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('223') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('224') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('225') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('226') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('227') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('228') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('229') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('230') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('231') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('232') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('233') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('234') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('235') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('236') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('237') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('238') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('239') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('240') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('241') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('242') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('243') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('244') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('245') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('246') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('247') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('248') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('249') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('250') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('251') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('252') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('253') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('254') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('255') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('256') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('257') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('258') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('259') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('260') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('261') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('262') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('263') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('264') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('265') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('266') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('267') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('268') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('269') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('270') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('271') && parseInt(digits.substring(0, 4)) <= 2720) ||
            (digits.startsWith('272') && parseInt(digits.substring(0, 4)) <= 2720))) {
    isValidType = digits.length === 16;
  }
  // AmEx
  else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
