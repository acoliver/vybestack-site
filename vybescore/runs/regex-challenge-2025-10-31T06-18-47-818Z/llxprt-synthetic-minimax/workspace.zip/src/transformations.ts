/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, ensure there's a space after sentence enders (.?!)
  // Replace .?! followed by non-space with .?! followed by space
  let result = text.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Now capitalize the first character after sentence enders
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize the first character of the string if it starts with a lowercase letter
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match http(s) URLs with common patterns
  const urlRegex = /\bhttps?:\/\/[^\s<>"']+[^\s<>"',.?!)]/g;
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?)]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com URLs
  return text.replace(/http:\/\/example\.com(\/[^\s<>"']*)/g, (match, path) => {
    // Check for dynamic hints in the path
    const hasDynamicHints = /(\?|=|&)|(\.(jsp|php|asp|aspx|do|cgi|pl|py)\b)|(cgi-bin)/i.test(path);
    
    // Check if path begins with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    // Upgrade to https
    let result = 'https://';
    
    if (isDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      result += 'docs.example.com';
    } else {
      // Keep original host
      result += 'example.com';
    }
    
    // Add the path
    result += path;
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
