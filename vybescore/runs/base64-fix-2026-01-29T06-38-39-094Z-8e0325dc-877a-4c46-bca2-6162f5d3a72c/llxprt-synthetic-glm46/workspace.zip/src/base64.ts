/**
 * Encode plain text to Base64 using canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects invalid payloads.
 * Special case: Node.js Buffer is lenient with invalid characters, so we add extra validation.
 */
export function decode(input: string): string {
  const trimmedInput = input.trim();
  
  // Validate basic Base64 format: only A-Z, a-z, 0-9, +, / and = (padding)
  if (!/^[A-Za-z0-9+/=]*$/.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Ensure input length is valid for Base64 (not 1 mod 4)
  if (trimmedInput.length % 4 === 1) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  // Validate padding rules:
  // 1. Padding only at the end
  const nonPadding = trimmedInput.replace(/=+$/, '');
  if (nonPadding.includes('=')) {
    throw new Error('Invalid Base64 input: padding in middle');
  }

  // 2. Maximum 2 padding characters
  const paddingCount = trimmedInput.length - nonPadding.length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: excessive padding');
  }

  try {
    const buffer = Buffer.from(trimmedInput, 'base64');
    
    // We accept that Node.js Buffer is lenient. If this is an issue for specific use cases
    // where stricter validation is needed, users should use a dedicated base64 validation library
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input');
  }
}
