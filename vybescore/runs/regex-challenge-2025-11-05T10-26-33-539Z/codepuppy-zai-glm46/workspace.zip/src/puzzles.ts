/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex to find words starting with prefix
  // \b ensures word boundary, \w+ matches the rest of the word
  const wordRegex = new RegExp(`\\b${escapeRegex(prefix)}\\w+`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches
    .map(match => match.toLowerCase())
    .filter(word => !exceptionsSet.has(word))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Helper function to escape regex special characters in prefix
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Use lookbehind to ensure token is preceded by a digit
  const tokenPattern = escapeRegex(token);
  
  // Try to match digit+token patterns, ensuring not at start
  const tokenRegex = new RegExp(`(?<!^)(?<=\d)${tokenPattern}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Find the full digit+token match
    const startIndex = match.index;
    const endIndex = match.index + match[0].length;
    
    // Find the preceding digit
    let digitStart = startIndex - 1;
    while (digitStart >= 0 && /\d/.test(text[digitStart])) {
      digitStart--;
    }
    digitStart++;
    
    const fullMatch = text.substring(digitStart, endIndex);
    matches.push(fullMatch);
  }
  
  // Fallback if lookbehind not supported
  if (matches.length === 0) {
    const fallbackRegex = new RegExp(/\d/.source + tokenPattern, 'g');
    let fallbackMatch;
    
    while ((fallbackMatch = fallbackRegex.exec(text)) !== null) {
      if (fallbackMatch.index > 0) {
        matches.push(fallbackMatch[0]);
      }
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (special character)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // No immediate repeated sequences (like abab, abcabc, 1212, etc.)
  // Check for patterns where a sequence repeats immediately
  const repeatPattern = /(..+?)\1+/;
  if (repeatPattern.test(value)) return false;
  
  // Also check for longer repeated patterns like 'abab'
  for (let i = 2; i <= value.length / 2; i++) {
    for (let j = 0; j <= value.length - i * 2; j++) {
      const chunk = value.substring(j, j + i);
      const nextChunk = value.substring(j + i, j + i * 2);
      if (chunk === nextChunk) return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // Simplified IPv6 detection
  // Look for patterns with colons that are typical of IPv6
  // Start with basic checks and then refine
  
  // Must contain at least one colon
  if (!value.includes(':')) return false;
  
  // Reject common IPv4 patterns
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Pattern.test(value)) return false;
  
  // Look for IPv6 patterns
  const ipv6Patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/g,
    // Compressed with :: in middle
    /(?:[0-9a-fA-F]{1,4}:){0,6}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/g,
    // Starting with ::
    /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/g,
    // Ending with ::
    /(?:[0-9a-fA-F]{1,4}:){0,7}::/g,
    // Just ::
    /::/g
  ];
  
  return ipv6Patterns.some(pattern => {
    pattern.lastIndex = 0;
    return pattern.test(value);
  });
}