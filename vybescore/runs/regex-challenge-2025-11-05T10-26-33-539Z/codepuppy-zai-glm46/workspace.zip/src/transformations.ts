/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing: collapse extra spaces, ensure single space after sentences
  const normalized = text
    .replace(/\s+/g, ' ') // Collapse multiple spaces to single space
    .replace(/([.!?])\s*/g, '$1 ') // Ensure space after sentence endings
    .trim(); // Remove leading/trailing spaces
  
  // Capitalize first letter of each sentence
  // This regex matches sentence boundaries and captures the first letter
  const capitalizeRegex = /(^|[.!?]\s+)([a-z])/g;
  
  return normalized.replace(capitalizeRegex, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex that matches http/https/www URLs
  const urlRegex = /\b((?:https?:\/\/)?(?:www\.)?[^\s<>'"(){}[\]]+(?:\.[^\s<>'"(){}[\]]+)+(?:\/[^\s<>'"(){}[\]]*)*)/g;
  
  const matches: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[1];
    
    // Remove trailing punctuation but preserve path delimiters
    url = url.replace(/[.,;:!?)]+$/g, '');
    
    // Remove surrounding brackets if present
    url = url.replace(/^[\[\(\{]+|[\]\)\}]+$/g, '');
    
    // Ensure it has a protocol or starts with www
    if (url.match(/^https?:\/\//) || url.match(/^www\./)) {
      matches.push(url);
    }
  }
  
  return [...new Set(matches)]; // Remove duplicates
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://, but don't touch existing https://
  const httpsRegex = /http:\/\/([^\s<>'"(){}[\]]+)/g;
  
  return text.replace(httpsRegex, 'https://$1');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // First, upgrade all http to https
  let result = enforceHttps(text);
  
  // Rewrite docs.example.com URLs
  // Match https://example.com/docs/... patterns but exclude those with dynamic hints
  const urlRegex = /(https:\/\/)([^\s<>'"(){}[\]]+?)(\/docs\/[^\s<>'"(){}[\]]*)/gi;
  
  result = result.replace(urlRegex, (match, protocol, domain, path) => {
    // Check for exceptions: cgi-bin, query strings, legacy extensions
    const exceptions = /(cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)($|\/|\?))/i;
    
    if (exceptions.test(path)) {
      // Only upgrade protocol, don't change domain
      return match;
    }
    
    // Rewrite to docs.subdomain
    return `${protocol}docs.${domain}${path}`;
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Extract mm/dd/yyyy pattern
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Basic validation for day/month combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Days in each month (simplified, not accounting for leap years)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  if (dayNum < 1 || dayNum > daysInMonth[monthNum - 1]) return 'N/A';
  
  return year;
}