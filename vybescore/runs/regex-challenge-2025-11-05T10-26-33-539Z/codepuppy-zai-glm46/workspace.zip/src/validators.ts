export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that supports common formats, rejects double dots, trailing dots, underscore domains
  // Local part: letters, digits, +, dots (no consecutive/trailing), underscores, hyphens
  // Domain: letters, digits, hyphens, dots (no consecutive/trailing)
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!value) return false;
  
  // Reject double dots in local part or domain
  if (value.includes('..')) return false;
  
  // Reject trailing dot in local part or domain
  if (value.endsWith('.')) return false;
  
  // Reject underscore in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits without country code, 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    if (!digitsOnly.startsWith('1')) return false;
    phoneNumber = digitsOnly.slice(1);
  }
  
  // Now phoneNumber should be exactly 10 digits
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Regex to match valid US phone formats
  // Supports: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^\+?1?[\s-]*\(?([2-9]\d{2})\)?[\s-]*([2-9]\d{2})[\s-]*(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // Optional +54 country code
  // Optional 0 trunk prefix (if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading 1-9
  // Subscriber: 6-8 digits
  // Supported: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  const argentinePhoneRegex = /^(\+54)?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, areaCode, subscriber] = match;
  
  // If no country code, must start with trunk prefix (0)
  if (!countryCode && !value.startsWith('0')) return false;
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Subscriber number: 6-8 digits total
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols like @#$%^&*()[]{} etc.
  // Support multiple words with proper spacing
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional validation: reject obviously invalid names like "X Æ A-12"
  if (/\d/.test(value)) return false;
  
  // Reject names with consecutive special characters
  if (/['][']/.test(value) || /[-][-]/.test(value)) return false;
  
  // Reject names starting or ending with apostrophe or hyphen
  if (value.startsWith("'") || value.endsWith("'") || 
      value.startsWith('-') || value.endsWith('-')) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9][0-9]|[3-6][0-9]{2}|7([01][0-9]|20))\d{12})$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if pattern matches any supported card type
  const isValidPrefix = visaRegex.test(cleanValue) || 
                       mastercardRegex.test(cleanValue) || 
                       amexRegex.test(cleanValue);
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
