/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words starting with the prefix
  const prefixedWordsRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all matches of digits followed by the token
  const pattern = new RegExp(`(\\d+)${escapedToken}`, 'g');
  const result = [];
  
  let match;
  while ((match = pattern.exec(text)) !== null) {
    // Ensure the match is not at the start of the string
    if (match.index > 0) {
      result.push(match[0]);
    }
  }
  
  return result;
}

/**
 * Checks if a password is strong.
 * Requirements: at least 10 characters, one uppercase, one lowercase, one digit, one symbol
 * No whitespace, no immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\w\s]/.test(value); // Non-word, non-space characters
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // This is a simple heuristic - it looks for patterns where a sequence of 2-4 characters
  // repeats immediately after itself
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - (len * 2); i++) {
      const sequence = value.substr(i, len);
      const nextSequence = value.substr(i + len, len);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern - this is complex due to the various formats IPv6 can take
  const ipv6Pattern = 
    // Full IPv6
    '(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|' +
    // IPv6 with ::
    '(?:[0-9a-fA-F]{1,4}:){1,7}:|' +
    '(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|' +
    '(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|' +
    '[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|' +
    // IPv6 with embedded IPv4
    '(?:[0-9a-fA-F]{1,4}:){1,4}:(?:[0-9]{1,3}[.]){3}[0-9]{1,3}';
  
  const ipv6Regex = new RegExp(`\\b(?:${ipv6Pattern})\\b`);
  
  // Check if there's a potential IPv6 match
  return ipv6Regex.test(value);
}