export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that covers most cases while rejecting obvious invalid formats
  const emailRegex = /^(?!\.)(?!.*\.\.)[a-zA-Z0-9+_\-]+(?:\.[a-zA-Z0-9+_\-]+)*@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}(?<!\.$)/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for domain underscores and other invalid patterns
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common formatting characters
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  const phoneNumber = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;
  
  // Check if we have exactly 10 digits for a US phone number
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code and check it doesn't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers
  // Optional +54, optional 0 trunk prefix, optional 9 mobile indicator
  // 2-4 digit area code (starting with 1-9)
  // 6-8 digit subscriber number
  const argentinePhoneRegex = /^(\+54)?(0?)(9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, trunkPrefix, mobileIndicator, areaCode, subscriberNumber] = match;
  
  // If no country code, must start with trunk prefix (0)
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Validate area code length (already enforced by regex: 2-4 digits)
  // Validate subscriber number length (already enforced by regex: 6-8 digits)
  
  return true;
}

/**
 * Validates names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  const trimmed = value.trim();
  
  // Cannot be empty
  if (trimmed.length === 0) {
    return false;
  }
  
  // Name regex: Unicode letters, spaces, hyphens, apostrophes
  // Must have at least one letter
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Must contain at least one Unicode letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) {
    return false;
  }
  
// Should not contain consecutive symbols like -- or ''
  if (/(['-])\1/.test(trimmed)) {
    return false;
  }
  
  // Should not start or end with symbols
  if (/^['-]|['-]$/.test(trimmed)) {
    return false;
  }
  
  // Should not start or end with symbols
  if (/^['\-]|['\-]$/.test(trimmed)) {
    return false;
  }
  
  // Should not contain more than one space in a row
  if (/\s{2,}/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if clean value is all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check valid lengths: 13-19 digits
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check valid prefixes for major card types
  // Visa: starts with 4
  // Mastercard: starts with 51-55 or 2221-2720
  // AmEx: starts with 34 or 37
  const visaRegex = /^4\d{12,18}$/;
  const mastercardRegex1 = /^5[1-5]\d{14}$/;
  const mastercardRegex2 = /^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidPrefix = 
    visaRegex.test(cleaned) || 
    mastercardRegex1.test(cleaned) || 
    mastercardRegex2.test(cleaned) || 
    amexRegex.test(cleaned);
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Start from the rightmost digit and move left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}