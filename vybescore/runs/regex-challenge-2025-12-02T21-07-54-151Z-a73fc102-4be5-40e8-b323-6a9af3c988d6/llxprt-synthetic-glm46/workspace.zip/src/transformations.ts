/**
 * Capitalizes the first character of each sentence.
 * After . ? ! punctuation, inserts exactly one space between sentences.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around punctuation
  let normalized = text
    // Ensure consistent spacing after punctuation
    .replace(/([.!?])\s+/g, '$1 ')
    // Remove spaces before punctuation
    .replace(/\s+([.!?])/g, '$1')
    // Collapse multiple spaces
    .replace(/\s{2,}/g, ' ')
    .trim();
  
  // Handle the beginning of the string
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  // Split by sentence punctuation and capitalize each sentence
  return normalized.replace(/([.!?]\s*)([a-z])/g, (_, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
}

/**
 * Extracts all URLs from the text.
 * URLs should not include trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http, https protocols
  // Includes domains, IP addresses, ports, and paths
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like . , ; : ) ] } etc.
  return matches.map(url => url.replace(/[.,;:)\]\}]+$/, ''));
}

/**
 * Converts all http:// URLs to https:// while leaving existing secure URLs unchanged.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules.
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 *
 * Example:
 * http://example.com/docs/api -> https://docs.example.com/docs/api
 * http://example.com/docs/api?param=1 -> https://example.com/docs/api?param=1 (host unchanged)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /https?:\/\/([^\/]+)(\/[^\s]*)/g,
    (match, host, path) => {
      // Always upgrade to HTTPS
      let newUrl = 'https://' + host + path;
      
      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Skip rewrite for dynamic content
        const hasDynamicContent = 
          path.includes('/cgi-bin') || 
          path.includes('?') || 
          path.includes('&') || 
          path.includes('=') ||
          /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/.test(path);
        
        if (!hasDynamicContent) {
          newUrl = 'https://docs.' + host + path;
        }
      }
      
      return newUrl;
    }
  );
}

/**
 * Extracts the year from a date string in mm/dd/yyyy format.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(value);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for specific months
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (February)
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  if (month === 2 && isLeapYear(year)) {
    daysInMonth[1] = 29;
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}