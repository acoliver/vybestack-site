/**
 * @fileoverview Lint-exempt test file for validators functionality.
 * This file is excluded from ESLint to allow for regex patterns that may trigger warnings.
 */

/* eslint-disable */

import { describe, expect, it } from 'vitest';
import { 
  isValidEmail, 
  isValidUSPhone, 
  isValidArgentinePhone, 
  isValidName, 
  isValidCreditCard 
} from '../../src/validators.js';

describe('validators (lint-exempt advanced)', () => {
  describe('isValidEmail', () => {
    it('accepts various valid email formats', () => {
      expect(isValidEmail('name+tag@example.co.uk')).toBe(true);
      expect(isValidEmail('user.name@example-domain.com')).toBe(true);
      expect(isValidEmail('a@b.co')).toBe(true);
    });

    it('rejects obviously invalid emails', () => {
      expect(isValidEmail('user@@example..com')).toBe(false);
      expect(isValidEmail('user@example.')).toBe(false);
      expect(isValidEmail('.user@example.com')).toBe(false);
      expect(isValidEmail('user@sub_domain.example.com')).toBe(false);
    });
  });

  describe('isValidUSPhone', () => {
    it('accepts various valid US phone formats', () => {
      expect(isValidUSPhone('212-555-7890')).toBe(true);
      expect(isValidUSPhone('(212) 555-7890')).toBe(true);
      expect(isValidUSPhone('2125557890')).toBe(true);
      expect(isValidUSPhone('+1 212 555 7890')).toBe(true);
    });

    it('rejects invalid US phone numbers', () => {
      expect(isValidUSPhone('012-555-7890')).toBe(false); // Area code starting with 0
      expect(isValidUSPhone('212555789')).toBe(false); // Too short
    });
  });

  describe('isValidArgentinePhone', () => {
    it('accepts various valid Argentine phone formats', () => {
      expect(isValidArgentinePhone('+54 9 11 1234 5678')).toBe(true);
      expect(isValidArgentinePhone('011 1234 5678')).toBe(true);
      expect(isValidArgentinePhone('+54 341 123 4567')).toBe(true);
      expect(isValidArgentinePhone('0341 4234567')).toBe(true);
    });
  });

  describe('isValidName', () => {
    it('accepts valid names with special characters', () => {
      expect(isValidName('Jean-Luc Picard')).toBe(true);
      expect(isValidName('O\'Connor')).toBe(true);
      expect(isValidName('José María')).toBe(true);
    });

    it('rejects invalid names', () => {
      expect(isValidName('X Æ A-12')).toBe(false); // Contains symbols
      expect(isValidName('John123')).toBe(false); // Contains digits
    });
  });

  describe('isValidCreditCard', () => {
    it('accepts valid credit card numbers', () => {
      expect(isValidCreditCard('4111111111111111')).toBe(true); // Visa
      expect(isValidCreditCard('5500-0000-0000-0004')).toBe(true); // Mastercard
      expect(isValidCreditCard('3782 822463 10005')).toBe(true); // AmEx
    });

    it('rejects invalid credit card numbers', () => {
      expect(isValidCreditCard('4111111111111112')).toBe(false); // Fails Luhn
      expect(isValidCreditCard('1234-5678-9012-3456')).toBe(false); // Invalid prefix/length
    });
  });
});