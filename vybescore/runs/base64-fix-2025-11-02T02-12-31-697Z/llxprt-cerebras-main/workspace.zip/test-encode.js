import { encode } from "./dist/base64.js"; console.log(encode("hello"));
