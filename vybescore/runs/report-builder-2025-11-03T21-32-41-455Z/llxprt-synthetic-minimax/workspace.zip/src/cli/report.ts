import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  // Skip 'node' and script name
  const argsToParse = argv.slice(2);

  for (let i = 0; i < argsToParse.length; i++) {
    const arg = argsToParse[i];

    if (!arg.startsWith('-')) {
      if (!args.dataFile) {
        args.dataFile = arg;
      } else if (!args.format && arg !== '--format') {
        // This shouldn't happen with proper argument structure, but handle gracefully
      }
    } else if (arg === '--format') {
      const formatValue = argsToParse[++i];
      if (!formatValue || formatValue.startsWith('-')) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      args.format = formatValue;
    } else if (arg === '--output') {
      const outputValue = argsToParse[++i];
      if (!outputValue || outputValue.startsWith('-')) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      args.output = outputValue;
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    }
  }

  // Validate required arguments
  if (!args.dataFile) {
    console.error('Error: Missing data file argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Missing --format argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return args;
}

function readAndParseJson(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }

    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry at index ${i} is missing or has invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry at index ${i} is missing or has invalid "amount" field`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
    } else if (error instanceof Error && error.message.startsWith('ENOENT:')) {
      console.error(`Error: File not found "${filePath}"`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Unknown error reading file "${filePath}"`);
    }
    process.exit(1);
  }
}

function getFormatter(format: string) {
  const formatters: Record<string, (data: ReportData, options: RenderOptions) => string> = {
    markdown: (data, options) => renderMarkdown.render(data, options),
    text: (data, options) => renderText.render(data, options),
  };

  const formatter = formatters[format];
  if (!formatter) {
    console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
    process.exit(1);
  }

  return formatter;
}

function main(): void {
  const args = parseArgs(process.argv);
  const data = readAndParseJson(args.dataFile);
  const formatter = getFormatter(args.format);

  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  const output = formatter(data, options);

  if (args.output) {
    try {
      writeFileSync(args.output, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();