import express, { Request, Response } from 'express';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { DatabaseManager } from './database.js';
import { FormData, validateFormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;
const dbManager = new DatabaseManager();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files from public directory
app.use(express.static(join(__dirname, '..', 'public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateFormData(formData);

    if (!validation.isValid) {
      res.status(400);
      return res.render('form', { 
        errors: validation.errors, 
        values: formData 
      });
    }

    // Store in database
    await dbManager.insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    });

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500);
    res.render('form', { 
      errors: ['An unexpected error occurred. Please try again.'], 
      values: req.body 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Extract firstName from query parameter or use a default
  const firstName = typeof req.query.firstName === 'string' ? req.query.firstName : 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen>;
async function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  try {
    await dbManager.close();
    console.log('Database closed');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

// Start server
export async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized');
    
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle SIGTERM for graceful shutdown
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start server if this module is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default { startServer };
