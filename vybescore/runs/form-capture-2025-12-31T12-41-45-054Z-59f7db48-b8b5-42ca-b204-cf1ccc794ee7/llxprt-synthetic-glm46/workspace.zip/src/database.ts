import initSqlJs from 'sql.js';

export type Database = InstanceType<typeof import('sql.js').Database>;
import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

export class DatabaseManager {
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = join(__dirname, '..', '..', 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      // Read schema.sql file
      const schemaPath = join(__dirname, '..', 'db', 'schema.sql');
      const schemaSQL = readFileSync(schemaPath, 'utf-8');

      // Initialize database (either from file or create new one)
      let dbData: Uint8Array;
      try {
        dbData = readFileSync(this.dbPath);
      } catch (error: unknown) {
        // File doesn't exist, create new database
        const SQL = await initSqlJs();
        this.db = new SQL.Database();
        this.db.run(schemaSQL);
        await this.saveDatabase();
        return;
      }

      const SQL = await initSqlJs();
      this.db = new SQL.Database(dbData);

      // Install schema if needed
      this.db.run(schemaSQL);
    } catch (error: unknown) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Ensure directory exists before writing
      const { dirname } = await import('path');
      const { mkdirSync } = await import('fs');
      
      try {
        mkdirSync(dirname(this.dbPath), { recursive: true });
      } catch (mkdirError: unknown) {
        // Directory might already exist, ignore
      }
      
      const data = this.db.export();
      writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error: unknown) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async insertSubmission(formData: {
    first_name: string;
    last_name: string;
    street_address: string;
    city: string;
    state_province: string;
    postal_code: string;
    country: string;
    email: string;
    phone: string;
  }): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.first_name,
        formData.last_name,
        formData.street_address,
        formData.city,
        formData.state_province,
        formData.postal_code,
        formData.country,
        formData.email,
        formData.phone
      ]);

      stmt.free();
      await this.saveDatabase();
    } catch (error: unknown) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}