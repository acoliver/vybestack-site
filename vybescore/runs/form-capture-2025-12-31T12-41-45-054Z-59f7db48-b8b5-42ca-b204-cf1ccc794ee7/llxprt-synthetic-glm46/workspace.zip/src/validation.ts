export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateFormData(formData: FormData): ValidationResult {
  const errors: string[] = [];

  // Required field validation
  if (!formData.firstName || formData.firstName.trim().length === 0) {
    errors.push('First name is required');
  }

  if (!formData.lastName || formData.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }

  if (!formData.streetAddress || formData.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }

  if (!formData.city || formData.city.trim().length === 0) {
    errors.push('City is required');
  }

  if (!formData.stateProvince || formData.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  }

  if (!formData.postalCode || formData.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  }

  if (!formData.country || formData.country.trim().length === 0) {
    errors.push('Country is required');
  }

  if (!formData.email || formData.email.trim().length === 0) {
    errors.push('Email is required');
  }

  if (!formData.phone || formData.phone.trim().length === 0) {
    errors.push('Phone number is required');
  }

  // Email validation (simple regex)
  if (formData.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push('Please enter a valid email address');
    }
  }

  // Phone validation (international formats with optional leading +)
  if (formData.phone) {
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
    }
  }

  // Postal code validation (alphanumeric)
  if (formData.postalCode) {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(formData.postalCode)) {
      errors.push('Postal code can only contain letters, digits, spaces, and dashes');
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}