declare module 'sql.js' {
  export default function ModuleOptions(): Promise<{
    Database: typeof Database;
    Statement: typeof Statement;
  }>;
  
  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export class Statement {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }
}