import { readFileSync, writeFile } from 'node:fs';
import { ReportData } from './types.js';

/**
 * Load and parse JSON data from a file path
 */
export function loadJsonData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Basic validation
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    const entries = reportData.entries.map((entry) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error('Invalid entry: expected an object');
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label"');
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid "amount"');
      }
      
      return {
        label: entryObj.label,
        amount: entryObj.amount,
      };
    }) as Array<{ label: string; amount: number }>;
    
    return {
      title: reportData.title,
      summary: reportData.summary,
      entries,
    } as ReportData;
  } catch (error: unknown) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${error.message}`);
    }
    if (error instanceof Error) {
      throw error;
    }
    throw new Error(`Unknown error: ${String(error)}`);
  }
}

/**
 * Calculate total of all entry amounts
 */
export function calculateTotal(entries: Array<{ label: string; amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Format amount as currency string with two decimal places
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Write content to stdout or file
 */
export function outputContent(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFile(outputPath, content, 'utf8', (error) => {
      if (error) {
        throw new Error(`Failed to write to ${outputPath}: ${error.message}`);
      }
    });
  } else {
    process.stdout.write(content);
  }
}