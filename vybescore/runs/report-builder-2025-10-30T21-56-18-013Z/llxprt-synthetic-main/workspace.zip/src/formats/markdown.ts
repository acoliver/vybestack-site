import { ReportData, FormatOptions, Formatter } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

/**
 * Render report data as markdown
 */
export const renderMarkdown: Formatter = (data: ReportData, options?: FormatOptions): string => {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries section
  lines.push('## Entries');
  lines.push('');
  
  // Entry list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  // Include totals if requested
  if (options?.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(``);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
};