#!/usr/bin/env node

/**
 * Report Builder CLI
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import { loadJsonData, outputContent } from '../utils.js';
import { formatters } from '../formats/index.js';
import { FormatOptions } from '../types.js';

interface CliArguments {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command line arguments
 */
function parseArguments(args: string[]): CliArguments {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  const result: CliArguments = {
    dataFile,
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Missing format argument after --format');
      }
      result.format = args[i + 1];
      i++; // Skip the next argument as it's the value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Missing output path argument after --output');
      }
      result.outputPath = args[i + 1];
      i++; // Skip the next argument as it's the value
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!result.format) {
    throw new Error('Format is required. Use --format <format>');
  }

  return result;
}

/**
 * Main function
 */
function main(): void {
  try {
    // Parse command line arguments
    const args = process.argv.slice(2);
    const { dataFile, format, outputPath, includeTotals } = parseArguments(args);

    // Check if the format is supported
    if (!formatters[format]) {
      throw new Error(`Unsupported format: ${format}`);
    }

    // Load and validate the JSON data
    const reportData = loadJsonData(dataFile);

    // Configure formatter options
    const options: FormatOptions = {
      includeTotals,
    };

    // Generate the report
    const formatter = formatters[format];
    const output = formatter(reportData, options);

    // Write the report to stdout or file
    outputContent(output, outputPath);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    console.error(`Unknown error: ${String(error)}`);
    process.exit(1);
  }
}

// Run the CLI
main();