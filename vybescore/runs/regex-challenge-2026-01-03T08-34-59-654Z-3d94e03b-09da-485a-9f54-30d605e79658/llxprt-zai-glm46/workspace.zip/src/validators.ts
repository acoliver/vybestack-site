export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with reasonable RFC 5322 compliance.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex - robust but practical
  // Local part: letters, digits, and special characters like . _ % + - but no consecutive dots
  // Domain: letters, digits, hyphens, and dots (but no leading/trailing/consecutive dots or underscores)
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

  // Additional checks for specific rejection patterns
  if (!emailRegex.test(value)) {
    return false;
  }

  // Reject double dots in local or domain part
  if (value.includes('..')) {
    return false;
  }

  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }

  // Reject domains with underscores (invalid in domain names)
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }

  // Reject dots at the start of local part or right after @
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // Check minimum length (10 digits for US number + optional 1 for country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }

  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    if (digitsOnly[0] !== '1') {
      return false;
    }
    phoneNumber = digitsOnly.slice(1);
  }

  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Match the format more strictly for the original string
  // Accept: (212) 555-7890, 212-555-7890, 212.555.7890, 2125557890, +1 212-555-7890
  const formatRegex = /^\+?1?\s*\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;

  return formatRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Argentine phone regex
  // Optional +54, optional 0 trunk prefix, optional 9 for mobile
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54|54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, areaCode, subscriber] = match;

  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  // If country code is omitted, must have trunk prefix 0 before area code
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  const hasTrunkPrefix = cleaned.startsWith('0') && !hasCountryCode;

  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  // Total digits check (country code: 0-2, trunk: 0-1, mobile: 0-1, area: 2-4, subscriber: 6-8)
  // Total should be between 8 and 14 digits
  const totalDigits = cleaned.replace(/\D/g, '').length;
  if (totalDigits < 8 || totalDigits > 14) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name should only contain: unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  // Should not contain digits or most symbols

  // Check for empty or whitespace-only names
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }

  // Check for invalid symbols (not letters, spaces, hyphens, apostrophes, or accented chars)
  // Allow unicode letters, common name punctuation
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must have at least one unicode letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Reject names that are just punctuation/spaces
  const letterContent = value.replace(/[^\p{L}\p{M}]/gu, '');
  if (letterContent.length === 0) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit card numbers.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  if (digits.length < 13) {
    return false;
  }

  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx).
 * Checks prefix, length, and performs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/;

  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const isValidPrefix = 
    visaRegex.test(cleaned) || 
    mastercardRegex.test(cleaned) || 
    amexRegex.test(cleaned);

  if (!isValidPrefix) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
