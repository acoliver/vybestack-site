/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences if missing.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence terminators (. ! ?) that are followed by lowercase
  // Then capitalize each sentence
  const sentences = text.split(/(?<=[.!?])\s+(?=[a-z])/);
  
  // Capitalize first letter of each sentence and normalize spacing
  const capitalized = sentences.map((sentence) => {
    if (!sentence) return '';
    // Collapse multiple spaces
    let collapsed = sentence.replace(/\s+/g, ' ').trim();
    // Capitalize first character (for all sentences including the first)
    if (collapsed.length > 0) {
      collapsed = collapsed[0].toUpperCase() + collapsed.slice(1);
    }
    return collapsed;
  });
  
  // Join with single spaces
  return capitalized.join(' ').trim();
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://
  // Captures the URL excluding trailing punctuation
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&/=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * Always upgrade to https://.
 * When path begins with /docs/, rewrite host to docs.example.com.
 * Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if this is example.com domain
    if (!host.includes('example.com')) {
      return newScheme + host + path;
    }
    
    // Check for dynamic hints that should skip host rewrite
    const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
    const hasLegacyExt = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#]|$)/i.test(path);
    const hasCgiBin = path.includes('/cgi-bin') || path.includes('cgi-bin');
    
    const shouldSkipHostRewrite = hasQueryString || hasLegacyExt || hasCgiBin;
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    if (isDocsPath && !shouldSkipHostRewrite) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
