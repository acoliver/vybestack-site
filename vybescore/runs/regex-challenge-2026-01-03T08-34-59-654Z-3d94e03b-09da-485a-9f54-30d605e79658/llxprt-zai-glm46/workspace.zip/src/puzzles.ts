/**
 * Find words starting with a prefix, excluding specified exception words.
 * Uses word boundaries and lookaheads for robust matching.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words starting with prefix
  // \b ensures word boundaries
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(word => !exceptionsLower.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit.
 * Token must not be at the start of the string.
 * Uses lookbehind to check for preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind to ensure token is preceded by a digit
  // (?<=\d) is a positive lookbehind for a digit
  // We capture the digit + token, then return the full match
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  // Return the full matches (including the digit)
  return matches;
}

/**
 * Validate passwords according to security policy.
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol/special character
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab")
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences of length 2-4 (e.g., "abab", "123123")
  // This regex captures repeating patterns
  const repeatedSequenceRegex = /(.{2,4})\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand with ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Full IPv6 form: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/;
  
  // IPv6 with :: shorthand (various positions)
  const shorthandStart = /\b::(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{1,4}\b/;
  const shorthandEnd = /\b(?:[a-fA-F0-9]{1,4}:){1,7}::\b/;
  const shorthandMiddle = /\b(?:[a-fA-F0-9]{1,4}:){1,6}::(?:[a-fA-F0-9]{1,4}:)*[a-fA-F0-9]{1,4}\b/;
  
  // Single :: cases
  const doubleColonOnly = /\b::\b/;
  const doubleColonStart = /\b::[a-fA-F0-9]{1,4}\b/;
  const doubleColonEnd = /\b[a-fA-F0-9]{1,4}::\b/;
  
  // Check for any IPv6 pattern
  const hasIPv6 = fullIPv6.test(value) || 
                  shorthandStart.test(value) || 
                  shorthandEnd.test(value) || 
                  shorthandMiddle.test(value) ||
                  doubleColonOnly.test(value) ||
                  doubleColonStart.test(value) ||
                  doubleColonEnd.test(value);
  
  if (hasIPv6) {
    // Make sure it's not a pure IPv4 address
    if (ipv4Pattern.test(value) && !value.includes(':')) {
      return false;
    }
    return true;
  }
  
  return false;
}
