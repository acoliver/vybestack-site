import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const schemaSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');

export default async function initDatabase(): Promise<unknown> {
  const SQL = await initSqlJs();
  
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  let db: unknown;
  
  // Check if database file exists
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer.buffer);
  } else {
    // Create new database
    db = new SQL.Database();
    
    // Create tables using schema
    (db as { run: (sql: string) => void }).run(schemaSql);
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Save initial database
    const data = (db as { export: () => ArrayBuffer }).export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
  
  return db;
}