import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initDatabase from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

let db: unknown;
let server: ReturnType<typeof app.listen>;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

app.post('/submit', (req, res) => {
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
  
  const errors: string[] = [];
  const values = { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone };
  
  // Validation
  if (!firstName?.trim()) errors.push('First name is required');
  if (!lastName?.trim()) errors.push('Last name is required');
  if (!streetAddress?.trim()) errors.push('Street address is required');
  if (!city?.trim()) errors.push('City is required');
  if (!stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!country?.trim()) errors.push('Country is required');
  if (!email?.trim()) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
    errors.push('Email is not valid');
  }
  if (!phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!/^[+]?[\d\s\-()]+$/.test(phone)) {
    errors.push('Phone number is not valid');
  }
  
  if (errors.length > 0) {
    return res.render('form', { errors, values });
  }
  
  try {
    // Insert into database
    const stmt = (db as { prepare: (sql: string) => unknown }).prepare('INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)');
    
    // Make sure all values are strings and handle undefined
    const values = [
      firstName || '',
      lastName || '',
      streetAddress || '',
      city || '',
      stateProvince || '',
      postalCode || '',
      country || '',
      email || '',
      phone || ''
    ];
    
    console.log('Inserting values:', values);
    
    (stmt as { run: (...params: unknown[]) => void }).run(...values);
    (stmt as { free: () => void }).free();
    
    // Save database to disk
    const data = (db as { export: () => ArrayBuffer }).export();
    fs.writeFileSync(path.join(__dirname, '../data/submissions.sqlite'), Buffer.from(data));
    
    console.log('Database successfully saved');
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    res.render('form', { errors, values });
  }
});

// Graceful shutdown
const gracefulShutdown = (signal: string) => {
  console.log(`Received ${signal}, shutting down gracefully`);
  
  if (server) {
    (server as { close: (cb: () => void) => void }).close(() => {
      console.log('HTTP server closed');
      
      if (db) {
        (db as { close: () => void }).close();
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
  }
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer() {
  try {
    // Initialize database
    db = await initDatabase();
    
    // Start Express server
    server = app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
    
    // Handle server errors
    server.on('error', (err: Error) => {
      console.error('Server error:', err);
      process.exit(1);
    });
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();
