declare module 'sql.js' {
  export default function initSqlJs(): Promise<{
    Database: new (data?: ArrayBuffer) => {
      run(sql: string, ...params: unknown[]): void;
      prepare(sql: string): {
        run(...params: unknown[]): unknown;
        free(): void;
      };
      export(): ArrayBuffer;
      close(): void;
    };
  }>;
}