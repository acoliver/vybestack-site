/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, ObserverR } from '../types/reactive.js'

// Global dependency tracking - Map from targets to set of dependent observers
const dependencyMap = new Map<ObserverR, Set<Observer<unknown>>>()

// Track dependencies for this callback
const trackedDependencies = new Set<ObserverR>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let currentValue = value
  
  // Create an observer that will track dependencies
  const observer: Observer<T> = {
    value: currentValue,
    updateFn: (newValue?: T): T => {
      if (disposed) return currentValue as T
      
      const previousActiveObserver = getActiveObserver()
      
      // Set this callback observer as active to track dependencies
      setActiveObserver(observer)
      
      try {
        currentValue = updateFn(newValue)
        return currentValue
      } finally {
        // Restore previous active observer
        setActiveObserver(previousActiveObserver)
      }
    }
  }

  // Run the update function initially to track dependencies
  if (!disposed) {
    const previousActiveObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      currentValue = updateFn(value)
    } finally {
      setActiveObserver(previousActiveObserver)
    }
  }

  // Create cleanup function
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all dependencies
    trackedDependencies.forEach((target) => {
      const dependents = dependencyMap.get(target)
      if (dependents) {
        dependents.delete(observer as Observer<unknown>)
        if (dependents.size === 0) {
          dependencyMap.delete(target)
        }
      }
    })
    trackedDependencies.clear()
  }

  return unsubscribe
}