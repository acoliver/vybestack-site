/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  EqualFn,
  Options,
  ObserverR
} from '../types/reactive.js'

// Global dependency tracking - Map from targets to set of dependent observers
const dependencyMap = new Map<ObserverR, Set<Observer<unknown>>>()

// Track this observer in the global dependency map
const trackObserver = (target: ObserverR, observer: Observer<unknown>) => {
  if (!dependencyMap.has(target as Observer<unknown>)) {
    dependencyMap.set(target as Observer<unknown>, new Set())
  }
  dependencyMap.get(target as Observer<unknown>)!.add(observer)
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T>
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (equal === false) {
    equalFn = () => false
  } else if (equal === undefined) {
    equalFn = (a, b) => a === b
  } else {
    equalFn = equal
  }

  const inputTarget: ObserverR = { name: options?.name }
  let currentValue = value

  const read = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      trackObserver(inputTarget as ObserverR, activeObserver as Observer<unknown>)
    }
    return currentValue
  }

  const write = (newValue: T): T => {
    if (!equalFn(currentValue, newValue)) {
      currentValue = newValue

      // Trigger updates for all observers that depend on this input
      const dependents = dependencyMap.get(inputTarget as Observer<unknown>)
      if (dependents) {
        // Create a copy of the dependents to avoid iteration issues
        const depsCopy = Array.from(dependents)
        depsCopy.forEach((observer) => {
          if (observer.updateFn) {
            observer.updateFn(observer.value)
          }
        })
      }
    }
    return newValue
  }

  return [read, write]
}