/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  ObserverR
} from '../types/reactive.js'

// Global dependency tracking - Map from targets to set of dependent observers
const dependencyMap = new Map<ObserverR, Set<Observer<unknown>>>()

// Track this observer in the global dependency map
const trackObserver = (target: ObserverR, observer: Observer<unknown>) => {
  if (!dependencyMap.has(target as Observer<unknown>)) {
    dependencyMap.set(target as Observer<unknown>, new Set())
  }
  dependencyMap.get(target as Observer<unknown>)!.add(observer)
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T>
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (equal === false) {
    equalFn = () => false
  } else if (equal === undefined) {
    equalFn = (a, b) => a === b
  } else {
    equalFn = equal
  }

  const computedTarget: ObserverR = { name: options?.name }
  let currentValue = value
  
  // Observer for this computed value
  const observer: Observer<T> = {
    name: options?.name,
    updateFn: (_newValue?: T): T => {
      // Recompute the value when dependencies change
      const previousActiveObserver = getActiveObserver()
      
      // Set this observer as active to track dependencies
      setActiveObserver(observer)
      
      try {
        const newComputedValue = updateFn(currentValue as T)
        if (currentValue === undefined || !equalFn(currentValue, newComputedValue)) {
          currentValue = newComputedValue
          
          // Notify dependent observers
          const dependents = dependencyMap.get(computedTarget as Observer<unknown>)
          if (dependents) {
            const depsCopy = Array.from(dependents)
            depsCopy.forEach((dependentObserver) => {
              if (dependentObserver.updateFn) {
                dependentObserver.updateFn(dependentObserver.value)
              }
            })
          }
        }
        return currentValue as T
      } finally {
        // Restore previous active observer
        setActiveObserver(previousActiveObserver)
      }
    }
  }

  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      trackObserver(computedTarget as ObserverR, activeObserver as Observer<unknown>)
    }

    // If value hasn't been computed yet, compute it
    if (currentValue === undefined) {
      const previousActiveObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        currentValue = updateFn()
      } finally {
        setActiveObserver(previousActiveObserver)
      }
    }
    
    return currentValue as T
  }

  return getter
}