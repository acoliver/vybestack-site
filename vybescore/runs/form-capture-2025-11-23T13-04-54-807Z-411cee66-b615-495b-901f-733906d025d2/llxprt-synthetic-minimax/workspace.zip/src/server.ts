import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';
import fs from 'fs';

const require = createRequire(import.meta.url);
const sqlJsModule = require('sql.js');
const initSqlJs = sqlJsModule.default || sqlJsModule;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Database management
interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => SqlJsDatabase;
}

interface SqlJsDatabase {
  exec: (sql: string) => void;
  prepare: (sql: string) => {
    run: (params: unknown[]) => void;
    free: () => void;
  };
  export: () => Uint8Array;
  close: () => void;
}

let sqlJs: SqlJsModule | null = null;
let db: SqlJsDatabase | null = null;

async function initializeDatabase(): Promise<void> {
  if (!initSqlJs) {
    throw new Error('sql.js not available');
  }
  
  const nodeModulesPath = path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist');
  
  sqlJs = await initSqlJs({
    locateFile: (file: string) => path.join(nodeModulesPath, file)
  });

  if (!sqlJs) {
    throw new Error('Failed to initialize sql.js');
  }

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    db = new (sqlJs as SqlJsModule).Database(fileBuffer);
  } else {
    db = new (sqlJs as SqlJsModule).Database();
    if (db) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
    }
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field]?.trim()) {
      errors[field] = 'This field is required';
    }
  }

  // Email validation
  if (data.email && data.email.trim()) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation
  if (data.phone && data.phone.trim()) {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && data.postalCode.trim()) {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  return errors;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Database configuration
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    data: {},
    pageTitle: 'Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (Object.keys(errors).length > 0) {
    // Re-render form with errors and previous values
    return res.status(400).render('form', {
      errors,
      data: formData,
      pageTitle: 'Contact Form'
    });
  }

  // Save to database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      data: formData,
      pageTitle: 'Contact Form'
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { pageTitle: 'Thank You!' });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  if (db) {
    db.close();
  }
  process.exit(0);
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    if (process.env.NODE_ENV !== 'test') {
      process.exit(1);
    }
  }
}

// Only start server if this file is run directly (not imported by tests)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default app;
export { startServer };