import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

interface ServerType {
  listen: (port: number) => { close: () => void };
}

let app: ServerType | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import the server module
  const serverModule = await import('../../src/server');
  app = serverModule.default;
  
  // Start server on test port
  if (app && app.listen) {
    // Use a specific port for testing
    const originalPort = process.env.PORT;
    process.env.PORT = '3537';
    
    try {
      await serverModule.startServer();
      // Give the server a moment to fully start
      await new Promise(resolve => setTimeout(resolve, 200));
    } catch (error) {
      console.error('Server startup failed:', error);
      throw error;
    }
    
    // Create test request handler
    if (app && typeof app === 'function') {
      // Ready to test
    }
    
    // Restore original port
    if (originalPort) {
      process.env.PORT = originalPort;
    }
  }
});

afterAll(() => {
  // The server.close() will be handled by the app's graceful shutdown
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    if (!app) return;
    
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toBeTruthy();
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (!app) return;
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1-555-0123'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
