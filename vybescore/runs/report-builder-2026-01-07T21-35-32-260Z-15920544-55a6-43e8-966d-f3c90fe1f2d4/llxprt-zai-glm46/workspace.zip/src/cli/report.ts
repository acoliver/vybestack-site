#!/usr/bin/env node
import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

type Renderer = (data: ReportData, options: RenderOptions) => string;

const RENDERERS: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText
};

function parseArgs(argv: string[]): CliArgs {
  const args: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false
  };

  for (let i = 0; i < argv.length; i++) {
    const arg = argv[i];

    if (arg === '--format' && i + 1 < argv.length) {
      args.format = argv[++i];
    } else if (arg === '--output' && i + 1 < argv.length) {
      args.outputPath = argv[++i];
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('-') && args.inputFile === '') {
      args.inputFile = arg;
    }
  }

  return args;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    return false;
  }

  if (typeof obj.summary !== 'string') {
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    return false;
  }

  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      return false;
    }
  }

  return true;
}

function loadJsonFile(filePath: string): ReportData {
  let content: string;

  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch {
    throw new Error(`Failed to read file: ${filePath}`);
  }

  let data: unknown;

  try {
    data = JSON.parse(content);
  } catch {
    throw new Error(`Invalid JSON in file: ${filePath}`);
  }

  if (!validateReportData(data)) {
    throw new Error(
      'Invalid report data structure. Expected { title: string, summary: string, entries: [{ label: string, amount: number }] }'
    );
  }

  return data;
}

function renderReport(format: string, data: ReportData, options: RenderOptions): string {
  const renderer = RENDERERS[format];

  if (!renderer) {
    throw new Error(`Unsupported format: ${format}. Supported formats: ${Object.keys(RENDERERS).join(', ')}`);
  }

  return renderer(data, options);
}

function writeOutput(content: string, outputPath: string | null): void {
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, content, 'utf-8');
    } catch {
      throw new Error(`Failed to write output file: ${outputPath}`);
    }
  } else {
    process.stdout.write(content);
    if (!content.endsWith('\n')) {
      process.stdout.write('\n');
    }
  }
}

function main(argv: string[]): void {
  try {
    const args = parseArgs(argv);

    if (!args.inputFile) {
      throw new Error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    }

    if (!args.format) {
      throw new Error('Missing required argument: --format');
    }

    const data = loadJsonFile(args.inputFile);
    const output = renderReport(args.format, data, { includeTotals: args.includeTotals });
    writeOutput(output, args.outputPath);
  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(`Error: ${error.message}\n`);
      process.exit(1);
    } else {
      process.stderr.write('Unknown error occurred\n');
      process.exit(1);
    }
  }
}

main(process.argv.slice(2));
