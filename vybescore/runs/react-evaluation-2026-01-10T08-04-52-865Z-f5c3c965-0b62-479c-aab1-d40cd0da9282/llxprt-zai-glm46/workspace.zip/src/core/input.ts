/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    observers: new Set<Observer<any>>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add this observer to the input's observers set
      s.observers.add(observer)
      // Track this input as a dependency of the current observer
      if (!observer.dependents) {
        observer.dependents = new Set()
      }
      observer.dependents.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    // Only notify if value changed (or if no equal function)
    if (!_equal || oldValue !== nextValue) {
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
