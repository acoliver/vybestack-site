/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev) => {
      // Clear the current dependencies before recomputing
      if (o.dependents) {
        for (const dep of o.dependents) {
          if ('observers' in dep) {
            dep.observers.delete(o)
          }
        }
        o.dependents.clear()
      }
      // Recompute the value - this will re-establish dependencies
      return updateFn(prev)
    },
    dependents: new Set(),
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // If called while another observer is active, this computed is being used as a dependency
      // Register this computed as a dependency of the active observer
      if (!observer.dependents) {
        observer.dependents = new Set()
      }
      observer.dependents.add(o)
      
      // Ensure our value is up-to-date by recomputing
      // This is necessary because our dependencies may have changed
      o.value = o.updateFn(o.value)
    }
    return o.value!
  }
  
  return getter
}
