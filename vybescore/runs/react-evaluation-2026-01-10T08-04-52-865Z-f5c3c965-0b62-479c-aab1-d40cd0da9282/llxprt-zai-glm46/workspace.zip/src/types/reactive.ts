/**
 * Type definitions for the reactive programming system.
 */

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<Dependent>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  observers: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export type Dependent = Observer<any> | Subject<any>

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let activeObserver: Observer<any> | undefined

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export function notifyObservers(subject: Subject<any>): void {
  // Create a copy to avoid issues if the set is modified during iteration
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    updateObserver(observer)
  }
}
