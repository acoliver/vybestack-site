import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer } from '../../src/server';
import request from 'supertest';

let server: Awaited<ReturnType<typeof startServer>>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Remove existing database for clean test
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server
  server = await startServer();
});

afterAll(() => {
  if (server && typeof server === 'object' && 'close' in server && typeof server.close === 'function') {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Database file should exist after submission
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
