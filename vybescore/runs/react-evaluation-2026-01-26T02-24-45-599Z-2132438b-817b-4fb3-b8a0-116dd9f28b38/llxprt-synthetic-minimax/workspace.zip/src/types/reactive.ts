/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  listeners?: Set<() => void>
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export interface SubjectR<T> {
  name?: string
  equalFn?: EqualFn<T>
}

export interface SubjectV<T> {
  value: T
  observers?: Set<ObserverR>
}

export type Subject<T> = SubjectR<T> & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObserver<T>(observer: ObserverR & { updateFn?: UpdateFn<T> }): void {
  if ('updateFn' in observer && observer.updateFn) {
    const typedObserver = observer as Observer<T>
    typedObserver.value = typedObserver.updateFn(typedObserver.value)
  }
}

export function notifySubject<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  // Create a copy to avoid issues during iteration
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    notifyObserver(observer)
  }
}
