/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  Subject,
  getActiveObserver,
  setActiveObserver,
  notifyObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const subject: Subject<T> = {
    name: options?.name,
    value: value as T, // assert non-undefined since subject requires T
    observers: new Set(),
  }
  
  const read: GetterFn<T> = () => {
    // Set this observer as active for dependency tracking
    const previous = getActiveObserver()
    setActiveObserver(subject as ObserverR)
    try {
      // Calculate new value - this will trigger dependency tracking
      const inputValue = observer.value
      const newValue = inputValue !== undefined ? updateFn(inputValue) : updateFn(undefined)
      observer.value = newValue
      subject.value = newValue
      
      // Notify all observers that depend on this computed value
      if (subject.observers && subject.observers.size > 0) {
        const observers = Array.from(subject.observers)
        for (const obs of observers) {
          notifyObserver(obs)
        }
      }
      
      return newValue
    } finally {
      // Restore previous active observer
      setActiveObserver(previous)
    }
  }

  return read
}
