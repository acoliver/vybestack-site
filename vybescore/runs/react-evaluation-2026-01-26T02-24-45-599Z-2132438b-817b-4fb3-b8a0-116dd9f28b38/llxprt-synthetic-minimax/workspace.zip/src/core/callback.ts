/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register with active subject for dependency tracking
  const activeSubject = getActiveObserver()
  if (activeSubject && 'observers' in activeSubject) {
    const subject = activeSubject as Subject<T>
    if (!subject.observers) subject.observers = new Set()
    subject.observers.add(observer)
    
    // If the active subject is also a computed getter, call it to initialize dependency tracking
    if (typeof (activeSubject as any) === 'function') {
      try {
        (activeSubject as any)()
      } catch (e) {
        // Not a function, ignore
      }
    }
    
    // Execute the callback immediately with current value if available
    const currentValue = subject.value
    if (currentValue !== undefined) {
      observer.value = updateFn(currentValue)
    }
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from subject's observers if we know the subject
    if (activeSubject && 'observers' in activeSubject) {
      const subject = activeSubject as Subject<unknown>
      subject.observers?.delete(observer)
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
