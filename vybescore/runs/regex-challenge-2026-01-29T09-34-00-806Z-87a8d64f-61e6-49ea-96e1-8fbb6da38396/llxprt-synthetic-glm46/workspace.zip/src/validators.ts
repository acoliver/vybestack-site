export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation rules
  // 1. No consecutive dots in local part
  // 2. No leading or trailing dots in local part
  // 3. No underscores in domain part
  // 4. No double dots in domain
  
  const localPart = value.split('@')[0];
  const domainPart = value.split('@')[1];
  
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  if (localPart.includes('..')) {
    return false;
  }
  
  if (domainPart.includes('_')) {
    return false;
  }
  
  if (domainPart.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn checksum algorithm.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let doubleDigit = false;

  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value[i], 10);
    let addend = digit;

    if (doubleDigit) {
      addend *= 2;
      if (addend > 9) {
        addend -= 9;
      }
    }

    sum += addend;
    doubleDigit = !doubleDigit;
  }

  return sum % 10 === 0;
}

/**
 * Validates US phone numbers with various formats.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  let cleanNumber = digitsOnly;
  if (cleanNumber.startsWith('1') && cleanNumber.length === 11) {
    cleanNumber = cleanNumber.substring(1);
  }
  
  // US phone numbers must have 10 digits after removing country code
  if (cleanNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = cleanNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format with regex
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)\s?|[2-9]\d{2}[-\s]?)[2-9]\d{2}[-\s]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering landlines and mobiles.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Strip non-digits for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional country code +54
  let cleanNumber = digitsOnly;
  let hasCountryCode = false;
  
  if (cleanNumber.startsWith('54')) {
    hasCountryCode = true;
    cleanNumber = cleanNumber.substring(2);
  }
  
  // Check for optional trunk prefix 0 when country code is omitted
  if (!hasCountryCode && !cleanNumber.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix for validation
  if (cleanNumber.startsWith('0')) {
    cleanNumber = cleanNumber.substring(1);
  }
  
  // Check for optional mobile indicator 9
  if (cleanNumber.startsWith('9')) {
    cleanNumber = cleanNumber.substring(1);
  }
  
  // Extract area code (can be 2-4 digits)
  let areaCodeLength = 2; // minimum
  
  // Try to find the right area code length
  if (cleanNumber.length >= 8) {
    // Try 4 digits first
    if (cleanNumber.length - 4 >= 6 && cleanNumber.length - 4 <= 8) {
      areaCodeLength = 4;
    }
    // Try 3 digits
    else if (cleanNumber.length - 3 >= 6 && cleanNumber.length - 3 <= 8) {
      areaCodeLength = 3;
    }
  }
  
  const areaCode = cleanNumber.substring(0, areaCodeLength);
  const subscriberNumber = cleanNumber.substring(areaCodeLength);
  
  // Validate area code (must be 2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Use regex to allow:
  // - Unicode letters (\p{L})
  // - Accents and diacritics (implicitly included in \p{L})
  // - Apostrophes and hyphens
  // - Spaces
  // At least one character is required and at most 100 characters
  // Reject digits and symbols like X Æ A-12
  
  const nameRegex = /^[\p{L}\p{M}'\-\s]{1,100}$/u;
  
  // Additional checks for invalid patterns
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject if starts or ends with space, hyphen, or apostrophe
  if (/^[ \-']|['\-"\s]$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using length/prefix validation and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const ccNumber = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(ccNumber)) {
    return false;
  }
  
  // Check length (13-19 digits for most cards)
  if (ccNumber.length < 13 || ccNumber.length > 19) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  if (/^4(\d{12}|\d{15})$/.test(ccNumber)) {
    return runLuhnCheck(ccNumber);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if ((/^(5[1-5]\d{14})$/.test(ccNumber)) || (/^(2[2-9]\d{0,2}|2[3-6]\d{0,1}|27[01]\d?)\d{12}$/.test(ccNumber))) {
    return runLuhnCheck(ccNumber);
  }
  
  // American Express: starts with 34 or 37, length 15
  if (/^(34|37)\d{13}$/.test(ccNumber)) {
    return runLuhnCheck(ccNumber);
  }
  
  // If none of the above patterns match, it's not a valid card
  return false;
}
