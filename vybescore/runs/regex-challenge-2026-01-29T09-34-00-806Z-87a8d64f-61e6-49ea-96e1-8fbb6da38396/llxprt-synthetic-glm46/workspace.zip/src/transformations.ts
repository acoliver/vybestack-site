/**
 * Capitalizes the first character of each sentence while preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  // Split text by sentence delimiters (.?!) preserving the delimiter
  const parts = text.split(/([.?!])/);
  
  // Process each sentence
  const processedParts = parts.map((part, index) => {
    // Text parts are at even indices (0, 2, 4, ...)
    if (index % 2 === 0 && part.length > 0) {
      // Trim leading whitespace from the part
      const trimmed = part.trimStart();
      // Capitalize first character if it exists
      if (trimmed.length > 0 && !/^[A-Z]/.test(trimmed[0])) {
        const capitalized = trimmed[0].toUpperCase() + trimmed.slice(1);
        // Restore original leading whitespace
        const leadingWhitespace = part.slice(0, part.length - trimmed.length);
        return leadingWhitespace + capitalized;
      }
    }
    return part;
  });
  
  // Join back and normalize spacing
  let result = processedParts.join('');
  // Ensure exactly one space after sentence end before a new sentence
  result = result.replace(/([.?!])(?=[\w])/g, '$1 ');
  // Collapse multiple spaces
  result = result.replace(/ {2,}/g, ' ');
  
  return result;
}

/**
 * Finds URLs in the text and returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with common schemes
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  let match;
  const urls: string[] = [];
  
  // Use a while loop to find all matches
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?'")\]]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/(?:www\.)?example\.com(\/[^?\s]*)/g, (match, path) => {
    // Always upgrade to HTTPS
    const upgradedUrl = match.replace(/^http:/, 'https:');
    
    // Check if the URL qualifies for host rewrite
    const hasQueryString = match.includes('?') || match.includes('&') || match.includes('=');
    const hasDynamicPath = path.includes('/cgi-bin/') || 
                            /\.(jsp|php|asp|aspx|do|cgi|pl|py)([/?]|$)/.test(path);
    
    // If it has a /docs/ path and doesn't contain dynamic elements, rewrite the host
    if (path.startsWith('/docs/') && !hasQueryString && !hasDynamicPath) {
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise, just return the HTTPS version
    return upgradedUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (simple validation)
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  // Adjust February days if it's a leap year
  if (month === 2 && isLeapYear(year)) {
    maxDays[1] = 29;
  }
  
  if (day > maxDays[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
