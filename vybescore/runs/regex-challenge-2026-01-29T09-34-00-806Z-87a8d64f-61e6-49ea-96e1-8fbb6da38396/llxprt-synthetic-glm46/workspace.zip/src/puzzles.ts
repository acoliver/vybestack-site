/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex and create a pattern to match words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'g');
  
  // Find all words with the prefix
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  const filtered = matches.filter(word => {
    // Handle word boundaries and check exact matches
    return !exceptions.includes(word);
  });
  
  // Return unique matches
  return [...new Set(filtered)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of the token that come after a digit
  const allRegex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(allRegex) || [];
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Validates passwords according to policy: at least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for character classes
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[^a-zA-Z0-9]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This checks for any pattern of two or more characters repeated immediately
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Check if this is a pure IPv4 address pattern (to exclude these)
  const ipv4Pattern = /^\s*((\d{1,3}(\.|\s|$)){4})\s*$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Simplified check for IPv6 patterns containing at least one colon
  return /:/.test(value);
}
