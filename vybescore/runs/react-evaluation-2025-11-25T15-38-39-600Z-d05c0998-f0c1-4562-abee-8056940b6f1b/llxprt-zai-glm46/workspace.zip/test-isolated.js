import { createInput, createComputed, createCallback } from './src/index.js'

// Replicate exact test case
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
createCallback(() => (value = output()))

console.log('Before setInput, value:', value)
console.log('Before setInput, output():', output())

setInput(3)

console.log('After setInput, value:', value)
console.log('After setInput, output():', output())