import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Test 1: Computed dependencies ===')
const [input1, setInput1] = createInput(1)
const timesTwo = createComputed(() => input1() * 2)
const timesThirty = createComputed(() => input1() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())
console.log('Initial sum:', sum())
setInput1(3)
console.log('After setInput1(3), sum:', sum())

console.log('\n=== Test 2: Callbacks ===')
// Clear global state for clean test
globalThis.__computedRegistry = undefined
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
console.log('Before creating callback, value:', value)
createCallback(() => { 
  value = output(); 
  console.log('Callback triggered, input2():', input2(), 'output():', output())
})
console.log('After creating callback, value:', value)
console.log('Before setInput2(3), value:', value)
setInput2(3)
console.log('After setInput2(3), value:', value)

console.log('\n=== Test 3: Add/remove callbacks ===')
// Clear global state for clean test
globalThis.__computedRegistry = undefined
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => values1.push(output3()))
console.log('values1 after first update:', values1)
const values2 = []
createCallback(() => values2.push(output3()))

setInput3(31) // First change
console.log('values1 after second update:', values1)
unsubscribe1()
setInput3(51) // Second change
console.log('values1 after unsubscribing first callback:', values1)
console.log('values2 after unsubscribing first callback:', values2)
console.log('values1 length:', values1.length, 'values2 length:', values2.length)