import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing basic callback behavior...')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log('Initial output:', output())

let value = 0

const callbackObserver = {
  value: undefined,
  updateFn: () => {
    console.log('Callback running! input() =', input(), 'output() =', output())
    value = output()
  }
}

createCallback(() => {
  console.log('Callback running! input() =', input(), 'output() =', output())
  value = output()
})

console.log('After creating callback, value:', value)

console.log('Setting input to 3...')
setInput(3)

console.log('After setInput(3), value:', value)
console.log('Current output:', output())