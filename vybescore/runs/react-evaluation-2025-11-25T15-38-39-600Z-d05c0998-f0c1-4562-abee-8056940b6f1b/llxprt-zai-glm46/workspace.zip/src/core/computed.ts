/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'
import { registerComputed, notifyComputedObservers } from './enhanced-notify.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const observers = new Set<unknown>()
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: []
  }
  
  const getter: GetterFn<T> = (): T => {
    const active = getActiveObserver()
    
    // If there's an active observer, register this computed with it
    if (active && active.dependencies) {
      // Check if this observer is already registered
      if (!active.dependencies.includes(observers)) {
        active.dependencies.push(observers)
      }
    }
    
    // Clear previous dependencies before recomputing
    observer.dependencies!.length = 0
    
    // Set this computed as the active observer so inputs can register with us
    setActiveObserver(observer)
    try {
      // Execute the compute function to get current value
      const newValue = updateFn(observer.value)
      observer.value = newValue
      return newValue
    } finally {
      // Restore the previous active observer
      setActiveObserver(active)
    }
  }
  
  // Register computed observer with enhanced notify system
  registerComputed(observer as Observer<unknown>, {
    observers, 
    getter: getter as GetterFn<unknown>
  })
  
  return getter
}

// Re-export enhanced notify function
export { notifyComputedObservers }