/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Observer
} from '../types/reactive.js'

// Import the enhanced notify function
import { notifyComputedObservers } from './computed.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const observers = new Set<unknown>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer)
      
      // Track dependency for computed observers
      const computedObserver = observer as Observer<unknown>
      if (computedObserver.dependencies) {
        computedObserver.dependencies.push(observers)
      }
    }
    return value
  }

  const write: SetterFn<T> = (newValue: T) => {
    // Check if value actually changed
    if (equalFn && equalFn(value, newValue)) {
      return value
    }
    
    value = newValue
    
    // Use the enhanced notify function
    notifyComputedObservers(observers)
    return value
  }

  return [read, write]
}