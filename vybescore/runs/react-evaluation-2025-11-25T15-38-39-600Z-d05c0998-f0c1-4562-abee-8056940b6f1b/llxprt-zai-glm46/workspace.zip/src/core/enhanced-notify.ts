/**
 * Enhanced notify function that also updates computed values.
 */

import { 
  getActiveObserver,
  setActiveObserver,
  notifyObservers,
  Observer,
  GetterFn
} from '../types/reactive.js'

interface ComputedRegistry {
  observers: Set<unknown>
  getter: GetterFn<unknown>
}

interface CallbackRegistry {
  observer: Observer<unknown>
  dependencies: Set<unknown>[]
  disposed: () => boolean
}

export function createEnhancedNotify() {
  const computedRegistry = new Map<Observer<unknown>, ComputedRegistry>()
  const callbackRegistry = new Set<CallbackRegistry>()

  function registerComputed(observer: Observer<unknown>, registry: ComputedRegistry) {
    computedRegistry.set(observer, registry)
  }

  function registerCallback(callbackInfo: CallbackRegistry) {
    callbackRegistry.add(callbackInfo)
  }

  function notifyComputedObservers(changedObservers?: Set<unknown>) {
    // First notify regular observers
    notifyObservers(changedObservers)
    
    if (!changedObservers) return
    
    // Keep processing until no more updates are needed
    let hasUpdates = true
    while (hasUpdates) {
      hasUpdates = false
      
      // Find computed values that depend on changed observers
      const toProcess: Array<{observer: Observer<unknown>, registry: ComputedRegistry}> = []
      for (const [observer, registry] of computedRegistry) {
        if (observer.dependencies && observer.dependencies.some((dep: Set<unknown>) => dep === changedObservers)) {
          toProcess.push({ observer, registry })
        }
      }
      
      // Process each computed value
      for (const { observer, registry } of toProcess) {
        // Recompute this computed value
        const active = getActiveObserver()
        observer.dependencies!.length = 0
        setActiveObserver(observer)
        try {
          const newValue = observer.updateFn(observer.value)
          observer.value = newValue
        } finally {
          setActiveObserver(active)
        }
        
        // Notify observers of this computed value
        if (registry.observers && registry.observers.size > 0) {
          notifyObservers(registry.observers)
          hasUpdates = true
          
          // Update for next iteration
          changedObservers = registry.observers
        }
      }
    }
  }

  return {
    registerComputed,
    registerCallback,
    notifyComputedObservers
  }
}

// Global enhanced notify instance
const enhancedNotify = createEnhancedNotify()
;(globalThis as { [key: string]: unknown }).__enhancedNotify = enhancedNotify

export const { registerComputed, registerCallback, notifyComputedObservers } = enhancedNotify