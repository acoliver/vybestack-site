/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'
import { registerCallback } from './enhanced-notify.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const dependencies: Set<unknown>[] = []
  
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies,
  }
  
  let disposed = false
  
  // Initial execution to track dependencies and run side effect
  updateObserver(observer)
  
  // Register callback with enhanced notify system
  registerCallback({ 
    observer: observer as Observer<unknown>, 
    dependencies, 
    disposed: () => disposed 
  })
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Remove from all dependency sets
    dependencies.forEach(depSet => {
      if (depSet) {
        depSet.delete(observer)
      }
    })
    dependencies.length = 0
  }
  
  return unsubscribe
}