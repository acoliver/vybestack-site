import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing library import ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
createCallback(() => (value = output()))
setInput(3)

console.log('Final value:', value)