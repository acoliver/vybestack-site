import { createInput, createComputed, createCallback } from './src/index.js'

// Test case 1: compute cells can depend on other compute cells
console.log('=== Test 1: Computed dependencies ===')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum:', sum()) // Should be 32
setInput(3)
console.log('After setInput(3), sum:', sum()) // Should be 96

// Test case 2: compute cells fire callbacks
console.log('\n=== Test 2: Callbacks ===')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0

console.log('Before creating callback, value:', value)
createCallback(() => {
  console.log('Callback triggered, input2():', input2(), 'output():', output())
  value = output()
})
console.log('After creating callback, value:', value)

console.log('Before setInput2(3), value:', value)
setInput2(3)
console.log('After setInput2(3), value:', value) // Should be 4

// Test case 3: callbacks can be added and removed
console.log('\n=== Test 3: Add/remove callbacks ===')
const [input3, setInput3] = createInput(11)
const output2 = createComputed(() => input3() + 1)

const values1 = []
const unsub1 = createCallback(() => values1.push(output2()))

setInput3(12)
console.log('values1 after first update:', values1)

const unsub2 = createCallback(() => values1.push(output2() * 10))
setInput3(13)
console.log('values1 after second update:', values1)

unsub1()
setInput3(14)
console.log('values1 after unsubscribing first callback:', values1)

unsub2()
setInput3(15)
console.log('values1 after unsubscribing second callback:', values1)