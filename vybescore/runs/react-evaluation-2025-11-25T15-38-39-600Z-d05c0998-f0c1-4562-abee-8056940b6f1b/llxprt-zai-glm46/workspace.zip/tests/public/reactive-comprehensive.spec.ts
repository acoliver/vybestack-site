import { describe, it, expect, beforeAll } from 'vitest'
import { createInput, createComputed, createCallback } from '../../src/index.js'

describe('Reactive Programming - Additional Regression Cases', () => {
  beforeAll(() => {
    // Clear any global state between tests
    delete (globalThis as { [key: string]: unknown }).__computedRegistry
  })

  it('compute cells can depend on other compute cells', () => {
    const [input, setInput] = createInput(1)
    const timesTwo = createComputed(() => input() * 2)
    const timesThirty = createComputed(() => input() * 30)
    const sum = createComputed(() => timesTwo() + timesThirty())
    expect(sum()).toEqual(32)
    setInput(3)
    expect(sum()).toEqual(96)
  })

  it('compute cells fire callbacks', () => {
    const [input, setInput] = createInput(1)
    const output = createComputed(() => input() + 1)
    let value = 0
    createCallback(() => (value = output()))
    expect(value).toEqual(2) // Initial callback execution
    setInput(3)
    expect(value).toEqual(4) // Callback should be triggered by the change
  })

  it('callbacks can be added and removed', () => {
    const [input, setInput] = createInput(11)
    const output = createComputed(() => input() + 1)

    const values1: number[] = []
    const unsubscribe1 = createCallback(() => values1.push(output()))
    const values2: number[] = []
    createCallback(() => values2.push(output()))

    setInput(31) // First change - both callbacks should trigger
    expect(values1.length).toBeGreaterThan(1)
    expect(values2.length).toBeGreaterThan(1)
    unsubscribe1()
    setInput(51) // Second change - only second callback should trigger
    expect(values1.length).toBe(1) // First callback unsubscribed
    expect(values2.length).toBeGreaterThan(1) // Second callback still active
  })
})