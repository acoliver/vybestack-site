import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing Reactively ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log('input():', input())
console.log('output():', output())

let value = 0

console.log('Creating callback...')
const unsubscribe = createCallback(() => {
  console.log('Callback executed! input():', input(), 'output():', output())
  value = output()
})

console.log('After callback creation, value:', value)
console.log('output():', output())

console.log('Setting input to 3...')
setInput(3)

console.log('After setInput(3), value:', value)
console.log('input():', input())
console.log('output():', output())

console.log('Unsubscribing...')
unsubscribe()

console.log('Setting input to 5...')
setInput(5)

console.log('After unsubscribe, value:', value)
console.log('input():', input())
console.log('output():', output())