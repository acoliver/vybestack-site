import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  public app: express.Application;
  private server: import('http').Server | null = null;
  private db: Database | null = null;
  private dbInitialized = false;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private async initializeDatabase(): Promise<void> {
    if (this.dbInitialized) return;
    
    try {
      const SQL = await initSqlJs();
      
      // Load existing database or create new one
      let dbData = null;
      if (fs.existsSync(dbPath)) {
        const dbFile = fs.readFileSync(dbPath);
        dbData = new Uint8Array(dbFile);
      }
      
      this.db = new SQL.Database(dbData);
      
      // Create table if it doesn't exist
      const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      this.db.run(schema);
      
      this.dbInitialized = true;
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, '..', 'templates'));
  }

  private validateForm(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields = [
      { field: 'firstName', name: 'First name' },
      { field: 'lastName', name: 'Last name' },
      { field: 'streetAddress', name: 'Street address' },
      { field: 'city', name: 'City' },
      { field: 'stateProvince', name: 'State/Province/Region' },
      { field: 'postalCode', name: 'Postal/Zip code' },
      { field: 'country', name: 'Country' },
      { field: 'email', name: 'Email' },
      { field: 'phone', name: 'Phone number' }
    ];

    for (const { field, name } of requiredFields) {
      const value = data[field as keyof FormData];
      if (!value || typeof value !== 'string' || value.trim().length === 0) {
        errors.push({ field, message: `${name} is required` });
      }
    }

    // Email validation
    if (data.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({ field: 'email', message: 'Please enter a valid email address' });
      }
    }

    // Phone validation - allow international formats
    if (data.phone) {
      // eslint-disable-next-line no-useless-escape
      const phoneRegex = /^\+?[\d\s()\-]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
      }
    }

    // Postal code validation - allow alphanumeric
    if (data.postalCode) {
      const postalRegex = /^[a-zA-Z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
      }
    }

    return errors;
  }

  private setupRoutes(): void {
    // Home page - form
    this.app.get('/', async (req, res) => {
      try {
        await this.initializeDatabase();
        const formData = req.query;
        const errors = req.query.errors ? JSON.parse(req.query.errors as string) : [];
        
        res.render('form', {
          formData,
          errors,
          title: 'Friendly Contact Form'
        });
      } catch (error) {
        console.error('Error rendering form:', error);
        res.status(500).send('Internal Server Error');
      }
    });

    // Form submission
    this.app.post('/submit', async (req, res) => {
      try {
        await this.initializeDatabase();
        
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const errors = this.validateForm(formData);
        
        if (errors.length > 0) {
          // Return to form with errors
          const queryParams = new URLSearchParams({
            errors: JSON.stringify(errors.map(e => e.message)),
            ...formData
          });
          return res.redirect(`/?${queryParams.toString()}`);
        }

        // Insert into database
        const stmt = this.db!.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName.trim(),
          formData.lastName.trim(),
          formData.streetAddress.trim(),
          formData.city.trim(),
          formData.stateProvince.trim(),
          formData.postalCode.trim(),
          formData.country.trim(),
          formData.email.trim(),
          formData.phone.trim()
        ]);
        stmt.free();

        // Save database to disk
        const data = this.db!.export();
        const buffer = Buffer.from(data);
        fs.writeFileSync(dbPath, buffer);

        // Redirect to thank you page
        res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
      } catch (error) {
        console.error('Error processing form submission:', error);
        res.status(500).send('Internal Server Error');
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req, res) => {
      const firstName = req.query.firstName as string || 'Friend';
      
      res.render('thank-you', {
        firstName,
        title: 'Thank You!'
      });
    });
  }

  public async start(port: number = 3535): Promise<void> {
    try {
      await this.initializeDatabase();
      
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });

      // Handle graceful shutdown
      process.on('SIGTERM', () => this.shutdown());
      process.on('SIGINT', () => this.shutdown());
      
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  public async shutdown(): Promise<void> {
    console.log('Shutting down server...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
      });
    }
    
    if (this.db) {
      this.db.close();
      console.log('Database closed');
    }
    
    process.exit(0);
  }
}

// Start server
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const server = new FormServer();

// Export for testing
export { FormServer };
export default server;

// Auto-start if this file is run directly
if (import.meta.url === `file://${path.resolve(process.argv[1])}`) {
  server.start(port);
}