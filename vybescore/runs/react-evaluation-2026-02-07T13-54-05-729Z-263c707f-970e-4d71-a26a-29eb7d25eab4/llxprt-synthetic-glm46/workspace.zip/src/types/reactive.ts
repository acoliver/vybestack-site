/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  active?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  observer?: ObserverR
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  active: boolean
  observers?: Set<ObserverR>
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined,
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Global registry of all subjects for cleanup purposes
const allSubjects = new Set<ObserverR>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function removeObserverFromDependencies(observerToRemove: ObserverR): void {
  // Actually remove the observer from all subjects' observer sets
  for (const subject of allSubjects) {
    if ('observers' in subject && subject.observers instanceof Set) {
      subject.observers.delete(observerToRemove)
    }
  }
}

export function registerSubject(subject: ObserverR): void {
  allSubjects.add(subject)
}

export function unregisterSubject(subject: ObserverR): void {
  allSubjects.delete(subject)
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Update dependent observers
  notifyDependents(observer)
}

export function notifyDependents<T>(observer: Observer<T>): void {
  // Update single dependent observer
  if (observer.observer && (observer.observer as Observer<T>).active !== false) {
    const dependentObserver = observer.observer as Observer<T>
    // Trigger recompute by calling the update again  
    updateObserver(dependentObserver)
  }
  
  // Update all subscribers in the observers set
  if (observer.observers) {
    const observersToRemove: ObserverR[] = []
    for (const subscriber of observer.observers) {
      if (subscriber.active === false) {
        observersToRemove.push(subscriber)
      } else {
        updateObserver(subscriber as Observer<T>)
      }
    }
    
    // Clean up disposed observers
    for (const observerToRemove of observersToRemove) {
      observer.observers!.delete(observerToRemove)
    }
  }
}
