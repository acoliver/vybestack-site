/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, removeObserverFromDependencies } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let latestValue: T | undefined = value
  
  const callbackObserver: Observer<T> = {
    value: latestValue,
    active: true,
    observers: new Set(),
    updateFn: () => {
      if (disposed) return latestValue as T
      latestValue = updateFn()
      return latestValue
    }
  }
  
  // Execute the callback once to establish dependencies
  const prevActive = getActiveObserver()
  setActiveObserver(callbackObserver)
  try {
    latestValue = updateFn()
    callbackObserver.value = latestValue
  } finally {
    setActiveObserver(prevActive)
  }
  
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates and remove from subscriptions
    callbackObserver.value = undefined
    callbackObserver.active = false
    
    // Remove from all subjects' observer lists
    removeObserverFromDependencies(callbackObserver)
  }
  
  return unsubscribe
}
