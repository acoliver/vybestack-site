/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerSubject,
  unregisterSubject
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? ((a, b) => a === b) : 
    equal === false || equal === undefined ? undefined : 
    equal as EqualFn<T>

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: new Set(),
  }
  
  // Register this subject for cleanup tracking
  registerSubject(s)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Only add the observer if it's still active
      if (observer.active !== false) {
        s.observer = observer
        // Add to subscribers list
        if (s.observers) {
          s.observers.add(observer)
        }
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    s.value = nextValue
    if (s.observer) updateObserver(s.observer as Observer<T>)
    
    // Notify all subscribers
    if (s.observers) {
      const observersToRemove: ObserverR[] = []
      for (const subscriber of s.observers) {
        if (subscriber.active === false) {
          observersToRemove.push(subscriber)
        } else {
          // Always update active observers
          updateObserver(subscriber as Observer<T>)
        }
        }
      }
      
      // Clean up disposed observers
      for (const observerToRemove of observersToRemove) {
        s.observers.delete(observerToRemove)
      }
    }
    
    return s.value
  }

  return [read, write]
}
