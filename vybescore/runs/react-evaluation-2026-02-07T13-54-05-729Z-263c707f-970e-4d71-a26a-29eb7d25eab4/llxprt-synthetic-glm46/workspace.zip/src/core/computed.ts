/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  Options,
  registerSubject,
  unregisterSubject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = 
    equal === true ? ((a, b) => a === b) : 
    equal === false || equal === undefined ? undefined : 
    equal as EqualFn<T>

  let cachedValue = value

  const o: Observer<T> = {
    name: options?.name,
    value: cachedValue,
    observer: undefined,
    active: true,
    updateFn: updateFn,
    observers: new Set()
  }
  
  // Register this observer for cleanup tracking
  registerSubject(o)

  // Add recompute flag
  let isRecomputing = false
  let isUploading = false

  const getter: GetterFn<T> = () => {
    // Prevent infinite recursion
    if (isRecomputing) {
      return cachedValue!
    }
    
    const activeObserver = getActiveObserver()
    
    // Register this computed as a dependency for the active observer
    if (activeObserver) {
      if (!o.observer) {
        o.observer = activeObserver
      }
      
      // Add to subscribers list if active and not already subscribed
      if (o.observers && activeObserver.active !== false && !o.observers.has(activeObserver)) {
        o.observers.add(activeObserver)
      }
    }
    
    // Recompute when accessed since this creates reactive dependencies
    const prev = getActiveObserver()
    isRecomputing = true
    try {
      setActiveObserver(o)
      const newValue = updateFn()
      
      // Only update if value actually changed
      const hasChanged = !equalFn || !equalFn(cachedValue!, newValue)
      if (hasChanged) {
        cachedValue = newValue
        o.value = cachedValue

        // Notify all dependent observers about the change if value changed
        // but defer until after this getter completes to avoid reentrancy
        if (!isUploading) {
          isUploading = true
          if (o.observers) {
            const observersToRemove: ObserverR[] = []
            for (const subscriber of o.observers) {
              if (subscriber.active === false) {
                observersToRemove.push(subscriber)
              } else {
                updateObserver(subscriber as Observer<T>)
              }
            }
            
            // Clean up disposed observers
            for (const observerToRemove of observersToRemove) {
              o.observers.delete(observerToRemove)
            }
          }
          isUploading = false
        }
      }
    } finally {
      setActiveObserver(prev)
      isRecomputing = false
    }

    return cachedValue!
  }
  
  return getter
}
