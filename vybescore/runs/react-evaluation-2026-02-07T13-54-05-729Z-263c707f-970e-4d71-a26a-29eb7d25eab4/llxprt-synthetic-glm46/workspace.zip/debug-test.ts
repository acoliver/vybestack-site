import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing Callback Subscription ===')

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => values1.push(output()))

const values2: number[] = []
const unsubscribe2 = createCallback(() => values2.push(output()))

console.log('Initial state:')
console.log('input():', input())
console.log('output():', output())
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nAfter setInput(31):')
setInput(31)
console.log('input():', input())
console.log('output():', output())
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nAfter unsubscribe1():')
unsubscribe1()
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nAfter setInput(41):')
setInput(41)
console.log('input():', input())
console.log('output():', output())
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nFinal counts:')
console.log('values1.length:', values1.length)
console.log('values2.length:', values2.length)
console.log('Did unsubscribe work?', values2.length > values1.length ? 'YES' : 'NO')