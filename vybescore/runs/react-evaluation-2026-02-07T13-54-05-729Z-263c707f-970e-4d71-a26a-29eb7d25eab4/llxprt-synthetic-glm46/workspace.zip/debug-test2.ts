import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Starting debug test...')

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

console.log('Input value:', input())
console.log('Computed value:', output())

const values1: number[] = []
const unsubscribe1 = createCallback(() => {
  const val = output()
  console.log('Callback 1 triggered with value:', val)
  values1.push(val)
})

const values2: number[] = []
const unsubscribe2 = createCallback(() => {
  const val = output()
  console.log('Callback 2 triggered with value:', val)
  values2.push(val)
})

console.log('Setting input to 31...')
setInput(31)
console.log('After first update, values1 count:', values1.length, 'values2 count:', values2.length)

console.log('Unsubscribing callback 1...')
unsubscribe1()
console.log('Setting input to 41...')
setInput(41)

console.log('After second update, values1 count:', values1.length, 'values2 count:', values2.length)

console.log('Expected: values1 > 0 and values2 > values1')
console.log('Actual: values1 =', values1.length, ', values2 =', values2.length)
console.log('Test passed?', values2.length > values1.length)