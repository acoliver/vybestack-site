// Quick manual tests for edge cases
import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== Email Tests ===');
console.log('name@tag@example.co.uk:', isValidEmail('name@tag@example.co.uk'));
console.log('user@example.com:', isValidEmail('user@example.com'));
console.log('user..name@example.com:', isValidEmail('user..name@example.com'));
console.log('user@domain_.com:', isValidEmail('user@domain_.com'));

console.log('\n=== US Phone Tests ===');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('2125557890:', isValidUSPhone('2125557890'));
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('012-555-7890 (bad area code):', isValidUSPhone('012-555-7890'));

console.log('\n=== Argentine Phone Tests ===');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567'));

console.log('\n=== Name Tests ===');
console.log('Jane Doe:', isValidName('Jane Doe'));
console.log('José María:', isValidName('José María'));
console.log('O\'Neill:', isValidName("O'Neill"));
console.log('X Æ A-12:', isValidName('X Æ A-12'));

console.log('\n=== Credit Card Tests ===');
console.log('4111111111111111 (Visa):', isValidCreditCard('4111111111111111'));
console.log('5500000000000004 (MC):', isValidCreditCard('5500000000000004'));
console.log('340000000000009 (AmEx):', isValidCreditCard('340000000000009'));
console.log('4111111111111112 (bad checksum):', isValidCreditCard('4111111111111112'));

console.log('\n=== Capitalize Sentences ===');
console.log(capitalizeSentences('hello world.how are you?i am fine.'));
console.log(capitalizeSentences('mr. smith went to washington. d.c. yesterday.'));

console.log('\n=== Extract URLs ===');
console.log(extractUrls('Visit https://example.com and http://test.com/foo!'));
console.log(extractUrls('Check out https://example.com/path?query=1 for more.'));

console.log('\n=== Enforce HTTPS ===');
console.log(enforceHttps('Visit http://example.com and https://secure.com'));

console.log('\n=== Rewrite Docs URLs ===');
console.log(rewriteDocsUrls('See http://example.com/docs/api for info'));
console.log(rewriteDocsUrls('See http://example.com/docs/api/v1/users'));
console.log(rewriteDocsUrls('See http://example.com/docs/api.cgi?x=1'));

console.log('\n=== Extract Year ===');
console.log('12/25/2023:', extractYear('12/25/2023'));
console.log('13/01/2023 (invalid):', extractYear('13/01/2023'));
console.log('02/30/2023 (invalid):', extractYear('02/30/2023'));

console.log('\n=== Find Prefixed Words ===');
console.log(findPrefixedWords('unhappy undo unrest unless', 'un', ['unless']));
console.log(findPrefixedWords('pretest preview posttest', 'pre', []));

console.log('\n=== Find Embedded Token ===');
console.log(findEmbeddedToken('123abc 456abc abc123', 'abc'));
console.log(findEmbeddedToken('test123token 123token token123', 'token'));

console.log('\n=== Strong Password ===');
console.log('StrongP@ssw0rd:', isStrongPassword('StrongP@ssw0rd'));
console.log('ababcABC!123:', isStrongPassword('ababcABC!123'));
console.log('Weak1:', isStrongPassword('Weak1'));
console.log('NoSymbols1Aa:', isStrongPassword('NoSymbols1Aa'));

console.log('\n=== Contains IPv6 ===');
console.log('2001:db8::1:', containsIPv6('2001:db8::1'));
console.log('::1:', containsIPv6('::1'));
console.log('192.168.1.1:', containsIPv6('192.168.1.1'));
console.log('fe80::1%eth0:', containsIPv6('fe80::1%eth0'));
