export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with strict rules.
 * - Accepts typical addresses like name@tag@example.co.uk
 * - Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // More permissive regex that allows subdomain addressing (name@tag@example.co.uk)
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local or domain part
  if (value.startsWith('.') || value.endsWith('.') || 
      value.includes('@.') || value.includes('.@')) {
    return false;
  }
  
  // Reject domains with underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * - Supports: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallows area codes starting with 0 or 1
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check if extensions are allowed (not currently used but kept for API compatibility)
  if (options?.allowExtensions) {
    // Future extension handling could go here
  }
  
  // Check minimum length
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match pattern: +54 [9] [0] area_code subscriber OR 0 [9] area_code subscriber
  // Area code: 2-4 digits starting with 1-9 (after optional trunk prefix)
  // Subscriber: 6-8 digits
  const argentinaPhoneRegex = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinaPhoneRegex.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(argentinaPhoneRegex);
  if (!match) return false;
  
  const hasCountryCode = match[1] !== undefined;
  const hasTrunkPrefix = match[3] !== undefined;
  
  // When country code is omitted, must start with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * - Rejects digits, symbols, and unusual names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols (except allowed punctuation)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx.
 * - Checks prefix and length
 * - Performs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 4 prefix, 13 or 16 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 51-55 or 2221-2720 prefix, 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/;
  
  // AmEx: 34 or 37 prefix, 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || 
                        mastercardRegex.test(cleaned) || 
                        amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}
