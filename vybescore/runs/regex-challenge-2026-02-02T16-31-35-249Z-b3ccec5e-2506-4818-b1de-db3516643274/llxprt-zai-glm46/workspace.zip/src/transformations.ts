/**
 * Capitalizes the first character of each sentence.
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Insert space between sentences if missing (after punctuation, before letter)
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first letter of string
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Capitalize after sentence-ending punctuation (. ? !) followed by space
  // Don't modify other letters in the sentence
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts all URLs from text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:[-\w.]|(?:%[\da-fA-F]{2})|[!*(),]|(?:[:][^\s]))+(?<![.,!?;:])/g;
  const matches = text.match(urlRegex);
  return matches || [];
}

/**
 * Converts all http:// URLs to https://.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... to https://..., with special handling for docs paths.
 * - Upgrades scheme to https
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/example\.com\/[^\s]*)/g;
  
  return text.replace(urlPattern, (url) => {
    // First, upgrade to https
    let rewrittenUrl = url.replace(/^http:\/\//, 'https://');
    
    // Parse the URL to check the path
    const match = url.match(/^https?:\/\/example\.com(\/[^\s?]*)/);
    if (match) {
      const path = match[1];
      const remaining = url.substring(url.indexOf(path) + path.length);
      
      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints that would prevent host rewrite
        const hasDynamicHint = 
          path.includes('/cgi-bin') || 
          path.includes('?') || 
          path.includes('&') || 
          path.includes('=') ||
          /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
        
        if (!hasDynamicHint) {
          // Rewrite host to docs.example.com
          rewrittenUrl = `https://docs.example.com${path}${remaining}`;
        }
      }
    }
    
    return rewrittenUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Assuming leap year for Feb
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
