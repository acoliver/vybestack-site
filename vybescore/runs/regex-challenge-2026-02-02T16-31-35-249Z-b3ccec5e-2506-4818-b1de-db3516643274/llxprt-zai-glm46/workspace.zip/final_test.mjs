import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== Additional Edge Case Tests ===\n');

// Email edge cases
console.log('Email edge cases:');
console.log('user+tag@example.com:', isValidEmail('user+tag@example.com'));
console.log('user.name@example.co.uk:', isValidEmail('user.name@example.co.uk'));
console.log('user@.com:', isValidEmail('user@.com'));
console.log('user@example..com:', isValidEmail('user@example..com'));
console.log('.user@example.com:', isValidEmail('.user@example.com'));

console.log('\nArgentine phone edge cases:');
console.log('+54 11 1234 5678:', isValidArgentinePhone('+54 11 1234 5678'));
console.log('11 1234 5678 (no prefix):', isValidArgentinePhone('11 1234 5678'));
console.log('+54 011 1234 5678 (both prefixes):', isValidArgentinePhone('+54 011 1234 5678'));

console.log('\nName edge cases:');
console.log(' anne:', isValidName(' anne'));
console.log('Anne:', isValidName('Anne'));
console.log('Anne-Marie:', isValidName('Anne-Marie'));
console.log("O'Connor:", isValidName("O'Connor"));
console.log('张三:', isValidName('张三'));

console.log('\nCapitalize sentences edge cases:');
console.log('"', capitalizeSentences('hello.how are you?'), '"');
console.log('"', capitalizeSentences('multiple   spaces   here'), '"');
console.log('"', capitalizeSentences('ALREADY UPPERCASE. and lowercase'), '"');

console.log('\nExtract URLs edge cases:');
console.log(extractUrls('Visit (https://example.com/path) today!'));
console.log(extractUrls('Go to example.com or http://test.com'));

console.log('\nRewrite docs URLs edge cases:');
console.log(rewriteDocsUrls('See http://example.com/docs/api.jsp'));
console.log(rewriteDocsUrls('See http://example.com/docs/api.php?id=1'));
console.log(rewriteDocsUrls('See http://example.com/path (not docs)'));

console.log('\nExtract year edge cases:');
console.log('00/15/2023:', extractYear('00/15/2023'));
console.log('02/29/2024:', extractYear('02/29/2024'));
console.log('not a date:', extractYear('not a date'));

console.log('\nStrong password edge cases:');
console.log('ValidPass123!:', isStrongPassword('ValidPass123!'));
console.log(' space Pass123!:', isStrongPassword(' space Pass123!'));
console.log('NoRepeat123!:', isStrongPassword('NoRepeat123!'));
console.log('ABABAB123!:', isStrongPassword('ABABAB123!'));

console.log('\nIPv6 edge cases:');
console.log('2001:0db8:85a3:0000:0000:8a2e:0370:7334:', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log(':::', containsIPv6('::'));
console.log('fe80::1::2:', containsIPv6('fe80::1::2'));
console.log('2001:db8::1%eth0:', containsIPv6('2001:db8::1%eth0'));
