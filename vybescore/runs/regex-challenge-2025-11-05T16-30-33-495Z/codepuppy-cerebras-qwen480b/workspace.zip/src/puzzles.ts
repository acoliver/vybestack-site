/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const filtered = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    const hasException = exceptions.some(exception => {
      const lowerException = exception.toLowerCase();
      return lowerWord === lowerException || lowerWord.startsWith(lowerException);
    });
    return !hasException;
  });
  
  // Return unique words
  return [...new Set(filtered)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Simple approach: manually find all occurrences
  const results: string[] = [];
  let currentIndex = 0;
  
  while (currentIndex < text.length) {
    const foundIndex = text.indexOf(token, currentIndex);
    if (foundIndex === -1) break;
    
    // Check if it's preceded by a digit and not at the start
    if (foundIndex > 0 && /\d/.test(text[foundIndex - 1])) {
      // Check if it's not part of a larger word (not followed by word character)
      const afterIndex = foundIndex + token.length;
      const isEndOfWord = afterIndex >= text.length || !/\w/.test(text[afterIndex]);
      
      if (isEndOfWord) {
        const match = text.substring(foundIndex - 1, afterIndex);
        results.push(match);
      }
    }
    
    currentIndex = foundIndex + 1;
  }
  
  return [...new Set(results)];
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace,
 * no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab, or 1212)
  // Look for any pattern of 2-4 characters that repeats immediately
  const repeatedPattern = /(.{1,4})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  // More sophisticated check for alternating patterns (like ababab)
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment1 = value.slice(i, i + len);
      const segment2 = value.slice(i + len, i + len * 2);
      if (segment1 === segment2) return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // First, remove potential IPv4 addresses to avoid false positives
  // IPv4 pattern: n.n.n.n where n is 0-255
  const withoutIPv4 = value.replace(/\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g, '');
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 1-4 hex digits
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: (compressed)
  // At most 7 groups total, with :: representing one or more groups of zeros
  const compressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with mixed notation (embedded IPv4)
  const mixedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){6}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 with :: and embedded IPv4
  const mixedCompressedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check any IPv6 pattern in the text without IPv4
  return (
    fullIPv6Regex.test(withoutIPv4) ||
    compressedIPv6Regex.test(withoutIPv4) ||
    mixedIPv6Regex.test(value) ||
    mixedCompressedIPv6Regex.test(value)
  );
}