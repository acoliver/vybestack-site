export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email regex that handles most cases
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for specific invalid patterns
  const hasDoubleDots = value.includes('..');
  const hasTrailingDot = value.endsWith('.');
  const hasUnderscoreInDomain = value.split('@')[1]?.includes('_') || false;
  const hasLeadingDot = value.startsWith('.');
  const hasConsecutiveDots = /\.\./.test(value);
  
  if (!emailRegex.test(value) || hasDoubleDots || hasTrailingDot || hasUnderscoreInDomain || hasLeadingDot || hasConsecutiveDots) {
    return false;
  }
  
  // Check for valid domain structure
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain || localPart.length > 64 || domain.length > 253) {
    return false;
  }
  
  // Domain should have at least one period and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2 || domainParts.some(part => part.length === 0)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common separators and optional +1.
 * Support formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallow impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check length - 10 digits for standard US number, 11 for +1 prefix
  if (digits.length !== 10 && digits.length !== 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digits.length === 11 && digits[0] !== '1') return false;
  
  // Extract the 10-digit number part
  const phoneDigits = digits.length === 11 ? digits.slice(1) : digits;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  const exchangeCode = phoneDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Validate the overall format
  const usPhoneRegex = /^(\+1[\s\-\.]?)?(\(?([2-9]\d{2})\)?[\s\-\.]?)?([2-9]\d{2})[\s\-\.]?(\d{4})(\s*x\d+)?$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile/landline formats.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Simplified validation for the common Argentine phone format
  // Either:
  // 1. +54[optional 9][area code][subscriber] 
  // 2. 0[area code][subscriber]
  // Area code: 2-4 digits (leading 1-9)
  // Subscriber: 6-8 digits
  const withCountryCode = /^\+54(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const withTrunkPrefix = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!withCountryCode.test(cleanValue) && !withTrunkPrefix.test(cleanValue)) {
    return false;
  }
  
  // Check if structured format with spaces/hyphens is valid
  // More flexible regex to handle various formatting patterns
  const structuredPatterns = [
    /^\+54[\s\-]?9?[\s\-]?[1-9]\d{1,3}[\s\-]?\d{3,4}[\s\-]?\d{3,4}$/, // +54 formats
    /^0[1-9]\d{1,3}[\s\-]?\d{3,4}[\s\-]?\d{2,4}$/, // 0 prefix formats
    /^\+54[\s\-]?[1-9]\d{1,3}[\s\-]?\d{3,4}[\s\-]?\d{3,4}$/, // +54 without 9
    /^\+54[\s\-]?9[\s\-]?[1-9]\d{1,3}[\s\-]?\d{4}[\s\-]?\d{4}$/ // +54 9 (mobile)
  ];
  
  return structuredPatterns.some(pattern => pattern.test(value));
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const trimmed = value.trim();
  if (!trimmed || trimmed.length > 100) return false;
  
  // Regex for valid names: unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Reject names with consecutive special characters
  const hasConsecutiveSpecial = /['\-]{2,}/.test(trimmed);
  if (hasConsecutiveSpecial) return false;
  
  // Reject names that start or end with special characters
  const startsOrEndsWithSpecial = /^[\-'\s]|[\-'\s]$/.test(trimmed);
  if (startsOrEndsWithSpecial) return false;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check length and prefix for different card types
  const visaRegex = /^4(\d{12}|\d{15})$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  const isValidFormat = visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}