/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 * Capitalize after .?!, insert exactly one space between sentences, collapse extra spaces.
 * Leave abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, collapse multiple spaces into single spaces, but preserve newlines
  let result = text.replace(/ {2,}/g, ' ');
  
  // Ensure proper spacing after sentence endings .!? 
  // Add space if missing after .!? (but not before)
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Remove spaces before sentence endings
  result = result.replace(/\s+([.!?])/g, '$1');
  
  // Split into sentences, capitalize each one
  const sentences = result.split(/([.!?]\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    if (sentences[i] && sentences[i].trim()) {
      const sentence = sentences[i];
      const trimmed = sentence.trim();
      
      // Find common abbreviations to avoid capitalizing after them
      const abbreviations = /^(mr|mrs|ms|dr|prof|sr|jr|st|ave|blvd|rd|etc|e\.g|i\.e|vs|\.)/i;
      // const prevSentence = i > 0 ? sentences[i - 2] : '';
      
      // Capitalize first letter unless it's an abbreviation
      if (!abbreviations.test(trimmed.toLowerCase())) {
        sentences[i] = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
      }
    }
  }
  
  // Rejoin and clean up extra spaces
  result = sentences.join('');
  
  // Final cleanup: remove multiple spaces around punctuation
  result = result.replace(/\s*([.!?])\s*/g, '$1 ');
  result = result.replace(/\s+$/g, '');
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Comprehensive URL regex
  const urlRegex = /(https?:\/\/)?(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/\/=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation: .,;:!?)]}
    return url.replace(/[.,;:!?\)\}\]]+$/g, '');
  });
  
  // Filter out empty strings and duplicates
  const uniqueUrls = [...new Set(cleanedUrls.filter(url => url.trim()))];
  
  return uniqueUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\/(?!\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skip host rewrite for URLs with cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/(https?:\/\/)([^\/]+)(\/[^ \)]*)/g, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    // Check for patterns that should skip host rewrite
    const skipHostRewrite = /(?:cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/.test(path);
    
    if (isDocsPath && !skipHostRewrite) {
      // Rewrite to docs.example.com
      const newHost = `docs.${host}`;
      return newScheme + newHost + path;
    } else {
      // Just upgrade scheme, keep original host
      return newScheme + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regex for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Basic validation for month/day combinations
  if (monthNum === 2) {
    // February - basic check (not accounting for leap years in detail)
    if (dayNum > 29) return 'N/A';
  } else if ([4, 6, 9, 11].includes(monthNum)) {
    // April, June, September, November have 30 days
    if (dayNum > 30) return 'N/A';
  } else {
    // All other months have 31 days
    if (dayNum > 31) return 'N/A';
  }
  
  // Reasonable year range (1900-2100)
  if (yearNum < 1900 || yearNum > 2100) return 'N/A';
  
  return year;
}