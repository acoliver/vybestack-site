import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Get __dirname equivalent for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define submission type
interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Initialize app
const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Database file path
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
let db: initSqlJs.Database;
let SQL: initSqlJs.SqlJsStatic;

initSqlJs().then(sql => {
  SQL = sql;
  
  // Load existing database or create a new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    db.run(`CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      street_address TEXT NOT NULL,
      city TEXT NOT NULL,
      state_province TEXT NOT NULL,
      postal_code TEXT NOT NULL,
      country TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );`);
  }
});

// Validate email with regex
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Validate phone number
function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone);
}

// Validate postal code
function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Render form
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

// Handle form submission
app.post('/submit', (req, res) => {
  const submission: Submission = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || '',
  };

  // Validate required fields
  const errors: string[] = [];
  if (!submission.firstName) errors.push('First name is required');
  if (!submission.lastName) errors.push('Last name is required');
  if (!submission.streetAddress) errors.push('Street address is required');
  if (!submission.city) errors.push('City is required');
  if (!submission.stateProvince) errors.push('State/Province is required');
  if (!submission.postalCode) errors.push('Postal code is required');
  if (!submission.country) errors.push('Country is required');
  if (!submission.email) errors.push('Email is required');
  if (!submission.phone) errors.push('Phone number is required');

  // Validate email format
  if (submission.email && !validateEmail(submission.email)) {
    errors.push('Please enter a valid email address');
  }

  // Validate phone format
  if (submission.phone && !validatePhone(submission.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Validate postal code format
  if (submission.postalCode && !validatePostalCode(submission.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  // If validation fails, re-render form with errors and values
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values: submission });
  }

  // Save to database
  try {
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        submission.firstName,
        submission.lastName,
        submission.streetAddress,
        submission.city,
        submission.stateProvince,
        submission.postalCode,
        submission.country,
        submission.email,
        submission.phone,
      ]
    );

    // Write the database back to file
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  } catch (err) {
    console.error('Database error:', err);
    return res.status(500).render('form', { 
      errors: ['Failed to save your submission'], 
      values: submission 
    });
  }

  // Redirect to thank-you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(submission.firstName));
});

// Render thank-you page
app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName?.toString() || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
let server: any;
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  server.close(() => {
    console.log('Express server closed');
    if (db) {
      db.close();
      console.log('Database closed');
    }
    process.exit(0);
  });
});

// Start server
server = app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});

export default app;