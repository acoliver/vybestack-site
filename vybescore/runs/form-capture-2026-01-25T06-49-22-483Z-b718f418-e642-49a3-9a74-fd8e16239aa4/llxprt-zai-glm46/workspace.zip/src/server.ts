import express, { type Request, type Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { type Database } from 'sql.js';

const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

/**
 * Validates form submission data.
 * Returns an array of validation errors (empty if valid).
 */
function validateSubmission(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field checks
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  }
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && data.email.trim() && !emailRegex.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Email must be a valid email address' });
  }

  // Phone validation: digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  if (data.phone && data.phone.trim() && !phoneRegex.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading +' });
  }

  // Postal code validation: alphanumeric (supports UK, Argentine, and international formats)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  if (data.postalCode && data.postalCode.trim() && !postalCodeRegex.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and dashes' });
  }

  return errors;
}

/**
 * Initialize SQLite database from file or create new one with schema.
 */
async function initializeDatabase(): Promise<Database> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load SQL.js WASM
  const SQL = await initSqlJs();

  let database: Database;
  if (fs.existsSync(DB_PATH)) {
    // Load existing database
    const dbBuffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(dbBuffer);
    console.log(`Loaded existing database from ${DB_PATH}`);
  } else {
    // Create new database and run schema
    database = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);
    saveDatabase(database);
    console.log(`Created new database at ${DB_PATH}`);
  }

  return database;
}

/**
 * Save database to disk.
 */
function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

/**
 * Validates form submission data.
 * Returns an array of validation errors (empty if valid).
 */
async function startServer(): Promise<void> {
  // Initialize database
  const database = await initializeDatabase();

  // Create Express app
  const app = express();

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.resolve('public')));

  // Set EJS as view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve('src', 'templates'));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validationErrors = validateSubmission(formData);

    if (validationErrors.length > 0) {
      // Validation failed - re-render form with errors
      const errorMessages = validationErrors.map((e) => e.message);
      res.status(400).render('form', {
        errors: errorMessages,
        values: formData
      });
      return;
    }

    // Validation passed - insert into database
    try {
      const stmt = database.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName!.trim(),
        formData.lastName!.trim(),
        formData.streetAddress!.trim(),
        formData.city!.trim(),
        formData.stateProvince!.trim(),
        formData.postalCode!.trim(),
        formData.country!.trim(),
        formData.email!.trim(),
        formData.phone!.trim()
      ]);

      stmt.free();

      // Save database to disk after insert
      saveDatabase(database);

      // Redirect to thank-you page with first name
      res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!.trim())}`);
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  });

  // Start listening
  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  // Handle graceful shutdown
  const shutdown = async (): Promise<void> => {
    console.log('Shutting down gracefully...');
    database.close();
    console.log('Database closed');
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
    // Force close after 5 seconds if hanging
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 5000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Start the server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for testing
export { startServer };
export const app = express();
