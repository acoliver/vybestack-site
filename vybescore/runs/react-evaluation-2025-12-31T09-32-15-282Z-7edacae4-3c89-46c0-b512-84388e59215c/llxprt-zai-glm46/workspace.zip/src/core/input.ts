/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register the active observer as depending on this input
      if (!s.observers) {
        s.observers = []
      }
      if (!s.observers.includes(observer as never)) {
        s.observers.push(observer as never)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // When value changes, update all observers that depend on this input
    if (s.observers && s.observers.length > 0) {
      for (const observer of s.observers) {
        updateObserver(observer)
      }
    }
    return s.value
  }

  return [read, write]
}
