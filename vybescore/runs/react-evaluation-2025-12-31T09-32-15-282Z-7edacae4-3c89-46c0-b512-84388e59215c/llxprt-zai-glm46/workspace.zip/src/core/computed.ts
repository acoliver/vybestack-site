/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: [], // Initialize empty array for dependent observers
  }
  
  // Initial computation
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    const active = getActiveObserver()
    if (active) {
      // Register the active observer as dependent on this computed value
      if (!o.observers) {
        o.observers = []
      }
      const obs = active as never
      if (!o.observers.includes(obs)) {
        o.observers.push(obs)
      }
    }
    return o.value!
  }
  
  return getter
}
