/**
 * Validate that a string is valid Base64.
 * Throws an error if the input contains characters outside the Base64 alphabet
 * or has invalid padding.
 */
function validateBase64(input: string): void {
  // Check for characters outside the Base64 alphabet
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // If padding exists, it must be valid
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end
    const nonPaddingAfter = input.slice(paddingIndex).replace(/=/g, '');
    if (nonPaddingAfter.length > 0) {
      throw new Error('Invalid Base64 input: padding must be at the end');
    }
    
    // Maximum 2 padding characters
    const paddingLength = input.length - paddingIndex;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // Total length with padding must be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: invalid structure');
    }
  }

  // Empty string is invalid
  if (input.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }
}

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate the input
  validateBase64(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
