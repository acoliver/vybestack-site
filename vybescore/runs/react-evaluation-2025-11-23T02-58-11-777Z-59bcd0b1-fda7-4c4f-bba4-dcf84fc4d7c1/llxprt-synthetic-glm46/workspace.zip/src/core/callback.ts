/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Store all callback observers globally
const allCallbacks = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set<Observer<unknown>>()
  }
  
  // Store the callback globally - use type assertion to bypass type checking
  allCallbacks.add(observer as Observer<unknown>)
  
  // Execute the callback function to track dependencies
  // The return value is not used, only side effects matter
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from global storage - use type assertion to bypass type checking
    allCallbacks.delete(observer as Observer<unknown>)
    
    // Clear dependencies to prevent memory leaks
    if (observer.dependencies) {
      observer.dependencies.clear()
    }
    
    // Set the update function to a no-op to prevent further callbacks
    observer.updateFn = () => value as T
  }
}

// Export function to trigger all callbacks
export function triggerAllCallbacks(): void {
  allCallbacks.forEach(callback => {
    updateObserver(callback)
  })
}