/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { triggerAllCallbacks } from './callback.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Define equality function
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (a, b) => a === b
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (a, b) => a === b : () => false
  } else {
    equalFn = equal
  }

  // Store multiple observers
  const observers = new Set<Observer<T>>()

  const s: Subject<T> = {
    name: options?.name,
    observer: {
      name: options?.name
    },
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add observer to the set of observers
      observers.add(observer as Observer<T>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (equalFn(nextValue, s.value)) {
      return s.value
    }
    
    // Always update the value
    s.value = nextValue
    // Notify all observers
    observers.forEach(observer => {
      updateObserver(observer)
    })
    
    // Also trigger all callbacks as a fallback
    triggerAllCallbacks()
    
    return s.value
  }

  return [read, write]
}
