import express from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Define types for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Define types for database submission
interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

// Create Express app
const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Initialize database
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
let db: initSqlJs.Database;

// Initialize SQL.js
const initDB = async () => {
  const SQL = await initSqlJs();
  let dbData: Uint8Array | null = null;
  
  // Load existing database if it exists
  if (fs.existsSync(dbPath)) {
    dbData = fs.readFileSync(dbPath);
  }
  
  // Create database instance
  db = new SQL.Database(dbData);
  
  // Create table if not exists
  const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
  db.run(schema);
};

// Initialize database on startup
initDB();

// Helper function to validate form data
const validateForm = (data: FormData): string[] => {
  const errors: string[] = [];
  
  // Check required fields
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State/Province is required');
  if (!data.postalCode?.trim()) errors.push('Postal code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');
  
  // Validate email format
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email)) {
    errors.push('Please provide a valid email address');
  }
  
  // Validate phone format
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.push('Please provide a valid phone number');
  }
  
  return errors;
};

// GET route for the form
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

// POST route for form submission
app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { 
      errors, 
      values: formData 
    });
  }
  
  // Insert submission into database
  const submission: Submission = {
    first_name: formData.firstName,
    last_name: formData.lastName,
    street_address: formData.streetAddress,
    city: formData.city,
    state_province: formData.stateProvince,
    postal_code: formData.postalCode,
    country: formData.country,
    email: formData.email,
    phone: formData.phone
  };
  
  const insertQuery = `
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  
  db.run(insertQuery, [
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone
  ]);
  
  // Write database back to file
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(formData.firstName));
});

// GET route for thank you page
app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown handling
let server: any;
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      // Close database
      if (db) {
        const data = db.export();
        const buffer = Buffer.from(data);
        fs.writeFileSync(dbPath, buffer);
        db.close();
      }
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
});

// Start server
server = app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});