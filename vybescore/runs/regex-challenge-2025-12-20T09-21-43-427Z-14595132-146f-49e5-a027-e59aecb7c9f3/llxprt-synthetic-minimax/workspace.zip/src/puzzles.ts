/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a regex pattern to find words starting with the prefix
  // Word boundaries ensure we match whole words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(word => {
    const wordLower = word.toLowerCase();
    return !exceptionsLower.includes(wordLower) && wordLower.startsWith(prefix.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Find all occurrences of the token and filter based on conditions
  const matches = [];
  let index = 0;
  
  while (index <= text.length - token.length) {
    const matchIndex = text.indexOf(token, index);
    if (matchIndex === -1) break;
    
    // Check if token is not at the start of the string
    if (matchIndex !== 0) {
      // Check if token is preceded by a digit
      const charBefore = text.charAt(matchIndex - 1);
      if (/\d/.test(charBefore)) {
        // Return the full context (digit + token)
        matches.push(charBefore + token);
      }
    }
    
    index = matchIndex + 1;
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., 'abab')
  // This pattern looks for any 2-character sequence that repeats immediately
  if (/([a-zA-Z0-9]{2,})\1/.test(value)) return false;
  
  // Check for sequences like 'abab', '1212', etc.
  // Look for patterns where two different characters or numbers repeat
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 patterns (including various formats)
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Pattern 1: :: (all zeros)
  const allZerosPattern = /\b::\b/;
  
  // Pattern 2: Starts with hex and contains :: 
  const standardShorthandPattern = /\b[a-fA-F0-9]*::(?:[a-fA-F0-9]*:)*[a-fA-F0-9]+\b/;
  
  // Pattern 3: :: in the middle with proper hex groups
  const middleShorthandPattern = /\b[a-fA-F0-9]+::[a-fA-F0-9]+\b/;
  
  // Check for various IPv6 patterns
  if (fullIPv6Pattern.test(value) ||
      standardShorthandPattern.test(value) ||
      middleShorthandPattern.test(value) ||
      allZerosPattern.test(value)) {
    return true;
  }
  
  // Additional check for IPv6 patterns that might be missed
  // Look for sequences of hex digits separated by colons with at least one ::
  const ipv6WithCompression = /([0-9a-fA-F]*::[0-9a-fA-F]*)/;
  if (ipv6WithCompression.test(value)) {
    const match = value.match(ipv6WithCompression);
    if (match && match[1]) {
      const compressed = match[1];
      // Ensure it's a valid IPv6 compression (not just looking like IPv4 with colons)
      const hexGroups = compressed.split(':').filter(group => group.length > 0);
      // Must have valid hex groups and the compression pattern
      if (hexGroups.length >= 2 && hexGroups.every(group => /^[0-9a-fA-F]*$/.test(group))) {
        return true;
      }
    }
  }
  
  return false;
}
