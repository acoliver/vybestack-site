export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern explanation:
  // - Local part: letters, numbers, dots, underscores, plus, hyphens, but no consecutive dots or trailing dot
  // - @ symbol
  // - Domain: letters, numbers, dots, hyphens, but no consecutive dots or trailing dot, and no underscores
  const emailPattern = /^[a-zA-Z0-9]+(?:[._+-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:[.-][a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
  
    // Basic validation passed, use regex pattern
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  if (!cleaned) return false;
  
  // Check if it starts with +1
  let digitsOnly = cleaned;
  if (digitsOnly.startsWith('+1')) {
    digitsOnly = digitsOnly.substring(2);
  } else if (digitsOnly.startsWith('+')) {
    return false; // Invalid international format
  }
  
  // Remove all non-digit characters
  digitsOnly = digitsOnly.replace(/\D/g, '');
  
  // Must have exactly 10 digits
  if (digitsOnly.length !== 10) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Pattern for various formats with optional parentheses and hyphens
  const phonePattern = /^\+?1?[-.\s]?\(?([2-9][0-9]{2})\)?[-.\s]?([2-9][0-9]{2})[-.\s]?([0-9]{4})$/;
  const matches = cleaned.match(phonePattern);
  
  if (!matches) return false;
  
  // Extract area code from matches and validate it doesn't start with 0 or 1
  const matchedAreaCode = matches[1];
  if (matchedAreaCode.startsWith('0') || matchedAreaCode.startsWith('1')) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except spaces and hyphens for analysis
  const cleaned = value.trim();
  if (!cleaned) return false;
  
  // Remove all spaces and hyphens for easier validation
  const compact = cleaned.replace(/[\s-]/g, '');
  
  // Pattern explanation:
  // Optional country code: (\+54)?
  // Optional mobile indicator: 9
  // Trunk prefix: 0
  // Area code: [1-9][0-9]{1,3} (2-4 digits, first digit 1-9)
  // Subscriber: [0-9]{6,8} (6-8 digits total after area code)
  
  // Match patterns like:
  // +549112345678 (mobile with country code)
  // 01112345678 (landline without country code)
  // +5491131234567 (mobile with country code)
  // 03414234567 (mobile without country code)
  
  const pattern = /^(\+54)?(9)?(0)?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  const match = compact.match(pattern);
  
  if (!match) return false;
  
  const [, countryCode, mobileIndicator, trunkPrefix] = match;
  
  // Validate rules:
  // 1. If no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) return false;
  
  // 2. If has country code, mobile indicator is optional for mobile, trunk prefix is not used
  // 3. If no country code and no mobile indicator, this should be a landline with trunk prefix
  // 4. Area code must be 2-4 digits (already enforced by regex)
  // 5. Subscriber must be 6-8 digits (already enforced by regex)
  
  // If has country code, can have mobile indicator or not
  // If no country code, must have trunk prefix
  
  // Check for invalid combinations
  if (countryCode && trunkPrefix) return false; // Don't use trunk prefix with country code
  
  // When no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) return false;
  
  // Mobile format validation: if has mobile indicator 9, it should be mobile
  if (mobileIndicator === '9' && countryCode && !trunkPrefix) {
    // This is mobile format with country code
    return true;
  }
  
  if (mobileIndicator === '9' && !countryCode && trunkPrefix) {
    // This is mobile format without country code
    return true;
  }
  
  if (!mobileIndicator && !countryCode && trunkPrefix) {
    // This is landline format without country code
    return true;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const trimmed = value.trim();
  if (trimmed.length === 0) return false;
  
  // Reject if contains digits
  if (/\d/.test(trimmed)) return false;
  
  // Reject symbols except apostrophes, hyphens, spaces
  if (/[^a-zA-ZÀ-ÿĀ-žÑñ' -]/.test(trimmed)) return false;
  
  // Reject obviously invalid patterns like "X Æ A-12"
  if (/[Ææ]/.test(trimmed)) return false; // Reject the Æ character
  if (/^[0-9]/.test(trimmed)) return false; // Cannot start with numbers
  
  // Must contain at least one letter (not just spaces/punctuation)
  if (!/[a-zA-ZÀ-ÿĀ-žÑñ]/.test(trimmed)) return false;
  
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Pattern explanation:
  // - Unicode letters (including accented characters)
  // - Spaces between words
  // - Apostrophes (O'Connor, D'Angelo)
  // - Hyphens (Jean-Pierre, Smith-Jones)
  const namePattern = /^[a-zA-ZÀ-ÿĀ-žÑñ]+(?:[ '-][a-zA-ZÀ-ÿĀ-žÑñ]+)*$/;
  
  return namePattern.test(trimmed);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Run Luhn checksum validation on a credit card number
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove all non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  if (digits.length === 0) return false;
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) return false;
  
  // Credit card length validation (13-19 digits)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check for valid card types and prefixes
  
  // Visa: starts with 4, 13 or 16 digits
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$/;
  if (visaPattern.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  const mastercardPattern1 = /^5[1-5][0-9]{14}$/; // 51-55
  const mastercardPattern2 = /^2[2-7][0-9]{13}$/; // 2221-2720
  if (mastercardPattern1.test(digits) || mastercardPattern2.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // American Express: starts with 34 or 37, 15 digits
  const amexPattern = /^3[47][0-9]{13}$/;
  if (amexPattern.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // Discover: starts with 6011, 65, 644-649, 16-19 digits
  const discoverPattern = /^(6011[0-9]{12}|65[0-9]{14}|64[4-9][0-9]{13})$/;
  if (discoverPattern.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // JCB: starts with 3528-3589, 16-19 digits
  const jcbPattern = /^35[2-8][0-9]{13,16}$/;
  if (jcbPattern.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // If no pattern matches but it's a valid number length, still run Luhn check
  // This allows for other card types while maintaining validation
  return runLuhnCheck(digits);
}
