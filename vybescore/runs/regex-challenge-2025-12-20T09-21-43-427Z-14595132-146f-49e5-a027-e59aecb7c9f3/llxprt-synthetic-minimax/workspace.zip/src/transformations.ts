/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // First, ensure there are spaces after sentence endings
  let processed = text.replace(/([.?!])([A-Za-z])/g, '$1 $2');
  
  // Capitalize first letter of each sentence
  // Pattern: start of string or space after sentence ending, followed by lowercase letter
  processed = processed.replace(/(^|[.?!]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Clean up extra spaces between sentences to exactly one space
  processed = processed.replace(/([.?!])\s+/g, '$1 ');
  
  return processed;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Match URLs starting with http:// or https://
  // Capture everything until we hit whitespace or certain punctuation (but allow dots)
  const urlPattern = /\bhttps?:\/\/[^\s"'<>()[\]{}[,!?;:]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Replace http:// with https:// (this will not affect existing https://)
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text || '';
  
  // Pattern to match http URLs that need transformation
  // This pattern captures the full URL structure
  const urlPattern = /http:\/\/([a-zA-Z0-9.-]+)([^<>\s]*)/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Always upgrade to https
    let newUrl = 'https://' + host;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check if path contains dynamic hints that should prevent host rewrite
      const hasDynamicHints = /(\?|=|&|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.<originalhost>
        newUrl = 'https://docs.' + host;
      }
    }
    
    newUrl += path;
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = new Date(parseInt(year), month, 0).getDate();
  if (day < 1 || day > daysInMonth) return 'N/A';
  
  return year;
}
