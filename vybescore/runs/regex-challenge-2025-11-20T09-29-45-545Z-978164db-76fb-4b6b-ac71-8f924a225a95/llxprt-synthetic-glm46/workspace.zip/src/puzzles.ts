/**
 * Finds words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a set for faster lookup of exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Escape any special regex characters in the prefix for safety
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex pattern to match words starting with the prefix (case-insensitive)
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[0];
    
    // Skip if the word is in the exceptions set (case-insensitive)
    if (exceptionSet.has(word.toLowerCase())) continue;
    
    matches.push(word);
  }
  
  return matches;
}

/**
 * Finds occurrences of a token that appears after a digit and not at the start of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token at the beginning of a word boundary
  // Return the full match (digit + token)
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenPattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates passwords with rules:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\\s/.test(value)) return false;
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) return false; // Uppercase
  if (!/[a-z]/.test(value)) return false; // Lowercase
  if (!/[0-9]/.test(value)) return false; // Digit
  if (!/[^A-Za-z0-9]/.test(value)) return false; // Symbol
  
  // Check for repeated sequences (2+ characters repeated)
  // Using positive lookahead to detect any sequence of 2+ chars repeated immediately
  if (/(..).*?\\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that supports shorthand (::)
  // [0-9a-fA-F]{1,4} - up to 4 hexadecimal digits for each segment
  // :: - shorthand for consecutive 0 segments
  const ipv6Pattern = new RegExp('(?:^|(?<=\\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9]))(?=\\s|$)');
  
  // Check if the value contains an IPv6 address
  return ipv6Pattern.test(value);
}