/**
 * Capitalizes the first character of each sentence with rules:
 * - Capitalize after .!?
 * - Insert exactly one space between sentences
 * - Collapse extra spaces
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing - replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure there's exactly one space after sentence-ending punctuation
  normalized = normalized.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Capitalize after sentence-ending punctuation or at the beginning
  return normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, char) => {
    return prefix + char.toUpperCase();
  });
}

/**
 * Finds URLs in the text and returns them without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Regex pattern to match URLs
  // Match http/https, www, or domain names
  // Capture the URL but exclude trailing punctuation
  const urlPattern = /(https?:\/\/|www\.)[^\s<>"']+?(?=[,.!?;:]?[\s<>"']|$)/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    // Extract the URL and remove trailing punctuation
    let url = match[0];
    
    // Remove trailing punctuation if present
    url = url.replace(/[,.!?;:]+$/, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://, but don't modify https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs with rules:
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for URLs with cgi-bin, query strings (?&=), or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with optional paths
  // Group 1: protocol (http://)
  // Group 2: domain (example.com)
  // Group 3: path (everything after domain)
  const urlPattern = /(http:\/\/)([a-zA-Z0-9.-]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, protocol, domain, path = '') => {
    // Always upgrade scheme to https
    const newProtocol = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /\/cgi-bin|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#/]|$))/i.test(path);
    
    // Rewrite host for docs paths, unless dynamic hints are present
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Change docs.example.com for documentation
      const newDomain = 'docs.' + domain;
      return newProtocol + newDomain + path;
    }
    
    // Just upgrade to https
    return newProtocol + domain + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Additional validation for day based on month
  const maxDayByMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day > maxDayByMonth[month]) return 'N/A';
  
  // Return the year
  return match[3];
}
