export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with rules:
 * - Accept typical addresses like name+tag@example.co.uk
 * - Reject double dots, trailing dots
 * - Reject domains with underscores
 * - Reject other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern that covers most valid cases while rejecting obvious invalid ones
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`|~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check basic format first
  if (!emailPattern.test(value)) return false;
  
  // Additional validation rules
  // No consecutive dots
  if (value.includes('..')) return false;
  
  // No dots at the beginning or end of local part
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain should not contain underscores
  if (domain.includes('_')) return false;
  
  // Domain cannot start or end with dot or hyphen
  if (domain.startsWith('.') || domain.startsWith('-')) return false;
  if (domain.endsWith('.') || domain.endsWith('-')) return false;
  
  // Domain segments should be valid
  const domainSegments = domain.split('.');
  if (domainSegments.length < 2) return false;
  
  for (const segment of domainSegments) {
    if (!/^[a-zA-Z0-9-]+$/.test(segment)) return false;
    if (segment.startsWith('-') || segment.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with rules:
 * - Support (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallow impossible area codes (leading 0/1)
 * - Disallow too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all whitespace and common separators
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Optional +1 country code
  const withCountryCode = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;
  
  // Must be exactly 10 digits for US numbers
  if (!/^\d{10}$/.test(withCountryCode)) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = withCountryCode.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Handle extensions if allowed
  if (options?.allowExtensions && cleaned.includes('ext')) {
    const [numberPart] = cleaned.split('ext');
    if (!/^\d{10}$/.test(numberPart.replace(/[\s\-()]/g, ''))) return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers with rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading 1-9)
 * - Subscriber number must contain 6-8 digits
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens first to normalize
  const normalized = value.replace(/[\s-]/g, '');
  
  // Pattern 1: +54 9 341 1234567 (international with country code and mobile indicator)
  const match1 = normalized.match(/^\+549(\d{2,4})(\d{6,8})$/);
  if (match1) {
    const areaCode = match1[1];
    const subscriber = match1[2];
    return areaCode.match(/^[1-9]\d{1,3}$/) !== null && subscriber.match(/^\d{6,8}$/) !== null;
  }
  
  // Pattern 2: +54 341 1234567 (international with country code but no mobile indicator)
  const match2 = normalized.match(/^\+54(\d{2,4})(\d{6,8})$/);
  if (match2) {
    const areaCode = match2[1];
    const subscriber = match2[2];
    return areaCode.match(/^[1-9]\d{1,3}$/) !== null && subscriber.match(/^\d{6,8}$/) !== null;
  }
  
  // Pattern 3: 09 341 1234567 (domestic with trunk and mobile indicator)
  const match3 = normalized.match(/^09(\d{2,4})(\d{6,8})$/);
  if (match3) {
    const areaCode = match3[1];
    const subscriber = match3[2];
    return areaCode.match(/^[1-9]\d{1,3}$/) !== null && subscriber.match(/^\d{6,8}$/) !== null;
  }
  
  // Pattern 4: 0341 1234567 (domestic with trunk prefix but no mobile indicator)
  const match4 = normalized.match(/^0(\d{2,4})(\d{6,8})$/);
  if (match4) {
    const areaCode = match4[1];
    const subscriber = match4[2];
    return areaCode.match(/^[1-9]\d{1,3}$/) !== null && subscriber.match(/^\d{6,8}$/) !== null;
  }
  
  return false;
}

/**
 * Validates personal names with rules:
 * - Permit unicode letters, accents, apostrophes, hyphens, spaces
 * - Reject digits, symbols, and "X Æ A-12" style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, and hyphens
  // \p{L} matches any unicode letter
  // \p{M} matches diacritical marks (accents)
  const namePattern = /^[\p{L}\p{M}'-]+(?:\s[\p{L}\p{M}'-]+)*$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Check for excessive consecutive diacritics or special characters
  if (/'{2,}/.test(value) || /-{2,}/.test(value)) return false;
  
  // Validate special cases
  if (value.trim().length < 1) return false;
  
  return true;
}

/**
 * Validates credit card numbers with rules:
 * - Accept Visa/Mastercard/AmEx prefixes and lengths
 * - Run a Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check basic length constraints based on card type
  if (cleaned.length < 13 || cleaned.length > 19) return false;
  
  // Validate prefixes
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34, 37
  const visaPattern = /^4\d{12,18}$/;
  const mastercardPattern1 = /^5[1-5]\d{14}$/;
  const mastercardPattern2 = /^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  if (!visaPattern.test(cleaned) && 
      !mastercardPattern1.test(cleaned) && 
      !mastercardPattern2.test(cleaned) && 
      !amexPattern.test(cleaned)) {
    return false;
  }
  
  // Luhn algorithm
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn checksum
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}