#!/usr/bin/env node

/**
 * Report Builder CLI
 * Renders reports from JSON input in various formats
 */

import * as fs from 'node:fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

type Formatter = (data: ReportData, options: { includeTotals: boolean }) => string;

const FORMATTERS: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(args: string[]): CliArgs {
  let dataFile = '';
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        fatalError('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        fatalError('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--')) {
      fatalError(`Unknown option: ${arg}`);
    } else if (!dataFile) {
      dataFile = arg;
    } else {
      fatalError(`Unexpected argument: ${arg}`);
    }
  }

  if (!dataFile) {
    fatalError('Missing required argument: <data.json>');
  }

  if (!format) {
    fatalError('Missing required option: --format <format>');
  }

  return { dataFile, format, outputPath, includeTotals };
}

function fatalError(message: string): never {
  console.error(`Error: ${message}`);
  process.exit(1);
}

function loadData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    if (!isValidReportData(data)) {
      fatalError('Invalid report data: missing required fields');
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      fatalError(`Invalid JSON in file: ${filePath}`);
    }
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      fatalError(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function isValidReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    return false;
  }

  if (typeof obj.summary !== 'string') {
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    return false;
  }

  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || typeof entryObj.amount !== 'number') {
      return false;
    }
  }

  return true;
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  const formatter = FORMATTERS[format];

  if (!formatter) {
    fatalError(`Unsupported format: ${format}`);
  }

  return formatter(data, { includeTotals });
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    fs.writeFileSync(outputPath, content, 'utf-8');
  } else {
    console.log(content);
  }
}

function main(): void {
  const args = process.argv.slice(2);
  const cliArgs = parseArgs(args);

  const data = loadData(cliArgs.dataFile);
  const output = renderReport(data, cliArgs.format, cliArgs.includeTotals);
  writeOutput(output, cliArgs.outputPath);
}

main();
