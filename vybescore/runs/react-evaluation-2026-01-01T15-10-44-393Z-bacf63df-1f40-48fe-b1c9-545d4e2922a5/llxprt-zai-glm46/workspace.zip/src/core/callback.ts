/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver, getActiveObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: new Set(),
  }
  
  let disposed = false
  
  // Capture subjects at creation time for cleanup
  const subjects: Set<Subject<unknown>> = new Set()
  
  // Set up tracking by accessing dependencies and run initial callback
  const previous = getActiveObserver()
  ;(globalThis as unknown as { __activeObserver: ObserverR | undefined }).__activeObserver = observer
  try {
    // Run the callback to execute initial side effect and track dependencies
    // Use updateObserver to properly set active observer during execution
    updateObserver(observer)
    // Capture any subjects that were tracked during the initial callback
    if (observer.subjects) {
      for (const subject of observer.subjects) {
        subjects.add(subject)
      }
    }
  } finally {
    (globalThis as unknown as { __activeObserver: ObserverR | undefined }).__activeObserver = previous
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    
    // Remove from all captured subjects' observer sets
    for (const subject of subjects) {
      subject.observers.delete(observer)
    }
    subjects.clear()
  }
}
