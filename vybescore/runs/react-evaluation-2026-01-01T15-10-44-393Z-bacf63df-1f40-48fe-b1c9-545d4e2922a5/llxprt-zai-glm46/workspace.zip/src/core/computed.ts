/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  Subject,
  updateObserver,
  setActiveObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create an internal observer that tracks inputs
  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Create a subject that will be observed by callbacks
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }

  // Flag to track if we're in an update cycle
  let updating = false

  // Track if computed has been initialized (value computed at least once)
  let initialized = value !== undefined

  // Track our own subjects (dependencies) for cleanup
  computedObserver.subjects = new Set<Subject<unknown>>()

  // When inputs notify this computed observer, update and propagate
  const originalUpdateFn = computedObserver.updateFn
  computedObserver.updateFn = (prev) => {
    if (updating) {
      // Already in an update cycle, return current value
      return computedObserver.value!
    }

    updating = true
    try {
      // Set this computed as active to track dependencies during update
      const previous = getActiveObserver()
      setActiveObserver(computedObserver)
      try {
        const newValue = originalUpdateFn(prev)
        computedObserver.value = newValue
        computedSubject.value = newValue  // Sync subject value
        initialized = true

        // Notify all observers of this computed subject (callbacks, other computeds)
        const observersToUpdate = Array.from(computedSubject.observers)
        for (const obs of observersToUpdate) {
          updateObserver(obs as Observer<unknown>)
        }

        return newValue
      } finally {
        setActiveObserver(previous)
      }
    } finally {
      updating = false
    }
  }

  // The getter function returned to users
  const getter = (): T => {
    const parentObserver = getActiveObserver()

    // If a parent observer is accessing us, register this computed subject as their dependency
    if (parentObserver) {
      computedSubject.observers.add(parentObserver)
      const obs = parentObserver as Observer<unknown>
      if (!obs.subjects) {
        obs.subjects = new Set()
      }
      obs.subjects.add(computedSubject as Subject<unknown>)
    }

    // Initialize on first read if not already initialized
    if (!initialized) {
      const previous = getActiveObserver()
      // Track dependencies but don't notify during initialization
      setActiveObserver(computedObserver)
      try {
        computedObserver.value = computedObserver.updateFn(computedObserver.value)
        initialized = true
        // Also update the subject value to match
        computedSubject.value = computedObserver.value
      } finally {
        setActiveObserver(previous)
      }
    }

    return computedObserver.value!
  }

  return getter
}
