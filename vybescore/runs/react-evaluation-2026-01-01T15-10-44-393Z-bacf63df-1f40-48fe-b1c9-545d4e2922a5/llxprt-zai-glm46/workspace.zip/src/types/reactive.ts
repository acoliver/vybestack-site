/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Set<Subject<unknown>>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Also store on globalThis for compatibility
declare global {
  // eslint-disable-next-line no-var
  var __activeObserver: ObserverR | undefined | typeof activeObserver
}

export function getActiveObserver(): ObserverR | undefined {
  return globalThis.__activeObserver ?? activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = getActiveObserver()
  globalThis.__activeObserver = observer
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
  } finally {
    globalThis.__activeObserver = previous
    activeObserver = previous
  }
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  globalThis.__activeObserver = observer
  activeObserver = observer
}

// Ensure globalThis.__activeObserver is initialized
if (typeof globalThis !== 'undefined' && globalThis.__activeObserver === undefined) {
  globalThis.__activeObserver = undefined
}
