// Debug script to understand reactive system behavior
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing reactive system...')

// Test case 1: compute cells fire callbacks
console.log('Test 1: compute cells fire callbacks')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0

console.log('Before callback - input:', input(), 'output:', output(), 'value:', value)

const unsubscribe = createCallback(() => {
  console.log('Callback firing - input:', input(), 'output:', output(), 'setting value to output')
  value = output()
})

console.log('After callback setup - input:', input(), 'output:', output(), 'value:', value)

setInput(3)
console.log('After setInput(3) - input:', input(), 'output:', output(), 'value:', value)

unsubscribe()

// Test case 2: callbacks can be added and removed
console.log('\nTest 2: callbacks can be added and removed')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 firing - output2:', output2())
  values1.push(output2())
})

const values2 = []
const unsubscribe2 = createCallback(() => {
  console.log('Callback 2 firing - output2:', output2())
  values2.push(output2())
})

setInput2(31)
console.log('After setInput2(31) - values1:', values1, 'values2:', values2)

unsubscribe1()
console.log('Unsubscribed callback 1')

setInput2(41)
console.log('After setInput2(41) - values1:', values1, 'values2:', values2)

console.log('Done.')