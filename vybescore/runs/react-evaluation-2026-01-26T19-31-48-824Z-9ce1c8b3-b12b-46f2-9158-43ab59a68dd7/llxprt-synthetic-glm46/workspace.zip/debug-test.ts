// Debug script to understand reactive system behavior
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Debug Reactive System ===')

const [input, setInput] = createInput(1, true, { name: 'input' })
const output = createComputed(() => input() + 1, undefined, undefined, { name: 'output' })

console.log('Initial values:')
console.log('input():', input())
console.log('output():', output())

let value = 0
const unsubscribe = createCallback(() => {
  console.log('Callback called!')
  console.log('Setting value to output() which is:', output())
  value = output()
}, undefined)

console.log('After callback setup:')
console.log('value:', value)

setInput(3)
console.log('After setInput(3):')
console.log('input():', input())
console.log('output():', output())
console.log('value:', value)
console.log('Expected value: 4')

unsubscribe()
console.log('After unsubscribe')