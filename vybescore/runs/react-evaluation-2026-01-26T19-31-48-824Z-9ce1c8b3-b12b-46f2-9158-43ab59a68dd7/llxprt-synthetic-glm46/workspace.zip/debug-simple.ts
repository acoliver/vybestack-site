// Simplified debug to understand dependencies
import { subjectToObservers, observerToSubjects } from './src/types/reactive.js'

console.log('=== Examining dependency system ===')
console.log('subjectToObservers size:', subjectToObservers.size)
console.log('observerToSubjects size:', observerToSubjects.size)