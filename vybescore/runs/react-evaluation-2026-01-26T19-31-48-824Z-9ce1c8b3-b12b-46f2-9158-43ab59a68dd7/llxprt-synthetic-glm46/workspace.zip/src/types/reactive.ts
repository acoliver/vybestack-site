/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependentSubjects?: Set<Subject<T>>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Global map to track which observers depend on which subjects
const subjectToObservers = new Map<Subject<unknown>, Set<Observer<unknown>>>()

// Global map to track which subjects an observer depends on
const observerToSubjects = new Map<Observer<unknown>, Set<Subject<unknown>>>()

// Track a subject dependency for an observer
export function trackDependency(observer: Observer<unknown>, subject: Subject<unknown>): void {
  if (!observerToSubjects.has(observer)) {
    observerToSubjects.set(observer, new Set())
  }
  observerToSubjects.get(observer)!.add(subject)
  
  if (!subjectToObservers.has(subject)) {
    subjectToObservers.set(subject, new Set())
  }
  subjectToObservers.get(subject)!.add(observer)
}

// Get all subjects an observer depends on
export function getDependentSubjects(observer: Observer<unknown>): Set<Subject<unknown>> {
  return observerToSubjects.get(observer) || new Set()
}

// Update all observers that depend on a given subject
export function notifyDependentObservers(subject: Subject<unknown>): void {
  // First, update all direct dependent observers
  const directDependents = getDependentObservers(subject)
  directDependents.forEach(observer => {
    // Use updateObserver to trigger the callback or computed function
    updateObserver(observer)
  })
  
  // For subjects with an observer property (computed values), cascade updates
  if (subject.observer) {
    // Find all subjects that represent this computed value
    // and notify their dependents too
    const allComputedPseudoSubjects: Subject<unknown>[] = []
    
    // Find pseudo-subjects for this computed observer
    subjectToObservers.forEach((observers, subj) => {
      if (subj.observer === subject.observer) {
        allComputedPseudoSubjects.push(subj)
      }
    })
    
    // Notify all observers that depend on these computed pseudo-subjects
    allComputedPseudoSubjects.forEach(pseudoSubject => {
      const pseudoDependents = getDependentObservers(pseudoSubject)
      pseudoDependents.forEach(callbackObserver => {
        if (!directDependents.has(callbackObserver)) {
          updateObserver(callbackObserver)
        }
      })
    })
  }
}

// Get all observers that depend on a subject
export function getDependentObservers(subject: Subject<unknown>): Set<Observer<unknown>> {
  const result = new Set<Observer<unknown>>()
  
  // Get direct observers
  const directObservers = subjectToObservers.get(subject)
  if (directObservers) {
    directObservers.forEach(observer => result.add(observer))
  }
  
  return result
}

// Clean up observer from tracking maps
export function cleanupObserver(observer: Observer<unknown>): void {
  const subjects = observerToSubjects.get(observer)
  if (subjects) {
    subjects.forEach(subject => {
      const observers = subjectToObservers.get(subject)
      if (observers) {
        observers.delete(observer)
        if (observers.size === 0) {
          subjectToObservers.delete(subject)
        }
      }
    })
    observerToSubjects.delete(observer)
  }
}

// Remove observer from all tracking maps (for unsubscribe)
export function removeObserverFromAllTracking(observer: Observer<unknown>): void {
  cleanupObserver(observer)
}




