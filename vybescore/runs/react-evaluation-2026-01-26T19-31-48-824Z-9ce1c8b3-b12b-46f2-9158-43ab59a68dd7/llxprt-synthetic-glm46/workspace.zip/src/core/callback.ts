/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, cleanupObserver, getDependentSubjects } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create the callback observer
  const callbackObserver: Observer<T> = {
    value: undefined,
    updateFn,
  }
  
  // Execute the callback to establish dependencies
  updateObserver(callbackObserver)
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove the observer from all tracking maps
    cleanupObserver(callbackObserver as Observer<unknown>)
    
    // Clear the callback observer
    callbackObserver.value = undefined
    callbackObserver.updateFn = () => value!
  }
  
  return unsubscribe
}
