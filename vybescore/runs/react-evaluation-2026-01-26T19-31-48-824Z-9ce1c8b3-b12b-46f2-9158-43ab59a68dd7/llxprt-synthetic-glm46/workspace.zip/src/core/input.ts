/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  trackDependency,
  notifyDependentObservers,
  getDependentObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equality function
  const equalFn: EqualFn<T> | undefined = 
    equal === false ? undefined : 
    equal === true ? ((a: T, b: T) => a === b) as EqualFn<T> :
    equal as EqualFn<T>

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Establish dependency tracking using the global tracking system
      trackDependency(observer as Observer<unknown>, s as Subject<unknown>)
      
      
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value changed using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Update direct observer if any
    if (s.observer) {
      updateObserver(s.observer as Observer<T>)
    }
    
    // Notify all observers that depend on this subject
    notifyDependentObservers(s as Subject<unknown>)
    
    return nextValue
  }

  return [read, write]
}
