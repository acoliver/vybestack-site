/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  getActiveObserver,
  trackDependency,
  notifyDependentObservers,
  EqualFn,
  subjectToObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a pseudo-subject that represents this computed value so callbacks can track dependencies on it
  const computedPseudoSubject: Subject<unknown> = { observer: o, value: o.value }
  
  // Register this computed value in the global tracking system
  if (!subjectToObservers.has(computedPseudoSubject)) {
    subjectToObservers.set(computedPseudoSubject, new Set())
  }
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed value is being accessed during another observer's execution
      // Track the dependency on this computed value using the pseudo-subject
      trackDependency(observer as Observer<unknown>, computedPseudoSubject)
      
      // Update the computed value if needed
      updateObserver(o)
      // Update the pseudo-subject's value for consistency and notify dependents
      computedPseudoSubject.value = o.value
      notifyDependentObservers(computedPseudoSubject)
      return o.value!
    } else {
      // Re-compute when called directly (no active observer)
      updateObserver(o)
      // Update the pseudo-subject's value for consistency
      computedPseudoSubject.value = o.value
      return o.value!
    }
  }
}
