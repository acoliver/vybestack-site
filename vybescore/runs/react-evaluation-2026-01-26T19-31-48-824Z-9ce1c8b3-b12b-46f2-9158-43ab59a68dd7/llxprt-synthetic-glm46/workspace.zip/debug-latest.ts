// Simplified debug to test fix
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Simple Reactive Debug ===')

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log('input():', input())
console.log('output():', output())

let value = 0
const unsubscribe = createCallback(() => {
  console.log('Callback called, output():', output())
  value = output()
})

console.log('After setup - value:', value)

setInput(3)
console.log('After setInput(3):')
console.log('input():', input())
console.log('output():', output())
console.log('value:', value)
console.log('Expected: 4')