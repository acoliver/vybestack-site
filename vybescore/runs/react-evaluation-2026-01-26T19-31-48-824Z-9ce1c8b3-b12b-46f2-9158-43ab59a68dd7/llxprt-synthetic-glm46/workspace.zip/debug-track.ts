// Debug to see what's happening with tracking
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Tracking Debug ===')

const [input, setInput] = createInput(1, true, { name: 'input' })

// Create computed that logs when called
const output = createComputed(() => {
  console.log('  Computed function called: input() =', input())
  return input() + 1
}, undefined, undefined, { name: 'output' })

console.log('Initial values:')
console.log('input():', input())
console.log('output():', output())

let value = 0
console.log('Creating callback...')
const unsubscribe = createCallback(() => {
  console.log('  Callback running, calling output()...')
  const result = output()
  console.log('  output() returned:', result)
  value = result
  console.log('  value updated to:', value)
})

console.log('After callback setup:')
console.log('value:', value)

console.log('\nSetting input to 3...')
setInput(3)
console.log('After setInput(3):')
console.log('input():', input())
console.log('output():', output())
console.log('final value:', value)
console.log('Expected value: 4')

unsubscribe()