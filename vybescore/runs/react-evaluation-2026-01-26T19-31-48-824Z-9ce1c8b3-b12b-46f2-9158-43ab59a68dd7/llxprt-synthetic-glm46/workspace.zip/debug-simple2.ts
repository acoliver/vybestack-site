// Debug script with detailed logging
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Detailed Reactive Debug ===')

const [input, setInput] = createInput(1, true, { name: 'input' })
const output = createComputed(() => {
  console.log('  Computed function called - input() =', input())
  return input() + 1
}, undefined, undefined, { name: 'output' })

console.log('Initial setup:')
console.log('input():', input())
console.log('output():', output())

let value = 0
const unsubscribe = createCallback(() => {
  console.log('  Callback function called, calling output()')
  const currentValue = output()
  console.log('  output() returned:', currentValue)
  console.log('  Setting value to', currentValue)
  value = currentValue
})

console.log('After callback setup:')
console.log('value:', value)

console.log('\nChanging input to 3:')
setInput(3)
console.log('After change:')
console.log('input():', input())
console.log('output():', output())
console.log('final value:', value)
console.log('Expected value: 4')

unsubscribe()
console.log('\nAfter unsubscribe')

console.log('\n=== Testing add/remove behavior ===')
let values1: number[] = []
let values2: number[] = []

const [input2, setInput2] = createInput(11, true, { name: 'input2' })
const output2 = createComputed(() => {
  console.log('  Computed2 function called - input2() =', input2())
  return input2() + 1
}, undefined, undefined, { name: 'output2' })

const unsubscribe1 = createCallback(() => {
  console.log('  Callback1 called')
  values1.push(output2())
})
const unsubscribe2 = createCallback(() => {
  console.log('  Callback2 called')
  values2.push(output2())
})

console.log('Before change - values1:', values1, 'values2:', values2)
setInput2(31)
console.log('After first change - values1:', values1, 'values2:', values2)

unsubscribe1()
setInput2(41)
console.log('After second change and unsubscribe1 - values1:', values1, 'values2:', values2)