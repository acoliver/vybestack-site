// Final debug to test the fix
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Final Debug Test ===')

// Test 1: Basic reactive callback
console.log('Test 1: Basic reactive callback')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

let value = 0
const unsubscribe = createCallback(() => {
  value = output()
  console.log('  Callback executed, value updated to:', value)
})

console.log('Initial - value:', value)
setInput(3)
console.log('After setInput(3) - value:', value, 'expected: 4')
console.log('Test 1:', value === 4 ? 'PASS' : 'FAIL')

unsubscribe()
console.log('')

// Test 2: Callback unsubscribe behavior
console.log('Test 2: Callback unsubscribe behavior')
let values1: number[] = []
let values2: number[] = []

const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

const unsubscribe1 = createCallback(() => values1.push(output2()))
const unsubscribe2 = createCallback(() => values2.push(output2()))

console.log('Before change - values1:', values1.length, 'values2:', values2.length)
setInput2(31)
console.log('After first change - values1:', values1.length, 'values2:', values2.length)

unsubscribe1()
setInput2(41)
console.log('After second change and unsubscribe1 - values1:', values1.length, 'values2:', values2.length)
console.log('Test 2:', values2.length > values1.length ? 'PASS' : 'FAIL')