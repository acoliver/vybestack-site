/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // This observer represents the computed value itself
  const observer: Observer<T> = {
    name: options?.name,
    disposed: false,
    value,
    updateFn,
    subjects: new Set<Subject<unknown>>(),
  }
  
  // Create a subject that will hold observers who depend on this computed
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value: value as T,
  }
  
  // The getter function - when called, it registers dependency
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Some observer is currently computing and accessing this computed value
      // Register that observer as depending on this computed's subject
      subject.observers.add(activeObserver)
    }
    return observer.value!
  }
  
  // Wrap the observer's update function to notify the computed's observers
  const originalUpdateFn = updateFn
  observer.updateFn = (prevValue?: T) => {
    // When this computed updates, first recalculate its value
    const newValue = originalUpdateFn(prevValue)
    observer.value = newValue
    subject.value = newValue
    
    // Then notify all observers who depend on this computed
    const observers = [...subject.observers]
    for (const obs of observers) {
      if (!obs.disposed) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        updateObserver(obs as any)
      }
    }
    
    return newValue
  }
  
  // Initial computation to establish dependencies
  updateObserver(observer)
  
  return getter
}
