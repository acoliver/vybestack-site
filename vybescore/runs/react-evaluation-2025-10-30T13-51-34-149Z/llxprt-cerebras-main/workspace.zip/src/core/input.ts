/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process equal parameter - if boolean false, use !== comparison
  const equalFn: EqualFn<T> = typeof equal === 'function' ? equal : 
    equal === false ? (lhs, rhs) => lhs !== rhs : (lhs, rhs) => lhs === rhs;

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  };

  const observers = new Set<Observer<T>>();

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver();
    if (observer) observers.add(observer as Observer<T>);
    return s.value;
  };

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed
    if (!s.equalFn!(s.value, nextValue)) {
      s.value = nextValue;
      // Notify all observers
      observers.forEach(observer => updateObserver(observer));
    }
    return s.value;
  };

  return [read, write];
}