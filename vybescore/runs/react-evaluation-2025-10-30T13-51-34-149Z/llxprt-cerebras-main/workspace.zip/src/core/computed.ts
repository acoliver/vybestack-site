/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process equal parameter - if boolean false, use !== comparison
  const equalFn: EqualFn<T> = typeof equal === 'function' ? equal : 
    equal === false ? (lhs, rhs) => lhs !== rhs : (lhs, rhs) => lhs === rhs;

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  };

  const observers = new Set<Observer<T>>();
  
  const o: Observer<T> = {
    name: options?.name,
    value: s.value,
    updateFn: (prevValue?: T) => {
      const newValue = updateFn(prevValue);
      // Only update if value has changed
      if (!s.equalFn!(s.value, newValue)) {
        s.value = newValue;
        // Notify all observers
        observers.forEach(observer => updateObserver(observer));
      }
      return s.value;
    }
  };
  
  // Compute initial value
  updateObserver(o);
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver();
    if (observer) observers.add(observer as Observer<T>);
    return s.value;
  };

  return read;
}