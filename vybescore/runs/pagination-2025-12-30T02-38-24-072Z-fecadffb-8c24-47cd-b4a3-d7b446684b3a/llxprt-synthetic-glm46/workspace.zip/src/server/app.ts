import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePageLimitParam(value: string | undefined, defaultValue: number, paramName: string): number {
  if (!value) return defaultValue;
  
  const num = Number(value);
  
  if (isNaN(num) || !Number.isInteger(num)) {
    throw new Error(`Invalid ${paramName}: must be an integer`);
  }
  
  if (num <= 0) {
    throw new Error(`Invalid ${paramName}: must be greater than 0`);
  }
  
  return num;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const page = validatePageLimitParam(pageParam, 1, 'page');
      const limit = validatePageLimitParam(limitParam, 5, 'limit');

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid request';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
