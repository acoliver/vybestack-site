import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination tests', () => {
  it('returns correct first page by default', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.total).toBe(15);
  });

  it('returns correct second page', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.total).toBe(15);
    // Verify it's different items than page 1
    expect(response.body.items[0].id).toBe(6);
  });

  it('returns correct third page (last page)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.hasNext).toBe(false);
    expect(response.body.total).toBe(15);
    // Verify it's different items than page 2
    expect(response.body.items[0].id).toBe(11);
  });

  it('returns error for invalid page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=invalid&limit=5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('returns error for negative page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1&limit=5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('returns error for zero page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0&limit=5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('returns error for negative limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=-1');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('returns error for zero limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=0');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('returns error for excessive limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=1000');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('handles small limit correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=2');
    
    expect(response.status).toBe(200);
    expect(response.body.items).toHaveLength(2);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(2);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.total).toBe(15);
    // Verify first two items
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[1].id).toBe(2);
  });
});