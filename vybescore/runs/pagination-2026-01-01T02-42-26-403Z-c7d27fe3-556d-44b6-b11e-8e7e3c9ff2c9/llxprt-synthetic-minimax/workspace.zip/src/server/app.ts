import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } {
  // Validate page parameter
  if (pageParam !== undefined) {
    const pageNum = Number(pageParam);
    if (!Number.isFinite(pageNum) || pageNum < 1) {
      throw new Error('Invalid page parameter: must be a positive number');
    }
  }

  // Validate limit parameter
  if (limitParam !== undefined) {
    const limitNum = Number(limitParam);
    if (!Number.isFinite(limitNum) || limitNum < 1 || limitNum > MAX_LIMIT) {
      throw new Error(`Invalid limit parameter: must be between 1 and ${MAX_LIMIT}`);
    }
  }

  const page = pageParam ? Number(pageParam) : DEFAULT_PAGE;
  const limit = limitParam ? Number(limitParam) : DEFAULT_LIMIT;

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const { page, limit } = validatePaginationParams(pageParam, limitParam);
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid parameters';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
