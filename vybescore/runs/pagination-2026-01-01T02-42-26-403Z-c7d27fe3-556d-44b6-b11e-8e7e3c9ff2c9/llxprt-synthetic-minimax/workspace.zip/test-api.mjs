import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';

const PORT = 3334;

async function testAPI() {
  try {
    console.log('Starting test server...');
    const db = await createDatabase();
    const app = await createApp(db);
    
    const server = app.listen(PORT, () => {
      console.log(`Test server running on http://localhost:${PORT}`);
    });

    // Wait for server to start
    await new Promise(resolve => setTimeout(resolve, 1000));

    console.log('\n=== Testing Default Pagination (page=1, limit=5) ===');
    const response1 = await fetch(`http://localhost:${PORT}/inventory`);
    const data1 = await response1.json();
    console.log('Status:', response1.status);
    console.log('Response:', JSON.stringify(data1, null, 2));

    console.log('\n=== Testing Page 2 (page=2, limit=5) ===');
    const response2 = await fetch(`http://localhost:${PORT}/inventory?page=2&limit=5`);
    const data2 = await response2.json();
    console.log('Status:', response2.status);
    console.log('Response:', JSON.stringify(data2, null, 2));

    console.log('\n=== Testing Small Limit (page=1, limit=2) ===');
    const response3 = await fetch(`http://localhost:${PORT}/inventory?page=1&limit=2`);
    const data3 = await response3.json();
    console.log('Status:', response3.status);
    console.log('Response:', JSON.stringify(data3, null, 2));

    console.log('\n=== Testing Invalid Page (page=invalid) ===');
    const response4 = await fetch(`http://localhost:${PORT}/inventory?page=invalid&limit=5`);
    console.log('Status:', response4.status);
    const errorData = await response4.json();
    console.log('Error Response:', JSON.stringify(errorData, null, 2));

    console.log('\n=== Testing Negative Limit (page=1&limit=-1) ===');
    const response5 = await fetch(`http://localhost:${PORT}/inventory?page=1&limit=-1`);
    console.log('Status:', response5.status);
    const errorData5 = await response5.json();
    console.log('Error Response:', JSON.stringify(errorData5, null, 2));

    console.log('\n=== Testing Zero Limit (page=1&limit=0) ===');
    const response6 = await fetch(`http://localhost:${PORT}/inventory?page=1&limit=0`);
    console.log('Status:', response6.status);
    const errorData6 = await response6.json();
    console.log('Error Response:', JSON.stringify(errorData6, null, 2));

    console.log('\n=== Testing Excessive Limit (page=1&limit=1000) ===');
    const response7 = await fetch(`http://localhost:${PORT}/inventory?page=1&limit=1000`);
    console.log('Status:', response7.status);
    const errorData7 = await response7.json();
    console.log('Error Response:', JSON.stringify(errorData7, null, 2));

    server.close();
    console.log('\nTest server closed.');
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testAPI();