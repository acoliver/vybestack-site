/**
 * Encode plain text to Base64 using canonical Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string.
 * @param input - The Base64 string to validate
 * @throws Error if the input contains invalid Base64 characters
 */
function validateBase64Input(input: string): void {
  // Base64 can contain A-Z, a-z, 0-9, +, /, and = (for padding)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check for valid padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Check if padding is only at the end
    if (!input.slice(paddingIndex).split('').every(char => char === '=')) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
    
    // Check if padding length is valid (1 or 2 characters)
    const paddingLength = input.length - paddingIndex;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // Check for valid string length with padding
    const unpaddedLength = paddingIndex;
    if ((unpaddedLength % 4) === 1) {
      throw new Error('Invalid Base64 input: string cannot have a single leftover character');
    }
  } else if (input.length % 4 === 1) {
    // Without padding, strings with length % 4 === 1 are invalid (cannot be valid Base64)
    throw new Error('Invalid Base64 input: string cannot have a single leftover character');
  }
  // Strings with length % 4 === 2 or 3 are valid unpadded Base64
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  // Validate input before processing
  validateBase64Input(input);
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
