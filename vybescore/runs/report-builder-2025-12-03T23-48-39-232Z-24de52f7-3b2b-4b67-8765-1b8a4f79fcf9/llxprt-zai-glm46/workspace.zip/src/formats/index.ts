import type { Format, Renderer } from '../types.js';
import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';

export const formatters: Record<Format, Renderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};

export { markdownRenderer } from './markdown.js';
export { textRenderer } from './text.js';