#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, Format, RenderOptions } from '../types.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: Partial<CliArgs> = {};
  
  // Default values
  result.includeTotals = false;

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    if (arg === '--format' && nextArg) {
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        throw new Error(`Unsupported format: ${nextArg}`);
      }
      result.format = nextArg as Format;
      i++; // Skip next argument
    } else if (arg === '--output' && nextArg) {
      result.output = nextArg;
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!result.dataFile && !arg.startsWith('--')) {
      result.dataFile = arg;
    }
  }

  if (!result.dataFile) {
    throw new Error('Data file path is required');
  }

  if (!result.format) {
    throw new Error('Format is required (use --format <markdown|text>)');
  }

  return result as CliArgs;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    // Validate the structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }

    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Missing or invalid "title" field (expected string)');
    }

    if (typeof reportData.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field (expected string)');
    }

    if (!Array.isArray(reportData.entries)) {
      throw new Error('Missing or invalid "entries" field (expected array)');
    }

    for (const entry of reportData.entries) {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error('Invalid entry: expected object');
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label" field (expected string)');
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid "amount" field (expected number)');
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function main() {
  try {
    const args = parseArgs(process.argv);
    const data = loadReportData(args.dataFile);
    
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const formatter = formatters[args.format];
    const output = formatter.render(data, options);

    if (args.output) {
      writeFileSync(args.output, output, 'utf-8');
      console.error(`Report written to ${args.output}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}