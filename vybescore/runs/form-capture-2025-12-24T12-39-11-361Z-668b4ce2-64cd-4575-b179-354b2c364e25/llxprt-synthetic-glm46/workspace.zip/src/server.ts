import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { readdirSync } from 'fs';

// Get __dirname equivalent for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface SubmissionData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
const PORT = process.env.PORT ?? 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(path.dirname(__dirname), 'src', 'templates'));

// Database initialization
import { Database } from 'sql.js';
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

async function initializeDatabase() {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }

    // Load sql.js
    const SQL = await initSqlJs();
    
    // Load or create database
    let dbBuffer: Uint8Array;
    if (existsSync(dbPath)) {
      const fileContent = readFileSync(dbPath);
      dbBuffer = new Uint8Array(fileContent);
    } else {
      dbBuffer = new Uint8Array([]);
    }
    
    db = new SQL.Database(dbBuffer);
    
    // Create table if not exists
    const schema = readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase() {
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    const data = db.export();
    writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?\d[\d\-\s()]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]{1,10}$/;
  return postalCodeRegex.test(postalCode);
}

function validateSubmission(data: SubmissionData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');

  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number');
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal/zip code');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const submissionData: SubmissionData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateSubmission(submissionData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', { 
      errors: validation.errors, 
      values: submissionData 
    });
  }

  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      submissionData.firstName,
      submissionData.lastName,
      submissionData.streetAddress,
      submissionData.city,
      submissionData.stateProvince,
      submissionData.postalCode,
      submissionData.country,
      submissionData.email,
      submissionData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: submissionData
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'friend' });
});

// Helper to copy directory
function copyDir(src: string, dest: string) {
  if (!existsSync(dest)) {
    mkdirSync(dest, { recursive: true });
  }
  
  const entries = readdirSync(src, { withFileTypes: true });
  
  for (const entry of entries) {
    const srcPath = path.join(src, entry.name);
    const destPath = path.join(dest, entry.name);
    
    if (entry.isDirectory()) {
      copyDir(srcPath, destPath);
    } else {
      const content = readFileSync(srcPath);
      writeFileSync(destPath, content);
    }
  }
}

// Graceful shutdown
function shutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database closed');
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer() {
  await initializeDatabase();
  
  // Copy templates directory to dist
  copyDir(path.join(__dirname, 'templates'), path.join(path.dirname(__dirname), 'dist', 'templates'));
  // Copy public directory to dist
  copyDir(path.join(path.dirname(__dirname), 'public'), path.join(path.dirname(__dirname), 'dist', 'public'));
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
