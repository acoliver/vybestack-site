import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.price_cents),
    createdAt: String(row.created_at)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  // Fixed: correct offset calculation
  const offset = (page - 1) * limit;

const stmt = db.prepare(`
    SELECT id, name, sku, price_cents, created_at FROM inventory
    ORDER BY id
    LIMIT ? OFFSET ?
  `);
  stmt.bind([limit, offset]);

  const items: InventoryItem[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject();
    items.push(mapRow(row));
  }
  stmt.free();

  return {
    items,
    page,
    limit,
    total,
    hasNext: page * limit < total
  };
}

export function validatePaginationParams(page?: string, limit?: string): { page: number; limit: number } | { error: string } {
  // Validate page parameter
  if (page !== undefined) {
    const pageNum = Number(page);
    if (!Number.isFinite(pageNum) || !Number.isInteger(pageNum)) {
      return { error: 'Page must be a valid integer' };
    }
    if (pageNum <= 0) {
      return { error: 'Page must be greater than 0' };
    }
    if (pageNum > 1000000) { // Reasonable upper limit
      return { error: 'Page value is too large' };
    }
  }

  // Validate limit parameter
  if (limit !== undefined) {
    const limitNum = Number(limit);
    if (!Number.isFinite(limitNum) || !Number.isInteger(limitNum)) {
      return { error: 'Limit must be a valid integer' };
    }
    if (limitNum <= 0) {
      return { error: 'Limit must be greater than 0' };
    }
    if (limitNum > 100) { // Reasonable upper limit
      return { error: 'Limit cannot exceed 100' };
    }
  }

  return {
    page: page ? Number(page) : 1,
    limit: limit ? Number(limit) : DEFAULT_LIMIT
  };
}