import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== Testing Edge Cases ===\n');

// Email tests
console.log('--- Email Validation ---');
const emailTests = [
  ['user@example.com', true],
  ['user+tag@example.co.uk', true],
  ['user.name@example.com', true],
  ['user..name@example.com', false],
  ['user@.example.com', false],
  ['user@example..com', false],
  ['user@example_.com', false],
  ['@example.com', false],
  ['user@', false],
  ['user@@example.com', false],
];

emailTests.forEach(([email, expected]) => {
  const result = isValidEmail(email);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${email}: ${result} (expected ${expected})`);
});

// US Phone tests
console.log('\n--- US Phone Validation ---');
const phoneTests = [
  ['212-555-7890', true],
  ['(212) 555-7890', true],
  ['2125557890', true],
  ['+1 212-555-7890', true],
  ['+12125557890', true],
  ['012-555-7890', false],
  ['112-555-7890', false],
  ['212-555-789', false],
  ['+44 20-7946-0958', false],
];

phoneTests.forEach(([phone, expected]) => {
  const result = isValidUSPhone(phone);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${phone}: ${result} (expected ${expected})`);
});

// Argentine Phone tests
console.log('\n--- Argentine Phone Validation ---');
const arPhoneTests = [
  ['+54 9 11 1234 5678', true],
  ['011 1234 5678', true],
  ['+54 341 123 4567', true],
  ['0341 4234567', true],
  ['11 1234 5678', false],
  ['54 11 1234 5678', false],
];

arPhoneTests.forEach(([phone, expected]) => {
  const result = isValidArgentinePhone(phone);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${phone}: ${result} (expected ${expected})`);
});

// Name tests
console.log('\n--- Name Validation ---');
const nameTests = [
  ['Jane Doe', true],
  ['José María González', true],
  ['O\'Brien', true],
  ['Smith-Johnson', true],
  ['X Æ A-12', false],
  ['John123', false],
  ['John@Doe', false],
  ['Àlvaro', true],
];

nameTests.forEach(([name, expected]) => {
  const result = isValidName(name);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${name}: ${result} (expected ${expected})`);
});

// Credit Card tests
console.log('\n--- Credit Card Validation ---');
const ccTests = [
  ['4111111111111111', true],
  ['5500000000000004', true],
  ['340000000000009', true],
  ['4111111111111112', false],
  ['1234567890123456', false],
];

ccTests.forEach(([cc, expected]) => {
  const result = isValidCreditCard(cc);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${cc}: ${result} (expected ${expected})`);
});

// Transformations tests
console.log('\n--- Transformations ---');
console.log('capitalizeSentences:', capitalizeSentences('hello world. how are you? i\'m fine!thanks.'));
console.log('extractUrls:', extractUrls('Visit http://example.com and https://test.com.'));
console.log('enforceHttps:', enforceHttps('Visit http://example.com and https://already.com'));
console.log('rewriteDocsUrls:', rewriteDocsUrls('See http://example.com/docs/guide and http://example.com/docs/api?v=1'));
console.log('extractYear:', extractYear('01/31/2024'));

// Puzzles tests
console.log('\n--- Puzzles ---');
console.log('findPrefixedWords:', findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));
console.log('findEmbeddedToken:', findEmbeddedToken('xfoo 1foo foo', 'foo'));
console.log('isStrongPassword(abab123!AB):', isStrongPassword('abab123!AB'));
console.log('isStrongPassword(Abcdef!234):', isStrongPassword('Abcdef!234'));
console.log('containsIPv6(2001:db8::1):', containsIPv6('2001:db8::1'));
console.log('containsIPv6(192.168.1.1):', containsIPv6('192.168.1.1'));
