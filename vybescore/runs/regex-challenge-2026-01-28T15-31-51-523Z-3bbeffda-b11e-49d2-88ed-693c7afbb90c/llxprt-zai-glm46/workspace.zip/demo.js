#!/usr/bin/env node

/**
 * Comprehensive demonstration of the Regex Challenge Toolkit
 * Run with: node demo.js
 */

import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('╔════════════════════════════════════════════════════════════════╗');
console.log('║         Regex Challenge Toolkit - Live Demonstration          ║');
console.log('╚════════════════════════════════════════════════════════════════╝\n');

// ========== VALIDATORS ==========
console.log('═══ VALIDATORS ═══\n');

console.log(' Email Validation:');
const emails = [
  'user@example.com',
  'user+tag@example.co.uk',
  'user..name@example.com',
  'user@example_.com'
];
emails.forEach(email => {
  console.log(`  ${email.padEnd(30)} → ${isValidEmail(email) ? '[OK] VALID' : ' INVALID'}`);
});

console.log('\n US Phone Validation:');
const usPhones = [
  '(212) 555-7890',
  '212-555-7890',
  '+1 212-555-7890',
  '012-555-7890',
  '+44 20-7946-0958'
];
usPhones.forEach(phone => {
  console.log(`  ${phone.padEnd(20)} → ${isValidUSPhone(phone) ? '[OK] VALID' : ' INVALID'}`);
});

console.log('\n Argentine Phone Validation:');
const arPhones = [
  '+54 9 11 1234 5678',
  '011 1234 5678',
  '+54 341 123 4567',
  '11 1234 5678',
  '54 11 1234 5678'
];
arPhones.forEach(phone => {
  console.log(`  ${phone.padEnd(25)} → ${isValidArgentinePhone(phone) ? '[OK] VALID' : ' INVALID'}`);
});

console.log('\n Name Validation:');
const names = [
  'Jane Doe',
  'José María González',
  "O'Brien",
  'X Æ A-12',
  'John123'
];
names.forEach(name => {
  console.log(`  ${name.padEnd(20)} → ${isValidName(name) ? '[OK] VALID' : ' INVALID'}`);
});

console.log('\n Credit Card Validation:');
const cards = [
  '4111111111111111',
  '5500000000000004',
  '340000000000009',
  '1234567890123456'
];
cards.forEach(card => {
  console.log(`  ${card.padEnd(20)} → ${isValidCreditCard(card) ? '[OK] VALID' : ' INVALID'}`);
});

// ========== TRANSFORMATIONS ==========
console.log('\n\n═══ TRANSFORMATIONS ═══\n');

console.log('  Sentence Capitalization:');
const text1 = 'hello world. how are you? i\'m fine!thanks.';
console.log(`  Input:  ${text1}`);
console.log(`  Output: ${capitalizeSentences(text1)}`);

console.log('\n URL Extraction:');
const text2 = 'Visit http://example.com and https://test.com/docs or www.github.com';
console.log(`  Input:  ${text2}`);
console.log(`  Output: ${extractUrls(text2).join(', ')}`);

console.log('\n HTTPS Enforcement:');
const text3 = 'Visit http://example.com and https://already.com';
console.log(`  Input:  ${text3}`);
console.log(`  Output: ${enforceHttps(text3)}`);

console.log('\n Docs URL Rewriting:');
const text4 = 'See http://example.com/docs/guide and http://example.com/docs/api?v=1';
console.log(`  Input:  ${text4}`);
console.log(`  Output: ${rewriteDocsUrls(text4)}`);

console.log('\n Year Extraction:');
const dates = ['01/31/2024', '12/25/1999', '13/01/2020', '02/30/2020'];
dates.forEach(date => {
  console.log(`  ${date.padEnd(15)} → ${extractYear(date)}`);
});

// ========== PUZZLES ==========
console.log('\n\n═══ PUZZLES ═══\n');

console.log(' Prefixed Word Search:');
const text5 = 'preview prevent prefix preface';
const prefix = 'pre';
const exceptions = ['prevent'];
console.log(`  Text: ${text5}`);
console.log(`  Prefix: "${prefix}", Exceptions: [${exceptions}]`);
console.log(`  Found: ${findPrefixedWords(text5, prefix, exceptions).join(', ')}`);

console.log('\n Embedded Token Search:');
const text6 = 'xfoo 1foo 2foo foo';
const token = 'foo';
console.log(`  Text: ${text6}`);
console.log(`  Token: "${token}"`);
console.log(`  Found: ${findEmbeddedToken(text6, token).join(', ')}`);

console.log('\n Password Strength:');
const passwords = [
  'Abcdef!234',
  'abab123!AB',
  'weak123',
  'StrongPass!123',
  'NoSpaces123!@'
];
passwords.forEach(pwd => {
  console.log(`  ${pwd.padEnd(20)} → ${isStrongPassword(pwd) ? '[OK] STRONG' : ' WEAK'}`);
});

console.log('\n IPv6 Detection:');
const addresses = [
  '2001:db8::1',
  '192.168.1.1',
  '::1',
  'fe80::1',
  '255.255.255.255'
];
addresses.forEach(addr => {
  console.log(`  ${addr.padEnd(20)} → ${containsIPv6(addr) ? '[OK] IPv6' : ' Not IPv6'}`);
});

console.log('\n╔════════════════════════════════════════════════════════════════╗');
console.log('║                    All demonstrations complete!                 ║');
console.log('╚════════════════════════════════════════════════════════════════╝');
