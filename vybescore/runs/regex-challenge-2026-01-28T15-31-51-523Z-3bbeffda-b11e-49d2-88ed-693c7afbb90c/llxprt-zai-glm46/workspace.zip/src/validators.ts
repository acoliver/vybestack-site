export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC standards.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for consecutive dots
  if (value.includes('..')) return false;
  
  // Check for dot at start or end of local part
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Check for underscores in domain (not allowed except in special cases, we reject)
  if (domain.includes('_')) return false;
  
  // Check for multiple @ signs
  if ((value.match(/@/g) || []).length > 1) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 prefix optional.
 * Rejects invalid area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const digitsOnly = value.replace(/[^\d+]/g, '');
  
  // Check for +1 prefix
  const hasPlus = value.startsWith('+');
  let digits = digitsOnly;
  if (hasPlus && digitsOnly.startsWith('+1')) {
    digits = digitsOnly.substring(2);
  } else if (hasPlus) {
    return false; // Has + but not +1
  }
  
  // Must be 10 digits (US phone number)
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (first digit after area code) cannot be 0 or 1
  const exchangeCode = digits.substring(3, 4);
  if (exchangeCode === '0' || exchangeCode === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it starts with +54 (country code)
  const hasCountryCode = cleaned.startsWith('+54');
  
  // If no country code, must start with 0 (trunk prefix)
  if (!hasCountryCode) {
    if (!cleaned.startsWith('0')) {
      return false;
    }
  }
  
  // Extract the part after country code (if present) or trunk prefix
  let numberPart: string;
  if (hasCountryCode) {
    numberPart = cleaned.substring(3); // Remove +54
  } else {
    numberPart = cleaned.substring(1); // Remove leading 0
  }
  
  // Check for optional mobile indicator 9
  if (numberPart.startsWith('9')) {
    numberPart = numberPart.substring(1);
  }
  
  // Now numberPart should contain area code + subscriber number
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  // Total: 8-12 digits
  
  if (numberPart.length < 8 || numberPart.length > 12) {
    return false;
  }
  
  // Try to extract area code (2-4 digits) and validate
  let foundValidSplit = false;
  
  // Try different area code lengths
  for (let acLen = 4; acLen >= 2; acLen--) {
    const potentialAreaCode = numberPart.substring(0, acLen);
    const potentialSubscriber = numberPart.substring(acLen);
    
    // Check if area code is valid (2-4 digits, leading digit 1-9)
    if (/^[1-9]\d{0,3}$/.test(potentialAreaCode) && 
        potentialSubscriber.length >= 6 && 
        potentialSubscriber.length <= 8) {
      
      // Area code must be 2-4 digits, leading digit must be 1-9
      if (potentialAreaCode.length >= 2 && potentialAreaCode.length <= 4 &&
          potentialAreaCode[0] >= '1' && potentialAreaCode[0] <= '9') {
        
        // Subscriber number must be 6-8 digits
        if (potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
          foundValidSplit = true;
          break;
        }
      }
    }
  }
  
  return foundValidSplit;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Check for other symbols (besides apostrophes, hyphens, spaces)
  // The regex handles this
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * Luhn algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx).
 * Checks prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{13})$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || 
                        mastercardRegex.test(cleaned) || 
                        amexRegex.test(cleaned);
  
  if (!isValidFormat) return false;
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
