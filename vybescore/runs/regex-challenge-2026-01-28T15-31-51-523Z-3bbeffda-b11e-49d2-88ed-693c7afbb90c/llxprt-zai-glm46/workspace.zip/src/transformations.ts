/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible (e.g., "e.g." not treated as sentence end).
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  let result = text.replace(/[ \t]+/g, ' ').trim();
  
  // Insert space after sentence endings if missing
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Split into sentences using sentence-ending punctuation
  // But be careful about abbreviations like e.g., i.e., etc., Mr., Dr., etc.
  const sentences: string[] = [];
  let current = '';
  let i = 0;
  
  while (i < result.length) {
    const char = result[i];
    current += char;
    
    // Check if we have a sentence-ending punctuation
    if (char === '.' || char === '!' || char === '?') {
      // If next char is uppercase or end of string, it's a sentence end
      const nextChar = result[i + 1];
      if (nextChar === undefined || nextChar === ' ' || nextChar === '\n' || 
          (nextChar >= 'A' && nextChar <= 'Z')) {
        sentences.push(current);
        current = '';
      }
    }
    i++;
  }
  
  if (current) {
    sentences.push(current);
  }
  
  // Capitalize first letter of each sentence
  const capitalized = sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return '';
    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
  });
  
  // Join with single spaces
  return capitalized.join(' ');
}

/**
 * Extracts all URLs from text, excluding trailing punctuation.
 * Returns an array of URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex matching http, https, and www protocols
  const urlRegex = /(https?:\/\/[^\s<]+|www\.[^\s<]+)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    return url.replace(/[.,;:!?)\]"']+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Replaces all http:// URLs with https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/([^/][^\s]*)/gi, 'https://$1');
}

/**
 * Rewrites http://example.com URLs to https:// format.
 * When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions).
 * Always upgrades scheme to https://.
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  let result = enforceHttps(text);
  
  // Now handle docs.example.com rewriting
  // Match https://example.com/docs/... and rewrite to https://docs.example.com/...
  result = result.replace(
    /https:\/\/(example\.com)(\/docs\/[^\s]*?)(?=[\s.,;:!?)\]"']|$)/gi,
    (match, host, path) => {
      // Check for excluded patterns
      const excludes = [
        '/cgi-bin', 
        '?', 
        '&', 
        '=', 
        '.jsp', 
        '.php', 
        '.asp', 
        '.aspx', 
        '.do', 
        '.cgi', 
        '.pl', 
        '.py'
      ];
      
      const shouldExclude = excludes.some(exclude => path.includes(exclude));
      
      if (shouldExclude) {
        return `https://${host}${path}`;
      }
      
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
  );
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' if format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Feb 29 for leap year
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}
