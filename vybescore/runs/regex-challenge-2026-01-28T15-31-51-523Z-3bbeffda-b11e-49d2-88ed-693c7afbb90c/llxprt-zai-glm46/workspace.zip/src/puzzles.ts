/**
 * Finds all words starting with the given prefix, excluding words in the exceptions list.
 * Uses word boundaries to ensure complete word matching.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to match words starting with prefix
  const regex = new RegExp('\\b' + escapedPrefix + '[a-zA-Z]*\\b', 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      exception.toLowerCase() === word.toLowerCase()
    )
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookahead/lookbehind to ensure proper context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit + token when it's not at the start
  const regex = new RegExp('\\d' + escapedToken + '(?=[^a-zA-Z]|$)', 'g');
  
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validates password strength.
 * Requirements: at least 10 characters, one uppercase, one lowercase, 
 * one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for repeated sequences (like "abab", "123123", etc.)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let i = 2; i <= 4; i++) {
    const repeatedPatternRegex = new RegExp('(.{' + i + '})\\1', 'g');
    if (repeatedPatternRegex.test(value)) return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation (::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8::1, ::1, 2001:db8:85a3::8a2e:370:7334
  // - IPv4 embedded: ::ffff:192.0.2.1 (we want to detect these as IPv6)
  
  // This regex matches IPv6 addresses but not plain IPv4
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;
  
  // Check for plain IPv4 (should not match)
  const ipv4Regex = /^((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])$/;
  
  // If it's a plain IPv4, return false
  if (ipv4Regex.test(value)) return false;
  
  // Check for IPv6 pattern
  return ipv6Regex.test(value);
}
