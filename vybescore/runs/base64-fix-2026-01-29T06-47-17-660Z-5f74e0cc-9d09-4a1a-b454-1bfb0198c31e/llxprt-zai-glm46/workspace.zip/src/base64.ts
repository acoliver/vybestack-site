/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Validate a Base64 string.
 * Returns true if the string contains only valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  // Remove padding for validation
  const withoutPadding = input.replace(/=+$/, '');
  
  // Empty string is not valid
  if (withoutPadding.length === 0) {
    return false;
  }
  
  // Check for valid Base64 characters (no need for length check since padding is optional)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Padding, if present, must be 1 or 2 = characters at the end
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    // Padding can only be 1 or 2 characters
    if (paddingLength > 2) {
      return false;
    }
    // Total length with padding must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate the input format
  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding produced meaningful results
    // A valid Base64 decode should produce bytes, but if the input was malformed,
    // Buffer might silently produce garbage. We need to validate.
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    // Verify by re-encoding and checking if it matches (normalized)
    const normalizedInput = trimmed.replace(/=+$/, '');
    const reencoded = buffer.toString('base64').replace(/=+$/, '');
    
    // If re-encoding doesn't match, the input was likely invalid
    if (reencoded !== normalizedInput) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message === INVALID_BASE64_ERROR) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
