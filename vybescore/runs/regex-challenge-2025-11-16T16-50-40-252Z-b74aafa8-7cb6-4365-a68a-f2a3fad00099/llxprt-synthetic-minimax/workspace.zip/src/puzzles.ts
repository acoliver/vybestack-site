/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex that matches words starting with the prefix
  const wordRegex = new RegExp(`\\b${prefix}\\w+\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  return matches.filter(match => !exceptionsLower.includes(match.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all words that contain the token
  const wordRegex = new RegExp(`\\b\\w*${token}\\w*\\b`, 'gi');
  const words = text.match(wordRegex) || [];
  
  // Filter words where token appears after a digit but not at the start of the word
  return words.filter(word => {
    const tokenIndex = word.indexOf(token);
    // Token must not be at the start of the word, and must be preceded by a digit
    return tokenIndex > 0 && /\d/.test(word[tokenIndex - 1]);
  });
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-={}[\];':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab should fail)
  // This regex looks for any 2+ character sequence that repeats immediately
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if there are any IPv4 addresses to exclude
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    // Remove IPv4 addresses to avoid false positives
    value = value.replace(ipv4Regex, ' ');
  }
  
  // IPv6 patterns to match
  const ipv6Patterns = [
    // Full IPv6: 8 groups of 4 hex digits
    /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/gi,
    // IPv6 with :: (shorthand)
    /\b(?:[a-f0-9]{1,4}:)*(?:[a-f0-9]{1,4})?(?:::[a-f0-9]{1,4})?(?::[a-f0-9]{1,4})*\b/gi,
    // IPv6 starting with ::
    /\b::(?:[a-f0-9]{1,4}:)*[a-f0-9]{1,4}\b/gi,
    // IPv6 ending with ::
    /\b(?:[a-f0-9]{1,4}:)+::(?:\d*\.\d*\.\d*\.\d*)?\b/gi // special case for IPv4-embedded
  ];
  
  // Test against all IPv6 patterns
  return ipv6Patterns.some(pattern => pattern.test(value));
}