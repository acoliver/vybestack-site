/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, identify sentence boundaries and capitalize the first letter after each boundary
  return text
    // Replace sentence endings (.?! followed by space or end of string)
    .replace(/([.!?])\s*([a-zA-ZÀ-ÿ])/g, (match, punctuation, letter) => {
      return punctuation + ' ' + letter.toUpperCase();
    })
    // Capitalize the very first character if it's a letter
    .replace(/^([a-zA-ZÀ-ÿ])/, (match, letter) => letter.toUpperCase())
    // Clean up extra spaces
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"'{}|\\^`[\]]+[^\s<>"'{}|\\^`[\].,!?;:]/gi;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.,!?;:\s]+$/, ''));
}

/**
 * Replace all http:// URLs with https://
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  const urlRegex = /http:\/\/([^/\s]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, host, path) => {
    // Skip if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|\?.*=|&.*=|\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    if (hasDynamicHints) {
      // Just upgrade to https, don't change host
      return `https://${host}${path}`;
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Extract domain name and append docs. prefix
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts.slice(-2).join('.');
        return `https://docs.${domain}${path}`;
      }
    }
    
    // For other paths, just upgrade the scheme
    return `https://${host}${path}`;
  });
}

/**
 * Extract year from mm/dd/yyyy format
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation
  if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
    return year;
  }
  
  return 'N/A';
}