export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn algorithm implementation for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').reverse().map(Number);
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex pattern
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  // Check for obviously invalid patterns
  if (emailRegex.test(value)) {
    // Additional checks
    const parts = value.split('@');
    if (parts.length !== 2) return false;
    
    const [local, domain] = parts;
    
    // Reject double dots
    if (local.includes('..') || domain.includes('..')) return false;
    
    // Reject trailing dots
    if (local.endsWith('.') || domain.endsWith('.')) return false;
    
    // Reject domains with underscores
    if (domain.includes('_')) return false;
    
    // Ensure local part is not empty
    if (!local || !domain) return false;
    
    // Ensure domain has a valid TLD (at least 2 characters)
    const domainParts = domain.split('.');
    if (domainParts.length < 2) return false;
    
    return true;
  }
  
  return false;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for minimum length (10 digits without country code, 11 with +1)
  if (digits.length < 10) return false;
  if (digits.length > 11) return false;
  
  // Remove country code if present
  const phoneDigits = digits.length === 11 && digits.startsWith('1') ? digits.slice(1) : digits;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneDigits.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check total length (should be exactly 10 digits)
  if (phoneDigits.length !== 10) return false;
  
  // Use the options parameter to check for extensions
  if (_options?.allowExtensions) {
    // If extensions are allowed, the input might have additional digits
    // For now, we'll validate the main phone number
  }
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Skip obviously wrong lengths
  if (digitsOnly.length < 8 || digitsOnly.length > 15) return false;
  
  // Check different patterns (after removing all non-digits)
  const patterns = [
    // Full international with mobile: +54 9 XX XXXX XXXX -> 549XXXXXXXXX
    /^54[2-9]\d{2,3}\d{6,8}$/,
    // International without mobile indicator: +54 XX XXXX XXXX -> 54XXXXXXXXX  
    /^54[2-9]\d{2,3}\d{6,8}$/,
    // National format with mobile: 0 9 XX XXXX XXXX -> 09XXXXXXXXX
    /^0[2-9]\d{2,3}\d{6,8}$/,
    // National format without mobile: 0XX XXXX XXXX -> 0XXXXXXXXX
    /^0[2-9]\d{2,3}\d{6,8}$/
  ];
  
  return patterns.some(pattern => pattern.test(digitsOnly));
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject empty or too short names
  if (!value || value.trim().length < 2) return false;
  
  // Allow unicode letters (including accents), spaces, apostrophes, and hyphens
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$/u;
  
  // Must be a valid name format and not contain digits or symbols (except allowed ones)
  if (!nameRegex.test(value.trim())) return false;
  
  // Additional check: reject if contains numbers or forbidden symbols
  if (/[0-9@#$%^&*()_+=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Reject "X Æ A-12" style names (consecutive capitals with special patterns)
  if (/[A-Z]{2,}\s*[Æ]\s*[A-Z]-\d{1,2}/.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check card type prefixes and lengths
  const cardTypes = [
    // Visa: starts with 4, length 13, 16, or 19
    { pattern: /^4\d{12}(\d{3})?(\d{3})?$/, lengths: [13, 16, 19] },
    // Mastercard: starts with 5[1-5] or 2[2-7], length 16
    { pattern: /^5[1-5]\d{14}$|^2[2-7]\d{14}$/, lengths: [16] },
    // American Express: starts with 34 or 37, length 15
    { pattern: /^3[47]\d{13}$/, lengths: [15] },
    // Discover: starts with 6011 or 65, length 16
    { pattern: /^6011\d{12}$|^65\d{14}$/, lengths: [16] }
  ];
  
  // Check if it matches any card type
  const isValidType = cardTypes.some(type => {
    return type.pattern.test(digits) && type.lengths.includes(digits.length);
  });
  
  if (!isValidType) return false;
  
  // Run Luhn algorithm
  return runLuhnCheck(digits);
}
