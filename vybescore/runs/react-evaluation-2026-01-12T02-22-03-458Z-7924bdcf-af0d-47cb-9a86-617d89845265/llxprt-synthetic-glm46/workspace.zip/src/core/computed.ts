/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = typeof equal === 'function' ? equal : undefined
  
  // Collection of observers that depend on this computed value
  const observers: Set<Observer<unknown>> = new Set()
  
  
  
  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer as Observer<unknown>)
    }
    
    // Always re-compute when read to ensure latest values from dependencies
    const prevObserver = getActiveObserver()
    setActiveObserver(computedObserver)
    try {
      const newValue = updateFn(computedObserver.value)
      
      // Only update if value has actually changed
      if (equalFn ? !equalFn(computedObserver.value!, newValue) : computedObserver.value !== newValue) {
        computedObserver.value = newValue
      }
    } finally {
      setActiveObserver(prevObserver)
    }
    
    return computedObserver.value!
  }
  
  const updateComputed = () => {
    // Force recomputation and notify dependent observers
    const newValue = updateFn(computedObserver.value)
    
    // Only update if value has actually changed
    if (equalFn ? !equalFn(computedObserver.value!, newValue) : computedObserver.value !== newValue) {
      computedObserver.value = newValue
      
      // Notify all observers that depend on this computed value
      const observersToNotify = Array.from(observers)
      for (const observer of observersToNotify) {
        // Skip observers that have been disposed
        try {
          updateObserver(observer)
        } catch (e) {
          // If observer fails, remove it to prevent memory leaks
          observers.delete(observer)
        }
      }
    }
  }
  
  // Replace the updateFn to call our updateComputed wrapper
  computedObserver.updateFn = (_prevValue) => {
    updateComputed()
    return computedObserver.value!
  }
  
  return read
}
