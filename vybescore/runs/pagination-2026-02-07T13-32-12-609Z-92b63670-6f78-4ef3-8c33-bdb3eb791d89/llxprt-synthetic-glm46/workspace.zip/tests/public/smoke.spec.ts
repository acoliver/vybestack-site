import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('validates page and limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test invalid page
    let response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
    
    // Test negative page
    response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
    
    // Test invalid limit
    response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
    
    // Test limit > 100
    response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
    
    // Test valid parameters
    response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.total).toBeGreaterThan(0);
  });

  it('returns correct pagination data', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // First page
    const page1 = await request(app).get('/inventory?page=1&limit=5');
    expect(page1.status).toBe(200);
    expect(page1.body.items).toHaveLength(5);
    expect(page1.body.page).toBe(1);
    expect(page1.body.limit).toBe(5);
    expect(page1.body.total).toBe(15);
    expect(page1.body.hasNext).toBe(true);
    
    // Second page
    const page2 = await request(app).get('/inventory?page=2&limit=5');
    expect(page2.status).toBe(200);
    expect(page2.body.items).toHaveLength(5);
    expect(page2.body.page).toBe(2);
    expect(page2.body.limit).toBe(5);
    expect(page2.body.total).toBe(15);
    expect(page2.body.hasNext).toBe(true);
    
    // Third page
    const page3 = await request(app).get('/inventory?page=3&limit=5');
    expect(page3.status).toBe(200);
    expect(page3.body.items).toHaveLength(5);
    expect(page3.body.page).toBe(3);
    expect(page3.body.limit).toBe(5);
    expect(page3.body.total).toBe(15);
    expect(page3.body.hasNext).toBe(false);
  });
});
