import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number;
    if (pageParam === undefined) {
      page = 1;
    } else {
      const parsed = Number(pageParam);
      if (isNaN(parsed) || parsed < 1 || !Number.isInteger(parsed)) {
        return res.status(400).json({ error: 'Invalid page parameter - must be a positive integer' });
      }
      page = parsed;
    }

    // Validate limit parameter
    let limit: number;
    if (limitParam === undefined) {
      limit = 5;
    } else {
      const parsed = Number(limitParam);
      if (isNaN(parsed) || parsed < 1 || parsed > 100 || !Number.isInteger(parsed)) {
        return res.status(400).json({ error: 'Invalid limit parameter - must be a positive integer between 1 and 100' });
      }
      limit = parsed;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
