import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { loadSQL } from './sqljs-types.js';
import type { Database } from './sqljs-types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field?: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Database variables
let db: Database | null = null;
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load SQL.js
    const SQL = await loadSQL();
    const initOptions = {
      locateFile: (file: string): string => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    };
    const initializedSQL = await SQL(initOptions);

    // Check if database exists
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      const arrayBuffer = dbBuffer.buffer.slice(dbBuffer.byteOffset, dbBuffer.byteOffset + dbBuffer.byteLength);
      db = new initializedSQL.Database(arrayBuffer);
    } else {
      // Create new database and initialize schema
      db = new initializedSQL.Database();
      const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      db!.run(schema);
      syncDatabaseToDisk();
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function syncDatabaseToDisk(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Form validation
function validateForm(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field]!.trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
      });
    }
  });

  // Email validation
  if (data.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.push({ message: 'Please enter a valid email address' });
    }
  }

  // Phone validation
  if (data.phone) {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.push({ message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode) {
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.push({ message: 'Postal code can only contain letters, numbers, spaces, and dashes' });
    }
  }

  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Return form with errors
    return res.render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
  }

  // Save to database
  if (!db) {
    return res.status(500).send('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);

  stmt.free();
  syncDatabaseToDisk();

  return res.redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  // Default first name
  let firstName = 'friend';
  
  // Extract first name from the most recent submission
  if (db) {
    try {
      // First check if the table has any rows
      const countStmt = db.prepare('SELECT COUNT(*) as count FROM submissions');
      const countResult = countStmt.getAsObject(['count']);
      countStmt.free();
      
      // Only attempt to fetch data if there are submissions
      if (countResult && countResult.count && Number(countResult.count) > 0) {
        const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
        stmt.step(); // Move to first row
        const result = stmt.getAsObject(['first_name']);
        stmt.free();
        
        if (result && result.first_name && typeof result.first_name === 'string') {
          firstName = result.first_name;
        }
      }
    } catch (error) {
      // Table might be empty or other error, use default name
      console.log('Could not fetch first name, using default');
    }
  }

  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    syncDatabaseToDisk();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });
}

startServer().catch(console.error);
