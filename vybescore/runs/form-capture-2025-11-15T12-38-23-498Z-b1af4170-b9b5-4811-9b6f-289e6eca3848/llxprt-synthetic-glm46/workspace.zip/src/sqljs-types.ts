export interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

export interface Statement {
  run(...params: unknown[]): void;
  step(): boolean; // Returns true if there's another row
  getAsObject(columnNames: string[]): Record<string, unknown>;
  free(): void;
}

// Import sql.js dynamically to avoid declaration issues
// @ts-ignore - sql.js doesn't provide proper TypeScript definitions
const loadSQL = async () => {
  const SQL = await import('sql.js');
  return SQL.default;
};

export { loadSQL };

type SqlJsModule = ReturnType<typeof loadSQL> extends Promise<infer T> ? T : never;

export interface SqlJsConstructor {
  Database: new (data?: ArrayBuffer) => Database;
}