/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words by whitespace
  const words = text.split(/\s+/);
  
  // Filter words that start with the prefix
  const prefixedWords = words.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerPrefix = prefix.toLowerCase();
    return lowerWord.startsWith(lowerPrefix);
  });
  
  // Remove exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  return prefixedWords
    .map(word => word.toLowerCase())
    .filter(word => !lowerExceptions.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Split text and find tokens that follow digits
  const words = text.split(/\s+/);
  const results: string[] = [];
  
  for (let i = 0; i < words.length; i++) {
    const word = words[i];
    
    // Check if word contains digit followed by token
    const match = word.match(/(\d+)(.+)/);
    if (match) {
      const [, digitPart, restPart] = match;
      if (restPart.includes(token) && restPart === token) {
        results.push(digitPart + token);
      }
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (anything that's not alphanumeric or whitespace)
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences
  // Look for patterns where a sequence of 2+ characters repeats immediately
  // e.g., abab, abcabc, 123123, etc.
  const repeatedSequenceRegex = /(..+?)\1+/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First filter out IPv4 addresses to avoid false positives
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  const textWithoutIPv4 = value.replace(ipv4Regex, 'IPV4');
  
  // IPv6 patterns (comprehensive but simplified)
  const ipv6Patterns = [
    // Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with :: (condensing zeros) - various forms
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}\b/,
    /\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})\b/,
    /\b:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)\b/,
    // IPv4-mapped IPv6: ::ffff:192.0.2.128
    /\b::ffff:(?=IPV4)\b/,
    // IPv6 with IPv4 suffix: 2001:db8::192.0.2.128
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?=IPV4)\b/
  ];
  
  // Test each IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(textWithoutIPv4)) {
      return true;
    }
  }
  
  return false;
}
