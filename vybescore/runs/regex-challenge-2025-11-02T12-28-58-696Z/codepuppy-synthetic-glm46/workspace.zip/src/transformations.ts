/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty string
  if (!text.trim()) return text;
  
  // First, normalize spacing around sentence endings
  // Ensure exactly one space after sentence endings (.?!)
  let normalized = text.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Collapse multiple spaces into one, but preserve newlines for now
  normalized = normalized.replace(/ {2,}/g, ' ');
  
  // Handle edge case: text might start with punctuation
  normalized = normalized.replace(/^[.!?]\s*/, '');
  
  // Capitalize first character of each sentence
  const sentences = normalized.split(/([.!?]\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    if (sentence && sentence.trim()) {
      // Find the first letter character and capitalize it
      sentences[i] = sentence.replace(/^[^a-zA-ZÀ-ÿ]*([a-zA-ZÀ-ÿ])/, (match, firstLetter) => {
        return match.replace(firstLetter, firstLetter.toUpperCase());
      });
    }
  }
  
  return sentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches:
  // - http:// and https:// protocols
  // - www. domains (optional)
  // - Domain names with various extensions
  // - Paths, query strings, fragments
  // - Numbers and special characters in URLs
  
  const urlRegex = /(https?:\/\/)?www\.[^\s/$.?#].[^\s]*|(https?:\/\/[^\s/$.?#].[^\s]*)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches: remove trailing punctuation but keep valid URL characters
  return matches.map(url => {
    // Remove trailing punctuation that's not part of URL
    return url.replace(/[.,;:!?)\]}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't affect https://
  // Use word boundary to avoid matching within other text
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  // This will handle various domains and paths
  
  const urlRegex = /http:\/\/([^\/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlRegex, (match, domain, path = '') => {
    // Always upgrade to https
    let result = 'https://' + domain + path;
    
    // Only rewrite host to docs.example.com when:
    // 1. Path begins with /docs/
    // 2. Path doesn't contain dynamic hints (cgi-bin, ?, &, =)
    // 3. Path doesn't end with legacy extensions (.jsp, .php, .asp, etc.)
    
    const dynamicHints = ['cgi-bin', '?', '&', '='];
    const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    
    const hasDynamicHints = dynamicHints.some(hint => path.includes(hint));
    const hasLegacyExtension = legacyExtensions.some(ext => path.endsWith(ext));
    const startsWithDocs = path.startsWith('/docs/');
    
    if (startsWithDocs && !hasDynamicHints && !hasLegacyExtension) {
      // Rewrite domain to docs.subdomain.com
      result = 'https://docs.' + domain + path;
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February (basic check)
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  
  const maxDays = monthNum === 2 && isLeapYear ? 29 : daysInMonth[monthNum - 1];
  
  if (dayNum > maxDays) return 'N/A';
  
  return year;
}
