export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that handles:
  // - Standard local parts with letters, digits, and special characters
  // - Plus signs for tagging (e.g., name+tag@example.com)
  // - Domain parts with proper structure
  // - Rejects double dots, trailing dots, underscores in domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for common invalid patterns
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots in local part
  if (value.includes('..')) return false;
  
  // Reject trailing dot in local or domain part
  if (value.endsWith('.')) return false;
  
  // Reject underscores in domain
  const [, domain] = value.split('@');
  if (domain.includes('_')) return false;
  
  // Ensure domain has at least one dot and proper structure
  if (!domain.includes('.') || domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Reject invalid domain segments (too short, starting/ending with hyphens)
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.length === 0) return false;
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number)
  if (digits.length < 10) return false;
  
  // Handle optional +1 country code
  const phoneDigits = digits.startsWith('1') && digits.length === 11 ? digits.slice(1) : digits;
  
  // Must be exactly 10 digits after removing country code
  if (phoneDigits.length !== 10) return false;
  
  // Extract area code and validate rules
  const areaCode = phoneDigits.substring(0, 3);
  const exchangeCode = phoneDigits.substring(3, 6);
  phoneDigits.substring(6, 10);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Validate the full format using regex for better pattern matching
  // Supports: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value.trim());
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Handle optional country code +54
  let remainingDigits = digits;
  let hasCountryCode = false;
  
  if (remainingDigits.startsWith('54')) {
    remainingDigits = remainingDigits.slice(2);
    hasCountryCode = true;
  }
  
  // Handle optional trunk prefix 0
  let hasTrunkPrefix = false;
  if (remainingDigits.startsWith('0')) {
    remainingDigits = remainingDigits.slice(1);
    hasTrunkPrefix = true;
  }
  
  // Handle optional mobile indicator 9
  if (remainingDigits.startsWith('9')) {
    remainingDigits = remainingDigits.slice(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  
  // Try different area code lengths
  for (const acLength of [2, 3, 4]) {
    if (remainingDigits.length >= acLength) {
      const areaCode = remainingDigits.substring(0, acLength);
      const subscriberNumber = remainingDigits.substring(acLength);
      
      // Area code validation: leading digit must be 1-9
      if (areaCode[0] !== '0' && /^[1-9]\d{0,3}$/.test(areaCode)) {
        // Subscriber number must be 6-8 digits
        if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8 && /^\d+$/.test(subscriberNumber)) {
          // When country code is omitted, trunk prefix is required
          if (!hasCountryCode && !hasTrunkPrefix) {
            continue;
          }
          return true;
        }
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and weird characters like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value.trim())) return false;
  
  // Must have at least one letter
  const hasLetter = /\p{L}/u.test(value);
  if (!hasLetter) return false;
  
  // Should not consist only of hyphens, apostrophes, or spaces
  const meaningfulChars = value.replace(/[\s\-']/g, '');
  if (meaningfulChars.length === 0) return false;
  
  // Reject obviously problematic patterns (too many special characters in a row)
  if (/[\-']{2,}/.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check format based on card type
  const isValidFormat = visaRegex.test(cleanNumber) || 
                        mastercardRegex.test(cleanNumber) || 
                        amexRegex.test(cleanNumber);
  
  if (!isValidFormat) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}
