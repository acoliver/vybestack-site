export interface ValidationError {
  message: string;
  field?: string;
}

export function validateReportData(data: unknown): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Check if data is an object
  if (typeof data !== 'object' || data === null) {
    errors.push({ message: 'Data must be a valid JSON object' });
    return errors;
  }
  
  const reportData = data as Record<string, unknown>;
  
  // Validate title
  if (!reportData.title || typeof reportData.title !== 'string') {
    errors.push({ message: 'Missing or invalid title field', field: 'title' });
  }
  
  // Validate summary
  if (!reportData.summary || typeof reportData.summary !== 'string') {
    errors.push({ message: 'Missing or invalid summary field', field: 'summary' });
  }
  
  // Validate entries
  if (!reportData.entries || !Array.isArray(reportData.entries)) {
    errors.push({ message: 'Missing or invalid entries field (must be an array)', field: 'entries' });
    return errors;
  }
  
  // Validate each entry
  reportData.entries.forEach((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      errors.push({ message: `Entry ${index + 1} must be an object`, field: `entries[${index}]` });
      return;
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    // Validate label
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      errors.push({ message: `Entry ${index + 1} missing or invalid label field`, field: `entries[${index}].label` });
    }
    
    // Validate amount
    if (entryObj.amount === undefined || typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      errors.push({ message: `Entry ${index + 1} missing or invalid amount field (must be a number)`, field: `entries[${index}].amount` });
    }
  });
  
  return errors;
}