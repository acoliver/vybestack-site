#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types.js';
import { validateReportData } from '../validation.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataPath: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script name
  const cliArgs = argv.slice(2);
  
  // Parse required positional arg (data.json)
  if (cliArgs.length === 0) {
    throw new Error('Missing required argument: data.json file path');
  }
  args.dataPath = cliArgs[0];

  // Parse flags
  for (let i = 1; i < cliArgs.length; i++) {
    const arg = cliArgs[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= cliArgs.length) {
          throw new Error('--format flag requires a value');
        }
        args.format = cliArgs[i + 1];
        i++; // Skip next arg as it's the value
        break;
      case '--output':
        if (i + 1 >= cliArgs.length) {
          throw new Error('--output flag requires a value');
        }
        args.outputPath = cliArgs[i + 1];
        i++; // Skip next arg as it's the value
        break;
      case '--includeTotals':
        args.includeTotals = true;
        break;
      default:
        if (!arg.startsWith('--')) {
          throw new Error(`Unknown argument: ${arg}`);
        }
        break;
    }
  }

  // Validate required arguments
  if (!args.dataPath) {
    throw new Error('Missing required argument: data.json file path');
  }
  if (!args.format) {
    throw new Error('Missing required flag: --format <format>');
  }

  return args;
}

function validateFormat(format: string): format is 'markdown' | 'text' {
  return format === 'markdown' || format === 'text';
}

function readAndParseJSON(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate data structure
    const errors = validateReportData(data);
    if (errors.length > 0) {
      const errorMessages = errors.map(e => `  - ${e.message}`).join('\n');
      throw new Error(`Invalid data structure:\n${errorMessages}`);
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && (error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  try {
    const args = parseArguments(process.argv);
    
    // Read and parse JSON data
    const reportData = readAndParseJSON(args.dataPath);
    
    // Validate format
    if (!validateFormat(args.format)) {
      throw new Error(`Unsupported format: ${args.format}`);
    }
    
    // Render report
    let renderedContent: string;
    if (args.format === 'markdown') {
      renderedContent = renderMarkdown(reportData, args.includeTotals);
    } else {
      renderedContent = renderText(reportData, args.includeTotals);
    }
    
    // Output result
    writeOutput(renderedContent, args.outputPath);
    
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
