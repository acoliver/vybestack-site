import { ReportData } from '../types.js';
import { formatAmount, computeTotal } from './formatter.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  let output = `${data.title}\n\n${data.summary}\n\nEntries:\n`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    const total = computeTotal(data.entries);
    output += `\nTotal: ${formatAmount(total)}\n`;
  }
  
  return output;
}