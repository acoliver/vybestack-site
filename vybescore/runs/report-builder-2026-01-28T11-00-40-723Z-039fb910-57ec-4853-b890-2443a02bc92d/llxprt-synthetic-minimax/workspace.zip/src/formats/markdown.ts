import { ReportData } from '../types.js';
import { formatAmount, computeTotal } from './formatter.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  let output = `# ${data.title}\n\n${data.summary}\n\n## Entries\n`;
  
  for (const entry of data.entries) {
    output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }
  
  if (includeTotals) {
    const total = computeTotal(data.entries);
    output += `\n**Total:** ${formatAmount(total)}\n`;
  }
  
  return output;
}