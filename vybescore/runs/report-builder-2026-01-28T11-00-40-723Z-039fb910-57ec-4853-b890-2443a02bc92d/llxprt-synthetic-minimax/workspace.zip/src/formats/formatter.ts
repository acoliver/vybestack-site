import { ReportData } from '../types.js';

export interface Formatter {
  render(data: ReportData, includeTotals: boolean): string;
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function computeTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}