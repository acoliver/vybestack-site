/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  // Handle equal parameter - can be boolean or EqualFn<T>
  if (equal !== undefined) {
    if (typeof equal === 'function') {
      s.equalFn = equal
    } else if (equal === false) {
      // Always update when equal is false
      s.equalFn = () => false
    } else {
      // Use default reference equality when equal is true
      s.equalFn = (lhs, rhs) => lhs === rhs
    }
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer to be notified when the value changes
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value should actually change based on equal function
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    
    if (shouldUpdate) {
      s.value = nextValue
      // Notify all registered observers
      notifyObservers(s)
    }
    
    return s.value
  }

  return [read, write]
}
