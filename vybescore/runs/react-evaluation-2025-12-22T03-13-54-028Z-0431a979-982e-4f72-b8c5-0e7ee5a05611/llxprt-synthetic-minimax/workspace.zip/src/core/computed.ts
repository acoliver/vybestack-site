/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value: value,
    updateFn,
  }

  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn: undefined,
  }

  const getComputedValue = (): T => {
    // Clear previous dependencies so we can re-register current ones
    subject.observers.clear()
    
    // Register this computed value's observer if there's an active observer
    const activeObs = getActiveObserver()
    if (activeObs) {
      subject.observers.add(activeObs)
    }

    // Re-compute the value
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    subject.value = newValue

    return newValue
  }

  return getComputedValue
}
