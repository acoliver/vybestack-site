import { readFileSync } from 'fs';
import { ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): { 
  dataFile: string; 
  format: string; 
  output?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  const parsedArgs: { 
    dataFile: string; 
    format: string; 
    output?: string; 
    includeTotals: boolean 
  } = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsedArgs.format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      parsedArgs.output = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      parsedArgs.includeTotals = true;
    } else if (!arg.startsWith('--') && !parsedArgs.dataFile) {
      parsedArgs.dataFile = arg;
    }
  }

  if (!parsedArgs.dataFile) {
    throw new Error('Missing data file argument');
  }
  
  if (!parsedArgs.format) {
    throw new Error('Missing --format argument');
  }
  
  if (!['markdown', 'text'].includes(parsedArgs.format)) {
    throw new Error(`Unsupported format: ${parsedArgs.format}`);
  }

  return parsedArgs;
}

function loadData(filePath: string): ReportData {
  try {
    const data = JSON.parse(readFileSync(filePath, 'utf8'));
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid label in entry');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid amount in entry');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${filePath}`);
    }
    throw error;
  }
}

function main() {
  try {
    const { dataFile, format, output, includeTotals } = parseArgs();
    const data = loadData(dataFile);
    
    let result: string;
    if (format === 'markdown') {
      result = renderMarkdown(data, { includeTotals });
    } else if (format === 'text') {
      result = renderText(data, { includeTotals });
    } else {
      // This should never happen due to validation in parseArgs
      throw new Error(`Unsupported format: ${format}`);
    }
    
    if (output) {
      // In a real implementation we would write to file
      // For now, just print to stdout as instructed
      console.log(result);
    } else {
      console.log(result);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();