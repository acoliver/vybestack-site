import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseService {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      this.sqlJs = await initSqlJs({
        locateFile: (file) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
      });

      console.log('sql.js initialized');

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        console.log('Loading existing database');
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new this.sqlJs.Database(dbBuffer);
      } else {
        console.log('Creating new database');
        this.db = new this.sqlJs.Database();
        await this.createSchema();
      }
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Database initialization failed:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!fs.existsSync(this.schemaPath)) {
      throw new Error(`Schema file not found at ${this.schemaPath}`);
    }

    const schemaSql = fs.readFileSync(this.schemaPath, 'utf-8');
    this.db!.run(schemaSql);
  }

  async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province_region,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvinceRegion,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    await this.saveToDisk();
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbBinary = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(dbBinary));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  async shutdown(): Promise<void> {
    await this.close();
  }
}

// Export singleton instance
export const dbService = new DatabaseService();

// Graceful shutdown handling
process.on('SIGTERM', async () => {
  await dbService.shutdown();
  process.exit(0);
});

process.on('SIGINT', async () => {
  await dbService.shutdown();
  process.exit(0);
});