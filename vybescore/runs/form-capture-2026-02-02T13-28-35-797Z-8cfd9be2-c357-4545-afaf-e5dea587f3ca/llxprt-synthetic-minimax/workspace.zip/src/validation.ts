import { Request } from 'express';

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationErrors {
  [key: string]: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationErrors;
  data?: FormData;
}

export function validateFormData(req: Request): ValidationResult {
  const errors: ValidationErrors = {};
  const body = req.body;

  // Required field validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const value = body[field];
    if (!value || typeof value !== 'string' || value.trim() === '') {
      errors[field] = `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`;
    }
  }

  // Email validation
  const email = body.email;
  if (email && typeof email === 'string') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation (allow international formats)
  const phone = body.phone;
  if (phone && typeof phone === 'string') {
    // Allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^[+]?[\d\s()-]{7,}$/;
    if (!phoneRegex.test(phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (alphanumeric)
  const postalCode = body.postalCode;
  if (postalCode && typeof postalCode === 'string') {
    // Allow alphanumeric and spaces (handle formats like "SW1A 1AA")
    const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
    if (!postalRegex.test(postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  const isValid = Object.keys(errors).length === 0;

  if (isValid) {
    return {
      isValid: true,
      errors: {},
      data: {
        firstName: body.firstName.trim(),
        lastName: body.lastName.trim(),
        streetAddress: body.streetAddress.trim(),
        city: body.city.trim(),
        stateProvinceRegion: body.stateProvinceRegion.trim(),
        postalCode: body.postalCode.trim(),
        country: body.country.trim(),
        email: body.email.trim(),
        phone: body.phone.trim()
      }
    };
  }

  return {
    isValid: false,
    errors,
    data: body
  };
}