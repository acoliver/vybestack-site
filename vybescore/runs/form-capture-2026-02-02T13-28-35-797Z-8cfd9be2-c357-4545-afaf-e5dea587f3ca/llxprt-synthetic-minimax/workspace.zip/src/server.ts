import express, { Request, Response } from 'express';
import * as path from 'path';
import { dbService } from './database';
import { validateFormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Configure Express
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Route handlers
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Us',
    errors: {},
    formData: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const validation = validateFormData(req);
    
    if (!validation.isValid) {
      // Validation failed, re-render form with errors
      res.status(400).render('form', {
        title: 'Contact Us - Please Fix Errors',
        errors: validation.errors,
        formData: validation.data || req.body
      });
      return;
    }

    // Validation passed, insert into database
    await dbService.insertSubmission(validation.data!);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      title: 'Contact Us - Error',
      errors: { general: 'An error occurred. Please try again.' },
      formData: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await dbService.shutdown();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await dbService.shutdown();
  process.exit(0);
});

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbService.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(console.error);

export default app;
