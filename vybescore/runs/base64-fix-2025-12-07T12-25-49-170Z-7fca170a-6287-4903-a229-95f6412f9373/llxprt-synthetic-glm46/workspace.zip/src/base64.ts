/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

function isValidBase64(input: string): boolean {
  // Check if input contains only valid Base64 characters
  if (!BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Check if padding characters are only at the end and are consecutive
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // All characters after first '=' must be '=' as well
    const afterPadding = input.slice(paddingIndex + 1);
    if (!/^[=]*$/.test(afterPadding)) {
      return false;
    }
    
    // Check that total padding is correct length (max 2 '=' chars)
    const paddingLength = input.length - paddingIndex;
    if (paddingLength > 2) {
      return false;
    }
    
    // Padding length must follow Base64 rules:
    // - If there is 1 '=', the string length must be 4n + 3
    // - If there are 2 '=', the string length must be 4n + 2
    // - Some implementations have padding even when divisible by 4, we should accept those
    
    const totalLength = input.length;
    if (totalLength % 4 === 0 && paddingLength > 0) {
      // Historically, some implementations (including Node's Buffer) produce
      // padded outputs even when the string length is divisible by 4.
      // We accept these as valid to maintain compatibility.
      return true;
    }
  } else {
    // No padding, Node.js Buffer allows strings not divisible by 4.
    // This is technically more lenient than the strict RFC standard,
    // but matches Node.js Buffer behavior which is what users expect.
    // We only reject obvious invalid cases.
    if (input.length % 4 === 1) {
      return false; // Length % 4 == 1 is invalid for any Base64 string
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 */
export function decode(input: string): string {
  // Validate input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
