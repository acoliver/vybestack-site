/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences and collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing around sentence terminators
  // Ensure there's exactly one space after sentence terminators
  let result = text.replace(/([.!?])(\s*)/g, '$1 ');
  
  // Collapse multiple spaces to single spaces
  result = result.replace(/\s+/g, ' ');
  
  // Trim leading and trailing spaces
  result = result.trim();
  
  // Split into sentences and capitalize each one
  const sentences = result.split(/([.!?]\s+)/);
  
  // Process each sentence
  for (let i = 0; i < sentences.length; i++) {
    // Only process non-empty sentences that don't start with punctuation
    if (sentences[i].length > 0 && /[A-Za-z]/.test(sentences[i][0])) {
      // Capitalize the first letter
      sentences[i] = sentences[i][0].toUpperCase() + sentences[i].slice(1);
    }
  }
  
  // Join sentences back together
  return sentences.join('');
}

/**
 * Extracts all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Extract URLs from text without trailing punctuation
  // Should handle common URL patterns with http(s), www, etc.
  
  // Regex to match URLs:
  // - Protocol (http, https, ftp, etc.)
  // - Domain name with subdomains
  // - Optional port
  // - Path, query, and fragment
  const urlRegex = /(https?:\/\/|ftp:\/\/|www\.)[^\s<>\"{}|\\\^`\[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,;!?'\"\}\]\)]+$/g, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using word boundary to avoid replacing part of https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to the rules described in problem.md.
 */
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade the scheme to https://
  // - When the path begins with /docs/, rewrite the host to docs.example.com
  // - Skip the host rewrite when the path contains dynamic hints
  // 
  // Dynamic hints include:
  // - cgi-bin
  // - Query strings (?, &, =)
  // - Legacy extensions (.jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
  
  return text.replace(/http:\/\/example\.com\/([^\s<>\"{}|\\\^`\[\]\)]+)/gi, (match, pathAndQuery) => {
    // Check for dynamic hints that should prevent the host rewrite
    const hasDynamicHints = /\/cgi-bin|[?=&]|\/(jsp|php|asp|aspx|do|cgi|pl|py)|\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i.test(pathAndQuery);
    
    // Always upgrade to https://
    let result = match.replace('http://', 'https://');
    
    // If path starts with /docs/ and no dynamic hints, rewrite host to docs.example.com
    if (pathAndQuery.startsWith('/docs/') && !hasDynamicHints) {
      result = result.replace('https://example.com', 'https://docs.example.com');
    }
    
    return result;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format or returns "N/A" for invalid dates.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy
  // If the string doesn't match that format or month/day are invalid, return "N/A"
  
  // Check if the string matches mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return "N/A";
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return "N/A";
  }
  
  // Validate day based on month (accounting for all months, including February)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  if (day < 1 || day > maxDay) {
    return "N/A";
  }
  
  return year;
}