// Temporary file to compare against the broken functions
export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implements robust email validation.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  if (value.includes('..')) return false;
  if (value.endsWith('.')) return false;
  
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) return false;
  
  return true;
}