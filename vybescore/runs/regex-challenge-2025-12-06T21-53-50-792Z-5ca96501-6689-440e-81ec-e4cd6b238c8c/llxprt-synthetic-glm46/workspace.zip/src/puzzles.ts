/**
 * Finds words starting with the prefix but excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
  if (!text || !prefix) return [];
  
  // Create a Set for efficient exception checking
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  // Create a regex that matches words with the specified prefix
  const regex = new RegExp(`\\b${prefix}\\w+`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions and return unique matches
  return [...new Set(matches.filter(word => 
    !exceptionSet.has(word.toLowerCase())
  ))];
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start
  
  if (!text || !token) return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a regex that matches a digit followed by the token
  // This captures the digit+token combination as expected by the test
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validates strong password requirements.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Validate strong password requirements:
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol
  // No whitespace, no immediate repeated sequences (e.g., abab should fail)
  
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, not including digits and letters)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This regex matches patterns where a 2-character sequence repeats immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses don't match
  
  if (!value) return false;
  
  // IPv6 address regex that includes shorthand support
  // This matches most common IPv6 formats, including those with :: shorthand
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  // IPv4 address regex to exclude false positives
  const ipv4Regex = /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // First check if it contains IPv6 pattern
  const hasIPv6 = ipv6Regex.test(value);
  
  if (!hasIPv6) {
    return false;
  }
  
  // Then check if it might be an IPv4 address (which would be a false positive)
  return !ipv4Regex.test(value);
}