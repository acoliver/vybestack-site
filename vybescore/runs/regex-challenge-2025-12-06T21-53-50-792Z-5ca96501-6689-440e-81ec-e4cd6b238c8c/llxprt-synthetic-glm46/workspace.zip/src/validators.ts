Exporting a clean validators.ts
