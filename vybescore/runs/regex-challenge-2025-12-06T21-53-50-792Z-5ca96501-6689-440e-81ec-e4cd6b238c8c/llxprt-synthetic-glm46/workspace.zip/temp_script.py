import re
import sys

# Read the file
with open('src/puzzles.ts', 'r') as f:
    content = f.read()

# Replace \\b with \b (literal backslash b with backslash+word boundary)
content = content.replace('\\b', '\b')

# Replace \\w+ with \w+ (literal backslash w with backslash+word character)
content = content.replace('\\w+', '\w+')

# Write back
with open('src/puzzles.ts', 'w') as f:
    f.write(content)

print("Fixed escape characters in puzzles.ts")