#!/usr/bin/env node
import fs from 'fs';
import path from 'path';

const filePath = path.join(__dirname, 'src/validators.ts');
const content = fs.readFileSync(filePath, 'utf8');

// Replace all escaped characters in regex character classes
const fixed = content
  .replace('/[\\\\s\\\\-\\\\(\\\\)]/g', '/[\\s\\-\\(\\)]/g')
  .replace('/[\\\\s-]/g', '/[\\s-]/g')
  .replace('/[-\\\\\\\\d\\\\\\\\s\\\\(\\\\)]+/', '/[-\\d\\s\\(\\)]+/');

fs.writeFileSync(filePath, fixed, 'utf8');
console.log('Fixed regex escape characters');