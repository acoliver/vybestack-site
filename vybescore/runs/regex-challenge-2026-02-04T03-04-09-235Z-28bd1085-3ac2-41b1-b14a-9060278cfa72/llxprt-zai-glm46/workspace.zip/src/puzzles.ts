/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match words starting with prefix (word boundaries)
  const regex = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');

  const matches = text.match(regex) || [];

  // Filter out exceptions and remove duplicates
  return [...new Set(matches.filter(word => !exceptions.includes(word)))];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match the digit followed by the token
  const regex = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(regex) || [];

  return matches;
}

/**
 * Validates passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let patternLen = 2; patternLen <= 4; patternLen++) {
    for (let i = 0; i <= value.length - patternLen * 2; i++) {
      const pattern = value.slice(i, i + patternLen);
      const nextPattern = value.slice(i + patternLen, i + patternLen * 2);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern to exclude
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  // First check if it looks like a pure IPv4
  const trimmed = value.trim();
  if (ipv4Pattern.test(trimmed)) {
    return false;
  }

  // IPv6 pattern - comprehensive pattern that handles:
  // - Full notation (8 groups of 1-4 hex digits)
  // - Shorthand with ::
  // - Mixed notation

  // More specific patterns for common IPv6 formats
  const patterns = [
    /(?:^|[\s(])(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:[\s)]|$)/,  // Full
    /(?:^|[\s(])(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[\s)]|$)/,                // :: at end
    /(?:^|[\s(]):(?::[0-9a-fA-F]{1,4}){1,7}(?:[\s)]|$)/,                // :: at start
    /(?:^|[\s(])(?:[0-9a-fA-F]{1,4}:){1,6}:(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}(?:[\s)]|$)/,  // :: in middle
    /(?:^|[\s(])(?:[0-9a-fA-F]{1,4}:)*:(?:[0-9a-fA-F]{1,4}:)*(?:[\s)]|$)/,  // Any ::
    /(?:^|[\s(])2001:(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}(?:[\s)]|$)/,  // 2001::/32 style
  ];

  // Check any pattern matches
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }

  // Check for common IPv6 patterns with :: shorthand
  if (/::/.test(value) && /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/.test(value)) {
    // Make sure it's not just random colons
    if (value.includes(':') && /[0-9a-fA-F]/.test(value)) {
      return true;
    }
  }

  // Check for full IPv6 pattern embedded in text
  const embeddedMatch = value.match(/(?:^|[\s(])([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/);
  if (embeddedMatch) {
    // Verify it has at least 3 colons (minimum for IPv6)
    const candidate = embeddedMatch[0].replace(/^[\s(]+/, '');
    if ((candidate.match(/:/g) || []).length >= 2) {
      return true;
    }
  }

  return false;
}
