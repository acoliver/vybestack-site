/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences if missing.
 * Collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around sentence boundaries
  // Add space after .?! if missing (unless followed by another punctuation)
  let normalized = text.replace(/([.!?])([a-zA-Z])/g, '$1 $2');

  // Collapse multiple spaces into single space
  normalized = normalized.replace(/[ \t]+/g, ' ');

  // Capitalize first character of string
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);

  // Capitalize after sentence boundaries .?!
  // But avoid capitalizing after known abbreviations
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'eg', 'ie', 'St', 'Ave'];

  let result = normalized;
  let position = 0;

  while (position < result.length) {
    // Find next sentence end
    const match = result.slice(position).match(/[.!?]\s+([a-z])/);
    if (!match) break;

    const endIndex = position + match.index! + match[0].length - 1;
    const capitalChar = match[1].toUpperCase();

    // Check if this might be an abbreviation
    const beforePunctuation = result.slice(Math.max(0, position + match.index! - 3), position + match.index!);
    const isAbbreviation = abbreviations.some(abbr => beforePunctuation.endsWith(abbr));

    if (!isAbbreviation) {
      result = result.slice(0, endIndex) + capitalChar + result.slice(endIndex + 1);
    }

    position = endIndex;
  }

  return result;
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  // Matches http://, https://, and www. URLs
  // Excludes trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"{}|[\]^`]+?(?=[).,;!?:]*(?:\s|$|<|"|'))/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing dots, commas, semicolons, colons, exclamation, question marks, parentheses
    return url.replace(/[).,;!?:]+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Replaces http:// with https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs.
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Capture groups: scheme, full URL, path including /docs/
  const urlPattern = /(https?):\/\/([^/\s]+)(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https';

    // Check if we should rewrite the host
    // Conditions for host rewrite:
    // 1. Path starts with /docs/
    // 2. No dynamic hints in path (cgi-bin, ?, &, =, .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
    const shouldRewriteHost = path && path.startsWith('/docs/') &&
      !/\/cgi-bin\/|[?&=]|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);

    if (shouldRewriteHost) {
      // Extract the main domain (e.g., example.com from subdomain.example.com)
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const mainDomain = domainParts.slice(-2).join('.');
        const newHost = `docs.${mainDomain}`;
        return `${newScheme}://${newHost}${path}`;
      }
    }

    // Just upgrade the scheme
    return `${newScheme}://${host}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  return year;
}
