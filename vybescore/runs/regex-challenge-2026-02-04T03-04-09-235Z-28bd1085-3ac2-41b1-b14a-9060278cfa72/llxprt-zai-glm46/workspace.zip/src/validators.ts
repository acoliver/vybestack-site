export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant simplified email regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  // Additional checks for specific rejection criteria
  if (!emailRegex.test(value)) {
    return false;
  }

  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }

  // Reject trailing dot in domain
  if (value.endsWith('.')) {
    return false;
  }

  // Reject leading dot in local part
  if (value.startsWith('.')) {
    return false;
  }

  // Reject underscores in domain
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }

  // Ensure domain has at least one dot and valid TLD
  if (!domainPart || !domainPart.includes('.') || domainPart.split('.').pop()!.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + for validation
  const cleaned = value.replace(/[^\d+]/g, '');

  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    // Could be country code 1 at start
    digits = digits.slice(1);
  }

  // Must have exactly 10 digits for US number
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Check if original matches common US phone formats
  // Formats: (XXX) XXX-XXXX, XXX-XXX-XXXX, XXXXXXXXX, +1 XXX-XXX-XXXX
  const usPhoneRegex = /^\+?1?\s*\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})$/;

  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Argentine phone regex
  // Optional +54 or 54
  // Optional trunk prefix 0 immediately before area code when country code is present
  // Optional mobile indicator 9 between country/trunk and area code
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:(?:\+?54)?0?|0)(9)?(\d{2,4})(\d{6,8})$/;

  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, , areaCode, subscriberNumber] = match;

  // Area code must be 2-4 digits with leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }

  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }

  // When country code is omitted, must begin with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }

  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Name regex: unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Reject if contains digits (basic check)
  if (/\d/.test(value)) {
    return false;
  }

  // Check for excessive symbols (more apostrophes/hyphens than letters seems suspicious)
  const symbolCount = (value.match(/['-]/g) || []).length;
  const letterCount = (value.match(/[\p{L}]/gu) || []).length;
  if (symbolCount > letterCount) {
    return false;
  }

  // Cannot be empty or only spaces
  if (value.trim().length === 0) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');

  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{2}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12}$/;

  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const isValidFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
