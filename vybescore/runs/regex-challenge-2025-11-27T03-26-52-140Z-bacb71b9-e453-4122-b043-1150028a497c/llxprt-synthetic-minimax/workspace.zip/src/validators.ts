export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex pattern
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots
  if (value.includes('..')) return false;
  
  // Check for trailing dots
  if (value.endsWith('.')) return false;
  
  // Check for domain with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const _options = options; // Parameter kept for API compatibility
  
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length (should be 10 or 11 with +1)
  if (digitsOnly.length < 10) return false;
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  if (digitsOnly.length > 11) return false;
  
  // If 11 digits and starts with 1, that's the country code - remove it
  let areaCode, exchangeCode, number;
  if (digitsOnly.length === 11) {
    areaCode = digitsOnly.substring(1, 4);
    exchangeCode = digitsOnly.substring(4, 7);
    number = digitsOnly.substring(7);
  } else {
    areaCode = digitsOnly.substring(0, 3);
    exchangeCode = digitsOnly.substring(3, 6);
    number = digitsOnly.substring(6);
  }
  
  // Check area code (first digit cannot be 0 or 1 for NANP)
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check exchange code (first digit cannot be 0 or 1)
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Check number is valid
  if (number.length !== 4) return false;
  
  // Check all parts are digits
  if (!/^\d+$/.test(areaCode) || !/^\d+$/.test(exchangeCode) || !/^\d+$/.test(number)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation with comprehensive format support.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove common separators (spaces, hyphens, parentheses)
let cleaned = value.replace(/[\s()\[\].-]/g, "");
  
  // Check if empty after cleaning
  if (!cleaned.trim()) return false;
  
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  let hasMobileIndicator = false;
  
  // Check for country code +54
  if (cleaned.startsWith('+54')) {
    hasCountryCode = true;
    cleaned = cleaned.substring(3); // Remove country code
  }
  
  // Check for mobile indicator 9
  if (cleaned.startsWith('9')) {
    hasMobileIndicator = true;
    cleaned = cleaned.substring(1); // Remove mobile indicator
  }
  
  // Check for trunk prefix 0
  if (cleaned.startsWith('0')) {
    hasTrunkPrefix = true;
    cleaned = cleaned.substring(1); // Remove trunk prefix
  }
  
  // Now we should have area code + subscriber number
  if (cleaned.length < 8 || cleaned.length > 10) return false;
  
  // Area code should be 2-4 digits, first digit 1-9
  let areaCodeLength;
  if (hasCountryCode && !hasTrunkPrefix) {
    // If country code but no trunk prefix, expect mobile format (9 after country)
    if (hasMobileIndicator) {
      areaCodeLength = cleaned.length >= 8 ? 2 : 0; // For mobile, area code is short
      if (areaCodeLength === 0) return false;
    } else {
      // Without mobile indicator, this might be landline with country code
      areaCodeLength = Math.min(4, cleaned.length - 6);
      if (areaCodeLength < 2) return false;
    }
  } else {
    // Without country code, should start with trunk prefix
    areaCodeLength = Math.min(4, cleaned.length - 6);
    if (areaCodeLength < 2) return false;
  }
  
  const areaCode = cleaned.substring(0, areaCodeLength);
  const subscriberNumber = cleaned.substring(areaCodeLength);
  
  // Validate area code (first digit 1-9)
  if (!/^[1-9]\d*$/.test(areaCode)) return false;
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Validate subscriber number (should be 6-8 digits total after area code)
  if (!/^\d+$/.test(subscriberNumber)) return false;
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // If has mobile indicator, should not have trunk prefix
  if (hasMobileIndicator && hasTrunkPrefix) return false;
  
  return true;
}

/**
 * TODO: Implement name validation with Unicode support.
 */
export function isValidName(value: string): boolean {
  if (!value || !value.trim()) return false;
  
  // Reject if it contains digits
  if (/\d/.test(value)) return false;
  
  // Reject if it contains symbols other than apostrophes, hyphens, and spaces
  // Allow Unicode letters, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!nameRegex.test(value)) return false;
  
  // Reject names that start or end with special characters (except spaces)
  const trimmed = value.trim();
  if (/^[''\-\s]/.test(trimmed) || /[''\-\s]$/.test(trimmed)) return false;
  
  // Reject sequences like "X Æ A-12" style names by checking for unusual character combinations
  if (/(^|[^A-Za-z\s])[ÆØÅ]/.test(value)) return false;
  if (/\b[A-Z]\s*[ÆØÅ]/.test(value)) return false;
  if (/\b[A-Z]\s*[a-z]+\s*[A-Z]\s*[0-9]/.test(value)) return false;
  if (/[A-Z]\s*[a-z]+\s*[A-Z]\s*[0-9]/.test(value)) return false;
  
  // Allow legitimate unicode characters but reject computer-generated looking names
  if (/\b[A-Z]{2,}\s*[a-z]+\s*[0-9]+/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Implement credit card validation with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length (Visa: 13, 16, 19; Mastercard: 16; AmEx: 15)
  const length = cleaned.length;
  if (length < 13 || length > 19) return false;
  
  // Check prefix based on card type
  const firstDigit = cleaned[0];
  const firstTwoDigits = parseInt(cleaned.substring(0, 2));
  const firstThreeDigits = parseInt(cleaned.substring(0, 3));
  const firstFourDigits = parseInt(cleaned.substring(0, 4));
  const firstSixDigits = parseInt(cleaned.substring(0, 6));
  
  let isValidPrefix = false;
  
  // Visa: starts with 4
  if (firstDigit === '4') {
    isValidPrefix = (length === 13 || length === 16 || length === 19);
  }
  // Mastercard: starts with 51-55 or 2221-2720
  else if (firstTwoDigits >= 51 && firstTwoDigits <= 55) {
    isValidPrefix = (length === 16);
  }
  else if (firstFourDigits >= 2221 && firstFourDigits <= 2720) {
    isValidPrefix = (length === 16);
  }
  // AmEx: starts with 34 or 37
  else if (firstTwoDigits === 34 || firstTwoDigits === 37) {
    isValidPrefix = (length === 15);
  }
  // Discover: starts with 6011, 65, or 644-649
  else if (firstFourDigits === 6011 || firstTwoDigits === 65 || 
           (firstThreeDigits >= 644 && firstThreeDigits <= 649)) {
    isValidPrefix = (length === 16);
  }
  // JCB: starts with 3528-3589
  else if (firstFourDigits >= 3528 && firstFourDigits <= 3589) {
    isValidPrefix = (length === 16);
  }
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}