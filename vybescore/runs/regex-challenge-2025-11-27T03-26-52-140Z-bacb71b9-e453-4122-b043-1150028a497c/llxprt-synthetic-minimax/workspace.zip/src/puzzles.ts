/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with the prefix
  // Word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const matches: string[] = [];
  const escapedToken = escapeRegExp(token);
  
  // Find token that appears after a digit but not at the start of string
  // Using positive lookbehind to ensure it's after a digit and capture the full sequence
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  let match;
  while ((match = regex.exec(text)) !== null) {
    // Get the full match including the digit before the token
    const startIndex = match.index - 1;
    const endIndex = match.index + token.length;
    matches.push(text.substring(startIndex, endIndex));
  }
  
  return matches;
}

/**
 * Helper function to escape special regex characters
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Validate strong password requirements.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences like "abab", "123123", etc.
  // This regex looks for any pattern that repeats immediately
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this looks like IPv4 addresses only (d.d.d.d format)
  // If it matches IPv4 pattern exactly, it's not IPv6
  const ipv4Pattern = /^\s*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\s*$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns: look for colons and hex digits (excluding simple port patterns)
  // IPv6 addresses contain colons and typically have multiple hex digits
  // They may also contain :: shorthand notation
  const ipv6Pattern = /([0-9a-fA-F]*:[0-9a-fA-F]*|[0-9a-fA-F]*::[0-9a-fA-F]*)/;
  
  // Check for IPv6 pattern and ensure it has proper IPv6 structure
  const match = value.match(ipv6Pattern);
  if (!match) return false;
  
  const ipv6Candidate = match[0];
  
  // Must have at least one colon to be IPv6
  if (!ipv6Candidate.includes(':')) return false;
  
  // Should not be just a single colon or malformed
  if (ipv6Candidate.split(':').length < 2) return false;
  
  // If it's a simple IPv4 address with colon (like port), reject
  const simpleIPv4WithPort = /^\d+\.\d+\.\d+\.\d+:\d+$/;
  if (simpleIPv4WithPort.test(value)) return false;
  
  return true;
}