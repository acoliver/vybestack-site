/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Normalize whitespace: replace multiple spaces with single space
  const result = text.replace(/\s+/g, ' ').trim();
  
  // Split into sentences using regex that looks for sentence endings followed by whitespace or end
  const sentences = result.split(/([.!?]+\s+)/);
  
  let capitalized = '';
  for (let i = 0; i < sentences.length; i++) {
    let sentence = sentences[i];
    
    // If this is a sentence content (not punctuation)
    if (sentence && !/^[.!?]+\s*$/.test(sentence)) {
      // Capitalize first letter
      sentence = sentence.replace(/^([a-z])/, (match, p1) => p1.toUpperCase());
    }
    
    capitalized += sentence;
  }
  
  return capitalized || text;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http, https, and www URLs
  const urlRegex = /\b(?:https?:\/\/www\.|https?:\/\/|www\.)[^\s]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * TODO: Replace http:// schemes with https:// while leaving secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite docs URLs according to the specific requirements.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^\/\s]+)\/docs\/([^\s]*)/g, (match, domain, path) => {
    // Check for dynamic hints that should skip host rewrite
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    
    if (hasDynamicHints) {
      // Still upgrade to https but keep original domain
      return `https://${domain}/docs/${path}`;
    } else {
      // Rewrite host to docs.domain.com and upgrade scheme
      return `https://docs.${domain}/docs/${path}`;
    }
  });
}

/**
 * TODO: Extract the four-digit year from mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, with month-specific validation)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simplified validation
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}