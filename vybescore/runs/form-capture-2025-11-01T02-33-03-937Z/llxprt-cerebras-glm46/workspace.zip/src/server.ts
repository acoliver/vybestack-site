import express, { Request, Response, Express } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
    firstName: string;
    lastName: string;
    streetAddress: string;
    city: string;
    stateProvince: string;
    postalCode: string;
    country: string;
    email: string;
    phone: string;
}

interface ValidationError {
    field: string;
    message: string;
}

import { Database as SqlJsDatabase } from 'sql.js';

class FormServer {
    private app: Express;
    private port: number;
    private db: SqlJsDatabase | null = null;
    private server: ReturnType<typeof this.app.listen> | null = null;

    constructor() {
        this.app = express();
        this.port = Number(process.env.PORT) || 3000;
        this.setupMiddleware();
        this.setupRoutes();
        this.setupGracefulShutdown();
    }

    private setupMiddleware(): void {
        this.app.use(express.urlencoded({ extended: true }));
        this.app.use(express.json());
        this.app.use('/public', express.static(path.join(__dirname, '../public')));
        this.app.set('view engine', 'ejs');
        this.app.set('views', path.join(__dirname, 'templates'));
    }

    private async initializeDatabase(): Promise<void> {
        const SQL = await initSqlJs();
        const dataPath = path.join(__dirname, '../data/submissions.sqlite');
        
        // Create data directory if it doesn't exist
        const dataDir = path.dirname(dataPath);
        if (!fs.existsSync(dataDir)) {
            fs.mkdirSync(dataDir, { recursive: true });
        }

        // Initialize database
        if (fs.existsSync(dataPath)) {
            const fileBuffer = fs.readFileSync(dataPath);
            this.db = new SQL.Database(fileBuffer);
        } else {
            this.db = new SQL.Database();
            const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf-8');
            this.db.run(schema);
            this.saveDatabase(dataPath);
        }
    }

    private saveDatabase(dataPath: string): void {
        if (!this.db) {
            throw new Error('Database not initialized');
        }
        const data = this.db.export();
        fs.writeFileSync(dataPath, Buffer.from(data));
    }

    private validateForm(formData: Partial<FormData>): ValidationError[] {
        const errors: ValidationError[] = [];

        // Required field validation
        const requiredFields: (keyof FormData)[] = [
            'firstName', 'lastName', 'streetAddress', 'city', 
            'stateProvince', 'postalCode', 'country', 'email', 'phone'
        ];

        requiredFields.forEach(field => {
            if (!formData[field] || formData[field]!.trim() === '') {
                errors.push({
                    field,
                    message: `${field.charAt(0).toUpperCase() + field.slice(1).replace(/([A-Z])/g, ' $1')} is required.`
                });
            }
        });

        // Email validation
        if (formData.email && formData.email.trim() !== '') {
            const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(formData.email)) {
                errors.push({
                    field: 'email',
                    message: 'Please enter a valid email address.'
                });
            }
        }

        // Phone validation - accept international formats
        if (formData.phone && formData.phone.trim() !== '') {
            const phoneRegex = /^[+]?[0-9\s\-()]+$/;
            if (!phoneRegex.test(formData.phone) || formData.phone.replace(/[^\d+]/g, '').length < 7) {
                errors.push({
                    field: 'phone',
                    message: 'Please enter a valid phone number (minimum 7 digits, accepts international formats).'
                });
            }
        }

        // Postal code validation - accept alphanumeric
        if (formData.postalCode && formData.postalCode.trim() !== '') {
            const postalRegex = /^[A-Za-z0-9\s-]+$/;
            if (!postalRegex.test(formData.postalCode)) {
                errors.push({
                    field: 'postalCode',
                    message: 'Please enter a valid postal/zip code.'
                });
            }
        }

        return errors;
    }

    private setupRoutes(): void {
        // GET / - render form
        this.app.get('/', (req: Request, res: Response) => {
            res.render('form', {
                errors: [],
                values: {}
            });
        });

        // POST /submit - handle form submission
        this.app.post('/submit', (req: Request, res: Response) => {
            const formData: Partial<FormData> = {
                firstName: req.body.firstName?.trim() || '',
                lastName: req.body.lastName?.trim() || '',
                streetAddress: req.body.streetAddress?.trim() || '',
                city: req.body.city?.trim() || '',
                stateProvince: req.body.stateProvince?.trim() || '',
                postalCode: req.body.postalCode?.trim() || '',
                country: req.body.country?.trim() || '',
                email: req.body.email?.trim() || '',
                phone: req.body.phone?.trim() || ''
            };

            const errors = this.validateForm(formData);

            if (errors.length > 0) {
                // Render form with errors and original values
                res.status(400).render('form', {
                    errors: errors.map(e => e.message),
                    values: formData
                });
                return;
            }

            // Insert into database
            if (!this.db) {
                throw new Error('Database not initialized');
            }

            try {
                const stmt = this.db.prepare(`
                    INSERT INTO submissions 
                    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                `);
                
                stmt.run([
                    formData.firstName!,
                    formData.lastName!,
                    formData.streetAddress!,
                    formData.city!,
                    formData.stateProvince!,
                    formData.postalCode!,
                    formData.country!,
                    formData.email!,
                    formData.phone!
                ]);
                
                stmt.free();
                
                // Save database to disk
                this.saveDatabase(path.join(__dirname, '../data/submissions.sqlite'));
                
                // Redirect to thank you page
                res.redirect('/thank-you');
            } catch (error) {
                console.error('Database error:', error);
                res.status(500).render('form', {
                    errors: ['An error occurred while saving your submission. Please try again.'],
                    values: formData
                });
            }
        });

        // GET /thank-you - render thank you page
        this.app.get('/thank-you', (req: Request, res: Response) => {
            // Get the most recent submission to extract the first name
            if (!this.db) {
                res.render('thank-you', { firstName: 'friend' });
                return;
            }

            try {
                const result = this.db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
                const firstName = result[0]?.values[0]?.[0] || 'friend';
                
                res.render('thank-you', { firstName });
            } catch (error) {
                console.error('Error fetching submission:', error);
                res.render('thank-you', { firstName: 'friend' });
            }
        });
    }

    private setupGracefulShutdown(): void {
        const shutdown = (signal: string) => {
            console.log(`\nReceived ${signal}. Shutting down gracefully...`);
            
            if (this.server) {
                this.server.close(() => {
                    console.log('HTTP server closed.');
                });
            }
            
            if (this.db) {
                try {
                    this.db.close();
                    console.log('Database closed.');
                } catch (error) {
                    console.error('Error closing database:', error);
                }
            }
            
            process.exit(0);
        };

        process.on('SIGTERM', () => shutdown('SIGTERM'));
        process.on('SIGINT', () => shutdown('SIGINT'));
    }

    public async start(): Promise<void> {
        try {
            await this.initializeDatabase();
            console.log('Database initialized successfully.');
            
            this.server = this.app.listen(this.port, () => {
                console.log(`Server running on port ${this.port}`);
            });
        } catch (error) {
            console.error('Failed to start server:', error);
            process.exit(1);
        }
    }
}

// Start the server
const formServer = new FormServer();
formServer.start().catch((error) => {
    console.error('Failed to start application:', error);
    process.exit(1);
});