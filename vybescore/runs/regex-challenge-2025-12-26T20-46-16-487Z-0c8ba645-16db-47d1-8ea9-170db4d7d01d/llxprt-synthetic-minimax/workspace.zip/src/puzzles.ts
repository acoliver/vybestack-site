/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for words starting with the prefix
  // Word boundary ensures we match complete words, include unicode letters
  const pattern = new RegExp(`\\b${prefix}[\\w]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exception words
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches.filter(match => {
    const word = match.toLowerCase();
    return !exceptionsSet.has(word);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Strategy: find all instances of the token and check the context
  const results: string[] = [];
  
  // Use regex to find token and capture its position
  const tokenRegex = new RegExp(token, 'g');
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    const matchIndex = match.index;
    
    // Check if token is at the beginning of the string
    if (matchIndex === 0) {
      continue; // Skip tokens at the start
    }
    
    // Check if there's a digit immediately before the token
    if (matchIndex > 0 && /\d/.test(text[matchIndex - 1])) {
      // Return the token with its preceding digit
      results.push(text[matchIndex - 1] + token);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // One uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // One lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // One digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // One symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // Check for patterns like abab, 1212, etc. - 2, 3, or 4 character sequences that repeat immediately
  if (/([A-Za-z0-9]{2,4})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude IPv4 addresses by checking for dotted decimal pattern
  if (/\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(value)) {
    return false;
  }
  
  // IPv6 address patterns
  // Standard IPv6: 8 groups of 4 hex digits separated by colons
  const standardIPv6 = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/;
  
  // IPv6 with shorthand using :: (compresses consecutive groups of zeros)
  const shorthandIPv6 = /\b(?:[a-fA-F0-9]{1,4}:)*::(?:[a-fA-F0-9]{1,4}:)*[a-fA-F0-9]{0,4}\b/;
  
  // Mixed patterns to catch various IPv6 formats
  const mixedIPv6 = /\b[a-fA-F0-9]{0,4}:[a-fA-F0-9]{0,4}:[a-fA-F0-9]{0,4}\b/;
  
  // Check for IPv6 patterns in the string
  if (standardIPv6.test(value) || shorthandIPv6.test(value) || mixedIPv6.test(value)) {
    return true;
  }
  
  // Additional check for shorthand formats like ::1, ::ffff, etc.
  if (/::/.test(value) && /[a-fA-F0-9]/.test(value)) {
    return true;
  }
  
  return false;
}
