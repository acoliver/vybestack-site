/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces
  const processed = text.replace(/\s+/g, ' ');
  
  // Split into sentences (after . ? !)
  const sentences = processed.split(/([.!?]+)\s*/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    if (sentence.match(/[.!?]+/)) {
      // This is punctuation, just add it
      result += sentence;
      capitalizeNext = true;
      // Add space after punctuation if there are more sentences
      if (i < sentences.length - 1) {
        result += ' ';
      }
    } else if (sentence.trim()) {
      // This is actual text
      if (capitalizeNext) {
        result += sentence.charAt(0).toUpperCase() + sentence.substring(1);
        capitalizeNext = false;
      } else {
        result += sentence;
      }
    }
  }
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern to match http(s):// URLs
  const urlRegex = /https?:\/\/[^\s<>"'()`]+[^\s<>"'()`.,!?;)]*[^\s<>"'()`.,!?;)]/g;
  
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return urls.map(url => {
    // Remove trailing punctuation but preserve the URL
    return url.replace(/[.,!?;)]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// untouched
  // Use two-step replacement to avoid conflicts
  return text.replace(/https:\/\//g, '___temp___').replace(/http:\/\//g, 'https://').replace(/___temp___/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match HTTP URLs
  const httpUrlPattern = /http:\/\/([^/\s]+)([^\s]*)/g;
  
  return text.replace(httpUrlPattern, (match, host, path) => {
    const newHost = host;
    const newPath = path;
    
    // Check if path begins with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should skip host rewrite
      const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.hostname (keeping original domain)
        const parts = host.split('.');
        if (parts.length >= 2) {
          // If host has parts like example.com, make it docs.example.com
          const domain = parts.slice(-2).join('.');
          const rewrittenHost = `docs.${domain}`;
          return `https://${rewrittenHost}${newPath}`;
        }
      }
    }
    
    // Always upgrade scheme to https
    return `https://${newHost}${newPath}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1]);
  const day = parseInt(dateMatch[2]);
  const year = parseInt(dateMatch[3]);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, more strict validation)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic validation for month-day combinations (not accounting for leap years exactly)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simplified
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year.toString();
}
