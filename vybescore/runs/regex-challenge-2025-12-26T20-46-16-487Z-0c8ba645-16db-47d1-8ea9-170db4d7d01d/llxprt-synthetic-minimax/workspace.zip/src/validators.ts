export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  value = value.trim();
  
  // Basic pattern for email validation
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]*@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for common invalid patterns
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot in domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain (but allowed in local part)
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Must have at least 2 characters in TLD
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  let cleanValue = value.trim();
  
  // Check if it starts with +1
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.substring(2);
  }
  
  // Remove all non-digits
  const digitsOnly = cleanValue.replace(/\D/g, '');
  
  // US phone numbers must be exactly 10 digits
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Additional check for valid exchange code (digits 4-6)
  const exchangeCode = digitsOnly.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  // Simple pattern matching for common formats
  const patterns = [
    /^\([2-9][0-8][0-9]\)\s?[2-9][0-9]{2}\s?[0-9]{4}$/, // (212) 555-7890
    /^[2-9][0-8][0-9]\s?[.-]?[2-9][0-9]{2}\s?[.-]?[0-9]{4}$/, // 212-555-7890
    /^[2-9][0-8][0-9][2-9][0-9]{2}[0-9]{4}$/, // 2125557890
    /^\+1\s?[2-9][0-8][0-9]\s?[.-]?[2-9][0-9]{2}\s?[.-]?[0-9]{4}$/, // +1 variants
  ];
  
  // Test against original value
  return patterns.some(pattern => pattern.test(value.trim()));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and whitespace
  const cleanValue = value.replace(/[\s.-]/g, '');
  
  // Check if it starts with optional country code +54
  let remaining = cleanValue;
  if (remaining.startsWith('+54')) {
    remaining = remaining.substring(3);
  }
  
  // Check for mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Check for trunk prefix 0
  let hasTrunkPrefix = false;
  if (remaining.startsWith('0')) {
    hasTrunkPrefix = true;
    remaining = remaining.substring(1);
  }
  
  // If no country code, must have trunk prefix
  if (!cleanValue.startsWith('+54') && !hasTrunkPrefix) {
    return false;
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = remaining.match(/^([1-9][0-9]{0,2})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const remainingAfterArea = remaining.substring(areaCode.length);
  
  // The subscriber number must contain 6-8 total digits
  if (remainingAfterArea.length < 6 || remainingAfterArea.length > 8) {
    return false;
  }
  
  // Check all remaining characters are digits
  if (!/^[0-9]+$/.test(remainingAfterArea)) {
    return false;
  }
  
  // Area code length validation (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if value is empty or only whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Must start with a unicode letter (not digit or symbol)
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}](?:[\p{L}\p{M}'\-\s]*[\p{L}])?$/u;
  
  // Additional check: reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Additional check: reject symbols other than apostrophes and hyphens
  if (/[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  return nameRegex.test(value.trim());
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const cleanValue = value.replace(/[\s|-]/g, '');
  
  // Must be all digits
  if (!/^[0-9]+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: 16 digits starting with 4
  if (cleanValue.startsWith('4') && cleanValue.length === 16) {
    return runLuhnCheck(cleanValue);
  }
  
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  if ((cleanValue.startsWith('51') || cleanValue.startsWith('52') || 
       cleanValue.startsWith('53') || cleanValue.startsWith('54') || 
       cleanValue.startsWith('55')) &&
       cleanValue.length === 16) {
    return runLuhnCheck(cleanValue);
  }
  
  // Additional Mastercard pattern for 2221-2720
  if (cleanValue.length === 16) {
    const prefix = parseInt(cleanValue.substring(0, 4));
    if ((prefix >= 2221 && prefix <= 2720)) {
      return runLuhnCheck(cleanValue);
    }
  }
  
  // AmEx: 15 digits starting with 34 or 37
  if ((cleanValue.startsWith('34') || cleanValue.startsWith('37')) && cleanValue.length === 15) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}
