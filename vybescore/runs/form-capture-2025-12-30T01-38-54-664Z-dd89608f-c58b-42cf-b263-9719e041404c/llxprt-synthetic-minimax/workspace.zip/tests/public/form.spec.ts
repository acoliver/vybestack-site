import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, ChildProcess } from 'node:child_process';
import http from 'node:http';

interface ServerResponse {
  status: number;
  text: string;
  headers: Record<string, string | number | boolean>;
}

let server: ChildProcess | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server
  server = spawn('node', ['dist/server.js'], {
    env: { ...process.env, PORT: '3536' }
  });
  
  // Wait for server to start and be ready
  await new Promise((resolve) => {
    let attempts = 0;
    const maxAttempts = 20;
    
    const checkServer = () => {
      const req = http.get('http://localhost:3536', (res: http.IncomingMessage) => {
        if (res.statusCode === 200) {
          resolve(undefined);
        }
      });
      req.on('error', () => {
        attempts++;
        if (attempts < maxAttempts) {
          setTimeout(checkServer, 100);
        } else {
          resolve(undefined); // Give up and proceed
        }
      });
      req.end();
    };
    
    setTimeout(checkServer, 500); // Initial delay
  });
});

afterAll(() => {
  if (server) {
    server.kill();
  }
  
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response: ServerResponse = await request('http://localhost:3536')
      .get('/')
      .expect(200);
    
    const html = response.text;
    
    // Check for form fields
    expect(html).toContain('name="firstName"');
    expect(html).toContain('name="lastName"');
    expect(html).toContain('name="streetAddress"');
    expect(html).toContain('name="city"');
    expect(html).toContain('name="stateProvince"');
    expect(html).toContain('name="postalCode"');
    expect(html).toContain('name="country"');
    expect(html).toContain('name="email"');
    expect(html).toContain('name="phone"');
  });

  it('persists submission and redirects', async () => {
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '90210',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response: ServerResponse = await request('http://localhost:3536')
      .post('/submit')
      .send(submissionData)
      .expect(302); // Should redirect
    
    // Should redirect to thank-you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Database file should be created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
  
  it('renders thank you page', async () => {
    const response: ServerResponse = await request('http://localhost:3536')
      .get('/thank-you')
      .expect(200);
    
    const html = response.text;
    expect(html).toContain('Thank You!');
  });
});
