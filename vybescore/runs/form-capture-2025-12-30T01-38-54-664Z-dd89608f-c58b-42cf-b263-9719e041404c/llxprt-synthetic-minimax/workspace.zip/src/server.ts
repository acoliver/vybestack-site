import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

// Import sql.js with dynamic import to handle WASM
const require = createRequire(import.meta.url);
const initSqlJs = require('sql.js');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// View engine setup
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// Initialize database
let db: import('sql.js').Database | null = null;
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Check if database file exists
    const fs = await import('fs');
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
    } else {
      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      db = new SQL.Database();
      
      // Load schema
      if (db) {
        const fsModule = await import('fs');
        
        // Try multiple locations for the schema file
        const possiblePaths = [
          path.resolve(process.cwd(), 'db', 'schema.sql'),
          path.resolve(process.cwd(), 'src', 'schema.sql'),
          path.resolve(process.cwd(), 'data', 'schema.sql'),
          path.join(__dirname, '..', '..', 'db', 'schema.sql'),
          path.join(__dirname, '..', 'schema.sql')
        ];
        
        let schemaPath: string | null = null;
        for (const p of possiblePaths) {
          if (fsModule.existsSync(p)) {
            schemaPath = p;
            break;
          }
        }
        
        if (!schemaPath) {
          console.error('Schema file not found');
          process.exit(1);
        }
        
        const schema = fsModule.readFileSync(schemaPath, 'utf8');
        db.exec(schema);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;
  try {
    const fs = await import('fs');
    const binary = db.export();
    fs.writeFileSync(DB_PATH, binary);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation function
function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  }

  // Email validation (simple check)
  if (data.email && data.email.trim() !== '') {
    if (!data.email.includes('@') || !data.email.includes('.')) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone number validation (simple check)
  if (data.phone && data.phone.trim() !== '') {
    if (data.phone.length < 7 || !/[0-9]/.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (simple check)
  if (data.postalCode && data.postalCode.trim() !== '') {
    if (!/[A-Za-z0-9]/.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    title: 'Contact Form',
    errors: {},
    data: {}
  });
});

app.post('/submit', async (req, res) => {
  console.log('=== POST /submit received ===');
  console.log('Request method:', req.method);
  console.log('Request headers:', req.headers);
  console.log('Request body type:', typeof req.body);
  console.log('Request body keys:', Object.keys(req.body || {}));
  console.log('Request body:', JSON.stringify(req.body, null, 2));
  
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  console.log('Processed form data:', JSON.stringify(formData, null, 2));

  const validation = validateForm(formData);
  console.log('Validation result:', JSON.stringify(validation, null, 2));
  
  if (!validation.isValid) {
    console.log('Validation failed, sending 400 with errors:', validation.errors);
    // Re-render form with errors and preserved data
    return res.status(400).render('form', {
      title: 'Contact Form',
      errors: validation.errors,
      data: formData
    });
  }

  try {
    if (!db) {
      console.log('Database not initialized, sending 500');
      return res.status(500).render('form', {
        title: 'Contact Form',
        errors: { general: 'Database not initialized. Please try again later.' },
        data: formData
      });
    }
    
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName, 
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    await saveDatabase();
    
    console.log('Database insert successful, sending redirect');
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database insert failed:', error);
    res.status(500).render('form', {
      title: 'Contact Form',
      errors: { general: 'Failed to save your information. Please try again.' },
      data: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  
  if (db) {
    try {
      await saveDatabase();
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
});

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
