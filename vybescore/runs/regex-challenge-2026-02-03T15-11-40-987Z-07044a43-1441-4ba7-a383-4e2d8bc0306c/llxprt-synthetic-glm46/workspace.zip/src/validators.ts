export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC standards.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other clearly invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that follows standard validation patterns
  // Local part: letters, numbers, dots, hyphens, plus, apostrophes
  // but no consecutive dots and not starting/ending with dot
  // Domain part: letters, numbers, hyphens, dots
  // but not starting/ending with dot, no underscores, and at least one dot
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional check to reject domains with underscores, consecutive dots, and trailing dots
  const invalidPatterns = {
    // No underscores in domain
    domainUnderscores: /@.*_/,
    // No consecutive dots
    consecutiveDots: /\.\./,
    // No dot before @ (no local part ending with dot)
    trailingDotAt: /\.@/,
    // No dot after @ to start domain
    leadingDotDomain: /@\./,
    // No dot at end
    trailingDotDot: /\.$/,
    // No double dots in local part
    consecutiveDotsLocal: /^[^@]*\.\.[^@]*@/
  };

  // Quick length check to prevent extremely long emails
  if (value.length > 320 || value.length < 5) {
    return false;
  }

  // If basic pattern doesn't match, reject
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for invalid patterns
  const hasInvalidPattern = Object.values(invalidPatterns).some(pattern => pattern.test(value));
  
  return !hasInvalidPattern;
}

/**
 * Validates US phone numbers with common separators and optional +1 country code.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if valid length (10 digits standard, 11 if starting with 1)
  const validLengths = [10, 11];
  if (!validLengths.includes(digitsOnly.length)) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract area code and check if valid (not starting with 0 or 1)
  const areaCodeStart = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(areaCodeStart, areaCodeStart + 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Main regex validation for format
  // Accepts: (212) 555-7890, 212-555-7890, 212.555.7890, 212 555 7890, 2125557890
  // With optional +1 prefix
  const usPhoneRegex = /^\+?1?\s*\(?(\d{3})\)?[\s.-]?(\d{3})[\s.-]?(\d{4})$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers including landlines and mobiles.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9,
 * area code 2-4 digits (leading digit 1-9), subscriber number 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize input by removing spaces and hyphens but keeping structure validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check if it starts with country code or trunk prefix when country code is omitted
  if (!normalized.startsWith('+54') && !normalized.startsWith('0')) {
    return false;
  }
  
  // Complex regex to match all valid formats:
  // [+54] [9] [2-4 digit area code] [6-8 digit subscriber]
  // or
  // 0 [2-4 digit area code] [6-8 digit subscriber] (when country code omitted)
  const argentinePhoneRegex = /^(?:\+54\s*)?(?:9\s*)?([1-9]\d{0,3})[\s-]?(\d{6,8})$|^0([1-9]\d{0,3})[\s-]?(\d{6,8})$/;
  
  // Extract parts for detailed validation
  const withCountryCodeMatch = normalized.match(/^\+54\s*(?:9\s*)?([1-9]\d{0,3})[\s-]?(\d{6,8})$/);
  const withoutCountryCodeMatch = normalized.match(/^0([1-9]\d{0,3})[\s-]?(\d{6,8})$/);
  
  if (withCountryCodeMatch) {
    const [, areaCode, subscriber] = withCountryCodeMatch;
    // Area code must be 2-4 digits
    // Subscriber must be 6-8 digits
    return areaCode.length >= 2 && areaCode.length <= 4 && 
           subscriber.length >= 6 && subscriber.length <= 8;
  }
  
  if (withoutCountryCodeMatch) {
    const [, areaCode, subscriber] = withoutCountryCodeMatch;
    // Area code must be 2-4 digits
    // Subscriber must be 6-8 digits
    return areaCode.length >= 2 && areaCode.length <= 4 && 
           subscriber.length >= 6 && subscriber.length <= 8;
  }
  
  // Basic format check with separators
  return argentinePhoneRegex.test(value);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Accepts names like José, O'Malley, Jean-Luc, but rejects digits, symbols and invalid names.
 */
export function isValidName(value: string): boolean {
  // Check for basic prohibitions
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Check for invalid characters (digits, symbols) - be more precise about what to reject
  // Reject common symbols but allow letters, spaces, apostrophes, hyphens, and accented characters
  if (/[0-9@#$%^&*()+=[\]{}|:;"'<>,.?/`~\\]/.test(value)) {
    return false;
  }
  
  // Pattern for unicode letters, marks (combining diacritics), spaces, apostrophes, and hyphens
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Check for repeated consecutive apostrophes or hyphens
  if (/'{2,}|-{2,}/.test(value)) {
    return false;
  }
  
  // Check against our regex pattern
  if (!namePattern.test(value.trim())) {
    return false;
  }
  
  // Basic sanity check: ensure there's at least one letter
  const hasLetters = /\p{L}/u.test(value);
  return hasLetters;
}

/**
 * Validates credit card numbers based on prefix, length, and Luhn checksum.
 * Accepts Visa (13 or 16 digits starting with 4), Mastercard (16 digits starting with 2221-2720 or 51-55),
 * and American Express (15 digits starting with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Check visa: 13 or 16 digits starting with 4
  const visaPattern = /^4(\d{12}|\d{15})$/;
  // Check mastercard: 16 digits starting with 2221-2720 or 51-55
  const mastercardPattern = /^(?:5[1-5]\d{14}|2(?:2[2-9]\d{12}|[3-6]\d{13}|7(?:0[01]\d{11}|[1-9]\d{12}))\d{0})\d{0}$/;
  // Check amex: 15 digits starting with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;
  
  // First validate format
  if (!visaPattern.test(digits) && !mastercardPattern.test(digits) && !amexPattern.test(digits)) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(digits);
}

/**
 * Helper function to perform Luhn checksum validation on a numeric string.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from rightmost digit
  for (let i = digits.length - 1; i >= 0; i--) {
    const digit = parseInt(digits[i], 10);
    
    if (isEven) {
      // Double every second digit from the right
      const doubled = digit * 2;
      // If the result is two digits, add them together
      const doubledDigits = doubled > 9 ? Math.floor(doubled / 10) + (doubled % 10) : doubled;
      sum += doubledDigits;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
