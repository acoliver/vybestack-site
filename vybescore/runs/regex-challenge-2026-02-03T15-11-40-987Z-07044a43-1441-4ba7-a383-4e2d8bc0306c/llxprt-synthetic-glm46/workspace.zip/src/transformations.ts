/**
 * Capitalizes the first character of each sentence in the text.
 * Handles sentence endings (.?!) and ensures exactly one space between sentences.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Replace multiple spaces with a single space
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence endings if missing
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Collapse multiple sentence-ending punctuation with spaces
  result = result.replace(/([.!?])\s+([.!?])\s+/g, '$1 ');
  
  // Capitalize first character of the text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Common abbreviations to preserve case (lowercase)
  const abbreviations = ['mr', 'mrs', 'dr', 'prof', 'sr', 'jr', 'st', ' ave', 'rd', 'blvd', 'etc', 'e.g', 'i.e'];
  
  // For each sentence delimiter - simplified approach
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, delimiter, letter, offset, fullText) => {
    // Get the text before this match
    const beforeText = fullText.substring(0, offset);
    
    // Split into words to check the last word
    const words = beforeText.split(/\s+/);
    const lastWord = words[words.length - 1] || '';
    
    // If the last word before the delimiter looks like an abbreviation, don't capitalize
    if (abbreviations.includes(lastWord.replace(/\.$/, '').toLowerCase())) {
      return delimiter + letter;
    }
    
    return delimiter + letter.toUpperCase();
  });
  
  // Capitalize after line breaks (if any remain)
  result = result.replace(/\n\s*([a-z])/g, (match, letter) => '\n' + letter.toUpperCase());
  
  // Normalize space around punctuation
  result = result.replace(/\s*([,.!?;:])\s*/g, '$1 ');
  result = result.replace(/\s+([,.!?;:])\s*/g, '$1 ');
  
  // Remove space before parentheses and brackets when appropriate
  result = result.replace(/\s+(\(|\[)/g, ' $1');
  
  // Trim trailing whitespace
  result = result.trim();
  
  return result;
}

/**
 * Extracts URLs from the given text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
// More precise regex that avoids common false positives
  const betterUrlRegex = /(?:https?:\/\/)?(?:www\.)?[-a-zA-Z0-9@:%._+~=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&=]*)/gi;
  
  const matches: string[] = [];
  
  // Find all matches
  let match;
  while ((match = betterUrlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation and common punctuation marks
    url = url.replace(/[,.;:!?)}\]]+$/, '');
    
    // Remove trailing quotes if the whole URL is wrapped in quotes
    if (url.startsWith('"') || url.startsWith("'")) {
      url = url.substring(1);
    }
    if (url.endsWith('"') || url.endsWith("'")) {
      url = url.substring(0, url.length - 1);
    }
    
    // Ensure protocol is present (add http:// if missing)
    if (!/^https?:\/\//.test(url)) {
      url = 'http://' + url;
    }
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Replaces all http:// URLs with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace all http:// URLs with https://
  // This regex finds http:// followed by a domain and other parts of the URL
  return text.replace(/http:\/\/([^\s<>"']+)(?=[\s<>"']|$)/gi, 'https://$1');
}

/**
 * Rewrites http://example.com/... URLs:
 * Always upgrades to https://
 * When path begins with /docs/, rewrites host to docs.example.com
 * Skips host rewrite for paths with dynamic hints (cgi-bin, query strings, legacy extensions)
 * Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\/example\.com\/([^\s<>"']*)/gi, 'https://example.com/$1');
  
  // Handle docs URLs - match full URL and check for rewrite
  result = result.replace(/https:\/\/example\.com(\/docs\/[^<>'"\s]*)/gi, (match, path) => {
    // Check for excluded patterns
    const excludedPatterns = [
      /\/cgi-bin\//i,
      /\?/i,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i
    ];
    
    // If any exclusion matches, don't rewrite the host
    const shouldNotRewrite = excludedPatterns.some(pattern => pattern.test(path));
    
    if (!shouldNotRewrite) {
      return `https://docs.example.com${path}`;
    }
    
    return match;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the string doesn't match the format or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format, with exact pattern
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3]; // Keep as string to return
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const maxDay = getMaxDay(month);
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to get the maximum number of days for a given month.
 */
function getMaxDay(month: number): number {
  // February (leap year not considered for this exercise)
  if (month === 2) return 28;
  // April, June, September, November have 30 days
  if (month === 4 || month === 6 || month === 9 || month === 11) return 30;
  // All others have 31 days
  return 31;
}
