/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape any special regex characters in the prefix and exceptions
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(ex => ex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  
  // Create regex pattern to match words starting with the prefix
  // \b matches word boundaries, \w* matches additional word characters
  const wordPattern = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'gi');
  
  // Find all words in text that match the pattern
  const allMatches: string[] = [];
  let match;
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    // Check if the word is not in the exceptions list
    if (!escapedExceptions.includes(word.toLowerCase())) {
      allMatches.push(word);
    }
  }
  
  // Remove duplicates (case insensitive) and return unique matches
  const uniqueWords = [...new Set(allMatches.map(w => w.toLowerCase()))];
  return uniqueWords.map(word => text.toLowerCase().includes(word) ? 
    text.match(new RegExp(`\\b${word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\b`, 'i'))?.[0] || word : 
    word);
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds for pattern matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match the digit + token combination
  // This captures both the digit and the token as one match
  const tokenPattern = new RegExp(`\\d(${escapedToken})`, 'gi');
  
  // Find all matches
  const matches: string[] = [];
  let match;
  while ((match = tokenPattern.exec(text)) !== null) {
    // Return the digit + token as one string
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates passwords according to the policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) return false; // At least one uppercase
  if (!/[a-z]/.test(value)) return false; // At least one lowercase  
  if (!/[0-9]/.test(value)) return false; // At least one digit
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>]/.test(value)) return false; // At least one symbol
  
  // Check for immediately repeated sequences
  // Pattern like abab, abcabc, etc.
  for (let i = 1; i <= value.length / 2; i++) {
    const pattern = value.substring(0, i);
    if (value.substring(i, i * 2) === pattern) {
      return false;
    }
  }
  
  // Check for immediate character repetition (aaaa)
  if (/(.)\1{3,}/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger a positive result.
 * Returns true if a valid IPv6 address is found in the text.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 pattern - includes full IPv6 notation, abbreviated notation with ::, and IPv6 addresses with embedded IPv4
  // But this should NOT match plain IPv4 addresses
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/g;
  
  // Check if IPv6 pattern is found
  // First, temporarily remove IPv4 addresses to avoid false positives
  const textWithoutIPv4 = value.replace(/\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b(?!:\d)/g, '');
  
  // Now check for IPv6 patterns
  return ipv6Regex.test(textWithoutIPv4);
}
