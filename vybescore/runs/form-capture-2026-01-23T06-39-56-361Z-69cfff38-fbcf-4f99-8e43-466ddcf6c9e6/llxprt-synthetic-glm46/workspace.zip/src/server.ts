import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Initialize Express application
const app = express();
const port = process.env.PORT || 3535;



// Global database variable
let db: Database | null = null;
const dataDir = path.join(process.cwd(), 'data');
const dbPath = path.join(dataDir, 'submissions.sqlite');

// Middleware setup
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Type definitions for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Type definitions for validation errors
interface ValidationError {
  field: string;
  message: string;
}

// Helper functions
function createDataDirectoryIfNotExists(): void {
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^[\s\d\-()]*$/;
const POSTAL_CODE_REGEX = /^[\w\s-]+$/;

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // First name validation
  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required.' });
  }

  // Last name validation
  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required.' });
  }

  // Street address validation
  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required.' });
  }

  // City validation
  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required.' });
  }

  // State/Province validation
  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required.' });
  }

  // Postal code validation
  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required.' });
  } else if (!POSTAL_CODE_REGEX.test(formData.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code contains invalid characters.' });
  }

  // Country validation
  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required.' });
  }

  // Email validation
  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required.' });
  } else if (!EMAIL_REGEX.test(formData.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address.' });
  }

  // Phone validation
  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required.' });
  } else if (!PHONE_REGEX.test(formData.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number contains invalid characters.' });
  }

  return errors;
}



function saveDbToFile(): void {
  if (db === null) return;
  
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

function cleanupDatabase(): void {
  if (db === null) return;
  
  saveDbToFile();
  db.close();
  db = null;
}

// Route handlers
function renderForm(req: Request, res: Response, errors?: string[], values?: FormData): void {
  res.render('form', {
    errors: errors || [],
    values: values || {},
  });
}

app.get('/', (req: Request, res: Response) => {
  renderForm(req, res);
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validationErrors = validateForm(formData);
  
  if (validationErrors.length > 0) {
    const errorMessages = validationErrors.map(err => err.message);
    return renderForm(req, res, errorMessages, formData);
  }

  // Save to database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDbToFile();
    
    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error saving submission:', error);
    return renderForm(req, res, ['An error occurred while saving your submission. Please try again.'], formData);
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Received SIGTERM, shutting down gracefully');
  cleanupDatabase();
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  try {
    // Initialize database
    const { Database } = await initSqlJs();
    
    createDataDirectoryIfNotExists();
    
    let dbBuffer: ArrayBuffer | null = null;
    
    if (fs.existsSync(dbPath)) {
      dbBuffer = fs.readFileSync(dbPath).buffer;
    }
    
    // Use the Database constructor from the initialized SQL module
    db = new Database(dbBuffer);
    
    // Check if the submissions table exists
    if (db === null) throw new Error('Database not initialized');
    const tableCheck = db.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='submissions'");
    
    if (tableCheck.length === 0) {
      // Read schema from file and execute
      const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
      db.exec(schema);
    }
    
    // Set up view engine
    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, 'templates'));

    // Set up SIGTERM handler for graceful shutdown
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

    // Start listening
    app.listen(port, () => {
      console.log(`Server listening on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
