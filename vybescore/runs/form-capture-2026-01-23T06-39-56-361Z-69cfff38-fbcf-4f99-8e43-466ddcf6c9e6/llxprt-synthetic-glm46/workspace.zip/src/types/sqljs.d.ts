declare module 'sql.js' {
  class Database {
    constructor(data?: ArrayBuffer | Uint8Array | null);
    exec(sql: string): ResultSet[];
    export(): Uint8Array;
    prepare(sql: string): Statement;
    run(sql: string, ...params: unknown[]): ResultSet;
    close(): void;
  }

  interface ResultSet {
    columns: string[];
    values: unknown[][];
  }

  interface Statement {
    run(...params: unknown[]): ResultSet;
    free(): void;
  }

  export default Database;
}