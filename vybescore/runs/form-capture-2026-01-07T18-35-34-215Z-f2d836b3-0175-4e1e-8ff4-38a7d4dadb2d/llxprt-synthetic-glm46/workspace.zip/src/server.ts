import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;

// Set up middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS as template engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Database setup
const dbPath = path.resolve('data', 'submissions.sqlite');
let db: import('sql.js').Database; // SQL.js Database instance

// Create directory if it doesn't exist
if (!fs.existsSync(path.dirname(dbPath))) {
  fs.mkdirSync(path.dirname(dbPath), { recursive: true });
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Initialize SQL.js
    // Use absolute path for the WASM file
    const sqlWasmPath = path.resolve('node_modules/sql.js/dist');
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(sqlWasmPath, file)
    });
    
    let data: Uint8Array;
    
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    } else {
      // Create new database in memory
      data = new Uint8Array(0);
    }
    
    // Load or create the database
    db = new SQL.Database(data);
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.resolve('db/schema.sql'), 'utf8');
    db.run(schema);
    
    // Save the database to disk to ensure it's created
    if (db) {
      const exportData = db.export();
      fs.writeFileSync(dbPath, Buffer.from(exportData));
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Validation functions
function validatePhone(phone: string): boolean {
  // Accept patterns: +44 20 7946 0958, +54 9 11 1234-5678, etc.
  // Allows digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+()\d\s-]+$/;
  return phoneRegex.test(phone) && phone.length > 5;
}

function validateEmail(email: string): boolean {
  // Simple email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric postal codes like SW1A 1AA, C1000, B1675
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!validateRequired(data.firstName)) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!validateRequired(data.lastName)) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!validateRequired(data.streetAddress)) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!validateRequired(data.city)) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!validateRequired(data.stateProvince)) {
    errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  }
  
  if (!validateRequired(data.country)) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!validateRequired(data.email)) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!validateRequired(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  if (!validateRequired(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }
  
  return errors;
}

// Save database to disk
function saveDatabase(): void {
  try {
    if (db) {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    }
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {}, title: 'Friendly Contact Form' });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    const errorMessages = errors.map(e => e.message);
    return res.status(400).render('form', { 
      errors: errorMessages, 
      values: formData 
    });
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database changes to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: ['Sorry, something went wrong. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { 
    firstName: req.query.firstName || 'friend', 
    title: 'Thank You!' 
  });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down server...');
  
  if (db) {
    try {
      saveDatabase(); // Save one last time
      db.close(); // Close database connection
      console.log('Database closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
  
  // Force shutdown if clean shutdown takes too long
  setTimeout(() => {
    console.log('Forcing shutdown');
    process.exit(1);
  }, 5000);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
let server: import('http').Server; // Server instance
  
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Server failed to start:', error);
    process.exit(1);
  }
}

startServer();
