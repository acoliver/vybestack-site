import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import http from 'http';

let server: http.Server;
const dbPath = path.resolve('data', 'submissions.sqlite');
let testApp: unknown;
const testPort = 3536;

async function makeRequest(method: string, path: string, data?: Record<string, unknown>) {
  return new Promise<http.IncomingMessage>((resolve, reject) => {
    const options: http.RequestOptions = {
      hostname: 'localhost',
      port: testPort,
      path,
      method,
      headers: {
        'Content-Type': 'application/json',
        ...(data && { 'Content-Length': Buffer.byteLength(JSON.stringify(data)) })
      }
    };

    const req = http.request(options, (res) => {
      resolve(res);
    });

    req.on('error', reject);
    
    if (data) {
      req.write(JSON.stringify(data));
    }
    req.end();
  });
}

beforeAll(async () => {
  // Clean up database file before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import the app after ensuring database is clean
  const appModule = await import('../../src/server.js');
  testApp = appModule.default;
  
  // Start the server on test port
  server = http.createServer(testApp);
  
  return new Promise<void>((resolve) => {
    server.listen(testPort, () => {
      console.log(`Test server running on port ${testPort}`);
      resolve();
    });
  });
});

afterAll(() => {
  return new Promise<void>((resolve) => {
    server.close(() => {
      console.log('Test server closed');
      resolve();
    });
  }).then(() => {
    // Clean up database after tests
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await makeRequest('GET', '/');
    expect(response.statusCode).toBe(200);
    
    const body = await new Promise<string>((resolve) => {
      let data = '';
      response.on('data', (chunk) => data += chunk);
      response.on('end', () => resolve(data));
    });
    
    // Check for all form fields
    expect(body).toContain('id="first_name"');
    expect(body).toContain('id="last_name"');
    expect(body).toContain('id="street_address"');
    expect(body).toContain('id="city"');
    expect(body).toContain('id="state_province"');
    expect(body).toContain('id="postal_code"');
    expect(body).toContain('id="country"');
    expect(body).toContain('id="email"');
    expect(body).toContain('id="phone"');
    expect(body).toContain('action="/submit"');
    expect(body).toContain('method="POST"');
  });

  it('validates required fields', async () => {
    const response = await makeRequest('POST', '/submit', {});
    expect(response.statusCode).toBe(200);
    
    const body = await new Promise<string>((resolve) => {
      let data = '';
      response.on('data', (chunk) => data += chunk);
      response.on('end', () => resolve(data));
    });
    
    // Should show error summary
    expect(body).toContain('Please fix the following errors');
  });

  it('validates email format', async () => {
    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'CA',
      postal_code: '12345',
      country: 'USA',
      email: 'invalid-email',
      phone: '+1-555-123-4567'
    };

    const response = await makeRequest('POST', '/submit', formData);
    expect(response.statusCode).toBe(200);
    
    const body = await new Promise<string>((resolve) => {
      let data = '';
      response.on('data', (chunk) => data += chunk);
      response.on('end', () => resolve(data));
    });
    
    // Should show email validation error
    expect(body).toContain('email');
  });

  it('validates phone number format', async () => {
    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'CA',
      postal_code: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '123' // Too short
    };

    const response = await makeRequest('POST', '/submit', formData);
    expect(response.statusCode).toBe(200);
    
    const body = await new Promise<string>((resolve) => {
      let data = '';
      response.on('data', (chunk) => data += chunk);
      response.on('end', () => resolve(data));
    });
    
    // Should show phone validation error
    expect(body).toContain('phone');
  });

  it('persists valid submission and redirects to thank you page', async () => {
    const formData = {
      first_name: 'Jane',
      last_name: 'Smith',
      street_address: '456 Oak Ave',
      city: 'Springfield',
      state_province: 'IL',
      postal_code: '62701',
      country: 'USA',
      email: 'jane.smith@example.com',
      phone: '+1-217-555-0123'
    };

    const response = await makeRequest('POST', '/submit', formData);
    expect(response.statusCode).toBe(302);

    // Should redirect to thank you page
    expect(response.headers.location).toBe('/thank-you');

    // Follow the redirect
    const thankYouResponse = await makeRequest('GET', '/thank-you');
    expect(thankYouResponse.statusCode).toBe(200);

    const body = await new Promise<string>((resolve) => {
      let data = '';
      thankYouResponse.on('data', (chunk) => data += chunk);
      thankYouResponse.on('end', () => resolve(data));
    });
    
    // Check thank you page content
    expect(body).toContain('success-icon');
    expect(body).toContain('Thank You');
    expect(body).toContain('Why did you give your personal information');
  });

  it('serves CSS file from public directory', async () => {
    const response = await makeRequest('GET', '/public/styles.css');
    expect(response.statusCode).toBe(200);
    expect(response.headers['content-type']).toContain('text/css');
    
    const body = await new Promise<string>((resolve) => {
      let data = '';
      response.on('data', (chunk) => data += chunk);
      response.on('end', () => resolve(data));
    });
    
    expect(body.length).toBeGreaterThan(100); // Should not be empty
  });

  it('handles international phone and postal codes', async () => {
    const formData = {
      first_name: 'José',
      last_name: 'García',
      street_address: 'Calle Mayor 123',
      city: 'Madrid',
      state_province: 'Madrid',
      postal_code: '28001',
      country: 'Spain',
      email: 'jose.garcia@ejemplo.es',
      phone: '+34 91 123 4567'
    };

    const response = await makeRequest('POST', '/submit', formData);
    expect(response.statusCode).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('provides health check endpoint', async () => {
    const response = await makeRequest('GET', '/health');
    expect(response.statusCode).toBe(200);
    expect(response.headers['content-type']).toContain('application/json');
    
    const body = await new Promise<string>((resolve) => {
      let data = '';
      response.on('data', (chunk) => data += chunk);
      response.on('end', () => resolve(data));
    });
    
    const json = JSON.parse(body);
    expect(json.status).toBe('ok');
    expect(json.timestamp).toBeDefined();
  });
});
