export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function validateSubmission(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  if (!formData.first_name.trim()) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  if (!formData.last_name.trim()) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  if (!formData.street_address.trim()) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }

  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.state_province.trim()) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }

  if (!formData.postal_code.trim()) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  }

  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }

  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Email validation
  if (formData.email.trim() && !isValidEmail(formData.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (formData.phone.trim() && !isValidPhone(formData.phone.trim())) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation
  if (formData.postal_code.trim() && !isValidPostalCode(formData.postal_code.trim())) {
    errors.push({ field: 'postal_code', message: 'Please enter a valid postal/Zip code' });
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  // Simple but effective email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Must have at least 7 digits
  const digits = phone.replace(/\D/g, '');
  return digits.length >= 7 && digits.length <= 15;
}

function isValidPostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings for international postal codes
  // UK format: SW1A 1AA, US: 12345, Argentina: C1000, B1675
  const cleaned = postalCode.replace(/\s/g, ''); // Remove spaces
  // Must be 3-10 characters long and contain only letters and digits
  return cleaned.length >= 3 && cleaned.length <= 10 && /^[A-Za-z0-9]+$/.test(cleaned);
}