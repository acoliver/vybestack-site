import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

class DatabaseService {
  private sql: SqlJsStatic | null = null;
  private db: Database | null = null;

  async initialize(): Promise<void> {
    try {
      if (!this.sql) {
        this.sql = await initSqlJs({
          locateFile: (file: string) => {
            // sql.js will look for the .wasm file in the node_modules/sql.js/dist directory
            return new URL(`../node_modules/sql.js/dist/${file}`, import.meta.url).pathname;
          }
        });
      }

      if (this.db) {
        return;
      }

      let dbBuffer: Uint8Array | undefined = undefined;
      
      // Load existing database file if it exists
      if (fs.existsSync(DB_FILE_PATH)) {
        const fileBuffer = fs.readFileSync(DB_FILE_PATH);
        dbBuffer = new Uint8Array(fileBuffer);
      }

      // Create database from buffer or empty
      this.db = new this.sql!.Database(dbBuffer);

      // Initialize schema if table doesn't exist
      this.createSchema();
    } catch (error) {
      console.error('Database initialization failed:', error);
      throw error;
    }
  }

  private createSchema(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    this.db.exec(schema);
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    // Get the last inserted row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    const id = result[0].values[0][0] as unknown as number;

    await this.save();
    return id;
  }

  async getAllSubmissions(): Promise<Submission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      SELECT id, first_name, last_name, street_address, city, state_province,
             postal_code, country, email, phone, created_at
      FROM submissions
      ORDER BY created_at DESC
    `);

    const submissions: Submission[] = [];
    while (stmt.step()) {
      const row = stmt.getAsObject() as {
        id: number;
        first_name: string;
        last_name: string;
        street_address: string;
        city: string;
        state_province: string;
        postal_code: string;
        country: string;
        email: string;
        phone: string;
        created_at: string;
      };
      submissions.push({
        id: row.id,
        first_name: row.first_name,
        last_name: row.last_name,
        street_address: row.street_address,
        city: row.city,
        state_province: row.state_province,
        postal_code: row.postal_code,
        country: row.country,
        email: row.email,
        phone: row.phone,
        created_at: row.created_at
      });
    }

    return submissions;
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Ensure data directory exists
    const dataDir = path.dirname(DB_FILE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const data = this.db.export();
    fs.writeFileSync(DB_FILE_PATH, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const db = new DatabaseService();