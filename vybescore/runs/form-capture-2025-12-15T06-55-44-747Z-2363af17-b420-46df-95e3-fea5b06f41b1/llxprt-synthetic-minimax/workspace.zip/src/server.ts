import express, { Request, Response } from 'express';
import path from 'path';
import { db } from './database.js';
import { validateSubmission } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Routes

// GET / - Display the contact form
app.get('/', async (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    formData: {},
    title: 'Contact Us - Friendly Form'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate the form data
    const errors = validateSubmission(formData);

    if (errors.length > 0) {
      // Re-render form with errors and previous values
      return res.status(200).render('form', {
        errors,
        formData,
        title: 'Contact Us - Please Correct Errors'
      });
    }

    // Submit to database
    await db.insertSubmission(formData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'An unexpected error occurred. Please try again.' }],
      formData: req.body,
      title: 'Contact Us - Error'
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', async (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You - Friendly Form'
  });
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', timestamp: new Date().toISOString() });
});

// Initialize database and start server
async function startServer() {
  try {
    await db.initialize();
    console.log('Database initialized successfully');

    const server = app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to access the form`);
    });

    // Handle graceful shutdown
    const gracefulShutdown = async (signal: string) => {
      console.log(`Received ${signal}. Starting graceful shutdown...`);
      
      server.close(async () => {
        console.log('HTTP server closed');
        await db.close();
        console.log('Database connection closed');
        process.exit(0);
      });

      // Force close after 30 seconds
      setTimeout(() => {
        console.error('Could not close connections in time, forcefully shutting down');
        process.exit(1);
      }, 30000);
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();

export default app;