/**
 * Regular expression that matches valid Base64 strings (with or without padding).
 * Base64 uses: A-Z, a-z, 0-9, +, /, and optional = padding.
 * The pattern allows:
 * - Groups of 4 valid Base64 characters (standard encoded blocks)
 * - Final group of 2 characters followed by == (1 byte of data)
 * - Final group of 3 characters followed by = (2 bytes of data)
 * - Final group of 2, 3, or 4 characters without padding (3, 2, or complete bytes)
 */
const VALID_BASE64_REGEX = /^(?:[A-Za-z0-9+/]{4})*(?:[A-Za-z0-9+/]{2}(?:==)?|[A-Za-z0-9+/]{3}=?)?$/;

/**
 * Checks if a string has a length that could potentially be valid Base64.
 * Valid Base64 (after removing padding) has length 4n, 4n+2, or 4n+3.
 */
function isValidLength(str: string): boolean {
  const withoutPadding = str.replace(/=+$/, '');
  const len = withoutPadding.length;
  // Base64 encoded length must be a multiple of 4, or could be 4n+2 or 4n+3 if padding is missing
  const remainder = len % 4;
  return remainder === 0 || remainder === 2 || remainder === 3;
}

/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 * Output includes padding characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!trimmed) {
    throw new Error('Invalid Base64 input: empty string');
  }

  if (!isValidLength(trimmed)) {
    throw new Error('Invalid Base64 input: invalid length');
  }

  if (!VALID_BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for improper padding (padding characters in the middle or wrong position)
  const lastEqIndex = trimmed.lastIndexOf('=');
  if (lastEqIndex !== -1) {
    // Padding can only be at the end
    const afterPadding = trimmed.slice(lastEqIndex + 1);
    if (afterPadding.length > 0) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    // Padding must be 1 or 2 = characters
    const padding = trimmed.slice(lastEqIndex);
    if (padding.length > 2) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
  }

  const buffer = Buffer.from(trimmed, 'base64');
  
  if (buffer.length === 0 && trimmed.length > 0) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
  
  return buffer.toString('utf8');
}
