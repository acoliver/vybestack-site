import { readFileSync, writeFileSync } from 'node:fs';
import { CliOptions, ReportData, ReportFormat } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): CliOptions {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  const options: Partial<CliOptions> = { includeTotals: false };
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      const format = args[i + 1] as ReportFormat;
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}. Supported formats: markdown, text`);
      }
      options.format = format;
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      options.outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!options.format) {
    throw new Error('--format is required');
  }

  return {
    dataPath,
    format: options.format,
    outputPath: options.outputPath,
    includeTotals: options.includeTotals ?? false,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    // Validate entries
    for (const [index, entry] of data.entries.entries()) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${index}].label must be a string`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entries[${index}].amount must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function formatReport(data: ReportData, format: ReportFormat, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown.format(data, { includeTotals });
    case 'text':
      return renderText.format(data, { includeTotals });
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const options = parseArgs(args);
    
    const data = loadReportData(options.dataPath);
    const output = formatReport(data, options.format, options.includeTotals);
    
    if (options.outputPath) {
      writeFileSync(options.outputPath, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
}

main();
