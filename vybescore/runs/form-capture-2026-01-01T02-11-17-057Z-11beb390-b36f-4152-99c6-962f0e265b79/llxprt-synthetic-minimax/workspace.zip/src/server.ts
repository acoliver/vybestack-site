import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { Database } from 'sql.js';

// Use __dirname for CommonJS compatibility
const rootDir = path.resolve();

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(rootDir, 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(rootDir, 'src/views'));

// Database setup
let db: Database | null = null;

async function initializeDatabase() {
  try {
    // For CommonJS, use dynamic import with require
    const sqlJsModule = await import('sql.js');
    const initSqlJs = sqlJsModule.default;
    
    // Configure sql.js to find the WASM file
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        // sql.js needs the wasm file to be accessible
        const wasmPath = path.join(rootDir, `node_modules/sql.js/dist/${file}`);
        return wasmPath;
      }
    });
    
    // Load existing database or create new one
    const dbPath = path.join(rootDir, 'data/submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      
      // Create table from schema
      const schemaPath = path.join(rootDir, 'db/schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.exec(schema);
      
      // Ensure data directory exists
      const dataDir = path.join(rootDir, 'data');
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase() {
  if (db) {
    const dbPath = path.join(rootDir, 'data/submissions.sqlite');
    const dbBuffer = db.export();
    fs.writeFileSync(dbPath, Buffer.from(dbBuffer));
  }
}

async function closeDatabase() {
  if (db) {
    db.close();
    db = null;
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric patterns like SW1A 1AA, C1000, B1675
  const postalRegex = /^[A-Za-z0-9\s-]{3,12}$/;
  return postalRegex.test(postalCode);
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateFormData(data: FormData): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};
  
  // Required field validation
  if (!validateRequired(data.firstName)) {
    errors.firstName = 'First name is required';
  }
  if (!validateRequired(data.lastName)) {
    errors.lastName = 'Last name is required';
  }
  if (!validateRequired(data.streetAddress)) {
    errors.streetAddress = 'Street address is required';
  }
  if (!validateRequired(data.city)) {
    errors.city = 'City is required';
  }
  if (!validateRequired(data.stateProvince)) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  if (!validateRequired(data.postalCode)) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal/zip code';
  }
  if (!validateRequired(data.country)) {
    errors.country = 'Country is required';
  }
  if (!validateRequired(data.email)) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  if (!validateRequired(data.phone)) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('contact-form', {
    title: 'Contact Us',
    errors: {},
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: (req.body.firstName as string) || '',
    lastName: (req.body.lastName as string) || '',
    streetAddress: (req.body.streetAddress as string) || '',
    city: (req.body.city as string) || '',
    stateProvince: (req.body.stateProvince as string) || '',
    postalCode: (req.body.postalCode as string) || '',
    country: (req.body.country as string) || '',
    email: (req.body.email as string) || '',
    phone: (req.body.phone as string) || ''
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    // Re-render form with errors and previously entered values
    return res.status(400).render('contact-form', {
      title: 'Contact Us - Please Fix Errors',
      errors: validation.errors,
      formData
    });
  }
  
  try {
    if (!db) {
      return res.status(500).render('contact-form', {
        title: 'Contact Us - Error',
        errors: { general: 'Database not available. Please try again later.' },
        formData
      });
    }
    
    // Insert data into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank-you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('contact-form', {
      title: 'Contact Us - Error',
      errors: { general: 'Sorry, there was an error saving your information. Please try again.' },
      formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await closeDatabase();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await closeDatabase();
  process.exit(0);
});

// Start server
async function startServer() {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to see the form`);
  });
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
