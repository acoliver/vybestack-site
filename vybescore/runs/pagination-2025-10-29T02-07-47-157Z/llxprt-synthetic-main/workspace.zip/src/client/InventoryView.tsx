import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({
  currentPage,
  totalItems,
  itemsPerPage,
  hasNext,
  onPageChange
}: {
  currentPage: number;
  totalItems: number;
  itemsPerPage: number;
  hasNext: boolean;
  onPageChange: (page: number) => void;
}) {
  const hasPrevious = currentPage > 1;
  const totalPages = Math.ceil(totalItems / itemsPerPage);

  return (
    <nav aria-label="Inventory pagination">
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem' }}>
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={!hasPrevious}
          aria-label="Previous page"
          style={{ 
            marginRight: '0.5rem',
            opacity: hasPrevious ? 1 : 0.5,
            cursor: hasPrevious ? 'pointer' : 'not-allowed'
          }}
        >
          Previous
        </button>
        
        <span>
          Page {currentPage} of {totalPages || 1} ({totalItems} total items)
        </span>
        
        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={!hasNext}
          aria-label="Next page"
          style={{ 
            marginLeft: '0.5rem',
            opacity: hasNext ? 1 : 0.5,
            cursor: hasNext ? 'pointer' : 'not-allowed'
          }}
        >
          Next
        </button>
      </div>
    </nav>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={data.page}
        totalItems={data.total}
        itemsPerPage={data.limit}
        hasNext={data.hasNext}
        onPageChange={(page) => setCurrentPage(page)}
      />
    </section>
  );
}
