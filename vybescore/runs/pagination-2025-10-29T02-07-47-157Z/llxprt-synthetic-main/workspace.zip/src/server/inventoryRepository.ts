import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  // Validate pagination parameters
  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;
  
  // Get total count
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // Calculate offset correctly: (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  // Calculate hasNext correctly
  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}

export function validatePaginationParams(
  pageParam?: string,
  limitParam?: string
): { page?: number; limit?: number; errors: string[] } {
  const errors: string[] = [];
  let page: number | undefined;
  let limit: number | undefined;

  if (pageParam) {
    if (isNaN(Number(pageParam))) {
      errors.push('Page must be a number');
    } else {
      page = Number(pageParam);
      if (page <= 0) {
        errors.push('Page must be greater than 0');
      } else if (!Number.isInteger(page)) {
        errors.push('Page must be an integer');
      }
    }
  }

  if (limitParam) {
    if (isNaN(Number(limitParam))) {
      errors.push('Limit must be a number');
    } else {
      limit = Number(limitParam);
      if (limit <= 0) {
        errors.push('Limit must be greater than 0');
      } else if (!Number.isInteger(limit)) {
        errors.push('Limit must be an integer');
      } else if (limit > 100) {
        errors.push('Limit cannot exceed 100');
      }
    }
  }

  return { page, limit, errors };
}
