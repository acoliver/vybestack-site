import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  hasNext, 
  onPageChange 
}: { 
  page: number; 
  hasNext: boolean; 
  onPageChange: (newPage: number) => void;
}): JSX.Element {
  return (
    <div style={{ marginTop: '1rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
      <button 
        onClick={() => onPageChange(page - 1)}
        disabled={page === 1}
        style={{ padding: '0.5rem 1rem' }}
      >
        Previous
      </button>
      <span>Page {page}</span>
      <button 
        onClick={() => onPageChange(page + 1)}
        disabled={!hasNext}
        style={{ padding: '0.5rem 1rem' }}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  // Handle empty state
  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory items found.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        page={data.page} 
        hasNext={data.hasNext} 
        onPageChange={setCurrentPage}
      />
      <p style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: '#666' }}>
        Showing items {((data.page - 1) * data.limit) + 1}-{Math.min(data.page * data.limit, data.total)} of {data.total}
      </p>
    </section>
  );
}
