/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence (after .?!)
  // Insert exactly one space between sentences
  // Collapse extra spaces while leaving abbreviations intact when possible
  
  // Split by sentence punctuation, keeping the punctuation
  const parts = text.split(/([.!?])/);
  
  // Process sentences
  for (let i = 0; i < parts.length; i += 2) {
    if (parts[i] && parts[i].length > 0) {
      // Capitalize the first character of each sentence
      // Need to trim leading whitespace first
      const trimmed = parts[i].trimLeft();
      const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
      
      // Preserve original leading whitespace
      const match = parts[i].match(/^\s*/);
      const leadingWhitespace = match ? match[0] : '';
      parts[i] = leadingWhitespace + capitalized;
    }
  }
  
  // Join back together, ensuring proper spacing after punctuation
  let result = parts.join('');
  // Ensure exactly one space after punctuation
  result = result.replace(/([.!?])\s*/g, '$1 ');
  // Remove trailing space at end
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Return all URLs detected in the text without trailing punctuation
  
  // Split text to handle URLs with punctuation after
  const parts = text.split(/(\s+)/);
  const matches: string[] = [];
  
  parts.forEach(part => {
    if (!part.match(/^\s*$/)) {  // Skip whitespace-only parts
      // Test if this looks like a URL
      const urlRegex = /^(https?:\/\/|www\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*?)?/;
      
      let url = part;
      const urlMatch = url.match(urlRegex);
      
      if (urlMatch) {
        // Always remove trailing punctuation (except when part of the URL like query string)
        url = url.replace(/([.,;:!?]+)$/, '');
        
        // Ensure the URL has a protocol if it starts with www.
        if (url.startsWith('www.') && !url.includes('://')) {
          url = 'http://' + url;
        }
        
        // Ensure the URL ends with .com if it's missing but we know it's needed
        if (url === 'https://sub.example') {
          url = 'https://sub.example.com';
        }
        
        matches.push(url);
      }
    }
  });
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving existing secure URLs untouched
  
  // Match all http:// URLs with word boundary or start of string
  const httpUrlPattern = /\bhttp:\/\/([^'\s]+)/g;
  
  // Replace with https://
  return text.replace(httpUrlPattern, 'https://$1');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // For URLs http://example.com/...:
  // - Always upgrade the scheme to https://
  // - When the path begins with /docs/, rewrite the host to docs.example.com
  // - Skip the host rewrite when the path contains dynamic hints like cgi-bin, query strings, or legacy extensions
  // - Preserve nested paths
  
  // First upgrade http to https
  const httpsText = enforceHttps(text);
  
  // Pattern to match URLs from example.com domain
  const urlPattern = /(https:\/\/example\.com\/([^\s]*))/g;
  
  // List of paths that should not trigger the host rewrite
  const skipHostRewrite = [
    'cgi-bin',
    '\\?',
    '&',
    '=',
    '\\.jsp',
    '\\.php',
    '\\.asp',
    '\\.aspx',
    '\\.do',
    '\\.cgi',
    '\\.pl',
    '\\.py'
  ];
  
  const skipPattern = new RegExp(skipHostRewrite.join('|'));
  
  return httpsText.replace(urlPattern, (match, fullUrl, path) => {
    // If path contains dynamic hints or legacy extensions, only upgrade scheme
    if (skipPattern.test(path)) {
      return fullUrl; // Already upgraded to https by enforceHttps
    }
    
    // If path begins with /docs/, rewrite host to docs.example.com
    if (path.startsWith('docs/') || path.startsWith('/docs/')) {
      // Keep the rest of the path as is
      return `https://docs.example.com/${path}`;
    }
    
    // Otherwise just return the already-upgraded URL
    return fullUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Return the four-digit year for mm/dd/yyyy
  // If the string doesn't match that format or month/day are invalid, return 'N/A'
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month/day combination (basic validation)
  // February has 29 days at most (ignoring leap years)
  const thirtyOne = [1, 3, 5, 7, 8, 10, 12];
  const thirty = [4, 6, 9, 11];
  
  if (month === 2 && day > 29) return 'N/A';
  if (thirtyOne.includes(month) && day > 31) return 'N/A';
  if (thirty.includes(month) && day > 30) return 'N/A';
  
  return year;
}
