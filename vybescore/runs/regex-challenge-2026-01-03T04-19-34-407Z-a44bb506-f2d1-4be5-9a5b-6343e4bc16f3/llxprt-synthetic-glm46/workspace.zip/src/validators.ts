export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation with restrictions:
  // - Accept typical addresses like name+tag@example.co.uk
  // - Reject double dots, trailing dots
  // - Reject domains with underscores
  // - Reject other obviously invalid forms

  // Email regex with allowed special characters in local part
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  // Basic pattern check
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for invalid patterns
  if (value.includes('..')) return false; // Double dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // Trailing/leading dots
  if (value.includes('@.') || value.includes('.@')) return false; // Dot next to @
  if (value.split('@')[1]?.includes('_')) return false; // Underscore in domain

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Support formats like (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs

  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');

  // Check for optional +1 prefix
  const phoneDigits = digitsOnly.startsWith('1') && digitsOnly.length > 10 
    ? digitsOnly.substring(1) 
    : digitsOnly;

  // Must be exactly 10 digits
  if (phoneDigits.length !== 10) {
    return false;
  }

  // Area code can't start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Match common US phone number patterns
  const usPhoneRegex = /^(?:\+?1[-\s]?)?(?:\(([2-9]\d{2})\)|([2-9]\d{2}))[-\s]?([2-9]\d{2})[-\s]?(\d{4})$/;

  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  // - Optional country code +54
  // - Optional trunk prefix 0 immediately before the area code
  // - Optional mobile indicator 9 between country/trunk and the area code
  // - Area code must be 2-4 digits (leading digit 1-9)
  // - Subscriber number (after the area code) must contain 6-8 digits in total
  // - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
  // - Allow single spaces or hyphens as separators; ignore punctuation when validating

  // First check for common patterns first (spaces and hyphens as separators)
  const withCountryPatterns = [
    /^\+54\s9\s\d{2,4}\s\d{4,5}\s\d{4}$/,  // +54 9 XXXX YYYY ZZZZ
    /^\+54\s\d{2,4}\s\d{4,5}\s\d{4}$/,        // +54 XXXX YYYY ZZZZ
    /^\+54\s0\d{2,4}\s\d{4,5}\s\d{4}$/,      // +54 0XXXX YYYY ZZZZ
    /^\+54\s\d{2,4}\s\d{6,8}$/,              // +54 XXXX YYYYYYYY
    /^\+54\s9\s\d{2,4}\s\d{6,8}$/,          // +54 9 XXXX YYYYYYYY
    /^\+54\d{2,4}\s\d{4,5}\s\d{4}$/,        // +54XXXX YYYY ZZZZ
    /^\+54\s\d{2,4}\s\d{3}\s\d{4}$/         // +54 XXXX YYY ZZZZ (for 7-digit subscriber)
  ];
  
  const hyphenatedPatterns = [
    /^\+54-?9-?\d{2,4}-?\d{4,5}-?\d{4}$/,   // +54-9-XXXX-YYYY-ZZZZ
    /^\+54-?\d{2,4}-?\d{4,5}-?\d{4}$/,      // +54-XXXX-YYYY-ZZZZ
    /^\+54-?\d{2,4}-?\d{3}-?\d{4}$/         // +54-XXX-YYY-ZZZZ (for 7-digit subscriber)
  ];
  
  const withoutCountryPatterns = [
    /^0\d{2,4}\s\d{4,5}\s\d{4}$/,  // 0XXXX YYYY ZZZZ
    /^0\d{2,4}\s\d{6,8}$/,        // 0XXXX YYYYYYYY
    /^0\d{2,4}-?\d{4,5}-?\d{4}$/, // 0XXXX-YYYY-ZZZZ
    /^0\d{2,4}-?\d{6,8}$/,        // 0XXXX-YYYYYYYY
    /^0\d{2,4}\s\d{3}\s\d{4}$/    // 0XXXX YYY ZZZZ (for 7-digit subscriber)
  ];
  
  if (withCountryPatterns.some(pattern => pattern.test(value)) || 
      hyphenatedPatterns.some(pattern => pattern.test(value))) {
    return true;
  }
  
  if (withoutCountryPatterns.some(pattern => pattern.test(value))) {
    return true;
  }
  
  // For more complex patterns, normalize and validate structure
  const normalized = value.replace(/[-\s]/g, '');

  // Case 1: With country code +54
  if (normalized.startsWith('+54')) {
    // Match +54[0][9][areaCode][subscriberNumber]
    const withCountryCode = /^\+54(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
    const match = normalized.match(withCountryCode);
    if (match) {
      const areaCode = match[1];
      const subscriberNumber = match[2];
      
      // Area code must be 2-4 digits (leading digit 1-9 is already ensured by regex)
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      
      // Subscriber number must be 6-8 digits
      if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
      
      // Already validated with patterns above, but as fallback return true
      return true;
    }
  }
  
  // Case 2: Without country code, must start with trunk prefix 0
  // Match 0[areaCode][subscriberNumber]
  const trunkPrefix = /^0([1-9]\d{1,3})(\d{6,8})$/;
  const trunkMatch = normalized.match(trunkPrefix);
  if (trunkMatch) {
    const areaCode = trunkMatch[1];
    const subscriberNumber = trunkMatch[2];
    
    // Area code must be 2-4 digits (leading digit 1-9 is already ensured by regex)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    // Already validated with patterns above, but as fallback return true
    return true;
  }

  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Permit unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols

  // Basic name validation: must be at least 2 characters
  if (!value || value.trim().length < 2) return false;

  // Allow unicode letters, apostrophes, hyphens, spaces, and periods
  // Must contain at least one letter
  const nameRegex = /^[\p{L}]+(?:[ '\p{L}.-]*[\p{L}])*$/u;

  // Additional check to ensure we have at least one letter
  const hasLetter = /[\p{L}]/u.test(value);

  return nameRegex.test(value) && hasLetter;
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').reverse();
  let sum = 0;

  for (let i = 0; i < digits.length; i++) {
    const digit = parseInt(digits[i], 10);

    if (isNaN(digit)) return false;

    // Double every second digit (starting from the right, after the first digit)
    if (i % 2 !== 0) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Accept Visa (starts with 4, 13 or 16 digits), 
  // Mastercard (starts with 51-55, 2221-2720, 16 digits),
  // AmEx (starts with 34 or 37, 15 digits)

  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be 13-16 digits
  const digitsRegex = /^\d{13,16}$/;
  if (!digitsRegex.test(cleaned)) return false;

  // Visa, Mastercard, AmEx patterns
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{12})))$/;
  const amexRegex = /^3[47]\d{13}$/;

  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  if (!validPrefix) return false;

  // Luhn checksum
  return runLuhnCheck(cleaned);
}
