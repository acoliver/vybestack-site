/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create pattern to match words with the prefix, using word boundaries
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w*)\\b`, 'g');

  const matches = [];
  let match;

  while ((match = pattern.exec(text)) !== null) {
    const word = match[1];

    // Skip if word is in exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }

  return [...new Set(matches)]; // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where the token appears after a digit and not at the start of the string

  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Find all occurrences where token is preceded by a digit
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = [];
  let match;

  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }

  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol
  // No whitespace, no immediate repeated sequences (e.g., abab should fail)

  // Minimum length is 10
  if (value.length < 10) return false;

  // No whitespace
  if (/\s/.test(value)) return false;

  // Must have at least one uppercase, one lowercase, one digit, and one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^a-zA-Z0-9]/.test(value);

  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;

  // Check for repeated sequences (like abab, abcabc, etc.)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const repeatedPattern = new RegExp(`(.{${len}})\\1`);
    if (repeatedPattern.test(value)) return false;
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result

  // Pattern for IPv6 addresses (simplified but handles common forms)
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::[0-9a-fA-F]{0,4}|::[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::/;
  
  // Extracted IPv6 addresses
  const ipv6Matches = value.match(ipv6Pattern);
  if (!ipv6Matches) return false;
  
  // Verify matches by ensuring they contain at least one colon and hex digits
  return ipv6Matches.some(match => match.includes(':') && /[a-f0-9]/i.test(match));
}
