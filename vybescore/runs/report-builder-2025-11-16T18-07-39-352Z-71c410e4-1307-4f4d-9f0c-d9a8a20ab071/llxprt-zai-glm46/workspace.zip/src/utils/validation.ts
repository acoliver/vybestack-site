import type { ReportData } from '../types.js';
import { readFileSync } from 'node:fs';

export function loadAndValidateData(dataPath: string): ReportData {
  try {
    const fileContent = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(fileContent) as unknown;
    
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${dataPath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${dataPath}`);
    }
    throw error;
  }
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Report data must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string' || obj.title.trim() === '') {
    throw new Error('Report must have a non-empty title');
  }

  if (typeof obj.summary !== 'string' || obj.summary.trim() === '') {
    throw new Error('Report must have a non-empty summary');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Report must have an entries array');
  }

  const entries = obj.entries as unknown[];
  
  if (entries.length === 0) {
    throw new Error('Report must have at least one entry');
  }

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Entry ${i + 1} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string' || entryObj.label.trim() === '') {
      throw new Error(`Entry ${i + 1} must have a non-empty label`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Entry ${i + 1} must have a valid amount`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries.map(entry => {
      const entryObj = entry as { label: string; amount: number };
      return {
        label: entryObj.label,
        amount: entryObj.amount,
      };
    }),
  };
}