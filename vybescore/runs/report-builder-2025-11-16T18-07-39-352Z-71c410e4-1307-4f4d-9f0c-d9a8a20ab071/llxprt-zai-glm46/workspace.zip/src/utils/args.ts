import type { Format } from '../types.js';

export interface CliArgs {
  dataPath: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseFormat(format: string): Format {
  if (format === 'markdown' || format === 'text') {
    return format;
  }
  throw new Error(`Unsupported format: ${format}. Supported formats: markdown, text`);
}

export function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  
  let format: Format | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing format value after --format');
      }
      format = parseFormat(args[i]);
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing output path after --output');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required. Supported formats: markdown, text');
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}