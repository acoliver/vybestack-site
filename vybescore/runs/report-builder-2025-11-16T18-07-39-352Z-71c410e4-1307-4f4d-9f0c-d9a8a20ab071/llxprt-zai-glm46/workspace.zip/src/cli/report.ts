#!/usr/bin/env node

import { parseArgs } from '../utils/args.js';
import { loadAndValidateData } from '../utils/validation.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';
import { writeFileSync } from 'node:fs';

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));
    const data = loadAndValidateData(args.dataPath);
    
    const renderer = args.format === 'markdown' ? markdownRenderer : textRenderer;
    const output = renderer.render(data, { includeTotals: args.includeTotals });
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
