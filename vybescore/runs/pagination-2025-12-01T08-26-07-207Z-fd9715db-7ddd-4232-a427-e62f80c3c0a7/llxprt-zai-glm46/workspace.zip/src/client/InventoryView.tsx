import { useState } from 'react';
import { useInventory } from './useInventory';
import type { InventoryItem } from '../shared/types';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const { items, hasNext, total } = data;
  const hasPrevious = currentPage > 1;

  return (
    <div>
      <h2>Inventory ({total} items)</h2>
      {items.length === 0 ? (
        <p>No inventory items found.</p>
      ) : (
        <InventoryList items={items} />
      )}
      
      <div style={{ marginTop: '1rem' }}>
        <button 
          onClick={() => setCurrentPage(currentPage - 1)}
          disabled={!hasPrevious}
        >
          Previous
        </button>
        <span style={{ margin: '0 1rem' }}>
          Page {currentPage}
        </span>
        <button 
          onClick={() => setCurrentPage(currentPage + 1)}
          disabled={!hasNext}
        >
          Next
        </button>
      </div>
    </div>
  );
}