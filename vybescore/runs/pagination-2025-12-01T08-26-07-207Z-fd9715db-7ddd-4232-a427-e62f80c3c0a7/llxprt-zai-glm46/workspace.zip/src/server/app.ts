import cors from 'cors';
import express, { type Express } from 'express';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(page?: number, limit?: number): string | null {
  if (page !== undefined) {
    if (isNaN(page) || !Number.isInteger(page) || page < 1) {
      return 'Invalid page parameter: must be a positive integer';
    }
    if (page > 1000) {
      return 'Invalid page parameter: maximum allowed value is 1000';
    }
  }

  if (limit !== undefined) {
    if (isNaN(limit) || !Number.isInteger(limit) || limit < 1) {
      return 'Invalid limit parameter: must be a positive integer';
    }
    if (limit > 100) {
      return 'Invalid limit parameter: maximum allowed value is 100';
    }
  }

  return null;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    let page: number | undefined = undefined;
    let limit: number | undefined = undefined;

    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage)) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a number' });
      }
      page = parsedPage;
    }

    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit)) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a number' });
      }
      limit = parsedLimit;
    }

    const validationError = validatePaginationParams(page, limit);
    if (validationError) {
      return res.status(400).json({ error: validationError });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}