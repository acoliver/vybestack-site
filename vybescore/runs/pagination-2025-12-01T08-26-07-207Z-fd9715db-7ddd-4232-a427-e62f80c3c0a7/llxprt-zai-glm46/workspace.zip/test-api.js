import { createApp } from './src/server/app.js';
import { createDatabase } from './src/server/db.js';

const db = await createDatabase();
const app = await createApp(db);

// Test API manually
const response = await app.request('/inventory');
const data = await response.json();

console.log('API Response:');
console.log(JSON.stringify(data, null, 2));

// Test with pagination
const page2Response = await app.request('/inventory?page=2&limit=5');
const page2Data = await page2Response.json();

console.log('\nPage 2 Response:');
console.log(JSON.stringify(page2Data, null, 2));

// Test validation
const invalidResponse = await app.request('/inventory?page=0');
console.log('\nInvalid page response status:', invalidResponse.status);

const invalidLimitResponse = await app.request('/inventory?limit=101');
console.log('Invalid limit response status:', invalidLimitResponse.status);