import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  // Skip 'node' and script name
  const args = argv.slice(2);
  
  const result: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };
  
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      result.format = args[i + 1];
      i += 2;
    } else if (arg === '--output') {
      result.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
      i += 1;
    } else if (!arg.startsWith('--')) {
      // Positional argument
      result.dataFile = arg;
      i += 1;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }
  
  if (!result.dataFile) {
    throw new Error('Missing data file path');
  }
  
  if (!result.format) {
    throw new Error('Missing --format option');
  }
  
  return result;
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (string required)');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (string required)');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (array required)');
  }
  
  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    // Read and parse JSON file
    const fileContent = readFileSync(args.dataFile, 'utf-8');
    const jsonData = JSON.parse(fileContent);
    
    // Validate data
    validateReportData(jsonData);
    
    const data: ReportData = jsonData;
    const options: RenderOptions = { includeTotals: args.includeTotals };
    
    // Select formatter
    let formatter;
    switch (args.format) {
      case 'markdown':
        formatter = renderMarkdown;
        break;
      case 'text':
        formatter = renderText;
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }
    
    // Generate report
    const report = formatter.format(data, options);
    
    // Output
    if (args.output) {
      writeFileSync(args.output, report);
    } else {
      process.stdout.write(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(`Error: ${error.message}\n`);
      process.exit(1);
    } else {
      process.stderr.write('An unknown error occurred\n');
      process.exit(1);
    }
  }
}

main();