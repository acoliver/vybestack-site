#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import type { ReportData, ReportOptions } from '../types/index.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

const parseArgs = (args: string[]): CliArgs => {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      switch (arg) {
        case '--format':
          i++;
          result.format = args[i] || '';
          break;
        case '--output':
          i++;
          result.outputPath = args[i] || undefined;
          break;
        case '--includeTotals':
          result.includeTotals = true;
          break;
        default:
          throw new Error(`Unknown option: ${arg}`);
      }
    } else if (!result.inputFile) {
      result.inputFile = arg;
    }
  }

  return result;
};

const validateReportData = (data: unknown): ReportData => {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry ${i} must be an object`);
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (typeof entryRecord.label !== 'string') {
      throw new Error(`Invalid report data: entry ${i} must have a string label`);
    }
    if (typeof entryRecord.amount !== 'number') {
      throw new Error(`Invalid report data: entry ${i} must have a number amount`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as Array<{ label: string; amount: number }>
  };
};

const main = (): void => {
  try {
    const args = parseArgs(process.argv.slice(2));

    if (!args.inputFile) {
      console.error('Error: Input file path is required');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    if (!args.format) {
      console.error('Error: --format is required');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    if (!['markdown', 'text'].includes(args.format)) {
      console.error(`Error: Unsupported format: ${args.format}. Supported formats: markdown, text`);
      process.exit(1);
    }

    const inputPath = path.resolve(args.inputFile);
    
    try {
      // Don't check file existence first - let fs.readFile handle missing files
      const rawData = fs.readFileSync(inputPath, 'utf-8');
      if (!rawData) {
        console.error(`Error: Unable to read file: ${inputPath}`);
        process.exit(1);
      }
      
      const jsonData = JSON.parse(rawData);
      const reportData = validateReportData(jsonData);

      const options: ReportOptions = {
        includeTotals: args.includeTotals
      };

      let output: string;
      switch (args.format) {
        case 'markdown':
          output = renderMarkdown(reportData, options);
          break;
        case 'text':
          output = renderText(reportData, options);
          break;
        default:
          console.error(`Error: Unsupported format: ${args.format}`);
          process.exit(1);
      }

      if (args.outputPath) {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
      } else {
        console.log(output);
      }
    } catch (error: unknown) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: Unable to find file: ${args.inputFile}`);
        process.exit(1);
      } else if (error instanceof SyntaxError && error.message.includes('JSON')) {
        console.error('Error: Malformed JSON in input file');
        process.exit(1);
      } else {
        console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    }

  } catch (error: unknown) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
};

main();