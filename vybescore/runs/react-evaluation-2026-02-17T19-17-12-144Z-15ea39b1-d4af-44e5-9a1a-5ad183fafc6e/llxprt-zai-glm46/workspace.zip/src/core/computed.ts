/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> & { subject?: Subject<T> } = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
  }
  
  // Computed values also act as subjects that other observers can depend on
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value: value as T,
    equalFn: undefined,
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  s.value = o.value!
  
  const getter = (): T => {
    const currentObserver = getActiveObserver()
    
    // If there's an active observer, register them as depending on this computed
    if (currentObserver && !currentObserver.disposed) {
      s.observers.add(currentObserver)
    }
    
    return s.value
  }
  
  // Store the subject on the observer so we can notify observers when we update
  o.subject = s
  
  return getter
}
