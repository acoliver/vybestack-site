export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure with local and domain parts
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+$/;
  if (!emailRegex.test(value)) return false;
  
  // Split into local and domain parts
  const [local, domain] = value.split('@');
  if (!local || !domain) return false;
  
  // Local part validation
  // Can't start or end with dot, no consecutive dots
  if (local.startsWith('.') || local.endsWith('.')) return false;
  if (local.includes('..')) return false;
  
  // Domain part validation  
  // Can't start or end with dot, no consecutive dots, no underscores
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..') || domain.includes('_')) return false;
  
  // Domain must have at least one dot and TLD of 2+ characters
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  // Each domain part must have at least one character
  if (domainParts.some(part => part.length === 0)) return false;
  
  return true;
}

/**
 * Validates US phone numbers with common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have enough digits (minimum 10, max 11 with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') return false;
  
  // Extract the actual phone number (without country code)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Validate area code (first 3 digits) - can't start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if the remaining format follows standard US patterns using regex
  // This validates separators placement
  const phonePatterns = [
    /^\+?1?\s*\(?(\d{3})\)?[-.\s]?(\d{3})[-.\s]?(\d{4})$/,  // +1 (212) 555-7890, 212-555-7890
    /^\+?1?\s*(\d{3})[-.\s]?(\d{3})[-.\s]?(\d{4})$/,       // 2125557890, 212 555 7890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, trunk prefix 0, and mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Argentine phone number regex with all valid components
  // +54 (country code, optional)
  // 9 (mobile indicator, optional)
  // Area code: 2-4 digits, leading digit 1-9, may start with 0 when country code omitted
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^\+?54\s?9?\s?([1-9]\d{1,3})\s?(\d{6,8})$/;
  
  // For numbers without country code (must start with 0)
  const localPhoneRegex = /^0([1-9]\d{1,3})\s?(\d{6,8})$/;
  
  // Try with original separators first
  if (argentinePhoneRegex.test(value)) {
    return true;
  }
  
  if (localPhoneRegex.test(value)) {
    return true;
  }
  
  // Try with cleaned number for more flexible validation
  if (/^\+?549?([1-9]\d{1,3})(\d{6,8})$/.test(cleanNumber)) {
    const areaCodeMatch = cleanNumber.match(/^\+?549?([1-9]\d{1,3})(\d{6,8})$/);
    if (areaCodeMatch) {
      const areaCode = areaCodeMatch[1];
      const subscriber = areaCodeMatch[2];
      return areaCode.length >= 2 && areaCode.length <= 4 && subscriber.length >= 6 && subscriber.length <= 8;
    }
  }
  
  if (/^0([1-9]\d{1,3})(\d{6,8})$/.test(cleanNumber)) {
    const areaCodeMatch = cleanNumber.match(/^0([1-9]\d{1,3})(\d{6,8})$/);
    if (areaCodeMatch) {
      const areaCode = areaCodeMatch[1];
      const subscriber = areaCodeMatch[2];
      return areaCode.length >= 2 && areaCode.length <= 4 && subscriber.length >= 6 && subscriber.length <= 8;
    }
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Empty input is invalid
  if (!value || value.trim() === '') return false;
  
  // Unicode letter pattern with support for:
  // - Letters from all languages (\p{L})
  // - Accented characters
  // - Apostrophes and hyphens
  // - Spaces between names
  // - Diacritical marks
  const validNamePattern = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!validNamePattern.test(value)) return false;
  
  // Additional checks for unusual patterns
  // Reject names with too many special characters
  const specialCharCount = (value.match(/['-]/g) || []).length;
  const letterCount = (value.match(/\p{L}/gu) || []).length;
  
  // Special characters shouldn't exceed a reasonable ratio
  if (letterCount > 0 && specialCharCount / letterCount > 0.5) return false;
  
  // Reject names with consecutive special characters (except legitimate patterns like O'Neill)
  if (value.includes('--') || value.includes('  ')) return false;
  
  // Reject names that look like "X Æ A-12" (contain digits and multiple Æ characters)
  const hasDigits = /\d/.test(value);
  const hasUnusualSymbol = /[ÆØÅ]/.test(value);
  if (hasDigits && hasUnusualSymbol) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using format and Luhn checksum.
 * Accepts standard prefixes and lengths for major card types.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens from input for validation
  const cleanCardNumber = value.replace(/[\s-]/g, '');
  
  // Must be only digits and reasonable length (13-19 digits)
  if (!/^\d{13,19}$/.test(cleanCardNumber)) return false;
  
  // Card type patterns
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardPattern = /^5[1-5][0-9]{14}$/; // 16 digits, starts with 51-55
  const amexPattern = /^3[47][0-9]{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if matches any valid card pattern
  const isValidFormat = visaPattern.test(cleanCardNumber) || 
                       mastercardPattern.test(cleanCardNumber) || 
                       amexPattern.test(cleanCardNumber);
  
  if (!isValidFormat) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanCardNumber);
}

/**
 * helper function to run Luhn algorithm checksum on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  const isEvenDigit = (position: number): boolean => position % 2 === 0;
  
  // Process each digit from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    const position = cardNumber.length - i;
    
    if (isEvenDigit(position)) {
      // Double every second digit from the right
      let doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        // If the result is two digits, sum them
        doubledDigit = doubledDigit - 9;
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
