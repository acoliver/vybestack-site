/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Sentence boundaries are detected after . ? ! punctuation marks.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim() === '') return text;
  
  // Handle common abbreviations to avoid incorrect sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e'];
  const abbrevPattern = new RegExp(`\\b(?:${abbreviations.join('|')}).\\s`, 'gi');
  
  // First, mark abbreviation boundaries with a temporary marker
  const processedText = text.replace(abbrevPattern, (match) => match.replace('.', '§DOT§'));
  
  // Split text into sentences using sentence-ending punctuation
  const sentences = processedText.split(/([.?!]+)/);
  
  let result = '';
  let capitalizeNext = true; // Start with capitalizing the first character
  let newSentence = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i].trim();
    
    if (!part) continue;
    
    if (/[.?!]+/.test(part)) {
      // This is punctuation, add it to result
      result += part;
      capitalizeNext = true; // Next character should be capitalized
      newSentence = true; // New sentence will follow
    } else {
      // This is text content
      if (capitalizeNext || newSentence) {
        // Capitalize first character, preserve rest of string
        const firstChar = part.charAt(0).toUpperCase();
        const restOfString = part.slice(1);
        result += (newSentence && result && !result.endsWith(' ') ? ' ' : '') + firstChar + restOfString;
        capitalizeNext = false;
        newSentence = false;
      } else {
        // Regular text within sentence
        result += (result && !result.endsWith(' ') ? ' ' : '') + part;
      }
    }
  }
  
  // Clean up temporary markers and normalize spacing
  return result.replace(/§DOT§/g, '.').replace(/\s+/g, ' ').trim();
}

/**
 * Extracts URLs from text, excluding trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern including common protocols and domain formats
  // Captures URLs with http, https, ftp protocols and also www domains
  const urlPattern = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+?(?=[,.!?;:]?(?:\s|$|[<>"']))/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up matches by removing trailing punctuation
  return matches.map(url => url.replace(/[,.!?;:]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://... and docs paths to docs.example.com.
 * For URLs with /docs/ paths, rewrites the host to docs.example.com.
 * Skips host rewrite for URLs with dynamic elements or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with scheme, host, and path
  const urlPattern = /(http:\/\/)([^/\s]+)((\/[^\s]*)?)/gi;
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to HTTPS
    const secureScheme = 'https://';
    
    // Check if path starts with /docs/ and doesn't contain forbidden patterns
    const isDocsPath = path && path.startsWith('/docs/');
    const hasForbiddenPatterns = path && (
      path.includes('/cgi-bin') ||
      path.includes('?') || 
      path.includes('&') || 
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$|$)/.test(path)
    );
    
    if (isDocsPath && !hasForbiddenPatterns) {
      // Rewrite the host to docs.example.com
      return secureScheme + 'docs.' + host + path;
    } else {
      // Just upgrade the scheme to HTTPS
      return secureScheme + host + path;
    }
  });
      // Rewrite the host to docs.example.com
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with capturing groups
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for specific month-day combinations
  const monthDays = [
    31, // January
    (month === 2 ? 28 : 31), // February (simplified, not accounting for leap years)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day > monthDays[month - 1]) {
    return 'N/A';
  }
  
  return yearStr;
}
