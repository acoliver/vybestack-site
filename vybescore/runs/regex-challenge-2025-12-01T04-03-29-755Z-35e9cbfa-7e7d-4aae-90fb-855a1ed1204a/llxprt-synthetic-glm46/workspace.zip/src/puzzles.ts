/**
 * Finds words starting with the given prefix but excluding the listed exceptions.
 * Returns an array of matched word strings.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Simple approach for prefixes with no special regex characters
  const wordPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches in the text
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token preceded by a digit (using a backreference in a larger pattern)
  // This approach is more compatible than lookbehinds
  const pattern = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Return the full match (digit + token)
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates passwords according to the security policy:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like ababab)
  // This checks for patterns where a character or group repeats immediately
  const repeatedPatterns = [
    /(.)\1{3,}/, // Four or more repeated characters: aaaa
    /(.{2,3})\1{2,}/ // Two or three character groups repeated 2+ times: abab, abcabc
  ];
  
  for (const pattern of repeatedPatterns) {
    if (pattern.test(value)) return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation with ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // First check for IPv4 addresses to exclude them
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  if (ipv4Pattern.test(value)) {
    // If contains IPv4, we need to check if it also contains IPv6
    // Remove the IPv4 part and then test for IPv6
    const withoutIPv4 = value.replace(ipv4Pattern, '');
    return containsIPv6Only(withoutIPv4);
  }
  
  return containsIPv6Only(value);
}

/**
 * Helper function to detect only IPv6 addresses in a string.
 */
function containsIPv6Only(value: string): boolean {
  // IPv6 regex patterns
  // Full IPv6 with all 8 groups: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/g;
  
  // IPv6 with :: shorthand for one or more groups of zeros
  // :: can appear at start, middle, or end, replacing at least one group
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}?\b/g;
  
  // IPv6 with :: at the beginning or end
  const edgeShorthand = /\b::(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}::\b/g;
  
  // IPv6 with IPv4 embedded: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:192.168.1.1
  const ipv6WithIPv4 = /\b(?:[0-9a-fA-F]{1,4}:){6}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  
  return fullIPv6.test(value) || 
         shorthandIPv6.test(value) || 
         edgeShorthand.test(value) || 
         ipv6WithIPv4.test(value);
}
