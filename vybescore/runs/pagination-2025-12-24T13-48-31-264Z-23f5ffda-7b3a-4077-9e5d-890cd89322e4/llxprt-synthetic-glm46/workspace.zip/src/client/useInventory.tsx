import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number): InventoryState {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;

    async function load(): Promise<void> {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        // FIXED: Include page and limit as query parameters
        const url = `/inventory?page=${encodeURIComponent(page)}&limit=${encodeURIComponent(limit)}`;
        const response = await fetch(url);
        if (!response.ok) {
          // Try to get error message from response body for better error handling
          const errorText = await response.text();
          throw new Error(errorText || `Request failed with status ${response.status}`);
        }
        const payload = (await response.json()) as InventoryPage;
        if (!cancelled) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    // FIXED: Always load data when page or limit changes
    load();

    return () => {
      cancelled = true;
    };
    // FIXED: Include page and limit in dependencies to trigger reloads
  }, [page, limit]);

  return state;
}
