import express, { Request, Response } from 'express';
import path from 'node:path';
import { initializeDatabase, insertSubmission, closeDatabase, type Submission } from './db.js';
import { validateForm, type FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.static(path.resolve('public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'views'));

// Extend Express Request to include validation data
interface RequestWithValidation extends Request {
  validationErrors?: Record<string, string>;
  validationData?: Record<string, string>;
}

// GET / - Render the form
app.get('/', (req: Request, res: Response) => {
  const reqWithValidation = req as RequestWithValidation;
  res.render('form', {
    errors: reqWithValidation.validationErrors || {},
    data: reqWithValidation.validationData || {},
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const result = validateForm(formData);

  if (!result.valid) {
    // Re-render form with errors
    const reqWithValidation = req as RequestWithValidation;
    reqWithValidation.validationErrors = result.errors;
    reqWithValidation.validationData = req.body;
    return res.status(400).render('form', {
      errors: result.errors,
      data: req.body,
    });
  }

  // Insert into database
  const submission: Submission = {
    first_name: result.data!.firstName,
    last_name: result.data!.lastName,
    street_address: result.data!.streetAddress,
    city: result.data!.city,
    state_province: result.data!.stateProvince,
    postal_code: result.data!.postalCode,
    country: result.data!.country,
    email: result.data!.email,
    phone: result.data!.phone,
  };

  insertSubmission(submission);

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

// GET /thank-you - Render thank-you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown handler
let server: ReturnType<typeof app.listen> | null = null;

async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  
  closeDatabase();
  console.log('Database closed');
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized');

    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Only start server if this file is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  start();
}

export { app, start, shutdown };
