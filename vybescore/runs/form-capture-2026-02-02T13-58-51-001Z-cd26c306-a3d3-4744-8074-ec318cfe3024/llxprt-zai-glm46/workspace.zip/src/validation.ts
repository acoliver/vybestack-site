export interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
  data?: Record<string, string>;
}

export interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function isRequired(value: string): boolean {
  return value.trim().length > 0;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function isValidPostalCode(code: string): boolean {
  // Allow alphanumeric characters and spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(code) && code.trim().length > 0;
}

export function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};
  const cleanData: Record<string, string> = {};

  // First name
  if (!data.firstName || !isRequired(data.firstName)) {
    errors.firstName = 'First name is required';
  } else {
    cleanData.firstName = data.firstName.trim();
  }

  // Last name
  if (!data.lastName || !isRequired(data.lastName)) {
    errors.lastName = 'Last name is required';
  } else {
    cleanData.lastName = data.lastName.trim();
  }

  // Street address
  if (!data.streetAddress || !isRequired(data.streetAddress)) {
    errors.streetAddress = 'Street address is required';
  } else {
    cleanData.streetAddress = data.streetAddress.trim();
  }

  // City
  if (!data.city || !isRequired(data.city)) {
    errors.city = 'City is required';
  } else {
    cleanData.city = data.city.trim();
  }

  // State/Province
  if (!data.stateProvince || !isRequired(data.stateProvince)) {
    errors.stateProvince = 'State/Province/Region is required';
  } else {
    cleanData.stateProvince = data.stateProvince.trim();
  }

  // Postal code
  if (!data.postalCode || !isRequired(data.postalCode)) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!isValidPostalCode(data.postalCode)) {
    errors.postalCode = 'Postal code must contain only letters, numbers, and spaces';
  } else {
    cleanData.postalCode = data.postalCode.trim();
  }

  // Country
  if (!data.country || !isRequired(data.country)) {
    errors.country = 'Country is required';
  } else {
    cleanData.country = data.country.trim();
  }

  // Email
  if (!data.email || !isRequired(data.email)) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  } else {
    cleanData.email = data.email.trim();
  }

  // Phone
  if (!data.phone || !isRequired(data.phone)) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(data.phone)) {
    errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  } else {
    cleanData.phone = data.phone.trim();
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors,
    data: Object.keys(errors).length === 0 ? cleanData : undefined,
  };
}
