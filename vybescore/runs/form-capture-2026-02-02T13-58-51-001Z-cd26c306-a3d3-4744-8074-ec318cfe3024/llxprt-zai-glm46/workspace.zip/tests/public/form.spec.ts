import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { initializeDatabase, closeDatabase } from '../../src/db.js';
import { app } from '../../src/server.js';

let closeServer: () => Promise<void>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize database before tests
  await initializeDatabase();
  
  // Start the server for testing
  const server = await new Promise<ReturnType<typeof app.listen>>((resolve) => {
    const srv = app.listen(0, () => {
      resolve(srv);
    });
  });
  
  closeServer = async () => {
    return new Promise<void>((resolve) => {
      server.close(() => {
        resolve();
      });
    });
  };
});

afterAll(async () => {
  if (closeServer) {
    await closeServer();
  }
  
  closeDatabase();
  
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Get In Touch');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required fields with proper labels
    expect($('label[for="firstName"]').text()).toContain('First Name');
    expect($('#firstName').attr('name')).toBe('firstName');
    
    expect($('label[for="lastName"]').text()).toContain('Last Name');
    expect($('#lastName').attr('name')).toBe('lastName');
    
    expect($('label[for="streetAddress"]').text()).toContain('Street Address');
    expect($('#streetAddress').attr('name')).toBe('streetAddress');
    
    expect($('label[for="city"]').text()).toContain('City');
    expect($('#city').attr('name')).toBe('city');
    
    expect($('label[for="stateProvince"]').text()).toContain('State / Province / Region');
    expect($('#stateProvince').attr('name')).toBe('stateProvince');
    
    expect($('label[for="postalCode"]').text()).toContain('Postal / Zip Code');
    expect($('#postalCode').attr('name')).toBe('postalCode');
    
    expect($('label[for="country"]').text()).toContain('Country');
    expect($('#country').attr('name')).toBe('country');
    
    expect($('label[for="email"]').text()).toContain('Email');
    expect($('#email').attr('name')).toBe('email');
    
    expect($('label[for="phone"]').text()).toContain('Phone Number');
    expect($('#phone').attr('name')).toBe('phone');
    
    // Check form action
    expect($('form').attr('method')).toBe('POST');
    expect($('form').attr('action')).toBe('/submit');
  });

  it('shows validation errors for invalid input', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: 'invalid-email',
        phone: 'invalid-phone',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Street address is required');
    expect(response.text).toContain('Please enter a valid email address');
    expect(response.text).toContain('Phone number can only contain');
  });

  it('accepts international phone and postal formats', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Juan',
        lastName: 'Pérez',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'juan@example.com',
        phone: '+54 9 11 1234-5678',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts UK postal codes', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Smith',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: '+44 20 7946 0958',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('persists submission and redirects', async () => {
    // Clean up database before this test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'jane@example.com',
        phone: '+1 555-123-4567',
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page with appropriate message', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thanks for Your Submission');
    expect(response.text.toLowerCase()).toContain('spam');
    expect(response.text.toLowerCase()).toContain('identity');
  });
});
