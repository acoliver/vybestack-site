import { validateForm } from './src/validation.js';

const testData = {
  firstName: 'Juan',
  lastName: 'Pérez',
  streetAddress: 'Av. Corrientes 1234',
  city: 'Buenos Aires',
  stateProvince: 'CABA',
  postalCode: 'C1000',
  country: 'Argentina',
  email: 'juan@example.com',
  phone: '+54 9 11 1234-5678',
};

const result = validateForm(testData);
console.log('Valid:', result.valid);
console.log('Errors:', result.errors);
console.log('Data:', result.data);
