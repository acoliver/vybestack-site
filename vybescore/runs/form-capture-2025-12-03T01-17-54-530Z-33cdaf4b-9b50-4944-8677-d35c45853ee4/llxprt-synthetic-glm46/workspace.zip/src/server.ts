import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - sql.js doesn't have proper type definitions
import sqlite3 from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const port = process.env.PORT || 3535;
let db: sqlite3.Database;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Initialize SQLite database
async function initializeDatabase() {
  try {
    const dataDir = path.join(__dirname, '../data');
    const dbPath = path.join(dataDir, 'submissions.sqlite');
    
    // Ensure data directory exists
    await fs.mkdir(dataDir, { recursive: true });
    
    // Read schema
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = await fs.readFile(schemaPath, 'utf8');
    
    // Check if database exists
    let dbData: Uint8Array | undefined;
    try {
      const existingDb = await fs.readFile(dbPath);
      dbData = new Uint8Array(existingDb);
    } catch (err) {
      // Database doesn't exist yet, will create new one
    }
    
    // Initialize database
    const SQL = await sqlite3();
    db = new SQL.Database(dbData);
    
    // Create tables if they don't exist
    db.run(schema);
    
    // Export database to disk
    const data = db.export();
    await fs.writeFile(dbPath, new Uint8Array(data));
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Form validation function
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }
  
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/\S+@\S+\.\S+/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^[+]?[0-9\s\-()]+$/.test(data.phone.replace(/\s/g, ''))) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  return errors;
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    const errorMessages = errors.map(error => error.message);
    res.render('form', { 
      errors: errorMessages, 
      values: formData
    });
    return;
  }
  
  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city,
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    stmt.free();
    
    // Export database to disk
    const data = db.export();
    const dataDir = path.join(__dirname, '../data');
    const dbPath = path.join(dataDir, 'submissions.sqlite');
    await fs.writeFile(dbPath, new Uint8Array(data));
  } catch (error) {
    console.error('Failed to save submission:', error);
    return res.render('form', { 
      errors: ['An error occurred while saving your submission. Please try again.'], 
      values: formData
    });
  }
  
  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown with SIGTERM handling
async function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}, shutting down gracefully...`);
  
  try {
    // Close database
    if (db) {
      db.close();
    }
    
    // Close server
    server.close(() => {
      console.log('Server closed successfully');
      process.exit(0);
    });
    
    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Forcing shutdown after timeout');
      process.exit(1);
    }, 10000);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

// Start server after database initialization
let server: import('http').Server;

async function startServer() {
  await initializeDatabase();
  
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  
  // Handle shutdown signals
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Start the application
startServer().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});