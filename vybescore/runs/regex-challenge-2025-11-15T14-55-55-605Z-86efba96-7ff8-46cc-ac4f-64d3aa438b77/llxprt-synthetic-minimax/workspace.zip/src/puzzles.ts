/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a regex pattern that matches words starting with the prefix
  // \b ensures we match whole words only
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const result = matches.filter(match => 
    !exceptions.some(exception => 
      match.toLowerCase() === exception.toLowerCase()
    )
  );
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Use regex to find digit followed by token
  // Pattern: digit + token (case insensitive)
  const pattern = new RegExp(`\\d${token}`, 'gi');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]); // The full match (digit + token)
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like abab, 1212, etc.)
  // Check for any 2+ character pattern repeated immediately
  for (let patternLength = 2; patternLength <= Math.floor(value.length / 2); patternLength++) {
    for (let i = 0; i <= value.length - (patternLength * 2); i++) {
      const pattern = value.substring(i, i + patternLength);
      const next = value.substring(i + patternLength, i + patternLength * 2);
      if (pattern === next) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, check if it's a valid IPv4 address - if so, reject it
  // IPv4 pattern: 0-255.0-255.0-255.0-255
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  if (ipv4Pattern.test(value)) {
    return false; // IPv4 addresses should not trigger IPv6 detection
  }
  
  // Simpler IPv6 pattern that catches the essential characteristics
  const simpleIpv6Pattern = /\b(?:[A-Fa-f0-9]{1,4}:){1,7}[A-Fa-f0-9]{0,4}|(?:[A-Fa-f0-9]{0,4}:){1,7}:|::/;
  
  // Test against the pattern, but also ensure it contains colons
  return (simpleIpv6Pattern.test(value) && value.includes(':'));
}