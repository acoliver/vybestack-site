export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Luhn checksum algorithm for credit card validation
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Must have format: local-part@domain
  // Local part: letters, numbers, dots, underscores, plus, hyphens, but no double dots
  // Domain: letters, numbers, dots, hyphens, but no leading/trailing dots
  // Must reject double dots, trailing dots, domains with underscores
const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  if (value.includes('..')) {
    return false;
  }
  
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const domain = parts[1];
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must have +1 prefix or 10 digits
  const phoneRegex = /^(\+1)?([2-9]\d{2}[2-9]\d{2}\d{4})$/;
  
  if (!phoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract the 10-digit number (without country code)
  const digits = cleaned.startsWith('+1') ? cleaned.slice(2) : cleaned;
  
  // Validate area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check length (should be exactly 10 digits)
  if (digits.length !== 10) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit, non-space, non-hyphen characters except plus
  const cleaned = value.replace(/[^\d\s+-]/g, '');
  
  // Remove spaces and hyphens to get just digits and plus
  const digitsOnly = cleaned.replace(/[\s-]/g, '');
  
  // Must be a reasonable length
  if (digitsOnly.length < 8 || digitsOnly.length > 15) {
    return false;
  }
  
  // Pattern matching for Argentine phone numbers
  // Optional +54, optional 9 (mobile), optional 0 (trunk), area code 2-4 digits (1-9), subscriber 6-8 digits
  
  const patterns = [
    // Mobile with country code: +54 9 XX YYYYYYY
    /^(\+54)?9([1-9]\d{1,3})(\d{6,8})$/,
    // Landline with country code: +54 XX YYYYYYY (without mobile indicator)
    /^(\+54)([1-9]\d{1,3})(\d{6,8})$/,
    // Mobile without country code: 0 9 XX YYYYYYY
    /^09([1-9]\d{1,3})(\d{6,8})$/,
    // Landline without country code: 0XX YYYYYYY
    /^0([1-9]\d{1,3})(\d{6,8})$/
  ];
  
  return patterns.some(pattern => pattern.test(digitsOnly));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty and reasonable length
  if (!value || value.length < 1 || value.length > 50) {
    return false;
  }
  
  // Allow unicode letters, accents (Unicode categories), apostrophes, hyphens, spaces
  // Reject digits and other symbols, including X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}]+(?:[\s'-][\p{L}\p{M}]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject obvious fake names (X Æ A-12 pattern)
  if (value.includes('Æ') || /^[XYZ]\s*[AEIOU]/.test(value) || /\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for valid card type based on prefix and length
  let validPrefix = false;
  let validLength = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    validPrefix = true;
    validLength = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
             digits.startsWith('54') || digits.startsWith('55') || 
             (digits.startsWith('222') && parseInt(digits.substring(0, 4)) >= 2221 && parseInt(digits.substring(0, 4)) <= 2720)) &&
             digits.length === 16) {
    validPrefix = true;
    validLength = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    validPrefix = true;
    validLength = true;
  }
  
  if (!validPrefix || !validLength) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
