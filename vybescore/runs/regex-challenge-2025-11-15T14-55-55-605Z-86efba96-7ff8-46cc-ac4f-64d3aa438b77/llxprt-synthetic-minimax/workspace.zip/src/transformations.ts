/**
 * Text transformation functions using regular expressions
 */

/**
 * Capitalize the first character of each sentence and ensure proper spacing
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Find sentence boundaries and capitalize first letter after sentence endings
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * Extract all URLs from text
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex that matches common URL patterns
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+/gi;
  const matches = text.match(urlRegex);
  
  return matches ? matches.map(url => url.replace(/[.,!?;:]+$/, '')) : [];
}

/**
 * Replace http:// URLs with https://
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs to use docs subdomain
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http:// URLs
const urlPattern = /http:\/\/([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    let result = 'https://';
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.hostname.com
      const docsHost = `docs.${host}`;
      result += docsHost;
    } else {
      result += host;
    }
    
    result += path;
    
    return result;
  });
}

/**
 * Extract year from mm/dd/yyyy format
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  return year;
}