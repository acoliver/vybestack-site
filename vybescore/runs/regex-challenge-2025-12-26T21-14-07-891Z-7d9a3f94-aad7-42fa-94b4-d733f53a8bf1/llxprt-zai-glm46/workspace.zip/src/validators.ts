export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || value.length > 254) return false;

  // Local part: alphanumeric, dots, hyphens, underscores, plus signs
  // Cannot start or end with dot, no consecutive dots
  // Domain: alphanumeric and hyphens only (no underscores), at least one dot
  // Note: hyphen is escaped because it's in the middle of the character class
  // eslint-disable-next-line no-useless-escape
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._%+\-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;

  if (!emailRegex.test(value)) return false;

  // Additional checks: no consecutive dots in local part, no trailing dot
  const [local, domain] = value.split('@');

  // Check for consecutive dots or trailing/leading dots in local part
  if (local.includes('..') || local.startsWith('.') || local.endsWith('.')) {
    return false;
  }

  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }

  // Check domain TLD is at least 2 chars
  const domainParts = domain.split('.');
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix. Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) return false;

  // Reserved for future use (allowExtensions)
  void options;

  // Remove common separators and spaces
  // Note: dot, hyphen, and parentheses inside [] don't need escaping
  const cleaned = value.replace(/[\s.\-()]/g, '');

  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    // Could be country code without +
    digits = digits.slice(1);
  }

  // US phone number should be 10 digits (area code + 7-digit number)
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  const areaCode = digits.slice(0, 3);
  const exchangeCode = digits.slice(3, 6);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code cannot start with 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles such as:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;

  // Remove spaces, hyphens, and other separators
  // Note: hyphen is escaped because it's in the middle of the character class
  // eslint-disable-next-line no-useless-escape
  const cleaned = value.replace(/[\s.\-]/g, '');

  // More flexible pattern to handle the 9 mobile indicator
  // When country code is omitted, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');

  // Check for mobile indicator 9 and calculate area code start position
  let areaCodeStart = 0;

  if (cleaned.startsWith('+549')) {
    areaCodeStart = 4;
  } else if (cleaned.startsWith('+54')) {
    areaCodeStart = 3;
  } else if (cleaned.startsWith('09')) {
    areaCodeStart = 2;
  } else if (cleaned.startsWith('0')) {
    areaCodeStart = 1;
  } else {
    // No valid prefix
    return false;
  }

  // When country code is omitted, must start with trunk prefix 0
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }

  // Extract area code and subscriber
  const remaining = cleaned.slice(areaCodeStart);

  // Area code is 2-4 digits starting with 1-9
  const areaMatch = remaining.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaMatch) return false;

  const area = areaMatch[1];
  const sub = areaMatch[2];

  // Area code must be 2-4 digits
  if (area.length < 2 || area.length > 4) return false;

  // Subscriber must be 6-8 digits
  if (sub.length < 6 || sub.length > 8) return false;

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) return false;

  // Unicode letters, accents, apostrophes, hyphens, spaces
  // At least 2 characters, must start and end with a letter
  // Note: hyphens are escaped because they're in the middle of character classes
  // eslint-disable-next-line no-useless-escape
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0370-\u03FF\u4E00-\u9FFF\uAC00-\uD7AF]([a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0370-\u03FF\u4E00-\u9FFF\uAC00-\uD7AF\s'\-]*[a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0370-\u03FF\u4E00-\u9FFF\uAC00-\uD7AF])?$/;

  if (!nameRegex.test(value.trim())) return false;

  // Check for disallowed characters (digits and symbols like Æ, numbers)
  // eslint-disable-next-line no-useless-escape
  if (/\d|[ÆÐØŒÞæøœþ]|[^a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0370-\u03FF\u4E00-\u9FFF\uAC00-\uD7AF\s'\-]/.test(value)) {
    return false;
  }

  // Minimum length of 2 characters
  if (value.trim().length < 2) return false;

  // Cannot contain consecutive spaces
  if (/\s{2,}/.test(value)) return false;

  // Cannot start or end with space, apostrophe, or hyphen
  const trimmed = value.trim();
  // eslint-disable-next-line no-useless-escape
  if (/^[\s'\-]|[\s'\-]$/.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * Luhn algorithm for credit card checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;

  // Remove spaces and hyphens
  // Note: hyphen at end of character class doesn't need escaping
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits, 13-19 digits (standard card lengths)
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }

  // Check Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  if (visaRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }

  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mcRegex1 = /^5[1-5]\d{14}$/;
  const mcRegex2 = /^2[2-7][0-2][0-1]\d{12}$/;
  if (mcRegex1.test(cleaned) || mcRegex2.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }

  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }

  return false;
}
