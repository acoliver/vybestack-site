/**
 * Capitalize the first character of each sentence.
 * After .?!, capitalize the next letter.
 * Insert exactly one space between sentences if needed.
 * Collapse extra spaces sensibly while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // First, normalize whitespace - collapse multiple spaces into one
  let normalized = text.replace(/[ \t]+/g, ' ').trim();

  // Ensure exactly one space after sentence-ending punctuation
  // Look for punctuation followed by optional space(s) then a lowercase letter
  normalized = normalized.replace(/([.!?])\s*([a-z])/g, '$1 $2');

  // Now capitalize the first letter of each sentence
  // A sentence starts after .!?, or at the beginning of the string
  const result = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (_match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });

  return result;
}

/**
 * Extract all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];

  // URL pattern: scheme://domain/path?query#fragment
  // Match common schemes and domains
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9._~:/?#[\]@!$&'()*+,;=%-]+[a-zA-Z0-9/]?(?=\s|$|[.,!?;:)\]}])/gi;

  const matches = text.match(urlPattern) || [];

  // Clean up: remove trailing punctuation that might have been captured
  return matches.map(url => {
    return url.replace(/[.,!?;:)\]}]+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Convert all http:// URLs to https://
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;

  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite documentation URLs.
 * For URLs http://example.com/...:
 * - Always upgrade scheme to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, ?, &, =, .jsp, .php, etc.)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;

  // Pattern to match URLs starting with http:// or https://
  // We need to find example.com URLs and process them
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (_match, _scheme, _host, path = '') => {
    // Always upgrade scheme to https
    const newScheme = 'https://';

    // Check if we should rewrite host (path starts with /docs/ and no dynamic hints)
    const shouldRewriteHost = path.startsWith('/docs/') &&
      !path.includes('cgi-bin') &&
      !path.includes('?') &&
      !path.includes('&') &&
      !path.includes('=') &&
      !/\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$)/i.test(path);

    const newHost = shouldRewriteHost ? 'docs.example.com' : 'example.com';

    return newScheme + newHost + path;
  });
}

/**
 * Extract year from mm/dd/yyyy format.
 * Returns the 4-digit year, or 'N/A' if format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';

  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) return 'N/A';

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';

  // Additional day validation per month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };

  if (day > daysInMonth[month]) return 'N/A';

  return year;
}
