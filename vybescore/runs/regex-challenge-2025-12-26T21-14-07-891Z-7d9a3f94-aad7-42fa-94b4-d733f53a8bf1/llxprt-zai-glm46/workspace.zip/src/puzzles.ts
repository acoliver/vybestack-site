/**
 * Find words starting with a prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Word boundary followed by prefix
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  return matches
    .map((word) => word)
    .filter((word) => !exceptions.some((ex) => ex.toLowerCase() === word.toLowerCase()));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Positive lookbehind for a digit, negative lookbehind for start of string
  // Use (\d) as a capturing group instead of lookbehind for better compatibility
  const pattern = new RegExp(`(\\d)(${escapedToken})`, 'gi');

  const results: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(text)) !== null) {
    // match[0] is the full match (digit + token)
    // match[2] is just the token
    results.push(match[0]);
  }

  return results;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab")
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;

  // Check for at least one digit
  if (!/\d/.test(value)) return false;

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;

  // Check for immediate repeated sequences of length 2 or more
  // e.g., "abab", "123123", "abcabc"
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const seq = value.slice(i, i + len);
      const nextSeq = value.slice(i + len, i + len * 2);
      if (seq === nextSeq) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand :: notation).
 * Must not detect IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;

  // First, exclude pure IPv4 addresses
  // IPv4: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /^\b(?:\d{1,3}\.){3}\d{1,3}\b$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }

  // Check for full IPv6 pattern (8 groups of hex)
  const ipv6FullPattern = /(?:^|[^\da-fA-F])([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:[^\da-fA-F]|$)/;
  if (ipv6FullPattern.test(value)) return true;

  // Check for compressed IPv6 (:: notation)
  const ipv6CompressedPattern = /(?:^|[^\da-fA-F])[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{0,4})?::([0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{0,4})*)?(?:[^\da-fA-F]|$)/;
  if (ipv6CompressedPattern.test(value)) return true;

  // Check for partial IPv6 patterns (embedded in text)
  // Must contain at least 2 colons to be a valid IPv6
  if (value.includes(':')) {
    // Look for sequences that look like IPv6 segments
    // Pattern: hex:hex:... or hex::hex
    const ipv6PartialPattern = /[0-9a-fA-F]{1,4}:(?::?[0-9a-fA-F]{1,4})+/;
    if (ipv6PartialPattern.test(value)) return true;
  }

  return false;
}
