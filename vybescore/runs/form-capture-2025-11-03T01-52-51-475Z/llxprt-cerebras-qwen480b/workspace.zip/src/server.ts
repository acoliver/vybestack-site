import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname in ES module
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize Express app
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3000;

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Initialize database
let db: Database | null = null;
let SQL: initSqlJs.SqlJsStatic | null = null;

async function initDatabase() {
  SQL = await initSqlJs({
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
  });
  
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  
  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase() {
  if (db) {
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric postal codes with possible spaces or dashes
  // No need to escape the dash when it's at the end of the character class
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: {}, formData: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body;
  
  // Validation errors object
  const errors: Record<string, string> = {};
  
  // Required field validation
  const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 
                         'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  }
  
  // Email validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }
  
  // If there are validation errors, re-render the form with errors and data
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', { errors, formData });
  }
  
  // Insert data into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    saveDatabase();
  }
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown handling
let serverInstance:ReturnType<express.Application["listen"]> | null = null;

function startServer(): void {
  serverInstance = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });
}

function closeServer(): void {
  if (serverInstance) {
    serverInstance.close(() => {
      console.log('Express server closed');
    });
  }
  
  if (db) {
    db.close();
    console.log('Database closed');
  }
}

process.on('SIGTERM', closeServer);
process.on('SIGINT', closeServer);

// Initialize and start server
initDatabase().then(() => {
  startServer();
}).catch((error) => {
  console.error('Failed to initialize database:', error);
  process.exit(1);
});

export default app;