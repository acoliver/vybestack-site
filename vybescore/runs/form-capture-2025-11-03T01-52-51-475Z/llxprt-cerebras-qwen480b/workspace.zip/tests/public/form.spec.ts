import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';
import { Express } from 'express';

// Convert import.meta.url to __filename and __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let server: Express;
const dbPath = path.resolve(__dirname, '../../data/submissions.sqlite');

beforeAll(async () => {
  // Dynamically import the server module
  const serverModule = await import('../../src/server.ts');
  server = serverModule.default || serverModule;
});

afterAll(() => {
  // Tests don't actually start the server, so no need to close it
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    
    // Parse HTML response
    const $ = cheerio.load(response.text);
    
    // Check for required form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clear database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'Country',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567'
    };
    
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send(submissionData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});