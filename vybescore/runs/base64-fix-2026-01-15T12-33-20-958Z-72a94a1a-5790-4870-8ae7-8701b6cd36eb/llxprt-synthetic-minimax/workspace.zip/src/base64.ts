/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Rejects invalid Base64 input by throwing an error.
 */
export function decode(input: string): string {
  const normalized = input.trim();

  // Validate that input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Check if input has padding or can be padded to multiple of 4
  if (normalized.length % 4 !== 0) {
    // Add padding if needed
    const padded = normalized + '='.repeat(4 - (normalized.length % 4));
    
    try {
      return Buffer.from(padded, 'base64').toString('utf8');
    } catch (error) {
      throw new Error('Failed to decode Base64 input');
    }
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
