import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('handles pagination with page and limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test default behavior (page 1, limit 5)
    const response1 = await request(app).get('/inventory');
    expect(response1.status).toBe(200);
    expect(response1.body.page).toBe(1);
    expect(response1.body.limit).toBe(5);
    expect(response1.body.total).toBeGreaterThan(0);
    expect('hasNext' in response1.body).toBe(true);
    
    // Test explicit page and limit
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    expect(response2.status).toBe(200);
    expect(response2.body.page).toBe(2);
    expect(response2.body.limit).toBe(3);
    expect(response2.body.total).toBe(response1.body.total); // Same total
  });

  it('validates pagination parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test invalid page parameter
    const response1 = await request(app).get('/inventory?page=0');
    expect(response1.status).toBe(400);
    
    const response2 = await request(app).get('/inventory?page=-1');
    expect(response2.status).toBe(400);
    
    const response3 = await request(app).get('/inventory?page=abc');
    expect(response3.status).toBe(400);
    
    // Test invalid limit parameter
    const response4 = await request(app).get('/inventory?limit=0');
    expect(response4.status).toBe(400);
    
    const response5 = await request(app).get('/inventory?limit=-5');
    expect(response5.status).toBe(400);
    
    const response6 = await request(app).get('/inventory?limit=xyz');
    expect(response6.status).toBe(400);
    
    // Test excessive limit parameter
    const response7 = await request(app).get('/inventory?limit=101');
    expect(response7.status).toBe(400);
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // First page
    const response1 = await request(app).get('/inventory?limit=2');
    expect(response1.body.page).toBe(1);
    expect(response1.body.limit).toBe(2);
    
    if (response1.body.total > 2) {
      expect(response1.body.hasNext).toBe(true);
    } else {
      expect(response1.body.hasNext).toBe(false);
    }
    
    // Last page (if more than 2 items exist)
    if (response1.body.total > 2) {
      const lastPage = Math.ceil(response1.body.total / 2);
      const response2 = await request(app).get(`/inventory?page=${lastPage}&limit=2`);
      expect(response2.body.hasNext).toBe(false);
    }
  });
});
