export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper RFC compliance.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that's comprehensive but not overly strict
  // Local part: letters, digits, +, -, ., apostrophes (no consecutive or trailing dots)
  // Domain part: letters, digits, hyphens (no underscores), at least one dot
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional validation rules
  if (!emailRegex.test(value)) return false;
  
  // No consecutive dots in the entire email
  if (value.includes('..')) return false;
  
  // No leading or trailing dots in local part or domain
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  const [localPart, domain] = value.split('@');
  
  // No leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // Domain must have at least one dot
  if (!domain.includes('.')) return false;
  
  return true;
}

/**
 * Validate US phone numbers supporting (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Minimum 10 digits (without country code), maximum 11 digits (with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  let areaCode: string;
  
  if (digitsOnly.length === 11) {
    // Start with country code 1
    if (!digitsOnly.startsWith('1')) return false;
    areaCode = digitsOnly.slice(1, 4);
  } else {
    areaCode = digitsOnly.slice(0, 3);
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate the overall format with common separators
  const phoneRegex = /^\+?1?\s*\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  return phoneRegex.test(value.replace(/\s+/g, ' '));
}

/**
 * Validate Argentine phone numbers handling landlines and mobiles.
 * Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Start with optional +54 country code
  let hasCountryCode = false;
  let remainingValue = cleanValue;
  
  if (remainingValue.startsWith('+54')) {
    hasCountryCode = true;
    remainingValue = remainingValue.slice(3);
  }
  
  // Check for optional trunk prefix 0 (required when no country code)
  if (remainingValue.startsWith('0')) {
    remainingValue = remainingValue.slice(1);
  } else if (!hasCountryCode) {
    // Must have trunk prefix if no country code
    return false;
  }
  
  // Check for optional mobile indicator 9
  if (remainingValue.startsWith('9')) {
    remainingValue = remainingValue.slice(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = remainingValue.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  remainingValue = remainingValue.slice(areaCode.length);
  
  // Subscriber number should be 6-8 digits
  if (!/^\d{6,8}$/.test(remainingValue)) return false;
  
  // Final validation with regex - subscriber can be split into multiple groups
  const argentinePhoneRegex = /^(\+54[\s-]?)?(0[\s-]?)?9?[\s-]?([1-9]\d{1,3})[\s-]?(\d{3,4})[\s-]?(\d{3,4})$/;
  return argentinePhoneRegex.test(value);
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, including accented characters, plus apostrophes, hyphens, and spaces
  // Name must have at least one letter character
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter (reject just spaces/punctuation)
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reasonable length check (1-100 characters)
  if (value.length < 1 || value.length > 100) return false;
  
  // Not just spaces or special characters
  const trimmedValue = value.trim();
  if (trimmedValue.length === 0) return false;
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx using prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Basic card type validation
  const isVisa = /^4\d{12}(\d{3})?$/.test(digitsOnly); // 13 or 16 digits, starts with 4
  const isMastercard = /^5[1-5]\d{14}$/.test(digitsOnly); // 16 digits, starts with 51-55
  const isAmEx = /^3[47]\d{13}$/.test(digitsOnly); // 15 digits, starts with 34 or 37
  
  // Check if it matches any supported card type
  if (!isVisa && !isMastercard && !isAmEx) return false;
  
  // Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to run Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
