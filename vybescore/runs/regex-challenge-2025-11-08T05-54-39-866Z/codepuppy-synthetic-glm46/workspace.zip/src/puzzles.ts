/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 * Uses word boundaries and case-sensitive matching.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Simple manual escaping for the most common regex special characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  const wordRegex = new RegExp('\\b' + escapedPrefix + '[a-zA-Z0-9_-]*', 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-sensitive)
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds as requested.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Simple manual escaping for the most common regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to ensure preceded by digit and include the digit
  // Use negative lookbehind to ensure not at start of string
  const tokenRegex = new RegExp('(?<!^)(\\d)' + escapedToken, 'g');
  
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * Validate passwords: At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At at least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // No immediate repeated sequences (like abab, abcabc, etc.)
  // Check for sequences of 2+ characters that repeat immediately
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const sequence = value.substr(i, len);
      const nextSequence = value.substr(i + len, len);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger.
 */
export function containsIPv6(value: string): boolean {
  // First, make sure we don't mistake IPv4 for IPv6
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it's pure IPv4, don't match
  if (ipv4Pattern.test(value) && !/[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/.test(value)) {
    return false;
  }
  
  // More comprehensive IPv6 patterns
  const patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits separated by colons
    /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with :: compression at various positions
    /\b([0-9a-fA-F]{1,4}:){0,7}::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/,
    /\b::([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{0,4}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,7}::\b/,
    /\b::\b/,
    // IPv6 with embedded IPv4
    /\b([0-9a-fA-F]{1,4}:){6}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/
  ];
  
  // Test all patterns
  return patterns.some(pattern => pattern.test(value));
}