/**
 * Capitalize the first character of each sentence, proper spacing, and handle abbreviations.
 * Sentence boundaries are .?! followed by whitespace and end of string.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces, but be careful with sentence boundaries
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Common abbreviations that should not end sentences (add more as needed)
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e\.g', 'i\.e', 'vs', 'U\.S', 'U\.K'];
  const abbrevPattern = abbreviations.join('|');
  
  // Capitalize after sentence-ending punctuation, but not after abbreviations
  const result = normalized.replace(/(\.\s+|\?\s+|!\s+|^\s+)([a-z])/g, (match, prefix, letter) => {
    // Check if we're after an abbreviation (look back up to 3 characters)
    const beforeMatch = normalized.substring(0, normalized.indexOf(match) + prefix.length - 2);
    if (new RegExp(`(${abbrevPattern})\.?$`, 'i').test(beforeMatch.slice(-10))) {
      return prefix + letter; // Don't capitalize if after abbreviation
    }
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize the very first character if it's a letter
  if (result.length > 0 && /[a-z]/.test(result[0])) {
    return result[0].toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * Extract all URLs from the text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  const urlRegex = /\b(?:https?:\/\/|www\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}(?:[^\s.,!?;:'")\]\}]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation marks commonly found at sentence end
    return url.replace(/[.,!?;:'")\]\}]+$/g, '');
  });
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Match http:// but not https:// using word boundary
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs and extract components
  // We'll handle this in multiple steps for better control
  
  return text.replace(/(https?:\/\/)([^\s\/]+)(\/[^\s]*)/g, (match, scheme, host, path) => {
    // Always upgrade to https
    const secureScheme = 'https://';
    
    // Check if we should skip host rewrite (legacy extensions, query strings, cgi-bin)
    const shouldSkipHostRewrite = /\/(cgi-bin\b|[^\s]*\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)|[^\s]*\?|[^\s]*&)/.test(path);
    
    // Only rewrite for example.com and docs paths when not skipping
    if (host === 'example.com' && path.startsWith('/docs/') && !shouldSkipHostRewrite) {
      return secureScheme + 'docs.example.com' + path;
    }
    
    // Just upgrade the scheme for all other cases
    return secureScheme + host + path;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' for invalid formats or impossible dates.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day/month combinations (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Simple leap year check
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  const maxDays = month === 2 ? (isLeapYear ? 29 : 28) : daysInMonth[month - 1];
  
  if (day > maxDays) return 'N/A';
  
  return year;
}
