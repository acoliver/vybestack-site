import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from '../../src/server.js';

let server: import('http').Server;
let closeServer: () => Promise<void>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const { server: srv, closeServer: close } = await createServer();
  server = srv;
  closeServer = close;
});

afterAll(async () => {
  if (closeServer) {
    await closeServer();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    const $ = cheerio.load(response.text || '');

    // Check for all required fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check that labels are properly associated
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);

    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(server)
      .post('/submit')
      .type('form')
      .send(formData);

    // Should redirect with 302
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/\/thank-you/);

    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid data', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        email: 'not-an-email',
        phone: 'invalid-phone!@#'
      });

    // Should return 400 and render form with errors
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text || '');
    
    // Check for error messages
    expect($('.error-list').length).toBeGreaterThan(0);
    expect(response.text).toMatch(/required/i);
  });

  it('renders thank you page', async () => {
    const response = await request(server).get('/thank-you?firstName=Jane');
    expect(response.status).toBe(200);
    expect(response.text).toMatch(/Thank you/i);
    expect(response.text).toMatch(/Jane/);
  });

  it('accepts international phone formats', async () => {
    const testCases = [
      '+54 9 11 1234-5678',
      '+44 20 7946 0958',
      '+1 555-123-4567',
      '(555) 123-4567'
    ];

    for (const phone of testCases) {
      const response = await request(server)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone
        });

      expect(response.status).toBe(302);
    }
  });

  it('accepts international postal formats', async () => {
    const testCases = [
      'SW1A 1AA',
      'C1000',
      'B1675',
      '12345'
    ];

    for (const postalCode of testCases) {
      const response = await request(server)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode,
          country: 'Test Country',
          email: 'test@example.com',
          phone: '+1 555-123-4567'
        });

      expect(response.status).toBe(302);
    }
  });
});
