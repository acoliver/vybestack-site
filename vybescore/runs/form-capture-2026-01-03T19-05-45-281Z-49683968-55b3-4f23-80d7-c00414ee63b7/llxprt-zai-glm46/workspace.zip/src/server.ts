import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let dbInstance: Database;
  
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required.');
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required.');
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required.');
  }

  if (!data.city || data.city.trim() === '') {
    errors.push('City is required.');
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required.');
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required.');
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and hyphens.');
  }

  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required.');
  }

  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required.');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push('Please enter a valid email address.');
    }
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required.');
  } else {
    const phoneRegex = /^\+?[\d\s()-]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +.');
    }
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

async function createServer() {
  const app = express();
  const port = process.env.PORT || '0';

  // Initialize database
  db = await initializeDatabase();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // Serve static files
  app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

  // Set EJS as view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, 'templates'));

  // GET / - Render the form
  app.get('/', (req, res) => {
    res.render('form', {
      values: {},
      errors: []
    });
  });

  // POST /submit - Handle form submission
  app.post('/submit', (req, res) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone
    };

    const validation = validateFormData(formData);

    if (!validation.valid) {
      return res.status(400).render('form', {
        values: formData,
        errors: validation.errors
      });
    }

    // Insert into database
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName!.trim(),
        formData.lastName!.trim(),
        formData.streetAddress!.trim(),
        formData.city!.trim(),
        formData.stateProvince!.trim(),
        formData.postalCode!.trim(),
        formData.country!.trim(),
        formData.email!.trim(),
        formData.phone!.trim()
      ]);

      stmt.free();
      saveDatabase(db);
    }

    // Redirect to thank-you page with first name
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
  });

  // GET /thank-you - Render thank you page
  app.get('/thank-you', (req, res) => {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  });

  const server = app.listen(port, () => {
    if (port !== '0') {
      console.log(`Server listening on port ${port}`);
    }
  });

  // Graceful shutdown
  const closeServer = (): Promise<void> => {
    return new Promise((resolve) => {
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        console.log('Server closed gracefully.');
        resolve();
      });
    });
  };

  // Handle SIGTERM - only add listener once
  if (!process.listenerCount('SIGTERM')) {
    process.on('SIGTERM', closeServer);
  }

  return { server, closeServer };
}

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  createServer();
}

export { createServer, FormData, ValidationResult };
