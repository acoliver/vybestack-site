/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle common abbreviations to avoid capitalizing after them
  const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'vs.', 'etc.', 'e.g.', 'i.e.', 'U.S.', 'U.K.'];
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    
    if (capitalizeNext && /[a-zA-Z]/.test(char)) {
      result += char.toUpperCase();
      capitalizeNext = false;
      continue;
    }
    
    if (capitalizeNext && /\s/.test(char)) {
      result += char;
      continue;
    }
    
    if (capitalizeNext && !/[a-zA-Z\s]/.test(char)) {
      result += char;
      continue;
    }
    
    result += char;
    
    // Check if we should capitalize next sentence
    if (/[.!?]/.test(char)) {
      // Look ahead to skip whitespace and determine next sentence
      let j = i + 1;
      while (j < text.length && /\s/.test(text[j])) {
        j++;
      }
      if (j < text.length) {
        // Check if this isn't an abbreviation
        const potentialAbbrev = text.substring(Math.max(0, j - 4), j + 1);
        const isAbbrev = abbreviations.some(abbr => potentialAbbrev.includes(abbr));
        if (!isAbbrev) {
          capitalizeNext = true;
        }
      }
    }
  }
  
  return result;
}

/**
 * TODO: Extract all URLs from text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http(s)://, www., and domain-based URLs
  const urlRegex = /\b(?:(?:https?:\/\/|www\.)[^\s<>"'`]+|([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s<>"'`]*)?)\b/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?;:\s]+$/, '');
  });
}

/**
 * TODO: Replace http:// schemes with https://, leaving existing https:// untouched.
 */
export function enforceHttps(text: string): string {
  // Only replace http:// with https://, leave https:// as is
return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match http URLs with capturing groups for host and path
const urlRegex = new RegExp('http:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)?', 'g');
  
  return text.replace(urlRegex, (match, host, path = '') => {
    // Check if path contains dynamic hints that should prevent host rewrite
    const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // Always upgrade to https
    let newUrl = 'https://' + host;
    
    // Only rewrite host if path starts with /docs/ and has no dynamic hints
    if (path.startsWith('/docs/') && !hasQueryString && !hasDynamicHint) {
      // Extract domain and replace with docs subdomain
      const domainParts = host.split('.');
      if (domainParts.length >= 2) {
        const domain = domainParts.slice(-2).join('.');
        newUrl = 'https://docs.' + domain + path;
      } else {
        newUrl = 'https://docs.' + host + path;
      }
    } else if (path) {
      newUrl += path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract year from mm/dd/yyyy format, return N/A if invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Check for invalid dates (e.g., February 30)
  const daysInMonth = new Date(year, month, 0).getDate();
  if (day > daysInMonth) {
    return 'N/A';
  }
  
  return year.toString();
}
