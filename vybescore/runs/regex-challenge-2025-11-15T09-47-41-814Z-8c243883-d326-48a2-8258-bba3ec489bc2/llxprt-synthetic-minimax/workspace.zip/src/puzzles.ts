/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary regex with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => 
    !exceptions.some(exception => 
      match.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a pattern that captures the digit before the token
  const pattern = `(\\d)${escapedToken}`;
  const matches: string[] = [];
  const regex = new RegExp(pattern, 'gi');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    // Return the full match including the digit
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., "abab")
  // This regex looks for any 4-character sequence that repeats immediately
  if (/(..)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, explicitly exclude IPv4 addresses to prevent false positives
  // IPv4 pattern: four groups of 1-3 digits separated by dots
  const ipv4Regex = /\b\d{1,3}(\.\d{1,3}){3}\b/;
  if (ipv4Regex.test(value)) return false;
  
  // IPv6 address patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6Regex = /\b(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}\b/i;
  
  // Compressed IPv6 with :: (at least two colons total)
  // This is more complex as :: can represent multiple zero groups
  const compressedIPv6Regex = /\b(?:[a-f0-9]{1,4}:)*::(?:[a-f0-9]{1,4}:*)*\b/i;
  
  // IPv6 with embedded IPv4 (last two groups are IPv4 address)
  const embeddedIPv6Regex = /\b(?:[a-f0-9]{1,4}:){6}\d{1,3}(\.\d{1,3}){3}\b/i;
  
  // Mixed IPv6 with :: and embedded IPv4
  const mixedIPv6Regex = /\b(?:[a-f0-9]{1,4}:)*::(?:[a-f0-9]{1,4}:*){0,4}\d{1,3}(\.\d{1,3}){3}\b/i;
  
  // Check if any IPv6 pattern matches
  return fullIPv6Regex.test(value) || 
         compressedIPv6Regex.test(value) || 
         embeddedIPv6Regex.test(value) || 
         mixedIPv6Regex.test(value);
}