export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove surrounding whitespace
  const email = value.trim();
  
  // Basic email pattern that:
  // - Allows letters, numbers, dots, plus signs in local part (but not consecutive dots)
  // - Allows letters, numbers, dots, hyphens in domain part (but not starting/ending with dot or hyphen)
  // - Requires at least one dot in domain
  // - No consecutive dots anywhere
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  return emailRegex.test(email);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (basic US phone number)
  if (digits.length < 10) return false;
  
  // Must have at most 11 digits (optional +1 country code)
  if (digits.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digits.length === 11 && !digits.startsWith('1')) return false;
  
  // Extract the 10-digit number (either all 10 digits, or last 10 if 11 with country code)
  const phoneNumber = digits.length === 10 ? digits : digits.slice(1);
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check for extensions if option is enabled
  if (options?.allowExtensions) {
    // Look for extension indicators (ext, x, extension, etc.)
    const hasExtension = /(ext|x|extension)[\s]*[:\d]/i.test(value);
    if (hasExtension) return true;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens to work with just digits and punctuation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Match Argentine phone number patterns
  // Group 1: Optional country code +54
  // Group 2: Optional mobile indicator 9 (when country code is present)
  // Group 3: Optional trunk prefix 0 (when no country code)
  // Group 4: Area code (2-4 digits, first digit 1-9)
  // Group 5: Subscriber number (remaining digits)
  
  const argentinePhoneRegex = /^(?:\+54)?(?:\s*9\s*)?(?:\s*0\s*)?([2-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate that if no country code is present, trunk prefix 0 was included
  if (!normalized.startsWith('+54')) {
    // Must have trunk prefix 0
    if (!value.trim().startsWith('0')) return false;
  }
  
  // Check that the total digits are reasonable (area + subscriber)
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-ɏḀ-ỿ]/.test(value)) return false;
  
  // Must not contain digits
  if (/[0-9]/.test(value)) return false;
  
  // Must not contain other symbols except apostrophes, hyphens, and spaces
  // Pattern allows:
  // - Unicode letters (including accented characters)
  // - Spaces
  // - Apostrophes (')
  // - Hyphens (-)
  // But rejects digits and other special characters
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF\s'-]+$/;
  
  // Additional check to reject obviously fake names like "X Æ A-12"
  if (/\b[A-Z]\s*Æ\s*[A-Z]\b|\b[A-Z]-[0-9]{1,3}\b/.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * Helper function to calculate Luhn checksum
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers using Luhn algorithm and proper prefix/length validation.
 */
export function isValidCreditCard(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check for valid credit card prefixes
  // Visa: starts with 4, 13, 16, 19 digits
  const isVisa = /^4\d{12}(\d{3})?(\d{3})?$/.test(digits);
  
  // MasterCard: starts with 51-55, 16 digits
  const isMasterCard = /^5[1-5]\d{14}$/.test(digits);
  
  // American Express: starts with 34 or 37, 15 digits  
  const isAmEx = /^3[47]\d{13}$/.test(digits);
  
  if (!isVisa && !isMasterCard && !isAmEx) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
