/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<unknown>> // Track multiple observers
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Computed also needs to act as both Observer and Subject
export type ComputedR = ObserverR & SubjectR

export type ComputedV<T> = {
  value: T | undefined
  updateFn: UpdateFn<T>
  equalFn?: EqualFn<T>
}

export type Computed<T> = ComputedR & ComputedV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers.add(observer)
}

export function removeObserver<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.observers.delete(observer)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  for (const observer of subject.observers) {
    updateObserver(observer as Observer<unknown>)
  }
}

// For computed values, add observer to the computed's observer set
export function addComputedObserver<T>(computed: Computed<T>, observer: Observer<unknown>): void {
  computed.observers.add(observer)
}

// For computed values, remove observer from the computed's observer set
export function removeComputedObserver<T>(computed: Computed<T>, observer: Observer<unknown>): void {
  computed.observers.delete(observer)
}

// For computed values, notify all observers
export function notifyComputedObservers<T>(computed: Computed<T>): void {
  for (const observer of computed.observers) {
    updateObserver(observer as Observer<unknown>)
  }
}
