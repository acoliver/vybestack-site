/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  addObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(s, observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = s.equalFn ? 
      !s.equalFn(s.value, nextValue) : 
      s.value !== nextValue
    
    if (shouldUpdate) {
      s.value = nextValue
      // Copy observers to array to avoid issues if observers modify during iteration
      const observersToUpdate = Array.from(s.observers)
      for (const observer of observersToUpdate) {
        updateObserver(observer as Observer<unknown>)
      }
    }
    return s.value
  }

  return [read, write]
}
