/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Computed,
  addComputedObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const c: Computed<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    updateFn,
    equalFn: undefined,
  }

  const computed: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      addComputedObserver(c, currentObserver as Observer<unknown>)
    }
    
    // Store previous value to detect changes
    const previousValue = c.value
    updateObserver(c)
    
    // Only notify observers if the value actually changed
    if (previousValue !== c.value && c.observers.size > 0) {
      const observersToNotify = Array.from(c.observers)
      for (const observer of observersToNotify) {
        updateObserver(observer as Observer<unknown>)
      }
    }
    
    return c.value!
  }

  return computed
}
