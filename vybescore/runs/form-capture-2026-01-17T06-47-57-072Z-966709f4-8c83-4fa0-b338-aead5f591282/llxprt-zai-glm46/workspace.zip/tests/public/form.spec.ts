import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app } from '../../src/server.js';

let server: ReturnType<typeof app.listen>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  server = app.listen(0); // Use random available port for tests
});

afterAll((done) => {
  if (server && server.close) {
    server.close(done);
  } else {
    done();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check form exists
    expect($('form[action="/submit"]').length).toBe(1);
    
    // Check all required fields exist with proper labels
    const expectedFields = [
      { id: 'firstName', label: 'First Name' },
      { id: 'lastName', label: 'Last Name' },
      { id: 'streetAddress', label: 'Street Address' },
      { id: 'city', label: 'City' },
      { id: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', label: 'Postal / Zip Code' },
      { id: 'country', label: 'Country' },
      { id: 'email', label: 'Email Address' },
      { id: 'phone', label: 'Phone Number' }
    ];
    
    for (const field of expectedFields) {
      expect($(`#${field.id}`).length).toBe(1);
      expect($(`label[for="${field.id}"]`).text()).toContain(field.label);
      expect($(`#${field.id}`).attr('name')).toBe(field.id);
    }
  });

  it('shows validation errors for empty fields', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({});
    
    expect([200, 400]).toContain(response.status);
    
    const $ = cheerio.load(response.text);
    expect($('.alert-error').length).toBe(1);
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('shows validation errors for invalid email', async () => {
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'invalid-email',
        phone: '+44 20 7946 0958'
      });
    
    expect([200, 400]).toContain(response.status);
    
    const $ = cheerio.load(response.text);
    expect($('.alert-error').length).toBe(1);
    expect($('.alert-error').text().toLowerCase()).toContain('email');
  });

  it('accepts international phone formats', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const testCases = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 555-123-4567'
    ];
    
    for (const phone of testCases) {
      const response = await request(server)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: 'T35T123',
          country: 'Test Country',
          email: 'test@example.com',
          phone: phone
        });
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('accepts various postal code formats', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const testCases = [
      'SW1A 1AA',     // UK
      'C1000',        // Argentina
      'B1675',        // Argentina
      '12345',        // US
      'A1B 2C3'       // Canada
    ];
    
    for (const postalCode of testCases) {
      const response = await request(server)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: postalCode,
          country: 'Test Country',
          email: `test${postalCode.replace(/\s/g, '')}@example.com`,
          phone: '+1 555-123-4567'
        });
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Avenue',
      city: 'Manchester',
      stateProvince: 'England',
      postalCode: 'M1 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 161 234 5678'
    };
    
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page with humorous content', async () => {
    const response = await request(server).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for key humorous elements
    expect($('body').text().toLowerCase()).toContain('stranger');
    expect($('body').text().toLowerCase()).toMatch(/spam|email/);
    expect($('.thank-you-icon').length).toBe(1);
    expect($('a[href="/"]').length).toBeGreaterThanOrEqual(1);
  });

  it('maintains form values on validation error', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'invalid-email-format',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(server)
      .post('/submit')
      .type('form')
      .send(formData);
    
    const $ = cheerio.load(response.text);
    
    expect($('#firstName').val()).toBe('John');
    expect($('#lastName').val()).toBe('Doe');
    expect($('#city').val()).toBe('London');
    expect($('#email').val()).toBe('invalid-email-format');
  });
});
