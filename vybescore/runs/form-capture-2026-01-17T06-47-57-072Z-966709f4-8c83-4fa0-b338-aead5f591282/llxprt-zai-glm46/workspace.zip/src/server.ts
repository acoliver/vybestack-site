import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const app = express();
const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join('src', 'views'));

// Initialize database
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();
  
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }
  
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  db.run(schema);
  
  // Export immediately to ensure file exists
  saveDatabase();
}

function saveDatabase(): void {
  if (!db) throw new Error('Database not initialized');
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Validation
interface ValidationError {
  field: string;
  message: string;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^[+\d\s()\\-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(body: Record<string, unknown>): { isValid: boolean; errors: ValidationError[]; data?: FormData } {
  const errors: ValidationError[] = [];
  
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    const value = body[field] || '';
    const strValue = typeof value === 'string' ? value : String(value);
    if (!value || strValue.trim().length === 0) {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').trim()} is required` });
    }
  }
  
  const emailValue = typeof body.email === 'string' ? body.email : '';
  if (emailValue && !validateEmail(emailValue)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  const phoneValue = typeof body.phone === 'string' ? body.phone : '';
  if (phoneValue && !validatePhone(phoneValue)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number (min 7 characters)' });
  }
  
  const postalValue = typeof body.postalCode === 'string' ? body.postalCode : '';
  if (postalValue && !validatePostalCode(postalValue)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }
  
  if (errors.length > 0) {
    return { isValid: false, errors };
  }
  
  const data: FormData = {
    firstName: String(body.firstName).trim(),
    lastName: String(body.lastName).trim(),
    streetAddress: String(body.streetAddress).trim(),
    city: String(body.city).trim(),
    stateProvince: String(body.stateProvince).trim(),
    postalCode: String(body.postalCode).trim(),
    country: String(body.country).trim(),
    email: String(body.email).trim(),
    phone: String(body.phone).trim()
  };
  
  return { isValid: true, errors: [], data };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', { 
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validation = validateForm(req.body);
  
  if (!validation.isValid) {
    return res.status(400).render('index', {
      errors: validation.errors,
      formData: req.body
    });
  }
  
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const data = validation.data;
  if (!data) {
    throw new Error('Validation data is missing');
  }
  
  db.run(
    `INSERT INTO submissions 
     (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]
  );
  
  saveDatabase();
  
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handler
app.use((err: Error, req: Request, res: Response) => {
  console.error(err);
  res.status(500).send('Internal Server Error');
});

// Start server
async function start(): Promise<void> {
  await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  // Graceful shutdown
  const shutdown = () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      process.exit(0);
    });
    
    // Force shutdown after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };
  
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

start().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

export { app, initDatabase, saveDatabase };
