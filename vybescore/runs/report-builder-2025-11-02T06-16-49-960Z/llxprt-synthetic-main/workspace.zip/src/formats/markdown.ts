import type { ReportData, ReportRenderer, RenderOptions } from '../types.js';

/**
 * Markdown formatter implementation
 */
export class MarkdownRenderer implements ReportRenderer {
  render(data: ReportData, options: RenderOptions = { includeTotals: false }): string {
    const lines: string[] = [];
    
    // Title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary
    if (data.summary) {
      lines.push(data.summary);
      lines.push('');
    }
    
    // Entries section
    lines.push('## Entries');
    
    // Entry list
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`**Total:** $${total.toFixed(2)}`);
    }
    
    return lines.join('\n');
  }
}

// Export a singleton for convenience
export const renderMarkdown = (data: ReportData, options?: RenderOptions): string => {
  const renderer = new MarkdownRenderer();
  return renderer.render(data, options);
};