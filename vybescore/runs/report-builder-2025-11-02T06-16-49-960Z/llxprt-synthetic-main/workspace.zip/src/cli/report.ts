#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Format handler mapping
const formatters: Record<string, (data: ReportData, options?: RenderOptions) => string> = {
  markdown: renderMarkdown,
  text: renderText,
};

// Parse command line arguments
function parseArguments(): {
  filePath?: string;
  format?: string;
  outputPath?: string;
  includeTotals: boolean;
  errors: string[];
} {
  const args = process.argv.slice(2);
  const result = {
    filePath: undefined as string | undefined,
    format: undefined as string | undefined,
    outputPath: undefined as string | undefined,
    includeTotals: false,
    errors: [] as string[],
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i < args.length) {
        result.format = args[i];
      } else {
        result.errors.push('Missing value for --format option');
      }
    } else if (arg === '--output') {
      i++;
      if (i < args.length) {
        result.outputPath = args[i];
      } else {
        result.errors.push('Missing value for --output option');
      }
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!result.filePath) {
      // First non-option argument is the file path
      result.filePath = arg;
    } else {
      result.errors.push(`Unexpected argument: ${arg}`);
    }
    i++;
  }

  return result;
}

// Load and validate JSON data
function loadReportData(filePath: string): ReportData {
  try {
    const fullPath = path.resolve(filePath);
    if (!fs.existsSync(fullPath)) {
      throw new Error(`File not found: ${fullPath}`);
    }
    
    const fileContent = fs.readFileSync(fullPath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    // Validate the data structure
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: "title" is required and must be a string');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: "summary" is required and must be a string');
    }
    
    if (!Array.isArray(data.entries) || data.entries.length === 0) {
      throw new Error('Invalid data: "entries" must be a non-empty array');
    }
    
    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: "label" is required and must be a string`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: "amount" is required and must be a number`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON format: ${error.message}`);
    }
    throw error;
  }
}

// Main function
function main(): void {
  const { filePath, format, outputPath, includeTotals, errors } = parseArguments();
  
  // Report parsing errors
  if (errors.length > 0) {
    console.error('Error parsing arguments:');
    for (const error of errors) {
      console.error(`  ${error}`);
    }
    process.exit(1);
  }
  
  // Check required arguments
  if (!filePath) {
    console.error('Error: Missing required argument: path to JSON data file');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  if (!format) {
    console.error('Error: Missing required option: --format');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  // Check if format is supported
  if (!formatters[format]) {
    console.error(`Error: Unsupported format: ${format}`);
    process.exit(1);
  }
  
  try {
    // Load and process data
    const data = loadReportData(filePath);
    const options: RenderOptions = { includeTotals };
    const output = formatters[format](data, options);
    
    // Write output
    if (outputPath) {
      const fullPath = path.resolve(outputPath);
      fs.writeFileSync(fullPath, output, 'utf-8');
      console.log(`Report written to ${fullPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

// Run the CLI
main();