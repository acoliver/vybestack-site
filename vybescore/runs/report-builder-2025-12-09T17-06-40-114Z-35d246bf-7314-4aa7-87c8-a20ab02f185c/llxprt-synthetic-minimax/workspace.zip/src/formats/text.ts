import { ReportData, RenderOptions, Formatter } from '../types/report.js';
import { calculateTotal, formatAmount } from '../utils/dataParser.js';

export const renderText: Formatter = {
  render(data: ReportData, options: RenderOptions): string {
    let output = `${data.title}\n\n`;
    output += `${data.summary}\n\n`;
    output += `Entries:\n\n`;
    
    // Add entries as bullet list
    data.entries.forEach(entry => {
      output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
    });
    
    // Add totals if requested
    if (options.includeTotals) {
      output += `\nTotal: ${formatAmount(calculateTotal(data.entries))}\n`;
    }
    
    return output;
  }
};