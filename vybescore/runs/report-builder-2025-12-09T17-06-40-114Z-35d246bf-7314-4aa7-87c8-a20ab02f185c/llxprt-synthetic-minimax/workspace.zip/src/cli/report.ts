#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { parseReportData } from '../utils/dataParser.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { CliOptions, Formatter } from '../types/report.js';

function parseArgs(argv: string[]): { dataFile: string; options: CliOptions } {
  if (argv.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  const options: CliOptions = {
    format: 'markdown', // default
    includeTotals: false
  };

  // Parse remaining arguments
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= argv.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        options.format = argv[i + 1] as 'markdown' | 'text';
        if (options.format !== 'markdown' && options.format !== 'text') {
          console.error(`Error: Unsupported format: ${options.format}`);
          process.exit(1);
        }
        i++; // Skip next argument as it's the format value
        break;
        
      case '--output':
        if (i + 1 >= argv.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        options.output = argv[i + 1];
        i++; // Skip next argument as it's the output path
        break;
        
      case '--includeTotals':
        options.includeTotals = true;
        break;
        
      default:
        if (arg.startsWith('--')) {
          console.error(`Error: Unknown option: ${arg}`);
          process.exit(1);
        }
        // Ignore positional arguments after the first one
        break;
    }
  }

  return { dataFile, options };
}

function getFormatter(format: 'markdown' | 'text'): Formatter {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv);
    
    // Load and parse data
    const reportData = parseReportData(dataFile);
    
    // Get appropriate formatter
    const formatter = getFormatter(options.format);
    
    // Render the report
    const output = formatter.render(reportData, { includeTotals: options.includeTotals });
    
    // Write output
    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
    
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();