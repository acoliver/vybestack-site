import { readFileSync } from 'node:fs';
import { ReportData } from '../types/report.js';

export function parseReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const rawData = JSON.parse(fileContent);
    
    // Validate required fields
    if (typeof rawData.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (typeof rawData.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(rawData.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    const entries = rawData.entries.map((entry: unknown, index: number) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Entry ${index}: must be an object`);
      }
      
      const typedEntry = entry as { label?: unknown; amount?: unknown };
      
      if (typeof typedEntry.label !== 'string') {
        throw new Error(`Entry ${index}: missing or invalid "label" field`);
      }
      
      if (typeof typedEntry.amount !== 'number' || isNaN(typedEntry.amount)) {
        throw new Error(`Entry ${index}: missing or invalid "amount" field`);
      }
      
      return {
        label: typedEntry.label,
        amount: typedEntry.amount
      };
    });
    
    return {
      title: rawData.title,
      summary: rawData.summary,
      entries
    };
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT')) {
        throw new Error(`File not found: ${filePath}`);
      }
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    throw new Error('Unknown error parsing data file');
  }
}

export function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((total, entry) => total + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}