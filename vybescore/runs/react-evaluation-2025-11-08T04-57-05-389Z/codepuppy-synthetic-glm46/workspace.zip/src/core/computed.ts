/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  ObserverV,
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T>
  
  if (equal === undefined) {
    equalFn = (a, b) => a === b
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (a, b) => a === b : () => false
  } else {
    equalFn = equal
  }

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => {
      // Recompute and notify our own observers if the value changed
      const newValue = updateFn()
      if (!equalFn(observer.value as T, newValue)) {
        observer.value = newValue
        // Notify observers that depend on this computed value
        notifyComputedObservers()
      }
      return newValue
    },
  }

  // This computed value's observers (things that depend on this computed)
  const computedObservers = new Set<ObserverR & ObserverV<unknown>>()
  
  function notifyComputedObservers() {
    for (const observer of computedObservers) {
      if (!observer.disposed) {
        updateObserver(observer)
      }
    }
  }
  
  // Initial computation to establish dependencies
  updateObserver(observer)
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && !activeObserver.disposed) {
      // Something is accessing this computed value, so register as dependent
      computedObservers.add(activeObserver)
    }
    return observer.value as T
  }
  
  return getter
}