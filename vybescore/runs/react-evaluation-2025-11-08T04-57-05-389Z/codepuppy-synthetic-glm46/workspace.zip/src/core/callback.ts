/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    disposed: false,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  const unsubscribe = () => {
    if (observer.disposed) return
    
    // Mark as disposed to prevent further updates
    observer.disposed = true
  }
  
  return unsubscribe
}