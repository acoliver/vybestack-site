import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number) {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;

    async function load() {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        // Pass page and limit as query parameters
        const searchParams = new URLSearchParams({
          page: page.toString(),
          limit: limit.toString()
        });
        const response = await fetch(`/inventory?${searchParams}`);
        if (!response.ok) {
          // Try to get error message from response
          let errorMessage = `Request failed with status ${response.status}`;
          try {
            const errorResponse = await response.json();
            errorMessage = errorResponse.error || errorMessage;
          } catch {
            // Ignore JSON parsing errors for error response
          }
          throw new Error(errorMessage);
        }
        const payload = (await response.json()) as InventoryPage;
        if (!cancelled) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    // Always reload when page or limit changes, not just when idle
    load();

    return () => {
      cancelled = true;
    };
    // Fixed: Add page and limit dependencies to trigger reloads when they change
  }, [page, limit]);

  return state;
}
