import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(__dirname, '..');
const DB_PATH = path.resolve(PROJECT_ROOT, 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(PROJECT_ROOT, 'db', 'schema.sql');

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(PROJECT_ROOT, 'public')));

app.set('views', path.resolve(PROJECT_ROOT, 'src', 'templates'));
app.set('view engine', 'ejs');

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+@]?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim();
    if (!value) {
      errors.push(`${field} is required`);
    }
  }

  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading + or @');
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Postal code can only contain letters, digits, spaces, and dashes');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  let dbInstance: Database;
  
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    persistDatabase(dbInstance);
  }
  
  return dbInstance;
}

function persistDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  const dir = path.dirname(DB_PATH);
  
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(DB_PATH, buffer);
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  if (!db) {
    return res.status(500).render('form', {
      errors: ['Database not available'],
      values: formData,
    });
  }

  try {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName || '',
        formData.lastName || '',
        formData.streetAddress || '',
        formData.city || '',
        formData.stateProvince || '',
        formData.postalCode || '',
        formData.country || '',
        formData.email || '',
        formData.phone || '',
      ]
    );

    persistDatabase(db);

    return res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: ['Failed to save submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

let server: ReturnType<typeof app.listen>;

export { app };

export async function startServer(): Promise<typeof server> {
  db = await initializeDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  return server;
}

export async function stopServer(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
  
  if (server) {
    return new Promise((resolve) => {
      server.close(() => {
        console.log('Server closed');
        resolve();
      });
    });
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });

  process.on('SIGTERM', async () => {
    console.log('SIGTERM received, shutting down gracefully');
    await stopServer();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.log('SIGINT received, shutting down gracefully');
    await stopServer();
    process.exit(0);
  });
}
