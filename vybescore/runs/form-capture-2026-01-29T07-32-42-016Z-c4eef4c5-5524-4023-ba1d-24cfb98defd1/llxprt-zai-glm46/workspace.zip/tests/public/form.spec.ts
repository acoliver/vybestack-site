import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer, stopServer } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await startServer();
});

afterAll(async () => {
  await stopServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'invalid-phone!',
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Testland',
        email: 'not-an-email',
        phone: '1234567890',
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('email');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Testland',
        email: 'test@example.com',
        phone: 'invalid@phone#',
      });

    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('Phone');
  });

  it('accepts international phone formats', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Carlos',
        lastName: 'Garcia',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'carlos@example.com',
        phone: '+54 9 11 1234-5678',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts UK postal codes', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Smith',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: '+44 20 7946 0958',
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('.thankyou-card').length).toBe(1);
    expect($('h1').text()).toMatch(/Thank you/i);
  });
});
