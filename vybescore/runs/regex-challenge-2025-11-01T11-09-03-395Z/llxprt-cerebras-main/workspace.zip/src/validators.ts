export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with additional checks for edge cases
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for double dots, trailing dots, and underscores in domain
  if (!value || value.includes('..') || value.endsWith('.') || /@.*_/.test(value)) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for length check
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it has enough digits
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Check if 11 digits start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract the 10-digit part (area code + number)
  const phoneDigits = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Check for valid area code (not starting with 0 or 1)
  if (phoneDigits.charAt(0) === '0' || phoneDigits.charAt(0) === '1') {
    return false;
  }
  
  // Validate format with regex
  const phoneRegex = /^(\+?1\s?)?(\([0-9]{3}\)|[0-9]{3})[\s\-]?[0-9]{3}[\s\-]?[0-9]{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Handle different formats
  let digitsOnly = cleanValue;
  
  // Check for +54 prefix
  if (cleanValue.startsWith('+54')) {
    digitsOnly = cleanValue.substring(3);
  } else if (!cleanValue.startsWith('0')) {
    // If no country code and no trunk prefix, it's invalid
    return false;
  } else {
    // Remove trunk prefix (0)
    digitsOnly = cleanValue.substring(1);
  }
  
  // Check for mobile indicator (9)
  if (digitsOnly.startsWith('9')) {
    digitsOnly = digitsOnly.substring(1);
  }
  
  // Check area code (2-4 digits starting with 1-9)
  const areaCodeMatch = /^([1-9][0-9]{1,3})/.exec(digitsOnly);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const remaining = digitsOnly.substring(areaCode.length);
  
  // Check subscriber number (6-8 digits)
  if (remaining.length < 6 || remaining.length > 8 || !/^[0-9]+$/.test(remaining)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // Unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  // Reject names with digits or symbols
  if (/[0-9]/.test(value) || /X.*Æ.*A-12/i.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check for valid card prefixes and lengths
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;          // 13 or 16 digits starting with 4
  const mastercardRegex = /^5[1-5][0-9]{14}$/;            // 16 digits starting with 51-55
  const amexRegex = /^3[47][0-9]{13}$/;                   // 15 digits starting with 34 or 37
  
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Luhn algorithm implementation
  return runLuhnCheck(cleanValue);
}

/**
 * Implementation of the Luhn algorithm for credit card validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}