/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // Split text into sentences based on punctuation followed by space or end of string
  // This regex looks for sentence endings (.?!)+ followed by whitespace or end of string
  return text.replace(/(^|[.?!]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  }).replace(/\s+/g, ' '); // Collapse multiple spaces into single space
}

/**
 * Extracts URLs from text.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - matches http/https URLs
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/gi;
  const matches = text.match(urlRegex);
  return matches ? matches.map(url => url.replace(/[.!?]+$/, '')) : []; // Remove trailing punctuation
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/.
 */
export function rewriteDocsUrls(text: string): string {
  // Regex to match http URLs with docs path but without dynamic components
  const docsUrlRegex = /http:\/\/([^/\s]+)(\/docs\/[^?\s]*)/gi;
  
  // Replace matching URLs with docs subdomain
  return text.replace(docsUrlRegex, (match, host, path) => {
    // Check if path contains dynamic components that should prevent host rewrite
    if (path.includes('cgi-bin') || 
        /[?&=]/.test(path) || 
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$)/i.test(path)) {
      // Host rewrite skipped but still upgrade to https
      return `https://${host}${path}`;
    }
    // Rewrite to docs subdomain and upgrade to https
    return `https://docs.${host}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}