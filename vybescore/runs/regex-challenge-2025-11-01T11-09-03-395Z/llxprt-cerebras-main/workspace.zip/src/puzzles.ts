/**
 * Finds words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // Use word boundaries to ensure we match complete words
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookbehind to ensure token follows a digit and is not at the start of the string
  // Use lookahead to ensure token is a complete word (not part of another word)
  const regex = new RegExp(`(?<=\\d)${token}(?!\\w)`, 'gi');
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * Validates passwords according to the policy.
 */
export function isStrongPassword(value: string): boolean {
  // Check if password meets all criteria:
  // At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace
  if (value.length < 10 || 
      !/[A-Z]/.test(value) || 
      !/[a-z]/.test(value) || 
      !/\d/.test(value) || 
      !/[!@#$%^&*(),.?":{}|<>]/.test(value) || 
      /\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This regex looks for any sequence of characters repeated immediately
  const repeatedSequenceRegex = /(.+)\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  // Basic IPv6 pattern (0000:0000:0000:0000:0000:0000:0000:0000)
  // Also handle compressed format (::) and mixed format (IPv6:IPv4)
  const ipv6Regex = /(?:::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){7}|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}::(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|::(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))/g;
  
  // IPv4 regex pattern (to exclude)
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // Check if string contains IPv6 addresses
  const ipv6Matches = value.match(ipv6Regex);
  
  // If there are IPv6 matches and no IPv4 matches, return true
  if (ipv6Matches && ipv6Matches.length > 0 && !ipv4Regex.test(value)) {
    return true;
  }
  
  return false;
}