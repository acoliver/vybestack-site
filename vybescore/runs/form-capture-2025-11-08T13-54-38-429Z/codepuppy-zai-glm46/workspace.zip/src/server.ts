import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

// Types for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  public app: express.Application;
  private db: Database | null = null;
  private server: import('http').Server | null = null;
  private dataDir: string;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dataDir = path.resolve('data');
    this.dbPath = path.join(this.dataDir, 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Serve static files from public directory
    this.app.use('/public', express.static(path.resolve('public')));
    
    // Parse URL-encoded bodies (as sent by HTML forms)
    this.app.use(express.urlencoded({ extended: true }));
    
    // Set view engine to EJS
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve('src', 'templates'));
  }

  private setupRoutes(): void {
    // Form page
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // Form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        await this.ensureDatabaseInitialized();
        
        const formData = req.body as FormData;
        const errors = this.validateFormData(formData);
        
        if (errors.length > 0) {
          const errorMessages = errors.map(err => err.message);
          res.status(400).render('form', {
            errors: errorMessages,
            values: formData
          });
          return;
        }

        // Insert into database
        this.insertSubmission(formData);
        
        // Redirect to thank you page
        res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
      } catch (error) {
        console.error('Error handling submission:', error);
        res.status(500).render('form', {
          errors: ['Internal server error. Please try again.'],
          values: req.body
        });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  private validateFormData(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field].trim().length === 0) {
        errors.push({
          field,
          message: this.getFieldLabel(field) + ' is required'
        });
      }
    }

    // Email validation (simple regex for plausibility)
    if (data.email && data.email.trim().length > 0) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation (international formats)
    if (data.phone && data.phone.trim().length > 0) {
      const phoneRegex = /^[+]?[\d\s()-]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({
          field: 'phone',
          message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +'
        });
      }
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && data.postalCode.trim().length > 0) {
      const postalRegex = /^[\d\sA-Za-z-]+$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({
          field: 'postalCode',
          message: 'Postal code can only contain letters, numbers, spaces, and dashes'
        });
      }
    }

    return errors;
  }

  private getFieldLabel(field: keyof FormData): string {
    const labels: Record<keyof FormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return labels[field] || field;
  }

  private async ensureDatabaseInitialized(): Promise<void> {
    if (this.db) {
      return;
    }

    // Create data directory if it doesn't exist
    if (!fs.existsSync(this.dataDir)) {
      fs.mkdirSync(this.dataDir, { recursive: true });
    }

    // Initialize SQL.js
    const SQL = await initSqlJs();
    
    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const dbFile = fs.readFileSync(this.dbPath);
      this.db = new SQL.Database(dbFile);
    } else {
      this.db = new SQL.Database();
      // Create tables using schema
      const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
      this.db.run(schema);
    }
  }

  private insertSubmission(data: FormData): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        data.firstName.trim(),
        data.lastName.trim(),
        data.streetAddress.trim(),
        data.city.trim(),
        data.stateProvince.trim(),
        data.postalCode.trim(),
        data.country.trim(),
        data.email.trim(),
        data.phone.trim()
      ]);
    } finally {
      stmt.free();
    }

    // Write database back to disk
    this.saveDatabase();
  }

  private saveDatabase(): void {
    if (!this.db) {
      return;
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  public async start(): Promise<number> {
    const preferredPort = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(preferredPort, () => {
        const serverAddress = this.server?.address();
        const actualPort = (serverAddress && typeof serverAddress === 'object' ? serverAddress.port : preferredPort);
        console.log(`Friendly form server listening on port ${actualPort}`);
        resolve(actualPort);
      });

      this.server?.on('error', (err: NodeJS.ErrnoException) => {
        if (err.code === 'EADDRINUSE') {
          // If preferred port is in use, try port 0 (random available port)
          this.server = this.app.listen(0, () => {
            const serverAddress = this.server?.address();
            const actualPort = serverAddress && typeof serverAddress === 'object' ? serverAddress.port : 0;
            console.log(`Friendly form server listening on port ${actualPort}`);
            resolve(actualPort);
          });
        } else {
          reject(err);
        }
      });

      // Handle graceful shutdown
      process.on('SIGTERM', () => this.shutdown());
      process.on('SIGINT', () => this.shutdown());
    });
  }

  private shutdown(): void {
    console.log('Shutting down friendly form server...');
    
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed');
      });
    }
  }

  // For testing purposes, allow manual shutdown without process.exit
  public async shutdownAsync(): Promise<void> {
    return new Promise((resolve) => {
      console.log('Shutting down friendly form server...');
      
      if (this.db) {
        this.db.close();
        this.db = null;
      }
      
      if (this.server) {
        this.server.close(() => {
          console.log('Server closed');
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
}

// Start the server
const server = new FormServer();
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for testing
export { FormServer };