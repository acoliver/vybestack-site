import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { FormServer } from '../../src/server';

let server: FormServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');
import express from 'express';

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Set a different port for testing to avoid conflicts
  process.env.PORT = '3001';
  
  // Start the server for testing
  server = new FormServer();
  await server.start();
  
  // Get the express app for testing
  app = server.app;
});

afterAll(async () => {
  if (server && server.shutdownAsync) {
    await server.shutdownAsync();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = cheerio.load(response.text || '');
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check for form submission button
    expect($('button[type="submit"]')).toHaveLength(1);
    
    // Check that the form POSTs to /submit
    expect($('form[method="post"][action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    // Submit the form
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank-you
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
    
    // Check that database was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow the redirect
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('John');
  });

  it('handles validation errors', async () => {
    const invalidData = {
      firstName: '', // Missing required field
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email', // Invalid email
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(invalidData);
    
    // Should re-render form with errors
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('valid email address');
  });

  it('accepts international postal codes', async () => {
    const testData = [
      { postalCode: 'SW1A 1AA', country: 'UK' },
      { postalCode: 'C1000', country: 'Argentina' },
      { postalCode: 'B1675', country: 'Argentina' },
      { postalCode: '90210', country: 'USA' }
    ];
    
    for (const { postalCode, country } of testData) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode,
        country,
        email: 'test@example.com',
        phone: '+1 555-123-4567'
      };
      
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(formData);
      expect(response.status).toBe(302);
    }
  });

  it('accepts international phone numbers', async () => {
    const testPhones = [
      '+44 20 7946 0958', // UK
      '+54 9 11 1234-5678', // Argentina
      '+1 (555) 123-4567', // USA
      '+86 10 1234 5678' // China
    ];
    
    for (const phone of testPhones) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone
      };
      
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(formData);
      expect(response.status).toBe(302);
    }
  });
});