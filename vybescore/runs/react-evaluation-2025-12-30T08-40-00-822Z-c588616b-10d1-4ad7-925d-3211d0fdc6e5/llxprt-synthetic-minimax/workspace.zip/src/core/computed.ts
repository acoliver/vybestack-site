/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  Subject,
  notifyObservers,
  setActiveObserver
} from "../types/reactive.js"

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn: undefined,
  }

  const getter = (): T => {
    // Set this observer as the active observer to establish dependencies
    setActiveObserver(observer)
    try {
      // Re-evaluate to get the current value and establish dependencies
      updateObserver(observer)
      const newValue = observer.value as T
      
      // Notify observers if value changed
      if (newValue !== subject.value) {
        subject.value = newValue
        notifyObservers(subject)
      }
      
      return newValue
    } finally {
      // Reset the active observer
      setActiveObserver(undefined)
    }
  }

  // For computed values with no dependencies, evaluate once
  if (value !== undefined) {
    observer.value = updateFn(value)
    subject.value = observer.value as T
  }

  return getter
}