/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  setActiveObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    disposed: false,
    value,
    updateFn,
  }

  const runCallback = (): void => {
    // Set this observer as the active observer to establish dependencies
    setActiveObserver(observer)
    try {
      // Run the callback effect to establish dependencies
      // When the callback accesses computed/input values, they will register this observer
      updateObserver(observer)
    } finally {
      // Reset the active observer
      setActiveObserver(undefined)
    }
  }

  // Initially run the callback to establish dependencies
  runCallback()

  const unsubscribe = () => {
    observer.disposed = true
  }

  return unsubscribe
}