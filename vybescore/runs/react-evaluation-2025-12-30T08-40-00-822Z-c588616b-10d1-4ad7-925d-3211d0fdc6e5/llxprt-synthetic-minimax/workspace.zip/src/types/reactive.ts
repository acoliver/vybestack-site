/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  disposed?: boolean // Add disposed flag
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Create a copy of observers to avoid issues with mutation during notification
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    // Skip disposed observers
    if (observer.disposed) {
      subject.observers.delete(observer)
      continue
    }
    
    // For computed observers (those with name), update them normally
    if (observer.name && typeof (observer as Observer<unknown>).updateFn === 'function') {
      updateObserver(observer as Observer<unknown>)
    } 
    // For callback observers (those without name), re-execute them directly
    else if (!observer.name && typeof (observer as Observer<unknown>).updateFn === 'function') {
      // Re-execute the callback to establish new dependencies and execute side effects
      const callbackObserver = observer as Observer<unknown>
      
      // Set this observer as active to establish new dependencies
      setActiveObserver(callbackObserver)
      try {
        // Re-execute the callback function which contains the side effects
        // This will establish new dependencies and execute the side effects
        callbackObserver.updateFn(callbackObserver.value)
      } finally {
        setActiveObserver(undefined)
      }
    }
  }
}