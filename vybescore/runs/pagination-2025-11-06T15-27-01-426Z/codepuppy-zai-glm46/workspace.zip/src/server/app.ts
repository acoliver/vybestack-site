import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || parsedPage <= 0 || !Number.isInteger(parsedPage)) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
      if (parsedPage > 1000) { // Prevent excessive values
        return res.status(400).json({ error: 'Page parameter exceeds maximum allowed value' });
      }
      page = parsedPage;
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || parsedLimit <= 0 || !Number.isInteger(parsedLimit)) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }
      if (parsedLimit > 100) { // Prevent excessive values
        return res.status(400).json({ error: 'Limit parameter exceeds maximum allowed value' });
      }
      limit = parsedLimit;
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
