import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Express } from 'express';
import type { Database } from 'sql.js';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
    expect(response.body).toHaveProperty('page');
    expect(response.body).toHaveProperty('limit');
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
  });

  it('returns default pagination parameters', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
  });

  it('respects custom page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBeLessThanOrEqual(3);
  });

  it('returns correct pagination metadata', async () => {
    const response = await request(app).get('/inventory?page=1&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.total).toBe(15); // Based on seed data
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.hasNext).toBe(true);
  });

  it('correctly handles pagination offsets', async () => {
    const page1Response = await request(app).get('/inventory?page=1&limit=4');
    const page2Response = await request(app).get('/inventory?page=2&limit=4');
    
    expect(page1Response.status).toBe(200);
    expect(page2Response.status).toBe(200);
    
    const page1Ids = page1Response.body.items.map((item: { id: number }) => item.id);
    const page2Ids = page2Response.body.items.map((item: { id: number }) => item.id);
    
    // Ensure no overlap between pages
    const overlappingIds = page1Ids.filter((id: number) => page2Ids.includes(id));
    expect(overlappingIds).toHaveLength(0);
    
    // Ensure sequential ordering
    expect(page1Ids).toEqual([1, 2, 3, 4]);
    expect(page2Ids).toEqual([5, 6, 7, 8]);
  });

  it('validates invalid page parameters', async () => {
    // Test negative page
    const negativeResponse = await request(app).get('/inventory?page=-1');
    expect(negativeResponse.status).toBe(400);
    expect(negativeResponse.body.error).toContain('Invalid page parameter');

    // Test zero page
    const zeroResponse = await request(app).get('/inventory?page=0');
    expect(zeroResponse.status).toBe(400);
    expect(zeroResponse.body.error).toContain('Invalid page parameter');

    // Test non-numeric page
    const textResponse = await request(app).get('/inventory?page=abc');
    expect(textResponse.status).toBe(400);
    expect(textResponse.body.error).toContain('Invalid page parameter');

    // Test excessive page
    const excessiveResponse = await request(app).get('/inventory?page=1001');
    expect(excessiveResponse.status).toBe(400);
    expect(excessiveResponse.body.error).toContain('exceeds maximum allowed value');
  });

  it('validates invalid limit parameters', async () => {
    // Test negative limit
    const negativeResponse = await request(app).get('/inventory?limit=-1');
    expect(negativeResponse.status).toBe(400);
    expect(negativeResponse.body.error).toContain('Invalid limit parameter');

    // Test zero limit
    const zeroResponse = await request(app).get('/inventory?limit=0');
    expect(zeroResponse.status).toBe(400);
    expect(zeroResponse.body.error).toContain('Invalid limit parameter');

    // Test non-numeric limit
    const textResponse = await request(app).get('/inventory?limit=abc');
    expect(textResponse.status).toBe(400);
    expect(textResponse.body.error).toContain('Invalid limit parameter');

    // Test excessive limit
    const excessiveResponse = await request(app).get('/inventory?limit=101');
    expect(excessiveResponse.status).toBe(400);
    expect(excessiveResponse.body.error).toContain('exceeds maximum allowed value');
  });

  it('correctly identifies last page', async () => {
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.hasNext).toBe(false);
    // Last page should have the remaining items (since 15 total items)
    expect(response.body.items.length).toBe(5);
  });

  it('handles page beyond available data', async () => {
    const response = await request(app).get('/inventory?page=10&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(10);
    expect(response.body.items).toHaveLength(0);
    expect(response.body.hasNext).toBe(false);
  });
});
