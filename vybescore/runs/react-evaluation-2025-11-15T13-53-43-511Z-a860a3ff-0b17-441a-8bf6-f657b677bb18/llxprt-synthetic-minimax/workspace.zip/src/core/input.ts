/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    dependents: new Set(),
  }

  const read: GetterFn<T> = () => {
    // Register dependency: observer depends on this input
    const observer = getActiveObserver()
    if (observer && s.dependents) {
      s.dependents.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Trigger updates for all dependent observers
    if (s.dependents) {
      for (const dependent of s.dependents) {
        updateObserver(dependent as Observer<T>)
      }
    }
    return s.value
  }

  return [read, write]
}
