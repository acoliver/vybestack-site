/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  let isInitialized = false

  const compute: GetterFn<T> = () => {
    const prevActive = getActiveObserver()
    setActiveObserver(o)
    
    try {
      const inputValue = !isInitialized ? value : o.value
      const newValue = updateFn(inputValue)
      
      if (!isInitialized) {
        o.value = newValue
        isInitialized = true
      } else {
        const hasChanged = o.value !== newValue
        o.value = newValue
        
        // Always notify dependents when computed value changes
        if (o.dependents) {
          for (const dependent of o.dependents) {
            if ((dependent as Observer<T>).isActive !== false) {
              updateObserver(dependent as Observer<T>)
            }
          }
        }
      }
    } finally {
      setActiveObserver(prevActive)
    }
    
    return o.value!
  }

  return compute
}
