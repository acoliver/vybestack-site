/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface BaseObserver {
  name?: string
  dependents?: Set<BaseObserver>
}

export interface ObserverWithValue<T> extends BaseObserver {
  value?: T
  updateFn: UpdateFn<T>
  isActive?: boolean
}

export type Observer<T> = ObserverWithValue<T>

export interface BaseSubject {
  name?: string
}

export interface SubjectWithValue<T> extends BaseSubject {
  value: T
  equalFn?: EqualFn<T>
  dependents?: Set<BaseObserver>
}

export type Subject<T> = SubjectWithValue<T>

let activeObserver: BaseObserver | undefined

export function getActiveObserver(): BaseObserver | undefined {
  return activeObserver
}

export function setActiveObserver(observer: BaseObserver | undefined): void {
  activeObserver = observer
}

export { activeObserver }

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    if (observer.isActive !== false) {
      const newValue = observer.updateFn(observer.value)
      
      // Only notify dependents if the value actually changed
      if (observer.value !== newValue) {
        observer.value = newValue
        
        // Trigger updates for all dependents after this observer is updated
        if (observer.dependents) {
          for (const dependent of observer.dependents) {
            if ((dependent as Observer<T>).isActive !== false) {
              updateObserver(dependent as Observer<T>)
            }
          }
        }
      }
    }
  } finally {
    activeObserver = previous
  }
}