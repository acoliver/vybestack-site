#!/usr/bin/env node

import * as fs from 'node:fs';
import { getFormatter } from '../formats/index.js';
import { validateReportData } from '../validator.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): CliArgs {
  if (argv.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = argv[2];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];

    if (arg === '--format') {
      i++;
      if (i >= argv.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = argv[i];
    } else if (arg === '--output') {
      i++;
      if (i >= argv.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = argv[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function main(): void {
  const args = parseArgs(process.argv);

  // Read input file
  let inputContent: string;
  try {
    inputContent = fs.readFileSync(args.inputFile, 'utf-8');
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading file "${args.inputFile}": ${error.message}`);
    } else {
      console.error(`Error reading file "${args.inputFile}"`);
    }
    process.exit(1);
  }

  // Parse JSON
  let rawData: unknown;
  try {
    rawData = JSON.parse(inputContent);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error parsing JSON: ${error.message}`);
    } else {
      console.error('Error parsing JSON');
    }
    process.exit(1);
  }

  // Validate data
  const data = validateReportData(rawData);

  // Get formatter
  let formatter: ReturnType<typeof getFormatter>;
  try {
    formatter = getFormatter(args.format);
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error(`Unsupported format: ${args.format}`);
    }
    process.exit(1);
  }

  // Render report
  const options: RenderOptions = { includeTotals: args.includeTotals };
  const output = formatter.render(data, options);

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing to file "${args.outputPath}": ${error.message}`);
      } else {
        console.error(`Error writing to file "${args.outputPath}"`);
      }
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
