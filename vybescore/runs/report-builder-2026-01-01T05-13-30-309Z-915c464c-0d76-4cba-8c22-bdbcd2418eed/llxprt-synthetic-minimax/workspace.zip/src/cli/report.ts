import { readFileSync, writeFileSync } from 'fs';
import { ReportData, Entry } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIArguments {
  filePath: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): CLIArguments {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const filePath = args[0];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && args[i + 1]) {
      format = args[i + 1] as 'markdown' | 'text';
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output' && args[i + 1]) {
      outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format parameter is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }
  
  return {
    filePath,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (data === null || data === undefined || typeof data !== 'object') {
    return false;
  }
  
  const typedData = data as Partial<ReportData>;
  
  if (typeof typedData.title !== 'string' || typedData.title.trim() === '') {
    return false;
  }
  
  if (typeof typedData.summary !== 'string' || typedData.summary.trim() === '') {
    return false;
  }
  
  if (!Array.isArray(typedData.entries) || typedData.entries.length === 0) {
    return false;
  }
  
  for (const entry of typedData.entries) {
    if (typeof entry !== 'object' || 
        typeof (entry as Partial<Entry>).label !== 'string' || 
        typeof (entry as Partial<Entry>).amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      console.error('Error: Invalid data format. Expected fields: title (string), summary (string), entries (array of objects with label (string) and amount (number))');
      process.exit(1);
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
    } else if (error instanceof Error) {
      console.error(`Error: Failed to read file '${filePath}': ${error.message}`);
    } else {
      console.error(`Error: Failed to read file '${filePath}': ${String(error)}`);
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error: Failed to write output file '${outputPath}': ${error.message}`);
      } else {
        console.error(`Error: Failed to write output file '${outputPath}': ${String(error)}`);
      }
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  const args = parseArguments(process.argv);
  const reportData = loadReportData(args.filePath);
  
  const options = {
    includeTotals: args.includeTotals
  };
  
  let output = '';
  switch (args.format) {
    case 'markdown':
      output = renderMarkdown.format(reportData, options);
      break;
    case 'text':
      output = renderText.format(reportData, options);
      break;
    default:
      console.error(`Error: Unsupported format '${args.format}'. Supported formats: markdown, text`);
      process.exit(1);
  }
  
  writeOutput(output, args.outputPath);
}

main();
