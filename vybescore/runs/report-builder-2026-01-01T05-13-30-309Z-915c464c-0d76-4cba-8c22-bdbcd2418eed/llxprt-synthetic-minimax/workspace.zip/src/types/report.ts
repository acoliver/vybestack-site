export interface Entry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: Entry[];
}

export interface RenderOptions {
  includeTotals: boolean;
}

export type Format = 'markdown' | 'text';

export interface Formatter {
  format: (data: ReportData, options: RenderOptions) => string;
}