import { ReportData, RenderOptions, Formatter } from '../types/report.js';

export const renderMarkdown: Formatter = {
  format: (data: ReportData, options: RenderOptions): string => {
    let output = '';
    
    // Title with heading
    output += `# ${data.title}\n\n`;
    
    // Summary
    output += `${data.summary}\n\n`;
    
    // Entries section
    output += `## Entries\n\n`;
    
    // Bullet list entries
    data.entries.forEach(entry => {
      const amount = entry.amount.toFixed(2);
      output += `- **${entry.label}** — $${amount}\n`;
    });
    
    // Optional total
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      const formattedTotal = total.toFixed(2);
      output += `\n**Total:** $${formattedTotal}\n`;
    }
    
    return output;
  }
};