# Manual Testing Guide

## Starting the Server

```bash
npm run dev:server
```

The server will start on http://localhost:3000

## API Testing with curl

### Test 1: Default Request (Page 1, Limit 5)
```bash
curl "http://localhost:3000/inventory"
```
Expected: First 5 items (IDs 1-5), hasNext: true

### Test 2: Page 2
```bash
curl "http://localhost:3000/inventory?page=2&limit=5"
```
Expected: Next 5 items (IDs 6-10), hasNext: true

### Test 3: Page 3
```bash
curl "http://localhost:3000/inventory?page=3&limit=5"
```
Expected: Last 5 items (IDs 11-15), hasNext: false

### Test 4: Beyond Available Data
```bash
curl "http://localhost:3000/inventory?page=4&limit=5"
```
Expected: Empty items array, hasNext: false

### Test 5: Invalid Page (Negative)
```bash
curl "http://localhost:3000/inventory?page=-1"
```
Expected: HTTP 400 with error message

### Test 6: Invalid Limit (Zero)
```bash
curl "http://localhost:3000/inventory?limit=0"
```
Expected: HTTP 400 with error message

### Test 7: Invalid Limit (Excessive)
```bash
curl "http://localhost:3000/inventory?limit=101"
```
Expected: HTTP 400 with error message

### Test 8: Non-Numeric Page
```bash
curl "http://localhost:3000/inventory?page=abc"
```
Expected: HTTP 400 with error message

### Test 9: Custom Limit
```bash
curl "http://localhost:3000/inventory?page=1&limit=10"
```
Expected: First 10 items (IDs 1-10), hasNext: true

## React Client Testing

The React client (`InventoryView` component) should display:

1. **Initial Load**: Shows first 5 items with "Previous" disabled, "Next" enabled
2. **Click Next**: Shows items 6-10, both buttons enabled
3. **Click Next Again**: Shows items 11-15, "Next" disabled
4. **Click Previous**: Navigates back to items 6-10
5. **Page Info**: Displays "Page X of Y" correctly
6. **Item Count**: Shows "Showing X of 15 items"

## Verification Checklist

- [ ] Server starts without errors
- [ ] Default request returns page 1 with 5 items
- [ ] Page 2 returns correct items (IDs 6-10)
- [ ] Page 3 returns correct items (IDs 11-15) with hasNext: false
- [ ] Invalid page parameters return HTTP 400
- [ ] Invalid limit parameters return HTTP 400
- [ ] Non-numeric parameters return HTTP 400
- [ ] Excessive limit (>100) returns HTTP 400
- [ ] Previous button disabled on page 1
- [ ] Next button disabled on last page
- [ ] Empty pages display "No inventory items found."
- [ ] Errors from server are displayed to user
- [ ] Pagination controls work smoothly
- [ ] Page count displays correctly
- [ ] Item count displays correctly
