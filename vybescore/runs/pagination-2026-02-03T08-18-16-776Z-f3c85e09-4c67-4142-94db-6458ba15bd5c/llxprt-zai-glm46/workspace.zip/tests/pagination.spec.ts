import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../src/server/app';
import { createDatabase } from '../src/server/db';

describe('pagination API (comprehensive)', () => {
  it('returns default page 1 with limit 5', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns page 2 with correct items', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.items[0].id).toBe(6); // First item on page 2
    expect(response.body.hasNext).toBe(true);
  });

  it('returns page 3 with correct items and hasNext=false', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.items[0].id).toBe(11); // First item on page 3
    expect(response.body.hasNext).toBe(false);
  });

  it('returns empty page when page exceeds available data', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=4&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(4);
    expect(response.body.items).toHaveLength(0);
    expect(response.body.hasNext).toBe(false);
  });

  it('rejects negative page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
  });

  it('rejects zero page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
  });

  it('rejects non-numeric page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
  });

  it('rejects zero limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=0');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
  });

  it('rejects negative limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=-5');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
  });

  it('rejects excessive limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=101');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
  });

  it('rejects non-numeric limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=xyz');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toBeDefined();
  });

  it('respects custom limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=10');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(10);
    expect(response.body.items).toHaveLength(10);
    expect(response.body.hasNext).toBe(true);
  });

  it('handles decimal page numbers by flooring', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2.9&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
  });

  it('handles decimal limit numbers by flooring', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=5.9');
    
    expect(response.status).toBe(200);
    expect(response.body.limit).toBe(5);
  });
});
