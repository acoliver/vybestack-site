#!/bin/bash

# Test pagination functionality
echo "Testing Pagination API..."
echo ""

# Start the server in background
npm run dev:server &
SERVER_PID=$!
echo "Started server (PID: $SERVER_PID)"
sleep 3

echo "Test 1: Default request (should return page 1 with limit 5)"
curl -s "http://localhost:3000/inventory" | jq '.'
echo ""
echo "---"
echo ""

echo "Test 2: Request page 2 with limit 5"
curl -s "http://localhost:3000/inventory?page=2&limit=5" | jq '.'
echo ""
echo "---"
echo ""

echo "Test 3: Request page 3 with limit 5"
curl -s "http://localhost:3000/inventory?page=3&limit=5" | jq '.'
echo ""
echo "---"
echo ""

echo "Test 4: Invalid page (negative) - should return 400"
curl -s "http://localhost:3000/inventory?page=-1" | jq '.'
echo ""
echo "---"
echo ""

echo "Test 5: Invalid limit (zero) - should return 400"
curl -s "http://localhost:3000/inventory?limit=0" | jq '.'
echo ""
echo "---"
echo ""

echo "Test 6: Invalid limit (excessive >100) - should return 400"
curl -s "http://localhost:3000/inventory?limit=101" | jq '.'
echo ""
echo "---"
echo ""

echo "Test 7: Non-numeric page - should return 400"
curl -s "http://localhost:3000/inventory?page=abc" | jq '.'
echo ""
echo "---"
echo ""

# Kill the server
echo "Killing server..."
kill $SERVER_PID
wait $SERVER_PID 2>/dev/null

echo "Tests complete!"
