import type { ReportData, RenderOptions, FormatType } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

export type FormatterFunction = (data: ReportData, options?: RenderOptions) => string;

export const formatters: Record<FormatType, FormatterFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};