#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, FormatType, RenderOptions } from '../types.js';
import { formatters } from '../formatters.js';

function parseArgs(): { dataFile: string; format: FormatType; outputPath?: string; options: RenderOptions } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  let format: FormatType = 'markdown';
  let outputPath: string | undefined;
  const options: RenderOptions = {};
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[i + 1] as FormatType;
        i += 1;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        outputPath = args[i + 1];
        i += 1;
        break;
      case '--includeTotals':
        options.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument: ${args[i]}`);
        process.exit(1);
    }
  }
  
  return { dataFile, format, outputPath, options };
}

function validateData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Root must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "title" field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "summary" field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: Missing or invalid "entries" field');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: Entry at index ${i} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: Entry at index ${i} missing or invalid "label" field`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: Entry at index ${i} missing or invalid "amount" field`);
    }
  }
}

function main() {
  try {
    const { dataFile, format, outputPath, options } = parseArgs();
    
    // Validate format
    if (!formatters[format]) {
      throw new Error(`Unsupported format: ${format}`);
    }
    
    // Read and parse JSON file
    let data: unknown;
    try {
      const fileContent = readFileSync(dataFile, 'utf8');
      data = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Failed to read or parse data file: ${error instanceof Error ? error.message : String(error)}`);
    }
    
    // Validate data structure
    validateData(data);
    
    // Render the report
    const formatter = formatters[format];
    const output = formatter(data, options);
    
    // Write output
    if (outputPath) {
      writeFileSync(outputPath, output, 'utf8');
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

if (process.argv[1] === new URL(import.meta.url).pathname) {
  main();
}
