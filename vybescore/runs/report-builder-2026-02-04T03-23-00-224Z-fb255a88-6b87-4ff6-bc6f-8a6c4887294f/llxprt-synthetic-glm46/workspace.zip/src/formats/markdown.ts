import type { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions = {}): string {
  const { includeTotals = false } = options;
  
  // Calculate total if needed
  const total = includeTotals
    ? data.entries.reduce((sum, entry) => sum + entry.amount, 0)
    : null;
  
  // Build the markdown content
  let result = '';
  
  // Title
  result += `# ${data.title}\n\n`;
  
  // Summary
  result += `${data.summary}\n\n`;
  
  // Entries heading
  result += `## Entries\n`;
  
  // List entries
  for (const entry of data.entries) {
    result += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }
  
  // Add total if requested
  if (includeTotals && total !== null) {
    result += `\n**Total:** $${total.toFixed(2)}`;
  }
  
  return result;
}