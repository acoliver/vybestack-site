#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, Renderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const FORMATS: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 3) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[2];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  const entries: unknown[] = obj.entries;

  if (entries.length === 0) {
    throw new Error('Invalid JSON: entries array cannot be empty');
  }

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];

    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }

    if (isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry at index ${i} has an invalid amount value (NaN)`);
    }
  }

  return data as ReportData;
}

function main(): void {
  const args = parseArgs(process.argv);

  // Read and parse JSON file
  let jsonContent: string;
  try {
    jsonContent = fs.readFileSync(args.inputFile, 'utf-8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: file not found: ${args.inputFile}`);
    } else {
      console.error(`Error: cannot read file: ${args.inputFile}`);
    }
    process.exit(1);
    return;
  }

  let data: unknown;
  try {
    data = JSON.parse(jsonContent);
  } catch (error) {
    console.error(`Error: invalid JSON in file: ${args.inputFile}`);
    process.exit(1);
    return;
  }

  // Validate data structure
  let reportData: ReportData;
  try {
    reportData = validateReportData(data);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
    return;
  }

  // Get formatter
  const formatter = FORMATS[args.format];
  if (!formatter) {
    console.error(`Error: Unsupported format: ${args.format}`);
    process.exit(1);
    return;
  }

  // Render report
  const output = formatter(reportData, { includeTotals: args.includeTotals });

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: cannot write to file: ${args.outputPath}`);
      process.exit(1);
      return;
    }
  } else {
    console.log(output);
  }
}

main();
