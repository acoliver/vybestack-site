/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver
} from '../types/reactive.js'

// Store observers that need to be notified of changes
const computedObservers = new Set<Observer<unknown>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  // Store the current computed value - initialize with undefined
  let currentValue: T | undefined
  let isInitialized = false
  
  // Observer that will track dependencies
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      // For initial runs with no dependencies, use prevValue if available
      // This ensures the default parameter is used correctly
      let usePrevValue = prevValue
      if (!isInitialized && dependencies.size === 0 && value !== undefined) {
        usePrevValue = value
      }
      
      // Compute the new value by running the update function
      // This will automatically track any dependencies accessed
      const newValue = updateFn(usePrevValue)
      
      // Check if value changed or first run
      if (!isInitialized || currentValue === undefined || !Object.is(currentValue, newValue)) {
        currentValue = newValue
        isInitialized = true
        
        // Notify all dependent computed values
        computedObservers.forEach(depObserver => {
          if (depObserver !== observer) {
            updateObserver(depObserver)
          }
        })
        
        return newValue
      }
      
      return currentValue as T
    }
  }
  
  // Track dependencies for this computed value
  const dependencies = new Set<ObserverR>()
  
  // Add this observer to the global registry
  computedObservers.add(observer as Observer<unknown>)
  
  // Initialize the computed value by running the observer once
  // Only if there are no dependencies - otherwise let it lazily compute
  if (dependencies.size === 0) {
    updateObserver(observer)
  }
  
  // Return getter function
  return (): T => {
    // When getter is accessed, register this computed as a dependency
    // for the current active observer
    
    // Check if we need to recompute
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Track dependencies
      computedObservers.add(activeObserver as Observer<unknown>)
    }
    
    // If not initialized and has dependencies, compute now
    if (!isInitialized) {
      updateObserver(observer)
    }
    
    return currentValue as T
  }
}