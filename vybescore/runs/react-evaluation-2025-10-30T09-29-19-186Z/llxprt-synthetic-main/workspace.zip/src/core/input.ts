/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Set up equality function using strict equality by default
  let equalFn: EqualFn<T>
  if (_equal === false) {
    // No equality checking, always update
    equalFn = () => false
  } else if (_equal === true || _equal === undefined) {
    // Default strict equality
    equalFn = (a: T, b: T) => a === b
  } else {
    // Custom equality function provided
    equalFn = _equal
  }

  // Create the subject
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    // Check if there's an active observer (computed value or callback)
    const observer = getActiveObserver()
    if (observer && observer !== s.observer) {
      // This input is being accessed within a computed value or callback
      // Register the observer with this input (only if not already registered)
      s.observer = observer
    }
    return s.value
  }

    const write: SetterFn<T> = (nextValue) => {
    // Always update and notify
    s.value = nextValue
    
    // Notify the registered observer if any
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    return s.value
  }

  return [read, write]
}
