#!/bin/bash

echo "Testing Unicode and special characters..."
npm run start -- --encode "hello 世界"
echo "Decoding back:"
npm run start -- --decode "aGVsbG8g5LiW5Lit"

echo "Testing obviously invalid Base64..."
npm run start -- --decode "@@@invalid@@@"

echo "Testing incorrect length..."
npm run start -- --decode "aGVsbG8="

echo "Testing padding edge cases without padding..."
npm run start -- --encode "A"
npm run start -- --decode "QQ"  # Should fail - missing padding

echo "Complete test results."
chmod +x test_edge_cases.sh