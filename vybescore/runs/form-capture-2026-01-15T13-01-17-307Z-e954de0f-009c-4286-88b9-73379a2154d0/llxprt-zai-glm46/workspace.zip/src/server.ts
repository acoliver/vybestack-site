import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    return new SQL.Database(buffer);
  }

  const database = new SQL.Database();
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  database.run(schema);

  saveDatabase(database);

  return database;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
  fs.writeFileSync(DB_PATH, buffer);
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim();
    if (!value) {
      errors.push({ field, message: `${fieldToLabel(field)} is required` });
    }
  }

  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number can contain digits, spaces, parentheses, dashes, and a leading +',
    });
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code must contain only letters, digits, spaces, and dashes',
    });
  }

  return errors;
}

function fieldToLabel(field: string): string {
  const labels: Record<string, string> = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State / Province / Region',
    postalCode: 'Postal / Zip code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone number',
  };
  return labels[field] || field;
}

function createApp(): express.Express {
  const app = express();

  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  app.get('/', (_req, res) => {
    res.render('form', { errors: [], values: {} });
  });

  app.post('/submit', (req, res) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone,
    };

    const errors = validateFormData(formData);

    if (errors.length > 0) {
      res.status(400);
      res.render('form', {
        errors: errors.map((e) => e.message),
        values: formData,
      });
      return;
    }

    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]);

      stmt.free();
      saveDatabase(db);
    }

    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req, res) => {
    const firstName = req.query.firstName || 'friend';
    res.render('thank-you', { firstName });
  });

  return app;
}

export async function startServer(): Promise<{ app: express.Express; close: () => void }> {
  db = await initializeDatabase();
  const app = createApp();

  app.set('views', path.resolve('src', 'templates'));
  app.set('view engine', 'ejs');
  app.use('/public', express.static(path.resolve('public')));

  const srv = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  const close = (): void => {
    try {
      srv.close();
    } finally {
      if (db) {
        try {
          db.close();
        } catch {
          // Ignore errors during database close
        }
        db = null;
      }
    }
  };

  process.on('SIGTERM', () => {
    close();
  });

  process.on('SIGINT', () => {
    close();
  });

  return { app, close };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
