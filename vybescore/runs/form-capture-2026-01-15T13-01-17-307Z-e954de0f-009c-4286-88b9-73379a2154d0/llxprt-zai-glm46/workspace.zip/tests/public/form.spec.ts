import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let close: (() => void) | null = null;
let app: import('express')['Express'] | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const { startServer } = await import('../../dist/server.js');
  const srv = await startServer();
  close = srv.close;
  app = srv.app;
});

afterAll(() => {
  if (close) {
    close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    expect(app).toBeTruthy();
    if (!app) throw new Error('App not initialized');

    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');

    const $ = cheerio.load(response.text);
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    expect(app).toBeTruthy();
    if (!app) throw new Error('App not initialized');

    const response = await request(app).post('/submit').type('form').send({
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'jane@example.com',
      phone: '+54 9 11 1234-5678',
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
