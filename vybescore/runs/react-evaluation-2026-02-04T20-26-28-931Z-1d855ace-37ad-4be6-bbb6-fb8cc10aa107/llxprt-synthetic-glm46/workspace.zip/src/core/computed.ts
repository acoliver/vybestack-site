/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      // This computed is being accessed by another observer
      // That observer should be notified when this computed changes
      // We'll handle this by creating a subscription mechanism
      if (!o.observers) o.observers = []
      if (!o.observers || !o.observers.includes(observer)) {
        if (!o.observers) o.observers = []
        o.observers.push(observer)
      }
    }
    return o.value!
  }
  
  // Subscribe to dependencies and compute initial value
  updateObserver(o)
  
  return getter
}
