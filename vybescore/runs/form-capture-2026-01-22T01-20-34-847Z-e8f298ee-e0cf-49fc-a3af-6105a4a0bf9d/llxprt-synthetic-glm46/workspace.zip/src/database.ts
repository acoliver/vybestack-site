import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const schemaPath = path.join(__dirname, '../db/schema.sql');

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Define a type for the SQL.js database
interface Database {
  exec: (sql: string) => void;
  prepare: (sql: string) => Statement;
  export: () => Uint8Array;
  close: () => void;
}

interface Statement {
  run: (params: unknown[]) => void;
  free: () => void;
}

let db: Database | null = null;

export async function initDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs({ locateFile: (file: string) => `node_modules/sql.js/dist/${file}` });
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create a new one
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer) as Database;
      console.log('Loaded existing database from', dbPath);
    } else {
      db = new SQL.Database() as Database;
      
      // Read schema and execute it
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.exec(schema);
      
      // Save the newly created database
      saveDatabase(db);
      console.log('Created new database at', dbPath);
    }
    
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export function saveDatabase(database: Database): void {
  try {
    const data = database.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to', dbPath);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

export function insertSubmission(database: Database, submission: FormSubmission): void {
  try {
    const stmt = database.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);
    
    stmt.free();
    saveDatabase(database);
  } catch (error) {
    console.error('Failed to insert submission:', error);
    throw error;
  }
}

export function closeDatabase(database: Database): void {
  try {
    database.close();
    console.log('Database connection closed');
  } catch (error) {
    console.error('Failed to close database:', error);
  }
}