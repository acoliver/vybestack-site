import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase, insertSubmission, closeDatabase, FormSubmission } from './database.js';
import { validateForm, FormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: Awaited<ReturnType<typeof initDatabase>>;
async function initializeServer() {
  try {
    db = await initDatabase();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// GET route for the form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    values: {},
    errors: []
  });
});

// POST route to handle form submissions
app.post('/submit', async (req: Request, res: Response) => {
  try {
    // Only process database operations if database is initialized
    if (!db) {
      console.error('Database not initialized');
      return res.status(500).render('form', {
        values: req.body,
        errors: ['Database not available. Please try again later.']
      });
    }

    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      // Extract field values for re-rendering form
      const fieldValues: Record<string, string> = {};
      Object.keys(validation.fields).forEach(key => {
        fieldValues[key] = validation.fields[key].value;
      });
      
      return res.status(400).render('form', {
        values: fieldValues,
        errors: validation.errors
      });
    }

    // Valid submission - insert into database
    const submission: FormSubmission = {
      firstName: formData.firstName,
      lastName: formData.lastName,
      streetAddress: formData.streetAddress,
      city: formData.city,
      stateProvince: formData.stateProvince,
      postalCode: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    };

    insertSubmission(db, submission);
    
    // Redirect to thank you page with first name
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error handling form submission:', error);
    res.status(500).render('form', {
      values: req.body,
      errors: ['An unexpected error occurred. Please try again later.']
    });
  }
});

// GET route for the thank-you page
app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Basic health check endpoint for testing
app.get('/health', (req: Request, res: Response) => {
  res.json({ status: 'ok', message: 'Friendly Form Capture is running!' });
});

// Graceful shutdown
let server: ReturnType<typeof app.listen>;

async function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  
  if (server) {
    server.close(async () => {
      console.log('HTTP server closed');
      
      if (db) {
        closeDatabase(db);
        console.log('Database connection closed');
      }
      
      process.exit(0);
    });
    
    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      process.exit(1);
    }, 10000);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize the server
async function startServer() {
  await initializeServer();
  
  server = app.listen(port, () => {
    console.log(`Friendly Form Capture server listening on port ${port}`);
    console.log(`Visit http://localhost:${port} to see the form`);
  });
  
  return server;
}

// Start the server if this file is being run directly
if (process.argv[1] === fileURLToPath(import.meta.url)) {
  startServer().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export default app;
