export interface FormField {
  value: string;
  error: string | null;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  fields: Record<string, FormField>;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateForm(formData: FormData): ValidationResult {
  const errors: string[] = [];
  const fields: Record<string, FormField> = {};
  
  // Initialize fields with values and empty errors
  Object.keys(formData).forEach(key => {
    fields[key] = {
      value: formData[key as keyof FormData] || '',
      error: null
    };
  });
  
  // Validate required fields
  if (!formData.firstName.trim()) {
    errors.push('First name is required');
    fields.firstName.error = 'First name is required';
  }
  
  if (!formData.lastName.trim()) {
    errors.push('Last name is required');
    fields.lastName.error = 'Last name is required';
  }
  
  if (!formData.streetAddress.trim()) {
    errors.push('Street address is required');
    fields.streetAddress.error = 'Street address is required';
  }
  
  if (!formData.city.trim()) {
    errors.push('City is required');
    fields.city.error = 'City is required';
  }
  
  if (!formData.stateProvince.trim()) {
    errors.push('State/Province/Region is required');
    fields.stateProvince.error = 'State/Province/Region is required';
  }
  
  if (!formData.postalCode.trim()) {
    errors.push('Postal/Zip code is required');
    fields.postalCode.error = 'Postal/Zip code is required';
  }
  
  if (!formData.country.trim()) {
    errors.push('Country is required');
    fields.country.error = 'Country is required';
  }
  
  // Validate email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email.trim()) {
    errors.push('Email is required');
    fields.email.error = 'Email is required';
  } else if (!emailRegex.test(formData.email)) {
    errors.push('Email address is not valid');
    fields.email.error = 'Email address is not valid';
  }
  
  if (!formData.phone.trim()) {
    errors.push('Phone number is required');
    fields.phone.error = 'Phone number is required';
  } else {
// Validate phone format - can contain digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push('Phone number format is not valid');
      fields.phone.error = 'Phone number format is not valid';
    }
  }
  
  // Validate postal code format - should accept alphanumeric strings
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  if (formData.postalCode && !postalCodeRegex.test(formData.postalCode)) {
    errors.push('Postal/Zip code format is not valid');
    fields.postalCode.error = 'Postal/Zip code format is not valid';
  }
  
  return {
    isValid: errors.length === 0,
    errors,
    fields
  };
}