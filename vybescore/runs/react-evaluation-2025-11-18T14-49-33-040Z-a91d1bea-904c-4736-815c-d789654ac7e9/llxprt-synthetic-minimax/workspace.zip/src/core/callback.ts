/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    observers: new Set()
  }
  
  // Initial execution to set up dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear all observer registrations to prevent future updates
    if (observer.observers) {
      for (const subject of observer.observers) {
        if (subject.observers) {
          subject.observers.delete(observer)
        }
      }
      observer.observers.clear()
    }
  }
}