
// Test to understand current behavior
import { createInput, createComputed, createCallback } from "../src/index.js"

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

console.log("Initial output:", output()) // Should be 2

let value = 0
const unsubscribe = createCallback(() => {
  console.log("Callback executing, output is:", output())
  value = output()
})

console.log("After callback creation, value:", value) // Should be 2

setInput(3)
console.log("After setInput(3), value:", value) // Should be 4 but is probably still 2

console.log("Final output:", output()) // Should be 4

