export interface USPhoneOptions {
  allowCountryCode?: boolean;
}

export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domain starting or ending with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

export function isValidUSPhone(value: string, options?: USPhoneOptions): boolean {
  const allowCountryCode = options?.allowCountryCode !== false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for country code +1
  if (allowCountryCode && digits.startsWith('1') && digits.length === 11) {
    const areaCode = digits.substring(1, 4);
    const exchangeCode = digits.substring(4, 7);
    
    // Area code cannot start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    // Exchange code cannot start with 0 or 1
    if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
      return false;
    }
    
    return true;
  }
  
  // 10-digit format
  if (digits.length === 10) {
    const areaCode = digits.substring(0, 3);
    const exchangeCode = digits.substring(3, 6);
    
    // Area code cannot start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    // Exchange code cannot start with 0 or 1
    if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other separators
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if it has country code
  const hasCountryCode = cleanNumber.startsWith('+54');
  
  let numberToCheck: string;
  
  if (hasCountryCode) {
    // Remove +54 prefix
    numberToCheck = cleanNumber.substring(3);
  } else {
    numberToCheck = cleanNumber;
  }
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !numberToCheck.startsWith('0')) {
    return false;
  }
  
  // Remove trunk prefix if present
  if (numberToCheck.startsWith('0')) {
    numberToCheck = numberToCheck.substring(1);
  }
  
  // Remove mobile indicator if present
  if (numberToCheck.startsWith('9')) {
    numberToCheck = numberToCheck.substring(1);
  }
  
  // Now we should have area code + subscriber number
  // Area code: 2-4 digits, leading digit 1-9
  const areaCodeRegex = /^([1-9]\d{1,3})/;
  const areaCodeMatch = numberToCheck.match(areaCodeRegex);
  
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const remainingDigits = numberToCheck.substring(areaCode.length);
  
  // Subscriber number: 6-8 digits
  if (remainingDigits.length < 6 || remainingDigits.length > 8) {
    return false;
  }
  
  // Verify all remaining characters are digits
  if (!/^\d+$/.test(remainingDigits)) {
    return false;
  }
  
  return true;
}

export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  // Check for obviously invalid patterns like consecutive special chars
  const hasInvalidPatterns = /(['-])\1/.test(value);
  
  // Check for digits
  const hasDigits = /\d/.test(value);
  
  return nameRegex.test(value) && hasLetter && !hasInvalidPatterns && !hasDigits;
}

function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanNumber = value.replace(/\D/g, '');
  
  // Check valid lengths for major card types
  const validLengths = [13, 14, 15, 16, 19];
  if (!validLengths.includes(cleanNumber.length)) {
    return false;
  }
  
  // Check valid prefixes
  const visaRegex = /^4\d{12,18}$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]|[3-6]\d|7([01]|20))\d{13}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanNumber) && !mastercardRegex.test(cleanNumber) && !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}