export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary regex for words starting with prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(match => 
    !exceptions.some(exception => 
      exception.toLowerCase() === match.toLowerCase()
    )
  );
  
  // Return unique matches preserving original case
  return [...new Set(filteredMatches)];
}

export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find digit + token combinations that are not at the start of the string
  const tokenRegex = new RegExp(`(\\d+)${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    // Include the digit with the token
    matches.push(match[0]);
  }
  
  return matches;
}

export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (anything that's not alphanumeric or whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences like abab, abcabc, etc.
  // Check for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);
      if (pattern === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  // Full IPv6 (8 groups of 1-4 hex digits)
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: (compression)
  const compressedIPv6 = /(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  // IPv6 with IPv4 embedded
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // IPv6 loopback and unspecified
  const specialIPv6 = /::1|::/;
  
  // First check for any IPv4 address to exclude false positives
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  const hasIPv4 = ipv4Regex.test(value);
  
  // Check for IPv6 patterns
  const hasIPv6 = fullIPv6.test(value) || compressedIPv6.test(value) || 
                  ipv6WithIPv4.test(value) || specialIPv6.test(value);
  
  // Return true if IPv6 is found and it's not just an IPv4 address
  return hasIPv6 && !(!hasIPv6 && hasIPv4);
}