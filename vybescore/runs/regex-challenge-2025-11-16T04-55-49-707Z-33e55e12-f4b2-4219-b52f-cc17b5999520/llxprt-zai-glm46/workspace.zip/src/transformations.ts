export function capitalizeSentences(text: string): string {
  // Split into sentences while preserving abbreviations when possible
  const sentences = text.split(/([.!?]+)/);
  let result = '';
  let i = 0;
  
  while (i < sentences.length) {
    const sentence = sentences[i];
    const punctuation = sentences[i + 1] || '';
    
    if (sentence.trim()) {
      // Capitalize first character of sentence
      let capitalized = sentence.trim();
      capitalized = capitalized.charAt(0).toUpperCase() + capitalized.slice(1).toLowerCase();
      
      if (result) {
        result += ' ';
      }
      result += capitalized;
    }
    
    if (punctuation) {
      result += punctuation;
      i += 2;
    } else {
      i++;
    }
  }
  
  // Collapse extra spaces
  result = result.replace(/\s+/g, ' ');
  
  return result.trim();
}

export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Filter out trailing punctuation and query strings
  return matches.map(url => 
    url.replace(/[.,;:!?')\]}]+$/, '').replace(/\?.*$/, '')
  );
}

export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  // URL regex that captures scheme, host, and path
  const urlRegex = /(https?):\/\/([^/]+)(\/[^#\s]*)/g;
  
  return text.replace(urlRegex, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https';
    
    // Check if path contains cgi-bin or legacy extensions
    // Query strings in /docs/ paths should be preserved (don't rewrite host)
    const hasDynamicHints = /\/cgi-bin/.test(path) || 
                            (/\?/.test(path) && path.startsWith('/docs/')) ||
                            /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(path);
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      return `${newScheme}://docs.${host}${path}`;
    }
    
    return `${newScheme}://${host}${path}`;
  });
}

export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Check for leap year
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  
  // Days in month (accounting for leap years)
  const daysInMonth = [31, isLeapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}