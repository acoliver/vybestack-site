/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn
} from '../types/reactive.js'
import { runWithEffect, trackDependency, triggerEffects } from './reactive-context.js'

interface ComputedState<T> {
  value: T
  isStale: boolean
  updateFn: UpdateFn<T>
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _options?: { name?: string }
): GetterFn<T> {
  const state: ComputedState<T> = {
    value: value as T,
    isStale: true,
    updateFn
  }

  // Create a signal object for dependency tracking
  const signal = {}

  const read: GetterFn<T> = () => {
    // If stale, recompute and track dependencies
    if (state.isStale) {
      // Create an effect to track dependencies during computation
      const computationEffect = () => {
        const newValue = state.updateFn(state.value)
        state.value = newValue
        state.isStale = false
      }
      
      runWithEffect(computationEffect, () => {
        state.value = state.updateFn(state.value)
        state.isStale = false
      })
    }

    // Track this computed as a dependency when read
    trackDependency(signal)
    
    return state.value
  }

  // Setup dependency tracking for this computed value
  const setupEffect = () => {
    // When dependencies change, mark this as stale
    state.isStale = true
    // Trigger effects on this computed's signal when it becomes stale
    triggerEffects(signal)
  }

  // Initial computation
  runWithEffect(setupEffect, () => {
    state.value = state.updateFn(state.value)
    state.isStale = false
  })

  return read
}