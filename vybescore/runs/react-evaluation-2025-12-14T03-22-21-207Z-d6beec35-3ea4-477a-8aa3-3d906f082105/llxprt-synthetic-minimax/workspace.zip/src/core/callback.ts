/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn } from '../types/reactive.js'
import { createEffect } from './reactive-context.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  const effectFn = () => {
    updateFn(_value)
  }

  return createEffect(effectFn)
}