/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { trackDependency, triggerEffects } from './reactive-context.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value
  const equalFn = typeof _equal === 'function' ? _equal : (_equal !== false ? defaultEqualFn : neverEqualFn)

  // Create a unique object to use as the key for dependency tracking
  const signal = {}

  const read: GetterFn<T> = () => {
    // Track this dependency when read during reactive evaluation
    trackDependency(signal)
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!equalFn(currentValue, nextValue)) {
      const oldValue = currentValue
      currentValue = nextValue
      // Trigger effects when value changes
      if (!equalFn(oldValue, currentValue)) {
        triggerEffects(signal)
      }
    }
    return currentValue
  }

  return [read, write]
}

function defaultEqualFn<T>(lhs: T, rhs: T): boolean {
  return Object.is(lhs, rhs)
}

function neverEqualFn<T>(_lhs: T, _rhs: T): boolean {
  return false
}