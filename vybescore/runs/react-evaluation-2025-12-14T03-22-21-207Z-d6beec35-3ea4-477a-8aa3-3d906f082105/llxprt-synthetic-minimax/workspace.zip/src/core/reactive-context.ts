/**
 * Reactive context for dependency tracking.
 */

type Effect = () => void
type Dependency = { effects: Set<Effect> }

interface ReactiveContext {
  currentEffect: Effect | null
  dependencies: WeakMap<object, Dependency>
  effectReferences: Map<Effect, Set<object>>
}

const globalContext: ReactiveContext = {
  currentEffect: null,
  dependencies: new WeakMap(),
  effectReferences: new Map(),
}

export function getGlobalContext(): ReactiveContext {
  return globalContext
}

export function trackDependency(dependable: object) {
  const context = getGlobalContext()
  if (context.currentEffect) {
    let dependency = context.dependencies.get(dependable)
    if (!dependency) {
      dependency = { effects: new Set() }
      context.dependencies.set(dependable, dependency)
    }
    dependency.effects.add(context.currentEffect)
    
    // Track this dependency relationship for cleanup
    let deps = context.effectReferences.get(context.currentEffect)
    if (!deps) {
      deps = new Set()
      context.effectReferences.set(context.currentEffect, deps)
    }
    deps.add(dependable)
  }
}

export function triggerEffects(dependable: object) {
  const context = getGlobalContext()
  const dependency = context.dependencies.get(dependable)
  if (dependency) {
    // Create a copy of effects to avoid mutation during iteration
    const effectsToRun = new Set(dependency.effects)
    effectsToRun.forEach(effect => effect())
  }
}

export function runWithEffect<T>(effect: Effect, fn: () => T): T {
  const context = getGlobalContext()
  const previousEffect = context.currentEffect
  context.currentEffect = effect
  try {
    return fn()
  } finally {
    context.currentEffect = previousEffect
  }
}

export function createEffect(effectFn: () => void): () => void {
  let isRunning = false
  const effect = () => {
    if (!isRunning) {
      isRunning = true
      try {
        runWithEffect(effect, effectFn)
      } finally {
        isRunning = false
      }
    }
  }
  
  // Run the effect immediately
  effect()
  
  // Return cleanup function that removes this effect from all dependencies
  return () => {
    const context = getGlobalContext()
    
    // Remove this effect from all dependencies it was tracking
    const deps = context.effectReferences.get(effect)
    if (deps) {
      for (const dependable of deps) {
        const dependency = context.dependencies.get(dependable)
        if (dependency) {
          dependency.effects.delete(effect)
        }
      }
      context.effectReferences.delete(effect)
    }
  }
}