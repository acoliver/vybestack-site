import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  describe('pagination functionality', () => {
    it('returns default page with 5 items', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(5);
      expect(response.body.items.length).toBe(5);
      expect(typeof response.body.total).toBe('number');
      expect(typeof response.body.hasNext).toBe('boolean');
    });

    it('returns specific page and limit', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=2&limit=3');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(2);
      expect(response.body.limit).toBe(3);
      expect(response.body.items.length).toBe(3);
    });

    it('handles edge case with limit=1', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=1&limit=1');
      
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(1);
      expect(response.body.limit).toBe(1);
    });

    it('calculates hasNext correctly', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const firstPage = await request(app).get('/inventory?limit=5');
      const lastPage = await request(app).get('/inventory?page=10&limit=5');
      
      expect(firstPage.body.hasNext).toBe(true); // Assuming more than 5 items
      expect(lastPage.body.hasNext).toBe(false); // Last page should have no next
    });

    it('handles request without pagination params', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory');
      
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
      expect(response.body.limit).toBe(5);
      expect(response.body.items.length).toBe(5);
    });
  });

  describe('input validation', () => {
    it('rejects non-numeric page parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=abc');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Page must be a positive integer');
    });

    it('rejects negative page parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=-1');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Page must be a positive integer');
    });

    it('rejects zero page parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?page=0');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Page must be a positive integer');
    });

    it('rejects non-numeric limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=xyz');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Limit must be a positive integer');
    });

    it('rejects negative limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=-5');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Limit must be a positive integer');
    });

    it('rejects zero limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=0');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Limit must be a positive integer');
    });

    it('rejects excessive limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=101');
      
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('Limit must be a positive integer between 1 and 100');
    });

    it('accepts maximum allowed limit parameter', async () => {
      const db = await createDatabase();
      const app = await createApp(db);
      const response = await request(app).get('/inventory?limit=100');
      
      expect(response.status).toBe(200);
      expect(response.body.limit).toBe(100);
    });
  });
});
