#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const cliArgs: Partial<CliArgs> = {};
  
  // First arg should be the data file
  if (args[0].startsWith('--')) {
    console.error('Error: Missing data file argument');
    process.exit(1);
  }
  cliArgs.dataFile = args[0];

  // Parse remaining args
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[i];
      if (format !== 'markdown' && format !== 'text') {
        console.error('Unsupported format: ' + format);
        process.exit(1);
      }
      cliArgs.format = format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      cliArgs.output = args[i];
    } else if (arg === '--includeTotals') {
      cliArgs.includeTotals = true;
    } else {
      console.error('Error: Unknown argument: ' + arg);
      process.exit(1);
    }
  }

  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (!cliArgs.includeTotals) {
    cliArgs.includeTotals = false;
  }

  return cliArgs as CliArgs;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    return false;
  }

  if (typeof report.summary !== 'string') {
    return false;
  }

  if (!Array.isArray(report.entries)) {
    return false;
  }

  for (const entry of report.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    const entryRecord = entry as Record<string, unknown>;
    if (typeof entryRecord.label !== 'string' || typeof entryRecord.amount !== 'number') {
      return false;
    }
  }

  return true;
}

function main(): void {
  try {
    const args = parseArgs();

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in ${args.dataFile}: ${error.message}`);
      } else {
        console.error(`Error: Could not read file ${args.dataFile}: ${error}`);
      }
      process.exit(1);
    }

    // Validate data structure
    if (!validateReportData(jsonData)) {
      console.error('Error: Invalid report data structure. Expected { title: string, summary: string, entries: { label: string, amount: number }[] }');
      process.exit(1);
    }

    const reportData: ReportData = jsonData;
    const options: ReportOptions = { includeTotals: args.includeTotals };

    // Render report
    let output: string;
    if (args.format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else {
      output = renderText(reportData, options);
    }

    // Write output
    if (args.output) {
      writeFileSync(args.output, output);
    } else {
      console.log(output);
    }

  } catch (error) {
    console.error(`Error: ${error}`);
    process.exit(1);
  }
}

main();