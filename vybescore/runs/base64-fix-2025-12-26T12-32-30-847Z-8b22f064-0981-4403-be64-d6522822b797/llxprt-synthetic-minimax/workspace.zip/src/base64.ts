/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 with proper validation.
 * Accepts standard Base64 input (with or without padding) and rejects invalid input.
 */
export function decode(input: string): string {
  // Clean up input - remove whitespace
  const cleaned = input.replace(/\s+/g, '');

  // Validate that input only contains valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Ensure input length is valid for Base64 (should be multiple of 4 when padded)
  if (cleaned.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Add padding if necessary
  let padded = cleaned;
  const remainder = cleaned.length % 4;
  if (remainder === 2) {
    padded += '==';
  } else if (remainder === 3) {
    padded += '=';
  } else if (remainder !== 0) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
