// Debug script to understand callback behavior
import { createInput, createComputed, createCallback } from './dist/index.js'

console.log('=== Testing callback behavior ===')

const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1 = []
console.log('Creating first callback...')
const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 executed, pushing value:', output())
  values1.push(output())
})

const values2 = []
console.log('Creating second callback...')
createCallback(() => {
  console.log('Callback 2 executed, pushing value:', output())
  values2.push(output())
})

console.log('Initial state:')
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nSetting input to 31...')
setInput(31)

console.log('After first change:')
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nUnsubscribing first callback...')
unsubscribe1()

console.log('Setting input to 41...')
setInput(41)

console.log('After second change (with first callback unsubscribed):')
console.log('values1:', values1)
console.log('values2:', values2)

console.log('\nFinal analysis:')
console.log('values1.length:', values1.length)
console.log('values2.length:', values2.length)
console.log('values2.length > values1.length?', values2.length > values1.length)