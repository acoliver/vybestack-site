import { setActiveObserver, type UpdateFn, type UnsubscribeFn } from '../types/reactive.js'

import { registerComputedCallback } from './computed.js'

const activeCallbacks = new Set<() => void>()

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let isActive = true
  
  function execute(): void {
    if (!isActive) return
    
    // Check if this callback is still active before executing
    if (!activeCallbacks.has(execute)) {
      return
    }
    
    const callbackObserver = { name: 'callback' }
    setActiveObserver(callbackObserver)
    try {
      updateFn(value)
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Add to active callbacks set
  activeCallbacks.add(execute)
  
  // Execute immediately for initial setup
  execute()
  
  // Register to be notified when computed values change
  const unregister = registerComputedCallback(execute)
  
  return function unsubscribe(): void {
    if (!isActive) return
    
    isActive = false
    activeCallbacks.delete(execute)
    unregister()
  }
}