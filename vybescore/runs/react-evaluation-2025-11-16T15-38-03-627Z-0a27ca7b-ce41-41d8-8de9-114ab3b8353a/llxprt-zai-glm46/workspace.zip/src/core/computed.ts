import { setActiveObserver, getActiveObserver, type EqualFn, type GetterFn, type Options, type UpdateFn, type Subject } from '../types/reactive.js'

import { inputs, observeInput } from './input.js'

const computedCallbacks = new Set<() => void>()
const computedRegistry = new Map<unknown, () => void>()

export function createComputed<T>(updateFn: UpdateFn<T>, value?: T, equalFn?: EqualFn<T>, options?: Options): GetterFn<T> {
  let cachedValue: T = value as T
  const dependencies = new Set<Subject<unknown>>()
  const unobserveFns = new Set<() => void>()
  let isComputing = false
  
  const computedId = {}
  
  function recompute(): void {
    if (isComputing) return
    
    isComputing = true
    
    try {
      // Clear old dependencies
      for (const unobserve of unobserveFns) {
        unobserve()
      }
      unobserveFns.clear()
      dependencies.clear()
      
      const previousObserver = getActiveObserver()
      const computedObserver = { name: options?.name, computedId }
      setActiveObserver(computedObserver)
      
      try {
        const oldValue = cachedValue
        cachedValue = updateFn(value)
        
        // Check dependencies after accessing inputs
        for (const input of inputs) {
          if (input.observer === computedObserver && !dependencies.has(input)) {
            dependencies.add(input)
            const unobserve = observeInput(input, () => {
              if (!isComputing) {
                recompute()
              }
            })
            unobserveFns.add(unobserve)
          }
        }
        
        // Check dependencies again after potentially accessing other computed
        for (const input of inputs) {
          if (input.observer === computedObserver && !dependencies.has(input)) {
            dependencies.add(input)
            const unobserve = observeInput(input, () => {
              if (!isComputing) {
                recompute()
              }
            })
            unobserveFns.add(unobserve)
          }
        }
        
        // Notify callbacks if value changed - schedule asynchronously to avoid issues with callback modifications
        const hasChanged = !equalFn || !equalFn(oldValue, cachedValue)
        if (hasChanged) {
          // Create a snapshot of callbacks to notify
          const callbacksToNotify = Array.from(computedCallbacks)
          
          // Use queueMicrotask for immediate async execution
          queueMicrotask(() => {
            for (const callback of callbacksToNotify) {
              // Double-check callback is still registered before executing
              if (computedCallbacks.has(callback)) {
                try {
                  callback()
                } catch (error: unknown) {
                  console.error('Error in computed callback:', error)
                }
              }
            }
          })
        }
      } finally {
        setActiveObserver(previousObserver)
      }
    } finally {
      isComputing = false
    }
  }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this computed as a dependency for the active observer
      const computedSubject: Subject<T> = {
        name: `computed-${options?.name || 'anonymous'}`,
        value: cachedValue,
        observer: undefined,
        equalFn
      }
      
      computedSubject.observer = activeObserver
      
      // Add to inputs set so it can be observed
      inputs.add(computedSubject as Subject<unknown>)
      
      // Create observer for this computed
      const unobserve = observeInput(computedSubject as Subject<unknown>, () => {
        recompute()
      })
      unobserveFns.add(unobserve)
      dependencies.add(computedSubject as Subject<unknown>)
    }
    
    recompute()
    return cachedValue
  }
  
  computedRegistry.set(computedId, getter)
  
  return getter
}

export function registerComputedCallback(callback: () => void): () => void {
  computedCallbacks.add(callback)
  
  return () => {
    computedCallbacks.delete(callback)
  }
}