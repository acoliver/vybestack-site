import { getActiveObserver, type EqualFn, type GetterFn, type InputPair, type Options, type SetterFn, type Subject } from '../types/reactive.js'

export const inputs = new Set<Subject<unknown>>()
export const inputObservers = new Map<Subject<unknown>, Set<() => void>>()

export function createInput<T>(value: T, equalFn?: EqualFn<T>, options?: Options): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
    observer: undefined
  }
  
  const observers = new Set<() => void>()
  inputObservers.set(subject as Subject<unknown>, observers)
  inputs.add(subject as Subject<unknown>)
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && !subject.observer) {
      subject.observer = activeObserver
    }
    return subject.value
  }
  
  const setter: SetterFn<T> = (newValue: T) => {
    const hasChanged = !subject.equalFn || !subject.equalFn(subject.value, newValue)
    if (hasChanged) {
      subject.value = newValue
      
      // Clear observer reference after change
      subject.observer = undefined
      
      // Notify all observers
      for (const observer of observers) {
        try {
          observer()
        } catch (error) {
          console.error('Error in input observer:', error)
        }
      }
    }
    return subject.value
  }
  
  return [getter, setter]
}

export function observeInput<T>(subject: Subject<T>, callback: () => void): () => void {
  const observers = inputObservers.get(subject as Subject<unknown>)
  if (observers) {
    observers.add(callback)
  }
  
  return () => {
    const observers = inputObservers.get(subject as Subject<unknown>)
    if (observers) {
      observers.delete(callback)
    }
  }
}