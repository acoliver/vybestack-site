export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName', 
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || value.trim().length === 0) {
      errors[field] = `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`;
    }
  });

  // Email validation
  if (data.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation
  if (data.phone) {
    // Allow digits, spaces, parentheses, dashes, leading + and international format symbols
    const phoneRegex = /^[+]?[@()\-\s\d]+$/;
    if (!phoneRegex.test(data.phone) || data.phone.trim().length < 7) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation - allow alphanumeric, spaces, and dashes
  if (data.postalCode) {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode) || data.postalCode.trim().length < 3) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}