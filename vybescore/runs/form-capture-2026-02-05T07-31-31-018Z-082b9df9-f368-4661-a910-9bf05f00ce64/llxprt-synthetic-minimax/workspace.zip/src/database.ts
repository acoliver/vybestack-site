import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

export interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    if (!existsSync('data')) {
      mkdirSync('data', { recursive: true });
    }

    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
    });

    const dbExists = existsSync(this.dbPath);
    
    if (dbExists) {
      const dbBuffer = readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      this.createSchema();
    }
  }

  private createSchema(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const schemaSQL = readFileSync(this.schemaPath, 'utf8');
    this.db.exec(schemaSQL);
  }

  insertSubmission(submission: Submission): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);
    
    stmt.free();
    this.saveToDisk();
  }

  private saveToDisk(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const dbBuffer = this.db.export();
    writeFileSync(this.dbPath, Buffer.from(dbBuffer));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default DatabaseManager;