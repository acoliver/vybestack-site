import express, { Request, Response } from 'express';
import path from 'path';
import DatabaseManager, { Submission } from './database.js';
import { validateContactForm } from './middleware/validation.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Database manager
let dbManager: DatabaseManager;

async function initializeServer() {
  dbManager = new DatabaseManager();
  await dbManager.initialize();
  console.log('Database initialized successfully');
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Form',
    errors: {},
    formData: {}
  });
});

app.post('/submit', validateContactForm, (req: Request, res: Response) => {
  try {
    const submission: Submission = {
      firstName: req.body.firstName.trim(),
      lastName: req.body.lastName.trim(),
      streetAddress: req.body.streetAddress.trim(),
      city: req.body.city.trim(),
      stateProvince: req.body.stateProvince.trim(),
      postalCode: req.body.postalCode.trim(),
      country: req.body.country.trim(),
      email: req.body.email.trim(),
      phone: req.body.phone.trim()
    };

    dbManager.insertSubmission(submission);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('form', {
      title: 'Contact Form',
      errors: { general: 'An error occurred. Please try again.' },
      formData: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  
  if (dbManager) {
    dbManager.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
initializeServer()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  })
  .catch((error) => {
    console.error('Failed to initialize server:', error);
    process.exit(1);
  });
