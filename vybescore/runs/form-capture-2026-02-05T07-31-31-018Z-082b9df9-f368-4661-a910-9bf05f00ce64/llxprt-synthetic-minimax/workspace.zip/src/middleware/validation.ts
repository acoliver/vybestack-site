import { Request, Response, NextFunction } from 'express';
import { validateFormData, ValidationResult } from '../validation.js';

interface ValidationRequest extends Request {
  validationResult?: ValidationResult;
}

export function validateContactForm(req: ValidationRequest, res: Response, next: NextFunction) {
  const validationResult = validateFormData(req.body);
  req.validationResult = validationResult;
  
  if (!validationResult.isValid) {
    return res.status(400).render('form', {
      title: 'Contact Form',
      errors: validationResult.errors,
      formData: req.body
    });
  }
  
  next();
}