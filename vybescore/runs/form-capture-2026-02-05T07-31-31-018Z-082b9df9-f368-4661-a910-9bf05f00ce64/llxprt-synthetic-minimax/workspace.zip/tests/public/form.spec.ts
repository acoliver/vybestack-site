import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, ChildProcess } from 'child_process';

let serverProcess: ChildProcess | undefined;
let appUrl: string;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Start the server
  return new Promise((resolve, reject) => {
    serverProcess = spawn('npm', ['run', 'dev'], {
      stdio: ['ignore', 'pipe', 'pipe'],
      cwd: process.cwd()
    });

    let serverStarted = false;

    serverProcess.stdout?.on('data', (data: Buffer) => {
      const output = data.toString();
      if (output.includes('Server running on http://localhost:')) {
        serverStarted = true;
        appUrl = 'http://localhost:3535';
        resolve(undefined);
      }
    });

    serverProcess.stderr?.on('data', (data: Buffer) => {
      console.error('Server stderr:', data.toString());
    });

    serverProcess.on('error', (error: Error) => {
      if (!serverStarted) {
        reject(error);
      }
    });

    // Timeout if server doesn't start
    setTimeout(() => {
      if (!serverStarted) {
        reject(new Error('Server failed to start'));
      }
    }, 10000);
  });
});

afterAll(() => {
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
    // Give it time to clean up
    return new Promise(resolve => setTimeout(resolve, 1000));
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(appUrl).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Friendly Contact Form');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    const fields = [
      'firstName',
      'lastName', 
      'streetAddress',
      'city',
      'stateProvince',
      'postalCode',
      'country',
      'email',
      'phone'
    ];
    
    fields.forEach(field => {
      expect($(`#${field}`)).toHaveLength(1);
      expect($(`#${field}`).attr('name')).toBe(field);
    });
    
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('button[type="submit"]')).toHaveLength(1);
  });

  it('validates required fields', async () => {
    const response = await request(appUrl)
      .post('/submit')
      .send({})
      .type('form');
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Please fix the following errors');
  });

  it('validates email format', async () => {
    const response = await request(appUrl)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'invalid-email',
        phone: '555-1234'
      })
      .type('form');
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });

  it('persists submission and redirects', async () => {
    // Clean up database first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown', 
      stateProvince: 'State',
      postalCode: '12345',
      country: 'Country',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(appUrl)
      .post('/submit')
      .send(submissionData)
      .type('form');
    
    expect(response.status).toBe(302);
    expect(response.header.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page with humorous content', async () => {
    const response = await request(appUrl).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you for your submission!');
    expect(response.text).toContain('stranger on the internet');
    expect(response.text).toContain('definitely not a scam');
  });

  it('accepts international phone formats', async () => {
    const submissionData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Toronto',
      stateProvince: 'Ontario',
      postalCode: 'M5V 3H1',
      country: 'Canada',
      email: 'jane.smith@example.com',
      phone: '+1 416-555-7890'
    };

    const response = await request(appUrl)
      .post('/submit')
      .send(submissionData)
      .type('form');
    
    expect(response.status).toBe(302);
  });

  it('accepts international postal codes', async () => {
    const submissionData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test Rd',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'test@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(appUrl)
      .post('/submit')
      .send(submissionData)
      .type('form');
    
    expect(response.status).toBe(302);
  });

  it('preserves form data on validation errors', async () => {
    const response = await request(appUrl)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: '',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'john@example.com',
        phone: '555-1234'
      })
      .type('form');
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('value="John"');
    expect(response.text).toContain('required');
  });
});
