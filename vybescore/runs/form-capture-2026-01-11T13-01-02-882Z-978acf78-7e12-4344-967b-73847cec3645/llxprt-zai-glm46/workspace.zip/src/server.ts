import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const projectRoot = path.resolve(__dirname, '..');

// Types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Database configuration
const dbDir = path.join(projectRoot, 'data');
const dbPath = path.join(dbDir, 'submissions.sqlite');
const schemaPath = path.join(projectRoot, 'db', 'schema.sql');

// Ensure data directory exists
if (!fs.existsSync(dbDir)) {
  fs.mkdirSync(dbDir, { recursive: true });
}

// Initialize database
let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  // Load existing database or create new one
  let database: Database;
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    database = new SQL.Database(buffer);
  } else {
    database = new SQL.Database();
  }

  // Run schema to ensure table exists
  const schema = fs.readFileSync(schemaPath, 'utf-8');
  database.run(schema);

  return database;
}

// Validation functions
function validateEmail(email: string): boolean {
  // Simple but effective email regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[\d\s\-()]+$/;
  const phoneWithPlusRegex = /^\+[\d\s\-()]+$/;
  return phoneRegex.test(phone) || phoneWithPlusRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const trimmed = postalCode.trim();
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return trimmed.length > 0 && postalRegex.test(postalCode);
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field];
    if (!value || (typeof value === 'string' && value.trim().length === 0)) {
      const labelMap: Record<string, string> = {
        firstName: 'First name',
        lastName: 'Last name',
        streetAddress: 'Street address',
        city: 'City',
        stateProvince: 'State / Province / Region',
        postalCode: 'Postal / Zip code',
        country: 'Country',
        email: 'Email',
        phone: 'Phone number',
      };
      errors.push({ field, message: `${labelMap[field]} is required.` });
    }
  }

  // Email validation
  if (data.email && data.email.trim().length > 0 && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address.' });
  }

  // Phone validation
  if (data.phone && data.phone.trim().length > 0 && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +.',
    });
  }

  // Postal code validation
  if (data.postalCode && data.postalCode.trim().length > 0 && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code must contain only letters and digits.',
    });
  }

  return errors;
}

// Express app setup
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use('/public', express.static(path.join(projectRoot, 'public')));

// Set up EJS - use src/templates for development and dist/templates for production
const templatesDir = fs.existsSync(path.join(__dirname, 'templates'))
  ? path.join(__dirname, 'templates')
  : path.join(projectRoot, 'src', 'templates');
app.set('views', templatesDir);
app.set('view engine', 'ejs');

// Routes
app.get('/', (_req: express.Request, res: express.Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', {
      errors: errors.map((e) => e.message),
      values: formData,
    });
    return;
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim(),
      ]
    );

    // Export database to disk
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: express.Request, res: express.Response) => {
  res.render('thank-you', {
    firstName: 'Friend',
  });
});

// Server state
let server: ReturnType<typeof app.listen> | null = null;

// Start server function
export async function startServer(): Promise<{ app: typeof app; server: NonNullable<ReturnType<typeof app.listen>> }> {
  db = await initializeDatabase();

  return new Promise((resolve) => {
    const srv = app.listen(PORT, () => {
      console.log(`Server is listening on port ${PORT}`);
      server = srv;
      resolve({ app, server: srv });
    });
  });
}

// Graceful shutdown function
export async function stopServer(): Promise<void> {
  return new Promise((resolve) => {
    if (server) {
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        console.log('Server closed gracefully');
        resolve();
      });
    } else {
      if (db) {
        db.close();
        db = null;
      }
      resolve();
    }
  });
}

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await stopServer();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await stopServer();
  process.exit(0);
});

// Start server if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
