import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer, stopServer } from '../../src/server.js';

let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const result = await startServer();
  app = result.app;
});

afterAll(async () => {
  await stopServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);

    const $ = cheerio.load(response.text);

    // Check for all form fields with proper labels
    const fields = [
      { label: 'First name', id: 'firstName', name: 'firstName' },
      { label: 'Last name', id: 'lastName', name: 'lastName' },
      { label: 'Street address', id: 'streetAddress', name: 'streetAddress' },
      { label: 'City', id: 'city', name: 'city' },
      { label: 'State / Province / Region', id: 'stateProvince', name: 'stateProvince' },
      { label: 'Postal / Zip code', id: 'postalCode', name: 'postalCode' },
      { label: 'Country', id: 'country', name: 'country' },
      { label: 'Email', id: 'email', name: 'email' },
      { label: 'Phone number', id: 'phone', name: 'phone' },
    ];

    for (const field of fields) {
      // Check label exists and has proper for attribute
      const label = $(`label[for="${field.id}"]`);
      expect(label.length).toBeGreaterThan(0);
      expect(label.text().trim()).toBe(field.label);

      // Check input exists with proper id and name
      const input = $(`#${field.id}[name="${field.name}"]`);
      expect(input.length).toBeGreaterThan(0);
    }

    // Check form action
    const form = $('form[action="/submit"]');
    expect(form.length).toBe(1);
    expect(form.attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    // Clean up database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Follow redirect
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    const $ = cheerio.load(thankYouResponse.text);
    const pageTitle = $('h1').text();
    expect(pageTitle).toContain('Thank you');

    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'invalid-email',
      phone: 'invalid-phone-@#$',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    // Check for error messages
    const errorText = $('.error-list').text();
    expect(errorText).toContain('required');
    expect(errorText).toContain('email');
  });

  it('accepts international phone formats', async () => {
    const testPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '(020) 7946 0958',
    ];

    for (const phone of testPhones) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '1 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone,
        });

      // Should not have validation errors for phone
      if (response.status === 400) {
        const $ = cheerio.load(response.text);
        const errorText = $('.error-list').text();
        expect(errorText).not.toContain('Phone number');
      }
    }
  });

  it('accepts international postal code formats', async () => {
    const testPostalCodes = ['SW1A 1AA', 'C1000', 'B1675', '12345'];

    for (const postalCode of testPostalCodes) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '1 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode,
          country: 'Test Country',
          email: 'test@example.com',
          phone: '+1 555 123 4567',
        });

      // Should not have validation errors for postal code
      if (response.status === 400) {
        const $ = cheerio.load(response.text);
        const errorText = $('.error-list').text();
        expect(errorText).not.toContain('Postal code');
      }
    }
  });
});
