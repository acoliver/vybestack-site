/**
 * Find words starting with the given prefix, escaping specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }
  
  // Simple approach: split text into words and check each
  const words = text.split(/\s+/);
  const result = new Set<string>();
  
  for (const word of words) {
    const cleanWord = word.replace(/[^a-zA-Z]/g, ''); // Remove punctuation
    if (cleanWord.startsWith(prefix) && 
        cleanWord.length > prefix.length &&
        !exceptions.includes(cleanWord)) {
      result.add(cleanWord);
    }
  }
  
  return Array.from(result);
}

/**
 * Find occurrences of token that appear after a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Simple approach: find all occurrences and check context
  const matches: string[] = [];
  let index = text.indexOf(token);
  
  while (index !== -1) {
    // Check if there's a digit right before the token
    // and the token is not at the very start
    if (index > 0 && text[index - 1] >= '0' && text[index - 1] <= '9') {
      // Include the digit + token
      matches.push(text.substring(index - 1, index + token.length));
    }
    
    // Look for next occurrence
    index = text.indexOf(token, index + 1);
  }
  
  return matches;
}

/**
 * Strong password validation: at least 10 characters, one uppercase, one lowercase,
 * one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab)
  // This is a simplified check for obvious patterns
  for (let i = 2; i < value.length - 2; i++) {
    const chunk1 = value.substring(i - 2, i);
    const chunk2 = value.substring(i, i + 2);
    
    if (chunk1 === chunk2) return false;
  }
  
  // Check for more complex repeated patterns like ababa, ababab
  for (let i = 3; i < value.length - 3; i++) {
    const chunk1 = value.substring(i - 3, i);
    const chunk2 = value.substring(i, i + 3);
    
    if (chunk1 === chunk2) return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand notation (::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 address patterns
  // Full IPv6: eight groups of 1-4 hex digits separated by colons
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Compressed IPv6 with ::
  const ipv6Compressed = /\b(?:[0-9a-fA-F]{1,4}:)*:[0-9a-fA-F]{0,4}::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with :: at start or end
  const ipv6EdgeCompressed = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::\b/;
  
  // IPv4-mapped IPv6: ::ffff:192.168.1.1
  const ipv4MappedIPv6 = /::ffff:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // IPv6 with embedded IPv4: 2001:db8::192.168.1.1
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // IPv4 address pattern (to exclude false positives)
  const ipv4 = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // First check if the string looks like an IPv4 address
  if (ipv4.test(value) && !value.includes(':')) {
    return false;
  }
  
  // Check for various IPv6 patterns
  return ipv6Full.test(value) || 
         ipv6Compressed.test(value) || 
         ipv6EdgeCompressed.test(value) || 
         ipv4MappedIPv6.test(value) || 
         ipv6WithIPv4.test(value);
}
