/**
 * Capitalize the first character of each sentence after .!? punctuation.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Attempts to preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, normalize spacing around sentence endings
  const normalized = text
    .replace(/\s*([.!?])\s*/g, '$1 ') // Single space after punctuation
    .replace(/\s+/g, ' ') // Collapse multiple spaces
    .trim(); // Remove leading/trailing spaces
  
  // Simple approach: split on sentence endings and capitalize each
  const parts = normalized.split(/([.!?]\s+)/);
  let result = '';
  let capitalizeNext = true;
  
  for (const part of parts) {
    if (capitalizeNext && part.trim()) {
      result += part.charAt(0).toUpperCase() + part.slice(1);
      capitalizeNext = false;
    } else {
      result += part;
      // If this part ends with sentence punctuation, capitalize the next part
      if (/[.!?]\s*/.test(part)) {
        capitalizeNext = true;
      }
    }
  }
  
  return result.trim();
}

/**
 * Extract URLs from text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern - matches http, https, ftp protocols and www domains
  const urlRegex = /\b((?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"]+(?<![,.;:!?)]))/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation and return unique URLs
  return [...new Set(
    matches.map(url => {
      // Remove trailing punctuation but keep essential URL characters
      return url.replace(/[\.,;:!?()\[\]{}]+$/g, '');
    })
  )];
}

/**
 * Convert all http:// URLs to https:// while leaving existing https:// URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// but don't touch https://
  return text.replace(/http:\/\/([^\s<>"]+)/g, 'https://$1');
}

/**
 * Rewrite example.com URLs to https:// and docs.example.com for /docs/ paths.
 * Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Match http://example.com URLs
  const exampleComRegex = /http:\/\/example\.com(\/[^\s<>"]*)/gi;
  
  return text.replace(exampleComRegex, (match, path) => {
    // Always upgrade to https
    let newUrl = 'https://example.com' + path;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for exclusion patterns that should prevent docs rewrite
      // Use escaped patterns for the regex
      const hasQueryString = /[?=&]/.test(path);
      const hasCgiBin = /\/cgi-bin\//i.test(path);
      const hasLegacyExt = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      const shouldExcludes = hasQueryString || hasCgiBin || hasLegacyExt;
      
      if (!shouldExcludes) {
        // Rewrite to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' for invalid formats or impossible dates.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Strict mm/dd/yyyy regex
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic date validation - check for impossible dates
  const maxDays = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Leap year check for February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  };
  
  const daysInMonth = month === 2 && isLeapYear(year) ? 29 : maxDays[month];
  
  if (day > daysInMonth) return 'N/A';
  
  return year;
}
