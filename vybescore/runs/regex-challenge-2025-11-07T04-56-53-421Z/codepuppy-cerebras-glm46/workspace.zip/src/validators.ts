export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation supporting typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email regex with edge case handling
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  const [local, domain] = value.split('@');
  
  // No double dots in local or domain
  if (local.includes('..') || domain.includes('..')) return false;
  
  // No trailing dots
  if (local.endsWith('.') || domain.endsWith('.')) return false;
  
  // Domain cannot contain underscores
  if (domain.includes('_')) return false;
  
  // Domain must have at least one dot
  if (!domain.includes('.')) return false;
  
  // Domain parts cannot be empty
  if (domain.split('.').some(part => !part)) return false;
  
  return true;
}

/**
 * US phone number validation supporting (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (starting with 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if it has +1 country code
  const hasCountryCode = value.startsWith('+1');
  const cleanDigits = hasCountryCode ? digits.slice(1) : digits;
  
  // US phone numbers must have exactly 10 digits (without country code)
  if (cleanDigits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = cleanDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check for valid format patterns
  const phoneRegex = /^(\+1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  return phoneRegex.test(value.replace(/\s+/g, ' '));
}

/**
 * Argentine phone number validation for landlines and mobiles.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex patterns
  // Pattern breakdown:
  // ^\+54? - optional country code
  // (?:9)? - optional mobile indicator
  // 0? - optional trunk prefix
  // ([2-9]\d{1,3}) - area code (2-4 digits, starts with 1-9)
  // (\d{6,8})$ - subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?0?([2-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) return false;
  
  // Additional validation: when no country code, must start with 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) return false;
  
  return true;
}

/**
 * Name validation allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols, but allow basic punctuation for names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional checks
  // No consecutive spaces or hyphens
  if (value.includes('  ') || value.includes('--')) return false;
  
  // Single character names are probably invalid (unless accent)
  if (value.trim().length < 2) return false;
  
  // Reject obvious technical/pattern names
  const technicalPatterns = /[0-9@#$%&*()=+\[\]{}|\/<>?]/;
  if (technicalPatterns.test(value)) return false;
  
  return true;
}

/**
 * Luhn checksum calculation helper function.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit.toString().split('').reduce((acc, d) => acc + parseInt(d, 10), 0);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Credit card validation supporting Visa/Mastercard/AmEx with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check card prefixes and lengths
  // Visa: starts with 4, length 13-19
  const visaRegex = /^4(\d{12}|\d{15}|\d{16}|\d{17}|\d{18})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{11})))$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleaned);
}
