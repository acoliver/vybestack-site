import { readFileSync, writeFileSync } from 'fs';
import { ReportData, FormatType, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);

if (args.length < 2) {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  process.exit(1);
}

const dataFile = args[0];
const formatIndex = args.indexOf('--format');
if (formatIndex === -1 || formatIndex >= args.length - 1) {
  console.error('Error: --format flag is required');
  process.exit(1);
}

const format = args[formatIndex + 1] as FormatType;
if (!['markdown', 'text'].includes(format)) {
  console.error('Error: Unsupported format. Supported formats: markdown, text');
  process.exit(1);
}

const outputIndex = args.indexOf('--output');
const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : null;

const includeTotalsIndex = args.indexOf('--includeTotals');
const includeTotals = includeTotalsIndex !== -1;

// Read and parse JSON data
let reportData: ReportData;
try {
  const dataContent = readFileSync(dataFile, 'utf8');
  const parsed = JSON.parse(dataContent);
  
  // Validate data structure
  if (!parsed.title || !parsed.summary || !Array.isArray(parsed.entries)) {
    console.error('Error: Invalid JSON structure. Expected fields: title, summary, entries');
    process.exit(1);
  }
  
  // Validate entries
  for (let i = 0; i < parsed.entries.length; i++) {
    const entry = parsed.entries[i];
    if (!entry.label || typeof entry.amount !== 'number') {
      console.error(`Error: Invalid entry at index ${i}. Expected fields: label (string), amount (number)`);
      process.exit(1);
    }
  }
  
  reportData = parsed as ReportData;
} catch (error) {
  if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
    console.error(`Error: Cannot read file '${dataFile}'`);
  } else if (error instanceof SyntaxError) {
    console.error('Error: Invalid JSON format');
  } else {
    console.error('Error: Failed to read or parse data file');
  }
  process.exit(1);
}

// Render the report
const formatter = format === 'markdown' ? renderMarkdown : renderText;
const options: RenderOptions = { includeTotals };
const output = formatter.render(reportData, options);

// Output the result
if (outputPath) {
  try {
    writeFileSync(outputPath, output);
  } catch (error) {
    console.error(`Error: Failed to write output file '${outputPath}'`);
    process.exit(1);
  }
} else {
  process.stdout.write(output);
}