/**
 * Encode plain text to Base64 using RFC 4648 canonical alphabet.
 * Uses standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 string.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Check for invalid Base64 characters (anything other than A-Z, a-z, 0-9, +, /, =)
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error('Invalid Base64 input');
  }

  // Check padding is only at the end (if present)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.substring(paddingIndex);
    const nonPaddingPart = input.substring(0, paddingIndex);
    
    // Non-padding part should only contain Base64 characters without =
    if (!/^[A-Za-z0-9+/]*$/.test(nonPaddingPart)) {
      throw new Error('Invalid Base64 input');
    }
    
    // Padding should be either one or two = characters at the end
    if (!/^(=|==)$/.test(paddingPart) || paddingIndex < input.length - paddingPart.length) {
      throw new Error('Invalid Base64 input');
    }
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: ensure the input was properly decodable
    // by trying to re-encode and compare (handling padding differences)
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedInput = input.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    // Special case for the empty string
    if (normalizedInput === '' && normalizedReencoded === '') {
      return result;
    }
    
    // For non-empty inputs, the normalized versions should match
    if (normalizedInput !== normalizedReencoded) {
      throw new Error('Invalid Base64 input');
    }
    
    return result;
  } catch (error) {
    throw new Error('Invalid Base64 input');
  }
}
