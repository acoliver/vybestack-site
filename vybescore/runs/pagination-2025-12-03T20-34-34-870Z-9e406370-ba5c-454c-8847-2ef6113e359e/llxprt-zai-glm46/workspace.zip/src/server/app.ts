import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validation: reject non-numeric, negative, zero, or excessive values
    const page = pageParam ? Number(pageParam) : 1;
    const limit = limitParam ? Number(limitParam) : 5;

    // Validate page parameter
    if (pageParam !== undefined) {
      if (isNaN(page) || page <= 0 || !Number.isInteger(page)) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
    }

    // Validate limit parameter  
    if (limitParam !== undefined) {
      if (isNaN(limit) || limit <= 0 || !Number.isInteger(limit) || limit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer <= 100' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
