declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    export(): Uint8Array;
    prepare(sql: string): Statement;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    get(params?: unknown[]): unknown;
    all(params?: unknown[]): unknown[];
    free(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface RunResult {
    changes: number;
    lastInsertRowid: number;
  }

  export interface SqlJsStatic {
    Database: new (data?: Buffer | ArrayLike<number>) => Database;
  }

  export default function initSqlJs(config?: Record<string, unknown>): Promise<SqlJsStatic>;
}
