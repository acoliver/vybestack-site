import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || '3535';
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

let db: Database | null = null;
let isInitialized = false;

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');

// When compiled, __dirname points to dist/, but views stay in src/views
const viewsPath = path.join(__dirname, '..', 'src', 'views');
app.set('views', viewsPath);

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^@?[\d\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, spaces, and hyphens' });
  }

  if (!data.country || data.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'valid email' });
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading @' });
  }

  return errors;
}

app.get('/', async (req: Request, res: Response) => {
  await initDatabase();
  res.render('form', {
    errors: [],
    data: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  await initDatabase();
  
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', {
      errors,
      data: formData
    });
    return;
  }

  if (!db) {
    errors.push({ field: '_', message: 'Database not available' });
    res.status(500);
    res.render('form', {
      errors,
      data: formData
    });
    return;
  }

  try {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      formData.firstName!,
      formData.lastName!,
      formData.streetAddress!,
      formData.city!,
      formData.stateProvince!,
      formData.postalCode!,
      formData.country!,
      formData.email!,
      formData.phone!
    ]);
    stmt.free();

    const data = db.export();
    const buffer = Buffer.from(data);
    await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
    await fs.writeFile(DB_PATH, buffer);

    res.redirect(302, '/thank-you');
  } catch (err) {
    console.error('Database error:', err);
    errors.push({ field: '_', message: 'Failed to save submission' });
    res.status(500);
    res.render('form', {
      errors,
      data: formData
    });
  }
});

app.get('/thank-you', async (req: Request, res: Response) => {
  await initDatabase();
  res.render('thank-you');
});

async function initDatabase(): Promise<void> {
  if (isInitialized) {
    return;
  }

  try {
    const SQL = await initSqlJs();
    let dbBuffer: Buffer | null = null;

    try {
      const fileData = await fs.readFile(DB_PATH);
      dbBuffer = fileData;
    } catch (err) {
      console.log('No existing database found, creating new one');
    }

    const DbClass = SQL.Database;
    db = new DbClass(dbBuffer ?? undefined);

    const schema = await fs.readFile(
      path.join(process.cwd(), 'db', 'schema.sql'),
      'utf-8'
    );
    
    if (db) {
      db.run(schema);
    }

    isInitialized = true;
    console.log('Database initialized successfully');
  } catch (err) {
    console.error('Failed to initialize database:', err);
    throw err;
  }
}

async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
    console.log('Database closed');
  }
}

function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}, shutting down gracefully...`);
  closeDatabase()
    .then(() => {
      process.exit(0);
    })
    .catch((err) => {
      console.error('Error during shutdown:', err);
      process.exit(1);
    });
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

async function startServer(): Promise<void> {
  try {
    await initDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    throw err;
  }
}

// Only start server if this file is run directly (not when imported for tests)
const modulePath = fileURLToPath(import.meta.url);
if (process.argv[1] === modulePath) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { app, closeDatabase };
