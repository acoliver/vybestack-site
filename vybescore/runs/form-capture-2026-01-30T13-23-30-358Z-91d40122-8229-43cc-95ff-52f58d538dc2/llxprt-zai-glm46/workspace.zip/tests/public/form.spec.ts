import { describe, it, expect, beforeAll } from 'vitest';
import request from 'supertest';
import { app, closeDatabase } from '../../src/server.js';

describe('Form Application', () => {
  beforeAll(async () => {
    // Wait a bit for server initialization
    await new Promise(resolve => setTimeout(resolve, 100));
  });

  afterAll(async () => {
    await closeDatabase();
  });

  describe('GET /', () => {
    it('should render the form page', async () => {
      const response = await request(app).get('/');
      expect(response.status).toBe(200);
      expect(response.text).toContain('Friendly International Contact Form');
    });

    it('should include all form fields', async () => {
      const response = await request(app).get('/');
      expect(response.text).toContain('name="firstName"');
      expect(response.text).toContain('name="lastName"');
      expect(response.text).toContain('name="streetAddress"');
      expect(response.text).toContain('name="city"');
      expect(response.text).toContain('name="stateProvince"');
      expect(response.text).toContain('name="postalCode"');
      expect(response.text).toContain('name="country"');
      expect(response.text).toContain('name="email"');
      expect(response.text).toContain('name="phone"');
    });

    it('should have associated labels for all inputs', async () => {
      const response = await request(app).get('/');
      expect(response.text).toContain('for="firstName"');
      expect(response.text).toContain('for="lastName"');
      expect(response.text).toContain('for="streetAddress"');
      expect(response.text).toContain('for="city"');
      expect(response.text).toContain('for="stateProvince"');
      expect(response.text).toContain('for="postalCode"');
      expect(response.text).toContain('for="country"');
      expect(response.text).toContain('for="email"');
      expect(response.text).toContain('for="phone"');
    });
  });

  describe('POST /submit', () => {
    const validSubmission = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '@44 20 7946 0958'
    };

    it('should accept valid international submission', async () => {
      const response = await request(app)
        .post('/submit')
        .send(validSubmission);
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should reject empty required fields', async () => {
      const response = await request(app)
        .post('/submit')
        .send({});
      expect(response.status).toBe(400);
      expect(response.text).toContain('First name is required');
    });

    it('should reject invalid email format', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          email: 'invalid-email'
        });
      expect(response.status).toBe(400);
      expect(response.text).toContain('valid email');
    });

    it('should accept UK postal code format', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          postalCode: 'SW1A 1AA'
        });
      expect(response.status).toBe(302);
    });

    it('should accept Argentine postal code format', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          postalCode: 'C1000',
          city: 'Buenos Aires',
          country: 'Argentina'
        });
      expect(response.status).toBe(302);
    });

    it('should accept international phone formats', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          phone: '@54 9 11 1234-5678',
          country: 'Argentina'
        });
      expect(response.status).toBe(302);
    });

    it('should redisplay form with errors on validation failure', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: '',
          lastName: '',
          email: 'not-an-email'
        });
      expect(response.status).toBe(400);
      expect(response.text).toContain('First name is required');
      expect(response.text).toContain('valid email');
    });

    it('should preserve entered values on validation error', async () => {
      const partialData = {
        firstName: 'Jane',
        lastName: 'Smith',
        email: 'invalid-email-format'
      };
      const response = await request(app)
        .post('/submit')
        .send(partialData);
      expect(response.status).toBe(400);
      expect(response.text).toContain('value="Jane"');
      expect(response.text).toContain('value="Smith"');
    });
  });

  describe('GET /thank-you', () => {
    it('should render thank you page', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.status).toBe(200);
      expect(response.text).toContain('Thank You');
      expect(response.text).toContain('stranger on the internet');
    });

    it('should contain humorous scam warning', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.text).toMatch(/spam|identity theft|stranger/i);
    });

    it('should link back to form', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.text).toContain('href="/"');
    });
  });

  describe('CSS', () => {
    it('should serve styles.css', async () => {
      const response = await request(app).get('/styles.css');
      expect(response.status).toBe(200);
      expect(response.headers['content-type']).toMatch(/css/);
      expect(response.text.length).toBeGreaterThan(1000);
    });
  });
});
