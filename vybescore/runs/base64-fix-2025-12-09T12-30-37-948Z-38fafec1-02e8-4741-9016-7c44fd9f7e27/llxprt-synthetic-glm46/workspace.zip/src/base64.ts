/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Reject empty input
  if (input.length === 0) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Validate Base64 format - must contain only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  const paddingIndex = input.indexOf('=');
  
  if (paddingIndex !== -1) {
    // Check for invalid padding
    validatePadding(input, paddingIndex);
    // If there's padding, total length must be divisible by 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  } else {
    validateLengthWithoutPadding(input);
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

function validatePadding(input: string, paddingIndex: number): void {
  // Padding must only appear at the end
  const paddingSection = input.substring(paddingIndex);
  if (!/^[=]+$/.test(paddingSection)) {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }
  
  // Padding must be 1 or 2 characters max
  const paddingLength = paddingSection.length;
  if (paddingLength > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
}

function validateLengthWithoutPadding(input: string): void {
  // Without padding, accept inputs where length modulo 4 is 0 (complete 4-char chunks)
  // or where we can pad implicitly
  const mod4 = input.length % 4;
  if (mod4 !== 0 && mod4 === 1) {
    // Only single Base64 characters can never be valid padding
    throw new Error('Invalid Base64 input: incorrect length');
  }
  // For mod4 == 2 or 3, we can add padding implicitly
  // These are valid cases like "YQ" (should be "YQ==") or "YWI" (should be "YWI=")
}