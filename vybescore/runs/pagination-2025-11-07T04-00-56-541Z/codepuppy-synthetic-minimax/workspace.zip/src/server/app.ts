import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate query parameters
    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    // Check for non-numeric values
    if ((pageParam !== undefined && isNaN(Number(pageParam))) ||
        (limitParam !== undefined && isNaN(Number(limitParam)))) {
      return res.status(400).json({ error: 'Page and limit must be numeric values' });
    }

    // Check for negative, zero, or excessive values
    if (page !== undefined && (page <= 0 || !Number.isInteger(page))) {
      return res.status(400).json({ error: 'Page must be a positive integer' });
    }

    if (limit !== undefined && (limit <= 0 || !Number.isInteger(limit))) {
      return res.status(400).json({ error: 'Limit must be a positive integer' });
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
