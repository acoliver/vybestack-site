import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  function validateQueryParams(pageParam: string | undefined, limitParam: string | undefined) {
  let page: number | undefined;
  let limit: number | undefined;

  if (pageParam !== undefined) {
    page = Number(pageParam);
    if (isNaN(page) || page < 1 || !Number.isInteger(page)) {
      throw new Error('Page must be a positive integer');
    }
  }

  if (limitParam !== undefined) {
    limit = Number(limitParam);
    if (isNaN(limit) || limit < 1 || !Number.isInteger(limit)) {
      throw new Error('Limit must be a positive integer');
    }
    if (limit > 100) {
      throw new Error('Limit cannot exceed 100');
    }
  }

  return { page, limit };
}

app.get('/inventory', (req, res) => {
  try {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const { page, limit } = validateQueryParams(pageParam, limitParam);

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Invalid request parameters';
    res.status(400).json({ error: message });
  }
});

  return app;
}
