// Simple reactive implementation without complex observer tracking

// Observer tracking
let currentObserver: any = null

// Input type
type InputPair<T> = [() => T, (value: T) => T]

// Computed type
type ComputedFn<T> = () => T

// Callback type
type UnsubscribeFn = () => void

// Create input value
function createInput<T>(value: T): InputPair<T> {
  const observers: any[] = []
  
  const getter = () => {
    if (currentObserver) {
      observers.push(currentObserver)
    }
    return value
  }
  
  const setter = (newValue: T) => {
    if (Object.is(value, newValue)) return value
    value = newValue
    observers.forEach(observer => observer())
    return value
  }
  
  return [getter, setter]
}

// Create computed value
function createComputed<T>(fn: () => T): ComputedFn<T> {
  let cached: T | undefined
  const observers: any[] = []
  
  const compute = () => {
    const prevObserver = currentObserver
    currentObserver = compute
    try {
      const result = fn()
      if (!Object.is(result, cached)) {
        cached = result
        observers.forEach(observer => observer())
      }
      return cached
    } finally {
      currentObserver = prevObserver
    }
  }
  
  return compute
}

// Create callback
function createCallback(fn: () => void): UnsubscribeFn {
  const prevObserver = currentObserver
  currentObserver = fn
  try {
    fn()
  } finally {
    currentObserver = prevObserver
  }
  
  return () => {} // noop unsubscribe for this test
}

// Export
export { createInput, createComputed, createCallback }