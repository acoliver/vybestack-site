/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Enhanced Subject type to track all observers 
 */
type EnhancedSubject<T> = Subject<T> & {
  observers?: Observer<unknown>[]
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Set up equality function
  let equalFn: EqualFn<T>
  if (equal === true) {
    // Default equality using Object.is
    equalFn = (a: T, b: T) => Object.is(a, b)
  } else if (equal === false) {
    // No equality check, always trigger updates
    equalFn = () => false
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    // Default equality using Object.is
    equalFn = (a: T, b: T) => Object.is(a, b)
  }

  const s: EnhancedSubject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: []
  }

  const read: GetterFn<T> = () => {
    // Register current observer (computed or callback) as dependent
    const currentObserved = (globalThis as any)._currentComputed
    
    if (currentObserved && typeof currentObserved === 'function') {
      if (s.observers && !s.observers.includes(currentObserved as Observer<unknown>)) {
        s.observers.push(currentObserved as Observer<unknown>)
      }
    }
    
    // Keep the original observer mechanism for backward compatibility
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      if (s.observers && !s.observers.includes(observer as Observer<unknown>)) {
        s.observers.push(observer as Observer<unknown>)
      }
    }
    
    return s.value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    // Check if value has changed using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value // No change, return current value
    }

    s.value = nextValue
    
    // Notify all dependent observers
    if (s.observers) {
      s.observers.forEach(observer => {
        if (typeof observer === 'function') {
          // It's a function from our computed system
          observer()
        } else {
          // It's an Observer from the original system
          updateObserver(observer as Observer<unknown>)
        }
      })
    }
    
    // Also notify the primary observer for backward compatibility
    if (s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}
