/**
 * Computed closure implementation
 * Simplified approach based on the simple-reactive.ts example
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  let observers: (() => void)[] = []  // Observers that depend on this computed value
  let disposed = false

  // Set up equality function
  let equalFn: EqualFn<T>
  if (equal === true) {
    // Default equality using Object.is
    equalFn = (a: T, b: T) => Object.is(a, b)
  } else if (equal === false) {
    // No equality check, always trigger updates
    equalFn = () => false
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    // Default equality using Object.is
    equalFn = (a: T, b: T) => Object.is(a, b)
  }

  let cachedValue: T | undefined = value

  const compute = (): T => {
    if (disposed) {
      throw new Error(`Computed observer '${options?.name || 'unnamed'}' has been disposed`)
    }
    
    // Set ourselves as the current observer during computation
    const prevObserver = (globalThis as any)._currentComputed
    ;(globalThis as any)._currentComputed = compute
    
    try {
      // The updateFn call will track dependencies via their getters
      const result = updateFn(cachedValue)
      
      // Update cached value if it changed or if this is the first computation
      if (cachedValue === undefined || !equalFn(result, cachedValue)) {
        cachedValue = result
        // Notify all observers that depend on this computed value
        observers.forEach(observer => observer())
      }
      
      return cachedValue as T
    } finally {
      ;(globalThis as any)._currentComputed = prevObserver
    }
  }

  // Initialize the value if not provided
  // Note: We skip initialization here and compute on demand to avoid double computation

  const getter: GetterFn<T> = () => {
    // Register the current computed or callback as dependent on us
    const currentObserved = (globalThis as any)._currentComputed
    
    if (currentObserved && typeof currentObserved === 'function' && !observers.includes(currentObserved)) {
      observers.push(currentObserved)
    }
    
    return compute()
  }

  return getter
}