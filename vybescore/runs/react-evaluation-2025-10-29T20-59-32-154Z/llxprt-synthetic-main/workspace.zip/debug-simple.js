// Test the simple implementation
import { createInput, createComputed } from './simple-reactive.js'

console.log('Testing simple reactive chain...')

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  const result = input() * 2
  console.log('timesTwo computed:', result)
  return result
})

const timesThirty = createComputed(() => {
  const result = input() * 30
  console.log('timesThirty computed:', result)
  return result
})

const sum = createComputed(() => {
  const result = timesTwo() + timesThirty()
  console.log('sum computed:', result)
  return result
})

console.log('Initial sum:', sum())
setInput(3)
console.log('After setting input to 3:')
console.log('Input value:', input())
console.log('Final sum:', sum())