// Debug the computed test case
import { createComputed } from './src/index.js'

console.log('Testing computed with initial value...')

const testFunction = (x: number = 3) => x * 2
console.log('Function result:', testFunction(3))

const computed = createComputed(testFunction)
console.log('Computed value:', computed())