// Debug the computed test case
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing simple case with input...')
const [input] = createInput(5)
const double = createComputed(() => input() * 2)
console.log('Double of 5:', double())

console.log('\nTesting computed with initial value...')
const testFn = (x?: number) => {
  console.log(`updateFn called with x=${x}`)
  return (x ?? 3) * 2
}

const computed = createComputed(testFn)
console.log('Computed value after creation:', computed())