// Debug the computed test case
import { createComputed } from './src/index.js'

console.log('Testing computed with initial value...')

const computed = createComputed((x: number = 3) => x * 2)
console.log('Computed value:', computed())