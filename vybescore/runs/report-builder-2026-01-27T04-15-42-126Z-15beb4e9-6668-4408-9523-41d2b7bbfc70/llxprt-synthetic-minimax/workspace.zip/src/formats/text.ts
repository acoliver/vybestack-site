import { ReportData } from '../types.js';

export function renderText(data: ReportData, includeTotals: boolean): string {
  const lines: string[] = [];
  
  // Add title (no markdown formatting)
  lines.push(data.title);
  lines.push(''); // blank line
  
  // Add summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Add entries section
  lines.push('Entries:');
  
  // Add each entry as bullet list
  for (const entry of data.entries) {
    const formattedAmount = formatCurrency(entry.amount);
    lines.push(`- ${entry.label}: $${formattedAmount}`);
  }
  
  // Add totals if requested
  if (includeTotals) {
    lines.push(''); // blank line before total
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = formatCurrency(total);
    lines.push(`Total: $${formattedTotal}`);
  }
  
  return lines.join('\n');
}

function formatCurrency(amount: number): string {
  return amount.toFixed(2);
}