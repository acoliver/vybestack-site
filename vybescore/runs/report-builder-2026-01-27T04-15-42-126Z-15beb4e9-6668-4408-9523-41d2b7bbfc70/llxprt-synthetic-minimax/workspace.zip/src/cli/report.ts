import { readFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): CLIOptions {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputPath = args[2];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments starting from index 3
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1] as 'markdown' | 'text';
      i++; // Skip next arg as it's the format value
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next arg as it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return {
    inputPath,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  // Check required fields
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: "title" field must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" field must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: "entries" field must be an array');
  }

  // Validate entries
  const entries = reportData.entries;
  if (entries.length === 0) {
    throw new Error('Invalid JSON: "entries" array cannot be empty');
  }

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i] as Record<string, unknown>;
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a string`);
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a number`);
    }
  }

  // Type assertion is safe due to validation above
  return reportData as unknown as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf-8');
    const jsonData = JSON.parse(fileContent);
    return validateReportData(jsonData);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.startsWith('ENOENT')) {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

import { writeFileSync } from 'fs';

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    // For simplicity, using writeFileSync - could be improved with streams for large files
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    console.log(content);
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const options = parseArgs(process.argv);
    const data = loadReportData(options.inputPath);
    const rendered = renderReport(data, options.format, options.includeTotals);
    writeOutput(rendered, options.outputPath);
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(errorMessage);
    process.exit(1);
  }
}

// Only run main if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
