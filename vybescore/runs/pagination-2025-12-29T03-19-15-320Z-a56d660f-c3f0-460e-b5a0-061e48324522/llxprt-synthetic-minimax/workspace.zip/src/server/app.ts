import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      if (isNaN(Number(pageParam)) || !isFinite(Number(pageParam))) {
        return res.status(400).json({ error: 'Page must be a valid number' });
      }
      const pageNum = Number(pageParam);
      if (pageNum <= 0 || !Number.isInteger(pageNum)) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      if (pageNum > 10000) { // Reasonable maximum
        return res.status(400).json({ error: 'Page number is too large' });
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      if (isNaN(Number(limitParam)) || !isFinite(Number(limitParam))) {
        return res.status(400).json({ error: 'Limit must be a valid number' });
      }
      const limitNum = Number(limitParam);
      if (limitNum <= 0 || !Number.isInteger(limitNum)) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      if (limitNum > 100) { // Reasonable maximum
        return res.status(400).json({ error: 'Limit cannot exceed 100 items per page' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
