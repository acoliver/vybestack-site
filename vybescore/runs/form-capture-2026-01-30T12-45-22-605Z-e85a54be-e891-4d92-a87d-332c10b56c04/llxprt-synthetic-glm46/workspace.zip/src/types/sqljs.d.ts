// Type definitions for sql.js
export interface Database {
  close(): void;
  run(sql: string, ...params: unknown[]): unknown;
  prepare(sql: string): Statement;
  export(): Uint8Array;
}

export interface Statement {
  run(...params: unknown[]): unknown;
  free(): void;
}

export function createDatabase(data?: Uint8Array): Database;

declare module 'sql.js' {
  export const Database: unknown;
  export default function(options?: unknown): unknown;
}