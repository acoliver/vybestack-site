import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import type { Database } from './types/sqljs.js';
// eslint-disable-next-line @typescript-eslint/no-unused-vars
import type { Statement } from './types/sqljs.js';



const PORT = process.env.PORT || 3535;
const DATA_DIR = path.join(process.cwd(), 'data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');
const DB_SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

let db: Database | null = null;

async function initializeDatabase(): Promise<Database | null> {
  // Ensure data directory exists
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  let dbBuffer: Uint8Array;
  
  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const dbData = fs.readFileSync(DB_PATH);
    dbBuffer = new Uint8Array(dbData);
  } else {
    dbBuffer = new Uint8Array([]);
  }

  // Initialize database
  // @ts-expect-error - sql.js doesn't have perfect types
  const SQL = await import('sql.js');
  const sqljs = await SQL.default();
  db = new sqljs.Database(dbBuffer);

  // If this is a new database, create schema
  if (!fs.existsSync(DB_PATH)) {
    const schema = fs.readFileSync(DB_SCHEMA_PATH, 'utf-8');
    if (db) {
      db.run(schema);
      saveDatabase(db);
    }
  }

  return db;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  fs.writeFileSync(DB_PATH, Buffer.from(data));
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  }
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation - allow digits, spaces, parentheses, dashes, and leading + or @
  const phoneRegex = /^[\s\d\-()]+$|^[@+][\s\d\-()]+$/;
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation - alphanumeric values
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  if (data.postalCode && !postalRegex.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  return errors;
}

function parseFormData(body: Record<string, string>): FormData {
  return {
    firstName: body.firstName,
    lastName: body.lastName,
    streetAddress: body.streetAddress,
    city: body.city,
    stateProvince: body.stateProvince,
    postalCode: body.postalCode,
    country: body.country,
    email: body.email,
    phone: body.phone,
  };
}

async function main() {
  const app = express();
  
  // Initialize database
  db = await initializeDatabase();
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static('public'));
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'views'));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: [],
      formData: {},
      success: null 
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData = parseFormData(req.body);
    const errors = validateForm(formData);

    if (errors.length > 0) {
      // Render form with errors and previously entered data
      res.status(400).render('form', {
        errors,
        formData,
        success: null
      });
      return;
    }

    try {
      // Insert into database
      if (!db) {
        throw new Error('Database not initialized');
      }
      const stmt = db.prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Save database to disk
      saveDatabase(db);
      
      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        errors: [{ field: 'general', message: 'An error occurred while saving your submission. Please try again.' }],
        formData,
        success: null
      });
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you');
  });

  // Graceful shutdown
  function gracefulShutdown() {
    if (db) {
      db.close();
      db = null;
    }
    process.exit(0);
  }

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);

  // Start server
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  if (db) {
    db.close();
  }
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  if (db) {
    db.close();
  }
  process.exit(1);
});

// Start the application
main().catch(error => {
  console.error('Failed to start application:', error);
  process.exit(1);
});
