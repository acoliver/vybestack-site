#!/usr/bin/env node

import fs from 'fs';
import type { ReportData, RenderOptions, FormatRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): CliOptions {
  if (argv.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const options: CliOptions = {
    format: '',
    includeTotals: false
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = argv[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      options.outputPath = argv[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return options;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: Expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: Missing or invalid "entries" field');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: Entry ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: Entry ${index} has missing or invalid "label"`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: Entry ${index} has missing or invalid "amount"`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function getFormatRenderer(format: string): FormatRenderer {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    
    const dataFilePath = process.argv[2];
    if (!dataFilePath) {
      console.error('Error: Data file path is required');
      process.exit(1);
    }

    const reportData = loadReportData(dataFilePath);
    const renderer = getFormatRenderer(options.format);
    
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals
    };

    const output = renderer(reportData, renderOptions);

    if (options.outputPath) {
      fs.writeFileSync(options.outputPath, output, 'utf-8');
      console.log(`Report written to ${options.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}