/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set(),
  }

  const read: GetterFn<T> = () => {
    // Establish dependency: if there's an active observer,
    // make this computed observer a subscriber to it
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      if (!activeObserver.subscribers) {
        activeObserver.subscribers = new Set()
      }
      activeObserver.subscribers.add(o)
    }
    
    // Set this computed observer as active and update value
    const previous = getActiveObserver()
    setActiveObserver(o)
    try {
      const newValue = updateFn(o.value)
      const oldValue = o.value
      o.value = newValue
      
      // Notify subscribers if the value changed
      if (oldValue !== newValue && o.subscribers && o.subscribers.size > 0) {
        for (const subscriber of [...o.subscribers]) {
          try {
            updateObserver(subscriber as Observer<unknown>)
          } catch (error) {
            o.subscribers.delete(subscriber)
          }
        }
      }
    } finally {
      setActiveObserver(previous)
    }
    
    // Always notify subscribers when this computed value is accessed
    // This ensures callbacks get re-executed
    if (o.subscribers && o.subscribers.size > 0) {
      for (const subscriber of [...o.subscribers]) {
        try {
          updateObserver(subscriber as Observer<unknown>)
        } catch (error) {
          o.subscribers.delete(subscriber)
        }
      }
    }
    
    return o.value!
  }

  // Create a method to notify subscribers when this computed value changes
  const notifySubscribers = () => {
    if (o.subscribers && o.subscribers.size > 0) {
      for (const subscriber of [...o.subscribers]) {
        try {
          updateObserver(subscriber as Observer<unknown>)
        } catch (error) {
          o.subscribers.delete(subscriber)
        }
      }
    }
  }

  // Override the getter to also notify subscribers
  const originalRead = read
  return () => {
    const result = originalRead()
    // Notify subscribers that this computed value was read (and potentially changed)
    if (o.subscribers && o.subscribers.size > 0) {
      notifySubscribers()
    }
    return result
  }
}
