/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    subscribers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Establish subscription relationship
      if (!s.subscribers) {
        s.subscribers = new Set()
      }
      s.subscribers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    // Notify all subscribers of the change
    if (s.subscribers && s.subscribers.size > 0) {
      const subscribers = [...s.subscribers]
      for (const subscriber of subscribers) {
        try {
          // Set this input subject as active so dependency tracking works correctly
          const previous = getActiveObserver()
          setActiveObserver(s as unknown as ObserverR)
          try {
            updateObserver(subscriber as Observer<unknown>)
          } finally {
            setActiveObserver(previous)
          }
        } catch (error) {
          s.subscribers.delete(subscriber)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
