/**
 * Type definitions for the reactive programming system.
 */

/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subscribers?: Set<ObserverR>
  dependencies?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  subscribers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const observerStack: ObserverR[] = []

export function getActiveObserver(): ObserverR | undefined {
  return observerStack[observerStack.length - 1]
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  if (observer) {
    observerStack.push(observer)
  } else if (observerStack.length > 0) {
    observerStack.pop()
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addDependency(observer: ObserverR, dependency: ObserverR): void {
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(dependency)
}

export function notifySubscribers(observer: ObserverR): void {
  const subscribers = observer.subscribers
  if (!subscribers) return
  
  for (const subscriber of [...subscribers]) {
    try {
      updateObserver(subscriber as Observer<unknown>)
    } catch (error) {
      // Remove failed subscribers
      subscribers.delete(subscriber)
    }
  }
}
