#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { type ReportData, type RenderOptions, type Format, FormatMap } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatMap: FormatMap = {
  markdown: renderMarkdown,
  text: renderText
};

function parseArguments(args: string[]): { inputFile: string; format: Format; outputFile?: string; includeTotals: boolean } {
  let inputFile = '';
  let format: Format = 'markdown';
  let outputFile: string | undefined;
  let includeTotals = false;

  let i = 2; // Skip node and script name
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputFile = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
    i++;
  }

  if (!inputFile) {
    throw new Error('Input file is required');
  }

  return { inputFile, format, outputFile, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: expected an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }

  for (const entry of reportData.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: each entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: each entry must have a label (string)');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: each entry must have an amount (number)');
    }
  }

  return reportData as unknown as ReportData;
}

function main() {
  try {
    const args = process.argv;
    const { inputFile, format, outputFile, includeTotals } = parseArguments(args);

    // Read and parse JSON file
    let data: unknown;
    try {
      const fileContent = readFileSync(inputFile, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Invalid JSON in file ${inputFile}: ${error.message}`);
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`File not found: ${inputFile}`);
      } else {
        throw error;
      }
    }

    // Validate data
    const reportData = validateReportData(data);

    // Render report
    const formatter = formatMap[format];
    const options: RenderOptions = { includeTotals };
    const output = formatter(reportData, options);

    // Write output
    if (outputFile) {
      writeFileSync(outputFile, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
