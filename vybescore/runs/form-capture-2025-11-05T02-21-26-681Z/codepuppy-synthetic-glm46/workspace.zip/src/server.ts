import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import createDatabase from 'sql.js';

interface SqlJsDatabase {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): {
    run(params: unknown[]): void;
    free(): void;
  };
  export(): Uint8Array;
  close(): void;
}

type Database = SqlJsDatabase;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
  sanitizedData: FormData;
}

const app = express();
const port = process.env.PORT || '3000';
const dbPath = path.resolve('data', 'submissions.sqlite');

let db: Database | null = null;

// Create data directory if it doesn't exist
const dataDir = path.dirname(dbPath);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await createDatabase();
    
    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const dbData = fs.readFileSync(dbPath);
      db = new SQL.Database(dbData);
      console.log('Loaded existing database from', dbPath);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(path.resolve('db', 'schema.sql'), 'utf8');
      if (db) {
        db.run(schema);
      }
      saveDatabase();
      console.log('Created new database at', dbPath);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateRequired(value: string, fieldName: string): string | null {
  if (!value || value.trim().length === 0) {
    return `${fieldName} is required`;
  }
  return null;
}

function validateEmail(email: string): string | null {
  const requiredError = validateRequired(email, 'Email');
  if (requiredError) return requiredError;
  
  // Simple email regex that works internationally
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Please enter a valid email address';
  }
  return null;
}

function validatePhone(phone: string): string | null {
  const requiredError = validateRequired(phone, 'Phone number');
  if (requiredError) return requiredError;
  
  // Allow international formats: digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return 'Please enter a valid phone number';
  }
  return null;
}

function validatePostalCode(postalCode: string): string | null {
  const requiredError = validateRequired(postalCode, 'Postal code');
  if (requiredError) return requiredError;
  
  // Allow alphanumeric codes with spaces (SW1A 1AA, C1000, B1675, etc.)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  if (!postalRegex.test(postalCode)) {
    return 'Please enter a valid postal code';
  }
  return null;
}

function sanitizeInput(value: string): string {
  return value.trim();
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  const sanitizedData: FormData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };

  // Validate each field
  const firstNameError = validateRequired(data.firstName || '', 'First name');
  if (firstNameError) errors.push(firstNameError);
  sanitizedData.firstName = sanitizeInput(data.firstName || '');

  const lastNameError = validateRequired(data.lastName || '', 'Last name');
  if (lastNameError) errors.push(lastNameError);
  sanitizedData.lastName = sanitizeInput(data.lastName || '');

  const streetAddressError = validateRequired(data.streetAddress || '', 'Street address');
  if (streetAddressError) errors.push(streetAddressError);
  sanitizedData.streetAddress = sanitizeInput(data.streetAddress || '');

  const cityError = validateRequired(data.city || '', 'City');
  if (cityError) errors.push(cityError);
  sanitizedData.city = sanitizeInput(data.city || '');

  const stateProvinceError = validateRequired(data.stateProvince || '', 'State / Province / Region');
  if (stateProvinceError) errors.push(stateProvinceError);
  sanitizedData.stateProvince = sanitizeInput(data.stateProvince || '');

  const postalCodeError = validatePostalCode(data.postalCode || '');
  if (postalCodeError) errors.push(postalCodeError);
  sanitizedData.postalCode = sanitizeInput(data.postalCode || '');

  const countryError = validateRequired(data.country || '', 'Country');
  if (countryError) errors.push(countryError);
  sanitizedData.country = sanitizeInput(data.country || '');

  const emailError = validateEmail(data.email || '');
  if (emailError) errors.push(emailError);
  sanitizedData.email = sanitizeInput(data.email || '');

  const phoneError = validatePhone(data.phone || '');
  if (phoneError) errors.push(phoneError);
  sanitizedData.phone = sanitizeInput(data.phone || '');

  return {
    isValid: errors.length === 0,
    errors,
    sanitizedData
  };
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve('public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

// Routes
app.get('/', (req: Request, res: Response): void => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response): void => {
  const formData = req.body as Partial<FormData>;
  const validation = validateForm(formData);

  if (!validation.isValid) {
    res.status(400).render('form', {
      errors: validation.errors,
      values: validation.sanitizedData
    });
    return;
  }

  try {
    // Insert into database
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      validation.sanitizedData.firstName,
      validation.sanitizedData.lastName,
      validation.sanitizedData.streetAddress,
      validation.sanitizedData.city,
      validation.sanitizedData.stateProvince,
      validation.sanitizedData.postalCode,
      validation.sanitizedData.country,
      validation.sanitizedData.email,
      validation.sanitizedData.phone
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(validation.sanitizedData.firstName)}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['Failed to save your submission. Please try again.'],
      values: validation.sanitizedData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response): void => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database closed');
  }

  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(parseInt(port, 10), () => {
    console.log(`Server running on port ${port}`);
  });

  // Handle graceful shutdown
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Export server for testing
let serverInstance: unknown;

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
} else {
  // For testing purposes
  initializeDatabase().then(() => {
    (globalThis as Record<string, unknown>).__TEST_APP__ = app;
    (globalThis as Record<string, unknown>).__TEST_DB__ = db;
  });
}

export { app, db, serverInstance };
