import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

// Import server dynamically for testing
let server: unknown;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and initialize the server
  const serverModule = await import('../../dist/server.js');
  app = serverModule.app;
  
  // Start the server on a different port for testing
  server = app.listen(0); // 0 means random available port
  return new Promise<void>((resolve) => {
    server.on('listening', () => {
      resolve();
    });
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server)
      .get('/')
      .expect(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that all form fields are present
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check that form has correct action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
    
    // Check that labels are properly associated
    expect($('label[for="firstName"]').text()).toContain('First name');
    expect($('label[for="email"]').text()).toContain('Email');
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    // Submit form
    const response = await request(server)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    // Check redirect location
    expect(response.headers.location).toContain('/thank-you');
    expect(response.headers.location).toContain('firstName=John');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Check that we can access the thank you page
    await request(server)
      .get('/thank-you?firstName=John')
      .expect(200);
  });
});
