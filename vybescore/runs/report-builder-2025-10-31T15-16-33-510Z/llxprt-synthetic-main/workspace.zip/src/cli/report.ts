#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(): ParsedArgs {
  const args = process.argv.slice(2);
  let dataPath: string | undefined;
  let format: string | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing format value after --format');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Missing output path after --output');
      }
      output = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('-') && !dataPath) {
      dataPath = arg;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!dataPath) {
    throw new Error('Missing data file path');
  }

  if (!format) {
    throw new Error('Missing format option');
  }

  return { dataPath, format, output, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const dataObj = data as Record<string, unknown>;

  if (typeof dataObj.title !== 'string') {
    throw new Error('Missing or invalid title field');
  }

  if (typeof dataObj.summary !== 'string') {
    throw new Error('Missing or invalid summary field');
  }

  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Missing or invalid entries field');
  }

  for (const entry of dataObj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: expected object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid label');
    }
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error('Invalid entry: missing or invalid amount');
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArguments();
    
    // Read JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.dataPath, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Invalid JSON in file ${args.dataPath}: ${error.message}`);
      }
      throw error;
    }

    // Validate data
    const reportData = validateReportData(jsonData);

    // Prepare options
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    // Render by format
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown.render(reportData, options);
        break;
      case 'text':
        output = renderText.render(reportData, options);
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }

    // Write output
    if (args.output) {
      writeFileSync(args.output, output, 'utf8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
