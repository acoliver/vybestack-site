import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Simple tests for our static assets
describe('friendly form (public smoke)', () => {
  it('has form template with all fields', () => {
    const formTemplate = fs.readFileSync(
      path.join(__dirname, '..', '..', 'src', 'templates', 'form.ejs'),
      'utf8'
    );
    
    // Check main elements exist
    expect(formTemplate).toContain('Tell us who you are');
    expect(formTemplate).toContain('action="/submit"');
    expect(formTemplate).toContain('method="post"');
    
    // Check all required fields exist
    expect(formTemplate).toContain('name="firstName"');
    expect(formTemplate).toContain('name="lastName"');
    expect(formTemplate).toContain('name="streetAddress"');
    expect(formTemplate).toContain('name="city"');
    expect(formTemplate).toContain('name="stateProvince"');
    expect(formTemplate).toContain('name="postalCode"');
    expect(formTemplate).toContain('name="country"');
    expect(formTemplate).toContain('name="email"');
    expect(formTemplate).toContain('name="phone"');
    
    // Check proper label associations
    expect(formTemplate).toContain('for="firstName"');
    expect(formTemplate).toContain('for="email"');
    expect(formTemplate).toContain('for="phone"');
  });

  it('has thank you template with humorous copy', () => {
    const thankYouTemplate = fs.readFileSync(
      path.join(__dirname, '..', '..', 'src', 'templates', 'thank-you.ejs'),
      'utf8'
    );
    
    expect(thankYouTemplate).toContain('Thank you');
    expect(thankYouTemplate).toContain('stranger on the internet');
  });

  it('has stylesheet with modern styles', () => {
    const stylesheet = fs.readFileSync(
      path.join(__dirname, '..', '..', 'public', 'styles.css'),
      'utf8'
    );
    
    // Check for modern CSS features
    expect(stylesheet).toContain('grid');
    expect(stylesheet).toContain('flex');
    expect(stylesheet).toContain('border-radius');
    expect(stylesheet.length).toBeGreaterThan(1000); // Ensure non-empty with substantial content
  });

  it('database schema exists and has proper structure', () => {
    const schema = fs.readFileSync(
      path.join(__dirname, '..', '..', 'db', 'schema.sql'),
      'utf8'
    );
    
    expect(schema).toContain('CREATE TABLE');
    expect(schema).toContain('submissions');
    expect(schema).toContain('first_name');
    expect(schema).toContain('email');
    expect(schema).toContain('phone');
  });

  it('server code has form validation logic', () => {
    const serverCode = fs.readFileSync(
      path.join(__dirname, '..', '..', 'src', 'server.ts'),
      'utf8'
    );
    
    expect(serverCode).toContain('validateForm');
    expect(serverCode).toContain('email');
    expect(serverCode).toContain('phone');
    expect(serverCode).toContain('required');
  });

  it('server code has database integration', () => {
    const serverCode = fs.readFileSync(
      path.join(__dirname, '..', '..', 'src', 'server.ts'),
      'utf8'
    );
    
    expect(serverCode).toContain('Database');
    expect(serverCode).toContain('INSERT INTO submissions');
    expect(serverCode).toContain('initSqlJs');
  });

  it('server has proper routing', () => {
    const serverCode = fs.readFileSync(
      path.join(__dirname, '..', '..', 'src', 'server.ts'),
      'utf8'
    );
    
    expect(serverCode).toContain("app.get('/',");
    expect(serverCode).toContain("app.post('/submit',");
    expect(serverCode).toContain("app.get('/thank-you',");
  });

  it('server has graceful shutdown handling', () => {
    const serverCode = fs.readFileSync(
      path.join(__dirname, '..', '..', 'src', 'server.ts'),
      'utf8'
    );
    
    expect(serverCode).toContain('SIGTERM');
    expect(serverCode).toContain('gracefulShutdown');
    expect(serverCode).toContain('db.close');
  });
});