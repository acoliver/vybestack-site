export interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

export interface Statement {
  run(...params: any[]): void;
  free(): void;
}

export interface SqlJsStatic {
  Database: new (data?: Uint8Array) => Database;
}

export const initSqlJs = (config?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic> => {
  return import('sql.js').then(module => module.default(config));
};