import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { initSqlJs, Database } from './sqljs.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

const app = express();
const port = process.env.PORT || '3535';
let db: Database | null = null;

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.static(path.join(__dirname)));
app.use(express.urlencoded({ extended: true }));

function validateForm(data: Partial<FormData>): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

async function initializeDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });

    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    let dbBuffer: Uint8Array | null = null;

    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(fileBuffer);
    }

    const database = new SQL.Database(dbBuffer || undefined);

    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    database.exec(schema);

    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(database: Database): void {
  try {
    const data = database.export();
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

app.get('/', (req, res) => {
  res.render('form', { 
    errors: {},
    formData: {}
  });
});

app.post('/submit', async (req, res) => {
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const validation = validateForm(formData);

    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        formData,
      });
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();
    saveDatabase(db);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while processing your submission' },
      formData: req.body,
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

let server: import('http').Server | null = null;

async function startServer() {
  try {
    db = await initializeDatabase();
    
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    const gracefulShutdown = (signal: string) => {
      console.log(`Received ${signal}, shutting down gracefully`);
      
      if (server) {
        server.close(() => {
          console.log('Express server closed');
          
          if (db) {
            try {
              db.close();
              console.log('Database connection closed');
            } catch (error) {
              console.error('Error closing database:', error);
            }
          }
          
          process.exit(0);
        });
      }
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Only start server if this file is run directly
if (process.argv[1] === import.meta.url.replace('file://', '')) {
  startServer();
}

// Export the app for testing
export default app;
