export interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

export interface Statement {
  run(...params: any[]): void;
  free(): void;
}

declare module 'sql.js' {
  interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  function initSqlJs(config?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
  
  export default initSqlJs;
}