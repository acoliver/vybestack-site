import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      // Must be numeric, greater than 0, and reasonable (avoid excessive values)
      if (!/^\d+$/.test(pageParam) || Number(pageParam) <= 0 || Number(pageParam) > 1000) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer less than 1000.' });
      }
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      // Must be numeric, greater than 0, and reasonable (avoid excessive values)
      if (!/^\d+$/.test(limitParam) || Number(limitParam) <= 0 || Number(limitParam) > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer less than 100.' });
      }
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
