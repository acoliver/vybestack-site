/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split text into sentences based on sentence endings
  // Handle . ? ! as sentence terminators
  const sentences = text.split(/([.!?]+["'\s]*["']?\s*)/g);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    if (sentence.trim() === '') {
      // Handle whitespace and separators
      result += sentence;
      continue;
    }
    
    // Check if this segment ends a sentence
    if (/[.!?]+["'\s]*["']?$/.test(sentence.trim())) {
      // End of sentence found
      if (capitalizeNext && sentence.trim()) {
        // Capitalize first letter of sentence
        const trimmed = sentence.trim();
        result += sentence.substring(0, sentence.indexOf(trimmed)) + 
                 trimmed.charAt(0).toUpperCase() + 
                 trimmed.substring(1);
      } else {
        result += sentence;
      }
      capitalizeNext = true;
    } else if (sentence.trim() && capitalizeNext) {
      // Start of new sentence, capitalize
      const trimmed = sentence.trim();
      result += sentence.substring(0, sentence.indexOf(trimmed)) + 
               trimmed.charAt(0).toUpperCase() + 
               trimmed.substring(1);
      capitalizeNext = false;
    } else {
      result += sentence;
    }
  }
  
  // Clean up spacing - ensure single spaces between sentences
  result = result.replace(/\s+([.!?])/g, '$1 '); // Remove extra spaces before sentence endings
  result = result.replace(/([.!?])[."'\s]*\s+/g, '$1 '); // Clean up after sentence endings
  result = result.replace(/\s+/g, ' '); // Collapse multiple spaces
  
  // Ensure proper sentence spacing
  result = result.replace(/([.!?])(?!["'\s]*["']?\s*$)([A-Z])/g, '$1 $2');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern to match various URL formats
  // Matches http/https URLs with optional trailing punctuation
  const urlPattern = /\bhttps?:\/\/[^\s<>"']+[.,?!;:]*[.,?!;]*(?=\s|$|[<>"'])/gi;
  
  const matches = text.match(urlPattern);
  if (!matches) return [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that shouldn't be part of the URL
    return url.replace(/[.,?!;:]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http:// URLs and transform them
  // Capture: 1=scheme, 2=host, 3=path
  const httpUrlPattern = /(http):\/\/([^/\s]+)([^\s]*)/gi;
  
  return text.replace(httpUrlPattern, (match, scheme, host, path) => {
    // Always upgrade scheme to https
    let newUrl = 'https://';
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const hasDocsPath = /^\/docs\//.test(path);
    const hasDynamicHints = /(\?|cgi-bin|&|=|cgi\.|\.jsp|\.php|\.asp|\.aspx|\.do|\.pl|\.py)/.test(path);
    
    if (hasDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.example.com' + path;
    } else {
      // Keep original host
      newUrl += host + path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for February (leap year handling not needed for validation)
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Additional validation for February
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  return year;
}
