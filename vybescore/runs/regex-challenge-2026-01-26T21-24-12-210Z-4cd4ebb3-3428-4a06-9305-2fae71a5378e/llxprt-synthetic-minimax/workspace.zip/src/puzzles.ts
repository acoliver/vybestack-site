/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a regex pattern to find words starting with the prefix
  // Word boundary to ensure whole word match
  const pattern = new RegExp(`\\b${escapeRegExp(prefix)}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !lowerExceptions.includes(lowerWord);
  });
}

// Helper function to escape special regex characters
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  const validMatches: string[] = [];
  
  // Find all occurrences of the token that immediately follow a digit
  // Pattern to match: digit followed by token
  const pattern = new RegExp(`(\\d)${escapeRegExp(token)}`, 'gi');
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Return the entire match (digit + token)
    validMatches.push(match[0]);
  }
  
  return validMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{}|;:,.<>?~]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for simple alternating patterns like "abab", "1212", "XYXY"
  // Look for 4-character sequences where position 1 and 3 match, position 2 and 4 match
  for (let i = 0; i < value.length - 3; i++) {
    const fourChars = value.substring(i, i + 4);
    if (fourChars.length === 4) {
      const chars = fourChars.split('');
      if (chars[0] === chars[2] && chars[1] === chars[3]) {
        return false; // Found repeating alternating sequence
      }
    }
  }
  
  // Check for more complex alternating patterns (6 characters)
  for (let i = 0; i < value.length - 5; i++) {
    const sixChars = value.substring(i, i + 6);
    if (sixChars.length === 6) {
      const chars = sixChars.split('');
      // Pattern XYXYXY where XY repeats 3 times
      if (chars[0] === chars[2] && chars[0] === chars[4] && 
          chars[1] === chars[3] && chars[1] === chars[5]) {
        return false; // Found repeating alternating sequence
      }
    }
  }
  
  // Simple check for consecutive identical characters (4+ in a row)
  const consecutivePattern = /(.)\1{3,}/;
  if (consecutivePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, rule out IPv4 addresses to avoid false positives
  // IPv4 pattern: X.X.X.X where X is 1-3 digits (0-255)
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g;
  if (ipv4Pattern.test(value)) {
    // Contains IPv4, so we return false (we only want IPv6)
    return false;
  }
  
  // IPv6 address detection patterns
  
  // Pattern 1: Standard IPv6 with colons (handles zero compression with ::)
  // Matches formats like: 2001:0db8:0000:0000:0000:ff00:0042:7879
  const standardIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/g;
  
  // Pattern 2: IPv6 with zero compression (::)
  // Matches formats like: 2001:db8::8a2e:370:7334 or ::1
  const compressedIPv6 = /\b(?:[0-9a-fA-F]{0,4}:){0,6}::[0-9a-fA-F]{0,4}\b/g;
  
  // Pattern 3: IPv6 loopback (::1)
  const loopbackIPv6 = /::1\b/g;
  
  // Pattern 4: IPv6 loopback/full notation (simplified)
  const fullLoopbackIPv6 = /\b0+:0+:0+:0+:0+:0+:0+:1\b/g;
  
  // Pattern 5: IPv6 with embedded IPv4 (X:X:X:X:X:X:X:X)
  // This handles cases like ::ffff:192.168.1.1
  const embeddedIPv4 = /\b(?:[0-9a-fA-F]{0,4}:){6}(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/g;
  
  // Test against all patterns
  const matchesStandard = standardIPv6.test(value);
  const matchesCompressed = compressedIPv6.test(value);
  const matchesLoopback = loopbackIPv6.test(value);
  const matchesFull = fullLoopbackIPv6.test(value);
  const matchesEmbedded = embeddedIPv4.test(value);
  
  return matchesStandard || matchesCompressed || matchesLoopback || matchesFull || matchesEmbedded;
}
