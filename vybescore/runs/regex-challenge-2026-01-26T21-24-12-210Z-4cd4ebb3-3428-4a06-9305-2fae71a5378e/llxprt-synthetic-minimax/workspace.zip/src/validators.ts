export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with restrictions
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for edge cases
  // No double dots in the local part
  if (value.split('@')[0].includes('..')) {
    return false;
  }
  
  // No trailing dots in domain
  const domain = value.split('@')[1];
  if (domain?.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain?.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  _options;
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if starts with optional +1
  const phoneRegex = /^(?:\+?1[\s.-]*)?(?:\(?([2-9][0-8][0-9])\)?[\s.-]*)?([2-9][0-9]{2})[\s.-]*([0-9]{4})$/;
  
  const match = cleaned.match(phoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const exchange = match[2];
  
  // Ensure we have a valid length (10-11 digits total)
  const totalDigits = cleaned.replace(/\D/g, '').length;
  if (totalDigits < 10 || totalDigits > 11) {
    return false;
  }
  
  // Area code cannot start with 0 or 1 (must be 2-9 for first digit)
  if (!areaCode || areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1 (must be 2-9 for first digit)
  if (!exchange || exchange[0] === '0' || exchange[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Argentine phone regex pattern
  // Optional +54, then optional 9 (mobile indicator), then area code (2-4 digits), then subscriber number
  // Total digits must be 8-13 (country code + area code + subscriber)
  const argentinePhoneRegex = /^(?:\+?54[\s.-]*)?(?:[\s.-]*9[\s.-]*)?(?:[\s.-]*0[\s.-]*)?([2-9][0-9]{1,3})[\s.-]*([0-9]{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits total)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Check total length
  const totalDigits = cleaned.replace(/\D/g, '').length;
  if (totalDigits < 8 || totalDigits > 13) {
    return false;
  }
  
  // If no country code, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('54')) {
    // Extract the number part and check if it starts with 0 (trunk)
    const numberPart = cleaned.match(/[0-9]+/);
    if (!numberPart || !numberPart[0].startsWith('0')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for empty or whitespace-only strings
  if (!value || !value.trim()) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Reject digits, symbols, and special character combinations
  const nameRegex = /^[\p{L}][\p{L}'\s-]*[\p{L}]$/u;
  
  // Check overall pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names containing digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names containing symbols that are not allowed
  if (/[!@#$%^&*()_+=[\]{}|;:',.<>?/`~]/.test(value)) {
    return false;
  }
  
  // Reject names that start with or contain unusual character combinations
  // like "X Æ A-12" style names
  if (/[ÆØÅ]/.test(value) && /[\d]/.test(value)) {
    return false;
  }
  
  // Reject consecutive special characters that don't make sense in names
  if (/['-]{2,}/.test(value)) {
    return false;
  }
  
  // Reject names starting with or ending with special characters (except apostrophes in middle)
  if (/^['\s-]|['\s-]$/.test(value.replace(/\s+/g, ' ').trim())) {
    return false;
  }
  
  // Ensure name has reasonable length (1-50 characters after trim)
  const trimmed = value.trim();
  if (trimmed.length < 1 || trimmed.length > 50) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check card type prefixes
  const cardType = getCardType(digits);
  if (!cardType.isValid) {
    return false;
  }
  
  // Validate specific length for card type
  if (digits.length !== cardType.length) {
    return false;
  }
  
  // Run Luhn checksum
  return luhnCheck(digits);
}

// Helper function to determine card type and validate
function getCardType(digits: string): { isValid: boolean; length: number } {
  // Visa: 4, 13-19 digits
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    return { isValid: true, length: digits.length };
  }
  
  // Mastercard: 51-55, 16 digits OR 2221-2720, 16 digits
  if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
       digits.startsWith('54') || digits.startsWith('55') || 
       (digits.startsWith('222') && parseInt(digits.substring(3, 4)) >= 1 && parseInt(digits.substring(3, 4)) <= 9) ||
       (digits.startsWith('2221') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9) ||
       (digits.startsWith('2222') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9) ||
       (digits.startsWith('2223') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9) ||
       (digits.startsWith('2224') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9) ||
       (digits.startsWith('2225') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9) ||
       (digits.startsWith('2226') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9) ||
       (digits.startsWith('2227') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9) ||
       (digits.startsWith('2720') && parseInt(digits.substring(4, 6)) >= 0 && parseInt(digits.substring(4, 6)) <= 9)) && digits.length === 16) {
    return { isValid: true, length: 16 };
  }
  
  // American Express: 34, 37, 15 digits
  if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    return { isValid: true, length: 15 };
  }
  
  return { isValid: false, length: 0 };
}

// Helper function for Luhn checksum algorithm
function luhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
