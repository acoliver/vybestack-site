import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

let db: Database | null = null;

// Serve static files from /public
app.use('/public', express.static(path.join(__dirname, '../public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));

// Set up EJS view engine
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    let fileBuffer: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      const fileData = fs.readFileSync(dbPath);
      fileBuffer = new Uint8Array(fileData);
    }
    
    db = new SQL.Database(fileBuffer);
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation helpers
function validateForm(formData: { [key: string]: string }): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields
  if (!formData.firstName?.trim()) errors.push('First name is required');
  if (!formData.lastName?.trim()) errors.push('Last name is required');
  if (!formData.streetAddress?.trim()) errors.push('Street address is required');
  if (!formData.city?.trim()) errors.push('City is required');
  if (!formData.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!formData.country?.trim()) errors.push('Country is required');
  if (!formData.email?.trim()) errors.push('Email is required');
  if (!formData.phone?.trim()) errors.push('Phone number is required');
  
  // Email validation (simple regex)
  if (formData.email?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
    errors.push('Please provide a valid email address');
  }
  
  // Phone validation (international formats with optional leading +)
  if (formData.phone?.trim() && !/^\+?[0-9\s()\-+]+$/.test(formData.phone.trim())) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +');
  }
  
  // Postal code validation (alphanumeric with optional dashes)
  if (formData.postalCode?.trim() && !/^[a-zA-Z0-9\\s-]+$/.test(formData.postalCode.trim())) {
    errors.push('Postal code can only contain letters, digits, spaces, and dashes');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const validation = validateForm(req.body);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: req.body
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      req.body.firstName?.trim(),
      req.body.lastName?.trim(),
      req.body.streetAddress?.trim(),
      req.body.city?.trim(),
      req.body.stateProvince?.trim(),
      req.body.postalCode?.trim(),
      req.body.country?.trim(),
      req.body.email?.trim(),
      req.body.phone?.trim()
    ]);
    
    stmt.free();
    
    // Save database after insert
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  // Extract first name from the latest submission if available
  let firstName = 'stranger';
  
  try {
    if (db) {
      const stmt = db.prepare(`
        SELECT first_name FROM submissions 
        ORDER BY rowid DESC 
        LIMIT 1
      `);
      const result = stmt.getAsObject(['first_name']) as { first_name: string };
      if (result.first_name) {
        firstName = result.first_name;
      }
      stmt.free();
    }
  } catch (error) {
    console.error('Failed to retrieve latest submission:', error);
  }
  
  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle graceful shutdown
  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}, closing server gracefully...`);
    
    server.close(() => {
      console.log('Server closed');
      
      if (db) {
        saveDatabase();
        db.close();
        db = null;
        console.log('Database closed');
      }
      
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Start the server
startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});