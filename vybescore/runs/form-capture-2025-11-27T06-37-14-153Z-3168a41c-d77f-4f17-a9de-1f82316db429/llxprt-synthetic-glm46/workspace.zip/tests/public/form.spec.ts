import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import { Request, Response } from 'express';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import express from 'express';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let app: express.Application;
const dbPath = path.resolve(__dirname, '../../data/submissions.sqlite');

// Mock database for testing
let db: {
  run: () => Record<string, unknown>;
  export: () => Uint8Array;
  close: () => void;
} | null = null;

// Simple form validation for testing
function validateFormSubmission(formData: Record<string, string>): { errors: string[] } {
  const errors: string[] = [];
  
  if (!formData.firstName?.trim()) errors.push('First name is required');
  if (!formData.lastName?.trim()) errors.push('Last name is required');
  if (!formData.streetAddress?.trim()) errors.push('Street address is required');
  if (!formData.city?.trim()) errors.push('City is required');
  if (!formData.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!formData.country?.trim()) errors.push('Country is required');
  if (!formData.email?.trim()) errors.push('Email is required');
  if (!formData.phone?.trim()) errors.push('Phone number is required');
  
// Email validation (simple regex)
  if (formData.email?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email.trim())) {
    errors.push('Please provide a valid email address');
  }
  
// Phone validation 
  if (formData.phone?.trim() && !/^[+?\d\s()-]+$/.test(formData.phone.trim())) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +');
  }
  
// Postal code validation 
  if (formData.postalCode?.trim() && !/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode.trim())) {
    errors.push('Postal/Zip code can only contain letters, numbers, spaces, and dashes');
  }
  
  return { errors };
}



afterAll(() => {
  // Clean up test database if it exists
  if (fs.existsSync(dbPath)) {
    try {
      fs.unlinkSync(dbPath);
    } catch (error) {
      console.log('Could not clean up test database:', error);
    }
  }
});

// Create a basic express app before running tests
beforeAll(() => {
  // Create Express app for testing
  app = express();
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Set view engine
  app.set('views', path.resolve(__dirname, '../../src/templates'));
  app.set('view engine', 'ejs');
  
  // Mock public directory
  app.use('/public', express.static(path.resolve(__dirname, '../../public')));
  
  // Test routes
  app.get('/', (_req: Request, res: Response) => {
    res.render('form', {
      title: 'Contact Form',
      errors: [],
      values: {}
    });
  });
  
  app.post('/submit', (req: Request, res: Response) => {
    const formData = req.body;
    const validation = validateFormSubmission(formData);
    
    console.log('Form data received:', formData);
    console.log('Validation result:', validation);
    
    if (validation.errors.length > 0) {
      console.log('Validation failed with errors:', validation.errors);
      return res.status(400).render('form', {
        title: 'Contact Form',
        errors: validation.errors,
        values: formData
      });
    }
    
    // Insert into mock database
    if (!db) {
      db = {
        run: () => ({}),
        export: () => new Uint8Array(),
        close: () => {}
      };
    }
    
    // Redirect to thank you page on successful submission
    console.log('Validation passed, redirecting to /thank-you');
    res.redirect('/thank-you');
  });
  
  app.get('/thank-you', (_req: Request, res: Response) => {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  });
});

describe('Form Submission Tests', () => {
  it('should render the form page correctly', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('<form');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
  });
  
  it('should handle successful form submission', async () => {
    const validData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(validData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Test thank you page works
    const thanksResponse = await request(app).get('/thank-you');
    expect(thanksResponse.status).toBe(200);
    
    // Check for thank you card content
    expect(thanksResponse.text).toContain('Thank you');
    expect(thanksResponse.text).toContain('definitely isn');
    expect(thanksResponse.text).toContain('t trying to steal your identity');
  });
  
  it('handles validation errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email'
      });
    
    // Form validation should fail and return error status
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
  });
});