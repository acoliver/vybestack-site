const express = require('express');
const path = require('path');
const app = express();

app.use(express.urlencoded({ extended: true }));

app.set('views', path.resolve('src/templates'));
app.set('view engine', 'ejs');

app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body;
  const errors = [];
  
  // Debug log
  console.log('Form data:', formData);
  
  // Validate required fields
  if (!formData.firstName?.trim()) errors.push('First name is required');
  if (!formData.lastName?.trim()) errors.push('Last name is required');
  if (!formData.streetAddress?.trim()) errors.push('Street address is required');
  if (!formData.city?.trim()) errors.push('City is required');
  if (!formData.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!formData.country?.trim()) errors.push('Country is required');
  if (!formData.email?.trim()) errors.push('Email is required');
  if (!formData.phone?.trim()) errors.push('Phone number is required');
  
  console.log('Errors:', errors);
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: formData
    });
  }
  
  res.redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'stranger';
  res.render('thank-you', { firstName });
});

const server = app.listen(0, () => {
  console.log('Test server running');
  
  // Test the form
  const testForm = {
    firstName: 'John',
    lastName: 'Doe',
    streetAddress: '123 Main St',
    city: 'London',
    stateProvince: 'England',
    postalCode: 'SW1A 1AA',
    country: 'United Kingdom',
    email: 'john.doe@example.com',
    phone: '+44 20 7946 0958'
  };
  
  const http = require('http');
  const postData = require('querystring').stringify(testForm);
  
  const options = {
    hostname: 'localhost',
    port: server.address().port,
    path: '/submit',
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
      'Content-Length': Buffer.byteLength(postData)
    }
  };
  
  const req = http.request(options, (res) => {
    console.log(`Status: ${res.statusCode}`);
    console.log(`Location: ${res.headers.location}`);
    
    console.log('Headers:', res.headers);
    
    res.on('data', (chunk) => {
      // console.log(`Body: ${chunk}`);
    });
    
    res.on('end', () => {
      server.close();
    });
  });
  
  req.on('error', (e) => {
    console.error(`Problem with request: ${e.message}`);
    server.close();
  });
  
  req.write(postData);
  req.end();
});