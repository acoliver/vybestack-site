/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Observer that tracks dependencies and executes the callback when they change
  const observer: Observer<T> = {
    name: `callback-${Date.now()}-${Math.random()}`,
    value,
    updateFn: (currentValue?: T) => {
      if (disposed) return currentValue!
      
      // Set this callback as active to track dependencies
      const oldObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        return updateFn(currentValue)
      } finally {
        setActiveObserver(oldObserver)
      }
    }
  }
  
  // Initial execution to establish dependencies
  updateObserver(observer)
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    // The observer will still be registered in dependencies, but won't execute
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}