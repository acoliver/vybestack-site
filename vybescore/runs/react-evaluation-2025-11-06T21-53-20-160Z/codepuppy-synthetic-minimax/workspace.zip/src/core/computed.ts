/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === false) return undefined
  if (equal === true || equal === undefined) {
    return (a: T, b: T) => a === b
  }
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  let currentValue = value
  
  // Store observers who depend on this computed value
  const observers = new Set<ObserverR>()
  
  // Observer that tracks dependencies and recomputes when they change
  const dependencyObserver: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (prevValue?: T) => {
      // Set this computed as active to track dependencies during recomputation
      const oldObserver = getActiveObserver()
      setActiveObserver(dependencyObserver)
      
      try {
        // Clear previous dependencies by accessing the function
        // Dependencies will be re-registered during this call
        const newValue = updateFn(prevValue)
        
        // Check if value actually changed
        const changed = !equalFn || !equalFn(newValue, currentValue as T)
        if (changed) {
          currentValue = newValue
          dependencyObserver.value = currentValue
          
          // Notify observers who depend on this computed value
          for (const observer of observers) {
            updateObserver(observer as Observer<unknown>)
          }
        }
        
        return currentValue!
      } finally {
        setActiveObserver(oldObserver)
      }
    }
  }
  
  // Initial computation to establish dependencies
  updateObserver(dependencyObserver)
  
  const getter: GetterFn<T> = (): T => {
    // If someone is accessing this computed value, they might be an observer
    const observer = getActiveObserver()
    if (observer) {
      // Register the observer as dependent on this computed value
      observers.add(observer)
    }
    
    // Ensure we have a value - recompute if undefined
    if (currentValue === undefined) {
      updateObserver(dependencyObserver)
    }
    
    return currentValue!
  }
  
  return getter
}