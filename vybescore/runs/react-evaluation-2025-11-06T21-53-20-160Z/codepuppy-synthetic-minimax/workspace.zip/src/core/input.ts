/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === false) return undefined
  if (equal === true || equal === undefined) {
    return (a: T, b: T) => a === b
  }
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: createEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    // If there's an active observer, register this input as a dependency
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }

    s.value = nextValue

    // Notify all observers - create a copy to avoid issues if observers are modified during iteration
    const currentObservers = Array.from(s.observers)
    
    for (const observer of currentObservers) {
      updateObserver(observer as Observer<unknown>)
    }

    return s.value
  }

  return [read, write]
}
