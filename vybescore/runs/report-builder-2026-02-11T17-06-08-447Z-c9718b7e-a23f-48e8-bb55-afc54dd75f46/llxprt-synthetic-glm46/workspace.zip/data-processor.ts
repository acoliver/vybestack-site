import { Readable, Transform } from 'node:stream';

/**
 * Streaming data processor that transforms and analyzes input data streams.
 * Supports multiple data formats and provides real-time analytics with async/await patterns.
 */
export class DataProcessor {
  private input: Readable | null = null;
  private transform: Transform | null = null;
  private dataBuffer: any[] = [];
  private processedCount: number = 0;
  private errorCount: number = 0;
  private transformationLog: string[] = [];
  private startTime: number = 0;
  private endTime: number = 0;

  /**
   * Sets up the data processor with an input stream
   * @param input - Input readable stream
   */
  constructor(input?: Readable) {
    this.startTime = Date.now();
    if (input) {
      this.setInput(input);
    }
  }

  /**
   * Sets or updates the input stream for processing
   * @param input - Input readable stream
   */
  setInput(input: Readable): this {
    this.input = input;
    this.transform = new Transform({
      objectMode: true,
      transform: (chunk: Buffer | string, encoding, callback) => {
        this.processChunk(chunk.toString());
        callback();
      }
    });
    return this;
  }

  /**
   * Starts the data processing pipeline
   * @returns Promise that resolves when processing completes
   */
  async process(): Promise<void> {
    if (!this.input || !this.transform) {
      throw new Error('Input stream not configured. Use setInput() method first.');
    }

    return new Promise((resolve, reject) => {
      this.input.pipe(this.transform);

      this.input.on('error', (err) => {
        this.errorCount++;
        this.transformationLog.push(`Stream error: ${err.message}`);
        reject(err);
      });

      this.transform.on('error', (err) => {
        this.errorCount++;
        this.transformationLog.push(`Transform error: ${err.message}`);
        reject(err);
      });

      this.transform.on('finish', () => {
        this.endTime = Date.now();
        resolve();
      });
    });
  }

  /**
   * Transforms input data chunk based on format type
   * @param chunk - Data chunk to process
   */
  private processChunk(chunk: string): void {
    try {
      // Try to detect and process different data formats
      let data: any;

      // Check if it's JSON
      try {
        data = JSON.parse(chunk);
        this.transformationLog.push('Processed JSON data');
      } catch {
        // Try CSV parsing (simple comma-separated values)
        if (chunk.includes(',')) {
          data = chunk.split(',').map(item => item.trim());
          this.transformationLog.push('Processed CSV data');
        } else {
          // Treat as plain text
          data = chunk;
          this.transformationLog.push('Processed text data');
        }
      }

      // Apply transformations and store in buffer
      const transformedData = this.applyTransformation(data);
      this.dataBuffer.push(transformedData);
      this.processedCount++;
    } catch (err) {
      this.errorCount++;
      this.transformationLog.push(`Error processing chunk: ${(err as Error).message}`);
    }
  }

  /**
   * Applies transformations to data based on type
   * @param data - Data to transform
   */
  private applyTransformation(data: any): any {
    if (typeof data === 'string') {
      return { text: data, length: data.length, type: 'text' };
    } else if (Array.isArray(data)) {
      return { array: data, count: data.length, type: 'array' };
    } else if (typeof data === 'object' && data !== null) {
      return { object: data, keys: Object.keys(data), type: 'object' };
    }
    return { raw: data, type: 'unknown' };
  }

  /**
   * Returns comprehensive statistics about the data processing
   */
  getAnalytics(): {
    processedCount: number;
    errorCount: number;
    processingTime: number;
    bufferSize: number;
    successRate: number;
    averageProcessingTime: number;
  } {
    const processingTime = this.endTime ? this.endTime - this.startTime : 0;
    const successRate = this.processedCount > 0 
      ? ((this.processedCount - this.errorCount) / this.processedCount) * 100 
      : 0;
    const averageProcessingTime = this.processedCount > 0 
      ? processingTime / this.processedCount 
      : 0;

    return {
      processedCount: this.processedCount,
      errorCount: this.errorCount,
      processingTime,
      bufferSize: this.dataBuffer.length,
      successRate,
      averageProcessingTime
    };
  }

  /**
   * Returns detailed processing logs
   */
  getTransformationLog(): string[] {
    return [...this.transformationLog];
  }

  /**
   * Returns the processed data buffer
   */
  getProcessedData(): any[] {
    return [...this.dataBuffer];
  }

  /**
   * Clears the processing buffer and resets counters
   */
  reset(): void {
    this.dataBuffer = [];
    this.processedCount = 0;
    this.errorCount = 0;
    this.transformationLog = [];
    this.startTime = Date.now();
    this.endTime = 0;
  }

  /**
   * Static method to create a DataProcessor instance with a stream
   * @param input - Input readable stream
   */
  static createWithStream(input: Readable): DataProcessor {
    return new DataProcessor(input);
  }

  /**
   * Async method to process data from a string
   * @param data - String data to process
   */
  static async processString(data: string): Promise<{
    analytics: ReturnType<DataProcessor['getAnalytics']>;
    processedData: any[];
    logs: string[];
  }> {
    const processor = new DataProcessor();
    const stream = Readable.from([data]);
    processor.setInput(stream);
    await processor.process();
    
    return {
      analytics: processor.getAnalytics(),
      processedData: processor.getProcessedData(),
      logs: processor.getTransformationLog()
    };
  }

  /**
   * Async method to process multiple data streams concurrently
   * @param streams - Array of readable streams
   */
  static async processStreams(streams: Readable[]): Promise<{
    totalProcessed: number;
    totalErrors: number;
    averageSuccessRate: number;
  }> {
    const processors = streams.map(stream => {
      const processor = new DataProcessor();
      processor.setInput(stream);
      return processor.process().then(() => processor);
    });

    const results = await Promise.all(processors);
    const totalProcessed = results.reduce((sum, p) => sum + p.processedCount, 0);
    const totalErrors = results.reduce((sum, p) => sum + p.errorCount, 0);
    const averageSuccessRate = results.reduce((sum, p) => {
      const analytics = p.getAnalytics();
      return sum + analytics.successRate;
    }, 0) / results.length;

    return {
      totalProcessed,
      totalErrors,
      averageSuccessRate
    };
  }
}