/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence terminators (.?!)
  const sentences = text.split(/([.?!])/);
  
  let result = "";
  let i = 0;
  
  while (i < sentences.length) {
    // Get the sentence text
    const sentence = sentences[i];
    // Get the terminator if it exists
    const terminator = i + 1 < sentences.length ? sentences[i + 1] : '';
    
    // Skip empty parts
    if (sentence.trim() === '') {
      i += 2;
      continue;
    }
    
    // Clean up spacing and capitalize
    const cleanedSentence = sentence.replace(/\s+/g, ' ').trim();
    const capitalizedSentence = cleanedSentence.charAt(0).toUpperCase() + cleanedSentence.slice(1).toLowerCase();
    
    // Add to result
    if (result) {
      result += ' ';
    }
    result += capitalizedSentence;
    
    // Add terminator
    if (terminator) {
      result += terminator;
    }
    
    i += 2;
  }
  
  return result;
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http, https, and protocol-less URLs
  const urlRegex = /((?:https?:)?\/\/[^\s<>"]+|www\.[^\s<>"]+)/gi;
  
  const matches = text.match(urlRegex) || [];
  
// Remove trailing punctuation from each URL, but keep the URL intact
  return matches.map(url => {
    // Remove trailing punctuation characters only from the end
    return url.replace(/[.,;:!?')]+$/g, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Find all http:// URLs but NOT https:// ones and replace them
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs for http://example.com/... in the following way:
 * - Always upgrade scheme to https://
 * - For paths starting with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for paths with dynamic hints (cgi-bin, query strings, etc.)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs with capture groups
  const exampleUrlRegex = /https?:\/\/example\.com(\/[^/\s?#]+)(.*)/gi;
  
  return text.replace(exampleUrlRegex, (match, path, rest) => {
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Check if we should rewrite the host
    // Skip if path contains cgi-bin or dynamic hints
    const shouldSkipHostRewrite = path.includes('cgi-bin') ||
                                 path.includes('?') ||
                                 path.includes('&') ||
                                 path.includes('=') ||
                                 /\.(jsp|php|asp|aspx|do|cgi|pl|py)([/]|$)/i.test(path + rest);
    
    if (!shouldSkipHostRewrite && path.startsWith('/docs')) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.example.com';
    } else {
      // Keep example.com
      newUrl += 'example.com';
    }
    
    // Add the path and any query/fragment
    newUrl += path + (rest || '');
    
    return newUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  if (monthNum === 2 && (yearNum % 4 === 0 && (yearNum % 100 !== 0 || yearNum % 400 === 0))) {
    if (dayNum < 1 || dayNum > 29) return 'N/A';
  } else {
    if (dayNum < 1 || dayNum > daysInMonth[monthNum]) return 'N/A';
  }
  
  return year;
}
