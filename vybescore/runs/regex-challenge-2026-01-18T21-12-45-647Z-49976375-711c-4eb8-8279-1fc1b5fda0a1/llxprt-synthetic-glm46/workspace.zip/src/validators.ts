export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC patterns.
 * Accepts typical addresses but rejects double dots, trailing dots, 
 * domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick regex check first
  if (!emailRegex.test(value)) return false;
  
  // Additional validation rules
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [local, domain] = parts;
  
  // Local part can't start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) return false;
  
  // Can't have consecutive dots anywhere
  if (local.includes('..') || domain.includes('..')) return false;
  
  // Domain can't have underscores
  if (domain.includes('_')) return false;
  
  // Domain can't start or end with hyphen or dot
  if (domain.startsWith('-') || domain.endsWith('-') || domain.startsWith('.') || domain.endsWith('.')) return false;
  
  return true;
}

/**
 * Validates US phone numbers with common formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, and optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be 10 or 11 digits (with optional country code)
  if (digits.length !== 10 && digits.length !== 11) return false;
  
  // If 11 digits, must start with '1' (US country code)
  if (digits.length === 11 && !digits.startsWith('1')) return false;
  
  // Extract the 10-digit phone number part
  const phoneNumber = digits.length === 11 ? digits.substring(1) : digits;
  
  // Area code (first 3 digits) can't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate the format by checking against patterns
  const patterns = [
    /^\(\d{3}\)\s*\d{3}[-]?\d{4}$/, // (212) 555-7890 or (212)5557890
    /^\d{3}[-]\d{3}[-]\d{4}$/,      // 212-555-7890
    /^\d{10}$/,                      // 2125557890
    /^\+1\s*\d{3}[-]?\d{3}[-]?\d{4}$/, // +1 212-555-7890 or +1-212-555-7890
    /^1\s*\d{3}[-]?\d{3}[-]?\d{4}$/   // 1 212-555-7890 or 1-212-555-7890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers for landlines and mobile.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
// Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex that captures:
  // Optional country code (+54 or 54)
  // Optional trunk prefix (0)
  // Optional mobile indicator (9)
  // Area code (2-4 digits, leading digit 1-9)
  // Subscriber number (6-8 digits)
  // Using character set syntax to avoid unnecessary escapes in the regex
  const argentinePhoneRegex = /^(\+?54)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check if it has the country code +54
  const hasCountryCode = value.includes('+54');
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, , trunkPrefix, areaCode] = match;
  
  // Check area code length and leading digit (2-4 digits, leading 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // If no country code, check for trunk prefix
  if (!hasCountryCode && !trunkPrefix && !value.startsWith('0')) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Basic name validation - allows letters (including unicode), spaces, apostrophes, and hyphens
  // Requiring at least one letter and rejecting consecutive special characters
  // Simplify character range to avoid "range out of order" error
  const nameRegex = /^[a-zA-Z\s'-]+$/;
  
  if (!nameRegex.test(value)) return false;
  
  // Can't start or end with space, apostrophe or hyphen
  if (/^[\s'-]|[\s'-]$/.test(value)) return false;
  
  // Can't have consecutive spaces, apostrophes, or hyphens
if (/([ ']){2,}|( {2,})|('-){2,}/.test(value)) return false;
  
  // Must contain at least one letter (not just symbols)
  if (!/[a-zA-Z]/.test(value)) return false;
  
  // Can't contain digits or other symbols
  if (/[0-9]|[@#$%^&*()+=[\]{}|:;"'<>,.?/|]/.test(value)) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm helper function.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value[i], 10);
    
    if (isEven) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for major brands (Visa/Mastercard/AmEx).
 * Checks both the format (length/prefix) and runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be between 13 and 19 digits (typical for major cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]|3[0-9]|[4-9]\d|1\d{2}|0\d{2})\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidVisa = visaRegex.test(digits);
  const isValidMastercard = mastercardRegex.test(digits);
  const isValidAmex = amexRegex.test(digits);
  
  // Must match at least one card type
  if (!isValidVisa && !isValidMastercard && !isValidAmex) return false;
  
  // Pass Luhn checksum
  return runLuhnCheck(digits);
}
