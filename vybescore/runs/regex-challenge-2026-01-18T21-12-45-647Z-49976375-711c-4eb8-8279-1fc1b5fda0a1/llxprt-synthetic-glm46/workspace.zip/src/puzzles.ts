/**
 * Finds words beginning with the specified prefix, excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a set for faster lookup
  const exceptionSet = new Set(exceptions);
  
  // Create regex pattern to match words with the prefix
  const wordRegex = new RegExp(`\\b${prefix.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&')}\\w*\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and deduplicate
  return [...new Set(matches.filter(word => !exceptionSet.has(word.toLowerCase())))];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex pattern to find tokens after digits
  // Use word boundary to ensure proper matching
  const embeddedTokenRegex = new RegExp(`\\d${token.replace(/[.*+?^${}()|[\\]/g, '\\$&')}`, 'g');
  
  const matches = text.match(embeddedTokenRegex) || [];
  
  return matches;
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  // Minimum 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // No immediate repeated sequences like abab
  // Look for 2+ character sequences that repeat immediately
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) but not IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex pattern (to ensure we don't match these)
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // If it contains an IPv4 pattern, return false (we'll handle IPv4 separately)
  if (ipv4Regex.test(value)) {
    // If it contains IPv4 AND IPv6, we still want to return false
    // because the requirement is to exclude IPv4 addresses entirely
    return false;
  }
  
  // Check if text contains explicit IPv6 address
  // Full IPv6 notation: 8 groups of 4 hex digits
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed notation with :: 
  const compressedIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/;
  
  // Special cases for :: (all zeros) or ::1 (localhost)
  const specialIPv6 = /\b::(?:1?)\b/;
  
  // IPv6 with embedded IPv4 (rare case)
  const embeddedIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){1,5}:(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  return fullIPv6.test(value) || compressedIPv6.test(value) || 
         specialIPv6.test(value) || embeddedIPv6.test(value);
}
