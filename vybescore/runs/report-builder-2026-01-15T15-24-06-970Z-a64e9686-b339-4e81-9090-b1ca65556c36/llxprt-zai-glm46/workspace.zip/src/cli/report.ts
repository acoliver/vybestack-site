#!/usr/bin/env node

import { validateAndParseReportData } from '../validator.js';
import { RENDERERS, type Format } from '../formats/index.js';
import { writeFileSync } from 'node:fs';

function parseArgs(args: string[]): {
  inputFile: string;
  format: Format;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  if (args.length < 2) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  let format: Format = 'markdown';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[++i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}. Supported formats: markdown, text`);
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return { inputFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const { inputFile, format, outputPath, includeTotals } = parseArgs(args);

    const data = validateAndParseReportData(inputFile);
    const renderer = RENDERERS[format];
    const output = renderer(data, { includeTotals });

    if (outputPath) {
      writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
