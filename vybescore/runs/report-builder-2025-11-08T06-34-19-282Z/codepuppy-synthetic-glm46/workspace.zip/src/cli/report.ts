#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData, ReportOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CLIArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CLIArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: CLIArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };
  
  let i = 0;
  
  // First argument should be data file
  if (!args[i].startsWith('--')) {
    result.dataFile = args[i];
    i++;
  } else {
    console.error('Error: First argument must be the data file path');
    process.exit(1);
  }
  
  // Parse remaining arguments
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
    
    i++;
  }
  
  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }
  
  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i} missing or invalid "amount" field (expected number)`);
    }
  }
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries as Array<{ label: string; amount: number }>,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const parsed = JSON.parse(content);
    return validateReportData(parsed);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.includes('ENOENT')) {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Load and validate data
    const data = loadReportData(args.dataFile);
    
    // Select formatter
    let formatter;
    switch (args.format) {
      case 'markdown':
        formatter = markdownFormatter;
        break;
      case 'text':
        formatter = textFormatter;
        break;
      default:
        console.error(`Error: Unsupported format: ${args.format}`);
        process.exit(1);
    }
    
    // Render report
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    const output = formatter.render(data, options);
    
    // Write output
    if (args.outputPath) {
      writeFile(args.outputPath, output, 'utf-8')
        .then(() => {
          console.log(`Report written to ${args.outputPath}`);
        })
        .catch((error) => {
          console.error(`Error writing to file: ${error.message}`);
          process.exit(1);
        });
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();