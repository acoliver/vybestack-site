import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const MAX_LIMIT = 100;

    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (!/^\d+$/.test(pageParam) || pageNum <= 0) {
        return res.status(400).json({ error: 'Invalid page: must be a positive integer' });
      }
    }

    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (!/^\d+$/.test(limitParam) || limitNum <= 0 || limitNum > MAX_LIMIT) {
        return res.status(400).json({ 
          error: `Invalid limit: must be a positive integer (max ${MAX_LIMIT})` 
        });
      }
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
