import initSqlJs from 'sql.js';
import { fileURLToPath } from 'url';
import path from 'path';
import { existsSync, mkdirSync, readFileSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export default async function initDB() {
  try {
    // Ensure data directory exists
    const dataDir = path.join(__dirname, '../../data');
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }

    // Initialize SQL.js - check multiple possible locations
    const possibleWasmPaths = [
      // For dev mode (running from src)
      path.join(__dirname, '../../node_modules/sql.js/dist/sql-wasm.wasm'),
      // For production mode (running from dist)
      path.join(__dirname, 'sql-wasm.wasm'),
      // Current working directory
      path.resolve(process.cwd(), 'sql-wasm.wasm'),
      // Absolute path from project root
      path.resolve(__dirname, '../sql-wasm.wasm')
    ];

    const wasmPath = possibleWasmPaths.find(p => existsSync(p));
    
    if (!wasmPath) {
      throw new Error('Could not find sql-wasm.wasm file');
    }

    console.log('Using WASM path:', wasmPath);

    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        if (file.endsWith('.wasm')) {
          return wasmPath;
        }
        return file;
      }
    });

    const dbPath = path.join(__dirname, '../../data/submissions.sqlite');
    let db;

    // Check if database file exists
    if (existsSync(dbPath)) {
      // Load existing database
      const fileBuffer = readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Create table
      db.exec(`
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province_region TEXT NOT NULL,
          postal_zip_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone_number TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
      `);
    }

    return db;
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
}