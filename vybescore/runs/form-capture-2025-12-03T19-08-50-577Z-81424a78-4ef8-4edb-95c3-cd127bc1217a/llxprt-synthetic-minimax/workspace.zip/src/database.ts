import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
  createdAt?: string;
}

interface SqlJsDatabase {
  run(sql: string): void;
  prepare(sql: string): Statement;
  exec(sql: string): QueryResult[];
  close(): void;
  export(): Uint8Array;
}

interface Statement {
  free(): void;
  run(params: string[]): void;
}

interface QueryResult {
  columns: string[];
  values: (string | number | null)[][];
}

interface SqlJsStatic {
  Database: new (buffer?: Uint8Array) => SqlJsDatabase;
}

export class DatabaseHandler {
  private sqlJs: SqlJsStatic | null = null;
  private db: SqlJsDatabase | null = null;
  private dbPath: string;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    // For ES modules, locate the WASM file using the current directory
    const sqlJsModule = await initSqlJs({
      locateFile: (file: string) => {
        return path.join(__dirname, '../node_modules/sql.js/dist/', file);
      }
    });

    this.sqlJs = sqlJsModule as SqlJsStatic;

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province_region TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone_number TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `;
    
    this.db.run(schema);
    await this.save();
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phoneNumber
    ]);

    stmt.free();
    await this.save();

    // Get the last insert ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    if (result.length > 0 && result[0].values.length > 0) {
      return Number(result[0].values[0][0]);
    }
    
    throw new Error('Failed to get insert ID');
  }

  async getSubmissions(): Promise<Submission[]> {
    if (!this.db) throw new Error('Database not initialized');

    const result = this.db.exec("SELECT * FROM submissions ORDER BY created_at DESC");
    if (result.length === 0) return [];

    const submissions: Submission[] = [];
    const values = result[0].values;

    for (const row of values) {
      const submission: Submission = {
        id: Number(row[0]),
        firstName: String(row[1]),
        lastName: String(row[2]),
        streetAddress: String(row[3]),
        city: String(row[4]),
        stateProvinceRegion: String(row[5]),
        postalCode: String(row[6]),
        country: String(row[7]),
        email: String(row[8]),
        phoneNumber: String(row[9]),
        createdAt: String(row[10])
      };
      submissions.push(submission);
    }

    return submissions;
  }

  async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const dbBuffer = this.db.export();
    fs.writeFileSync(this.dbPath, dbBuffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}