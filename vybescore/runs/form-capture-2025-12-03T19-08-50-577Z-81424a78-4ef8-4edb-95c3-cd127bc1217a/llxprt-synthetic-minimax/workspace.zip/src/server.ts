import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initDB from './db.js';
import { validateFormData } from './validation.js';
import type { ValidationError, FormData } from './types.js';
import type Database from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Initialize database
let db: Database.Database;

async function initializeApp() {
  try {
    db = await initDB();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// GET / - Render the contact form
app.get('/', (req, res) => {
  res.render('form', {
    title: 'Contact Us',
    errors: [],
    formData: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalZipCode: req.body.postalZipCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phoneNumber: req.body.phoneNumber || ''
  };

  const errors: ValidationError[] = validateFormData(formData);

  if (errors.length > 0) {
    // Re-render form with errors and previously entered values
    res.status(400).render('form', {
      title: 'Contact Us',
      errors,
      formData
    });
    return;
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province_region,
        postal_zip_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvinceRegion,
      formData.postalZipCode,
      formData.country,
      formData.email,
      formData.phoneNumber
    ]);

    stmt.free();
    
    // Save database changes to disk
    const data = db.export();
    const buffer = Buffer.from(data);
    const fs = await import('fs/promises');
    await fs.writeFile('data/submissions.sqlite', buffer);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving form data:', error);
    res.status(500).render('form', {
      title: 'Contact Us',
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      formData
    });
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
async function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Graceful shutdown...`);
  
  if (db) {
    try {
      const data = db.export();
      const buffer = Buffer.from(data);
      const fs = await import('fs/promises');
      await fs.writeFile('data/submissions.sqlite', buffer);
      db.close();
    } catch (error) {
      console.error('Error during database cleanup:', error);
    }
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
initializeApp().then(() => {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
});