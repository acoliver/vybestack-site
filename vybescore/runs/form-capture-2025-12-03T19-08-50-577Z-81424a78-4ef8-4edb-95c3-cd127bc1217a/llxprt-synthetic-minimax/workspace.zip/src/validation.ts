import type { FormData, ValidationError } from './types.js';

export function validateFormData(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.stateProvinceRegion.trim()) {
    errors.push({ field: 'stateProvinceRegion', message: 'State/Province/Region is required' });
  }

  if (!formData.postalZipCode.trim()) {
    errors.push({ field: 'postalZipCode', message: 'Postal/Zip code is required' });
  }

  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }

  if (!formData.phoneNumber.trim()) {
    errors.push({ field: 'phoneNumber', message: 'Phone number is required' });
  }

  // Email validation
  if (formData.email && !isValidEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (formData.phoneNumber && !isValidPhone(formData.phoneNumber)) {
    errors.push({ field: 'phoneNumber', message: 'Please enter a valid phone number' });
  }

  // Postal/Zip code validation
  if (formData.postalZipCode && !isValidPostalCode(formData.postalZipCode)) {
    errors.push({ field: 'postalZipCode', message: 'Please enter a valid postal/zip code' });
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings (handle UK "SW1A 1AA", Argentine formats like "C1000" or "B1675")
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}