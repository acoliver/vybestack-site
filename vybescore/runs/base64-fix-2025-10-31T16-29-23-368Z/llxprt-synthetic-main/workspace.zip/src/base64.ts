/**
 * Encode plain text to Base64.
 * Uses RFC 4648 standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64 strings.
 */
export function decode(input: string): string {
  // Validate input: check for valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for invalid padding structure
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    if (paddingIndex !== input.length - input.substring(paddingIndex).length) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
    
    // Can only have 1 or 2 padding characters
    const padding = input.substring(paddingIndex);
    if (padding.length > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    
    // According to RFC 4648, any properly padded Base64 string must have a length 
    // that is a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
  } else {
    // Without padding, length can be any valid length except modulo 1
    if (input.length % 4 === 1) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
