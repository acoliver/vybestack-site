#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { ReportData } from '../interfaces.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): ParsedArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse flags
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[++i] || '';
    } else if (arg === '--output') {
      outputPath = args[++i] || undefined;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

function validateAndParseData(dataPath: string): ReportData {
  try {
    const content = readFileSync(resolve(dataPath), 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries is required and must be an array');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label is required and must be a string`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entries[${i}].amount is required and must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading or parsing ${dataPath}: ${error.message}`);
    } else {
      console.error(`Error reading or parsing ${dataPath}: Unknown error`);
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(resolve(outputPath), content, 'utf-8');
    } catch (error) {
      console.error(`Error writing to file ${outputPath}:`, error instanceof Error ? error.message : 'Unknown error');
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  const args = parseArgs();
  const data = validateAndParseData(args.dataFile);
  
  const renderOptions = {
    includeTotals: args.includeTotals,
    outputPath: args.outputPath,
    format: args.format as 'markdown' | 'text'
  };
  
  let renderedContent: string;
  
  if (args.format === 'markdown') {
    renderedContent = renderMarkdown(data, renderOptions);
  } else {
    renderedContent = renderText(data, renderOptions);
  }
  
  writeOutput(renderedContent, args.outputPath);
}

main();
