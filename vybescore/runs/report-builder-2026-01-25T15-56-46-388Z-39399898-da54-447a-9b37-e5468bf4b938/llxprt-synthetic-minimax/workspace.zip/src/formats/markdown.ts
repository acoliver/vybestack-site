import { ReportData, RenderOptions } from '../interfaces.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${data.title}`);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries section
  lines.push('## Entries');
  
  // Entries bullet list
  data.entries.forEach(entry => {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  });
  
  // Total if requested
  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(calculateTotal(data))}`);
  }
  
  return lines.join('\n');
}