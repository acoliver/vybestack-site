/**
 * Matches words starting with the prefix but excluding banned words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // Using word boundaries to ensure we match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookahead/lookbehind to find token after a digit but not at string start
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * Validates passwords according to specified policy
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for character requirements
  if (!/[A-Z]/.test(value)) return false;  // uppercase
  if (!/[a-z]/.test(value)) return false;  // lowercase
  if (!/\d/.test(value)) return false;     // digit
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;  // symbol
  
  // Check for immediate repeated sequences (e.g. 'abab')
  if (/(\w{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles standard and shorthand formats
  // This is a simplified version that covers most common cases
  const ipv6Regex = /(?:::[\dA-Fa-f]{1,4}|[\dA-Fa-f]{1,4}::|[\dA-Fa-f]{1,4}:(?::[\dA-Fa-f]{1,4}){1,6}|::)/;

  // Check if it matches IPv6 pattern (this is a broad check)
  if (!ipv6Regex.test(value)) return false;

  // Additional checks to distinguish from IPv4
  // IPv4 addresses typically don't contain '::'
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // If it looks like IPv4, reject it
  if (ipv4Regex.test(value)) return false;
  
  // More specific IPv6 validation
  // Covers standard IPv6 and shorthand (::) formats
  const detailedIPv6 = /^(?:::[\dA-Fa-f]{1,4}(?::[\dA-Fa-f]{1,4}){0,6}|[\dA-Fa-f]{1,4}::|[\dA-Fa-f]{1,4}:(?::[\dA-Fa-f]{1,4}){1,6}|::)$/;

  // If it contains '::', it's IPv6 shorthand 
  if (value.includes('::')) {
    const parts = value.split('::');
    // Should have at most 2 parts with '::'
    if (parts.length > 2) return false;
    
    // Validate each part to ensure it contains valid hex segments
    for (const part of parts) {
      if (part && !/^[\dA-Fa-f]{1,4}(:[\dA-Fa-f]{1,4})*$/.test(part)) return false;
    }
    
    return true;
  }

  // For standard IPv6 (without ::)
  // Should have exactly 8 segments of hex values separated by ':'
  const standardIPv6 = /^([\dA-Fa-f]{1,4}:){7}[\dA-Fa-f]{1,4}$/;
  return standardIPv6.test(value);
}