/**
 * Capitalizes the first character of each sentence, preserving spacing rules
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with single space, but preserve single newlines
  text = text.replace(/\s+/g, ' ');
  
  // Split on sentence ending punctuation followed by space or end of string
  // Using a regex that captures the punctuation and space
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  }).trim();
}

/**
 * Finds URLs in the text and returns an array of matched URL strings
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs (http/https)
  // Handles common URL structures but removes trailing punctuation
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s,;.!?]*/gi;
  const matches = text.match(urlRegex);
  
  // Clean up trailing punctuation from URLs
  if (matches) {
    return matches.map(url => url.replace(/[.,;!?]+$/, ''));
  }
  
  return [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs that start with http:// and may have docs paths
  // But skip those with dynamic hints like query strings, cgi-bin, etc.
  return text.replace(/http:\/\/([a-zA-Z0-9.-]+)(\/docs\/[^\s,;.?&=\[\]{}|\\^`<>]*)(?=[\s,;.!?]|$)/gi, 
    (match, host, path) => {
      // Check if the path contains dynamic hints
      const hasDynamicHints = /[?&=#]|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
      
      if (hasDynamicHints) {
        // Only upgrade http to https
        return `https://${host}${path}`;
      } else {
        // Rewrite host to docs.host for /docs/ paths
        return `https://docs.${host}${path}`;
      }
    });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  return year;
}