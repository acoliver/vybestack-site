export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  value = value.trim();
  
  // Check for basic email structure
  if (!value.includes('@')) return false;
  
  // Validate email with regex
  // Local part (before @): allow alphanumeric, dots, hyphens, underscores, plus signs
  // but not consecutive dots or leading/trailing dots
  // Domain part (after @): allow alphanumeric, dots, hyphens but not underscores or consecutive dots
  const emailRegex = /^[a-zA-Z0-9]+([._-]?[a-zA-Z0-9]+)*@[a-zA-Z0-9]+([.-]?[a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
  
  // Check for double dots or trailing dots in local part
  const [localPart] = value.split('@');
  if (localPart.includes('..') || localPart.endsWith('.')) return false;
  
  // Check for underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common separators and optional +1
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1 (if present) and remove it
  let digits = cleanValue;
  if (cleanValue.startsWith('+1')) {
    digits = cleanValue.substring(2);
  } else if (cleanValue.startsWith('+')) {
    // If it starts with + but not +1, it's not a valid US number
    return false;
  }
  
  // Check for area code (first 3 digits)
  if (digits.length < 10) return false;
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if it matches one of the expected formats
  const phoneRegex = /^(\+?1[-.\s]?)?\(?([2-9][0-8][0-9])\)?[-.\s]?([2-9][0-9]{2})[-.\s]?(\d{4})$/;
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers for landlines and mobiles
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the value - remove all non-digit characters except +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check the format patterns
  const withCountryCodeRegex = /^\+54(9)?(\d{2,4})(\d{6,8})$/;
  const withTrunkPrefixRegex = /^0(\d{2,4})(\d{6,8})$/;
  
  // Process based on presence of country code or trunk prefix
  if (cleanValue.startsWith('+54')) {
    const match = cleanValue.match(withCountryCodeRegex);
    if (!match) return false;
    
    const mobileIndicator = match[1];  // Optional '9'
    const areaCode = match[2];
    const subscriberNumber = match[3];
    
    // Area code must be 2-4 digits, first digit 1-9
    if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
    
    // Subscriber number must contain 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    return true;
  } else if (cleanValue.startsWith('0')) {
    const match = cleanValue.match(withTrunkPrefixRegex);
    if (!match) return false;
    
    const areaCode = match[1];
    const subscriberNumber = match[2];
    
    // Area code must be 2-4 digits, first digit 1-9
    if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
    
    // Subscriber number must contain 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    return true;
  }
  
  // No country code or trunk prefix - invalid
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 */
export function isValidName(value: string): boolean {
  // Empty or whitespace only names are invalid
  if (!value.trim()) return false;
  
  // Check if name contains digits or symbols (other than allowed ones)
  // Allow letters, spaces, hyphens, apostrophes, and unicode characters
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0100-\u024F\u1E00-\u1EFF\s\-']+$/;
  
  // Check if it matches X Æ A-12 style (contains digit with letters)
  const digitWithLettersRegex = /.*\d.*/;
  
  return nameRegex.test(value.trim()) && !digitWithLettersRegex.test(value.trim());
}

/**
 * Helper function to run Luhn algorithm check
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/[^\d]/g, '');
  let sum = 0;
  let isEven = false;
  
  // Loop through digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleanValue = value.replace(/[^\d]/g, '');
  
  // Check if it matches known credit card patterns
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 5, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  const mastercardRegex = /^5\d{15}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the format matches one of the card types
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanValue);
}