import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Express } from 'express';
import type { Database } from 'sql.js';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination metadata', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1); // default page
    expect(response.body.limit).toBe(5); // default limit
    expect(response.body.total).toBe(15); // total items in seed data
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('respects custom page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBeLessThanOrEqual(3);
  });

  it('returns correct items for page 2 with limit 5', async () => {
    const response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    // Should have items with IDs 6-10
    expect(response.body.items[0].id).toBe(6);
    expect(response.body.items[4].id).toBe(10);
  });

  it('calculates hasNext correctly', async () => {
    // Page 1 with limit 5 should have next
    const response1 = await request(app).get('/inventory?page=1&limit=5');
    expect(response1.body.hasNext).toBe(true);

    // Page 2 with limit 5 should have next (15 total items)
    const response2 = await request(app).get('/inventory?page=2&limit=5');
    expect(response2.body.hasNext).toBe(true);

    // Page 3 with limit 5 should not have next (last page with items 11-15)
    const response3 = await request(app).get('/inventory?page=3&limit=5');
    expect(response3.body.hasNext).toBe(false);

    // Page 4 with limit 5 should not have next (no items)
    const response4 = await request(app).get('/inventory?page=4&limit=5');
    expect(response4.body.hasNext).toBe(false);
  });

  it('returns empty items for page beyond available data', async () => {
    const response = await request(app).get('/inventory?page=10&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(10);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(0);
    expect(response.body.hasNext).toBe(false);
  });

  describe('validation', () => {
    it('rejects non-numeric page parameter', async () => {
      const response = await request(app).get('/inventory?page=abc');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('page must be a numeric value');
    });

    it('rejects non-numeric limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=xyz');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('limit must be a numeric value');
    });

    it('rejects negative page parameter', async () => {
      const response = await request(app).get('/inventory?page=-1');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('page must be greater than 0');
    });

    it('rejects negative limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=-5');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('limit must be greater than 0');
    });

    it('rejects zero page parameter', async () => {
      const response = await request(app).get('/inventory?page=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('page must be greater than 0');
    });

    it('rejects zero limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('limit must be greater than 0');
    });

    it('rejects excessive page parameter', async () => {
      const response = await request(app).get('/inventory?page=1001');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('page must be less than or equal to 1000');
    });

    it('rejects excessive limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=101');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('limit must be less than or equal to 100');
    });

    it('rejects empty string page parameter', async () => {
      const response = await request(app).get('/inventory?page=');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('page must be a numeric value');
    });

    it('rejects empty string limit parameter', async () => {
      const response = await request(app).get('/inventory?limit=');
      expect(response.status).toBe(400);
      expect(response.body.error).toContain('limit must be a numeric value');
    });
  });
});
