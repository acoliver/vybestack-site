export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive regex checks.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (/\.\.|^\.|\.$|@\.|\.@|^@|@$/.test(value)) return false;
  if (/_/.test(value.split('@')[1] || '')) return false; // underscore in domain
  
  // Main email regex pattern
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [local, domain] = parts;
  
  // Local part checks
  if (local.length === 0 || local.length > 64) return false;
  if (local.startsWith('.') || local.endsWith('.')) return false;
  
  // Domain checks
  if (domain.length === 0 || domain.length > 255) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..')) return false;
  
  return true;
}

/**
 * Validate US phone numbers supporting common separators and optional +1.
 * Accepts formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have 10 digits (US number) or 11 digits (with country code 1)
  const hasCountryCode = digitsOnly.length === 11 && digitsOnly.startsWith('1');
  const isStandard = digitsOnly.length === 10;
  
  if (!hasCountryCode && !isStandard) return false;
  
  // Extract the actual 10-digit number
  const tenDigitNumber = hasCountryCode ? digitsOnly.slice(1) : digitsOnly;
  
  // Check area code (first digit cannot be 0 or 1)
  const areaCode = tenDigitNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check exchange code (first digit cannot be 0 or 1)
  const exchangeCode = tenDigitNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Validate the format with regex
  // Accepts: +1 (212) 555-7890, (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^(?:(?:\+1\s?)?(?:\(\d{3}\)\s?|\d{3}[-\s]?)?\d{3}[-\s]?\d{4})$/;
  
  return phoneRegex.test(value.replace(/\s/g, ''));
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // More precise validation
  // Mobile: +54 9 XX XXXXXXXX or 0XX 9 XXXXXXXX or +54 9 XXX XXXXXXXX
  // Landline: +54 XX XXXXXXXX or 0XX XXXXXXXX or XXX XXXXXXXX
  const phoneRegex = /^(?:(?:\+54)|(?:0))?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(phoneRegex);
  if (!match) return false;
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits and start with 1-9
  if (!/^[1-9]\d{0,3}$/.test(areaCode)) return false;
  
  // Subscriber must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriber)) return false;
  
  // Total digits should be at least 8 and at most 12
  const totalDigits = areaCode.length + subscriber.length;
  if (totalDigits < 8 || totalDigits > 12) return false;
  
  // If country code is omitted, must have trunk prefix 0 before area code
  const hasCountryCode = normalized.startsWith('+54');
  if (!hasCountryCode && !value.startsWith('0')) {
    // Check if the original value started with 0
    if (!/^0/.test(normalized)) return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and strange names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name should not be empty
  if (!value || value.trim().length === 0) return false;
  
  // Check for invalid characters (digits or certain symbols)
  if (/\d|[@#$%^&*()_+=[\]{}|\\:;"<>/?`~]/.test(value)) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces, and some basic punctuation
  // Reject names that look like "X Æ A-12" (has digits mixed with special chars)
  const nameRegex = /^[\p{L}\p{M}'\-\s.]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must have at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  // Cannot be only special characters
  const lettersOnly = value.replace(/[\s'\-.]/g, '');
  if (lettersOnly.length === 0) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number).reverse();
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa, Mastercard, AmEx formats.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  // Check prefixes
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const validPrefix = visaRegex.test(digitsOnly) || 
                      mastercardRegex.test(digitsOnly) || 
                      amexRegex.test(digitsOnly);
  
  if (!validPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}
