/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences even if the input omitted it.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces and tabs into one
  let normalized = text.replace(/[ \t]+/g, ' ');
  
  // Ensure exactly one space after sentence terminators (?!)
  normalized = normalized.replace(/([.!?])\s*/g, '$1 ');
  
  // Remove leading space if any
  normalized = normalized.replace(/^\s+/, '');
  
  // Capitalize first letter of the string
  normalized = normalized.replace(/^[a-z]/, char => char.toUpperCase());
  
  // Capitalize letters after sentence terminators
  // Use a negative lookbehind to avoid capitalizing after abbreviations
  // Common abbreviations: Mr., Mrs., Ms., Dr., Prof., etc., Ave., St., Blvd., etc.
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St', 'Ave', 'Blvd', 'Rd', 'Ln', 'etc', 'vs', 'eg', 'ie'];
  const abbrPattern = new RegExp(`\\b(${abbreviations.join('|')})\\.`, 'i');
  
  // Split into sentences and capitalize appropriately
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  const capitalized = sentences.map((sentence, index) => {
    if (index === 0 || sentence.trim().length === 0) {
      return sentence;
    }
    // Check if previous sentence ended with an abbreviation
    const prevSentence = sentences[index - 1] || '';
    const endsWithAbbr = abbrPattern.test(prevSentence);
    
    if (!endsWithAbbr && /^[a-z]/.test(sentence)) {
      return sentence.replace(/^[a-z]/, char => char.toUpperCase());
    }
    return sentence;
  });
  
  return capitalized.join(' ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  const urlRegex = /https?:\/\/(?:[-\w._~:/?#\]@!$&'()*+,;=%]|%[0-9a-fA-F]{2})+(?:[/?](?:[-\w._~:/?#\]@!$&'()*+,;=%]|%[0-9a-fA-F]{2})*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * - Always upgrade the scheme to https.
 * - When path begins with /docs/, rewrite host to docs.example.com.
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/example\.com)([/?][^\s]*)/gi;
  
  return text.replace(urlPattern, (match, schemeAndHost, path) => {
    // Always upgrade scheme
    const upgradedScheme = 'https://';
    
    // Check if we should skip host rewrite (dynamic hints)
    const dynamicHints = /\/cgi-bin|[?&=]|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)(?=[?#]|$)/i;
    
    if (dynamicHints.test(path)) {
      // Just upgrade the scheme, keep the same host
      return upgradedScheme + 'example.com' + path;
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return upgradedScheme + 'docs.example.com' + path;
    }
    
    // Just upgrade the scheme
    return upgradedScheme + 'example.com' + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // Check for specific month day limits
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day > daysInMonth[month]) return 'N/A';
  
  return year;
}
