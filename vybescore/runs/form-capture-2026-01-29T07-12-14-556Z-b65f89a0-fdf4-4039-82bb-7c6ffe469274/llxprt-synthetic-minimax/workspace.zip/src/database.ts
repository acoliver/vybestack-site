import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as path from 'path';
import * as fs from 'fs';

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js
      this.sqlJs = await initSqlJs({
        locateFile: (file: string) => {
          return require.resolve(`sql.js/dist/${file}`);
        }
      });

      // Load existing database or create new one
      let initialDbBuffer: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        initialDbBuffer = new Uint8Array(dbFile);
      }

      this.db = new this.sqlJs.Database(initialDbBuffer);
      
      // Create table if it doesn't exist
      if (fs.existsSync(this.schemaPath)) {
        const schemaSql = fs.readFileSync(this.schemaPath, 'utf8');
        this.db.run(schemaSql);
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  insertSubmission(data: SubmissionData): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    this.saveDatabase();
  }

  private saveDatabase(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const dbBuffer = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(dbBuffer));
  }

  close(): void {
    if (this.db) {
      this.saveDatabase();
      this.db.close();
      this.db = null;
    }
  }
}

export default DatabaseManager;