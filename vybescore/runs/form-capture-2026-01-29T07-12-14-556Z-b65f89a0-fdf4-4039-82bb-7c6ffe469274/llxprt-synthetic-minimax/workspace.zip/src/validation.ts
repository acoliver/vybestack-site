export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export class Validator {
  static validateForm(data: FormData): ValidationResult {
    const errors: Record<string, string> = {};

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      const value = data[field]?.trim();
      if (!value) {
        errors[field] = `${this.getFieldLabel(field)} is required`;
      }
    }

    // Email validation
    if (data.email && !this.isValidEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone validation
    if (data.phone && !this.isValidPhone(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation (alphanumeric support)
    if (data.postalCode && !this.isValidPostalCode(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private static getFieldLabel(field: keyof FormData): string {
    const labels: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State/Province/Region',
      postalCode: 'Postal/Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return labels[field] || field;
  }

  private static isValidEmail(email: string): boolean {
    // Simple email regex
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private static isValidPhone(phone: string): boolean {
    // Remove common formatting characters
    const cleaned = phone.replace(/[\s-()@]/g, '');
    // Should have at least 7 digits
    const digitCount = (cleaned.match(/\d/g) || []).length;
    return digitCount >= 7;
  }

  private static isValidPostalCode(postalCode: string): boolean {
    // Should have at least 3 characters, max 10
    // Support alphanumeric (UK SW1A 1AA, Argentine formats)
    const cleaned = postalCode.trim();
    if (cleaned.length < 3 || cleaned.length > 10) {
      return false;
    }
    // Must contain at least one letter or digit
    return /[a-zA-Z0-9]/.test(cleaned);
  }
}