import express, { Request, Response } from 'express';
import * as path from 'path';
import DatabaseManager from './database';
import { Validator, FormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

// Static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Database manager
const dbManager = new DatabaseManager();

// Route definitions
app.get('/', (_req: Request, res: Response) => {
  res.render('index', { 
    errors: {}, 
    formData: {},
    pageTitle: 'Contact Us - Friendly Form Capture'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const validation = Validator.validateForm(formData);

  if (!validation.isValid) {
    res.status(400).render('index', {
      errors: validation.errors,
      formData,
      pageTitle: 'Contact Us - Please Fix Errors'
    });
    return;
  }

  try {
    // Insert submission into database
    dbManager.insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    });

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('index', {
      errors: { general: 'An error occurred. Please try again.' },
      formData,
      pageTitle: 'Contact Us - Error'
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', { 
    pageTitle: 'Thank You - We Will Be In Touch'
  });
});

// Graceful shutdown
const gracefulShutdown = (): void => {
  console.log('Shutting down gracefully...');
  dbManager.close();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;
