/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with padding characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with optional padding.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate input contains only Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Check for valid padding configuration
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const padding = paddingMatch[0];
    // Padding should only be at the end and length should be 1 or 2
    if (padding.length > 2 || input.slice(0, -padding.length).includes('=')) {
      throw new Error('Invalid Base64 input: malformed padding');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
