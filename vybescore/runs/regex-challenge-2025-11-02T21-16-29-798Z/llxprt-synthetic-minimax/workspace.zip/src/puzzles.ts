/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Create a regex to match words starting with the prefix
  // Using word boundaries to match whole words only
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Create a regex pattern that uses lookaheads/lookbehinds
  // (?<!^)(?<=\d) - ensures token is after a digit and not at the start
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Create a regex pattern that uses lookaheads/lookbehinds
  // (?<!^)(?<=\d) - ensures token is after a digit and not at the start
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    matches.push(token);
  }
  
  return matches;
}');
  const regex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  const matches = [];
  let _match;
  while ((_match = regex.exec(text)) !== null) {
    matches.push(token);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (e.g., abab)
  // This pattern looks for any sequence of 2+ characters repeated immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // First check if it's a pure IPv4 address - if so, reject
  const ipv4Regex = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Regex.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns (including shorthand ::)
  // Full IPv6: 8 groups of hex digits
  const fullIPv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with :: in the middle (various positions)
  const ipv6WithCompression = /^(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$/;
  
  // IPv6-mapped IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6MappedIPv4 = /^(?:[0-9a-fA-F]{1,4}:){7}(?:[0-9a-fA-F]{1,4}|:):(?:(?:\d{1,3}\.){3}\d{1,3})$/;
  
  const trimmed = value.trim();
  
  // Check for IPv6 patterns
  if (fullIPv6.test(trimmed) || ipv6WithCompression.test(trimmed) || ipv6MappedIPv4.test(trimmed)) {
    // Additional check: ensure it's not just a pure IPv4
    if (!ipv4Regex.test(trimmed)) {
      return true;
    }
  }
  
  // Handle cases with :: shorthand more comprehensively
  if (trimmed.includes('::')) {
    // Count the number of colon groups
    const parts = trimmed.split('::');
    if (parts.length === 2) {
      // This is a valid :: compression
      // Check that the parts contain only valid IPv6 characters
      const validChars = /^[0-9a-fA-F:.]*$/;
      if (validChars.test(trimmed)) {
        // Ensure it's not just IPv4
        const hasColons = trimmed.includes(':');
        if (hasColons && !ipv4Regex.test(trimmed)) {
          return true;
        }
      }
    }
  }
  
  // Check for IPv6 pattern with colons and hex digits
  // But exclude if it's only IPv4
  if (/[0-9a-fA-F]*:[0-9a-fA-F]*/.test(trimmed)) {
    const hasColons = trimmed.includes(':');
    const isPureIPv4 = ipv4Regex.test(trimmed);
    
    if (hasColons && !isPureIPv4) {
      return true;
    }
  }
  
  return false;
}