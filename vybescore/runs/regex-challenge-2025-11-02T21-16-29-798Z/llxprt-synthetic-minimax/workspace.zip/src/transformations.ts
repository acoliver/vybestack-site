/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // First, normalize whitespace and collapse multiple spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Capitalize first character of the string
  result = result.replace(/^([a-z])/, (match) => match.toUpperCase());
  
  // Capitalize first character after sentence endings (.?!)
  result = result.replace(/([.?!]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // Match URLs including http://, https://, and www.
  // Stop at trailing punctuation
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s)]+(?=[)\s.,!?]|$)/gi;
  
  const urls = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  return urls.map(url => {
    // Remove trailing punctuation that might have been captured
    return url.replace(/[.,!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https:// but leave https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // Pattern to match http://example.com/ followed by a path
  const urlRegex = /http:\/\/example\.com(\/[^\s)]*)/gi;
  
  return text.replace(urlRegex, (match, path) => {
    // Check for dynamic hints that prevent host rewrite
    const hasDynamicHints = /(\?|&|=)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))|(cgi-bin)/i.test(match);
    
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com
      newUrl += 'docs.example.com';
    } else {
      // Keep original host
      newUrl += 'example.com';
    }
    
    newUrl += path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31) based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (for February)
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear) {
      daysInMonth[1] = 29;
    }
  }
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
