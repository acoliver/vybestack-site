export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with the following rules:
  // - Local part can contain letters, numbers, and some special characters
  // - No double dots (..)
  // - No trailing dots
  // - Domain part without underscores
  // - Valid TLD format
  
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for no domain with underscore
  if (value.includes('_@') || value.match(/@[^@]+\..*\./)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length: 10 digits for standard US number, 11 if starting with country code
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11) {
    if (digitsOnly[0] !== '1') {
      return false;
    }
    // Check area code (next 3 digits after country code)
    const areaCode = parseInt(digitsOnly.substring(1, 4));
    if (areaCode < 200 || areaCode > 999) {
      return false;
    }
    return true;
  }
  
  // For 10 digits, check area code (first 3 digits)
  const areaCode = parseInt(digitsOnly.substring(0, 3));
  if (areaCode < 200 || areaCode > 999) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for optional country code +54
  let remaining = cleaned;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.substring(3);
  }
  
  // Check for optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Check for trunk prefix 0 (required when no country code)
  if (!hasCountryCode) {
    if (!remaining.startsWith('0')) {
      return false;
    }
    remaining = remaining.substring(1);
  }
  
  // Extract area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = remaining.match(/^([1-9][0-9]{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  const areaCode = areaCodeMatch[1];
  remaining = remaining.substring(areaCode.length);
  
  // Remaining should be 6-8 digits (subscriber number)
  if (!/^[0-9]{6,8}$/.test(remaining)) {
    return false;
  }
  
  // Total digits should be reasonable
  const totalDigits = cleaned.replace(/\D/g, '').length;
  if (totalDigits < 10 || totalDigits > 14) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Must start with a letter (unicode)
  const firstCharRegex = /^[\p{L}]/u;
  if (!firstCharRegex.test(value)) {
    return false;
  }
  
  // Allow letters (unicode), spaces, apostrophes, and hyphens
  // Reject any digits or special symbols
  const nameRegex = /^[\p{L}](?:[\p{L}\s'\-]*[\p{L}])?$/u;
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */

// Helper function to run Luhn checksum
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length (13-19 digits)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check card type by prefix and length
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(digitsOnly)) {
    if (digitsOnly.length === 13 || digitsOnly.length === 16 || digitsOnly.length === 19) {
      return runLuhnCheck(digitsOnly);
    }
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if ((/^5[1-5]/.test(digitsOnly)) || (/^22[2-9]/.test(digitsOnly)) || (/^2[3-6][0-9]/.test(digitsOnly)) || (/^27[01][0-9]/.test(digitsOnly)) || (/^2720/.test(digitsOnly))) {
    if (digitsOnly.length === 16) {
      return runLuhnCheck(digitsOnly);
    }
  }
  
  // American Express: starts with 34 or 37, length 15
  if (/^3[47]/.test(digitsOnly)) {
    if (digitsOnly.length === 15) {
      return runLuhnCheck(digitsOnly);
    }
  }
  
  return false;
}
