/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing by collapsing multiple spaces
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to identify sentence endings: ., !, or ?
  // We need to be careful about abbreviations
  // Split on sentence boundaries but preserve the delimiters
  const sentences = normalized.split(/([.!?]+)\s*/);
  
  let result = '';
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    const delimiter = sentences[i + 1] || '';
    
    if (sentence.trim()) {
      // Capitalize first letter of sentence
      const capitalized = sentence.charAt(0).toUpperCase() + 
                           sentence.slice(1).toLowerCase();
      
      result += capitalized + delimiter;
      
      // Add exactly one space after sentence delimiters (except at end)
      if (i + 2 < sentences.length) {
        result += ' ';
      }
    }
  }
  
  // Trim any trailing space
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs
  // Matches http:// or https:// followed by domain and path
  const urlPattern = /(?:https?:\/\/)[^\s<>"']*[^\s<>"'.,!?;:")]?/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that was likely sentence punctuation
    return url.replace(/[.,!?;:]?$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave existing https:// untouched
  // Use word boundary to avoid matching http inside larger words
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const urlPattern = /http:\/\/[^\s<>"']+/gi;
  
  return text.replace(urlPattern, (url) => {
    try {
      // Parse the URL to extract components
      const urlObj = new URL(url);
      let finalUrl = url;
      
      // Always upgrade the scheme to https
      finalUrl = finalUrl.replace(/^http:\/\//, 'https://');
      
      // Check if path begins with /docs/
      if (urlObj.pathname.startsWith('/docs/')) {
        // Check for dynamic hints or legacy extensions
        const dynamicHints = ['cgi-bin', '?', '&', '='];
        const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
        
        const hasDynamicHints = dynamicHints.some(hint => 
          urlObj.pathname.includes(hint) || urlObj.search.includes(hint) || urlObj.hash.includes(hint)
        );
        
        const hasLegacyExtensions = legacyExtensions.some(ext => 
          urlObj.pathname.toLowerCase().includes(ext)
        );
        
        // Only rewrite host if no dynamic hints or legacy extensions
        if (!hasDynamicHints && !hasLegacyExtensions) {
          // Parse the upgraded URL to get the path
          const httpsUrlObj = new URL(finalUrl);
          finalUrl = `https://docs.example.com${httpsUrlObj.pathname}`;
          
          // Preserve query string and hash if present
          if (httpsUrlObj.search) {
            finalUrl += httpsUrlObj.search;
          }
          if (httpsUrlObj.hash) {
            finalUrl += httpsUrlObj.hash;
          }
        } else {
          // Just upgrade the scheme for URLs with dynamic hints
          finalUrl = finalUrl.replace(/^http:\/\//, 'https://');
        }
      } else {
        // Just upgrade the scheme for non-docs URLs
        finalUrl = finalUrl.replace(/^http:\/\//, 'https://');
      }
      
      return finalUrl;
    } catch {
      // If URL parsing fails, just upgrade the scheme
      return url.replace(/^http:\/\//, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic leap year validation for February
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    // Leap year check: divisible by 4, but not by 100 unless divisible by 400
    if ((yearNum % 4 !== 0) || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  // Return the year if everything is valid
  return year;
}
