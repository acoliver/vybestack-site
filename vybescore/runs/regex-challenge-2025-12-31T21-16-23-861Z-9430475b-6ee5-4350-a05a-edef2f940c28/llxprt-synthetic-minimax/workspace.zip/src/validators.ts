export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Pattern allows: letters, numbers, dots, underscores, plus signs before @
  // After @: domain with hyphens, dots, and TLD
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validation rules
  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in domain
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters to analyze the number structure
  const digitsOnly = value.replace(/\D/g, '');
  
  // Basic length validation - must be 10 digits (standard US)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Handle optional +1 country code
  let digits = digitsOnly;
  if (digits.length === 11 && digits.startsWith('1')) {
    digits = digits.slice(1); // Remove country code for validation
  }
  
  // Validate area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Now validate the original format with regex
  // Allow formats like: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890
  const phoneRegex = /^(?:\+?1[\s.-]?)?(?:\(?[2-9]\d{2}\)?[\s.-]?[2-9]\d{2}[\s.-]?\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators but keep digits and +
  const cleanValue = value.replace(/[\s.-]/g, '');
  
  // Pattern: handle various Argentine phone formats
  // Examples: +54 341 123 4567, +54 9 11 1234 5678, 011 1234 5678
  const pattern = /^(?:\+54)?(?:9)?0?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanValue.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;

  // Basic validation: area code 2-4 digits, subscriber 6-8 digits total
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Ensure area code doesn't start with 0
  if (areaCode.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, and hyphens
  // Reject digits, symbols, and complex fantasy names
  // Pattern: Start with letter (including unicode), allow spaces, apostrophes, hyphens
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation: reject names with symbols like Æ
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }
  
  // Ensure it's not just symbols or fantasy-style codes
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Reject obviously invalid patterns
  if (value.trim().length === 0) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const cleanCard = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  // Check for valid prefixes and lengths
  // Visa: starts with 4, length 13 or 16
  const visaPattern = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55, length 16
  const mastercardPattern = /^5[1-5]\d{14}$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if it matches any valid pattern
  if (!visaPattern.test(cleanCard) && 
      !mastercardPattern.test(cleanCard) && 
      !amexPattern.test(cleanCard)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanCard);
}

// Helper function to run Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
