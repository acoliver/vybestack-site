/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary pattern
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(match => !exceptionsSet.has(match.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: find occurrences where token appears after a digit
  // We need digit followed by the token (immediately after, no space)
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // Look for any pattern that repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.slice(i, i + 2);
    const repeated = value.slice(i + 2, i + 4);
    if (pattern === repeated) {
      return false;
    }
  }
  
  // Check for longer repeated sequences
  for (let i = 0; i < value.length - 1; i++) {
    const char = value[i];
    const nextChar = value[i + 1];
    if (char === nextChar && char === value[i + 2]) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, explicitly exclude IPv4 addresses
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern - allow matches anywhere in the string (not anchored)
  // Multiple patterns to handle different IPv6 formats
  const patterns = [
    // Full format: 2001:0db8:0000:0000:0000:ff00:0042:7879
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    
    // Compressed formats - allow anywhere in string
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/,
    /:(?::[0-9a-fA-F]{1,4}){1,7}/,
    /(?:[0-9a-fA-F]{1,4}:){0,7}:/,
    
    // General pattern allowing various compression
    /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}/,
    /(?:[0-9a-fA-F]{1,4}:){0,7}:(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/
  ];
  
  // Check if any pattern matches
  return patterns.some(pattern => pattern.test(value));
}
