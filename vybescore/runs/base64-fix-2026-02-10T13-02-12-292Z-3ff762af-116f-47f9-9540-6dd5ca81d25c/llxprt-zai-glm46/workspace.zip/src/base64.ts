const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Check if a string is valid Base64.
 * Valid Base64 consists of characters from the alphabet A-Z, a-z, 0-9, +, /
 * with optional padding (=) at the end (0, 1, or 2 padding characters).
 */
function isValidBase64(input: string): boolean {
  // Empty input is not valid
  if (input.length === 0) {
    return false;
  }

  // Check if string matches the Base64 character set
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }

  // Validate padding rules:
  // - Padding can only appear at the end
  // - If present, padding must be either 1 or 2 '=' characters
  // - Total length (without padding) must be a multiple of 4 characters
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding found, validate it
    const padding = input.slice(paddingIndex);
    
    // Padding must be 1 or 2 '=' characters
    if (padding.length > 2) {
      return false;
    }
    
    // Padding must be all '=' characters
    if (!/^=+$/.test(padding)) {
      return false;
    }
    
    // No non-padding characters after padding
    if (paddingIndex + padding.length !== input.length) {
      return false;
    }
  }

  // Total length must be a multiple of 4 (after accounting for padding)
  return input.length % 4 === 0;
}

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the input before attempting to decode
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the decoded result is valid UTF-8
    const decoded = buffer.toString('utf8');
    
    // Verify the encoding is reversible (basic sanity check)
    // This catches some edge cases of malformed input
    const checkBuffer = Buffer.from(decoded, 'utf8');
    const isValidEncoding = checkBuffer.equals(buffer);
    
    return isValidEncoding ? decoded : (() => {
      throw new Error('Invalid Base64 input');
    })();
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
