export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  // Local part: allowed characters, no consecutive dots, no leading/trailing dots
  // Domain part: no underscores, proper structure, valid TLD
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) return false;
  
  // Reject double dots in local part
  if (value.includes('..')) return false;
  
  // Reject domain with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  // Reject trailing dot anywhere
  if (value.endsWith('.')) return false;
  
  // Reject leading dot in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.')) return false;
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (cleaned.length < 10) return false;
  
  // Handle +1 country code
  let number = cleaned;
  if (number.startsWith('1') && number.length > 10) {
    number = number.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (number.length !== 10) return false;
  
  // Extract area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate the format matches one of the accepted patterns
  const patterns = [
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/, // (212) 555-7890
    /^\+?1?\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/, // 212-555-7890, 2125557890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports various formats with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if country code is present
  const hasCountryCode = cleaned.startsWith('+54');
  
  // Extract main number without country code for pattern matching
  const mainNumber = hasCountryCode ? cleaned.substring(3) : cleaned;
  
  // Comprehensive regex for Argentine phone numbers (without country code)
  // Pattern breakdown:
  // ^0? - Optional trunk prefix (required when country code is omitted)
  // 9? - Optional mobile indicator
  // ([1-9]\d{1,3}) - Area code (2-4 digits, leading 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = mainNumber.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, hasTrunkPrefix, , areaCode, subscriberNumber] = match;
  
  // When country code is omitted, trunk prefix must be present
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  // Area code validation (2-4 digits, doesn't start with 0)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode.startsWith('0')) return false;
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names with unicode support.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and invalid name formats.
 */
export function isValidName(value: string): boolean {
  // Regex for valid names:
  // ^[\p{L}\p{M}]+ - Start with one or more unicode letters (including combining marks)
  // (?:['\s-][\p{L}\p{M}]+)* - Allow apostrophes, spaces, hyphens followed by letters
  // $ - End with letters only
  // \p{L} = any kind of letter, \p{M} = combining marks (for accents)
  const nameRegex = /^[\p{L}\p{M}]+(?:['\s-][\p{L}\p{M}]+)*$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names that are too short (less than 2 characters)
  if (value.trim().length < 2) return false;
  
  // Reject names with consecutive separators
  if (value.includes("  ") || value.includes("--") || value.includes("''")) return false;
  
  // Reject very unusual patterns like "X Æ A-12"
  if (/\d/.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for major card types.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Card patterns:
  // Visa: 4, length 13 or 16
  // Mastercard: 51-55 or 2221-2720, length 16
  // AmEx: 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{14}|[3-6]\d{15}|7([01]\d{14}|20\d{13})))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if number matches any card pattern
  const isValidPattern = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!isValidPattern) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
