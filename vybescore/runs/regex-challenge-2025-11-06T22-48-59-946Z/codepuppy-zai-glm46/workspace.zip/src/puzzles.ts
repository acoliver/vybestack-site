/**
 * Find words starting with the specified prefix, excluding given exceptions.
 * Returns array of matching words (case-sensitive).
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary pattern with prefix
  // \b ensures we match whole words
  // Escape the prefix for special regex characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[\\w-]*`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of token that appear after a digit and not at string start.
 * Uses lookbehind to ensure token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for special regex characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit + token, but not at start of string
  const pattern = new RegExp(`\\d${escapedToken}(?!^)`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validate password strength according to security policy.
 * Requirements: 10+ chars, upper/lower/digit/symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character classes
  if (!/[A-Z]/.test(value)) return false; // Uppercase
  if (!/[a-z]/.test(value)) return false; // Lowercase
  if (!/\d/.test(value)) return false; // Digit
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false; // Symbol
  
  // Check for immediate repeated sequences (like abab, abcabc)
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  // Check for repeated characters (like aaa, bbb)
  const charRepeatPattern = /(.)\1{2,}/;
  if (charRepeatPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand notation.
 * Must distinguish from IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (from RFC 4291)
  // 1. Full notation: 8 groups of 4 hex digits
  // 2. Shortened notation: groups can have 1-4 hex digits
  // 3. Shorthand with :: for consecutive zero groups
  // 4. IPv4-mapped IPv6: ::ffff:192.168.1.1
  
  const ipv6Patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // Shorthand with :: replacing one or more groups
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/,
    /:[0-9a-fA-F]{1,4}/,
    // Start with :: and have up to 7 groups
    /::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/,
    // End with :: and have up to 7 groups before it
    /(?:[0-9a-fA-F]{1,4}:){1,7}::/,
    // :: in the middle
    /(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}/,
    // IPv4-mapped IPv6
    /::ffff:(?:\d{1,3}\.){3}\d{1,3}/,
    // Single :: (need more context)
    /::[0-9a-fA-F]*/,  // Ensure :: is followed by hex if not at end
  ];
  
  // First, extract potential IPv6-like patterns
  // This excludes pure IPv4 patterns
  const potentialIPv6Pattern = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F:]+/g;
  const potentialMatches = value.match(potentialIPv6Pattern) || [];
  
  // Check each potential match against IPv6 patterns
  for (const match of potentialMatches) {
    // Reject if it looks more like an IPv4 address
    if (/^(?:\d{1,3}\.){3}\d{1,3}$/.test(match)) continue;
    
    // Check against IPv6 patterns
    for (const pattern of ipv6Patterns) {
      if (pattern.test(match)) {
        return true;
      }
    }
  }
  
  // Also check for standalone :: which is valid IPv6 shorthand
  if (/::/.test(value)) {
    // Make sure it's not part of something else that isn't IPv6
    const contextMatch = value.match(/.*(::).*/);
    if (contextMatch) {
      const before = value.substring(0, contextMatch.index! + contextMatch[1].length);
      const after = value.substring(contextMatch.index! + contextMatch[1].length);
      
      // Check if surrounding context suggests IPv6
      const beforeOk = before.length === 0 || /(?::|[0-9a-fA-F])$/.test(before);
      const afterOk = after.length === 0 || /^([0-9a-fA-F]|:)/.test(after);
      
      if (beforeOk && afterOk) return true;
    }
  }
  
  return false;
}
