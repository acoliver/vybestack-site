/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries after .!? with proper spacing.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces and trim
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after sentence-ending punctuation if missing
  result = result.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  // Capitalize first letter of each sentence
  // Pattern: start of string or after punctuation + optional spaces
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  // Remove any double spaces that might have been created
  result = result.replace(/\s+/g, ' ');
  
  return result.trim();
}

/**
 * Extract all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  // Matches http/https, www, domain names, IP addresses
  // Includes optional ports, paths, query strings, fragments
  const urlRegex = /\b(?:(?:https?|ftp):\/\/|www\.)[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each match
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?'"\]\)\}]+$/g, '');
  });
}

/**
 * Replace http:// schemes with https:// while preserving existing https URLs.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch existing https://
  // Use word boundary to avoid matching parts of other strings
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite example.com URLs with special rules.
 * - Always upgrade to HTTPS
 * - Move /docs/ paths to docs.example.com subdomain
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Captures: protocol, domain, path, query/fragment
  const urlRegex = /(http:\/\/)(example\.com)(\/[^\s?#]*)?([?#][^\s]*)?/gi;
  
  return text.replace(urlRegex, (match, protocol, domain, path = '', queryFragment = '') => {
    // Always upgrade to HTTPS
    const newProtocol = 'https://';
    
    // Check if we should skip the host rewrite
    const skipHostRewrite = [
      // Dynamic hints
      /cgi-bin/,
      // Query strings
      /[?&=]/,
      // Legacy extensions
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#]?|$)/i
    ].some(pattern => pattern.test(path + queryFragment));
    
    if (!skipHostRewrite && path.startsWith('/docs/')) {
      // Move to docs.example.com subdomain, keep the full path
      const newPath = path; // Keep /docs/ and any sub-paths
      return newProtocol + 'docs.' + domain + newPath + queryFragment;
    } else {
      // Just upgrade the protocol, keep original domain
      return newProtocol + domain + path + queryFragment;
    }
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' for invalid formats or invalid dates.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr);
  const day = parseInt(dayStr);
  
  // Validate day based on month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  if (month === 2) {
    const isLeapYear = (parseInt(year) % 4 === 0 && parseInt(year) % 100 !== 0) || parseInt(year) % 400 === 0;
    if (day > (isLeapYear ? 29 : 28)) return 'N/A';
  } else {
    if (day > daysInMonth[month - 1]) return 'N/A';
  }
  
  return year;
}
