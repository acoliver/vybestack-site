/**
 * Validate that a string is valid Base64.
 * Uses regex to check if it only contains valid Base64 characters and proper padding.
 * According to RFC 4648, padding is optional and length constraints are more flexible.
 */
function isValidBase64(input: string): boolean {
  // Empty string should be valid
  if (input === '') {
    return true;
  }
  
  // Base64 regex: contains only A-Z, a-z, 0-9, +, /, and optional padding = at the end
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // If there's padding, it must only be at the end and be = or ==
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.substring(paddingIndex);
    // Only =, == are valid padding and they must be at the end
    if (!/^={1,2}$/.test(paddingPart)) {
      return false;
    }
    
    // If there's padding, length must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
    
    // Check that padding length is correct for the overall length
    const paddingLength = paddingPart.length;
    const nonPaddedLength = input.length - paddingLength;
    
    // When there's padding, the non-padded part should have a valid length
    if (paddingLength === 1 && (nonPaddedLength % 4 !== 3)) {
      return false;
    }
    if (paddingLength === 2 && (nonPaddedLength % 4 !== 2)) {
      return false;
    }
  } else {
    // No padding: length can be anything that's valid Base64
    // Check if the length, when padded, would be valid
    const paddedLength = Math.ceil(input.length / 4) * 4;
    const paddingNeeded = paddedLength - input.length;
    
    // Padding needed should be 0, 1, or 2
    if (paddingNeeded > 2) {
      return false;
    }
    
    // For lengths that need padding, check the modulo 4 remainder
    const remainder = input.length % 4;
    if (remainder === 1) {
      // A single leftover base64 character is invalid
      return false;
    }
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using standard RFC 4648 encoding.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding.
 */
export function encode(input: string): string {
  // Use standard Base64 encoding which includes proper padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input format and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate the input first
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
