import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('encodes single character with proper padding', () => {
    const result = encode('a');
    expect(result).toBe('YQ==');
  });

  it('encodes two characters with proper padding', () => {
    const result = encode('ab');
    expect(result).toBe('YWI=');
  });

  it('encodes three characters without padding', () => {
    const result = encode('abc');
    expect(result).toBe('YWJj');
  });

  it('decodes Base64 without padding', () => {
    const result = decode('YWJj');
    expect(result).toBe('abc');
  });

  it('encodes Unicode characters correctly', () => {
    const result = encode('😊');
    expect(result).toBe('8J+Yig==');
  });

  it('decodes Unicode characters correctly', () => {
    const result = decode('8J+Yig==');
    expect(result).toBe('😊');
  });

  it('encodes empty string', () => {
    const result = encode('');
    expect(result).toBe('');
  });

  it('decodes empty string', () => {
    const result = decode('');
    expect(result).toBe('');
  });

  it('rejects invalid Base64 with special characters', () => {
    expect(() => decode('invalid!base64*')).toThrow('Invalid Base64 input');
  });

  it('rejects Base64 with invalid padding position', () => {
    expect(() => decode('YWJj=')).toThrow('Invalid Base64 input');
  });

  it('rejects Base64 with too much padding', () => {
    expect(() => decode('YQ===')).toThrow('Invalid Base64 input');
  });

  it('accepts unpadded Base64 of length 3 (but only if Node accepts it)', () => {
    // Test what Node.js actually does - this may change based on implementation
    const result = decode('YWJ');
    expect(result).toBe('ab');
  });

  it('encodes string with null bytes', () => {
    const data = 'a\x00b';
    const result = encode(data);
    expect(result).toBe('YQBi');
  });

  it('decodes string with null bytes', () => {
    const result = decode('YQBi');
    expect(result).toBe('a\x00b');
  });

  it('accepts valid unpadded Base64 strings', () => {
    const result = decode('YWJjZA');
    expect(result).toBe('abcd');
  });

  it('rejects single character Base64 strings', () => {
    expect(() => decode('Y')).toThrow('Invalid Base64 input');
  });

  it('accepts two character unpadded Base64 strings', () => {
    const result = decode('YW');
    expect(result).toBe('a');
  });
});