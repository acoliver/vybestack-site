/**
 * Finds words beginning with the given prefix, excluding words in the exceptions list.
 * Uses regex with word boundaries and positive lookahead for the prefix.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
// Build regex to match words starting with prefix (using word boundaries)
  const prefixPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  // Find all matches
  const matches = text.match(prefixPattern) || [];
  
  // Filter out null/undefined and convert to lowercase for comparison
  const filteredMatches = matches.filter(match => match);
  
  // Remove excluded words (case-insensitive comparison)
  const result = filteredMatches.filter(word => {
    return !exceptions.some(exclude => 
      exclude.toLowerCase() === word.toLowerCase()
    );
  });
  
  // Remove duplicates while preserving case sensitivity
  const uniqueMatches = [...new Set(result)];
  
  return uniqueMatches;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the string start.
 * Uses lookbehind to check for preceding digit and ensures the match isn't at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build regex to capture digit + token combination
  const tokenPattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  return matches;
}

/**
 * Validates passwords according to complex policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab")
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!"#$%&'()*+,\-./:;<=>?@[@[^_`{|}~]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab")
  // This is a simplified check - in real scenarios you might want something more sophisticated
  for (let i = 0; i < value.length - 3; i++) {
    const sequence1 = value.substring(i, i + 2);
    const sequence2 = value.substring(i + 2, i + 4);
    
    if (sequence1 === sequence2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses in text, excluding IPv4 addresses.
 * Supports shorthand notation like ::.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv4 address pattern (to ensure we don't match these as IPv6)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 address pattern
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: can have :: representing consecutive zero sections
  const ipv6Pattern = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::(([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?/;
  
  // Extract potential IPv6 addresses
  const potentialMatches = value.match(/[\da-fA-F:]+/g) || [];
  
  for (const match of potentialMatches) {
    // Skip if it looks like an IPv4 address
    if (ipv4Pattern.test(match)) {
      continue;
    }
    
    // Check if it's a valid IPv6 address
    if (ipv6Pattern.test(match)) {
      return true;
    }
  }
  
  return false;
}
