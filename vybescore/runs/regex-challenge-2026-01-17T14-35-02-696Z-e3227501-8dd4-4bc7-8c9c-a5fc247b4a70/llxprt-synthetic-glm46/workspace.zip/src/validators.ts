export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with strong regex checks.
 * Accepts typical addresses like name@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check domain part
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject trailing dots in local part or domain
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Ensure domain has at least one dot and proper TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2 || domainParts[domainParts.length - 1].length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with common formats and optional +1 prefix.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix allowed
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Clean the input by removing common separators and spaces
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Check minimum length (should be at least 10 digits)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Use options to check for extensions if provided
  if (options?.allowExtensions && cleaned.includes('x')) {
    // We'll allow extensions but keep the validation logic simple for now
    return false; // Don't handle extensions for this implementation
  }
  
  // Handle optional country code
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // After removing country code, should be exactly 10 digits
  if (phoneNumber.length !== 10 || !/^\d+$/.test(phoneNumber)) {
    return false;
  }
  
  // Extract area code, exchange code, and subscriber number
  const areaCode = phoneNumber.substring(0, 3);
  const exchangeCode = phoneNumber.substring(3, 6);
  
  // Area code cannot start with 0 or 1 (NPA code rules)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code cannot start with 0 or 1 (NXX code rules)
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize input by removing spaces and hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  let argPhoneNumber = normalized;
  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  
  // Check for optional country code
  if (argPhoneNumber.startsWith('+54')) {
    hasCountryCode = true;
    argPhoneNumber = argPhoneNumber.substring(3);
  }
  
  // Check for trunk prefix (when country code is omitted, number must start with 0)
  if (argPhoneNumber.startsWith('0')) {
    hasTrunkPrefix = true;
    argPhoneNumber = argPhoneNumber.substring(1);
  }
  
  // Check for mobile indicator 9 between country/trunk and area code
  if (argPhoneNumber.startsWith('9')) {
    argPhoneNumber = argPhoneNumber.substring(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCode = '';
  let subscriberNumber = '';
  
  // Try to extract area code of 2-4 digits
  for (let acLength = 4; acLength >= 2; acLength--) {
    if (argPhoneNumber.length > acLength) {
      const potentialAreaCode = argPhoneNumber.substring(0, acLength);
      const potentialSubscriber = argPhoneNumber.substring(acLength);
      
      // Area code must start with 1-9 and contain only digits
      if (/^[1-9]\d{0,3}$/.test(potentialAreaCode) && potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
        areaCode = potentialAreaCode;
        subscriberNumber = potentialSubscriber;
        break;
      }
    }
  }
  
  if (!areaCode || !subscriberNumber) {
    return false;
  }
  
  // When country code is omitted, the number must begin with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Validate area code (2-4 digits, leading digit must be 1-9)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Check for minimum length (at least 1 character) and no whitespace-only strings
  if (value.trim().length === 0) {
    return false;
  }
  
  // Basic pattern: unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Check for consecutive special characters
  if (/(['-])\1/.test(value)) {
    return false;
  }
  
  // Check for starting/ending with special characters
  if (/^[ '-]|[ '-]$/.test(value)) {
    return false;
  }
  
  // Check for "X Æ A-12" style names (contains digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers based on format and Luhn checksum.
 * Supports Visa (13-19 digits, starts with 4), Mastercard (16 digits, starts 51-55/2221-2720), Amex (15 digits, starts 34/37)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits)
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check format based on card type
  const isVisa = cleanValue.length >= 13 && cleanValue.length <= 19 && cleanValue.startsWith('4');
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const isMastercard = cleanValue.length === 16 && 
    ((cleanValue.startsWith('5') && parseInt(cleanValue.substring(1, 2)) >= 1 && parseInt(cleanValue.substring(1, 2)) <= 5) ||
     (cleanValue.startsWith('2') && parseInt(cleanValue.substring(1, 4)) >= 221 && parseInt(cleanValue.substring(1, 4)) <= 720));
  
  // American Express: 15 digits, starts with 34 or 37
  const isAmex = cleanValue.length === 15 && (cleanValue.startsWith('34') || cleanValue.startsWith('37'));
  
  // Must be one of the supported card types
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
