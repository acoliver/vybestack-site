/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Common abbreviations to preserve (basic set for better sentence detection)
  
  // Split text into sentences while handling abbreviations
  const sentences: string[] = [];
  let currentIndex = 0;
  
  while (currentIndex < text.length) {
    const nextSentenceBreak = findSentenceBreak(text, currentIndex);
    
    if (nextSentenceBreak === -1) {
      // No more sentence breaks, add the rest of the text
      const sentence = text.substring(currentIndex).trim();
      sentences.push(sentence);
      break;
    } else {
      const sentence = text.substring(currentIndex, nextSentenceBreak).trim();
      sentences.push(sentence);
      currentIndex = nextSentenceBreak;
    }
  }
  
  // Capitalize first letter of each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return sentence;
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  // Join sentences with single space and collapse multiple spaces
  return capitalizedSentences.join(' ').replace(/\s+/g, ' ').trim();
}

/**
 * Helper function to find the end of a sentence
 */
function findSentenceBreak(text: string, startIndex: number): number {
  for (let i = startIndex; i < text.length; i++) {
    const char = text.charAt(i);
    
    // Check if character is a sentence terminator
    if (char === '.' || char === '?' || char === '!') {
      // Look ahead to check if this is truly a sentence break
      return findTrueSentenceBreak(text, i);
    }
  }
  
  return -1;
}

/**
 * Helper function to determine if a punctuation mark is a true sentence break
 */
function findTrueSentenceBreak(text: string, punctuationIndex: number): number {
  // Check if this is an abbreviation
  const nextChar = punctuationIndex < text.length - 1 ? text.charAt(punctuationIndex + 1) : '';
  
  // If next char is a lowercase letter, likely an abbreviation
  if (nextChar && /[a-z]/.test(nextChar)) {
    const wordBefore = getWordBeforeChar(text, punctuationIndex);
    if (isAbbreviation(wordBefore)) {
      return -1;
    }
  }
  
  // Find the position after the punctuation
  let endPos = punctuationIndex + 1;
  
  // Skip any spaces
  while (endPos < text.length && /\s/.test(text.charAt(endPos))) {
    endPos++;
  }
  
  return endPos;
}

/**
 * Helper function to get the word before a specific character position
 */
function getWordBeforeChar(text: string, charIndex: number): string {
  if (charIndex === 0) return '';
  
  let start = charIndex - 1;
  
  // Skip spaces
  while (start >= 0 && /\s/.test(text.charAt(start))) {
    start--;
  }
  
  // Find start of word
  while (start >= 0 && /[a-zA-Z]/.test(text.charAt(start))) {
    start--;
  }
  
  return text.substring(start + 1, charIndex);
}

/**
 * Helper function to check if a word is a common abbreviation
 */
function isAbbreviation(word: string): boolean {
  const commonAbbreviations = /^(mr|mrs|ms|dr|prof|sr|jr|st|vs|etc|i\.e|e\.g)$/i;
  return commonAbbreviations.test(word);
}

/**
 * Finds all URLs in the given text and returns them in an array.
 * Removes trailing punctuation from detected URLs.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern that matches http, https, and protocol-less URLs
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"']+|[^\s<>"']*\.[a-z]{2,}(?:[^\s<>"']*)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Process matches to remove trailing punctuation and validate
  return matches
    .map(match => {
      // Remove trailing punctuation that's not part of the URL
      const cleanMatch = match.replace(/[.,;:!?)\]}]+$/g, '');
      
      // Basic validation: ensure the URL has at least a domain and a TLD
      if (!isValidUrl(cleanMatch)) {
        return null;
      }
      
      return cleanMatch;
    })
    .filter(match => match !== null) as string[];
}

/**
 * Helper function to validate if a URL is well-formed
 */
function isValidUrl(url: string): boolean {
  // Add protocol if missing
  let fullUrl = url;
  if (!fullUrl.match(/^https?:\/\//) && !fullUrl.startsWith('www.')) {
    return false;
  }
  
  // Convert to full URL for validation
  if (fullUrl.startsWith('www.')) {
    fullUrl = 'http://' + fullUrl;
  }
  
  try {
    // Standard URL validation
    const urlObj = new URL(fullUrl);
    
    // Ensure we have a hostname and it has at least one dot
    if (!urlObj.hostname || !urlObj.hostname.includes('.')) {
      return false;
    }
    
    // Ensure the TLD is at least 2 characters
    const domainParts = urlObj.hostname.split('.');
    if (domainParts[domainParts.length - 1].length < 2) {
      return false;
    }
    
    return true;
  } catch (e) {
    return false;
  }
}

/**
 * Converts all http URLs to https while leaving existing https URLs untouched.
 * Returns the modified text with all URLs using https protocol.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // First, identify all URLs in the text
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"']+|[^\s<>"']*\.[a-z]{2,}(?:[^\s<>"']*)/gi;
  
  return text.replace(urlRegex, (match) => {
    // Clean the URL by removing trailing punctuation
    const cleanUrl = match.replace(/[.,;:!?)\]}]+$/g, '');
    
    // Convert to full URL for parsing
    let fullUrl = cleanUrl;
    if (fullUrl.startsWith('www.')) {
      fullUrl = 'http://' + fullUrl;
    }
    
    // Only process if it's a valid URL
    if (!isValidUrl(cleanUrl)) {
      return match;
    }
    
    // If it's already https, leave it alone
    if (fullUrl.startsWith('https://')) {
      return match;
    }
    
    // Replace http with https
    fullUrl.replace('http://', 'https://');
    
    // Return with the original formatting (remove http prefix we added)
    return cleanUrl.replace(/^http:\/\//, 'https://');
  });
}

/**
 * Rewrites http://example.com/... URLs following specific rules:
 * - Always upgrades scheme to https
 * - When path starts with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints: cgi-bin, query strings, or legacy extensions
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match example.com URLs
  const exampleUrlRegex = /https?:\/\/example\.com(\/[^\s<>"']*)?/gi;
  
  return text.replace(exampleUrlRegex, (match, path) => {
    // Default path to root
    const urlPath = path || '/';
    
    // Always upgrade to https
    let newUrl = 'https://example.com' + urlPath;
    
    // List of patterns that should prevent host rewriting
    const skipPatterns = [
      /cgi-bin/i,
      /\?/,    // Query string
      /&/,     // Query parameter
      /=/,     // Query key-value
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    // Check if we should skip host rewrite
    const shouldSkipRewrite = skipPatterns.some(pattern => pattern.test(urlPath));
    
    if (!shouldSkipRewrite && urlPath.startsWith('/docs')) {
      // Rewrite host to docs.example.com while preserving the path
      newUrl = 'https://docs.example.com' + urlPath;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Check for mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const maxDays = getMaxDayOfMonth(month, parseInt(year, 10));
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to get the maximum number of days in a month
 */
function getMaxDayOfMonth(month: number, year: number): number {
  switch (month) {
    case 2:
      // Leap year check
      return (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? 29 : 28;
    case 4:
    case 6:
    case 9:
    case 11:
      return 30;
    default:
      return 31;
  }
}
