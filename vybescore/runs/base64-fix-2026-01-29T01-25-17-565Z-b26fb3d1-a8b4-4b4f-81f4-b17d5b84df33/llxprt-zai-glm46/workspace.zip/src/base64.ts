/**
 * Encode plain text to Base64 using the standard alphabet (A-Z, a-z, 0-9, +, /)
 * with padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove any whitespace for lenient parsing
  const normalized = input.trim();

  // Check for invalid characters - valid base64 chars: A-Z, a-z, 0-9, +, /, =
  // Also accept unpadded input (no =), but reject other special characters
  const validBase64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Pattern.test(normalized)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for incorrect padding placement (only allowed at end)
  const paddingIndex = normalized.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be at the end
    const afterPadding = normalized.substring(paddingIndex).replace(/=/g, '');
    if (afterPadding.length > 0) {
      throw new Error('Invalid Base64 input: padding characters in the middle');
    }
  }

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Validate that the decoded buffer is not empty (which would mean invalid input)
    if (buffer.length === 0 && normalized.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
