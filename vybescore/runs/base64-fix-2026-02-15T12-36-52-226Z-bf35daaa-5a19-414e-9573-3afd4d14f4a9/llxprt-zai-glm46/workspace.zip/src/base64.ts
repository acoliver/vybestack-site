/**
 * Regular expression to validate Base64 strings.
 * Matches the standard Base64 alphabet: A-Z, a-z, 0-9, +, /, with optional padding (=).
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Checks if a string is valid Base64.
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid
  if (!input) return false;
  
  // Must match the Base64 pattern
  if (!VALID_BASE64_REGEX.test(input)) return false;
  
  // If there's padding, it must be at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be contiguous and at the end
    const paddingMatch = input.match(/=+$/);
    if (!paddingMatch) return false;
    
    // Padding must be 1 or 2 characters
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) return false;
    
    // With padding, total length must be multiple of 4
    if (input.length % 4 !== 0) return false;
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes padding characters as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Trim whitespace
  const trimmed = input.trim();
  
  // Validate the input format
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Additional validation: if the result contains replacement characters,
    // it indicates the input was not valid Base64
    if (result.includes('\uFFFD')) {
      throw new Error('Invalid Base64 input');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
