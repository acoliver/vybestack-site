/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Returns output with padding as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate the input is valid Base64
  const trimmed = input.trim();
  
  // Check for valid Base64 characters (standard alphabet)
  // Allow optional padding at the end
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!validBase64Regex.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the standard Base64 alphabet');
  }
  
  // Check length is valid (must be multiple of 4, accounting for padding)
  if (trimmed.length % 4 !== 0 && !trimmed.endsWith('=')) {
    // Allow unpadded input - Buffer.from will handle it
  }
  
  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Additional validation: if the result contains invalid UTF-8 sequences,
    // Buffer will still succeed but we should detect corruption
    // Re-encode and check if we get the same input (modulo padding)
    const reEncoded = Buffer.from(result, 'utf8').toString('base64');
    
    // Normalize both for comparison (add padding if needed)
    const normalizeForComparison = (str: string): string => {
      const trimmed = str.trim();
      // Add padding if needed
      const padLength = trimmed.length % 4;
      if (padLength !== 0) {
        return trimmed + '='.repeat(4 - padLength);
      }
      return trimmed;
    };
    
    if (normalizeForComparison(trimmed) !== normalizeForComparison(reEncoded)) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
