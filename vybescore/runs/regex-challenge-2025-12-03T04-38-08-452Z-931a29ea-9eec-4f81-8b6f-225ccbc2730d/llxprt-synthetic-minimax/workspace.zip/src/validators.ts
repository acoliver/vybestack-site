export function isValidEmail(value: string): boolean {
  // Basic email validation regex pattern
  // Allow letters, numbers, dots, underscores, hyphens in local part
  // Allow letters, numbers, hyphens in domain
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with +1
  const hasPlusOne = digitsOnly.startsWith('1');
  
  if (hasPlusOne && digitsOnly.length !== 11) {
    return false;
  }
  
  if (!hasPlusOne && digitsOnly.length !== 10) {
    return false;
  }
  
  // Extract area code
  const areaCode = hasPlusOne ? digitsOnly.slice(1, 4) : digitsOnly.slice(0, 3);
  
  // Check if area code is valid (not starting with 0 or 1)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

export function isValidArgentinePhone(value: string): boolean {
  // Clean the input - remove all spaces, hyphens, and other separators
  const cleanValue = value.replace(/[\s\-()]/g, '');
  
  // Check for country code format: +54
  if (cleanValue.startsWith('+54')) {
    const remainder = cleanValue.slice(3); // Remove +54
    
    // Optional mobile indicator 9
    const hasMobileIndicator = remainder.startsWith('9');
    const mainPart = hasMobileIndicator ? remainder.slice(1) : remainder;
    
    // Area code (2-4 digits, starting with 1-9) + subscriber number
    const areaCodeMatch = mainPart.match(/^([1-9]\d{1,3})(\d{4,8})$/);
    if (areaCodeMatch) {
      // Total length check: 2-4 for area + 4-8 for subscriber + optional mobile indicator
      const expectedLength = 2 + 4; // minimum
      const actualLength = mainPart.length;
      return actualLength >= expectedLength && actualLength <= 12;
    }
  }
  
  // Check for local format starting with 0 (trunk prefix)
  if (cleanValue.startsWith('0')) {
    const remainder = cleanValue.slice(1); // Remove trunk prefix 0
    
    // Optional mobile indicator 9
    const hasMobileIndicator = remainder.startsWith('9');
    const mainPart = hasMobileIndicator ? remainder.slice(1) : remainder;
    
    // Area code (2-4 digits, starting with 1-9) + subscriber number
    const areaCodeMatch = mainPart.match(/^([1-9]\d{1,3})(\d{4,8})$/);
    if (areaCodeMatch) {
      // Total length check: 1 (trunk) + 2-4 for area + 4-8 for subscriber + optional mobile indicator
      const expectedLength = 1 + 2 + 4; // minimum
      const actualLength = cleanValue.length;
      return actualLength >= expectedLength && actualLength <= 13;
    }
  }
  
  return false;
}

export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  return nameRegex.test(value);
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check card type and length
  const isVisa = /^4\d{12}(\d{3})?$/.test(digitsOnly); // 13 or 16 digits
  const isMastercard = /^5[1-5]\d{14}$/.test(digitsOnly); // 16 digits
  const isAmex = /^3[47]\d{13}$/.test(digitsOnly); // 15 digits
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Luhn algorithm
  return runLuhnCheck(digitsOnly);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}