export function capitalizeSentences(text: string): string {
  // Capitalize first character after sentence endings (.?!)
  // Insert exactly one space between sentences
  // Collapse extra spaces while preserving abbreviations
  
  return text
    // First, normalize multiple spaces to single spaces
    .replace(/\s+/g, ' ')
    // Add space after sentence ending if not present
    .replace(/([.?!])([^\s])/g, '$1 $2')
    // Capitalize first character of each sentence
    .replace(/(^|[.?!]\s+)([a-z])/g, (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    });
}

export function extractUrls(text: string): string[] {
  // Extract all URLs without trailing punctuation
  const urlRegex = /https?:\/\/[^\s)>',;!?]+/gi;
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;!?]+$/, '');
  });
}

export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving secure URLs untouched
  return text.replace(/http:\/\//g, 'https://');
}

export function rewriteDocsUrls(text: string): string {
  // Rewrite URLs according to specific rules
  return text.replace(/https?:\/\/[^/]+(\/docs\/[^?]*(?:[?&].*)?)/g, (match, path) => {
    // Always upgrade to https
    const result = 'https://';
    
    // Extract original domain
    const domainMatch = match.match(/https?:\/\/([^/]+)/);
    if (!domainMatch) return match;
    
    const originalDomain = domainMatch[1];
    
    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHints = /\?.*=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i.test(match);
    
    if (hasDynamicHints) {
      // Only upgrade scheme, keep original domain
      return 'https://' + originalDomain + path;
    }
    
    // Rewrite host to docs.domain.com
    const domainParts = originalDomain.split('.');
    if (domainParts.length <= 2) {
      // Simple domain like example.com -> docs.example.com
      return result + 'docs.' + originalDomain + path;
    } else {
      // Complex domain like sub.example.com -> docs.example.com  
      const mainDomain = domainParts.slice(-2).join('.');
      return result + 'docs.' + mainDomain + path;
    }
  });
}

export function extractYear(value: string): string {
  // Return four-digit year for mm/dd/yyyy format
  const yearMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!yearMatch) {
    return 'N/A';
  }
  
  const year = parseInt(yearMatch[3]);
  const month = parseInt(yearMatch[1]);
  const day = parseInt(yearMatch[2]);
  
  // Basic validation
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return String(year);
}