export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with prefix but excluding listed exceptions
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exc => lowerMatch.includes(exc.toLowerCase()));
  });
}

export function findEmbeddedToken(text: string, token: string): string[] {
  // Return occurrences where token appears after a digit and not at start of string
  // Use lookaheads/lookbehinds
  const regex = new RegExp(`(\\d${token})`, 'gi');
  const matches = text.match(regex) || [];
  return matches;
}

export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // One uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // One lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // One digit
  if (!/[0-9]/.test(value)) return false;
  
  // One symbol
  if (!/[!@#$%^&*()_+\-={}[\];':"\\|,.<>/?]/.test(value)) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab)
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

export function containsIPv6(value: string): boolean {
  // First check if it contains IPv4 pattern - if so, return false
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 regex with support for shorthand notation and compressed zeros
  const ipv6Regex = /\b(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}\b|\b(?:[0-9A-Fa-f]{1,4}:){1,7}:\b|\b:(?::[0-9A-Fa-f]{1,4}){1,7}\b|(?:[0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4}\b|(?:[0-9A-Fa-f]{1,4}:){1,5}(?::[0-9A-Fa-f]{1,4}){1,2}\b|(?:[0-9A-Fa-f]{1,4}:){1,4}(?::[0-9A-Fa-f]{1,4}){1,3}\b|(?:[0-9A-Fa-f]{1,4}:){1,3}(?::[0-9A-Fa-f]{1,4}){1,4}\b|(?:[0-9A-Fa-f]{1,4}:){1,2}(?::[0-9A-Fa-f]{1,4}){1,5}\b|[0-9A-Fa-f]{1,4}:(?:(?::[0-9A-Fa-f]{1,4}){1,6})|:(?:(?::[0-9A-Fa-f]{1,4}){1,7}|:)\b/;
  
  return ipv6Regex.test(value);
}