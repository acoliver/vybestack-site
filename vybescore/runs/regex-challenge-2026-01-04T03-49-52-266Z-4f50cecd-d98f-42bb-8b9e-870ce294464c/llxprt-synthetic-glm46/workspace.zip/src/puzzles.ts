/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words with the given prefix
  const regex = new RegExp(`\\b${prefix}\\w+`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => !exceptions.some(exception => 
    word.toLowerCase() === exception.toLowerCase()
  ));
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex to find the token preceded by a digit and not at the start
  const regex = new RegExp(`(\\d${token})`, 'gi');
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validates passwords with requirements: at least 10 characters, one uppercase, one lowercase, 
 * one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (anything that's not alphanumeric or whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex checks for any sequence of 2+ characters repeated immediately
  if (/(\w{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Look for IPv6 pattern in the text
  const ipv6Regex = /[0-9a-fA-F]{1,4}:[0-9a-fA-F:]+[0-9a-fA-F]{1,4}/;
  return ipv6Regex.test(value);
}
