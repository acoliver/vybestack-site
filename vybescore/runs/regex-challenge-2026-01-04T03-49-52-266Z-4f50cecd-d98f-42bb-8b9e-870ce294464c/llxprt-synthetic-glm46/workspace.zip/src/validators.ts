export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with typical patterns while rejecting obviously invalid forms.
 * Accepts patterns like name+tag@example.co.uk, rejects double dots, trailing dots,
 * domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick basic validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional constraints from problem description
  const [local, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (local.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject domain with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject trailing dots
  if (local.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject leading dots
  if (local.startsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with optional +1 prefix.
 * Supports (212) 555-7890, 212-555-7890, 2125557890 formats.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  let cleaned = value.replace(/\D/g, '');
  
  // Handle optional +1 prefix
  if (cleaned.startsWith('1') && cleaned.length === 11) {
    cleaned = cleaned.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (cleaned.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = cleaned.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Supports formats like:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (landline without country code)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline with trunk prefix)
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces and hyphens)
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Full pattern: optional +54, optional 0 trunk, optional 9 mobile, area code (2-4 digits), subscriber (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = argentinePhoneRegex.exec(cleaned);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix] = match;

  // If country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }

  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and invalid name patterns.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'-]+(?:\s[\p{L}\p{M}'-]+)*$/u;
  return nameRegex.test(value) && !/\d/.test(value);
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  // Check Mastercard (16 digits, starts with 51-55, 2221-2720)
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  // Check AmEx (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card format
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
