/**
 * Capitalizes the first character of each sentence, inserts exactly one space between sentences,
 * and collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Split into sentences by punctuation marks
  const sentences = text.split(/([.!?]+)/);
  
  // Capitalize first letter of each sentence and rejoin with punctuation properly
  let result = '';
  for (let i = 0; i < sentences.length; i++) {
    if (i % 2 === 0) {
      // Regular text sentence
      const sentence = sentences[i].trim();
      if (sentence.length > 0) {
        result += sentence.charAt(0).toUpperCase() + sentence.slice(1);
      }
    } else {
      // Punctuation mark
      result += sentences[i] + ' ';
    }
  }
  
  // Clean up extra spaces
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Finds URLs in the text and returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Enhanced URL regex that captures various URL formats
  const urlRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return urls.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ when applicable.
 * Skips host rewrite for dynamic hints (cgi-bin, query strings, or legacy extensions) but still upgrades scheme.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com\/([^\s<>"]+)/g, (match, path) => {
    // Check if path contains dynamic hints that should prevent host rewrite
    const dynamicHints = /(cgi-bin|[?&=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/;
    
    if (path.startsWith('docs/') && !dynamicHints.test(path)) {
      // Rewrite host to docs.example.com and upgrade to https
      return `https://docs.example.com/${path}`;
    } else {
      // Just upgrade the scheme as requested
      return `https://example.com/${path}`;
    }
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Validate month (1-12)
  const monthNum = parseInt(month, 10);
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const dayNum = parseInt(day, 10);
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Simple leap year check for February
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  const maxDay = monthNum === 2 && isLeapYear ? 29 : daysInMonth[monthNum - 1];
  
  if (dayNum < 1 || dayNum > maxDay) {
    return 'N/A';
  }
  
  return year;
}
