import express from 'express';
import { readFile, writeFile } from 'node:fs/promises';
import { join } from 'node:path';
import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

type FormData = {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
};

type ValidationError = string;

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

let db: import('sql.js').Database;
const dbPath = join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = join(__dirname, '..', 'db', 'schema.sql');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(join(__dirname, '..', 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const regexResult = /^[+]?[0-9()\-\s]+$/.test(phone);
  return regexResult && phone.length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings including spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postalCode) && postalCode.length > 0;
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  }
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  }
  if (!data.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  if (!data.city?.trim()) {
    errors.push('City is required');
  }
  if (!data.stateProvince?.trim()) {
    errors.push('State/Province/Region is required');
  }
  if (!data.postalCode?.trim()) {
    errors.push('Postal/Zip code is required');
  }
  if (!data.country?.trim()) {
    errors.push('Country is required');
  }
  if (!data.email?.trim()) {
    errors.push('Email is required');
  }
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  }

  // Format validation
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number');
  }
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: () => 'node_modules/sql.js/dist/sql-wasm.wasm',
    });

    // Try to load existing database
    try {
      const dbBuffer = await readFile(dbPath);
      db = new SQL.Database(new Uint8Array(dbBuffer));
      console.log('Database loaded from file');
    } catch {
      // Create new database
      db = new SQL.Database();
      console.log('Created new database');
    }

    // Ensure schema exists
    const schema = await readFile(schemaPath, 'utf-8');
    db.exec(schema);
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to file
async function saveDatabase(): Promise<void> {
  try {
    const data = db.export();
    await writeFile(dbPath, Buffer.from(data));
    console.log('Database saved to file');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', async (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.render('form', { errors, values: formData });
    return;
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    stmt.free();

    // Save database
    await saveDatabase();

    // Redirect to thank you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    errors.push('Failed to save your submission. Please try again.');
    res.render('form', { errors, values: formData });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = async (signal: string): Promise<void> => {
    console.log(`Received ${signal}. Shutting down gracefully...`);
    
    server.close(async () => {
      console.log('Express server closed');
      
      if (db) {
        await saveDatabase();
        db.close();
        console.log('Database closed');
      }
      
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});