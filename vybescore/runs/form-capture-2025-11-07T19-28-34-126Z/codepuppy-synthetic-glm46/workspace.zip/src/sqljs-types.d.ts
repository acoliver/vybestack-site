declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(bindings?: unknown[]): void;
    get(bindings?: unknown[]): unknown;
    all(bindings?: unknown[]): unknown[];
    free(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  function initSqlJs(options?: { locateFile: (file: string) => string }): Promise<SqlJsStatic>;
  export default initSqlJs;
}