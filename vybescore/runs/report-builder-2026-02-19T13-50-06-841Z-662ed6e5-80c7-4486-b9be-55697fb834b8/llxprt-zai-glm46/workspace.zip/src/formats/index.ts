import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type Format = 'markdown' | 'text';

export type Renderer = (data: ReportData, options: RenderOptions) => string;

export const formatters: Record<Format, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getFormatter(format: string): Renderer {
  const formatter = formatters[format as Format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
