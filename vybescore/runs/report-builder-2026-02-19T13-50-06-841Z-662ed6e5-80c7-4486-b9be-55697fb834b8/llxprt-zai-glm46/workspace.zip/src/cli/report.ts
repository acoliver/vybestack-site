#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { getFormatter } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  const entries: ReportData['entries'] = [];
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }

    entries.push({ label: entryObj.label, amount: entryObj.amount });
  }

  return { title: obj.title, summary: obj.summary, entries };
}

function main() {
  const args = parseArgs(process.argv.slice(2));

  let fileContent: string;
  try {
    fileContent = fs.readFileSync(args.inputFile, 'utf-8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: ${args.inputFile}`);
    } else {
      console.error(`Error reading file: ${(error as Error).message}`);
    }
    process.exit(1);
  }

  let jsonData: unknown;
  try {
    jsonData = JSON.parse(fileContent);
  } catch (error) {
    console.error(`Error: Invalid JSON in file: ${(error as Error).message}`);
    process.exit(1);
  }

  let reportData: ReportData;
  try {
    reportData = validateReportData(jsonData);
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }

  const options: RenderOptions = { includeTotals: args.includeTotals };

  try {
    const formatter = getFormatter(args.format);
    const output = formatter(reportData, options);

    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing output file: ${(error as Error).message}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

main();
