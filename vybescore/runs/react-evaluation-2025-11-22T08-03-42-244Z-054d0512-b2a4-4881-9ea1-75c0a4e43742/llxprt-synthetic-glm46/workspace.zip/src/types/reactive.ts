/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  observer?: unknown
  updating?: boolean
  observers?: Set<Observer>
}

export type ComputedObserver<T> = Observer & {
  updateFn: UpdateFn<T>
  value?: T
  dependencies?: Set<unknown>
  dirty?: boolean
}

export interface Subject<T> extends Observer {
  value: T
  equalFn?: EqualFn<T>
}

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver || ((globalThis as { __activeObserver?: unknown }).__activeObserver as Observer)
}

export function setActiveObserver(observer: Observer | undefined): void {
  activeObserver = observer
  ;(globalThis as { __activeObserver?: unknown }).__activeObserver = observer
}

export function updateObserver<T>(observer: ComputedObserver<T>): void {
  if (observer.updating || updateDepth >= MAX_UPDATE_DEPTH) {
    return
  }
  
  const previous = activeObserver
  
  try {
    updateDepth++
    observer.updating = true
    setActiveObserver(observer)
    
    // Run the update function
    const oldValue = observer.value
    const newValue = observer.updateFn(oldValue)
    observer.value = newValue
    
    // Notify dependent observers
    if (observer.observers && observer.observers.size > 0) {
      const observersToNotify = Array.from(observer.observers)
      observersToNotify.forEach((dep: Observer) => {
        const computedObserver = dep as ComputedObserver<unknown>
        if (computedObserver && typeof computedObserver.updateFn === 'function' && !computedObserver.updating) {
          // Set the computed observer as the current active observer to maintain dependency chain
          setActiveObserver(computedObserver)
          updateObserver(computedObserver)
          setActiveObserver(observer)
        }
      })
    }
  } finally {
    setActiveObserver(previous)
    observer.updating = false
    updateDepth--
  }
}

let updateDepth = 0
const MAX_UPDATE_DEPTH = 50