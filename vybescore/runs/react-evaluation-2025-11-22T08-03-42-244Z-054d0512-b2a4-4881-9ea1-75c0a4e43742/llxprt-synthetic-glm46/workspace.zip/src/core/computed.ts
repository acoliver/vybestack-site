/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ComputedObserver,
  getActiveObserver,
  EqualFn,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    equalFn = undefined
  } else {
    equalFn = (a, b) => a === b
  }

  const o: ComputedObserver<T> = {
    name: options?.name,
    observer: undefined,
    value,
    observers: new Set(),
    updating: false,
    updateFn,
    dependencies: new Set()
  }
  
  const getter: GetterFn<T> = () => {
    const prevObserver = getActiveObserver()
    
    // Register this computed as a dependent of the active observer
    if (prevObserver && o.observers) {
      // Register dependency relationship
      prevObserver.observers = prevObserver.observers || new Set()
      prevObserver.observers.add(o)
      o.observers.add(prevObserver)
    }
    
    // Track dependencies by making the computed the active observer
    setActiveObserver(o)
    
    try {
      // Compute value
      const newValue = o.updateFn(o.value)
      
      // Check if value has actually changed
      if (!equalFn || o.value === undefined || !equalFn(o.value, newValue)) {
        o.value = newValue
      }
      
      return o.value!
    } finally {
      // Restore previous active observer
      setActiveObserver(prevObserver)
    }
  }
  
  // No initial computation - compute on first access
  
  return getter
}