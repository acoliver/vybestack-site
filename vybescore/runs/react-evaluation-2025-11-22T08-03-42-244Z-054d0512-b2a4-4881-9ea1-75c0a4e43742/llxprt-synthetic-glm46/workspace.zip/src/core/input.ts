/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ComputedObserver,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === false) {
    equalFn = undefined
  } else {
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && s.observers) {
      s.observers.add(activeObserver)
      activeObserver.observers = activeObserver.observers || new Set()
      activeObserver.observers.add(s)
    }
    return s.value
  }

  const set: SetterFn<T> = (newValue) => {
    // Check if the value has changed
    if (equalFn && equalFn(s.value, newValue)) {
      return s.value
    }

    // Update the subject's value
    s.value = newValue

    // Notify all dependent observers
    if (s.observers && s.observers.size > 0) {
      const observersToNotify = Array.from(s.observers)
      for (const obs of observersToNotify) {
        const observer = obs as ComputedObserver<T>
        if (observer) {
          updateObserver(observer)
        }
      }
    }

    return s.value
  }

  return [read, set]
}