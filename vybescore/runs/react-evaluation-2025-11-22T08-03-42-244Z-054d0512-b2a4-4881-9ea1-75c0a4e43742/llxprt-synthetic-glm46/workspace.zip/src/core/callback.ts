/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, ComputedObserver, UpdateFn, setActiveObserver, getActiveObserver } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create the observer
  const o: ComputedObserver<T> = {
    name: undefined,
    observers: new Set(),
    updating: false,
    updateFn: () => {
      // Execute the callback as a side effect
      if (value !== undefined) {
        updateFn(value)
      } else {
        updateFn()
      }
      return value as T // return something to satisfy type system
    },
    value,
    dependencies: new Set()
  }

  // Track dependencies by temporarily setting this as the active observer
  const previousActive = getActiveObserver()
  setActiveObserver(o)
  
  try {
    // Execute the callback initially to track dependencies
    if (value !== undefined) {
      updateFn(value)
    } else {
      updateFn()
    }
  } catch (e) {
    // Silently ignore errors in callback functions
  } finally {
    // Restore previous active observer
    setActiveObserver(previousActive)
  }

  return () => {
    // Detach from all dependencies
    if (o.observers) {
      const dependencies = Array.from(o.observers)
      dependencies.forEach(dep => {
        if (dep.observers) {
          dep.observers.delete(o)
        }
      })
      o.observers.clear()
    }
  }
}