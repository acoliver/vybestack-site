/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the standard Base64 alphabet.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate Base64 input - check for valid characters only
  const base64Regex = /^[A-Za-z0-9+/=]+$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Validate padding is only at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.slice(paddingIndex);
    const nonPaddingAfterPadding = paddingPart.replace(/=/g, '');
    if (nonPaddingAfterPadding.length > 0) {
      throw new Error('Invalid Base64 input: characters after padding');
    }
    
    // Validate padding count doesn't exceed 2
    const paddingCount = (paddingPart.match(/=/g) || []).length;
    if (paddingCount > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
