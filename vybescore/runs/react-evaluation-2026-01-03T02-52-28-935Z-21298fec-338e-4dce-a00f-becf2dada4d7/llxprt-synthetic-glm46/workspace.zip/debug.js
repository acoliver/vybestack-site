// Debug script to understand the reactive system
import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Starting reactive debug")

// First test - basic computed
try {
  const [input, setInput] = createInput(1)
  const timesTwo = createComputed(() => input() * 2)
  console.log("Initial computed value:", timesTwo())
  
  setInput(3)
  console.log("After setInput(3), computed value:", timesTwo())
} catch (e) {
  console.error("Error in basic test:", e)
}

// Second test - computed depending on computed
try {
  console.log("\n--- Testing computed depending on computed ---")
  const [input, setInput] = createInput(1)
  const timesTwo = createComputed(() => input() * 2)
  const timesThirty = createComputed(() => input() * 30)
  const sum = createComputed(() => timesTwo() + timesThirty())
  
  console.log("Initial sum:", sum())
  setInput(3)
  console.log("After setInput(3), sum:", sum())
} catch (e) {
  console.error("Error in nested test:", e)
}

// Third test - callbacks
try {
  console.log("\n--- Testing callbacks ---")
  const [input, setInput] = createInput(1)
  const output = createComputed(() => input() + 1)
  
  let value = 0
  const unsubscribe = createCallback(() => {
    console.log("Callback triggered, value before:", value)
    value = output()
    console.log("Callback triggered, value after:", value)
  })
  
  setInput(3)
  console.log("Final value after setInput(3):", value)
} catch (e) {
  console.error("Error in callback test:", e)
}