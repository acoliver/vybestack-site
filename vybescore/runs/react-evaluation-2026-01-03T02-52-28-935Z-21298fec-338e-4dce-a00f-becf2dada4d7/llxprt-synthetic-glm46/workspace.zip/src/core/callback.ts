/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, callbackRegistry, setActiveObserver, getActiveObserver, registerObserver, Subject, notifyObservers, notifyComputedObservers, computedDependencies, registerComputedDependency, EqualFn, isActiveCallback } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      // Set this observer as active to track dependencies
      const previousObserver = getActiveObserver()
      setActiveObserver(observer)
      try {
        const newValue = updateFn(prevValue)
        observer.value = newValue
        return newValue
      } finally {
        setActiveObserver(previousObserver)
      }
    },
  }
  
  let disposed = false
  
  // Track this callback
  callbackRegistry.add(observer)
  
  // Initialize dependencies
  const dependencies = new Set<Subject<unknown>>()
  computedDependencies.set(observer, dependencies)
  
  // Register observer to track dependencies by running it once
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previousObserver)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from callback registry
    callbackRegistry.delete(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    computedDependencies.delete(observer)
  }
}
