/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  registerObserver,
  computedDependencies,
  notifyComputedObservers,
  registerComputedDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create equality function from boolean or function
  const equalFn: EqualFn<T> | undefined = typeof equal === 'function' 
    ? equal 
    : equal === true 
      ? (a: T, b: T) => a === b 
      : undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      registerObserver(observer, s)
      
      // If current observer is a computed, track this subject as a dependency
      const isComputed = computedDependencies.has(observer as Observer<unknown>)
      if (isComputed) {
        registerComputedDependency(observer as Observer<unknown>, s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Skip update if equal and values are the same
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all direct observers
    notifyObservers(s)
    
    // Notify computed observers that depend on this subject
    notifyComputedObservers(s)
    
    return s.value
  }

  return [read, write]
}
