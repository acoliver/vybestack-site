/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  EqualFn,
  getActiveObserver,
  registerObserver,
  Subject,
  computedObservers,
  computedDependencies,
  registerComputedDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create equality function from boolean or function
  const equalFn: EqualFn<T> | undefined = typeof equal === 'function' 
    ? equal 
    : equal === true 
      ? (a: T, b: T) => a === b 
      : undefined

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Clear previous dependencies first
      const deps = computedDependencies.get(o)
      if (deps) {
        deps.clear()
      }
      
      // Set this observer as active to track dependencies
      const previousObserver = getActiveObserver()
      setActiveObserver(o)
      try {
        const newValue = updateFn(prevValue)
        // Skip update if equal and values are the same
        if (equalFn && o.value !== undefined && equalFn(o.value, newValue)) {
          return o.value
        }
        o.value = newValue
        return newValue
      } finally {
        setActiveObserver(previousObserver)
      }
    },
  }

  // Track dependencies
  const dependencies = new Set<Subject<unknown>>()
  computedDependencies.set(o, dependencies)

  // Add to global computed observers
  computedObservers.add(o)

  // Initialize computed value
  const previousObserver = getActiveObserver()
  setActiveObserver(o)
  try {
    o.updateFn(o.value)
  } finally {
    setActiveObserver(previousObserver)
  }

  const getter = (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Create a pseudo-subject to track this computed value
      const subject: Subject<T> = {
        name: o.name,
        observers: new Set(),
        value: o.value!,
      }
      
      // Register this computed as a dependency
      registerObserver(currentObserver, subject)
      
      // If this is a computed observer, track this computed as a dependency
      const isComputed = computedDependencies.has(currentObserver as Observer<unknown>)
      if (isComputed) {
        registerComputedDependency(currentObserver as Observer<unknown>, subject)
      }
    }
    return o.value!
  }

  // Note: Dependencies are already tracked in the updateFn itself through getActiveObserver()
  // No need for a separate establishDependencies function
  
  return getter
}
