/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const oldValue = observer.value
    const newValue = observer.updateFn(observer.value)
    
    // If this is a computed observer and value changed, notify dependent observers
    if (computedObservers.has(observer as Observer<unknown>) && oldValue !== newValue) {
      // Find all dependent observers
      const deps = computedDependencies.get(observer as Observer<unknown>)
      if (deps) {
        deps.forEach(subject => {
          notifyComputedObservers(subject)
        })
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  const observers = [...subject.observers]
  observers.forEach(observer => {
    updateObserver(observer as Observer<T>)
    
    // Also trigger any callbacks that depend on this subject
    if (isActiveCallback(observer as Observer<unknown>)) {
      try {
        updateObserver(observer as Observer<unknown>)
      } catch (e) {
        // Ignore errors in callbacks
      }
    }
  })
}

export function registerObserver(observer: ObserverR, subject: Subject<unknown>) {
  if (subject?.observers) {
    subject.observers.add(observer)
    
    // If the observer is a callback (active observer), track it as a dependency
    if (isActiveCallback(observer as Observer<unknown>)) {
      // Track this subject as a dependency for the callback
      const deps = computedDependencies.get(observer as Observer<unknown>)
      if (deps) {
        deps.add(subject)
        
        // Register this observer as dependent on the subject
        let dependent = dependentObservers.get(subject)
        if (!dependent) {
          dependent = new Set()
          dependentObservers.set(subject, dependent)
        }
        dependent.add(observer)
      }
    }
  }
}

// Track computed observers and their dependencies
export const computedObservers = new Set<Observer<unknown>>()
export const computedDependencies = new WeakMap<Observer<unknown>, Set<Subject<unknown>>>()
export const dependentObservers = new WeakMap<Subject<unknown>, Set<Observer<unknown>>>()
export const recomputingObservers = new Set<Observer<unknown>>()

// Trigger re-evaluation for any computed values that depend on a subject
export function notifyComputedObservers<T>(changedSubject: Subject<T>): void {
  // Find all computed observers that depend on this subject
  const dependent = dependentObservers.get(changedSubject)
  if (dependent) {
    dependent.forEach(observer => {
      // Avoid infinite recursion
      if (recomputingObservers.has(observer)) {
        return
      }
      
      // Mark as recomputing to prevent cycles
      recomputingObservers.add(observer)
      
      try {
        // Recompute by updating the observer (which will also re-establish dependencies)
        updateObserver(observer as Observer<unknown>)
        
        // After recomputing, notify all callback observers that depend on this subject
        const callbacks = [...callbackRegistry].filter(cb => {
          const deps = computedDependencies.get(cb)
          return deps && deps.has(changedSubject as Subject<unknown>)
        })
        
        callbacks.forEach(callback => {
          try {
            updateObserver(callback)
          } catch (e) {
            // Ignore errors in callbacks
          }
        })
      } finally {
        // Remove from recomputing set
        recomputingObservers.delete(observer)
      }
    })
  }
}

// Export registerComputedDependency to avoid circular imports
export function registerComputedDependency<T>(observer: Observer<T>, subject: Subject<unknown>) {
  const deps = computedDependencies.get(observer)
  if (deps) {
    deps.add(subject)
    
    // Register this observer as dependent on the subject
    let dependent = dependentObservers.get(subject)
    if (!dependent) {
      dependent = new Set()
      dependentObservers.set(subject, dependent)
    }
    dependent.add(observer)
  }
}

// Callback registry for subscription management
export const callbackRegistry = new Set<Observer<unknown>>()
export function isActiveCallback(observer: Observer<unknown>): boolean {
  return callbackRegistry.has(observer)
}
