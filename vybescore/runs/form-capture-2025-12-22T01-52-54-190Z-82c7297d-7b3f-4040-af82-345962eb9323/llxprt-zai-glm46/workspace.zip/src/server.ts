import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const initSqlJs = require('sql.js');

interface SqlJsModule {
  Database: new (data?: Uint8Array) => SQLiteDatabase;
}

interface Statement {
  run(...params: unknown[]): void;
  getAsObject(params?: unknown[]): Record<string, unknown>;
  free(): void;
}

interface SQLiteDatabase {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

let db: SQLiteDatabase | null = null;

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }

  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  }

  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Email must be a valid email address' });
  }

  // Phone validation
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^[+]?[\d\s\-()]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, digits, spaces, and dashes' });
  }

  return errors;
}

async function initializeDatabase(): Promise<void> {
  try {
    const dbPath = join(__dirname, '..', 'data', 'submissions.sqlite');
    
    let dbBuffer: Uint8Array;
    if (existsSync(dbPath)) {
      const fileContent = readFileSync(dbPath);
      dbBuffer = new Uint8Array(fileContent);
    } else {
      dbBuffer = new Uint8Array([]);
    }

    const SQL = await initSqlJs();
    db = new SQL.Database(dbBuffer);

    // Ensure schema exists
    const schemaPath = join(__dirname, '..', 'db', 'schema.sql');
    const schema = readFileSync(schemaPath, 'utf-8');
    db?.exec(schema);

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = db.export();
    writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
  
  process.exit(0);
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData = req.body as FormData;
  const errors = validateFormData(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
  }

  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['Failed to save your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  // Get the most recent submission for the first name
  if (!db) {
    return res.status(500).send('Database not available');
  }

  try {
    const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
    const result = stmt.getAsObject([]) as { first_name: string };
    stmt.free();
    
    const firstName = result?.first_name || 'Friend';
    res.render('thank-you', { firstName });
  } catch (error) {
    console.error('Failed to retrieve submission:', error);
    res.render('thank-you', { firstName: 'Friend' });
  }
});

// Error handling middleware
app.use((err: Error, req: express.Request, res: express.Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {}
  });
});

// Initialize and start server
async function startServer(): Promise<ReturnType<typeof app.listen>> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  return server;
}

// Handle graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start the server only if this file is being run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export app and startServer for testing
export { startServer };
export default app;
