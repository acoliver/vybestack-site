// Simple test for API endpoints
import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';

async function testAPI() {
  try {
    console.log('Creating database and app...');
    const db = await createDatabase();
    const app = await createApp(db);
    
    console.log('API tests completed successfully!');
  } catch (error) {
    console.error('API test failed:', error);
  }
}

testAPI();