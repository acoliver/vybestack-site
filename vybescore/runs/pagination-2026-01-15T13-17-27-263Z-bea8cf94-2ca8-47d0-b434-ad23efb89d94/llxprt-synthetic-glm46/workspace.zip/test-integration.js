// Integration test for API endpoints
import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';

// Helper function to make requests
async function makeRequest(url) {
  const db = await createDatabase();
  const app = await createApp(db);
  
  // Since we can't easily test the actual HTTP endpoint, 
  // let's simulate requests by directly calling the app
  return new Promise((resolve, reject) => {
    const req = { 
      query: {}
    };
    
    // Parse URL to get query parameters
    const urlObj = new URL(url);
    urlObj.searchParams.forEach((value, key) => {
      req.query[key] = value;
    });
    
    const res = {
      status: (code) => {
        return {
          json: (data) => {
            resolve({ status: code, data });
          }
        };
      },
      json: (data) => {
        resolve({ status: 200, data });
      }
    };
    
    try {
      app._router.handle(req, res);
    } catch (error) {
      reject(error);
    }
  });
}

async function testAPI() {
  try {
    console.log('Testing default pagination (page 1, limit 5)...');
    // Create app and manually invoke the route
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Import listInventory directly to test the logic
    const { listInventory } = await import('./src/server/inventoryRepository.ts');
    
    // Test 1: Default pagination
    console.log('\nTest 1: Default pagination');
    let result = listInventory(db, {});
    console.log('Default pagination response:');
    console.log(JSON.stringify(result, null, 2));
    console.log(`Items count: ${result.items.length}`);
    console.log(`First item ID: ${result.items[0]?.id}`);
    console.log(`HasNext: ${result.hasNext}`);
    
    // Test 2: Page 2
    console.log('\nTest 2: Page 2');
    result = listInventory(db, { page: 2, limit: 5 });
    console.log('Page 2 response:');
    console.log(JSON.stringify(result, null, 2));
    console.log(`Items count: ${result.items.length}`);
    console.log(`First item ID: ${result.items[0]?.id}`);
    console.log(`HasNext: ${result.hasNext}`);
    
    // Test 3: Last page
    console.log('\nTest 3: Last page');
    result = listInventory(db, { page: 3, limit: 5 });
    console.log('Page 3 response:');
    console.log(JSON.stringify(result, null, 2));
    console.log(`Items count: ${result.items.length}`);
    console.log(`First item ID: ${result.items[0]?.id}`);
    console.log(`HasNext: ${result.hasNext}`);
    
    // Test 4: Page beyond last
    console.log('\nTest 4: Page beyond last');
    result = listInventory(db, { page: 4, limit: 5 });
    console.log('Page 4 response:');
    console.log(JSON.stringify(result, null, 2));
    console.log(`Items count: ${result.items.length}`);
    console.log(`HasNext: ${result.hasNext}`);
    
    // Test 5: Different limit
    console.log('\nTest 5: Different limit');
    result = listInventory(db, { page: 1, limit: 3 });
    console.log('Page 1, limit 3 response:');
    console.log(JSON.stringify(result, null, 2));
    console.log(`Items count: ${result.items.length}`);
    console.log(`First item ID: ${result.items[0]?.id}`);
    console.log(`HasNext: ${result.hasNext}`);
    
    console.log('\nAPI tests completed successfully!');
  } catch (error) {
    console.error('API test failed:', error);
  }
}

testAPI();