/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate basic Base64 format
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 format');
  }
  
  // Check for minimum valid length (a single valid Base64 character needs at least 2 chars)
  if (input.length < 2) {
    throw new Error('Invalid Base64 input');
  }
  
  // Try decoding directly first (for properly padded inputs)
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (directError) {
    // If direct decoding fails, try with added padding
    try {
      // Calculate the length without padding
      const inputWithoutPadding = input.replace(/=+$/, '');
      
      // Make sure this could be valid when properly padded
      if (inputWithoutPadding.length % 4 === 1) {
        throw new Error('Invalid Base64 length');
      }
      
      const paddedInput = inputWithoutPadding + '='.repeat((4 - (inputWithoutPadding.length % 4)) % 4);
      return Buffer.from(paddedInput, 'base64').toString('utf8');
    } catch (paddedError) {
      throw new Error('Failed to decode Base64 input');
    }
  }
}
