/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  getActiveObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const computed: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: (value !== undefined) ? value : (updateFn() as T),
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  let isUpdating = false
  
  const getter: GetterFn<T> = () => {
    // Prevent infinite loops
    if (isUpdating) return computed.value
    isUpdating = true
    
    // Establish dependency relationship when this computed value is accessed
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      computed.observer = activeObserver
    }
    
    // Recompute when dependencies change
    updateObserver(observer)
    computed.value = observer.value
    
    isUpdating = false
    return computed.value
  }
  
  
  
  return getter
}