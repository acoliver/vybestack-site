/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  const read: GetterFn<T> = () => {
    // Establish dependency relationship
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !s.equalFn ? !Object.is(s.value, nextValue) : !s.equalFn(s.value, nextValue)
    
    if (hasChanged) {
      s.value = nextValue
      
      // Notify all dependent observers (including computed values and callbacks)
      const observersToUpdate: ObserverR[] = []
      
      // Add the direct observer
      if (s.observer) {
        observersToUpdate.push(s.observer)
      }
      
      // Add any cascaded observers
      if (s.observer && (s.observer as any).observers) {
        for (const observer of (s.observer as any).observers) {
          observersToUpdate.push(observer)
        }
      }
      
      // Update all observers
      for (const observer of observersToUpdate) {
        updateObserver(observer as Observer<T>)
      }
    }
    return s.value
  }

  return [read, write]
}
