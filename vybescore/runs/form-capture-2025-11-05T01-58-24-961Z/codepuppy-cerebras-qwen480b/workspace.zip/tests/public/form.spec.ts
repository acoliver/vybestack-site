import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase, closeDatabase } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Initialize database for testing
  await initializeDatabase();
});

afterAll(() => {
  closeDatabase();
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check all form fields are present
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check form action
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '90210',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData);
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Database file should exist
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
