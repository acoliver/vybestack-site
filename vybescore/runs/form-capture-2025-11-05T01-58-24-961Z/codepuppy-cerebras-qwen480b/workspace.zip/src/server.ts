import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

// Dynamic types for sql.js
declare interface SqlJsDatabase {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): SqlJsStatement;
  export(): Uint8Array;
  close(): void;
}

declare interface SqlJsStatement {
  run(...params: unknown[]): void;
  getAsObject(): Record<string, unknown>;
  free(): void;
}

declare interface SqlJsStatic {
  Database: new (data?: ArrayBuffer) => SqlJsDatabase;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

let db: SqlJsDatabase | null = null;
let server: ReturnType<typeof app.listen> | null = null;

// Ensure data directory exists
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    // Use dynamic import for sql.js (it's a default export)
    // @ts-expect-error - sql.js doesn't have proper TypeScript types
    const sqlModule = await import('sql.js');
    const initSqlJs: unknown = sqlModule.default;
    const SQL: SqlJsStatic = await (initSqlJs as (config: unknown) => Promise<SqlJsStatic>)({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH);
      db = new SQL.Database(data.buffer);
    } else {
      db = new SQL.Database();
      // Create tables using schema
      const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      if (db) {
        db.run(schema);
      }
    }
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    try {
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Close database
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Form validation interface
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Validate form data
function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }

  // Email validation (simple regex)
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone validation (international formats)
  if (data.phone && data.phone.trim() !== '') {
    const phoneRegex = /^[+]?[0-9\s-()]+$/;
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push({
        field: 'phone',
        message: 'Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +'
      });
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && data.postalCode.trim() !== '') {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode.trim())) {
      errors.push({
        field: 'postalCode',
        message: 'Postal code can only contain letters, digits, spaces, and dashes'
      });
    }
  }

  return errors;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    // Validation failed, re-render form with errors
    res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
    return;
  }

  // Validation passed, save to database
  try {
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      stmt.run([
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim()
      ]);
      stmt.free();

      // Save database to disk
      saveDatabase();

      // Redirect to thank you page
      res.redirect(302, '/thank-you');
    } else {
      throw new Error('Database not initialized');
    }
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission to extract first name
  let firstName = 'Friend';
  try {
    if (db) {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const result = stmt.getAsObject() as { first_name: string };
      if (result.first_name) {
        firstName = result.first_name;
      }
      stmt.free();
    }
  } catch (error) {
    console.error('Failed to get recent submission:', error);
    // Continue with default first name
  }

  res.render('thank-you', { firstName });
});

// Graceful shutdown function
async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`\nReceived ${signal}, starting graceful shutdown...`);
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  closeDatabase();
  console.log('Database closed');
  
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, initializeDatabase, closeDatabase, gracefulShutdown };

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}