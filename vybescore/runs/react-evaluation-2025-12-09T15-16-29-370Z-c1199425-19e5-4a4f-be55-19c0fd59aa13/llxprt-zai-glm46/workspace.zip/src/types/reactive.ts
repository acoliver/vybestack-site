/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
export const dependencyGraph = new Map<Observer<unknown>, Set<Observer<unknown>>>()
export const subjectObservers = new Map<Subject<unknown>, Set<Observer<unknown>>>()
export const updateQueue = new Set<Observer<unknown>>()
let isProcessingQueue = false

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function addDependency(from: Observer<unknown>, to: Observer<unknown>): void {
  if (!dependencyGraph.has(from)) {
    dependencyGraph.set(from, new Set())
  }
  dependencyGraph.get(from)!.add(to)
}

export function addSubjectObserver(subject: Subject<unknown>, observer: Observer<unknown>): void {
  if (!subjectObservers.has(subject)) {
    subjectObservers.set(subject, new Set())
  }
  subjectObservers.get(subject)!.add(observer)
}

export function removeObserver(observer: Observer<unknown>): void {
  dependencyGraph.delete(observer)
  for (const observers of subjectObservers.values()) {
    observers.delete(observer)
  }
}

export function notifyDependents(observer: Observer<unknown>): void {
  const dependents = dependencyGraph.get(observer)
  if (dependents) {
    // Clone to avoid issues with modification during iteration
    const dependentsCopy = new Set(dependents)
    for (const dependent of dependentsCopy) {
      updateQueue.add(dependent)
    }
    
    // Process queue synchronously
    processUpdateQueue()
  }
}

function processUpdateQueue(): void {
  if (isProcessingQueue || updateQueue.size === 0) {
    return
  }
  
  isProcessingQueue = true
  
  try {
    // Process all queued updates
    const queueCopy = new Set(updateQueue)
    updateQueue.clear()
    
    for (const observerItem of queueCopy) {
      updateObserver(observerItem)
    }
    
    // If new updates were queued during processing, process them
    if (updateQueue.size > 0) {
      processUpdateQueue()
    }
  } finally {
    isProcessingQueue = false
  }
}

export function notifySubjectObservers(subject: Subject<unknown>): void {
  const observers = subjectObservers.get(subject)
  if (observers) {
    // Clone to avoid issues with modification during iteration
    const observersCopy = new Set(observers)
    for (const observerItem of observersCopy) {
      // Clear dependencies and recompute
      dependencyGraph.delete(observerItem)
      updateObserver(observerItem)
      // Also notify any observers that depend on this observer
      notifyDependents(observerItem as Observer<unknown>)
    }
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent recursive updates
  if (activeObserver === observer) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  
  // Clear dependencies before recomputing to establish new ones
  dependencyGraph.delete(observer as Observer<unknown>)
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Notify any observers that depend on this observer
  notifyDependents(observer as Observer<unknown>)
}
