/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  addDependency,
  addSubjectObserver,
  EqualFn,
  Subject,
  notifySubjectObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equality flag to proper function if needed
  const equalFn: EqualFn<T> | undefined = typeof _equal === 'function' 
    ? _equal 
    : _equal === true 
      ? (a, b) => a === b 
      : undefined

  // Create a subject for this computed to allow other observers to subscribe to it
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      // Run the user's update function to compute new value
      const newValue = updateFn(prevValue)
      
      // Update both the observer and subject values
      o.value = newValue
      subject.value = newValue
      
      // After updating, notify any computed that depends on this computed's subject
      notifySubjectObservers(subject as Subject<unknown>)
      
      return newValue
    },
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  // Update the subject with the initial computed value
  subject.value = o.value!
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed's subject as a dependency
      addSubjectObserver(subject as Subject<unknown>, observer as Observer<unknown>)
      // Also register the observer dependency for computed chain tracking
      addDependency(observer as Observer<unknown>, o as Observer<unknown>)
    }
    return subject.value
  }
}