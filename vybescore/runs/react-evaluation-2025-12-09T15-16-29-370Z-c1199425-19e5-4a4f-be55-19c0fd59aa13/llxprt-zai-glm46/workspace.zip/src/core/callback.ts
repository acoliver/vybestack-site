/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, removeObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      // Call the user's callback function
      const result = updateFn(prevValue)
      return result
    },
  }
  
  // Register observer to track dependencies and run initial effect
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from dependency tracking
    removeObserver(observer as Observer<unknown>)
    
    // Clear the observer to stop further updates
    observer.updateFn = () => observer.value!
  }
}