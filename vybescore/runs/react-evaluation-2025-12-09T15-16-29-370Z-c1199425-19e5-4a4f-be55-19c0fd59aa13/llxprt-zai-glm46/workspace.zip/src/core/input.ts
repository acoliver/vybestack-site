/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  addSubjectObserver,
  notifySubjectObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean equality flag to proper function
  const equalFn: EqualFn<T> | undefined = typeof _equal === 'function' 
    ? _equal 
    : _equal === true 
      ? (a, b) => a === b 
      : undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register the active observer as dependent on this subject
      addSubjectObserver(s as Subject<unknown>, observer as Observer<unknown>)
    }
    return s.value
  }

const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all dependent observers when value changes
    notifySubjectObservers(s as Subject<unknown>)
    
    return nextValue
  }

  return [read, write]
}
