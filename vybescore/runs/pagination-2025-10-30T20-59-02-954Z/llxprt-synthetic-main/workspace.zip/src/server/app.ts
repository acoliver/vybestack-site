import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Default values
    const DEFAULT_PAGE = 1;
    const DEFAULT_LIMIT = 5;
    const MAX_LIMIT = 100; // Prevent excessive values

    let page = DEFAULT_PAGE;
    let limit = DEFAULT_LIMIT;

    // Parse and validate page parameter
    if (pageParam !== undefined) {
      if (isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'page must be a number' });
      }
      const parsedPage = Number(pageParam);
      if (parsedPage <= 0) {
        return res.status(400).json({ error: 'page must be greater than 0' });
      }
      if (parsedPage > 1000) { // Prevent unreasonably high pages
        return res.status(400).json({ error: 'page must not exceed 1000' });
      }
      page = Math.floor(parsedPage);
    }

    // Parse and validate limit parameter
    if (limitParam !== undefined) {
      if (isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'limit must be a number' });
      }
      const parsedLimit = Number(limitParam);
      if (parsedLimit <= 0) {
        return res.status(400).json({ error: 'limit must be greater than 0' });
      }
      if (parsedLimit > MAX_LIMIT) {
        return res.status(400).json({ error: `limit must not exceed ${MAX_LIMIT}` });
      }
      limit = Math.floor(parsedLimit);
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
