import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
const DB_PATH = path.join(__dirname, '..', '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private server: any = null;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    
    // View engine setup
    this.app.set('views', path.join(__dirname, 'templates'));
    this.app.set('view engine', 'ejs');
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file) => path.join(__dirname, '..', '..', 'node_modules', 'sql.js', 'dist', file)
      });

      let dbBuffer: Uint8Array | null = null;
      
      try {
        const dbFile = await fs.readFile(DB_PATH);
        dbBuffer = new Uint8Array(dbFile);
      } catch (error) {
        // Database file doesn't exist yet
      }

      this.db = new SQL.Database(dbBuffer);
      
      // Execute schema if needed
      const schemaSql = await fs.readFile(SCHEMA_PATH, 'utf-8');
      this.db.exec(schemaSql);
      
      console.error('Database initialized');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (this.db) {
      const data = this.db.export();
      await fs.writeFile(DB_PATH, Buffer.from(data));
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field].trim() === '') {
        errors.push({
          field,
          message: `${this.getFieldLabel(field)} is required`
        });
      }
    }

    // Email validation
    if (data.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation (international formats)
    if (data.phone) {
      const phoneRegex = /^[\+]?[\d\s\(\)\-]+$/;
      if (!phoneRegex.test(data.phone)) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number'
        });
      }
    }

    // Postal code validation (alphanumeric for international)
    if (data.postalCode) {
      const postalRegex = /^[A-Za-z0-9\s\-]+$/;
      if (!postalRegex.test(data.postalCode)) {
        errors.push({
          field: 'postalCode',
          message: 'Postal code should contain only letters, numbers, spaces, and hyphens'
        });
      }
    }

    return errors;
  }

  private getFieldLabel(field: keyof FormData): string {
    const labels: Record<keyof FormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return labels[field];
  }

  private setupRoutes(): void {
    // GET / - Render the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: (req.body.firstName || '').trim(),
        lastName: (req.body.lastName || '').trim(),
        streetAddress: (req.body.streetAddress || '').trim(),
        city: (req.body.city || '').trim(),
        stateProvince: (req.body.stateProvince || '').trim(),
        postalCode: (req.body.postalCode || '').trim(),
        country: (req.body.country || '').trim(),
        email: (req.body.email || '').trim(),
        phone: (req.body.phone || '').trim()
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        // Re-render form with errors
        const errorMessages = errors.map(error => error.message);
        res.status(400).render('form', {
          errors: errorMessages,
          values: formData
        });
        return;
      }

      // Insert into database
      if (this.db) {
        try {
          const stmt = this.db.prepare(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);

          stmt.run([
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvince,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);

          stmt.free();
          await this.saveDatabase();

          // Redirect to thank you page with first name
          res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
        } catch (error) {
          console.error('Database error:', error);
          res.status(500).render('form', {
            errors: ['An error occurred while saving your information. Please try again.'],
            values: formData
          });
        }
      } else {
        res.status(500).render('form', {
          errors: ['Database not available. Please try again later.'],
          values: formData
        });
      }
    });

    // GET /thank-you - Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = (req.query.firstName as string) || 'Friend';
      res.render('thank-you', {
        firstName
      });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    this.server = this.app.listen(PORT, () => {
      console.error(`Server running on port ${PORT}`);
    });
  }

  public async stop(): Promise<void> {
    if (this.server) {
      await new Promise<void>((resolve) => {
        this.server.close(() => {
          resolve();
        });
      });
    }

    if (this.db) {
      this.db.close();
    }

    console.error('Server stopped');
  }
}

async function main() {
  const server = new FormServer();
  
  // Handle SIGTERM gracefully
  process.on('SIGTERM', async () => {
    console.error('SIGTERM received, shutting down gracefully');
    await server.stop();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.error('SIGINT received, shutting down gracefully');
    await server.stop();
    process.exit(0);
  });

  await server.start();
}

main().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});