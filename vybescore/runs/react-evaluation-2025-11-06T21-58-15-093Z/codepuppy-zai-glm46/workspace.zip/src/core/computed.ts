/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // The equalFn parameter is available for future use but not currently implemented
  // for computed values (computed values always recompute when dependencies change)

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Computed values also need to track their observers (entities that depend on them)
  const observers = new Set<ObserverR>()

  // Wrap the original updateFn to add observer notification logic
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue) => {
    const oldValue = o.value
    const result = originalUpdateFn(prevValue)
    o.value = result
    // If the computed value changed, notify its own observers
    if (oldValue !== o.value) {
      observers.forEach(observer => {
        updateObserver(observer as Observer<unknown>)
      })
    }
    return result
  }

  // Initial computation - this sets up dependencies and computes initial value
  updateObserver(o)

  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed value is being accessed by another reactive entity
      // That entity should observe this computed value
      observers.add(observer)
      // We need to establish the dependency relationship by making this computed
      // recompute while the other observer is active
      updateObserver(o)
    }
    // Return the current cached value
    return o.value!
  }

  return getter
}