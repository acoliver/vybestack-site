/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: `callback-${Date.now()}-${Math.random()}`,
    value,
    updateFn: (prevValue) => {
      const newValue = updateFn(prevValue)
      observer.value = newValue
      return newValue
    },
  }
  
  // Register observer to track dependencies and execute the callback
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subject's observer sets
    // Note: In a complete implementation, we'd need to track which subjects
    // this observer is subscribed to and remove it from their observer sets
    // For now, we just disable the observer
    observer.value = undefined
    // Set updateFn to a no-op to prevent further executions
    observer.updateFn = () => value as T
  }
}