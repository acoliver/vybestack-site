import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      // Check if pageParam is a valid positive integer
      if (!/^\d+$/.test(pageParam) || parseInt(pageParam) <= 0) {
        return res.status(400).json({ error: 'Page must be a positive integer greater than 0' });
      }
      page = parseInt(pageParam);
      
      // Check for excessive page values
      if (page > 1000) {
        return res.status(400).json({ error: 'Page value too large' });
      }
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      // Check if limitParam is a valid positive integer
      if (!/^\d+$/.test(limitParam) || parseInt(limitParam) <= 0) {
        return res.status(400).json({ error: 'Limit must be a positive integer greater than 0' });
      }
      limit = parseInt(limitParam);
      
      // Check for excessive limit values
      if (limit > 100) {
        return res.status(400).json({ error: 'Limit value too large (max 100)' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
