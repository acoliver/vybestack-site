export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check
  const emailRegex = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;
  if (!emailRegex.test(value)) return false;
  
  // More comprehensive validation
  const emailParts = value.split('@');
  if (emailParts.length !== 2) return false;
  
  const [localPart, domain] = emailParts;
  
  // Local part validation: allow letters, digits, +, ., -, _ but no consecutive dots
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localRegex.test(localPart)) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  // Domain validation: no underscores, no consecutive dots, no trailing dots
  if (domain.includes('_')) return false;
  if (domain.includes('..')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Domain part validation - allow subdomains
  const domainRegex = /^[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)+$/;
  return domainRegex.test(domain);
}

/**
 * Validate US phone numbers supporting common separators and optional +1.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check length: 10 digits (standard) or 11 digits (with leading 1)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Remove the leading 1 for validation
    const mainDigits = digits.slice(1);
    return validateUSPhoneFormat(mainDigits, value);
  } else if (digits.length === 10) {
    return validateUSPhoneFormat(digits, value);
  }
  
  return false;
}

function validateUSPhoneFormat(digits: string, original: string): boolean {
  // Validate area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Line number (last 4 digits)
  const lineNumber = digits.slice(6, 10);
  if (lineNumber.length !== 4) return false;
  
  // Validate the format with regex
  const phoneRegex = /^\+?1?[\s\-\.]?\(?([2-9]\d{2})\)?[\s\-\.]?([2-9]\d{2})[\s\-\.]?(\d{4})$/;
  return phoneRegex.test(original.replace(/\s+/g, ' '));
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern to match Argentine phone numbers
  // Structure: [+]54 [9] [areaCode] [subscriber]
  // Or: 0[areaCode] [subscriber]
  const withCountryCodeRegex = /^\+54 ?9?([1-9]\d{1,3})(\d{6,8})$/;
  const withoutCountryCodeRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  let match;
  let areaCode, subscriber;
  
  if (withCountryCodeRegex.test(cleanValue)) {
    match = cleanValue.match(withCountryCodeRegex);
    if (match) {
      [, areaCode, subscriber] = match;
    }
  } else if (withoutCountryCodeRegex.test(cleanValue)) {
    match = cleanValue.match(withoutCountryCodeRegex);
    if (match) {
      [, areaCode, subscriber] = match;
    }
  } else {
    return false;
  }
  
  if (!match) return false;
  
  // Area code must be 2-4 digits, starting with 1-9
  if (!areaCode || !/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber must be 6-8 digits
  if (!subscriber || !/^\d{6,8}$/.test(subscriber)) return false;
  
  // Basic format validation - allow spaces and hyphens
  const formatRegex = /^(\+54[\s-]?9?[\s-]?|[0][1-9]\d{1,3}[\s-]?)[1-9]\d{1,3}[\s-]?\d{3,4}[\s-]?\d{3,4}$/;
  return formatRegex.test(value);
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Check for empty string or only whitespace
  if (!value || value.trim().length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Use \p{L} for unicode letters and \p{M} for combining marks
  const nameRegex = /^[\p{L}\p{M}'–-]+(?:[\s][\p{L}\p{M}'–-]+)*$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional validation: reject names with consecutive special characters
  if (/['']{2,}|[-]{2,}|[''][-]|[ -]['']/ .test(value)) return false;
  
  // Reject names that start or end with apostrophe or hyphen
  if (value.match(/^[‘''’-]|[‘''’-]$/)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check length based on card type
  const length = cleanValue.length;
  
  // Visa: 13 or 16 digits, starts with 4
  if ((length === 13 || length === 16) && cleanValue.startsWith('4')) {
    return runLuhnCheck(cleanValue);
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (length === 16) {
    if (cleanValue.match(/^5[1-5]/) || cleanValue.match(/^2(2[2-9]|[3-6]\d|7[01]|720)/)) {
      return runLuhnCheck(cleanValue);
    }
  }
  
  // American Express: 15 digits, starts with 34 or 37
  if (length === 15 && (cleanValue.startsWith('34') || cleanValue.startsWith('37'))) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}