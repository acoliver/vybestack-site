/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Insert exactly one space between sentences and collapse extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim().length === 0) return text;
  
  // First, normalize extra spaces between words
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Split by sentence endings (. ! ?) and process each part
  const sentences = normalized.split(/([.!?])/);
  let result = '';
  
  for (let i = 0; i < sentences.length; i++) {
    const current = sentences[i];
    
    if (current.match(/[.!?]/)) {
      // This is a punctuation mark
      result += current;
    } else if (current.trim().length > 0) {
      // This is a sentence - capitalize first letter
      const trimmed = current.trim();
      const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1).toLowerCase();
      result += capitalized;
    }
  }
  
  // Clean up spacing around punctuation
  result = result.replace(/\s*([.!?])\s*/g, '$1 ').trim();
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s/$.?#].[^\s]*\b/gi;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,!?;:)}\]]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/\bhttp:\/\/([^\s"')>]+)/gi, 'https://$1');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/\bhttps?:\/\/([^/\s"']+)((?:\/[^\s"']*)*)\b/gi, (match, host, path) => {
    // Always upgrade to https
    let newHost = host;
    let newUrl = 'https://' + host + path;
    
    // Check if we should rewrite the host for docs
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const skipHostRewrite = /(?:cgi-\bin|[?&=]|\.(?:jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$))/i.test(path);
      
      if (!skipHostRewrite) {
        // Rewrite host to docs.example.com
        newHost = 'docs.' + host;
        newUrl = 'https://' + newHost + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month/day combinations
  if (month === 2) {
    // February - check for leap year
    const yearNum = parseInt(year, 10);
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (day > (isLeap ? 29 : 28)) return 'N/A';
  } else if (month === 4 || month === 6 || month === 9 || month === 11) {
    // April, June, September, November have 30 days
    if (day > 30) return 'N/A';
  } else {
    // All other months have 31 days
    if (day > 31) return 'N/A';
  }
  
  return year;
}