#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { ReportData } from '../types.js';
import { formatters, supportedFormats } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parse command-line arguments using Node's standard library.
 */
function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  // Skip node and script path
  const positional: string[] = [];
  for (let i = 2; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      positional.push(arg);
    }
  }

  // First positional argument is the input file
  if (positional.length === 0) {
    throw new Error('Input file path is required');
  }
  result.inputFile = positional[0];

  // Validate format
  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}

/**
 * Load and parse JSON data from a file.
 */
function loadData(filePath: string): ReportData {
  const absolutePath = path.resolve(filePath);

  if (!fs.existsSync(absolutePath)) {
    throw new Error(`File not found: ${filePath}`);
  }

  const content = fs.readFileSync(absolutePath, 'utf-8');
  let data: unknown;

  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error(`Invalid JSON: ${(error as Error).message}`);
  }

  // Validate data structure
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: entry ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: entry ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid data: entry ${i} missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI execution.
 */
function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Validate format
    if (!supportedFormats.includes(args.format)) {
      console.error(`Unsupported format: ${args.format}`);
      console.error(`Supported formats: ${supportedFormats.join(', ')}`);
      process.exit(1);
    }

    // Load and validate data
    const data = loadData(args.inputFile);

    // Render report
    const renderer = formatters[args.format];
    const output = renderer(data, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

// Run the CLI
main();
