/**
 * Format registry for easy extension.
 */

import type { FormatRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatters: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const supportedFormats = Object.keys(formatters);
