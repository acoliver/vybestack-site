/**
 * Utility functions for formatting amounts.
 */

/**
 * Format a number as a currency string with exactly two decimal places.
 */
export function formatAmount(amount: number): string {
  return amount.toFixed(2);
}
