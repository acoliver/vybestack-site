/**
 * Capitalizes the first character of each sentence.
 * After sentence-ending punctuation (.?!), capitalizes the next letter.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence endings
  // Replace punctuation followed by optional spaces with a single space
  let normalized = text.replace(/([.!?])\s*/g, '$1 ');
  
  // Collapse multiple spaces into one
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Trim leading/trailing whitespace
  normalized = normalized.trim();
  
  // Capitalize first character
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence-ending punctuation
  // But be careful not to capitalize after abbreviations like "Mr.", "Dr.", etc.
  // For simplicity, we'll capitalize after .!? when followed by a letter
  // and the letter before the punctuation is lowercase (not an abbreviation)
  normalized = normalized.replace(/([.!?])\s+([a-z])/g, (_match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http:// or https:// followed by domain and optional path
  const urlRegex = /https?:\/\/[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,!?;:]/g;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Return unique URLs
  return [...new Set(matches)];
}

/**
 * Converts all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to the following rules:
 * 1. Always upgrade scheme to https://
 * 2. When path begins with /docs/, rewrite host to docs.example.com
 * 3. Skip host rewrite when path contains dynamic hints (cgi-bin, ?, &, =, or legacy extensions)
 * 4. Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /(http:\/\/example\.com\/[^\s<>"{}|\\^`[\]]*)/gi;
  
  return text.replace(urlPattern, (url: string) => {
    // Always upgrade to https
    let upgradedUrl = url.replace(/^http:\/\//i, 'https://');
    
    // Extract the path part (after domain)
    const pathMatch = upgradedUrl.match(/^https:\/\/example\.com(\/.*)$/i);
    
    if (pathMatch) {
      const path = pathMatch[1];
      
      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints that should prevent host rewrite
        const hasDynamicHint = /[?&=]|\/cgi-bin\/|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
        
        if (!hasDynamicHint) {
          // Safe to rewrite host
          upgradedUrl = upgradedUrl.replace(/^https:\/\/example\.com\/docs\//i, 'https://docs.example.com/docs/');
        }
      }
    }
    
    return upgradedUrl;
  });
}

/**
 * Extracts the year from a date string in mm/dd/yyyy format.
 * Returns 'N/A' if the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
