export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regular expressions.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex: local-part@domain
  // Local part: letters, digits, and special characters !#$%&'*+/=?^_`{|}~-
  // But no consecutive dots, no leading/trailing dots, no double dots
  // Domain: letters, digits, hyphens, and dots (but no underscores, no leading/trailing dots, no consecutive dots)
  // TLD: at least 2 letters

  const emailRegex = /^(?![.@])[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[A-Za-z0-9!#$%&'*+/=?^_`{|}~-]+)*(?<!\.)(?<!\.)@[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]{0,61}[A-Za-z0-9])?)*\.[A-Za-z]{2,}$/;

  // Additional checks for things hard to express in a single regex
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }

  // Check for underscore in domain
  const [localPart, domain] = value.split('@');
  if (domain.includes('_')) {
    return false;
  }

  // Check for trailing dot in local part
  if (localPart.endsWith('.')) {
    return false;
  }

  // Check for leading dot in local part
  if (localPart.startsWith('.')) {
    return false;
  }

  // Check domain doesn't start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix allowed.
 * Disallows impossible area codes (leading 0 or 1).
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all whitespace and common separators for validation
  const cleaned = value.replace(/[\s\-().]/g, '');

  // Check if starts with +1 or 1
  const hasCountryCode = cleaned.startsWith('+1') || cleaned.startsWith('1');
  const digits = hasCountryCode ? cleaned.substring(cleaned.startsWith('+1') ? 2 : 1) : cleaned;

  // US phone numbers (without country code) should be exactly 10 digits
  // Format: NXX-NXX-XXXX where N is 2-9, X is 0-9
  const usPhoneRegex = /^[2-9]\d{2}[2-9]\d{6}$/;

  if (!usPhoneRegex.test(digits)) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1 (already enforced by regex)
  // Exchange code (next 3 digits) cannot start with 0 or 1 (already enforced by regex)

  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles in various formats:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (Buenos Aires without country code)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline without country code)
 *
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code (required when country code is omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Separators: single spaces or hyphens allowed
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if country code +54 is present
  const hasCountryCode = cleaned.startsWith('+54');
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode) {
    if (!cleaned.startsWith('0')) {
      return false;
    }
  }

  // Remove optional country code
  const afterCountryCode = hasCountryCode ? cleaned.substring(3) : cleaned;
  
  // At this point, if we had no country code, afterCountryCode starts with '0'
  // Remove the trunk prefix 0 (required when country code is omitted)
  if (!hasCountryCode && !afterCountryCode.startsWith('0')) {
    return false; // Shouldn't happen due to earlier check, but safety
  }
  const afterTrunk = (!hasCountryCode && afterCountryCode.startsWith('0')) 
    ? afterCountryCode.substring(1) 
    : afterCountryCode;
  
  // Remove optional mobile indicator 9
  const afterMobile = afterTrunk.startsWith('9') ? afterTrunk.substring(1) : afterTrunk;

  // Area code: 2-4 digits, first digit 1-9
  // Try each possible area code length (2, 3, or 4 digits)
  const areaCode2Digit = /^([1-9]\d)(\d+)$/.exec(afterMobile);
  const areaCode3Digit = /^([1-9]\d{2})(\d+)$/.exec(afterMobile);
  const areaCode4Digit = /^([1-9]\d{3})(\d+)$/.exec(afterMobile);

  // Check if area code + subscriber is valid
  const isValidLength = (areaCode: RegExpExecArray | null) => {
    if (!areaCode) return false;
    const subscriber = areaCode[2];
    return subscriber.length >= 6 && subscriber.length <= 8;
  };

  return isValidLength(areaCode2Digit) || isValidLength(areaCode3Digit) || isValidLength(areaCode4Digit);
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and strange names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Name regex: unicode letters (including accents), apostrophes, hyphens, spaces
  // At least one character, can have multiple parts separated by spaces
  // No digits, no symbols other than apostrophe and hyphen
  const nameRegex = /^[\p{L}\p{M}'-][\p{L}\p{M}'\s-]*[\p{L}\p{M}'-]$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Check for digits (already excluded by regex, but double-check)
  if (/\d/.test(value)) {
    return false;
  }

  // Check for other symbols (not letters, apostrophe, hyphen, or whitespace)
  const symbolRegex = /[^\p{L}\p{M}'\-\s]/u;
  if (symbolRegex.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa, Mastercard, and American Express formats.
 * Validates prefix, length, and performs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 13, 16 or 19 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37

  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;

  const validFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validFormat) {
    return false;
  }

  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn algorithm checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
