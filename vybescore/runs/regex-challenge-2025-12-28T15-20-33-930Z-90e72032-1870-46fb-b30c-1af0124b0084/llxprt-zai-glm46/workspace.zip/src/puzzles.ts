/**
 * Finds words beginning with the given prefix, excluding specified exceptions.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  // Word boundary \b ensures we match whole words
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and return unique values
  const exceptionSet = new Set(exceptions);
  return [...new Set(matches.filter(word => !exceptionSet.has(word)))];
}

/**
 * Finds occurrences of a token only when it appears after a digit
 * and not at the start of the string.
 * Uses lookbehind to check for preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: match the token preceded by a digit, capturing the whole match including the digit
  // This will match "1foo" but not "foo" at the start or "xfoo"
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validates password strength according to the policy:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric, non-whitespace)
 * - No whitespace allowed
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // A sequence of 2-4 characters that repeats immediately
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation (::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (excluding IPv4-mapped IPv6 addresses that look like IPv4)
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can appear once to represent one or more consecutive zero groups
  // Should not match pure IPv4 addresses
  
  // First, check if it looks like an IPv4 address and exclude it
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // IPv6 patterns:
  // 1. Full form: 8 groups of hex digits separated by colons
  const fullIpv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // 2. Compressed form with ::
  const compressedIpv6 = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // 3. Mixed form (starts with some hex groups, may end with IPv4)
  // But we want to exclude pure IPv4, so we're careful here
  const ipv6WithIpv4 = /^(?:[0-9a-fA-F]{1,4}:){1,6}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Extract potential IPv6 addresses from the text
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*[0-9a-fA-F]{0,4}/g;
  
  const matches = value.match(ipv6Pattern);
  
  if (!matches) {
    return false;
  }
  
  // Verify that at least one match is a valid IPv6 and not just an IPv4
  for (const match of matches) {
    // Skip if it's just an IPv4 address
    if (ipv4Pattern.test(match)) {
      continue;
    }
    
    // Check if it's a valid IPv6 pattern
    if (fullIpv6.test(match) || compressedIpv6.test(match)) {
      return true;
    }
    
    // Check for IPv6 with embedded IPv4
    if (ipv6WithIpv4.test(match)) {
      return true;
    }
  }
  
  return false;
}
