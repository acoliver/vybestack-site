import type { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(
  data: ReportData,
  options: RenderOptions
): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  const lines: string[] = [];

  // Title
  lines.push(`# ${title}`);
  lines.push('');

  // Summary
  lines.push(summary);
  lines.push('');

  // Entries heading
  lines.push('## Entries');

  // Entries list
  for (const entry of entries) {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }

  // Total if requested
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }

  return lines.join('\n');
}