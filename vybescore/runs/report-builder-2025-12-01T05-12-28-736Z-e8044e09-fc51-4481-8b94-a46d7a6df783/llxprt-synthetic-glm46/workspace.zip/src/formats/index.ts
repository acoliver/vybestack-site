import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type ReportRenderer = (data: ReportData, options: RenderOptions) => string;

export const formatRenderers: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getSupportedFormats(): string[] {
  return Object.keys(formatRenderers);
}

export function getRenderer(format: string): ReportRenderer {
  const renderer = formatRenderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}