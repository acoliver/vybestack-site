#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { getRenderer, getSupportedFormats } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(processArgs: string[]): CliArgs {
  const args = processArgs.slice(2);

  if (args.length < 3) {
    throw new Error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  
  const formatFlagIndex = args.findIndex(arg => arg === '--format');
  if (formatFlagIndex === -1 || formatFlagIndex === args.length - 1) {
    throw new Error('Missing --format argument');
  }
  const format = args[formatFlagIndex + 1];

  const outputFlagIndex = args.findIndex(arg => arg === '--output');
  let outputPath: string | undefined;
  if (outputFlagIndex !== -1 && outputFlagIndex < args.length - 1) {
    outputPath = args[outputFlagIndex + 1];
  }

  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected object');
  }

  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid data: entries is required and must be an array');
  }

  const entries = report.entries.filter((entry): entry is { label: string; amount: number } => {
    return (
      typeof entry === 'object' &&
      entry !== null &&
      typeof entry.label === 'string' &&
      typeof entry.amount === 'number'
    );
  });

  if (entries.length !== report.entries.length) {
    throw new Error('Invalid data: all entries must have label (string) and amount (number)');
  }

  return {
    title: report.title,
    summary: report.summary,
    entries,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Validate format
    if (!getSupportedFormats().includes(args.format)) {
      throw new Error(`Unsupported format: ${args.format}. Supported formats: ${getSupportedFormats().join(', ')}`);
    }

    // Read and parse JSON data
    let data: unknown;
    try {
      const jsonContent = readFileSync(args.dataFile, 'utf8');
      data = JSON.parse(jsonContent);
    } catch (error) {
      throw new Error(`Failed to read or parse JSON file ${args.dataFile}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }

    // Validate and type-check data
    const reportData = validateReportData(data);

    // Configure rendering options
    const renderOptions: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    // Render report
    const renderer = getRenderer(args.format);
    const output = renderer(reportData, renderOptions);

    // Output result
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();
