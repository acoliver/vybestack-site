/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  dependents?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addDependent<T extends ObserverR | SubjectR>(source: T, dependent: ObserverR): void {
  if (!source.dependents) {
    source.dependents = new Set()
  }
  source.dependents.add(dependent)
}

export function removeDependent<T extends ObserverR | SubjectR>(source: T, dependent: ObserverR): void {
  if (source.dependents) {
    source.dependents.delete(dependent)
  }
}

export function notifyDependents<T extends ObserverR | SubjectR>(source: T): void {
  if (source.dependents) {
    const dependentsCopy = new Set(source.dependents) // Create copy to avoid modification during iteration
    for (const dependent of dependentsCopy) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
}