/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(
  updateFn: UpdateFn<T>,
  value?: T
): UnsubscribeFn {
  let isActive = true
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      if (!isActive) return currentValue as T
      
      // Execute the actual callback function to perform side effects
      const result = updateFn(currentValue)
      
      // Return the result so the observer.value gets updated
      return result
    },
    dependents: new Set()
  }

  // Execute initially to register dependencies
  updateObserver(observer)

const unsubscribe = () => {
    // Mark as inactive so future updates don't execute the callback
    isActive = false

    // Remove this observer from the reactive system
    // The callback observer needs to be removed from its dependencies' dependents sets
    // We can't directly access the sources, but we can clear our dependents
    if (observer.dependents) {
      observer.dependents.clear()
    }
  }

  return unsubscribe
}