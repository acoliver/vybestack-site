/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  notifyDependents,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: EqualFn<T>,
  options?: { name?: string; maxHistory?: number }
): GetterFn<T> {
  // Observer to track this computed value
  const observer: Observer<T> = {
    value,
    updateFn,
    name: options?.name,
    dependents: new Set()
  }

  // History tracking if enabled
  const history: T[] = []
  const maxHistory = options?.maxHistory || 0
  
  if (maxHistory > 0 && value !== undefined) {
    history.push(value)
  }

  // Store the equal function for value comparison
  const equalFn = equal

  // Getter function that performs the computation
  const getter: GetterFn<T> = () => {
    // Store the old value before updating
    const oldValue = observer.value

    // Update the observer to compute the new value and track dependencies
    updateObserver(observer)

    // Get the new value
    const newValue = observer.value as T

    // Check if value changed and add to history if enabled
    let valueChanged = false
    if (equalFn) {
      valueChanged = !equalFn(oldValue as T, newValue)
    } else {
      valueChanged = oldValue !== newValue
    }

    // Add to history if enabled and value changed
    if (maxHistory > 0 && valueChanged) {
      history.push(newValue)
      if (history.length > maxHistory) {
        history.shift()
      }
    }

    // Notify dependents if value changed
    if (valueChanged) {
      notifyDependents(observer)
    }

    return newValue
  }

  return getter
}