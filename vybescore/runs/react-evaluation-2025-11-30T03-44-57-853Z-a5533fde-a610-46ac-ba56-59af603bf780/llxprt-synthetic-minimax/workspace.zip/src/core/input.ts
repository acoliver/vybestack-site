/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyDependents,
  addDependent,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options & { maxHistory?: number }
): InputPair<T> {
  // Subject to track this input's reactive state
  const subject: Subject<T> = {
    value,
    equalFn: equal,
    observer: undefined,
    dependents: new Set()
  }

  // History tracking if enabled
  const history: T[] = []
  const maxHistory = options?.maxHistory || 0
  
  if (maxHistory > 0) {
    history.push(value)
  }

  // Getter function
  const getter: GetterFn<T> = () => {
    // Register this subject as a dependent of the active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addDependent(subject, activeObserver)
    }
    return subject.value
  }

  // Setter function
  const setter: SetterFn<T> = (newValue: T) => {
    // Check if value actually changed
    if (subject.equalFn) {
      if (subject.equalFn(subject.value, newValue)) {
        return subject.value // Values are equal, return current value
      }
    } else if (subject.value === newValue) {
      return subject.value // Values are equal (reference or primitive), return current value
    }

    // Update the value
    subject.value = newValue

    // Add to history if enabled
    if (maxHistory > 0) {
      history.push(newValue)
      if (history.length > maxHistory) {
        history.shift()
      }
    }

    // Notify all dependents that this subject has changed
    notifyDependents(subject)

    return newValue
  }

  return [getter, setter]
}