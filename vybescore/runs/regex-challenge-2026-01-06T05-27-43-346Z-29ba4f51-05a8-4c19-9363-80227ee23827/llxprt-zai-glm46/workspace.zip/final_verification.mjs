#!/usr/bin/env node
/**
 * Final comprehensive test suite for regex challenge implementations
 */

import * as validators from './dist/src/validators.js';
import * as transformations from './dist/src/transformations.js';
import * as puzzles from './dist/src/puzzles.js';

const { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } = validators;
const { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } = transformations;
const { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } = puzzles;

let passCount = 0;
let failCount = 0;

function test(name, fn) {
  try {
    fn();
    console.log(`[OK] ${name}`);
    passCount++;
  } catch (e) {
    console.log(` ${name}`);
    console.log(`  ${e.message}`);
    failCount++;
  }
}

function assertEqual(actual, expected, msg) {
  const a = JSON.stringify(actual);
  const b = JSON.stringify(expected);
  if (a !== b) {
    throw new Error(`${msg}\n  Expected: ${b}\n  Actual: ${a}`);
  }
}

console.log('=== FINAL VERIFICATION TESTS ===\n');

console.log('--- Validators ---');
test('Email: accepts simple', () => {
  if (!isValidEmail('user@example.com')) throw new Error('Should accept simple email');
});

test('Email: accepts plus tag', () => {
  if (!isValidEmail('name+tag@example.co.uk')) throw new Error('Should accept plus tag');
});

test('Email: rejects double dots', () => {
  if (isValidEmail('user@domain..com')) throw new Error('Should reject double dots in domain');
});

test('Email: rejects underscore in domain', () => {
  if (isValidEmail('user@_domain.com')) throw new Error('Should reject underscore in domain');
});

test('Email: rejects trailing dot', () => {
  if (isValidEmail('user@domain.com.')) throw new Error('Should reject trailing dot');
});

test('US Phone: accepts (212) 555-7890', () => {
  if (!isValidUSPhone('(212) 555-7890')) throw new Error('Should accept (212) 555-7890');
});

test('US Phone: accepts 212-555-7890', () => {
  if (!isValidUSPhone('212-555-7890')) throw new Error('Should accept 212-555-7890');
});

test('US Phone: accepts +1 212-555-7890', () => {
  if (!isValidUSPhone('+1 212-555-7890')) throw new Error('Should accept +1 212-555-7890');
});

test('US Phone: rejects area code starting with 0', () => {
  if (isValidUSPhone('(012) 555-7890')) throw new Error('Should reject 012 area code');
});

test('US Phone: rejects area code starting with 1', () => {
  if (isValidUSPhone('(112) 555-7890')) throw new Error('Should reject 112 area code');
});

test('US Phone: rejects too short', () => {
  if (isValidUSPhone('212555789')) throw new Error('Should reject 9-digit number');
});

test('Argentine Phone: accepts +54 9 11 1234 5678', () => {
  if (!isValidArgentinePhone('+54 9 11 1234 5678')) throw new Error('Should accept mobile format');
});

test('Argentine Phone: accepts 011 1234 5678', () => {
  if (!isValidArgentinePhone('011 1234 5678')) throw new Error('Should accept Buenos Aires format');
});

test('Argentine Phone: accepts +54 341 123 4567', () => {
  if (!isValidArgentinePhone('+54 341 123 4567')) throw new Error('Should accept landline with country code');
});

test('Argentine Phone: accepts 0341 4234567', () => {
  if (!isValidArgentinePhone('0341 4234567')) throw new Error('Should accept landline with trunk prefix');
});

test('Argentine Phone: rejects without trunk prefix when no country code', () => {
  if (isValidArgentinePhone('11 1234 5678')) throw new Error('Should reject without 0 prefix');
});

test('Name: accepts Jane Doe', () => {
  if (!isValidName('Jane Doe')) throw new Error('Should accept simple name');
});

test('Name: accepts unicode José María', () => {
  if (!isValidName('José María')) throw new Error('Should accept unicode with accents');
});

test('Name: accepts O\'Brien', () => {
  if (!isValidName("O'Brien")) throw new Error('Should accept apostrophe');
});

test('Name: accepts Mary-Jane', () => {
  if (!isValidName('Mary-Jane')) throw new Error('Should accept hyphen');
});

test('Name: rejects X Æ A-12', () => {
  if (isValidName('X Æ A-12')) throw new Error('Should reject name with digits');
});

test('Name: rejects empty string', () => {
  if (isValidName('')) throw new Error('Should reject empty string');
});

test('Credit Card: accepts Visa 4111111111111111', () => {
  if (!isValidCreditCard('4111111111111111')) throw new Error('Should accept test Visa');
});

test('Credit Card: accepts Mastercard 5555555555554444', () => {
  if (!isValidCreditCard('5555555555554444')) throw new Error('Should accept test Mastercard');
});

test('Credit Card: accepts AmEx 378282246310005', () => {
  if (!isValidCreditCard('378282246310005')) throw new Error('Should accept test AmEx');
});

test('Credit Card: rejects bad Luhn checksum', () => {
  if (isValidCreditCard('4111111111111112')) throw new Error('Should reject bad checksum');
});

console.log('\n--- Transformations ---');
test('Capitalize: handles basic sentences', () => {
  assertEqual(capitalizeSentences('hello. how are you?'), 'Hello. How are you?', 'capitalize basic');
});

test('Capitalize: inserts space after punctuation', () => {
  assertEqual(capitalizeSentences('hello.how are you?'), 'Hello. How are you?', 'insert space');
});

test('Capitalize: collapses multiple spaces', () => {
  assertEqual(capitalizeSentences('hello.  how   are  you?'), 'Hello. How are you?', 'collapse spaces');
});

test('Extract URLs: finds http URLs', () => {
  const urls = extractUrls('Visit http://example.com today');
  assertEqual(urls, ['http://example.com'], 'extract http');
});

test('Extract URLs: removes trailing punctuation', () => {
  const urls = extractUrls('Go to http://example.com.');
  assertEqual(urls, ['http://example.com'], 'remove trailing dot');
});

test('Enforce HTTPS: upgrades http to https', () => {
  assertEqual(enforceHttps('http://example.com'), 'https://example.com', 'upgrade scheme');
});

test('Enforce HTTPS: preserves existing https', () => {
  assertEqual(enforceHttps('https://example.com'), 'https://example.com', 'preserve https');
});

test('Rewrite Docs: upgrades scheme and changes host', () => {
  const result = rewriteDocsUrls('See http://example.com/docs/guide');
  if (!result.includes('https://docs.example.com/docs/guide')) {
    throw new Error('Should rewrite docs URL');
  }
});

test('Rewrite Docs: skips .jsp files', () => {
  const result = rewriteDocsUrls('See http://example.com/docs/guide.jsp');
  if (!result.includes('https://example.com/docs/guide.jsp')) {
    throw new Error('Should not rewrite .jsp URLs');
  }
});

test('Rewrite Docs: skips query strings', () => {
  const result = rewriteDocsUrls('See http://example.com/docs/guide?foo=bar');
  if (!result.includes('https://example.com/docs/guide?foo=bar')) {
    throw new Error('Should not rewrite URLs with query strings');
  }
});

test('Extract Year: works for valid date', () => {
  assertEqual(extractYear('01/31/2024'), '2024', 'extract year');
});

test('Extract Year: handles leap year', () => {
  assertEqual(extractYear('02/29/2024'), '2024', 'leap year 2024');
});

test('Extract Year: rejects invalid leap year', () => {
  assertEqual(extractYear('02/29/2023'), 'N/A', 'not leap year 2023');
});

test('Extract Year: rejects invalid month', () => {
  assertEqual(extractYear('13/01/2024'), 'N/A', 'invalid month');
});

test('Extract Year: rejects invalid day', () => {
  assertEqual(extractYear('01/32/2024'), 'N/A', 'invalid day');
});

test('Extract Year: rejects bad format', () => {
  assertEqual(extractYear('not-a-date'), 'N/A', 'bad format');
});

console.log('\n--- Puzzles ---');
test('Find Prefixed Words: finds matches', () => {
  const result = findPrefixedWords('preview prevent prefix', 'pre', ['prevent']);
  assertEqual(result, ['preview', 'prefix'], 'find prefixed words');
});

test('Find Embedded Token: finds after digits', () => {
  const result = findEmbeddedToken('xfoo 1foo foo', 'foo');
  assertEqual(result, ['1foo'], 'find embedded token');
});

test('Strong Password: accepts valid password', () => {
  if (!isStrongPassword('Abcdef!234')) throw new Error('Should accept strong password');
});

test('Strong Password: rejects repeated sequence', () => {
  if (isStrongPassword('abab!1234')) throw new Error('Should reject repeated sequence');
});

test('Strong Password: rejects too short', () => {
  if (isStrongPassword('Weak1!')) throw new Error('Should reject short password');
});

test('Strong Password: rejects no symbol', () => {
  if (isStrongPassword('NoSymbol123A')) throw new Error('Should reject password without symbol');
});

test('Strong Password: rejects no uppercase', () => {
  if (isStrongPassword('testtest!123')) throw new Error('Should reject password without uppercase');
});

test('Strong Password: rejects no lowercase', () => {
  if (isStrongPassword('TESTTEST!123')) throw new Error('Should reject password without lowercase');
});

test('IPv6: detects full address', () => {
  if (!containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334')) throw new Error('Should detect full IPv6');
});

test('IPv6: detects compressed ::1', () => {
  if (!containsIPv6('::1')) throw new Error('Should detect ::1');
});

test('IPv6: detects 2001:db8::1', () => {
  if (!containsIPv6('2001:db8::1')) throw new Error('Should detect compressed IPv6');
});

test('IPv6: rejects double double-colon', () => {
  if (containsIPv6('2001::db8::1')) throw new Error('Should reject double ::');
});

test('IPv6: rejects IPv4', () => {
  if (containsIPv6('192.168.1.1')) throw new Error('Should reject IPv4');
});

test('IPv6: rejects non-IP', () => {
  if (containsIPv6('not an ip')) throw new Error('Should reject non-IP');
});

console.log(`\n=== RESULTS ===`);
console.log(`Passed: ${passCount}`);
console.log(`Failed: ${failCount}`);
console.log(`Total: ${passCount + failCount}`);

if (failCount > 0) {
  process.exit(1);
}
