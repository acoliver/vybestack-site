import * as validators from './dist/src/validators.js';
import * as transformations from './dist/src/transformations.js';
import * as puzzles from './dist/src/puzzles.js';

const { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } = validators;
const { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } = transformations;
const { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } = puzzles;

console.log('=== EDGE CASE TESTS ===\n');

console.log('--- Email Edge Cases ---');
console.log('double..dot@example.com:', isValidEmail('double..dot@example.com'));
console.log('user@domain..com:', isValidEmail('user@domain..com'));
console.log('user@_domain.com:', isValidEmail('user@_domain.com'));
console.log('user@domain_.com:', isValidEmail('user@domain_.com'));
console.log('test.email+tag@example.co.uk:', isValidEmail('test.email+tag@example.co.uk'));
console.log('user@sub.domain.example.com:', isValidEmail('user@sub.domain.example.com'));
console.log('user@localhost:', isValidEmail('user@localhost'));

console.log('\n--- US Phone Edge Cases ---');
console.log('1-212-555-7890:', isValidUSPhone('1-212-555-7890'));
console.log('+1 (212) 555-7890:', isValidUSPhone('+1 (212) 555-7890'));
console.log('(012) 555-7890:', isValidUSPhone('(012) 555-7890'));
console.log('(112) 555-7890:', isValidUSPhone('(112) 555-7890'));
console.log('212555789:', isValidUSPhone('212555789')); // Too short

console.log('\n--- Argentine Phone Edge Cases ---');
console.log('+54 9 11 12345678:', isValidArgentinePhone('+54 9 11 12345678'));
console.log('11 12345678:', isValidArgentinePhone('11 12345678')); // Missing 0 prefix
console.log('011 123456:', isValidArgentinePhone('011 123456')); // Too short
console.log('+54 011 12345678:', isValidArgentinePhone('+54 011 12345678'));
console.log('0 11 12345678:', isValidArgentinePhone('0 11 12345678'));

console.log('\n--- Name Edge Cases ---');
console.log('Émilie:', isValidName('Émilie'));
console.log('Müller-Lüdenscheidt:', isValidName('Müller-Lüdenscheidt'));
console.log("O'Connor-Smith:", isValidName("O'Connor-Smith"));
console.log('Åsa:', isValidName('Åsa'));
console.log('José:', isValidName('José'));
console.log('X Æ A-12:', isValidName('X Æ A-12'));
console.log('Test123:', isValidName('Test123'));
console.log('', isValidName(''));
console.log('   :', isValidName('   '));

console.log('\n--- Credit Card Edge Cases ---');
console.log('4111 1111 1111 1111:', isValidCreditCard('4111 1111 1111 1111'));
console.log('4111-1111-1111-1111:', isValidCreditCard('4111-1111-1111-1111'));
console.log('4222222222222 (13 digits):', isValidCreditCard('4222222222222'));
console.log('378282246310005 (AmEx):', isValidCreditCard('378282246310005'));
console.log('5555555555554444 (Mastercard):', isValidCreditCard('5555555555554444'));
console.log('4111111111111111 (bad checksum):', isValidCreditCard('4111111111111111'));

console.log('\n--- Capitalize Sentences Edge Cases ---');
console.log('Input: "hello.how are you?"');
console.log('Output:', capitalizeSentences('hello.how are you?'));
console.log('Input: "hello.  how   are  you?"');
console.log('Output:', capitalizeSentences('hello.  how   are  you?'));
console.log('Input: "dr. smith is here. mr. jones arrived."');
console.log('Output:', capitalizeSentences('dr. smith is here. mr. jones arrived.'));

console.log('\n--- Extract URLs Edge Cases ---');
console.log('Input: "Visit (http://example.com/foo)."');
console.log('Output:', extractUrls('Visit (http://example.com/foo).'));
console.log('Input: "Go to http://example.com/path?query=1&sort=desc now"');
console.log('Output:', extractUrls('Go to http://example.com/path?query=1&sort=desc now'));

console.log('\n--- Rewrite Docs URLs Edge Cases ---');
console.log('Input: "See http://example.com/docs/api/v1/guide"');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/api/v1/guide'));
console.log('Input: "See http://example.com/docs/guide.jsp"');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/guide.jsp'));
console.log('Input: "See http://example.com/cgi-bin/docs/guide"');
console.log('Output:', rewriteDocsUrls('See http://example.com/cgi-bin/docs/guide'));
console.log('Input: "See http://example.com/docs/guide?foo=bar"');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/guide?foo=bar'));
console.log('Input: "See http://example.com/about"');
console.log('Output:', rewriteDocsUrls('See http://example.com/about'));

console.log('\n--- Extract Year Edge Cases ---');
console.log('02/29/2024 (leap year):', extractYear('02/29/2024'));
console.log('02/29/2023 (not leap year):', extractYear('02/29/2023'));
console.log('00/15/2024:', extractYear('00/15/2024'));
console.log('01/00/2024:', extractYear('01/00/2024'));

console.log('\n--- Find Prefixed Words Edge Cases ---');
console.log('Input: "pretest preview prevent pre", prefix: "pre", exceptions: ["prevent"]');
console.log('Output:', findPrefixedWords('pretest preview prevent pre', 'pre', ['prevent']));

console.log('\n--- Find Embedded Token Edge Cases ---');
console.log('Input: "1foo 2foo 3foo", token: "foo"');
console.log('Output:', findEmbeddedToken('1foo 2foo 3foo', 'foo'));
console.log('Input: "foo 1foo", token: "foo"');
console.log('Output:', findEmbeddedToken('foo 1foo', 'foo'));

console.log('\n--- Strong Password Edge Cases ---');
console.log('abcabcabc!1A:', isStrongPassword('abcabcabc!1A'));
console.log('Test!123:', isStrongPassword('Test!123')); // Too short
console.log('Test!12345:', isStrongPassword('Test!12345'));
console.log('TESTTEST!123:', isStrongPassword('TESTTEST!123')); // No lowercase
console.log('testtest!123:', isStrongPassword('testtest!123')); // No uppercase
console.log('TestTest!123:', isStrongPassword('TestTest!123')); // Has repeated sequence

console.log('\n--- IPv6 Detection Edge Cases ---');
console.log('2001:0db8:85a3:0000:0000:8a2e:0370:7334:', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log('2001:db8::1:', containsIPv6('2001:db8::1'));
console.log('::1:', containsIPv6('::1'));
console.log('2001::db8::1:', containsIPv6('2001::db8::1'));
console.log('fe80::1%lo0:', containsIPv6('fe80::1%lo0'));
console.log('192.168.1.1:', containsIPv6('192.168.1.1'));
console.log('not an ip:', containsIPv6('not an ip'));
