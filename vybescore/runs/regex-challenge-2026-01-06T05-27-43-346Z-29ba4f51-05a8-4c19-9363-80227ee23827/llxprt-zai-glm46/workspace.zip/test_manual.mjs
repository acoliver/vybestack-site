import * as validators from './dist/src/validators.js';
import * as transformations from './dist/src/transformations.js';
import * as puzzles from './dist/src/puzzles.js';

const { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } = validators;
const { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } = transformations;
const { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } = puzzles;

console.log('=== Testing Email ===');
console.log('name+tag@example.co.uk:', isValidEmail('name+tag@example.co.uk'));
console.log('user@example.com:', isValidEmail('user@example.com'));
console.log('user@@example..com:', isValidEmail('user@@example..com'));
console.log('user@domain_.com:', isValidEmail('user@domain_.com'));
console.log('.user@example.com:', isValidEmail('.user@example.com'));
console.log('user.@example.com:', isValidEmail('user.@example.com'));

console.log('\n=== Testing US Phone ===');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('2125557890:', isValidUSPhone('2125557890'));
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('012-555-7890:', isValidUSPhone('012-555-7890')); // Should fail - area code starts with 0
console.log('112-555-7890:', isValidUSPhone('112-555-7890')); // Should fail - area code starts with 1

console.log('\n=== Testing Argentine Phone ===');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567'));

console.log('\n=== Testing Name ===');
console.log('Jane Doe:', isValidName('Jane Doe'));
console.log('José María:', isValidName('José María'));
console.log('O\'Brien:', isValidName('O\'Brien'));
console.log('Mary-Jane:', isValidName('Mary-Jane'));
console.log('X Æ A-12:', isValidName('X Æ A-12')); // Should fail - has digit
console.log('John123:', isValidName('John123')); // Should fail - has digit

console.log('\n=== Testing Credit Card ===');
console.log('4111111111111111 (Visa):', isValidCreditCard('4111111111111111'));
console.log('5500000000000004 (Mastercard):', isValidCreditCard('5500000000000004'));
console.log('340000000000009 (AmEx):', isValidCreditCard('340000000000009'));
console.log('4111111111111112 (bad checksum):', isValidCreditCard('4111111111111112'));

console.log('\n=== Testing Capitalize Sentences ===');
console.log('Input: "hello world. how are you?"');
console.log('Output:', capitalizeSentences('hello world. how are you?'));

console.log('\n=== Testing Extract URLs ===');
console.log('Input: "Visit http://example.com, https://test.org, and www.site.com."');
console.log('Output:', extractUrls('Visit http://example.com, https://test.org, and www.site.com.'));

console.log('\n=== Testing Enforce HTTPS ===');
console.log('Input: "http://example.com and https://already.com"');
console.log('Output:', enforceHttps('http://example.com and https://already.com'));

console.log('\n=== Testing Rewrite Docs URLs ===');
console.log('Input: "See http://example.com/docs/guide"');
console.log('Output:', rewriteDocsUrls('See http://example.com/docs/guide'));

console.log('\n=== Testing Extract Year ===');
console.log('01/31/2024:', extractYear('01/31/2024'));
console.log('13/01/2024:', extractYear('13/01/2024')); // Should fail - invalid month
console.log('01/32/2024:', extractYear('01/32/2024')); // Should fail - invalid day
console.log('not-a-date:', extractYear('not-a-date')); // Should fail

console.log('\n=== Testing Find Prefixed Words ===');
console.log('Input: "preview prevent prefix", prefix: "pre", exceptions: ["prevent"]');
console.log('Output:', findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));

console.log('\n=== Testing Find Embedded Token ===');
console.log('Input: "xfoo 1foo foo", token: "foo"');
console.log('Output:', findEmbeddedToken('xfoo 1foo foo', 'foo'));

console.log('\n=== Testing Strong Password ===');
console.log('Abcdef!234:', isStrongPassword('Abcdef!234'));
console.log('abab!1234:', isStrongPassword('abab!1234')); // Should fail - repeated sequence
console.log('Weak1:', isStrongPassword('Weak1')); // Should fail - too short
console.log('NoSymbol123A:', isStrongPassword('NoSymbol123A')); // Should fail - no symbol

console.log('\n=== Testing IPv6 Detection ===');
console.log('2001:db8::1:', containsIPv6('2001:db8::1'));
console.log('192.168.1.1:', containsIPv6('192.168.1.1')); // Should be false - IPv4
