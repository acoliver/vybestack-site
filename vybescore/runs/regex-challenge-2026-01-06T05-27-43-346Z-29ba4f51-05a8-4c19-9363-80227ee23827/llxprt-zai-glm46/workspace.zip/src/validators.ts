export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses. Accepts typical forms like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that:
  // - Accepts letters, digits, dots, hyphens, underscores, plus signs in local part
  // - Requires @
  // - Domain must have at least one dot
  // - TLD must be at least 2 chars
  // - Rejects double dots, trailing dots, underscores in domain
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*\.[a-zA-Z]{2,}$/;

  // Additional checks for invalid patterns
  if (/\.\./.test(value)) return false; // Double dots
  if (/\.$/.test(value)) return false; // Trailing dot
  if (/^[._%+-]/.test(value.split('@')[0])) return false; // Local part starts with special char
  if (/[._%+-]$/.test(value.split('@')[0])) return false; // Local part ends with special char
  if (/_/.test(value.split('@')[1])) return false; // Underscore in domain

  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common separators and optional +1 prefix.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // Minimum 10 digits (standard US number), 11 if country code is present
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;

  // Handle optional +1 country code
  let areaCodeStart = 0;
  if (digitsOnly.length === 11) {
    if (digitsOnly[0] !== '1') return false; // Must be +1
    areaCodeStart = 1;
  }

  // Area code must not start with 0 or 1
  const areaCodeFirstDigit = digitsOnly[areaCodeStart];
  if (areaCodeFirstDigit === '0' || areaCodeFirstDigit === '1') return false;

  // Check overall format with separators
  // Accepts: +1 (212) 555-7890, (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/;

  // Additional check: area code can't start with 0/1
  const areaCodeMatch = value.match(/\(?(\d{3})\)?/);
  if (areaCodeMatch) {
    const areaCode = areaCodeMatch[1];
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  }

  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');

  // Argentine phone regex:
  // - Optional +54 country code
  // - When country code is omitted, must start with 0 (trunk prefix)
  // - Optional 9 (mobile indicator) after country code/trunk prefix
  // - Area code: 2-4 digits, first digit 1-9
  // - Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?0?9?\d{2,4}\d{6,8}$/;

  if (!argentinePhoneRegex.test(normalized)) return false;

  // Extract the area code part (after optional country code and trunk prefix)
  let remaining = normalized;
  if (remaining.startsWith('+54')) {
    remaining = remaining.slice(3);
  } else if (remaining.startsWith('0')) {
    remaining = remaining.slice(1);
  } else {
    // If no country code, must have trunk prefix 0
    return false;
  }

  // Remove optional mobile indicator 9
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }

  // Area code must be 2-4 digits, first digit 1-9
  const areaCodeMatch = remaining.match(/^(\d{2,4})/);
  if (!areaCodeMatch) return false;

  const areaCode = areaCodeMatch[1];
  if (areaCode[0] === '0') return false; // Area code can't start with 0

  // Check subscriber number length (6-8 digits after area code)
  const subscriberNumber = remaining.slice(areaCode.length);
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and names like "X Æ A-12" with digits.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least one letter
  // Reject digits and other symbols
  const nameRegex = /^[\p{L}'\-\s]+$/u;

  // Must contain at least one letter
  const hasLetter = /\p{L}/u.test(value);

  // No digits allowed
  const hasDigit = /\d/.test(value);

  // Must not be empty or only whitespace
  const hasContent = value.trim().length > 0;

  return nameRegex.test(value) && hasLetter && !hasDigit && hasContent;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa (13-16 digits, starts with 4), Mastercard (16 digits, starts with 51-55 or 2221-2720),
 * and American Express (15 digits, starts with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const digitsOnly = value.replace(/[\s-]/g, '');

  // Check length based on card type
  // Visa: 13-16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^(5[1-5]\d{14}|(2[2-7][0-9]|2[2-7])\d{14})$/;
  const amexRegex = /^3[47]\d{13}$/;

  const validFormat = visaRegex.test(digitsOnly) ||
                      mastercardRegex.test(digitsOnly) ||
                      amexRegex.test(digitsOnly);

  if (!validFormat) return false;

  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

/**
 * Run Luhn checksum algorithm on a card number string.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
