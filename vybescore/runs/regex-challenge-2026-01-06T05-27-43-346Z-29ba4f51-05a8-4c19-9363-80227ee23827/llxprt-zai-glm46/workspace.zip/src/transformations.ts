/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Ensures exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Step 1: Insert exactly one space after sentence-ending punctuation if missing
  // This looks for punctuation followed by lowercase (or space + lowercase)
  let result = text.replace(/([.!?])([a-z])/g, '$1 $2');

  // Step 2: Collapse multiple spaces to single space
  result = result.replace(/\s+/g, ' ');

  // Step 3: Capitalize first character of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Step 4: Capitalize first letter after sentence-ending punctuation
  // This handles the general case while being careful about abbreviations
  // We'll capitalize after . ! ? unless it looks like an abbreviation
  // (short word followed by another lowercase word is likely an abbreviation)
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });

  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http://, https://, and www. URLs
  // Uses negative lookahead to exclude trailing punctuation
  const urlRegex = /https?:\/\/[^\s<>"']+|www\.[^\s<>"']+/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation: . , ; : ? ! ) ] }
    return url.replace(/[.,;:?!\])}]+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints: cgi-bin, query strings, legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /(http:\/\/example\.com\/[^\s<>"']+)/gi;

  return text.replace(urlPattern, (url) => {
    // First, upgrade scheme to https
    const upgraded = url.replace(/^http:\/\//, 'https://');

    // Parse the URL to check if it has /docs/ path
    const urlObj = new URL(upgraded);
    const pathname = urlObj.pathname;
    const search = urlObj.search;

    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHint =
      pathname.includes('/cgi-bin') ||
      search.includes('?') ||
      search.includes('&') ||
      search.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/i.test(pathname);

    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (pathname.startsWith('/docs/') && !hasDynamicHint) {
      urlObj.host = 'docs.example.com';
      return urlObj.toString();
    }

    // Otherwise, just return the upgraded https URL
    return upgraded;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

  if (!dateMatch) return 'N/A';

  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';

  // Days in each month (non-leap year)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  let maxDay = daysInMonth[month - 1];

  // Handle leap years for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    // Leap year if divisible by 4, except centuries not divisible by 400
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (isLeap) {
      maxDay = 29;
    }
  }

  if (day > maxDay) return 'N/A';

  return year;
}
