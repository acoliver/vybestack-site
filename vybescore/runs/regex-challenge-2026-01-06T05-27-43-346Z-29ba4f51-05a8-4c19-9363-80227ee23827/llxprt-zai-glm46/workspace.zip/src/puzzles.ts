/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Build regex to match words starting with the prefix
  // Word boundaries at start and end, and we want the full word
  const wordRegex = new RegExp('\\b(' + escapedPrefix + '\\w+)\\b', 'gi');

  const matches = text.match(wordRegex) || [];

  // Filter out exceptions (case-insensitive)
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match digit + token combination
  const regex = new RegExp('\\d' + escapedToken, 'g');

  const matches = text.match(regex) || [];

  // Filter to ensure we're not matching at the very start of the string
  // We need to check if the match position is > 0
  if (matches.length === 0) return [];

  // Use exec to find the actual positions
  const results: string[] = [];
  let match;
  const posRegex = new RegExp('\\d' + escapedToken, 'g');

  while ((match = posRegex.exec(text)) !== null) {
    if (match.index > 0) {
      results.push(match[0]);
    }
  }

  return results;
}

/**
 * Validate passwords according to security policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences (e.g., abab).
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length 10
  if (value.length < 10) return false;

  // No whitespace
  if (/\s/.test(value)) return false;

  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;

  // At least one lowercase letter
  if (!/[a-z]/.test(value)) return false;

  // At least one digit
  if (!/\d/.test(value)) return false;

  // At least one symbol (non-alphanumeric, not whitespace)
  const symbolPattern = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/;
  if (!symbolPattern.test(value)) return false;

  // No immediate repeated sequences (like abab, abcabc)
  // Check for patterns where a 2-4 character sequence repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const sequence = value.slice(i, i + len);
      const nextSequence = value.slice(i + len, i + len * 2);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  const trimmed = value.trim();

  // First, exclude pure IPv4 addresses (e.g., 192.168.1.1)
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(trimmed)) return false;

  // IPv6 patterns:
  // - Can have :: (compressed zeros) - can be at start, end, or middle (but only once)
  // - Has colons separating hex groups
  // - Each group is 1-4 hex digits
  // - Can have zone identifier like %eth0 (link-local)

  // Count occurrences of :: - valid IPv6 should have at most one
  const doubleColonCount = (trimmed.match(/::/g) || []).length;
  if (doubleColonCount > 1) return false;

  // Check for :: which indicates compressed IPv6
  if (trimmed.includes('::')) {
    // Must look like IPv6: has colons with hex groups
    // Allow zone identifier (% followed by text)
    const withoutZone = trimmed.split('%')[0];
    // At minimum, should have : and some hex digits
    return /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{0,4}/.test(withoutZone) || /^::[0-9a-fA-F]{1,4}$/.test(withoutZone) || /^[0-9a-fA-F]{1,4}:$/.test(withoutZone);
  }

  // Full IPv6: 8 groups of 1-4 hex digits separated by 7 colons
  // Strip zone identifier if present
  const withoutZone = trimmed.split('%')[0];
  const ipv6FullPattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;

  return ipv6FullPattern.test(withoutZone);
}
