// Challenge data with predefined questions and answers
const challenges = [
    {
        description: "Match hexadecimal color codes. Include both uppercase and lowercase letters.",
        explanation: "Hexadecimal color codes start with # followed by exactly 3 or 6 hexadecimal digits (0-9, a-f, A-F).",
        examples: ["#FFF", "#ff00aa", "#1a2b3c", "#123"],
        invalidExamples: ["#GGG", "#12", "#12345", "123456"],
        pattern: "^#[0-9a-fA-F]{3}(?:[0-9a-fA-F]{3})?$"
    },
    {
        description: "Match valid email addresses. Only allow letters, numbers, dots, hyphens in username part.",
        explanation: "Email addresses consist of a local part (username) and a domain part separated by @. The local part can contain letters, numbers, dots, and hyphens.",
        examples: ["user@example.com", "test.email@domain.co.uk", "user-name@my.domain.com"],
        invalidExamples: ["user@@example.com", "@example.com", "user@.com"],
        pattern: "^[a-zA-Z0-9.-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$"
    },
    {
        description: "Match dates in YYYY-MM-DD format. Validate actual date ranges.",
        explanation: "Dates in ISO format with year (1900-2099), month (01-12), and day (01-31) separated by hyphens.",
        examples: ["2023-05-15", "1999-12-31", "2024-02-29"],
        invalidExamples: ["2023-13-15", "2023-00-10", "2023-05-32"],
        pattern: "^(19|20)\\d{2}-(0[1-9]|1[0-2])-(0[1-9]|[12]\\d{3}|3[01])$"
    },
    {
        description: "Match IPv4 addresses. Validate octet ranges (0-255).",
        explanation: "IPv4 addresses consist of four octets separated by dots, with each octet in the range 0-255.",
        examples: ["192.168.1.1", "10.0.0.1", "255.255.255.255"],
        invalidExamples: ["256.1.1.1", "192.168.1.1.1", "192.168.1"],
        pattern: "^([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])(?:\\.([0-9]|[1-9][0-9]|1[0-9][0-9]|2[0-4][0-9]|25[0-5])){3}$"
    },
    {
        description: "Match strong passwords. Minimum 8 chars, containing uppercase, lowercase, numbers, and special chars.",
        explanation: "Strong passwords require at least 8 characters and include at least one uppercase letter, one lowercase letter, one number, and one special character.",
        examples: ["StrongP@ss", "MyP@ssw0rd!2", "C0mpl3x_pass"],
        invalidExamples: ["weakpass", "12345678", "PASSWORD", "pass_word"],
        pattern: "^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[!@#$%^&*()_+\\-=\\[\\]{};':\"\\\\|,.<>\\/?]).{8,}$"
    },
    {
        description: "Match URLs starting with http:// or https://.",
        explanation: "URLs must start with http:// or https:// followed by a domain name and optional path components.",
        examples: ["https://example.com", "http://sub.domain.org/path", "https://site.com/page?param=value"],
        invalidExamples: ["ftp://example.com", "example.com", "www.example.com"],
        pattern: "^https?://[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}(?:/.*)?$"
    }
];

// Game state
let currentChallengeIndex = 0;
let userPattern = "";
let matchResults = { valid: [], invalid: [] };

// DOM elements
const challengeDescEl = document.getElementById('challenge-description');
const examplesListEl = document.getElementById('valid-examples');
const invalidExamplesListEl = document.getElementById('invalid-examples');
const patternInputEl = document.getElementById('pattern-input');
const testInputEl = document.getElementById('test-input');
const matchResultsEl = document.getElementById('match-results');
const currentScoreEl = document.getElementById('current-score');
const totalChallengesEl = document.getElementById('total-challenges');
const feedbackEl = document.getElementById('feedback');
const hintsEl = document.getElementById('hints');
const solutionEl = document.getElementById('solution');
const solutionPatternEl = document.getElementById('solution-pattern');
const checkAnswerBtn = document.getElementById('check-answer');
const showHintBtn = document.getElementById('show-hint');
const showSolutionBtn = document.getElementById('show-solution');
const nextChallengeBtn = document.getElementById('next-challenge');
const resetGameBtn = document.getElementById('reset-game');

// Initialize game
function initGame() {
    currentChallengeIndex = 0;
    userPattern = "";
    matchResults = { valid: [], invalid: [] };
    
    totalChallengesEl.textContent = challenges.length;
    loadChallenge(0);
    
    // Setup event listeners
    patternInputEl.addEventListener('input', handlePatternChange);
    testInputEl.addEventListener('input', handleTestInput);
    checkAnswerBtn.addEventListener('click', checkAnswer);
    showHintBtn.addEventListener('click', showHint);
    showSolutionBtn.addEventListener('click', showSolution);
    nextChallengeBtn.addEventListener('click', nextChallenge);
    resetGameBtn.addEventListener('click', resetGame);
    
    // Start with the first challenge
    updateScore();
}

// Load a challenge by index
function loadChallenge(index) {
    if (index < 0 || index >= challenges.length) return;
    
    const challenge = challenges[index];
    currentChallengeIndex = index;
    
    // Update UI with challenge data
    challengeDescEl.textContent = challenge.description;
    
    // Clear and populate examples
    examplesListEl.innerHTML = '';
    challenge.examples.forEach(example => {
        const li = document.createElement('li');
        li.textContent = example;
        li.className = 'valid-example';
        examplesListEl.appendChild(li);
    });
    
    // Clear and populate invalid examples
    invalidExamplesListEl.innerHTML = '';
    challenge.invalidExamples.forEach(example => {
        const li = document.createElement('li');
        li.textContent = example;
        li.className = 'invalid-example';
        invalidExamplesListEl.appendChild(li);
    });
    
    // Reset inputs and results
    patternInputEl.value = "";
    testInputEl.value = "";
    matchResultsEl.innerHTML = "";
    feedbackEl.textContent = "";
    hintsEl.style.display = 'none';
    solutionEl.style.display = 'none';
    hintsEl.textContent = challenge.explanation;
    
    // Reset buttons
    checkAnswerBtn.disabled = false;
    showHintBtn.style.display = 'inline-block';
    showSolutionBtn.style.display = 'inline-block';
    nextChallengeBtn.style.display = 'none';
    
    updateScore();
}

// Handle pattern input change
function handlePatternChange() {
    userPattern = patternInputEl.value;
    testPattern();
}

// Handle test input change
function handleTestInput() {
    const testValue = testInputEl.value;
    if (!userPattern || !testValue) return;
    
    testPattern();
}

// Test the current pattern against examples
function testPattern() {
    if (!userPattern) {
        matchResultsEl.innerHTML = '<p style="margin-top: 10px; color: #7f8c8d;">Enter a pattern to test.</p>';
        return;
    }
    
    const challenge = challenges[currentChallengeIndex];
    let regex;
    
    try {
        regex = new RegExp(userPattern);
    } catch (error) {
        matchResultsEl.innerHTML = `<p style="margin-top: 10px; color: #e74c3c;">Invalid regex: ${error.message}</p>`;
        return;
    }
    
    // Test valid examples
    const validResults = challenge.examples.map(test => {
        const matches = regex.test(test);
        return { test, matches, valid: true };
    });
    
    // Test invalid examples
    const invalidResults = challenge.invalidExamples.map(test => {
        const matches = regex.test(test);
        return { test, matches, valid: false };
    });
    
    // Display results
    displayMatchResults([...validResults, ...invalidResults]);
}

// Display match results with color coding
function displayMatchResults(results) {
    matchResultsEl.innerHTML = '';
    
    if (results.length === 0) {
        matchResultsEl.innerHTML = '<p style="margin-top: 10px; color: #7f8c8d;">Enter a pattern to test.</p>';
        return;
    }
    
    results.forEach(result => {
        const div = document.createElement('div');
        div.className = 'test-result';
        
        if (result.valid && result.matches) {
            div.classList.add('valid-success');
        } else if (!result.valid && !result.matches) {
            div.classList.add('invalid-success');
        } else {
            div.classList.add('failure');
        }
        
        div.innerHTML = `
            <span class="test-text">${escapeHtml(result.test)}</span>
            <span class="status">${result.matches ? 'MATCH' : 'NO MATCH'}</span>
            <span class="expected">${result.valid ? 'SHOULD MATCH' : 'SHOULD NOT MATCH'}</span>
        `;
        
        matchResultsEl.appendChild(div);
    });
    
    // Update match results for answer checking
    matchResults.valid = results.filter(r => r.valid && r.matches).length;
    matchResults.invalid = results.filter(r => !r.valid && !r.matches).length;
}

// Escape HTML to prevent XSS
function escapeHtml(str) {
    return str.replace(/[&<>"']/g, function(match) {
        return {
            '&': '&amp;',
            '<': '&lt;',
            '>': '&gt;',
            '"': '&quot;',
            "'": '&#39;'
        }[match];
    });
}

// Check if the user's answer is correct
function checkAnswer() {
    if (!userPattern) {
        feedbackEl.textContent = "Please enter a regex pattern first.";
        feedbackEl.className = 'error';
        return;
    }
    
    const challenge = challenges[currentChallengeIndex];
    let regex;
    
    try {
        regex = new RegExp(userPattern);
    } catch (error) {
        feedbackEl.textContent = `Invalid regex: ${error.message}`;
        feedbackEl.className = 'error';
        return;
    }
    
    // Test valid examples
    const validResults = challenge.examples.every(example => regex.test(example));
    
    // Test invalid examples
    const invalidResults = challenge.invalidExamples.every(example => !regex.test(example));
    
    if (validResults && invalidResults) {
        feedbackEl.textContent = "Excellent! Your pattern works correctly!";
        feedbackEl.className = 'success';
        checkAnswerBtn.disabled = true;
        showHintBtn.style.display = 'none';
        showSolutionBtn.style.display = 'none';
        nextChallengeBtn.style.display = 'inline-block';
    } else {
        feedbackEl.textContent = "Not quite right. Keep trying! Check the results above.";
        feedbackEl.className = 'error';
    }
}

// Show a hint
function showHint() {
    hintsEl.style.display = 'block';
    showHintBtn.style.display = 'none';
}

// Show the solution
function showSolution() {
    const challenge = challenges[currentChallengeIndex];
    solutionPatternEl.textContent = challenge.pattern;
    solutionEl.style.display = 'block';
    showSolutionBtn.style.display = 'none';
}

// Move to the next challenge
function nextChallenge() {
    if (currentChallengeIndex < challenges.length - 1) {
        loadChallenge(currentChallengeIndex + 1);
    } else {
        // Game completed
        challengeDescEl.textContent = "Congratulations! You've completed all challenges!";
        examplesListEl.innerHTML = '';
        invalidExamplesListEl.innerHTML = '';
        patternInputEl.style.display = 'none';
        testInputEl.style.display = 'none';
        matchResultsEl.innerHTML = '';
        feedbackEl.textContent = "Well done! You've mastered all the regex challenges.";
        feedbackEl.className = 'success';
        checkAnswerBtn.style.display = 'none';
        showHintBtn.style.display = 'none';
        showSolutionBtn.style.display = 'none';
        nextChallengeBtn.style.display = 'none';
        hintsEl.style.display = 'none';
        solutionEl.style.display = 'none';
        
        updateScore();
    }
}

// Reset the game
function resetGame() {
    patternInputEl.style.display = 'block';
    testInputEl.style.display = 'block';
    checkAnswerBtn.style.display = 'inline-block';
    
    // Reset all completed challenges' buttons
    for (let i = 0; i < challenges.length; i++) {
        const button = document.getElementById(`challenge-${i}-complete`);
        if (button) {
            button.style.display = 'none';
            button.disabled = false;
        }
    }
    
    initGame();
}

// Update the score display
function updateScore() {
    currentScoreEl.textContent = currentChallengeIndex + 1;
}

// Initialize the game when the page loads
document.addEventListener('DOMContentLoaded', initGame);