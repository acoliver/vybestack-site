import { CLIParseResult, Format } from '../types.js';

export function parseArguments(argv: string[]): CLIParseResult {
  if (argv.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = argv[2];
  if (!inputFile) {
    throw new Error('Input file path is required');
  }

  let format: Format = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      const formatValue = argv[++i];
      if (!formatValue) {
        throw new Error('--format requires a value');
      }
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      outputPath = argv[++i];
      if (!outputPath) {
        throw new Error('--output requires a value');
      }
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}