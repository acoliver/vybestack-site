#!/usr/bin/env node

import { parseArguments } from '../utils/args.js';
import { loadAndValidateReportData } from '../utils/validation.js';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';
import { writeFileSync } from 'node:fs';

function main(): void {
  try {
    const args = parseArguments(process.argv);
    const data = loadAndValidateReportData(args.inputFile);

    let formatter: MarkdownFormatter | TextFormatter;

    switch (args.format) {
      case 'markdown':
        formatter = new MarkdownFormatter();
        break;
      case 'text':
        formatter = new TextFormatter();
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }

    const output = formatter.render(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      process.stderr.write(`Error: ${error.message}\n`);
      process.exit(1);
    } else {
      process.stderr.write('Unknown error occurred\n');
      process.exit(1);
    }
  }
}

main();