import { ReportData, RenderOptions } from './types.js';

export interface Formatter {
  render(data: ReportData, options: RenderOptions): string;
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}