export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with proper rules:
 * - Allows typical addresses like name+tag@example.co.uk
 * - Rejects double dots, trailing dots, domains with underscores
 * - Rejects other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that covers most valid cases while rejecting invalid ones
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional validation rules
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Reject domain starting or ending with hyphen
  if (domainPart && (domainPart.startsWith('-') || domainPart.endsWith('-') || domainPart.includes('-.'))) {
    return false;
  }
  
  // Reject local part starting or ending with dot
  const localPart = value.split('@')[0];
  if (localPart && (localPart.startsWith('.') || localPart.endsWith('.'))) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers:
 * - Supports (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallows impossible area codes (leading 0/1)
 * - Disallows too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (with country code: 11 digits, without: 10 digits)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // Extract area code (after removing +1 if present)
  let areaCode: string;
  if (digits.length === 11) {
    // Must start with 1 for US country code
    if (!digits.startsWith('1')) {
      return false;
    }
    areaCode = digits.substring(1, 4);
  } else {
    areaCode = digits.substring(0, 3);
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate the pattern with separators
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers:
 * - Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must start with 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const clean = value.replace(/[\s-]/g, '');
  
  // Regex to match Argentine phone numbers
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = clean.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const countryCode = clean.startsWith('+54');
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // When country code is omitted, must start with 0 (trunk prefix)
  if (!countryCode && !areaCode.startsWith('0')) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Check that the input contains only valid separators
  const invalidChars = value.match(/[^0-9+\s-]/);
  if (invalidChars) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names:
 * - Permits unicode letters, accents, apostrophes, hyphens, spaces
 * - Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow: unicode letters, accents, apostrophes, hyphens, spaces
  // Reject: digits, symbols (except allowed ones)
  const nameRegex = /^[\p{L}\u0300-\u036F]['\-\s]*[\p{L}\u0300-\u036F'\-\s]*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Cannot start or end with hyphen, apostrophe, or space
  if (value.startsWith("'") || value.startsWith('-') || value.startsWith(' ') ||
      value.endsWith("'") || value.endsWith('-') || value.endsWith(' ')) {
    return false;
  }
  
  // Cannot have consecutive spaces, hyphens, or apostrophes
  if (value.includes('  ') || value.includes('--') || value.includes("''")) {
    return false;
  }
  
  // Cannot contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers:
 * - Accepts Visa/Mastercard/AmEx prefixes and lengths
 * - Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const clean = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(clean)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[0-9]{3})\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any accepted card type
  if (!visaRegex.test(clean) && !mastercardRegex.test(clean) && !amexRegex.test(clean)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(clean);
}

/**
 * Helper function for Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
