/**
 * Capitalizes the first character of each sentence:
 * - Capitalizes after .?! 
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Insert space after sentence endings if missing (except for abbreviation cases)
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Common abbreviations to avoid false sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs', 'US', 'UK'];
  const abbrevPattern = new RegExp(`\b(${abbreviations.join('|')})\.`, 'gi');
  
  // Protect abbreviations by temporarily replacing them
  const abbreviationPlaceholders: string[] = [];
  result = result.replace(abbrevPattern, (match) => {
    const placeholder = `__ABBR_${abbreviationPlaceholders.length}__`;
    abbreviationPlaceholders.push(match);
    return placeholder;
  });
  
  // Capitalize after sentence endings
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Capitalize the very first character
  result = result.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  // Restore abbreviations
  abbreviationPlaceholders.forEach((abbr, index) => {
    result = result.replace(`__ABBR_${index}__`, abbr);
  });
  
  // Trim leading/trailing spaces
  return result.trim();
}

/**
 * Extracts URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern matching http/https/ftp protocols and www domains
  const urlRegex = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation (.,;!?) but keep parentheses if balanced
  return matches.map(url => {
    // Remove trailing punctuation
    const cleanUrl = url.replace(/[.,;!?]+$/g, '');
    
    // Handle trailing parentheses - remove unmatched closing parens
    let balancedUrl = cleanUrl;
    const openCount = (cleanUrl.match(/\(/g) || []).length;
    let closeCount = (cleanUrl.match(/\)/g) || []).length;
    
    // Remove excess closing parentheses
    while (closeCount > openCount && balancedUrl.endsWith(')')) {
      balancedUrl = balancedUrl.slice(0, -1);
      closeCount--;
    }
    
    return balancedUrl;
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not if it's already https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - But still upgrade scheme to https://
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/\bhttps?:\/\/([^\/]+)(\/[^\s]*)/gi, (match, host, path) => {
    // Always upgrade to HTTPS
    const scheme = 'https://';
    
    // Check if we should skip host rewrite
    // Skip if contains cgi-bin, query strings, or legacy extensions
    const skipRewrite = /(?:\?(?:[^?]*&?)*=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path + host);
    
    if (!skipRewrite && path && path.startsWith('/docs/')) {
      // Rewrite to docs.example.com for docs paths
      // Always use docs.example.com as specified in requirements
      return scheme + 'docs.example.com' + path;
    }
    
    // Just upgrade the scheme
    return scheme + host + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (simplified, not accounting for leap years in detail)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // February as 29 for simplicity
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Check for reasonable year range (optional, but good practice)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }
  
  return year;
}
