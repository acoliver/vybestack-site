/**
 * Finds words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern manually - use regex literal approach
  // Split text by spaces and manually check for prefix
  const words = text.split(/\s+/);
  const matches = words.filter(word => {
    return word.toLowerCase().startsWith(prefix.toLowerCase());
  });
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  // Remove duplicates and return
  return Array.from(new Set(result));
}

/**
 * Returns occurrences where token appears after a digit and not at string start
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use string approach - find occurrences of token preceded by digit
  const results: string[] = [];
  const textLength = text.length;
  const tokenLength = token.length;
  
  for (let i = 0; i <= textLength - tokenLength; i++) {
    const substring = text.substring(i, i + tokenLength);
    if (substring === token) {
      // Check if preceded by digit and not at start
      if (i > 0 && /\d/.test(text[i - 1])) {
        return [text[i - 1] + token];
      }
    }
  }
  
  return results;
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 1212, etc.)
  for (let i = 0; i < value.length - 3; i++) {
    const twoChars = value.substring(i, i + 2);
    const nextTwoChars = value.substring(i + 2, i + 4);
    if (twoChars === nextTwoChars) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  // Must have at least one colon, and not be a plain IPv4
  if (value.indexOf(':') === -1) {
    return false;
  }
  
  // Check if it's plain IPv4
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Basic IPv6 patterns
  const ipv6Patterns = [
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/, // Full IPv6
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/, // Ending with ::
    /:(?::[0-9a-fA-F]{1,4}){1,7}/, // Starting with ::
    /::/, // Shorthand
    /[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}/, // Mid-range ::
    /fe80:[0-9a-fA-F:]*%[0-9a-zA-Z]+/, // Link-local
  ];
  
  // Check if any IPv6 pattern matches
  return ipv6Patterns.some(pattern => pattern.test(value));
}