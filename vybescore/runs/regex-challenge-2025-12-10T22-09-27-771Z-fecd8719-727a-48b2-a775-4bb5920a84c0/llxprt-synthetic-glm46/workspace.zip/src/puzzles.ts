/**
 * Find words beginning with the specified prefix, excluding any words in the exceptions list.
 * Returns an array of matched words without duplicates.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  const matches = text.match(wordRegex) || [];
  
  // Convert to lowercase for case-insensitive comparison and filtering
  const prefixLower = prefix.toLowerCase();
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  
  // Filter out exceptions and duplicates
  const result = matches
    .map(word => word)
    .filter(word => {
      const wordLower = word.toLowerCase();
      // Must start with the prefix (case-insensitive) and not be in exceptions
      return wordLower.startsWith(prefixLower) && !exceptionsLower.includes(wordLower);
    })
    // Remove duplicates while preserving original case
    .filter((word, index, self) => self.indexOf(word) === index);
  
  return result;
}

/**
 * Find occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds to find the pattern.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Create a regex to find digits followed by the token
  // Use a lookbehind to ensure we're not at the start of the string
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matched = [];
  let match = tokenRegex.exec(text);
  while (match) {
    matched.push(match[0]);
    match = tokenRegex.exec(text);
  }
  
  return matched;
}

/**
 * Validate password strength with these requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (like 'abab')
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\w\s]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for repeated patterns (like abab, abcabc)
  // This is a simplified check - it looks for any 2+ character sequence repeated immediately
  const repeatedPatternPattern = /(.{2,})\1{1,}/;
  
  // Further check if the repeated pattern is a simple alternation (like abab)
  const parts = value.match(repeatedPatternPattern);
  if (parts) {
    const pattern = parts[1];
    const pattern = parts[1];
    // Check if the pattern is repeated immediately without much separation
    if (new RegExp(`${pattern}[a-zA-Z0-9\s]{0,4}${pattern}`).test(value)) {
      // Additional check for alternation patterns
      if (pattern[0] !== pattern[1]) {
        return false;
      }
    }
    
    // Check for alternating patterns like abab
    if (pattern.length >= 2 && 
        new RegExp(`${pattern[0]}${pattern[1]}${pattern[0]}${pattern[1]}`).test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while ensuring IPv4 addresses do not trigger.
 * Returns true if IPv6 is detected, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches:
  // - Full IPv6 notation with colons (xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx)
  // - Shorthand notation with :: (compressed zeros)
  // - IPv4-mapped IPv6 addresses
  // Does NOT match IPv4 addresses alone
  
  // First check if this might be an IPv4 address - if so, reject it
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Regex.test(value.trim())) {
    return false;
  }
  
  // IPv6 regex pattern
  const ipv6Regex = new RegExp([
    // Full IPv6 (8 groups of 1-4 hex digits)
    `^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$`,
    // IPv6 with :: (1-7 groups, then ::, then 0-7 groups)
    `^(?:[0-9a-fA-F]{1,4}:){1,7}:(?::[0-9a-fA-F]{1,4}){1,7}$`,
    // IPv6 with :: at start
    `^::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}$`,
    // IPv6 with embedded IPv4
    `^(?:[0-9a-fA-F]{1,4}:){6}:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$`
  ].join('|'));
  
  return ipv6Regex.test(value.trim());
  
  return ipv6Regex.test(value.trim());
}