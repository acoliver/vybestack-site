/**
 * Capitalize the first character of each sentence after sentence-ending punctuation (.?!).
 * Ensures exactly one space between sentences, collapses extra spaces, and tries to preserve abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // Normalize multiple spaces to single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Add space after punctuation if missing
  result = result.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  // Split by sentence delimiters and capitalize first letters
  const sentences = result.split(/([.!?]\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    // Every other item should be a sentence content (odd indices are delimiters)
    const sentence = sentences[i];
    if (sentence && sentence.trim().length > 0) {
      sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
  }
  
  // Rejoin and cleanup extra spaces
  result = sentences.join('');
  
  // Add single space after delimiters
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  return result.trim();
}

/**
 * Extract all URLs from the given text without trailing punctuation.
 * Returns an array of URL strings found in the text.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern that matches:
  // - Protocol (http://, https://, ftp://, etc.) or protocol-relative (//)
  // - Domain with subdomains
  // - Optional port
  // - Optional path, query, and fragment
  const urlRegex = /(?:https?:|ftp:)?\/\/(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?::\d+)?(?:\/[^\s]*)?/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)\]]+$/, ''));
}

/**
 * Replace all http:// URLs with https:// while leaving already secure URLs untouched.
 * Returns the modified text with all HTTP URLs upgraded to HTTPS.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Find all http:// URLs and replace with https://
  // This regex matches http:// but not https://
  const httpRegex = /http:\/\//g;
  
  return text.replace(httpRegex, 'https://');
}

/**
 * Rewrite URLs according to these rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for paths containing cgi-bin, query strings, or certain extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // First, upgrade all http to https
  let result = enforceHttps(text);
  
  // Pattern to match URLs with example.com domain
  const exampleUrlRegex = /(https?:\/\/)(example\.com)(\/[^\s]*)/g;
  
  // List of patterns that should prevent the host rewrite
  const noRewritePatterns = [
    /\/cgi-bin\//,
    /[?&=]/,
    /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?&\s]|$)/
  ];
  
  result = result.replace(exampleUrlRegex, (match, protocol, host, path) => {
    // Upgrade to HTTPS first
    protocol = 'https://';
    
    // Check if we should skip host rewrite
    const shouldSkipRewrite = noRewritePatterns.some(pattern => pattern.test(path));
    
    if (!shouldSkipRewrite && path.startsWith('/docs/')) {
      // Rewrite host to docs.example.com
      host = 'docs.example.com';
    }
    
    return protocol + host + path;
  });
  
  return result;
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (isNaN(month) || month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const maxDay = getMaxDayForMonth(month, year);
  if (isNaN(day) || day < 1 || day > maxDay) return 'N/A';
  
  // Validate year (between 1000 and 9999)
  if (isNaN(year) || year < 1000 || year > 9999) return 'N/A';
  
  return yearStr;
}

/**
 * Helper function to get the maximum day for a given month and year (handles leap years).
 */
function getMaxDayForMonth(month: number, year: number): number {
  if (month === 1 || month === 3 || month === 5 || month === 7 || month === 8 || month === 10 || month === 12) {
    return 31;
  } else if (month === 4 || month === 6 || month === 9 || month === 11) {
    return 30;
  } else if (month === 2) {
    // Check for leap year
    return (year % 400 === 0 || (year % 100 !== 0 && year % 4 === 0)) ? 29 : 28;
  } else {
    return 0;
  }
}