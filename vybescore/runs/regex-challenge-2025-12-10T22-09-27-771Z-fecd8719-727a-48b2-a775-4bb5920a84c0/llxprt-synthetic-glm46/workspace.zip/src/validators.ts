export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper RFC 5322 rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Basic local part: letters, digits, plus, hyphens, dots, apostrophes
  // But no consecutive dots, no starting/ending dots
  // Domain part: letters, digits, hyphens, dots, no underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific restrictions
  // No consecutive dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Check local part doesn't start or end with dot
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain cannot have underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers in various formats:
 * (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove common separators and whitespace
  const cleaned = value.replace(/[\s\-\(\)]/g, '');
  
  // If options are provided, we could handle extensions here in the future
  // Currently unused but kept for API compatibility
  
  // Remove optional +1 country code
  const withoutCountryCode = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;
  
  // Check if we have exactly 10 digits (standard US number)
  if (!/^[2-9]\d{9}$/.test(withoutCountryCode)) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = withoutCountryCode.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers supporting:
 * Landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, 
 * +54 341 123 4567, 0341 4234567
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number (after the area code) must contain 6-8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep the structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern
  // Group 1: Optional +54 country code
  // Group 2: Optional 0 trunk prefix
  // Group 3: Optional 9 mobile indicator
  // Group 4: Area code (2-4 digits, leading 1-9)
  // Group 5: Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const countryCode = match[1];
  const trunkPrefix = match[2];
  // const mobileIndicator = match[3]; // captured but not used
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // If country code is omitted, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Validate area code length
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate person names allowing:
 * Unicode letters, accents, apostrophes, hyphens, spaces
 * Reject digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Check for empty input
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Names with unicode letters (including accents), apostrophes, hyphens, and spaces
  const validNameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!validNameRegex.test(value)) {
    return false;
  }
  
  // Reject names starting or ending with hyphen, apostrophe, or space
  if (/^[ '\-]|['\-]$/u.test(value)) {
    return false;
  }
  
  // Limit the number of special characters to prevent names like "X Æ A-12"
  const specialCharsCount = (value.match(/['\-]/g) || []).length;
  if (specialCharsCount > 2) {
    return false;
  }
  
  // Check for name with only special characters
  if (/^['\-\s]+$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for major brands:
 * Visa: starts with 4, length 13 or 16
 * Mastercard: starts with 51-55 or 2221-2720, length 16
 * American Express: starts with 34 or 37, length 15
 * Also runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove common separators
  const cleaned = value.replace(/[\s\-]/g, '');
  const cleaned = value.replace(/[\s\-]/g, '');
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
  if (!/^\d+$/.test(cleaned)) {
  }
  
  // Check for valid prefixes and lengths
  const isVisa = /^4(\d{12}|\d{15})$/.test(cleaned);
  const isMastercard = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|4[0-1]\d|5[0-9]\d|72[0-9])\d{12})$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn checksum on a numeric string
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process the number from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    // Double every other digit from the right
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9; // Equivalent to summing the two digits
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;




}
