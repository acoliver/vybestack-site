/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  // Use word boundaries to match whole words
  const prefixedWordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(prefixedWordRegex);
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches
    .filter(word => !exceptionsSet.has(word.toLowerCase()))
    .filter((word, index, array) => array.indexOf(word) === index); // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a lookbehind to match cases where the token is preceded by a digit
  // and capture the digit along with the token
  const embeddedTokenRegex = new RegExp(`(?<!^)(\\d)${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  while ((match = embeddedTokenRegex.exec(text)) !== null) {
    matches.push(match[0]); // Include the digit and the token
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc)
  for (let i = 0; i < value.length / 2; i++) {
    const firstHalf = value.substring(0, value.length / 2);
    const secondHalf = value.substring(value.length / 2);
    
    if (firstHalf === secondHalf) {
      return false;
    }
  }
  
  // Check for pattern like ABAB (same character repeated at intervals of 2)
  for (let i = 0; i < value.length - 3; i++) {
    if (value[i] === value[i+2]) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // IPv6 patterns to match:
  // 1. Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. Shorthand with :: (can appear once)
  // 3. Mixed IPv4/IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:d.d.d.d
  
  // IPv6 regular expression to detect valid IPv6 addresses
  const ipv6Regex = /(?:^|(?<=\s))(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|(?:[0-9a-fA-F]{1,4}:){6}:(?:\d{1,3}\.){3}\d{1,3}|(?:[0-9a-fA-F]{1,4}:){1,5}:(?:\d{1,3}\.){3}\d{1,3}|[0-9a-fA-F]{1,4}::(?:\d{1,3}\.){3}\d{1,3}|::(?:\d{1,3}\.){3}\d{1,3}(?=$|\s)/;
  
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Check if it contains IPv6 pattern
  return ipv6Regex.test(value) && !ipv4Regex.test(value);
}