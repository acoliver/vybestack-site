export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Regular expression for email validation
  // Local part: allows letters, digits, +, dots (not consecutive or at start/end)
  // Domain part: allows letters, digits, hyphens (not at start/end), and subdomains
  const emailRegex = /^[a-zA-Z0-9]+(?:[._+-][a-zA-Z0-9]+)*@[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*(?:\.[a-zA-Z0-9]+(?:-[a-zA-Z0-9]+)*)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject domains with underscores
  if (value.includes('_')) {
    return false;
  }
  
  // Reject double dots in either local or domain part
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if it's at least 10 digits (minimum for US phone)
  if (digits.length < 10) {
    return false;
  }
  
  // Check if it has a valid 10-digit format or 11 digits with leading +1
  if (digits.length === 10) {
    // Validate area code (first 3 digits) - can't start with 0 or 1
    const areaCode = digits.substring(0, 3);
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
    return true;
  } else if (digits.length === 11 && digits[0] === '1') {
    // Has country code 1, validate area code (digits 1-3) - can't start with 0 or 1
    const areaCode = digits.substring(1, 4);
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalizedPhone = value.replace(/[- ]/g, '');
  
  // Argentine phone regex
  // +54 9 11 1234 5678 (mobile)
  // 011 1234 5678 (Buenos Aires landline without country code)
  // +54 341 123 4567 (landline with country code)
  // 0341 4234567 (landline with trunk prefix)
  const argPhoneRegex = /^(?:\+54)?(?:9)?([1-9]\d{1,3})(\d{6,8})$|^0([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalizedPhone.match(argPhoneRegex);
  if (!match) {
    return false;
  }
  
  // Extract area code and subscriber number based on which pattern matched
  let areaCode: string;
  let subscriberNumber: string;
  
  if (match[1] && match[2]) {
    // Pattern with optional country code and optional mobile indicator
    areaCode = match[1];
    subscriberNumber = match[2];
  } else if (match[3] && match[4]) {
    // Pattern with trunk prefix
    areaCode = match[3];
    subscriberNumber = match[4];
  } else {
    return false;
  }
  
  // Area code must be 2-4 digits and start with 1-9 (already validated by regex)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits (already validated by regex)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for empty string
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that look like "X Æ A-12" (contains digits or weird symbols)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanedValue = value.replace(/[- ]/g, '');
  
  // Validate length (13-19 digits for credit cards)
  if (!/^\d{13,19}$/.test(cleanedValue)) {
    return false;
  }
  
  // Validate prefixes for major card types
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // Amex: starts with 34 or 37, length 15
  
  // Visa
  if (cleanedValue.startsWith('4') && (cleanedValue.length === 13 || cleanedValue.length === 16)) {
    return runLuhnCheck(cleanedValue);
  }
  
  // Mastercard
  if (cleanedValue.length === 16) {
    const firstTwo = parseInt(cleanedValue.substring(0, 2), 10);
    const firstFour = parseInt(cleanedValue.substring(0, 4), 10);
    
    if ((firstTwo >= 51 && firstTwo <= 55) || (firstFour >= 2221 && firstFour <= 2720)) {
      return runLuhnCheck(cleanedValue);
    }
  }
  
  // Amex
  if ((cleanedValue.startsWith('34') || cleanedValue.startsWith('37')) && cleanedValue.length === 15) {
    return runLuhnCheck(cleanedValue);
  }
  
  return false;
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
