/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // Common abbreviations that should not end a sentence
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Mt', 'vs', 'etc', 'e.g', 'i.e', 'al', 'ca', 'approx', 'est', 'Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  // First, ensure exactly one space after sentence-ending punctuation
  let result = text.replace(/([.?!])([^\s])/, '$1 $2');
  
  // Split into sentences, but be careful with abbreviations
  const sentences = result.split(/(?<=[.?!])\s+/);
  
  const capitalizedSentences = sentences.map((sentence, index) => {
    if (!sentence) return sentence;
    
    // If this is not the first sentence, check if the previous sentence might have ended with an abbreviation
    if (index > 0) {
      const prevSentence = sentences[index - 1];
      const prevWords = prevSentence.split(' ');
      const lastWord = prevWords[prevWords.length - 1].replace(/[.!?]$/, '');
      
      // If the last word of the previous sentence is an abbreviation, don't capitalize this sentence
      if (abbreviations.some(abbr => lastWord.toLowerCase().includes(abbr.toLowerCase()))) {
        return sentence;
      }
    }
    
    // Capitalize the first letter
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  // Join the sentences back with a single space
  result = capitalizedSentences.join(' ');
  
  // Collapse multiple spaces to a single space
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // Regular expression to match URLs
  // Includes protocol (http, https), subdomains, domain extensions, paths, query strings, anchors
  const urlRegex = /(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex);
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?'"()\[\]{}]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https:// using regex with word boundary to avoid partial matches
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // Match all http URLs with example.com domain
  return text.replace(/http:\/\/example\.com(\/[^\s]*)?/g, (match, path) => {
    // Default result - just upgrade to HTTPS
    let result = `https://example.com${path || ''}`;
    
    if (path) {
      // Check if the path contains any of the excluded patterns
      const hasExcludePattern = /\/cgi-bin|[?&=]|(\/.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      // If path starts with /docs/ and doesn't have exclude patterns, rewrite the host
      if (path.startsWith('/docs/') && !hasExcludePattern) {
        result = `https://docs.example.com${path}`;
      } else {
        // Otherwise just upgrade the scheme to HTTPS
        result = `https://example.com${path}`;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Regular expression to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check leap years for February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  };
  
  // Adjust for leap year
  if (month === 2 && isLeapYear(year)) {
    daysInMonth[2] = 29;
  }
  
  // Validate day against month
  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
