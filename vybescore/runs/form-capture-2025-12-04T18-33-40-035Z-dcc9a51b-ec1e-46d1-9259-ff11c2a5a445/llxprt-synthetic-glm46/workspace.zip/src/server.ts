import express from 'express';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Initialize app
const app = express();

// Configuration
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = join(__dirname.replace('dist', ''), 'data/submissions.sqlite');

// Middleware
app.use(express.urlencoded({ extended: true }));
// Use absolute path for static files
app.use(express.static(join(__dirname.replace('dist', ''), 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// In production, make sure templates can be found when running from dist/
if (__dirname.includes('dist')) {
  app.set('views', join(__dirname.replace('dist', 'src'), 'templates'));
}

// Database setup
let DB: initSqlJs.Database | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    // Load sql.js
    const SQL = await initSqlJs();
    
    if (existsSync(DB_PATH)) {
      const fileBuffer = readFileSync(DB_PATH);
      DB = new SQL.Database(fileBuffer);
      console.log('Database loaded from existing file.');
    } else {
      DB = new SQL.Database();
      const schema = readFileSync(join(__dirname, '../db/schema.sql'), 'utf8');
      DB.run(schema);
      
      // Save the new database to disk
      const data = DB.export();
      writeFileSync(DB_PATH, Buffer.from(data));
      console.log('Database created and schema initialized.');
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  try {
    if (!DB) {
      console.error('Database not initialized');
      return;
    }
    const data = DB.export();
    writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// Validation functions
function validateRequired(value: string): string | null {
  return value.trim() ? null : 'This field is required';
}

function validateEmail(email: string): string | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email) ? null : 'Please enter a valid email address';
}

function validatePhone(phone: string): string | null {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) ? null : 'Please enter a valid phone number';
}

function validatePostalCode(code: string): string | null {
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(code) ? null : 'Please enter a valid postal/zip code';
}

function validateForm(formData: FormData): string[] {
  const errors: string[] = [];
  
  const firstNameError = validateRequired(formData.firstName);
  if (firstNameError) errors.push(`First name: ${firstNameError}`);
  
  const lastNameError = validateRequired(formData.lastName);
  if (lastNameError) errors.push(`Last name: ${lastNameError}`);
  
  const streetAddressError = validateRequired(formData.streetAddress);
  if (streetAddressError) errors.push(`Street address: ${streetAddressError}`);
  
  const cityError = validateRequired(formData.city);
  if (cityError) errors.push(`City: ${cityError}`);
  
  const stateProvinceError = validateRequired(formData.stateProvince);
  if (stateProvinceError) errors.push(`State/Province: ${stateProvinceError}`);
  
  const postalCodeError = validatePostalCode(formData.postalCode);
  if (postalCodeError) errors.push(`Postal/Zip code: ${postalCodeError}`);
  
  const countryError = validateRequired(formData.country);
  if (countryError) errors.push(`Country: ${countryError}`);
  
  const emailError = validateEmail(formData.email);
  if (emailError) errors.push(`Email: ${emailError}`);
  
  const phoneError = validatePhone(formData.phone);
  if (phoneError) errors.push(`Phone: ${phoneError}`);
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    res.status(400).render('form', { errors, values: formData });
    return;
  }
  
  // Insert into database
  if (!DB) {
    res.status(500).send('Database not initialized');
    return;
  }
  
  const stmt = DB.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone,
  ]);
  
  stmt.free();
  
  // Save database to disk
  saveDatabase();
  
  res.redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  // Get the last submitted first name (for personalization)
  if (!DB) {
    res.render('thank-you', { firstName: 'friend' });
    return;
  }
  
  const stmt = DB.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
  const result = stmt.get() as unknown;
  stmt.free();
  
  const firstName = (result as { first_name: string })?.first_name || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Shutting down gracefully.`);
  
  if (DB) {
    saveDatabase();
    DB.close();
    console.log('Database closed.');
  }
  
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  // Handle graceful shutdown
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  
  // Handle server close event
  server.on('close', () => {
    if (DB) {
      saveDatabase();
      DB.close();
      console.log('Database closed.');
    }
  });
}

export { startServer };

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Error starting server:', error);
    process.exit(1);
  });
}