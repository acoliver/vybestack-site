export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for common formats.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email pattern with proper validation
  const emailRegex = /^([a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)@([a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*)$/;
  
  // Check for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('_@')) return false;
  if (value.startsWith('@') || value.endsWith('@')) return false;
  if (value.split('@').length !== 2) return false;
  
  const match = value.match(emailRegex);
  if (!match) return false;
  
  const [local, domain] = [match[1], match[2]];
  
  // Local part validation
  if (local.startsWith('.') || local.endsWith('.')) return false;
  if (local.includes('..')) return false;
  
  // Domain part validation
  if (domain.includes('_')) return false;
  if (domain.includes('..') || domain.startsWith('.') || domain.endsWith('.')) return false;
  
  const parts = domain.split('.');
  if (parts.length < 2) return false;
  
  // Validate TLD has at least 2 characters
  const tld = parts[parts.length - 1];
  if (tld.length < 2) return false;
  
  return true;
}

export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters to extract only numbers
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 for regular, 11 for +1 prefix)
  if (digits.length < 10) return false;
  if (digits.length > 11) return false;
  
  // Extract phone number without country code if +1 is present
  let phoneNumber: string;
  if (digits.length === 11) {
    if (!digits.startsWith('1')) return false;
    phoneNumber = digits.slice(1);
  } else {
    phoneNumber = digits;
  }
  
  // Check area code (leading digit cannot be 0 or 1)
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Regular US phone pattern validation
  const usPhonePattern = /^(\+?1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?[\d-]{3,4}[\s-]?\d{4}$/;
  
  return usPhonePattern.test(value);
}

/**
 * Validates Argentine phone numbers including mobile and landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens but keep digits and '+' and other relevant characters
  const normalized = value.replace(/[\s-]/g, '');

  // Pattern for Argentine phone numbers
  // (\+54)? - optional country code
  // 0? - optional trunk prefix (required if country code omitted)
  // (9)? - optional mobile indicator
  // (\d{2,4}) - area code (2-4 digits, first digit 1-9)
  // (\d{6,8}) - subscriber number (6-8 digits)
  const argentinePhonePattern = /^(\+54)?0?(9)?(\d{2,4})(\d{6,8})$/;
  
  const match = normalized.match(argentinePhonePattern);
  if (!match) return false;
  
  const [, countryCode = '', , areaCode, subscriberNumber] = match;
  
  // If country code is omitted, must start with trunk prefix '0'
  if (!countryCode && !normalized.startsWith('0')) return false;
  
  // Area code validation (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accented letters, 
 * apostrophes, hyphens, and spaces. Rejects digits, symbols, and unusual names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  if (value.trim().length === 0) return false;
  
  // Characters allowed: Unicode letters (including accented), apostrophes, hyphens, spaces
  const namePattern = /^[\p{L}\p{M}'\-\s.]+$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Ensure at least some letters are present (not just symbols/space)
  const hasLetters = /\p{L}+/u.test(value);
  if (!hasLetters) return false;
  
  // Reject sequences that look like "X Æ A-12"
  const rejectPattern = /([A-Za-z]\s+Æ\s+[A-Za-z]\-\d+)/;
  if (rejectPattern.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers for major brands using Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (typical credit card lengths)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check Luhn checksum
  if (!runLuhnCheck(digits)) return false;
  
  // Check prefixes for major card types
  const visa = /^4/;
  const mastercard = /^5[1-5]|^2[2-7]/;
  const amex = /^3[47]/;
  
  return visa.test(digits) || mastercard.test(digits) || amex.test(digits);
}

/**
 * Implements the Luhn algorithm to verify credit card checksums.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    if (isEven) {
      const doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        const strDigit = doubledDigit.toString();
        digit = parseInt(strDigit[0], 10) + parseInt(strDigit[1], 10);
      } else {
        digit = doubledDigit;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}