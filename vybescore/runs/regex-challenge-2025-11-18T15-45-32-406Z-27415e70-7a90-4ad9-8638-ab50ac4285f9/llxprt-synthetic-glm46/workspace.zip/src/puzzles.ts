/**
 * Helper function to escape special characters in regex patterns.
 */
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Finds words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create word boundary regex for the prefix
  const prefixPattern = new RegExp(`\\b${escapeRegex(prefix)}\\w+`, 'g');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => 
    !exceptions.some(ex => ex.toLowerCase() === match.toLowerCase())
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Use lookbehind for digit to match "digit + token"
  const pattern = new RegExp(`\\d${escapeRegex(token)}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validates password strength: at least 10 characters, one uppercase, one lowercase,
 * one digit, one symbol, no whitespace, and no repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"|,.<>\/]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (e.g., 'abab')
  if (/(..)\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 patterns (including shorthand with ::)
  const ipv6Patterns = [
    // Full IPv6 (8 groups of 4 hex digits)
    /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with :: compression
    /\b([0-9a-fA-F]{1,4}:){1,7}:\b/,
    /\b:(:[0-9a-fA-F]{1,4}){1,7}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}\b/,
    /\b[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})\b/,
    /\b:((:[0-9a-fA-F]{1,4}){1,7}|:)\b/,
    // The pattern for "2001:db8::1"
    /\b[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}\b/,
    // Other compressed patterns
    /\b[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}\b/,
  ];
  
  // Check if any IPv6 patterns exist in the text
  return ipv6Patterns.some(pattern => pattern.test(value));
}