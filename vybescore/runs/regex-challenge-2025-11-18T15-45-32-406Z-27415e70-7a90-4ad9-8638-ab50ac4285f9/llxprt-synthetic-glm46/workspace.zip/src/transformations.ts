/**
 * Capitalizes the first character of each sentence with proper spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Add space after sentence-ending punctuation if not already present
  let result = text.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize the first character of the text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Find sentence endings and capitalize the following character
  result = result.replace(/([.!?])(?:\s+)?([a-zA-Z])/g, (match, punctuation, letter) => {
    return `${punctuation} ${letter.toUpperCase()}`;
  });
  
  // Collapse multiple spaces
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern
  const urlPattern = /https?:\/\/[^\s/$.?#].[^\s]*/gi;
  
  const matches = text.match(urlPattern) || [];
  
// Remove trailing punctuation
  return matches.map(url => {
    return url.replace(/[.,:;!?'\"()\[\]{}]+$/g, '');
  });
}

/**
 * Replaces all http:// URLs with https:// while leaving existing secure URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://, moving docs paths to docs.example.com.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then rewrite docs.example.com pattern (skip dynamic URLs)
  result = result.replace(/https:\/\/example\.com(\/docs\/[^\s?&#]*[^.jsp.php.asp.aspx.do.cgi.pl.py]*)(?=[\s]|$)/g, 'https://docs.example.com$1');
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy pattern
  const datePattern = /(\d{1,2})\/(\d{1,2})\/(\d{4})/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // More specific day validation based on month
  const daysInMonth = [
    31, // January
    (year => year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28)(parseInt(year, 10)), // February (leap year check)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}