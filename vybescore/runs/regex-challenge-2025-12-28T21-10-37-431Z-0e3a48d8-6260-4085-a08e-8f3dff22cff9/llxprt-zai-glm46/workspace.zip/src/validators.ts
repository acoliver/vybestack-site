export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || value.length > 254) {
    return false;
  }

  // Main email regex pattern
  const emailPattern =
    /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;

  if (!emailPattern.test(value)) {
    return false;
  }

  // Additional checks for specific invalid patterns
  if (value.includes('..')) {
    return false;
  }

  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  const [localPart, domain] = value.split('@');

  // Check for consecutive dots in local part
  if (localPart.includes('..')) {
    return false;
  }

  // Check for consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }

  // Domain shouldn't start or end with dot or hyphen
  if (
    domain.startsWith('.') ||
    domain.endsWith('.') ||
    domain.startsWith('-') ||
    domain.endsWith('-')
  ) {
    return false;
  }

  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }

  // Local part shouldn't start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value) {
    return false;
  }

  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');

  // Check length - must be 10 digits (US number) or 11 digits (with country code 1)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Valid with country code
  } else if (digitsOnly.length === 10) {
    // Valid without country code
  } else {
    return false;
  }

  // Extract the 10-digit phone number (without country code)
  const phoneNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Validate format with regex
  const pattern = /^(\+1\s?)?(\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  return pattern.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) {
    return false;
  }

  // Remove spaces and hyphens for validation, but keep structure
  const cleaned = value.replace(/[\s-]/g, '');

  // Main pattern for Argentine phone numbers
  // Optional +54, optional trunk prefix 0, optional mobile indicator 9,
  // area code 2-4 digits (leading 1-9), subscriber 6-8 digits
  const pattern = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;

  if (!pattern.test(cleaned)) {
    return false;
  }

  const match = cleaned.match(pattern);
  if (!match) {
    return false;
  }

  const [, areaCode, subscriber] = match;

  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  // If country code is omitted, trunk prefix 0 must be present
  const hasCountryCode = cleaned.startsWith('+54');

  // More flexible check: if no +54, we need to see if the original starts with 0
  if (!hasCountryCode) {
    // When country code is omitted, the number should begin with trunk prefix 0
    // But we need to check the original value before removing spaces
    const originalCleaned = value.replace(/[\s-]/g, '');
    if (!originalCleaned.startsWith('0')) {
      return false;
    }
  }

  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Trim leading/trailing whitespace
  const trimmed = value.trim();

  // Pattern: Unicode letters (including accents), apostrophes, hyphens, spaces
  // Must contain at least one letter
  const namePattern = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!namePattern.test(trimmed)) {
    return false;
  }

  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) {
    return false;
  }

  // Check for invalid patterns - no digits or symbols
  if (/\d/.test(trimmed)) {
    return false;
  }

  // Reject obviously weird patterns like "X Æ A-12" (has digit)
  // The regex above should catch digits

  // Check for repeated special characters
  const specialChars = trimmed.replace(/[\p{L}\p{M}\s]/gu, '');
  if (/(.)\1{2,}/.test(specialChars)) {
    return false;
  }

  // Check for valid structure - shouldn't start/end with special chars
  if (/^[']/ .test(trimmed) || /[']$/.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) {
    return false;
  }

  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check length based on card type
  // Visa: 13, 16 or 19 digits, starts with 4
  const visaPattern = /^4\d{12}(\d{3}(\d{3})?)?$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;

  const isVisa = visaPattern.test(cleaned);
  const isMastercard = mastercardPattern.test(cleaned);
  const isAmex = amexPattern.test(cleaned);

  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
