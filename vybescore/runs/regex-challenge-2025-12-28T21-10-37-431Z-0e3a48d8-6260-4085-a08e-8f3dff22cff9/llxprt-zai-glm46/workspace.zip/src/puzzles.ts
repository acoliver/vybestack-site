/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Escape the prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with the prefix
  // Word boundary ensures we match whole words
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w+)`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exc => lowerWord === exc.toLowerCase());
  });
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookahead/lookbehind to find embedded tokens.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to find token that:
  // - Is preceded by a digit (using lookbehind)
  // - Is NOT at the start of the string
  // Pattern: \dtoken - digit followed by token (we want to return the full match)
  const regex = new RegExp(`\\d${escapedToken}`, 'g');

  const result: string[] = [];
  let match;

  while ((match = regex.exec(text)) !== null) {
    if (match.index > 0) {
      result.push(match[0]);
    }
  }

  return result;
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }

  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    // Pattern to detect immediate repetition like "abab" or "abcabc"
    const pattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (pattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  // IPv6 pattern - must NOT match IPv4 addresses
  // Full IPv6: 8 groups of 1-4 hex digits, separated by colons
  // Shorthand: :: can appear once to represent consecutive zeros
  
  // First, explicitly exclude pure IPv4 addresses
  // IPv4: 4 groups of 1-3 digits
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // IPv6 patterns
  // Full form: 8 groups of hex digits
  const ipv6FullPattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Shorthand with :: (can appear at start, middle, or end)
  // At minimum, we need some hex groups with ::
  const ipv6ShorthandPattern = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/;
  
  // IPv6 with embedded IPv4 (last two groups can be IPv4)
  const ipv6EmbeddedPattern = /^(?:[0-9a-fA-F]{1,4}:){6}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  // Check if value matches any IPv6 pattern
  if (ipv6FullPattern.test(value.trim()) || 
      ipv6ShorthandPattern.test(value.trim()) ||
      ipv6EmbeddedPattern.test(value.trim())) {
    return true;
  }

  // Also check for IPv6 within larger text (not just exact match)
  const ipv6InTextPattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*/;
  
  const matches = value.match(ipv6InTextPattern);
  if (matches) {
    // Verify it's not an IPv4 address
    for (const match of matches) {
      if (!ipv4Pattern.test(match.trim())) {
        return true;
      }
    }
  }

  return false;
}
