/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }

  // First, normalize spacing: collapse multiple spaces into one
  let normalized = text.replace(/[ \t]+/g, ' ');

  // Handle case where sentences are missing space after punctuation
  // Insert space after .?! when followed by a lowercase letter
  normalized = normalized.replace(/([.!?])([a-z])/g, (match, punct, nextLetter) => {
    return punct + ' ' + nextLetter.toUpperCase();
  });

  // Capitalize first letter of the text
  normalized = normalized.replace(/^[a-z]/, (match) => match.toUpperCase());

  // Capitalize after sentence boundaries
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });

  // Clean up: ensure single space after punctuation
  normalized = normalized.replace(/([.!?])\s+/g, '$1 ');

  return normalized;
}

/**
 * Extracts URLs from text.
 * Returns all URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // URL pattern matching http, https, and www URLs
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+/g;

  const matches = text.match(urlPattern) || [];

  // Clean up trailing punctuation that might have been captured
  return matches.map((url) => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Replaces http:// schemes with https://.
 * Leaves existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs.
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // Pattern to match http(s):// URLs with a path
  const urlPattern = /https?:\/\/[^\s]+\/[^\s]*/g;

  return text.replace(urlPattern, (match) => {
    // Parse the URL
    const urlMatch = match.match(/(https?:\/\/)([^/\s]+)(\/[^\s]*)/);
    if (!urlMatch) return match;

    const [, , host, path] = urlMatch;

    // Always upgrade to https
    const newScheme = 'https://';

    // Check if this is example.com
    if (host === 'example.com' && path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = [
        'cgi-bin',
        '?',
        '&',
        '=',
        '.jsp',
        '.php',
        '.asp',
        '.aspx',
        '.do',
        '.cgi',
        '.pl',
        '.py',
      ];

      const hasDynamicHint = dynamicHints.some((hint) => path.includes(hint));

      if (hasDynamicHint) {
        // Only upgrade scheme, keep original host
        return newScheme + host + path;
      }

      // Rewrite host to docs.example.com
      return newScheme + 'docs.example.com' + path;
    }

    // Just upgrade scheme
    return newScheme + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Pattern for mm/dd/yyyy
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Days in each month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  // Validate day based on month
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
