#!/bin/bash
cd /home/runner/work/vybestack-site/vybestack-site/evals/outputs/form-capture-2026-01-24T01-25-59-357Z-efb61bba-987e-4f1c-bf6c-29a8162b24d2
node dist/server.js &