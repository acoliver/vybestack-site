import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have TypeScript definitions
import sqljs from 'sql.js';
import type { Database } from './sqljs-types.js';

// Polyfill __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ServerWithDB extends express.Application {
  db?: Database;
}

async function initializeDatabase(): Promise<{ db: Database }> {
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  const dataDir = path.dirname(dbPath);
  
  // Ensure data directory exists
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Initialize SQL.js
  const SQL = await sqljs();
  
  let db: Database;
  if (fs.existsSync(dbPath)) {
    // Load existing database
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    // Create new database and run schema
    db = new SQL.Database();
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Split schema by semicolons and execute each statement
    const statements = schema.split(';').filter(s => s.trim());
    for (const statement of statements) {
      if (statement.trim()) {
        db.run(statement);
      }
    }
  }
  
  return { db };
}

function validateSubmission(data: FormSubmission): string[] {
  const errors: string[] = [];
  
  // Required fields validation
  if (!data.firstName.trim()) errors.push('First name is required');
  if (!data.lastName.trim()) errors.push('Last name is required');
  if (!data.streetAddress.trim()) errors.push('Street address is required');
  if (!data.city.trim()) errors.push('City is required');
  if (!data.stateProvince.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode.trim()) errors.push('Postal code is required');
  if (!data.country.trim()) errors.push('Country is required');
  
  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email.trim()) {
    errors.push('Email is required');
  } else if (!emailRegex.test(data.email)) {
    errors.push('Email format is invalid');
  }
  
  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!data.phone.trim()) {
    errors.push('Phone number is required');
  } else if (!phoneRegex.test(data.phone)) {
    errors.push('Phone number format is invalid');
  }
  
  return errors;
}

async function saveDatabase(db: Database, dbPath: string): Promise<void> {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

async function startServer(): Promise<void> {
  const app = express() as ServerWithDB;
  const port = process.env.PORT || 3535;
  const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  
  // Initialize database
  const { db } = await initializeDatabase();
  app.db = db;
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));
  
  // Set up EJS
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, '..', 'src', 'templates'));
  
  // Routes
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormSubmission = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const errors = validateSubmission(formData);
    
    if (errors.length > 0) {
      // Return form with errors
      return res.render('form', { errors, values: formData });
    }
    
    // Insert into database
    const stmt = app.db!.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase(app.db!, dbPath).catch(err => {
      console.error('Failed to save database:', err);
    });
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  });
  
  app.get('/thank-you', (req, res) => {
    // We don't have user data after redirect, so use generic message
    res.render('thank-you', { firstName: 'friend' });
  });
  
  // Start server
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Graceful shutdown
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      console.log('HTTP server closed');
      if (app.db) {
        app.db.close();
        console.log('Database closed');
      }
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
