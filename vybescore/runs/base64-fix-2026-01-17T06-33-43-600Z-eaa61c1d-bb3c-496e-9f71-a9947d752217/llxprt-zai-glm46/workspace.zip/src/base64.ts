const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate if a string is valid Base64 format.
 * @param input - The string to validate
 * @returns true if the string matches the Base64 character set
 */
function isValidBase64Format(input: string): boolean {
  return VALID_BASE64_REGEX.test(input);
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) as required by the Base64 specification.
 * @param input - UTF-8 string to encode
 * @returns Base64-encoded string with padding
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both padded and unpadded input, but rejects invalid Base64 characters.
 * @param input - Base64-encoded string to decode
 * @returns Decoded UTF-8 string
 * @throws Error if input contains invalid Base64 characters or cannot be decoded
 */
export function decode(input: string): string {
  // Validate character set before attempting decode
  if (!isValidBase64Format(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    // Normalize by removing any whitespace
    const normalized = input.replace(/\s/g, '');
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if decoding succeeded (empty buffer is ok for empty input)
    if (normalized.length > 0 && buffer.length === 0) {
      throw new Error('Failed to decode Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
