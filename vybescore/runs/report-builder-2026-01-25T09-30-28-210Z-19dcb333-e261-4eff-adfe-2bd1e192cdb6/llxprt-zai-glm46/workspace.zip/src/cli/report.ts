#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions, ReportFormatter } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

/**
 * Map of supported format names to their formatters
 */
const FORMATTERS: Record<string, ReportFormatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

/**
 * Parse CLI arguments from process.argv
 */
function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  const [, , ...rest] = args;
  
  if (rest.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = rest[0];
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 1; i < rest.length; i++) {
    const arg = rest[i];
    
    if (arg === '--format') {
      i++;
      if (i >= rest.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = rest[i];
    } else if (arg === '--output') {
      i++;
      if (i >= rest.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = rest[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

/**
 * Load and parse JSON data from file
 */
function loadData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    // Validate the data structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }

    const reportData = data as Partial<ReportData>;

    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field (expected string)');
    }

    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field (expected string)');
    }

    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field (expected array)');
    }

    for (let i = 0; i < reportData.entries.length; i++) {
      const entry = reportData.entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid data: entry ${i} is not an object`);
      }

      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry ${i} missing or invalid "label" field (expected string)`);
      }

      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entry ${i} missing or invalid "amount" field (expected number)`);
      }
    }

    return reportData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON from '${filePath}': ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: '${filePath}'`);
      process.exit(1);
    }
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    throw error;
  }
}

/**
 * Main CLI entry point
 */
function main(): void {
  const { dataPath, format, outputPath, includeTotals } = parseArgs(process.argv);

  // Validate format
  const formatter = FORMATTERS[format];
  if (!formatter) {
    console.error(`Error: Unsupported format '${format}'. Supported formats: ${Object.keys(FORMATTERS).join(', ')}`);
    process.exit(1);
  }

  // Load and validate data
  const data = loadData(dataPath);

  // Render report
  const options: RenderOptions = { includeTotals };
  const output = formatter.render(data, options);

  // Write output
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error: Failed to write output file: ${error.message}`);
        process.exit(1);
      }
      throw error;
    }
  } else {
    console.log(output);
  }
}

main();
