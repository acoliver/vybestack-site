/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, ObserverR, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: (value?: T) => T, value?: T): UnsubscribeFn {
  let disposed = false
  
  // This observer will be triggered when dependencies change
  const observer: ObserverR = {
    value,
    updateFn: (currentValue?: unknown) => {
      if (disposed) return currentValue
      // Execute the callback function to perform side effects
      updateFn(currentValue as T)
      return currentValue
    },
  }
  
  // Execute the callback immediately to establish dependencies and get initial update
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear references to prevent memory leaks
    observer.value = undefined
    observer.updateFn = () => undefined
  }
}
