/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Subject,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn: undefined,
  }

  const updateComputed = (currentValue: T) => updateFn(currentValue)

  const read: GetterFn<T> = () => {
    const previousValue = s.value
    
    // Register as observer if there's an active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      s.observers.add(activeObserver)
    }
    
    // Re-evaluate the computed value
    try {
      s.value = updateComputed(s.value)
    } catch (e) {
      console.error('Error in computed value:', e)
    }
    
    // If the value changed, notify our observers
    if (previousValue !== s.value && s.observers.size > 0) {
      // Create a copy to avoid modification during iteration
      const observers = Array.from(s.observers)
      for (const observer of observers) {
        if (observer.updateFn) {
          try {
            observer.updateFn()
          } catch (e) {
            console.error('Error notifying observer:', e)
          }
        }
      }
    }
    
    return s.value
  }

  return read
}
