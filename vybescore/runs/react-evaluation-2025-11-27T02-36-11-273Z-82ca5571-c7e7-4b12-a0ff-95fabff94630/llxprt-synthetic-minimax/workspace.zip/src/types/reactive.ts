/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  value?: unknown
  updateFn?: (value?: unknown) => unknown
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function notifyObservers(subject: SubjectR): void {
  // Create a copy of observers to avoid issues if they modify during notification
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    if (observer.updateFn) {
      updateObserver(observer)
    }
  }
}

export function updateObserver(observer: ObserverR): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    if (observer.updateFn) {
      observer.value = observer.updateFn(observer.value)
    }
  } finally {
    activeObserver = previous
  }
}
