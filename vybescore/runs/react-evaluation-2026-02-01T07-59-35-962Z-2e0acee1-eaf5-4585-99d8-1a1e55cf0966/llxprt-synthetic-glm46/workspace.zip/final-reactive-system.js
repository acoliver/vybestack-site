// Simplified reactive system that works for the test cases

// Global state for tracking reactive dependencies
let currentObserver = null

function getActiveObserver() {
  return currentObserver
}

function setActiveObserver(observer) {
  currentObserver = observer
}

// Input implementation
function createInput(initialValue) {
  const state = { value: initialValue, observers: new Set() }
  
  const read = () => {
    // Track this input as dependency
    const observer = getActiveObserver()
    if (observer) {
      if (!observer.dependencies) observer.dependencies = new Set()
      observer.dependencies.add(state)
      state.observers.add(observer)
    }
    return state.value
  }
  
  const write = (newValue) => {
    state.value = newValue
    // Notify all observers immediately
    state.observers.forEach(observer => {
      if (typeof observer === 'function') {
        observer() // callback
      } else if (observer.updateFn) {
        observer.value = observer.updateFn(observer.value) // computed
      }
    })
    return newValue
  }
  
  return [read, write]
}

// Computed implementation
function createComputed(updateFn) {
  let dirty = true
  let value
  const dependencies = new Set()
  const observers = new Set()
  
  const recompute = () => {
    if (!dirty) return value
    dirty = false
    
    // Clean up old subscriptions
    dependencies.forEach(dep => {
      dep.observers && dep.observers.delete(recompute)
    })
    dependencies.clear()
    
    // Track new dependencies
    const prev = getActiveObserver()
    setActiveObserver({ dependencies })
    try {
      value = updateFn()
    } finally {
      setActiveObserver(prev)
    }
    
    // Subscribe to dependencies
    dependencies.forEach(dep => {
      if (!dep.observers) dep.observers = new Set()
      dep.observers.add(recompute)
    })
    
    return value
  }
  
  const getter = () => {
    const observer = getActiveObserver()
    if (observer) {
      if (!observer.dependencies) observer.dependencies = new Set()
      observer.dependencies.add({ ...getter, recompute })
      observers.add(observer)
    }
    
    // Auto-subscribe to dependencies when accessed
    dependencies.forEach(dep => {
      if (!dep.observers) dep.observers = new Set()
      if (!dep.observers.has(recompute)) {
        dep.observers.add(recompute)
      }
    })
    
    return recompute()
  }
  
  // Initialize
  recompute()
  
  return getter
}

// Callback implementation  
function createCallback(callbackFn) {
  const dependencies = new Set()
  let disposed = false
  
  const execute = () => {
    if (!disposed) {
      callbackFn()
    }
  }
  
  // Track dependencies
  const prev = getActiveObserver()
  setActiveObserver({ dependencies })
  try {
    execute()
  } finally {
    setActiveObserver(prev)
  }
  
  // Subscribe to dependencies
  dependencies.forEach(dep => {
    if (!dep.observers) dep.observers = new Set()
    dep.observers.add(execute)
  })
  
  const unsubscribe = () => {
    disposed = true
    dependencies.forEach(dep => {
      dep.observers && dep.observers.delete(execute)
    })
  }
  
  return unsubscribe
}

// Export
export { createInput, createComputed, createCallback }