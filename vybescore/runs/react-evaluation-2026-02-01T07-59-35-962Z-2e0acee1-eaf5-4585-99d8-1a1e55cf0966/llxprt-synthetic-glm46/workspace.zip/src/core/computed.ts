/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  ObserverR,
  SubjectR,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let dirty = true
  const dependencies = new Set<SubjectR<unknown>>()
  const observers = new Set<ObserverR>()

  const recompute = () => {
    if (!dirty) return
    dirty = false

    // Clean up old dependencies
    dependencies.forEach(dep => {
      if (dep.observers) {
        dep.observers.delete(recompute)
      }
    })
    dependencies.clear()

    // Set this as active observer to track dependencies
    const prev = getActiveObserver()
    setActiveObserver({ dependencies } as ObserverR)
    try {
      value = updateFn(value)
    } finally {
      setActiveObserver(prev)
    }

    // Setup new dependencies
    dependencies.forEach(dep => {
      if (!dep.observers) dep.observers = new Set()
      dep.observers.add(recompute)
    })
  }

  // Initial computation
  recompute()

  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      if (!observer.dependencies) observer.dependencies = new Set()
      observer.dependencies.add({ recompute } as SubjectR<unknown>)
      observers.add(observer)
    }

    // Auto-subscribe computed as observer to its dependencies
    dependencies.forEach(dep => {
      if (!dep.observers) dep.observers = new Set()
      dep.observers.add(recompute)
    })
    
    // Notify observers when this computed becomes dirty
    const markDirty = () => {
      dirty = true
      // Notify all dependent observers to recompute
      observers.forEach(obs => {
        try {
          if (obs.updateFn) {
            obs.updateFn(obs.value)
          }
        } catch (e) {
          // Silent error handling
        }
      })
    }

    // Register as observer to all dependencies with markDirty callback
    dependencies.forEach(dep => {
      if (!dep.observers) dep.observers = new Set()
      dep.observers.add(markDirty)
    })

    recompute()
    return value!
  }
}
