/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn, ObserverR, SubjectR, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const dependencies = new Set<SubjectR<unknown>>()
  let disposed = false

  const execute = () => {
    if (disposed) return
    updateFn(value)
  }

  // Set up to track dependencies
  const prevObserver = getActiveObserver()
  const dummyObserver = { dependencies }
  
  // Temporarily set active observer to track dependencies
  setActiveObserver(dummyObserver as ObserverR)
  try {
    // Execute once to track dependencies
    execute()

    // Subscribe to all dependencies
    dependencies.forEach(dep => {
      if (!dep.observers) dep.observers = new Set()
      dep.observers.add(execute)
    })
  } finally {
    setActiveObserver(prevObserver)
  }

  return () => {
    if (disposed) return
    disposed = true

    // Unsubscribe from all dependencies
    dependencies.forEach(dep => {
      if (dep.observers) {
        dep.observers.delete(execute)
      }
    })
  }
}
