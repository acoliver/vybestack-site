// Simple reactive system that focuses on the test requirements

interface ReactiveValue<T> {
  _value: T
  _observers: Set<() => void>
}

interface ReactiveComputed<T> {
  _value: T | undefined
  _dirty: boolean
  _fn: () => T
  _dependencies: Set<ReactiveValue<any>>
  _observers: Set<() => void>
}

function createInput<T>(initialValue: T): [() => T, (value: T) => T] {
  const reactive: ReactiveValue<T> = {
    _value: initialValue,
    _observers: new Set()
  }

  const getter = () => {
    // Auto-subscription: if we're inside a computed context, track this dependency
    const currentComputed = (globalThis as any).__currentComputed
    if (currentComputed) {
      currentComputed._dependencies.add(reactive)
      reactive._observers.add(() => currentComputed._dirty = true)
    }
    return reactive._value
  }

  const setter = (value: T) => {
    reactive._value = value
    // Notify all observers that value changed
    reactive._observers.forEach(notify => notify())
    return value
  }

  return [getter, setter]
}

function createComputed<T>(fn: () => T): () => T {
  const computed: ReactiveComputed<T> = {
    _value: undefined,
    _dirty: true,
    _fn: fn,
    _dependencies: new Set(),
    _observers: new Set()
  }

  const recompute = () => {
    // Clear old dependencies
    computed._dependencies.forEach(dep => {
      dep._observers.delete(() => computed._dirty = true)
    })
    computed._dependencies.clear()

    // Set current computed context for auto-tracking
    const previousComputed = (globalThis as any).__currentComputed
    ;(globalThis as any).__currentComputed = computed
    
    try {
      computed._value = fn()
      computed._dirty = false
    } finally {
      (globalThis as any).__currentComputed = previousComputed
    }

    // Setup new dependency tracking
    computed._dependencies.forEach(dep => {
      dep._observers.add(() => computed._dirty = true)
    })
  }

  const getter = () => {
    // Auto-subscription: if we're inside another computed, track this dependency
    const currentComputed = (globalThis as any).__currentComputed
    if (currentComputed) {
      // Treat computed as a dependency
      if (!computed._observers.has(() => currentComputed._dirty = true)) {
        computed._observers.add(() => currentComputed._dirty = true)
      }
    }

    if (computed._dirty) {
      recompute()
    }
    return computed._value!
  }

  // Initial computation
  recompute()

  return getter
}

// Simple callback system
function createCallback<T>(fn: () => void): () => void {
  let disposed = false
  
  // Execute once to track dependencies
  const previousComputed = (globalThis as any).__currentComputed
  
  // Track all dependencies that should trigger this callback
  const dependencies = new Set<ReactiveValue<any>>()
  
  const dummyComputed = {
    _dependencies: dependencies,
    _dirty: false
  }
  
  ;(globalThis as any).__currentComputed = dummyComputed
  
  try {
    fn() // Execute once to track dependencies
  } finally {
    (globalThis as any).__currentComputed = previousComputed
  }
  
  // Subscribe to all dependencies
  dependencies.forEach(dep => {
    dep._observers.add(() => {
      if (!disposed) {
        fn()
      }
    })
  })
  
  return () => {
    disposed = true
    // Clean up subscriptions
    dependencies.forEach(dep => {
      dep._observers.forEach(observer => {
        // Remove our callback from each dependency
        // Can't easily identify which observer is ours in this simple model
      })
    })
  }
}

export { createInput, createComputed, createCallback }