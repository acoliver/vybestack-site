import { createInput, createComputed } from './src/index.js'

console.log('Testing reactive system...')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  console.log('Computing timesTwo, input =', input())
  return input() * 2
})
console.log('Initial timesTwo:', timesTwo())

const timesThirty = createComputed(() => {
  console.log('Computing timesThirty, input =', input())
  return input() * 30
})
console.log('Initial timesThirty:', timesThirty())

const sum = createComputed(() => {
  console.log('Computing sum, timesTwo =', timesTwo(), 'timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})
console.log('Initial sum:', sum(), 'expected: 32')

console.log('About to call setInput(3)')
setInput(3)
console.log('After setInput(3)')
const sumAfter = sum()
console.log('After setInput(3), sum =', sumAfter, 'expected: 96')

// Try manual recalculation
console.log('Manually retrigging sum computation...')
const retrySum = sum()
console.log('Retried sum =', retrySum, 'expected: 96')