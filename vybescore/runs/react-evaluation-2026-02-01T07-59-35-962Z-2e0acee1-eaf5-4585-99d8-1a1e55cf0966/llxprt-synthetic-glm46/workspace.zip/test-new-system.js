import { createInput, createComputed, createCallback } from './new-reactive-system.js'

console.log('Testing new reactive system...')

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  console.log('Computing timesTwo, input =', input())
  return input() * 2
})
console.log('Initial timesTwo:', timesTwo())

const timesThirty = createComputed(() => {
  console.log('Computing timesThirty, input =', input())
  return input() * 30
})
console.log('Initial timesThirty:', timesThirty())

const sum = createComputed(() => {
  console.log('Computing sum, timesTwo =', timesTwo(), 'timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})
console.log('Initial sum:', sum(), 'expected: 32')

// Test with callback
let callbackValue = 0
const output = createComputed(() => input() + 1)
createCallback(() => {
  console.log('Callback triggered! output =', output())
  callbackValue = output()
})

console.log('About to call setInput(3)')
setInput(3)
console.log('After setInput(3), callbackValue =', callbackValue, 'expected: 4')

// Test multiple callbacks
const values1 = []
const unsubscribe1 = createCallback(() => values1.push(output()))

const values2 = []
createCallback(() => values2.push(output()))

setInput(31)
unsubscribe1()
setInput(41)

console.log('values1.length =', values1.length, ', values2.length =', values2.length)
console.log('values1:', values1)
console.log('values2:', values2)
console.log('values2.length > values1.length?', values2.length > values1.length)