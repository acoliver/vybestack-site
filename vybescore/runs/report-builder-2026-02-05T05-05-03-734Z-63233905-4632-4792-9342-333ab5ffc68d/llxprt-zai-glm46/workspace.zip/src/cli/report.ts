#!/usr/bin/env node

/**
 * Report Builder CLI
 * Renders reports from JSON input in various formats
 */

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command-line arguments using Node's standard library
 */
function parseArgs(args: string[]): CliArgs {
  const result: Partial<CliArgs> = {
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[i];
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Error: Unsupported format "${format}"`);
        console.error('Supported formats: markdown, text');
        process.exit(1);
      }
      result.format = format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: Unknown option "${arg}"`);
      process.exit(1);
    } else if (!result.inputFile) {
      result.inputFile = arg;
    } else {
      console.error(`Error: Unexpected argument "${arg}"`);
      process.exit(1);
    }

    i++;
  }

  if (!result.inputFile) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    console.error('  <data.json>       Path to the JSON report data file');
    console.error('  --format <fmt>    Output format: markdown or text');
    console.error('  --output <path>   Optional output file path (defaults to stdout)');
    console.error('  --includeTotals   Include total of all entry amounts');
    process.exit(1);
  }

  if (!result.format) {
    console.error('Error: --format is required');
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  return result as CliArgs;
}

/**
 * Load and parse JSON data from a file
 */
function loadData(filePath: string): ReportData {
  let content: string;
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: "${filePath}"`);
      process.exit(1);
    }
    console.error(`Error: Unable to read file "${filePath}": ${(error as Error).message}`);
    process.exit(1);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    console.error(`Error: Invalid JSON in file "${filePath}": ${(error as Error).message}`);
    process.exit(1);
  }

  // Validate the data structure
  if (typeof data !== 'object' || data === null) {
    console.error('Error: JSON data must be an object');
    process.exit(1);
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error('Error: Missing or invalid "title" field (expected string)');
    process.exit(1);
  }

  if (typeof obj.summary !== 'string') {
    console.error('Error: Missing or invalid "summary" field (expected string)');
    process.exit(1);
  }

  if (!Array.isArray(obj.entries)) {
    console.error('Error: Missing or invalid "entries" field (expected array)');
    process.exit(1);
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${i} is not an object`);
      process.exit(1);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Entry at index ${i} missing or invalid "label" field (expected string)`);
      process.exit(1);
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Entry at index ${i} missing or invalid "amount" field (expected number)`);
      process.exit(1);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI entry point
 */
function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Load and validate input data
  const data = loadData(args.inputFile);

  // Select the appropriate renderer
  const renderers = {
    markdown: renderMarkdown,
    text: renderText,
  };

  const renderer = renderers[args.format];
  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  const output = renderer(data, options);

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Unable to write to file "${args.outputPath}": ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
