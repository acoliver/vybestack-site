/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // Find sentence boundaries (.?! followed by whitespace or end of string)
  // Capture the punctuation and what comes after
  return text
    // First, normalize whitespace between sentences
    // Match end of sentence followed by any amount of whitespace
    .replace(/([.!?])(\s*)/g, (match, punct, whitespace) => {
      return punct + ' ';
    })
    // Now capitalize first letter after sentence boundaries
    .replace(/([.!?]\s+)(\w)/g, (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    })
    // Also capitalize the very first character if it's a letter
    .replace(/^(\s*)([a-z])/, (match, whitespace, letter) => {
      return whitespace + letter.toUpperCase();
    });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urls: string[] = [];
  
  // Match http(s):// URLs
  const urlRegex = /\bhttps?:\/\/[^\s<>"']+(?=[<>"'()]|$)/gi;
  const matches = text.match(urlRegex);
  
  if (matches) {
    for (const url of matches) {
      // Remove trailing punctuation
      const cleanUrl = url.replace(/[.,;!?]+$/, '');
      urls.push(cleanUrl);
    }
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Use negative lookbehind to ensure it's not already https
  return text.replace(/(?<!s)http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Match http URLs with example.com
  return text.replace(/http:\/\/example\.com\/([^\s<>"']*)/gi, (match, path) => {
    // Always upgrade to https
    let result = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|\?|=|&|\.(jsp|php|asp|aspx|do|cgi|pl|py)($|\?)/i.test(path);
    
    if (path.startsWith('docs/') && !hasDynamicHints) {
      // Rewrite to docs.example.com
      result += 'docs.example.com/';
      result += path.substring(5); // Remove 'docs/' prefix
    } else {
      // Keep the host as example.com
      result += 'example.com/';
      result += path;
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate year (reasonable range)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  return year.toString();
}