/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const results: string[] = [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  // Word boundaries to ensure we match whole words
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(regex);
  
  if (matches) {
    for (const match of matches) {
      // Check if this match is in the exceptions list (case-insensitive)
      const isException = exceptions.some(exc => 
        exc.toLowerCase() === match.toLowerCase()
      );
      
      if (!isException) {
        results.push(match);
      }
    }
  }
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const results: string[] = [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use negative lookbehind to ensure it's not at the start
  // Use positive lookbehind to ensure it's preceded by a digit
  const regex = new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'gi');
  
  let match;
  while ((match = regex.exec(text)) !== null) {
    results.push(match[0]);
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric, non-space)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences like "abab"
  // Check for any 4-character sequence that repeats immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns to match
  
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullPattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with :: shorthand (one or more consecutive groups of zeros compressed)
  const shorthandPattern = /^((?:[0-9a-fA-F]{1,4}:)*)(::)((?::[0-9a-fA-F]{1,4})*)$/;
  
  // IPv6 with some zeros omitted but not at start/end
  const partialPattern = /^([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 starting with ::
  const doubleColonStart = /^::((:[0-9a-fA-F]{1,4})+)$/;
  
  // IPv6 ending with ::
  const doubleColonEnd = /^(([0-9a-fA-F]{1,4}:)+)::$/;
  
  // Check if the entire value matches IPv6 patterns
  const trimmed = value.trim();
  
  // If it matches any IPv6 pattern and doesn't look like IPv4, it's valid
  if (fullPattern.test(trimmed) || 
      shorthandPattern.test(trimmed) || 
      partialPattern.test(trimmed) ||
      doubleColonStart.test(trimmed) ||
      doubleColonEnd.test(trimmed)) {
    
    // Exclude if it contains dots (IPv4 indicator)
    if (trimmed.includes('.')) {
      return false;
    }
    
    return true;
  }
  
  // Also check if it contains an IPv6 address within the string
  // Match IPv6 patterns within the text (with word boundaries or punctuation)
  const ipv6Regex = /\b(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?::[0-9a-fA-F]{1,4})*|(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::|(?::[0-9a-fA-F]{1,4})+)\b/;
  
  const matches = trimmed.match(ipv6Regex);
  
  if (matches) {
    for (const match of matches) {
      // If it's a standalone match or surrounded by non-dot characters
      if (!match.includes('.')) {
        return true;
      }
    }
  }
  
  return false;
}