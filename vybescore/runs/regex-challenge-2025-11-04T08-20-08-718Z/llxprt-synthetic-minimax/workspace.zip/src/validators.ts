export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // - Must have @ symbol
  // - Local part: letters, numbers, dots, hyphens, underscores, plus signs
  // - Domain part: letters, numbers, dots, hyphens (no underscores)
  // - No consecutive dots
  // - No trailing dot
  // - Domain must have at least 2 characters after last dot
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  // No double dots in local part
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check domain part for underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  
  // Check for optional +1 prefix
  let phoneDigits = cleaned;
  if (cleaned.startsWith('+1')) {
    phoneDigits = cleaned.substring(2);
  }
  
  // Remove all non-digits from the remaining part
  const digits = phoneDigits.replace(/\D/g, '');
  
  // Must have exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Format validation - ensure original input matches one of the valid patterns
  const patterns = [
    /^\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,       // 212-555-7890
    /^\d{10}$/,                   // 2125557890
    /^\+1\s*\d{3}\s*\d{3}\s*\d{4}$/, // +1 212 555 7890
  ];
  
  if (options?.allowExtensions) {
    // Allow extensions like "ext 123" or "x123"
    const extPattern = /^(?:\(\d{3}\)\s*\d{3}-\d{4}|\d{3}-\d{3}-\d{4}|\d{10}|\+1\s*\d{3}\s*\d{3}\s*\d{4})\s*(?:ext\.?\s*\d+|x\s*\d+)?$/i;
    return extPattern.test(value.trim());
  }
  
  return patterns.some(pattern => pattern.test(value.trim()));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all punctuation and spaces, we'll validate structure separately
  const cleaned = value.trim();
  
  // Match: [+54][9][0][area_code][subscriber_number]
  // Where:
  // - Country code: +54 (optional)
  // - Mobile indicator: 9 (optional, if present must be after country code)
  // - Trunk prefix: 0 (required if no country code)
  // - Area code: 2-4 digits, first digit 1-9
  // - Subscriber number: 6-8 digits total (including area code)
  
  const patterns = [
    // With country code +54
    /^\+54\s*9?\s*0?\s*([1-9]\d{1,3})\s*(\d{6,8})$/, // +54 9 11 1234 5678, +54 341 123 4567
    /^\+54\s*9?\s*0?\s*([1-9]\d{1,3})\s*(\d{6,8})$/, // +54 341 4234567
    // Without country code but with trunk prefix 0
    /^0\s*9?\s*([1-9]\d{1,3})\s*(\d{6,8})$/, // 011 1234 5678, 0341 4234567
  ];
  
  for (const pattern of patterns) {
    const match = cleaned.match(pattern);
    if (match) {
      const areaCode = match[1];
      const subscriberNumber = match[2];
      
      // Area code validation: 2-4 digits (first digit already validated as 1-9)
      if (areaCode.length >= 2 && areaCode.length <= 4) {
        // Total length validation: area code + subscriber number = 6-8 digits
        const totalLength = (areaCode + subscriberNumber).length;
        if (totalLength >= 6 && totalLength <= 8) {
          return true;
        }
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject anything with digits or special symbols except apostrophe and hyphen
  // Unicode property escapes for letters
  const nameRegex = /^[\p{L}\s'\-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional validation: reject "X Æ A-12" style names
  // Check for sequences like "Æ" or patterns with numbers
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Reject names that are just symbols or unusual character combinations
  // Allow reasonable apostrophe and hyphen usage
  const cleaned = value.replace(/[\s'\-]/g, '');
  if (cleaned.length === 0) {
    return false;
  }
  
  // Check for unusual character sequences (Æ, special symbols not caught above)
  if (/Æ|Ø|Å/.test(value)) {
    // Allow single occurrences of these but not in weird combinations
    const symbolCount = (value.match(/Æ|Ø|Å/g) || []).length;
    if (symbolCount > 1) {
      return false;
    }
    // If it's just the symbol, reject
    if (cleaned.match(/^[ÆØÅ]$/)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  // Check card type based on prefix and length
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digits.startsWith('4')) {
    if (digits.length === 13 || digits.length === 16 || digits.length === 19) {
      isValidType = true;
    }
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (digits.startsWith('51') || digits.startsWith('52') || 
      digits.startsWith('53') || digits.startsWith('54') || digits.startsWith('55')) {
    if (digits.length === 16) {
      isValidType = true;
    }
  }
  
  // Mastercard 2221-2720 range
  if (digits.length === 16) {
    const startRange = parseInt(digits.substring(0, 4), 10);
    if (startRange >= 2221 && startRange <= 2720) {
      isValidType = true;
    }
  }
  
  // American Express: starts with 34 or 37, length 15
  if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}