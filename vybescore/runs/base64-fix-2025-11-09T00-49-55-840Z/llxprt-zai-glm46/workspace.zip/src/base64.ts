/**
 * Encode plain text to Base64 using canonical RFC 4648 alphabet.
 * Includes required padding with '=' characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and uses the canonical alphabet.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: empty or not a string');
  }

  // Validate Base64 format - only allow valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Remove whitespace and normalize padding
  const cleanInput = input.trim().replace(/\s+/g, '');

  try {
    const result = Buffer.from(cleanInput, 'base64').toString('utf8');
    
    // Additional validation: check if the decoded result makes sense
    // If the input was valid Base64 but couldn't be decoded to UTF-8, throw error
    if (cleanInput.length > 0 && result === '' && !cleanInput.includes('=')) {
      throw new Error('Invalid Base64 input: could not decode to valid UTF-8');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
