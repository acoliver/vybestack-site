/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Normalize the equality function
  const equalFn: EqualFn<T> = 
    typeof equal === 'function' ? equal : 
    equal === true ? Object.is : 
    (a, b) => a === b

  // Create subject with observer tracking
  const s: Subject<T> & { observers?: Observer<T>[] } = {
    name: options?.name,
    value,
    equalFn,
    observer: undefined
  }
  
  // Add observers array as a custom property
  s.observers = []

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !s.observers!.includes(observer as Observer<T>)) {
      s.observers!.push(observer as Observer<T>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has actually changed
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Update all observers
      for (const observer of s.observers!) {
        if (observer !== getActiveObserver()) { // Prevent infinite recursion
          updateObserver(observer)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
