/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Normalize the equality function
  const equalFn: EqualFn<T> = 
    typeof equal === 'function' ? equal : 
    equal === true ? Object.is : 
    (a, b) => a === b
  
  const o: Observer<T> & { observers?: Observer<T>[] } = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Add observers array as a custom property
  o.observers = []
  
  // Compute initial value
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && !o.observers!.includes(activeObserver as Observer<T>)) {
      o.observers!.push(activeObserver as Observer<T>)
    }
    return o.value!
  }
  
  // Override updateFn to track dependencies and propagate changes
  const originalUpdateFn = o.updateFn;
  o.updateFn = (prev?: T) => {
    // Save previous value
    const prevValue = o.value;
    
    // Compute new value using original update function
    const newValue = originalUpdateFn(prev);
    
    // If value changed according to equalFn, update observers
    if (!equalFn || prevValue === undefined || !equalFn(prevValue, newValue)) {
      o.value = newValue;
      for (const observer of o.observers!) {
        if (observer !== getActiveObserver()) { // Prevent infinite recursion
          updateObserver(observer);
        }
      }
    }
    
    return newValue;
  };
  
  return read;
}