/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for words starting with the prefix
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`(?<!^)[0-9]${escapedToken}`, 'gi');
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for no immediate repeated sequences (like abab)
  if (/(..).*\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that matches various IPv6 formats including shorthand ::
  // This pattern excludes IPv4 addresses by not allowing dotted decimal notation in the pattern
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b|\b::\b|\b[0-9a-fA-F]{1,4}::\b|\b::[0-9a-fA-F]{1,4}\b/g;
  
  // First check if there are any IPv6 patterns
  if (!ipv6Pattern.test(value)) return false;
  
  // Make sure we're not matching IPv4 addresses that might slip through
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  const potentialMatches = value.match(ipv6Pattern) || [];
  
  for (const match of potentialMatches) {
    // If this match also looks like an IPv4 address, skip it
    if (ipv4Pattern.test(match)) continue;
    
    // Additional validation: check if it's a valid IPv6 pattern
    // Remove :: and check if all parts are valid hex
    const cleanMatch = match.replace(/::/g, ':');
    const parts = cleanMatch.split(':');
    
    // Check if all parts are valid hex numbers (max 4 hex digits)
    const isValidHex = parts.every(part => {
      if (part === '') return false; // Shouldn't happen after :: replacement
      return /^[0-9a-fA-F]{1,4}$/.test(part);
    });
    
    if (isValidHex) {
      return true;
    }
  }
  
  return false;
}