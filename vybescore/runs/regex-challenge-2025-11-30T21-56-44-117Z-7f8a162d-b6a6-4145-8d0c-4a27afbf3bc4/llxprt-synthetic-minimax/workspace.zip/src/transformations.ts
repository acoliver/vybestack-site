/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences by finding sentence endings followed by spaces and next sentence
  return text.replace(/([.!?]\s+)(\p{Lowercase})/gu, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  }).replace(/^(\p{Lowercase})/u, (match, letter) => {
    // Capitalize the first letter of the whole text
    return letter.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlPattern = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"'()]+[^\s<>"'(),.]/gi;
  const urls = text.match(urlPattern) || [];
  
  return urls.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;!?]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  const urlPattern = /http:\/\/([^/]+)(\/.*)/g;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Check if path has dynamic hints or legacy extensions
    const dynamicHints = /(cgi-bin|[?&]=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    const hasDynamicContent = dynamicHints.test(path);
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/') && !hasDynamicContent) {
      // Rewrite host to docs.domain.com
      const newHost = `docs.${host}`;
      return `https://${newHost}${path}`;
    } else {
      // Just upgrade the scheme to https
      return `https://${host}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) return 'N/A';
  
  // Validate year is 4 digits and reasonable range
  if (year.length !== 4 || parseInt(year, 10) < 1000) return 'N/A';
  
  return year;
}
