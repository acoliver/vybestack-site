export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._-]*[a-zA-Z0-9]*@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])*(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])*)+$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for specific invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('@example..') || value.includes('@..')) return false;
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const { allowExtensions } = _options || {};
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be at least 10 digits
  if (digitsOnly.length < 10) return false;
  
  // Remove optional +1
  const phoneNumber = digitsOnly.startsWith('1') ? digitsOnly.substring(1) : digitsOnly;
  
  // Must be exactly 10 digits
  if (phoneNumber.length !== 10) return false;
  
  const areaCode = parseInt(phoneNumber.substring(0, 3));
  
  // Area code cannot start with 0 or 1
  if (areaCode <= 100) return false;
  
  // Check format patterns
  const patterns = [
    /^\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/, // (212) 555-7890
    /^\d{3}[-\s]\d{3}[-\s]\d{4}$/,    // 212-555-7890
    /^\d{10}$/,                        // 2125557890
    /^\+?1\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/ // +1 212-555-7890
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Optional +54, then optional 0, then optional 9 (for mobile), then 2-4 digit area code (1-9), then 6-8 digit subscriber
  const patterns = [
    // +54 9 11 1234 5678 (mobile with country code)
    /^\+54?9(11)\d{8}$/,
    // +54 341 123 4567 (mobile with country code, different area code)
    /^\+54?9(\d{2,3})\d{7}$/,
    // 011 1234 5678 (landline with trunk prefix)
    /^(011)\d{8}$/,
    // 0341 4234567 (landline with trunk prefix, different area code)
    /^0(\d{2,3})\d{7}$/,
    // +54 11 1234 5678 (mobile with country code, no mobile indicator)
    /^\+54(11)\d{8}$/,
    // +54 341 1234567 (mobile with country code, no mobile indicator)
    /^\+54(\d{2,3})\d{7}$/
  ];
  
  return patterns.some(pattern => pattern.test(cleanValue));
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject names with digits or problematic symbols
  if (/[0-9]/.test(value)) return false;
  
  // Reject special symbol combinations like "X Æ A-12"
  if (/[ÆØÅ]/.test(value) && /[0-9]/.test(value)) return false;
  if (value.includes('Æ') && /\d/.test(value)) return false;
  
  // Allow letters, spaces, apostrophes, hyphens, and common accent marks
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  return namePattern.test(value);
}

/**
 * Run Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers using proper prefixes and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  const cleanValue = value.replace(/\s|-/g, '');
  
  // Must be 13-19 digits for major credit cards
  if (!/^\d{13,19}$/.test(cleanValue)) return false;
  
  // Check card type prefixes
  const patterns = {
    visa: /^4\d{12}(\d{3})?(\d{3})?$/,
    mastercard: /^5[1-5]\d{14}$/,
    amex: /^3[47]\d{13}$/,
    discover: /^6(?:011|5\d{2})\d{12}$/
  };
  
  const isValidPrefix = Object.values(patterns).some(pattern => pattern.test(cleanValue));
  
  if (!isValidPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
