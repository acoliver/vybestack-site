#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { formatRenderers, type Format } from '../formats/index.js';
import type { ReportData } from '../types.js';

function parseArgs(args: string[]): {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[2];

  let format: Format = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Error: Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      format = formatValue;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (must be a number)`);
    }
  }

  return data as ReportData;
}

function main() {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArgs(process.argv);

    const inputPath = path.resolve(inputFile);

    if (!fs.existsSync(inputPath)) {
      console.error(`Error: File not found: ${inputPath}`);
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      const rawContent = fs.readFileSync(inputPath, 'utf-8');
      jsonData = JSON.parse(rawContent);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`Error: Failed to parse JSON file: ${message}`);
      process.exit(1);
    }

    let reportData: ReportData;
    try {
      reportData = validateReportData(jsonData);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`Error: ${message}`);
      process.exit(1);
    }

    const renderer = formatRenderers[format];
    const output = renderer(reportData, { includeTotals });

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
