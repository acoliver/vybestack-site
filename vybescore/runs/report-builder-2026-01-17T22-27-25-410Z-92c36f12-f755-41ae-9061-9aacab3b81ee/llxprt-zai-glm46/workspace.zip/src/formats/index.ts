import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type Format = 'markdown' | 'text';

export type Renderer = (data: ReportData, options: RenderOptions) => string;

export const formatRenderers: Record<Format, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};
