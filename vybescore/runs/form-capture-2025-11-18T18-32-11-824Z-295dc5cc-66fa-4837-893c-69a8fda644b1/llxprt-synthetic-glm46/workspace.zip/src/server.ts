import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any | undefined;

async function initDatabase() {
  try {
    // Initialize SQL.js
    const SQL = await initSqlJs();
    
    // Create data directory if it doesn't exist
    const dataDir = path.join(process.cwd(), 'data');
    try {
      await fs.access(dataDir);
    } catch {
      await fs.mkdir(dataDir, { recursive: true });
    }
    
    // Load or create database
    const dbPath = path.join(dataDir, 'submissions.sqlite');
    let dbData: Uint8Array;
    
    try {
      const buffer = await fs.readFile(dbPath);
      dbData = new Uint8Array(buffer);
    } catch {
      dbData = new Uint8Array(0);
    }
    
    // Initialize database
    db = new SQL.Database(dbData);
    
    // Create schema if DB is new
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = await fs.readFile(schemaPath, 'utf-8');
    if (db) {
      db.run(schema);
    }
    
    console.log('Database initialized');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function saveDatabase() {
  if (!db) {
    throw new Error("Database not initialized");
  }
  
  try {
    const dbData = db.export();
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    await fs.writeFile(dbPath, Buffer.from(dbData));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // First name
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  // Last name
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  // Street address
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  // City
  if (!data.city || data.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  // State/Province/Region
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  // Postal code
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and hyphens' });
  }
  
  // Country
  if (!data.country || data.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  // Email
  if (!data.email || data.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  // Phone
  if (!data.phone || data.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\\+?[0-9\\s\\-\\(\\)]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, hyphens, parentheses, and a leading +' });
  }
  
  return errors;
}

function getFieldValue(formData: FormData, fieldName: string): string {
  return formData[fieldName as keyof FormData] || '';
}

const app = express();
const PORT = process.env.PORT || 3535;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(fileURLToPath(import.meta.url), '..', 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    formData: {},
    getFieldValue 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    return res.render('form', { errors, formData, getFieldValue });
  }
  
  try {
    // Insert into database
    if (!db) throw new Error('Database not initialized');
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    await saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', { 
      errors: [{ field: '', message: 'Something went wrong. Please try again.' }], 
      formData, 
      getFieldValue 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Initialize server
async function startServer() {
  try {
    await initDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const shutdown = async () => {
      console.log('Shutting down server...');
  
      server.close(() => {
        console.log('Express server closed');
        
        if (db) {
          db.close();
          console.log('Database connection closed');
          saveDatabase().then(() => {
            process.exit(0);
          });
        } else {
          process.exit(0);
        }
      });
    };
    
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();