// Type definitions for sql.js module
declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string, ...params: unknown[]): Database;
    exec(sql: string): unknown[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export class Statement {
    bind(...params: unknown[]): Statement;
    step(): unknown;
    run(...params: unknown[]): unknown;
    free(): void;
  }
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
export function init(config?: any): Promise<{ Database: typeof Database }>;
}

// Exported types for our internal use
export interface InitSqlJsConfig {
  locateFile?: (file: string) => string;
}

export interface SqlJs {
  Database: typeof Database;
}

// Direct export for our internal usage
export function init(initSqlJsConfig?: InitSqlJsConfig): Promise<SqlJs>;
export class Database {
  constructor(data?: Uint8Array);
  run(sql: string, ...params: unknown[]): Database;
  exec(sql: string): unknown[];
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

export class Statement {
  bind(...params: unknown[]): Statement;
  step(): unknown;
  run(...params: unknown[]): unknown;
  free(): void;
}