import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

// Determine views path - check if we're running from dist or src
let viewsPath: string;
if (__dirname.includes('dist') || __dirname.includes('build')) {
  // Running from dist, look for templates in src
  viewsPath = path.resolve(process.cwd(), 'src', 'templates');
} else {
  // Running from src during development
  viewsPath = path.join(__dirname, 'templates');
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', viewsPath);

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^[+]?\d[\d\s\-()]*$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters and spaces
  const postalRegex = /^[A-Za-z0-9\s]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code must contain only letters and numbers' });
  }
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buffer);
    } else {
      db = new SQL.Database();
      // Apply schema
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Close database
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    values: {},
    errors: []
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', {
      values: formData,
      errors: errors.map(e => e.message)
    });
    return;
  }

  // Insert into database
  try {
    db?.run(
      `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    saveDatabase();
  } catch (error) {
    console.error('Database error:', error);
    res.status(500);
    res.render('form', {
      values: formData,
      errors: ['An error occurred while saving your submission. Please try again.']
    });
    return;
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission for personalization
  let firstName = 'friend';
  try {
    const result = db?.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
    if (result && result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  } catch (error) {
    console.error('Error fetching submission:', error);
  }

  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });

  // Graceful shutdown
  const shutdown = (signal: string): void => {
    console.log(`\n${signal} received, shutting down gracefully...`);
    server.close(() => {
      console.log('Server closed');
      closeDatabase();
      process.exit(0);
    });

    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Forcing shutdown after timeout');
      closeDatabase();
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

// Export for testing
export { app, initializeDatabase, closeDatabase };

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
