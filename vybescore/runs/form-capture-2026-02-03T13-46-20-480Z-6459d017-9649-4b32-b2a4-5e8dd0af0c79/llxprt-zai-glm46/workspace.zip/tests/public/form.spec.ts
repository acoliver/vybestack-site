import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, closeDatabase, initializeDatabase } from '../../src/server.js';

let server: { close: (cb?: () => void) => void };
const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Initialize database
  await initializeDatabase();

  // Start server
  server = app.listen(0); // Use random available port
});

afterAll(async () => {
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check form exists
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('form[method="post"]').length).toBe(1);
    
    // Check all required fields exist with proper labels and attributes
    const fields = [
      { id: 'firstName', name: 'firstName', label: 'First name' },
      { id: 'lastName', name: 'lastName', label: 'Last name' },
      { id: 'streetAddress', name: 'streetAddress', label: 'Street address' },
      { id: 'city', name: 'city', label: 'City' },
      { id: 'stateProvince', name: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', name: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', name: 'country', label: 'Country' },
      { id: 'email', name: 'email', label: 'Email' },
      { id: 'phone', name: 'phone', label: 'Phone number' }
    ];

    fields.forEach(field => {
      const $input = $(`#${field.id}`);
      expect($input.length).toBe(1);
      expect($input.attr('name')).toBe(field.name);
      
      // Check associated label
      const $label = $(`label[for="${field.id}"]`);
      expect($label.length).toBe(1);
      expect($label.text().trim()).toBe(field.label);
    });

    // Check submit button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Ensure database doesn't exist
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Follow redirect to thank-you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('body').text()).toContain('John'); // First name should be personalized
    expect($('a[href="/"]').length).toBe(1); // Link back to form
  });

  it('shows validation errors for invalid data', async () => {
    const invalidData = {
      firstName: '', // Required
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'invalid-email', // Invalid format
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(invalidData);

    // Should show form with errors (not redirect)
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    
    // Check error messages are displayed
    expect($('.error-list').length).toBe(1);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('First name is required');
    expect(errorText).toContain('valid email');
  });

  it('accepts international phone formats', async () => {
    const internationalPhoneNumbers = [
      '+44 20 7946 0958', // UK format
      '+54 9 11 1234-5678', // Argentina format
      '+1 (555) 123-4567', // US format
      '+33 1 23 45 67 89' // France format
    ];

    for (const phone of internationalPhoneNumbers) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: 'Test Street',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone: phone
      };

      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(formData);

      // Should redirect (success) for valid international phone numbers
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('accepts international postal code formats', async () => {
    const internationalPostalCodes = [
      'SW1A 1AA', // UK format
      'C1000', // Argentine format
      'B1675', // Argentine format
      '12345', // US format
      '1001' // Simple format
    ];

    for (const postalCode of internationalPostalCodes) {
      const formData = {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: 'Test Street',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: postalCode,
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555 123 4567'
      };

      const response = await request(app)
        .post('/submit')
        .type('form')
        .send(formData);

      // Should redirect (success) for valid postal codes
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });
});
