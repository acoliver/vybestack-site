export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Email validation based on RFC 5322 with practical restrictions
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for common issues
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // No consecutive dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No leading or trailing dots in local part or domain
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.') || 
      domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must have at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers in various formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Remove optional +1 prefix
  const digits = cleaned.startsWith('1') && cleaned.length === 11 ? cleaned.slice(1) : cleaned;
  
  // US phone numbers should have exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format with regex (supports common separators)
  const usPhoneRegex = /^(?:\+1[\s-.]?)?(?:\(\d{3}\)|\d{3})[\s-.]?\d{3}[\s-.]?\d{4}$/;
  return usPhoneRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers (mobile and landline).
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep track of format
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // Optional +54 country code
  // Optional trunk prefix 0 (if no country code)
  // Optional mobile indicator 9
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0|9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  // More permissive format validation with separators
  const formatRegex = /^(?:\+54[\s-]?)?(?:9[\s-]?)?(?:0?[1-9]\d{1,3}[\s-]?)(?:\d{3,4}[\s-]?)?\d{4}(?:\d{2,4})?$/;
  
  return formatRegex.test(value.trim());
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and bizarre names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, most special characters, and emoji
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Additional checks for obviously invalid names
  const trimmed = value.trim();
  
  // Must have at least one letter
  if (!/[\p{L}\p{M}]/u.test(trimmed)) {
    return false;
  }
  
  // No consecutive apostrophes or hyphens
  if (trimmed.includes("'") && trimmed.includes("''")) {
    return false;
  }
  if (trimmed.includes('-') && trimmed.includes('--')) {
    return false;
  }
  
  // Reject names that look like bizarre character combinations
  // (too many special characters for the length)
  const specialCharCount = (trimmed.match(/['\-]/g) || []).length;
  const letterCount = (trimmed.match(/[\p{L}\p{M}]/gu) || []).length;
  
  if (specialCharCount > letterCount * 0.5) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx prefixes and lengths with Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Validate credit card patterns:
  // Visa: 4, length 13 or 16
  // Mastercard: 51-55 or 2221-2720, length 16
  // AmEx: 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^((5[1-5]\d{14})|(2[2-7]\d{13})|(222[1-9]\d{12})|(22[3-9]\d{13})|(2[3-6]\d{14})|(27[01]\d{13})|(2720\d{12}))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(cleaned) || 
                       mastercardRegex.test(cleaned) || 
                       amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
