/**
 * Capitalize the first character of each sentence.
 * Handles .?! sentence terminators, adds single space between sentences,
 * collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // First, normalize spacing around sentence terminators
  const normalized = text
    .replace(/\s*([.?!])\s*/g, '$1 ') // Ensure single space after punctuation
    .replace(/\s+/g, ' ') // Collapse multiple spaces
    .trim();
  
  // Common abbreviations to preserve (basic set)
  const abbreviations = ['Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Ave', 'Rd', 'Blvd', 'Inc', 'Ltd', 'Co', 'etc', 'e\.g', 'i\.e'];
  
  // Split into sentences, being careful about abbreviations
  const sentences: string[] = [];
  let start = 0;
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    if (char === '.' || char === '!' || char === '?') {
      // Check if this might be an abbreviation
      const beforeDot = normalized.substring(Math.max(0, i - 3), i);
      const isAbbreviation = abbreviations.some(abbr => 
        beforeDot.toLowerCase().includes(abbr.toLowerCase().replace('.', '\.'))
      );
      
      // If not an abbreviation and we have text after this punctuation, split here
      if (!isAbbreviation && i < normalized.length - 1) {
        const sentence = normalized.substring(start, i + 1).trim();
        if (sentence) {
          sentences.push(sentence);
        }
        start = i + 1;
      }
    }
  }
  
  // Add the final sentence
  const lastSentence = normalized.substring(start).trim();
  if (lastSentence) {
    sentences.push(lastSentence);
  }
  
  // Capitalize each sentence and join back together
  return sentences
    .map(sentence => {
      // Find the first alphabetic character and capitalize it
      const firstLetterIndex = sentence.search(/[a-zA-Z]/);
      if (firstLetterIndex === -1) {
        return sentence;
      }
      
      return sentence.substring(0, firstLetterIndex) + 
             sentence[firstLetterIndex].toUpperCase() + 
             sentence.substring(firstLetterIndex + 1);
    })
    .join(' ');
}

/**
 * Find URLs in the text and return an array of matched URL strings.
 * Excludes trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https, www domains, and accepts common TLDs
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?|[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation but keep path/query/fragment
    return url.replace(/[.,;:!?\)\]\}"']+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite URLs according to rules:
 * - Always upgrade http to https
 * - For example.com URLs with /docs/ paths, rewrite to docs.example.com
 * - Skip host rewrite for cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com([^\s]*)/g, (match, path) => {
    // Always upgrade to https
    const httpsUrl = `https://example.com${path}`;
    
    // Check if we should skip host rewrite
    const skipPatterns = [
      /cgi-bin/,      // CGI scripts
      /[?=|&]/,         // Query strings
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?![\/])$/  // Legacy extensions at end of path
    ];
    
    const shouldSkip = skipPatterns.some(pattern => 
      pattern.test(path)
    );
    
    // If path starts with /docs/ and we shouldn't skip, rewrite the host
    if (path.startsWith('/docs/') && !shouldSkip) {
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise just upgrade to https
    return httpsUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation: check for impossible dates (e.g., 02/30)
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  if (month === 2 && day > (isLeapYear(year) ? 29 : 28)) {
    return 'N/A';
  }
  
  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
