/**
 * Find words starting with the given prefix but excluding exceptions.
 * Uses regex with word boundaries and negative lookahead for exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!prefix.trim()) {
    return [];
  }
  
  // Split text into words using word boundaries
  const words = text.split(/\s+/);
  
  // Filter words that start with prefix and are not in exceptions
  const result: string[] = [];
  
  for (const word of words) {
    const cleanWord = word.replace(/[^\w]/g, ''); // Remove punctuation
    
    if (cleanWord.startsWith(prefix) && 
        !exceptions.includes(cleanWord) && 
        cleanWord.length > prefix.length) {
      result.push(cleanWord);
    }
  }
  
  return result;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookbehind to require preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!token.trim()) {
    return [];
  }
  
  const result: string[] = [];
  const tokenLen = token.length;
  
  // Search through the text for token occurrences
  for (let i = 0; i <= text.length - tokenLen; i++) {
    const substring = text.substring(i, i + tokenLen);
    
    if (substring === token) {
      // Check if it's preceded by a digit and not at the start
      if (i > 0 && /\d/.test(text[i - 1])) {
        // Return the token with the preceding digit
        result.push(text.substring(i - 1, i + tokenLen));
      }
    }
  }
  
  return result;
}

/**
 * Validate strong passwords.
 * Requirements: 10+ chars, uppercase, lowercase, digit, symbol, no whitespace,
 * no immediate repeated sequences (like 'abab').
 */
export function isStrongPassword(value: string): boolean {
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Alternative check for simple repeated sequences like abab
  for (let i = 0; i < value.length - 4; i++) {
    const segment1 = value.substring(i, i + 2);
    const segment2 = value.substring(i + 2, i + 4);
    if (segment1 === segment2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand :: notation).
 * Excludes IPv4 addresses to prevent false positives.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  const ipv6Patterns = [
    // Full IPv6 (8 groups of hex digits)
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // Compressed IPv6 with ::
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/,
    /:(?:[0-9a-fA-F]{1,4}:){1,7}/,
    // Various compressed forms
    /(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}/,
    /(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}/,
    /(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}/,
    /::1/,
    /::/
  ];
  
  // First check if it contains any IPv6 pattern
  const hasIPv6 = ipv6Patterns.some(pattern => pattern.test(value));
  
  if (!hasIPv6) {
    return false;
  }
  
  // Make sure it's not just IPv4
  const ipv4Pattern = /^(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)$/;
  
  // If the entire string is just an IPv4 address and nothing else, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  return true;
}