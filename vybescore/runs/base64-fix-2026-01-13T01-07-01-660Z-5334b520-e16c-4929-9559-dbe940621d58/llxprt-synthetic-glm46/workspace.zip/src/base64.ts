/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet and includes padding '=' characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
const VALID_BASE64_CHARS = 'A-Za-z0-9+/';
const PADDING_ERROR_MSG = 'Invalid Base64 input: incorrect padding';
const ALPHABET_ERROR_MSG = 'Invalid Base64 input: contains characters outside the Base64 alphabet';
const DECODE_ERROR_MSG = 'Failed to decode Base64 input';

export function decode(input: string): string {
  // First, count padding characters at the end
  const paddingMatch = input.match(/=+$/);
  const paddingCount = paddingMatch ? paddingMatch[0].length : 0;
  
  // Check for invalid padding (more than 2 padding chars)
  if (paddingCount > 2) {
    throw new Error(PADDING_ERROR_MSG);
  }
  
  // Check for invalid Base64 characters (allowing only standard alphabet chars with padding at the end)
  const base64Pattern = new RegExp(`^[${VALID_BASE64_CHARS}]*={0,${paddingCount}}$`);
  if (!base64Pattern.test(input)) {
    throw new Error(ALPHABET_ERROR_MSG);
  }
  
  // Check for invalid padding placement
  if (paddingMatch) {
    // Count the number of non-padding characters
    const nonPaddingLength = input.replace(/=+$/, '').length;
    
    // Check for invalid padding placement based on padding count
    if (paddingCount === 1 && nonPaddingLength % 4 !== 3) {
      throw new Error(PADDING_ERROR_MSG);
    }
    if (paddingCount === 2 && nonPaddingLength % 4 !== 2) {
      throw new Error(PADDING_ERROR_MSG);
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error(DECODE_ERROR_MSG);
  }
}
