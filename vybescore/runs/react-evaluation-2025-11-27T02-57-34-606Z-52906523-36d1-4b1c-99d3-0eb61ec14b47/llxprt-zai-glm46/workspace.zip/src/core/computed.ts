/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  notifyObservers
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = equal === true ? Object.is : (equal === false || equal === undefined) ? undefined : equal
  
  // This is the subject that other observers can depend on
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }
  
  // This observer tracks dependencies and recomputes when they change
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
    dependencies: new Set(),
  }
  
  const getter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      subject.observers.add(activeObs)
    }
    return subject.value
  }
  
  // Override updateFn to handle dependency tracking and notifications
  observer.updateFn = (prevValue?: T) => {
    // Compute new value
    const newValue = updateFn(prevValue)
    
    // Check if value actually changed
    const hasChanged = equalFn ? !equalFn(subject.value, newValue) : subject.value !== newValue
    
    if (hasChanged) {
      subject.value = newValue
      observer.value = newValue
      // Notify any observers that depend on this computed value
      notifyObservers(subject)
    }
    
    return newValue
  }
  
  // Initial computation
  updateObserver(observer)
  
  return getter
}
