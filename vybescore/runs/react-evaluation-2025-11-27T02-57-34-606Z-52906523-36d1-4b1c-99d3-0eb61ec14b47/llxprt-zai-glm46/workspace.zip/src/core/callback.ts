/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      if (observer.disposed) return prevValue as T
      return updateFn(prevValue)
    },
    disposed: false,
    dependencies: new Set(),
  }
  
  // Run the effect immediately to establish dependencies
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Remove from all dependencies
    observer.dependencies?.forEach(subject => {
      subject.observers.delete(observer as ObserverR)
    })
    observer.dependencies?.clear()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
