#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import type { ReportData, ReportFormat } from '../types.js';
import { renderReport } from '../formatters.js';

function parseArguments(): {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
    process.exit(1);
  }

  const dataFile = args[0];
  let format: ReportFormat = 'text';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Skip the first argument (data file) and parse the rest
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      format = formatValue as ReportFormat;
      i++; // Skip the next argument since it's the format value
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the next argument since it's the output path value
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Format is required. Use --format <markdown|text>');
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: data must be an object');
  }

  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string' || !obj.title) {
    throw new Error('Invalid JSON: title is required and must be a string');
  }

  if (typeof obj.summary !== 'string' || !obj.summary) {
    throw new Error('Invalid JSON: summary is required and must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: entries is required and must be an array');
  }

  const entries = obj.entries as unknown[];
  for (const entry of entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON: each entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || !entryObj.label) {
      throw new Error('Invalid JSON: each entry must have a label');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid JSON: each entry must have an amount as number');
    }
  }

  return obj as unknown as ReportData;
}

async function main(): Promise<void> {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments();

    // Read and parse JSON data
    let rawData: unknown;
    try {
      const fileContent = await readFile(dataFile, 'utf-8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error parsing JSON: ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error reading file: ${error.message}`);
      } else {
        console.error('Unknown error occurred');
      }
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(rawData);

    // Generate report
    const output = renderReport(format, reportData, { includeTotals });

    // Write output
    if (outputPath) {
      try {
        await writeFile(resolve(outputPath), output, 'utf-8');
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error writing to output file: ${error.message}`);
        } else {
          console.error('Unknown error occurred while writing output');
        }
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exit(1);
});
