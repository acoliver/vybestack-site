import type { ReportData, ReportOptions } from '../types.js';

export function renderText(data: ReportData, options: ReportOptions): string {
  let output = `${data.title}\n${data.summary}\nEntries:\n`;

  for (const entry of data.entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `Total: $${total.toFixed(2)}\n`;
  }

  return output;
}