import type { ReportFormat, ReportData, ReportOptions } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

export const formatters = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

export function renderReport(
  format: ReportFormat,
  data: ReportData,
  options: ReportOptions,
): string {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter(data, options);
}