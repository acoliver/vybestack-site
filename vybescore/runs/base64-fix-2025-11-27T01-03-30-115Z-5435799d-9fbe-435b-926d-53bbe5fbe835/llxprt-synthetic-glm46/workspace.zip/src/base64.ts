/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Remove whitespace (optional in Base64 spec)
  const cleaned = input.replace(/\s/g, '');
  
  // Basic validation: check for valid Base64 characters
  if (!/^[A-Za-z0-9+/]*=*$/.test(cleaned)) {
    throw new Error('Invalid Base64 characters in input');
  }
  
  // Padding validation: only 0, 1, or 2 padding characters allowed
  const paddingCount = cleaned.length - cleaned.replace(/=/g, '').length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 padding');
  }
  
  // Padding must be at the end
  if (paddingCount > 0 && !/={1,2}$/.test(cleaned)) {
    throw new Error('Invalid Base64 padding position');
  }
  
  try {
    return Buffer.from(cleaned, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
