/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes proper padding with '=' characters when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and throws on invalid input.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Ensure proper padding
  const normalized = input.replace(/\s/g, ''); // Remove whitespace
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  const padded = normalized + '='.repeat(paddingNeeded);

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}