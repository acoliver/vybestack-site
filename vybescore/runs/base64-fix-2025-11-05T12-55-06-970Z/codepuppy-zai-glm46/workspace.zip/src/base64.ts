/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  // Use standard Base64 encoding with padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }
  
  // Validate input is proper Base64 format
  // Base64 regex: only allows A-Z, a-z, 0-9, +, /, and optional = padding at end
  // Allow up to 2 = signs for the regex validation so we can check padding rules separately
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    // Check if it fails because of too much padding
    const tooMuchPadding = /^[A-Za-z0-9+/]*={3,}$/.test(input);
    if (tooMuchPadding) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check padding rules: only allowed at end and at most 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    
    // Total length must be divisible by 4 when padding is present
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  } else {
    // If no padding, allow lengths that are not divisible by 4 (will be padded automatically)
    // This accepts inputs like "YQ" which should be treated as "YQ=="
    if (input.length % 4 === 1) {
      // Length 1 mod 4 can never be valid Base64
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    // Add missing padding if needed (Buffer.from can handle this)
    const paddedInput = input.padEnd(Math.ceil(input.length / 4) * 4, '=');
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
