/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 pattern that handles:
  // - Standard format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Compressed format with :: 
  // - Mixed format with embedded IPv4
  // - Loopback ::1
  // But excludes IPv4 addresses
  const ipv6Pattern = /\b(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}\b|(?:[0-9A-Fa-f]{1,4}:){1,7}:|(?:[0-9A-Fa-f]{1,4}:){1,6}:[0-9A-Fa-f]{1,4}|(?:[0-9A-Fa-f]{1,4}:){1,5}(?::[0-9A-Fa-f]{1,4}){1,2}|(?:[0-9A-Fa-f]{1,4}:){1,4}(?::[0-9A-Fa-f]{1,4}){1,3}|(?:[0-9A-Fa-f]{1,4}:){1,3}(?::[0-9A-Fa-f]{1,4}){1,4}|(?:[0-9A-Fa-f]{1,4}:){1,2}(?::[0-9A-Fa-f]{1,4}){1,5}|[0-9A-Fa-f]{1,4}:(?:(?::[0-9A-Fa-f]{1,4}){1,6})|:(?:(?::[0-9A-Fa-f]{1,4}){1,7}|:)|fe80:(?::[0-9A-Fa-f]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])|([0-9A-Fa-f]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])/;
  
  // First ensure it's not an IPv4 address
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  return ipv6Pattern.test(value);
}

/**
 * Match words starting with the prefix but excluding banned words.
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }

  // Create a regex pattern to find words starting with the prefix
  // \b ensures we match whole words only
  // \w+ matches the rest of the word characters
  const pattern = new RegExp(`\\b${prefix}\\w+`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions and remove duplicates
  const filteredWords = [...new Set(
    matches
      .filter(word => !exceptionsLower.includes(word.toLowerCase()))
  )];
  
  return filteredWords;
}

/**
 * Find occurrences of token that appear after a digit and not at string start.
 * Return occurrences where the token appears after a digit and not at the start of the string (use lookaheads/lookbehinds).
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Look for token that has a digit before it and is not at the start of the string
  // Use positive lookbehind to check for digit before token, and include the digit in the match
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Remove duplicates and return
  return [...new Set(matches)];
}

/**
 * Check if password meets strong criteria.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Minimum length check
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }

  // Check for repeated sequences (like abab, ababab)
  for (let i = 0; i < value.length - 3; i++) {
    const seq1 = value.substring(i, i + 2);
    const seq2 = value.substring(i + 2, i + 4);
    if (seq1 === seq2) {
      return false;
    }
  }

  return true;
}