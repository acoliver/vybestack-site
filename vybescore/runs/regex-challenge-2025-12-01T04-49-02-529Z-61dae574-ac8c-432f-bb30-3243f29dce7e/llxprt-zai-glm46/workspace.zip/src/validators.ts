export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to RFC 5322-ish rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional validation rules
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  if (value.startsWith('@') || value.endsWith('@')) {
    return false;
  }
  
  // Domain cannot have underscores
  if (value.includes('_@') || value.includes('@_') || value.includes('_.') || value.includes('._')) {
    return false;
  }
  
  // Cannot have consecutive dots in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('..')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common separators and optional +1.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters for validation
  let digits = value.replace(/\D/g, '');
  
  // Check for extensions if allowed
  if (options?.allowExtensions) {
    const extPattern = /(?:ext\.?|extension|x)\s*\d+$/i;
    const phoneWithoutExt = value.replace(extPattern, '').trim();
    digits = phoneWithoutExt.replace(/\D/g, '');
  }
  
  return validateUSPhoneDigits(digits);
}

/**
 * Helper function to validate just the digits of a US phone number
 */
function validateUSPhoneDigits(digits: string): boolean {
  // Handle optional +1 country code
  if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits for standard US phone numbers
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile/landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits in total
 * - When country code is omitted, number must begin with trunk prefix 0
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all whitespace and hyphens for validation, but keep track for format checking
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with all components
  // ^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$
  // Explanation:
  // (?:\+54)? - Optional country code
  // (?:0)? - Optional trunk prefix
  // (?:9)? - Optional mobile indicator
  // ([1-9]\d{1,3}) - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8}) - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check if it matches the basic pattern
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Check the format rules more carefully
  const hasCountryCode = cleanValue.startsWith('+54');
  
  // When country code is omitted, must begin with trunk prefix 0
  if (!hasCountryCode && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Validate that separators are only single spaces or hyphens
  if (value !== cleanValue) {
    const invalidSeparators = /[^\s-]/g;
    const hasInvalidSeparators = invalidSeparators.test(value.replace(/\+54|\d/g, ''));
    if (hasInvalidSeparators) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Trim whitespace and check if empty
  const trimmedValue = value.trim();
  if (!trimmedValue) {
    return false;
  }

  // Unicode letter pattern that includes:
  // \p{L} - Any kind of letter from any language
  // \p{M} - Combining marks (accents, diacritics)
  // apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if the name contains only allowed characters
  if (!nameRegex.test(trimmedValue)) {
    return false;
  }

  // Check for invalid patterns:
  // - No consecutive hyphens or apostrophes
  // - No starting or ending hyphens/apostrophes
  // - No numbers or special symbols
  if (/[-']{2,}/.test(trimmedValue)) {
    return false;
  }

  if (trimmedValue.match(/^['\s-]+|['\s-]+$/)) {
    return false;
  }

  // Check for digits
  if (/\d/.test(trimmedValue)) {
    return false;
  }

// Check for obvious invalid symbols (excluding allowed ones)
  const invalidSymbols = /[!@#$%^&*()_+=\\[\\]{}|\\:";<>,.?\/`~]/;
  if (invalidSymbols.test(trimmedValue)) {
    return false;
  }

  // Check for names that are too short (at least 2 characters after trimming)
  const nameWithoutSpaces = trimmedValue.replace(/\s+/g, '');
  if (nameWithoutSpaces.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }

  // Check length for different card types
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexRegex = /^3[47]\d{13}$/;

  const isValidFormat = visaRegex.test(cleanNumber) || 
                       mastercardRegex.test(cleanNumber) || 
                       amexRegex.test(cleanNumber);

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.split('').map(Number);
  
  // Double every second digit from the right
  for (let i = digits.length - 2; i >= 0; i -= 2) {
    let doubled = digits[i] * 2;
    if (doubled > 9) {
      doubled = doubled - 9;
    }
    digits[i] = doubled;
  }
  
  // Sum all digits
  const sum = digits.reduce((acc, digit) => acc + digit, 0);
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}