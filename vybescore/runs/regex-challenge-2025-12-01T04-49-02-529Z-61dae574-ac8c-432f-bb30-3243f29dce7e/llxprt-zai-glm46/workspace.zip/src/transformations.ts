/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 * Capitalizes the first character of each sentence (after .?!), inserts exactly one space between sentences,
 * and collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // First, normalize spacing around sentence endings
  let result = text.replace(/\s*([.!?])\s*/g, '$1 ');
  
  // Remove extra spaces
  result = result.replace(/\s+/g, ' ');
  
  // Trim leading and trailing spaces
  result = result.trim();
  
  // Capitalize first letter of each sentence
  return result.replace(/(?:^|[.!?]\s+)([a-z])/g, (match) => {
    return match.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Returns all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // URL regex pattern
  const urlRegex = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+[^\s<>"'.!?,:;]*/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.!?,;:]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Upgrade http:// URLs to https://.
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // Replace http:// with https://, but avoid matching https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs to use docs subdomain and upgrade to https.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Pattern to match URLs and capture components
const urlPattern = new RegExp('(https?://)([^/\\s]+)(/[^\\s]*)', 'g');
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should rewrite the host
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !path.includes('/cgi-bin/') && 
      !path.includes('?') &&
      !path.includes('&') &&
      !path.includes('=') &&
      !/\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#]|$)/.test(path);
    
    if (shouldRewriteHost) {
      // Rewrite host to docs.example.com
      const newHost = 'docs.example.com';
      return newScheme + newHost + path;
    }
    
    // Just upgrade scheme
    return newScheme + host + path;
  });
}

/**
 * Extract year from mm/dd/yyyy format.
 * Return the four-digit year for mm/dd/yyyy. If the string doesn't match that format or month/day are invalid, return 'N/A'.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, month, day, year] = dateMatch;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  
  if (monthNum === 2 && isLeapYear) {
    if (dayNum < 1 || dayNum > 29) {
      return 'N/A';
    }
  } else {
    if (dayNum < 1 || dayNum > daysInMonth[monthNum - 1]) {
      return 'N/A';
    }
  }
  
  return year;
}