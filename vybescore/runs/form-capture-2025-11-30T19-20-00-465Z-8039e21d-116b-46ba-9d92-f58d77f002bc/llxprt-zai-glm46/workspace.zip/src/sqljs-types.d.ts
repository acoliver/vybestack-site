declare module 'sql.js' {
  export interface QueryResult {
    columns: string[];
    values: unknown[][];
  }

  export interface DatabaseRunResult {
    columns: string[];
    values: unknown[][];
  }

  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string, ...params: unknown[]): DatabaseRunResult;
    exec(sql: string): QueryResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export class Statement {
    run(...params: unknown[]): DatabaseRunResult;
    get(): unknown;
    all(): unknown[];
    free(): void;
  }

  export interface SqlJsStatic {
    Database: typeof Database;
  }

  export default function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
}