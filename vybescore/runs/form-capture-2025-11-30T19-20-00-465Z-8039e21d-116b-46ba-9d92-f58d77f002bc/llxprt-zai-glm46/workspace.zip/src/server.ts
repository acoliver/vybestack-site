import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import type { Database } from 'sql.js';

// Import SQL.js types
/// <reference path="./sqljs-types.d.ts" />

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormCaptureApp {
  private app: express.Application;
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
    this.initializeDatabase();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, '..', 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load or create database
      let dbBuffer: Uint8Array | null = null;
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        dbBuffer = new Uint8Array(dbFile);
      }

      // Load sql.js WASM module and create database
      const SQL = await import('sql.js');
      const { default: initSqlJs } = SQL;
      const SQLLib = await initSqlJs();
      this.db = new SQLLib.Database(dbBuffer || undefined);

      // Initialize schema if needed
      if (this.db) {
        const schema = fs.readFileSync(
          path.join(__dirname, '..', 'db', 'schema.sql'),
          'utf8'
        );
        this.db.run(schema);
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      process.exit(1);
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;

    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateFormData(formData: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!formData[field] || formData[field].trim() === '') {
        errors.push({
          field,
          message: `${field.replace(/([A-Z])/g, ' $1').trim()} is required`
        });
      }
    }

    // Email validation
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    // Phone validation (allow international formats)
    if (formData.phone && !/^[+]?[\d\s\-()]+$/.test(formData.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }

    // Postal code validation (alphanumeric)
    if (formData.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }

    return errors;
  }

  private setupRoutes(): void {
    // Home page - form
    this.app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        formData: null
      });
    });

    // Form submission
    this.app.post('/submit', (req, res) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateFormData(formData);

      if (errors.length > 0) {
        // Validation failed - re-render form with errors
        res.status(400).render('form', {
          errors: errors,
          formData: formData
        });
        return;
      }

      // Validation passed - save to database
      try {
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);

        stmt.free();
        this.saveDatabase();

        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Failed to save submission:', error);
        res.status(500).render('form', {
          errors: [{ field: 'general', message: 'Failed to save your submission. Please try again.' }],
          formData: formData
        });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req, res) => {
      // Get the most recent submission to personalize the thank you message
      let firstName = 'friend';
      try {
        if (this.db) {
          const stmt = this.db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
          const result = stmt.get() as { first_name: string } | undefined;
          stmt.free();
          if (result) {
            firstName = result.first_name;
          }
        }
      } catch (error) {
        console.error('Failed to get recent submission:', error);
      }

      res.render('thank-you', { firstName });
    });
  }

  public start(port: number = 3535): void {
    this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }

  public async stop(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    console.log('Server stopped gracefully');
  }
}

// Start the server
const app = new FormCaptureApp();
const port = parseInt(process.env.PORT || '3535', 10);

app.start(port);

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await app.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await app.stop();
  process.exit(0);
});

export default app;