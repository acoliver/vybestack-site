import type { FormatHandler } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatHandlers: Record<string, FormatHandler> = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

export type SupportedFormat = keyof typeof formatHandlers;