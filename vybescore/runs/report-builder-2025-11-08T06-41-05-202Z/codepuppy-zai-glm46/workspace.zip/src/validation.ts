import type { ReportData, ReportEntry } from './types.js';

function isReportEntry(obj: unknown): obj is ReportEntry {
  return (
    typeof obj === 'object' &&
    obj !== null &&
    'label' in obj &&
    'amount' in obj &&
    typeof (obj as ReportEntry).label === 'string' &&
    typeof (obj as ReportEntry).amount === 'number'
  );
}

export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!('title' in obj) || typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (!('summary' in obj) || typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!('entries' in obj) || !Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    if (!isReportEntry(entries[i])) {
      throw new Error(
        `Invalid JSON: entry at index ${i} is invalid. Each entry must have a "label" (string) and "amount" (number)`
      );
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries as ReportEntry[],
  };
}