#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import type { ReportData } from '../types.js';
import { formatHandlers } from '../formats/index.js';
import { validateReportData } from '../validation.js';
import { parseCliArgs, type CliArgs } from './args.js';

async function readJsonFile(filePath: string): Promise<unknown> {
  try {
    const content = await readFile(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw new Error(`Error reading file ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

async function writeOutput(content: string, outputPath?: string): Promise<void> {
  if (outputPath) {
    try {
      await writeFile(outputPath, content, 'utf-8');
    } catch (error) {
      throw new Error(`Error writing to ${outputPath}: ${error instanceof Error ? error.message : String(error)}`);
    }
  } else {
    console.log(content);
  }
}

function getSupportedFormats(): string[] {
  return Object.keys(formatHandlers);
}

async function main(): Promise<void> {
  try {
    const args: CliArgs = parseCliArgs(process.argv);

    // Validate format
    const supportedFormats = getSupportedFormats();
    if (!supportedFormats.includes(args.format)) {
      throw new Error(`Unsupported format: ${args.format}. Supported formats: ${supportedFormats.join(', ')}`);
    }

    // Read and validate JSON data
    const rawData = await readJsonFile(args.dataFile);
    const reportData: ReportData = validateReportData(rawData);

    // Render report
    const formatter = formatHandlers[args.format];
    const output = formatter(reportData, { includeTotals: args.includeTotals });

    // Write output
    await writeOutput(output, args.outputPath);

    // Exit successfully
    process.exit(0);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

// Handle unhandled promise rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Run main function
main();