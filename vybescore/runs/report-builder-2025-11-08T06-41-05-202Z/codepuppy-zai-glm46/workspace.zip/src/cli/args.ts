export interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseCliArgs(args: string[]): CliArgs {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const result: CliArgs = {
    dataFile: args[2],
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  let i = 3;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Error: --format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Error: --output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      throw new Error(`Error: Unknown argument: ${arg}`);
    }
    i++;
  }

  if (!result.format) {
    throw new Error('Error: --format is required');
  }

  return result;
}