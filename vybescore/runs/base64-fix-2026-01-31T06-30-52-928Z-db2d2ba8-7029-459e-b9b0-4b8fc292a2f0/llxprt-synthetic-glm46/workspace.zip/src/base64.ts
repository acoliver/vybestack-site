/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const BASE64_ERROR_MSG = 'Failed to decode Base64 input';
const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;
const PADDING_PATTERN = /={1,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Check for invalid characters in Base64
  if (!BASE64_PATTERN.test(input)) {
    throw new Error(BASE64_ERROR_MSG);
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    // Additional validation: if decoding didn't consume all bytes, the input was invalid
    const decodedBase64 = Buffer.from(result, 'utf8').toString('base64');
    const normalizedInput = input.replace(PADDING_PATTERN, '');
    const normalizedDecoded = decodedBase64.replace(PADDING_PATTERN, '');
    
    if (normalizedInput !== normalizedDecoded) {
      throw new Error(BASE64_ERROR_MSG);
    }
    
    return result;
  } catch (error) {
    throw new Error(BASE64_ERROR_MSG);
  }
}
