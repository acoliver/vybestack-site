export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts: name+tag@example.co.uk format
 * Rejects: double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in local part or domain
  const [local, domain] = value.split('@');
  if (local.endsWith('.') || domain.endsWith('.') || domain.startsWith('.')) {
    return false;
  }
  
  // Check for underscore in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: area codes starting with 0 or 1, too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[\s\-.()]/g, '');
  
  const phoneRegex = /^(\+1)?([2-9]\d{2})(\d{3})(\d{4})(x\d+)?$/;
  
  if (!phoneRegex.test(cleaned)) {
    return false;
  }
  
  const withoutCountry = cleaned.replace(/^\+1/, '');
  const mainNumber = withoutCountry.replace(/x\d+$/, '');
  
  if (mainNumber.length < 10) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber: 6-8 digits
 * - When no country code, must have trunk prefix 0
 * - Separators: space or hyphen
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean up separators
  const cleaned = value.replace(/[-]/g, ' ').replace(/\s+/g, ' ').trim();
  
  // Pattern for Argentine phone numbers
  // With country code: +54 area subscriber (subscriber can be split into parts by spaces)
  // With trunk prefix: 0 area subscriber
  // Optional mobile indicator 9 after country/trunk
  
  // Try to match and validate
  const fullPattern = /^(\+54|0)\s*(9\s*)?([1-9]\d{1,3})\s+((?:\d+\s*)+)$/;
  const match = cleaned.match(fullPattern);
  
  if (!match) {
    return false;
  }
  
  const [, countryOrTrunk, , areaCode, subscriberParts] = match;
  
  // Check trunk prefix requirement (if no +54, must have 0)
  if (countryOrTrunk !== '+54' && countryOrTrunk !== '0') {
    return false;
  }
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Clean up subscriber number
  const subscriber = subscriberParts.replace(/\s/g, '');
  
  // Validate subscriber length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Ensure subscriber is all digits
  if (!/^\d+$/.test(subscriber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and other symbols
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for suspicious patterns like multiple symbols in sequence
  if (/[Æ]/.test(value) && /\d/.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Supports: Visa (4), Mastercard (5), AmEx (3)
 * Validates: Prefix, length, and Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');
  
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const cardRegex = /^(?:4[0-9]{12}(?:[0-9]{3})?|(?:5[1-5][0-9]{2}|2[2-7][0-9]{2})[0-9]{12}|3[47][0-9]{13})$/;

  if (!cardRegex.test(cleaned)) {
    return false;
  }

  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn checksum on card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
