/**
 * Finds words starting with prefix, excluding words in exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[1];
    // Only include if not in exceptions
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Finds token occurrences that appear after a digit and not at the start of string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token preceded by digit, capturing the digit as well
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates password strength:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, 1212)
  // A sequence of 2-4 characters that repeats immediately
  for (let i = 2; i <= 4; i++) {
    const repeatedPattern = new RegExp(`(.{${i}})\\1`);
    if (repeatedPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::).
 * Excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (including shorthand ::)
  // Must have colons and hex digits
  // Should not match IPv4
  
  // First, exclude IPv4
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // This might be an IPv4-mapped IPv6, so we need more careful checking
    // Check if it's purely IPv4
    const pureIPv4 = /^\s*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\s*$/.test(value);
    if (pureIPv4) {
      return false;
    }
  }
  
  // IPv6 patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const ipv6FullPattern = /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with shorthand :: (double colon)
  const ipv6ShorthandPattern = /\b([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6EmbeddedIPv4 = /\b([0-9a-fA-F]{0,4}:)*::([0-9a-fA-F]{0,4}:)*\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  return ipv6FullPattern.test(value) || ipv6ShorthandPattern.test(value) || ipv6EmbeddedIPv4.test(value);
}
