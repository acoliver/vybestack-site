/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes after . ? !
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: collapse multiple spaces to one
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Ensure space after sentence endings
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first letter
  normalized = normalized.replace(/^[a-z]/, c => c.toUpperCase());
  
  // Capitalize after sentence boundaries, but be careful with abbreviations
  // Common abbreviations that don't end sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'eg', 'ie', 'St', 'Ave', 'Blvd', 'Rd', 'Lt', 'Col', 'Gen', 'Rep', 'Sen', 'Gov'];
  
  // Split on sentence boundaries, but not after abbreviations
  const sentences = normalized.split(/(?<=[.!?])\s+/);
  
  const capitalized = sentences.map((sentence, index) => {
    if (index === 0 || sentence.length === 0) {
      return sentence;
    }
    
    // Check if previous sentence ended with an abbreviation
    const prevSentence = sentences[index - 1];
    const lastWord = prevSentence.split(' ').pop()?.replace(/[.,!?]$/, '') || '';
    
    if (abbreviations.includes(lastWord)) {
      return sentence.charAt(0).toLowerCase() + sentence.slice(1);
    }
    
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  return capitalized.join(' ');
}

/**
 * Extracts all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: scheme://domain/path?query#fragment
  const urlPattern = /https?:\/\/[^\s<>"(){}|[\]\\^`]+[^\s<>"(){}|[\]\\^`.,!?;:]/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Converts all http:// URLs to https://
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrade to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/[^\s<>"(){}|[\]\\^`]*)/g, (match, path) => {
    // Check for dynamic hints or legacy extensions
    const skipHostRewrite = /\/cgi-bin|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      return `https://docs.example.com${path}`;
    }
    
    return `https://example.com${path}`;
  });
}

/**
 * Extracts year from mm/dd/yyyy format.
 * Returns 'N/A' for invalid formats or invalid dates.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, also check days per month)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Check for invalid day-month combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  if (isLeapYear) {
    daysInMonth[1] = 29;
  }
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
