#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData } from '../types/report.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (arg === '--output' && argv[i + 1]) {
      args.outputPath = argv[i + 1];
      i++; // Skip next arg as it's the path
    } else if (arg === '--format' && argv[i + 1]) {
      args.format = argv[i + 1];
      i++; // Skip next arg as it's the format
    } else if (!arg.startsWith('--')) {
      // First non-flag argument is the data file
      if (!args.dataFile) {
        args.dataFile = arg;
      }
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Missing data file argument');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Missing --format argument');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error('Error: Unsupported format. Allowed formats: markdown, text');
    process.exit(1);
  }
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const report = data as ReportData;

  if (typeof report.title !== 'string' || report.title.trim() === '') {
    throw new Error('Invalid JSON: missing or empty "title" field');
  }

  if (typeof report.summary !== 'string' || report.summary.trim() === '') {
    throw new Error('Invalid JSON: missing or empty "summary" field');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  if (report.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" array cannot be empty');
  }

  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    if (typeof entry.label !== 'string' || entry.label.trim() === '') {
      throw new Error(`Invalid JSON: entries[${i}].label must be a non-empty string`);
    }

    if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a finite number`);
    }
  }

  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const resolvedPath = resolve(filePath);
    const fileContent = readFileSync(resolvedPath, 'utf8');
    const jsonData = JSON.parse(fileContent);
    
    validateReportData(jsonData);
    
    return jsonData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        console.error(`Error: File not found - ${filePath}`);
      } else if (error.message.startsWith('JSON.parse')) {
        console.error('Error: Invalid JSON syntax');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read or parse data file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, includeTotals);
    case 'text':
      return renderText(data, includeTotals);
    default:
      throw new Error('Unsupported format');
  }
}

// Main execution
function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);

  const reportData = loadReportData(args.dataFile);
  
  try {
    const output = renderReport(reportData, args.format, args.includeTotals);
    
    if (args.outputPath) {
      const resolvedOutputPath = resolve(args.outputPath);
      writeFileSync(resolvedOutputPath, output, 'utf8');
    } else {
      process.stdout.write(output + '\n');
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to render report');
    }
    process.exit(1);
  }
}

main();
