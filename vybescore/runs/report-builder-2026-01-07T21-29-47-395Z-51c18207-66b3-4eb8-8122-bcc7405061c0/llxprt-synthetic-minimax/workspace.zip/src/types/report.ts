// Report data model types

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CLIOptions {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

export type FormatterType = 'markdown' | 'text';

export interface Formatter {
  render(data: ReportData, includeTotals: boolean): string;
}