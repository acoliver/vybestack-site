/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if the input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Trim leading/trailing whitespace
  normalized = normalized.trim();
  
  // Split by sentence boundaries (. ! ?)
  // We need to be careful about abbreviations (e.g., Mr., Mrs., Dr., etc.)
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'eg', 'ie', 'approx', 'dept', 'univ'];
  const abbrevPattern = new RegExp(`\\b(${abbreviations.join('|')})\\.\\s*$`, 'i');
  
  // Split by sentence terminators, but keep the delimiter
  const sentences: string[] = [];
  let current = '';
  
  for (let i = 0; i < normalized.length; i++) {
    current += normalized[i];
    
    if (normalized[i] === '.' || normalized[i] === '!' || normalized[i] === '?') {
      // Check if this might be an abbreviation
      const sentenceSoFar = current.trim();
      if (abbrevPattern.test(sentenceSoFar) && i < normalized.length - 1 && normalized[i + 1] === ' ') {
        // Likely an abbreviation, continue
        continue;
      }
      
      // Also check if next character is lowercase (likely abbreviation)
      if (i < normalized.length - 1 && normalized[i + 1] === ' ') {
        const nextChar = normalized[i + 2];
        if (nextChar && nextChar === nextChar.toLowerCase() && nextChar >= 'a' && nextChar <= 'z') {
          // Lowercase after space suggests abbreviation (e.g., "Mr. Smith")
          // But need to be more careful
          const words = sentenceSoFar.split(' ');
          const lastWord = words[words.length - 1].replace(/[.!?]$/, '');
          if (lastWord.length <= 3 && /^[A-Z][a-z]*$/.test(lastWord)) {
            // Short word ending with period, likely abbreviation
            continue;
          }
        }
      }
      
      sentences.push(current.trim());
      current = '';
    }
  }
  
  // Add any remaining text
  if (current.trim()) {
    sentences.push(current.trim());
  }
  
  // Capitalize first letter of each sentence and join with single space
  const result = sentences
    .map(sentence => {
      if (!sentence) return '';
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    })
    .join(' ');
  
  return result || normalized.charAt(0).toUpperCase() + normalized.slice(1);
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex
  // Matches http://, https://, and www. URLs
  // Handles domains, paths, query strings, fragments
  // Excludes trailing punctuation
  const urlRegex = /\b(?:https?:\/\/|www\.)[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s\])}.,;!?"']*)?(?:\?[^\s\])}.,;!?"']*)?(?:#[^\s\])}.,;!?"']*)?(?=\s|$|[.,;!?"'\]]|$)/g;

  const matches = text.match(urlRegex);

  if (!matches) {
    return [];
  }

  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;!?"'\]]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';

    // Check if this is example.com domain
    if (host === 'example.com' || host.startsWith('example.com:')) {
      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints that should prevent host rewrite
        const hasDynamicHint =
          path.includes('/cgi-bin/') ||
          path.includes('?') ||
          path.includes('&') ||
          path.includes('=') ||
          /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#]|$)/.test(path);

        if (!hasDynamicHint) {
          // Safe to rewrite host
          host = 'docs.example.com';
        }
      }
    }

    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Assume leap year for Feb
  const maxDays = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  // Validate year (reasonable range)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return yearStr;
}
