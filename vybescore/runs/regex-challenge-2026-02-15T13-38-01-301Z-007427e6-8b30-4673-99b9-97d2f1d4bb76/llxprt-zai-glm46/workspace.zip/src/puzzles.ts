/**
 * Match words starting with the prefix but excluding banned words.
 * Uses regex to find words and filter exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches
    .filter(word => !exceptionSet.has(word.toLowerCase()))
    .filter((word, index, self) => self.indexOf(word) === index); // Remove duplicates
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match digit followed by token (including the digit in the result)
  // and not at the start of the string
  const pattern = new RegExp(`(?:^|\\D)(\\d${escapedToken})(?=\\D|$)`, 'g');

  const matches: string[] = [];
  let match;

  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[1]);
  }

  return matches;
}

/**
 * Validate passwords according to security policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const sequence = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + 2 * len);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  // Also check for character repetition (aaa, bbbb, etc.)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true if the value contains an IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns:
  // 1. Full form: 8 groups of 1-4 hex digits separated by colons
  // 2. Compressed form with :: (double colon)
  // 3. Can have IPv4 mapped address at the end (::ffff:192.168.1.1)
  
  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Pattern.test(value) && !value.includes(':')) {
    return false;
  }
  
  // IPv6 patterns
  // Full form: 8 groups of hex digits
  const ipv6FullPattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed form with ::
  const ipv6CompressedPattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv6 with IPv4 at the end
  const ipv6MappedPattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv4-mapped IPv6 ::ffff:x.x.x.x
  const ipv4MappedPattern = /(?:^|\s|:)::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/i;
  
  // Check for any IPv6 pattern
  return ipv6FullPattern.test(value) ||
         ipv6CompressedPattern.test(value) ||
         ipv6MappedPattern.test(value) ||
         ipv4MappedPattern.test(value);
}
