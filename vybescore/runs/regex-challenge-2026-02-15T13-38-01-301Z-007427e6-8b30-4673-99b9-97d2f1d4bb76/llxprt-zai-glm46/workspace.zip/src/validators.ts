export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using regex.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@(?!.*\.\.)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  const [localPart, domain] = value.split('@');
  
  // No trailing dots in local part
  if (localPart.endsWith('.') || localPart.startsWith('.')) {
    return false;
  }
  
  // No double dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // No trailing dots in domain
  if (domain.endsWith('.') || domain.startsWith('.')) {
    return false;
  }
  
  // No double dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // Domain must have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if the original format is valid
  // Common formats: (212) 555-7890, 212-555-7890, 212.555.7890, 2125557890
  const validFormats = [
    /^\(\d{3}\)\s*\d{3}[-.]?\d{4}$/,       // (212) 555-7890 or (212)555-7890
    /^\d{3}[-.]?\d{3}[-.]?\d{4}$/,          // 212-555-7890 or 212.555.7890 or 2125557890
    /^\+1\s*\(\d{3}\)\s*\d{3}[-.]?\d{4}$/,  // +1 (212) 555-7890
    /^\+1\s*\d{3}[-.]?\d{3}[-.]?\d{4}$/     // +1 212-555-7890
  ];
  
  const isValidFormat = validFormats.some(regex => regex.test(value.trim()));
  
  return isValidFormat;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // Optional +54 or 54
  // Optional trunk prefix 0 (required if no country code)
  // Optional mobile indicator 9
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:(?:\+?54)?)(0)?[1-9]\d{0,2}(9)?\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Parse components
  let remaining = cleaned;
  
  // Strip country code
  if (remaining.startsWith('+54')) {
    remaining = remaining.substring(3);
  } else if (remaining.startsWith('54')) {
    remaining = remaining.substring(2);
  }
  
  // Check trunk prefix rule: if no country code, must have trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || (cleaned.startsWith('54') && cleaned.length > 10);
  const hasTrunkPrefix = remaining.startsWith('0');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Strip trunk prefix
  if (remaining.startsWith('0')) {
    remaining = remaining.substring(1);
  }
  
  // Strip mobile indicator if present
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Now remaining should be area code + subscriber number
  // Area code is 2-4 digits starting with 1-9
  // Subscriber number is 6-8 digits
  // Total should be 8-12 digits
  if (remaining.length < 8 || remaining.length > 12) {
    return false;
  }
  
  // Extract area code (first 2-4 digits)
  const areaCodeLength = Math.min(4, remaining.length - 6); // Ensure at least 6 digits for subscriber
  const areaCode = remaining.substring(0, areaCodeLength);
  
  // Area code must start with 1-9
  if (!/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  const subscriberNumber = remaining.substring(areaCodeLength);
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Must have at least 2 characters
  // Must contain at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one unicode letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with only special characters or spaces
  const trimmed = value.trim();
  if (trimmed.length < 2) {
    return false;
  }
  
  // Reject names that look like "X Æ A-12" (contains digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with consecutive special characters
  if (/'{2,}|-{2,}|\s{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Run Luhn checksum algorithm on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length: 13-19 digits
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check prefixes and lengths for different card types
  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(\d{3}(\d{3})?)?$/;
  if (visaRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{2})|(2[2-7][0-9]{2}))\d{12}$/;
  if (mastercardRegex.test(cleaned) && cleaned.length === 16) {
    return runLuhnCheck(cleaned);
  }
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleaned)) {
    return runLuhnCheck(cleaned);
  }
  
  return false;
}
