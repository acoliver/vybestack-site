import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Parse and validate page parameter
      let page = 1;
      if (pageParam !== undefined) {
        const parsedPage = Number(pageParam);
        if (!Number.isFinite(parsedPage) || parsedPage <= 0) {
          return res.status(400).json({ error: 'Page must be a positive integer' });
        }
        page = Math.floor(parsedPage);
      }

      // Parse and validate limit parameter
      let limit = 5; // default
      if (limitParam !== undefined) {
        const parsedLimit = Number(limitParam);
        if (!Number.isFinite(parsedLimit) || parsedLimit <= 0) {
          return res.status(400).json({ error: 'Limit must be a positive integer (max 100)' });
        }
        if (parsedLimit > 100) { // reasonable maximum
          return res.status(400).json({ error: 'Limit must be a positive integer (max 100)' });
        }
        limit = Math.floor(parsedLimit);
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error handling inventory request:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
