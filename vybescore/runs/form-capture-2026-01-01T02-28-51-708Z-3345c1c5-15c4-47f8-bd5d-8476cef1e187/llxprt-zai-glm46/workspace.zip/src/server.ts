import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm } from './validator.js';
import type { FormData } from './types.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// View engine setup
app.set('view engine', 'ejs');
// When running from dist, the views are in src/views
app.set('views', path.join(__dirname, '../src/views'));

// Routes
app.get('/', (_req: Request, res: Response): void => {
  res.render('index', { formData: {}, errors: [] });
});

interface SubmissionRequest extends Request {
  body: FormData;
}

app.post('/submit', async (req: SubmissionRequest, res: Response): Promise<void> => {
  const formData = req.body;
  
  const validation = validateForm(formData);
  
  if (!validation.valid) {
    res.status(400).render('index', {
      formData,
      errors: validation.errors,
    });
    return;
  }

  try {
    await insertSubmission(formData as FormData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('index', {
      formData,
      errors: [{ field: 'all', message: 'An error occurred. Please try again.' }],
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response): void => {
  res.render('thank-you');
});

// Error handler
app.use((err: Error, _req: Request, res: Response): void => {
  console.error(err.stack);
  res.status(500).send('Something broke!');
});

// Initialize database and start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Graceful shutdown
  const shutdown = async (signal: string): Promise<void> => {
    console.log(`\n${signal} received. Shutting down gracefully...`);
    server.close(() => {
      console.log('HTTP server closed.');
      closeDatabase();
      console.log('Database closed.');
      process.exit(0);
    });
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export default app;
