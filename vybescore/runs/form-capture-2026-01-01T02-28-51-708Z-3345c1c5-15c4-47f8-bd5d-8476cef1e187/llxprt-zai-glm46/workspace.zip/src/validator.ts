import type { FormData, ValidationResult, ValidationError } from './types.js';

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^[\d\s\-()+]+$/;
  if (!phoneRegex.test(phone)) {
    return { field: 'phone', message: 'Please enter a valid phone number' };
  }
  return null;
}

function validatePostalCode(postalCode: string): ValidationError | null {
  const postalRegex = /^[\d\w\s-]+$/;
  if (!postalRegex.test(postalCode)) {
    return { field: 'postalZipCode', message: 'Please enter a valid postal code' };
  }
  return null;
}

export function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields: Array<keyof FormData> = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvinceRegion',
    'postalZipCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field];
    if (!value) {
      errors.push({ field, message: `${field} is required` });
    }
  }

  // Email validation
  if (data.email) {
    const emailError = validateEmail(data.email);
    if (emailError) errors.push(emailError);
  }

  // Phone validation
  if (data.phone) {
    const phoneError = validatePhone(data.phone);
    if (phoneError) errors.push(phoneError);
  }

  // Postal code validation
  if (data.postalZipCode) {
    const postalError = validatePostalCode(data.postalZipCode);
    if (postalError) errors.push(postalError);
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}