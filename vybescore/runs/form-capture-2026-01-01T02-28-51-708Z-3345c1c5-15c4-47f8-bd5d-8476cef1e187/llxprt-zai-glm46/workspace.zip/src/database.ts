import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'node:fs';
import { dirname } from 'node:path';
import type { FormData, Submission } from './types.js';

const DB_PATH = 'data/submissions.sqlite';
const SCHEMA_PATH = 'db/schema.sql';

let db: Database | null = null;
let SQL: SqlJsStatic | null = null;

export async function initializeDatabase(): Promise<void> {
  SQL = await initSqlJs();

  const dbDir = dirname(DB_PATH);
  if (!existsSync(dbDir)) {
    mkdirSync(dbDir, { recursive: true });
  }

  if (existsSync(DB_PATH)) {
    const buffer = readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = readFileSync(SCHEMA_PATH, 'utf-8');
    db!.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  const data = db.export();
  const buffer = Buffer.from(data);
  writeFileSync(DB_PATH, buffer);
}

export function insertSubmission(formData: FormData): Submission {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city,
      state_province_region, postal_zip_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvinceRegion,
    formData.postalZipCode,
    formData.country,
    formData.email,
    formData.phone,
  ]);

  stmt.free();

  saveDatabase();

  const lastId = db.exec('SELECT last_insert_rowid() as id')[0].values[0][0] as number;
  
  return {
    ...formData,
    id: lastId,
    createdAt: new Date().toISOString(),
  };
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}