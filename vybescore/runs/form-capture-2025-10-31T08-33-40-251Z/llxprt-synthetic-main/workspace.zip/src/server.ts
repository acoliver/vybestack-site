import express, { Express, Request, Response } from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";

// Dynamic import for sql.js to avoid type issues
const SQL = (await import("sql.js")) as unknown;

// Convert ESM import to __dirname equivalent
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Interfaces
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Global variables
let db: unknown = null;
const dbPath = path.join(__dirname, "..", "data", "submissions.sqlite");

// Validation functions
const validateEmail = (email: string): boolean => {
  // Simple email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Accept alphanumeric字符串 with possible spaces
  // This allows codes like "SW1A 1AA" (UK) or "B1675" or "C1000" (Argentina)
  const postalRegex = /^[\w\s-]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
};

const validateRequired = (value: string): boolean => {
  return value.trim().length > 0;
};

const validateForm = (data: FormData): string[] => {
  const errors: string[] = [];

  if (!validateRequired(data.firstName)) {
    errors.push("First name is required");
  }

  if (!validateRequired(data.lastName)) {
    errors.push("Last name is required");
  }

  if (!validateRequired(data.streetAddress)) {
    errors.push("Street address is required");
  }

  if (!validateRequired(data.city)) {
    errors.push("City is required");
  }

  if (!validateRequired(data.stateProvince)) {
    errors.push("State / Province / Region is required");
  }

  if (!validateRequired(data.postalCode)) {
    errors.push("Postal / Zip code is required");
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push("Invalid postal code format");
  }

  if (!validateRequired(data.country)) {
    errors.push("Country is required");
  }

  if (!validateRequired(data.email)) {
    errors.push("Email is required");
  } else if (!validateEmail(data.email)) {
    errors.push("Invalid email format");
  }

  if (!validateRequired(data.phone)) {
    errors.push("Phone number is required");
  } else if (!validatePhone(data.phone)) {
    errors.push("Invalid phone number format");
  }

  return errors;
};

// Database operations
const initializeDatabase = async (): Promise<unknown> => {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load or create database
    let data: Uint8Array = new Uint8Array(0);
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    }

    // Initialize SQL.js
    const sqlJs = await (SQL as { initSqlJs(): Promise<{ Database: new (data?: Uint8Array) => unknown }> }).initSqlJs();
    const database = new sqlJs.Database(data);

    // Create table if it doesn't exist
    const schema = fs.readFileSync(
      path.join(__dirname, "..", "db", "schema.sql"),
      "utf8"
    );
    
    // Type casting to access run method
    const db = database as { run(sql: string): void };
    db.run(schema);

    return database;
  } catch (error) {
    console.error("Failed to initialize database:", error);
    throw error;
  }
};

const saveSubmission = (database: unknown, data: FormData): number => {
  try {
    // Type casting to access methods safely
    const db = database as {
      prepare(sql: string): { run(params: unknown[]): void; free(): void };
      exec(sql: string): { values: unknown[][] }[];
    };

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvince,
      data.postalCode,
      data.country,
      data.email,
      data.phone,
    ]);

    stmt.free();

    // Get the ID of the inserted submission
    const result = db.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  } catch (error) {
    console.error("Failed to save submission:", error);
    throw error;
  }
};

const persistDatabase = async (database: unknown): Promise<void> => {
  try {
    // Type casting to access export method
    const db = database as { export(): Uint8Array };
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error("Failed to persist database:", error);
    throw error;
  }
};

// Express app setup
const app: Express = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "..", "public")));

// Set view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "templates"));

// Routes
app.get("/", (req: Request, res: Response) => {
  res.render("form", {
    errors: [],
    values: {},
  });
});

app.post("/submit", async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || "",
      lastName: req.body.lastName || "",
      streetAddress: req.body.streetAddress || "",
      city: req.body.city || "",
      stateProvince: req.body.stateProvince || "",
      postalCode: req.body.postalCode || "",
      country: req.body.country || "",
      email: req.body.email || "",
      phone: req.body.phone || "",
    };

    const errors = validateForm(formData);

    if (errors.length > 0) {
      // Re-render form with errors
      res.status(400).render("form", {
        errors,
        values: formData,
      });
      return;
    }

    // Save the submission
    if (!db) {
      throw new Error("Database not initialized");
    }

    saveSubmission(db, formData);
    await persistDatabase(db);

    // Redirect to thank you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error("Error in submit:", error);
    res.status(500).send("Internal server error");
  }
});

app.get("/thank-you", (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || "friend";
  res.render("thank-you", { firstName });
});

// Start server and initialize database
const port = process.env.PORT || 3000;

let server: unknown = null;

const startServer = async (): Promise<void> => {
  try {
    db = await initializeDatabase();
    server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
};

// Graceful shutdown
const gracefulShutdown = async (): Promise<void> => {
  console.log("Shutting down gracefully...");
  
  if (server) {
    // Type casting to access close method
    const srv = server as { close(callback: () => void): void };
    srv.close(() => {
      console.log("Express server closed");
    });
  }
  
  if (db) {
    // Type casting to access close method
    const database = db as { close(): void };
    database.close();
    console.log("Database connection closed");
    process.exit(0);
  }
};

process.on("SIGTERM", gracefulShutdown);
process.on("SIGINT", gracefulShutdown);

// Start the server
startServer().catch((error) => {
  console.error("Failed to start application:", error);
  process.exit(1);
});

export { startServer, gracefulShutdown };