#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions, Formatter } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const parsed: CliArgs = {
    dataFile: '',
    format: '',
    outputPath: null,
    includeTotals: false
  };

  for (let i = 2; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsed.format = args[i + 1];
      i++; // Skip next arg
    } else if (arg === '--output' && i + 1 < args.length) {
      parsed.outputPath = args[i + 1];
      i++; // Skip next arg
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (!parsed.dataFile && !arg.startsWith('--')) {
      parsed.dataFile = arg;
    }
  }

  return parsed;
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    return false;
  }

  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string' || typeof obj.summary !== 'string') {
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    return false;
  }

  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      return false;
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || typeof entryObj.amount !== 'number') {
      return false;
    }
  }

  return true;
}

function getFormatter(format: string): Formatter {
  switch (format) {
    case 'markdown':
      return markdownFormatter;
    case 'text':
      return textFormatter;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArguments(process.argv);

    if (!args.dataFile) {
      console.error('Error: Data file path is required');
      process.exit(1);
    }

    if (!args.format) {
      console.error('Error: Format is required (--format <markdown|text>)');
      process.exit(1);
    }

    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading or parsing file ${args.dataFile}:`, error instanceof Error ? error.message : error);
      process.exit(1);
    }

    // Validate data structure
    if (!validateReportData(jsonData)) {
      console.error('Error: Invalid JSON data structure. Expected {title, summary, entries[{label, amount}]}');
      process.exit(1);
    }

    const reportData: ReportData = jsonData;
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };

    // Get formatter and render
    const formatter = getFormatter(args.format);
    const output = formatter.render(reportData, options);

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file ${args.outputPath}:`, error instanceof Error ? error.message : error);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : error);
    process.exit(1);
  }
}

main();