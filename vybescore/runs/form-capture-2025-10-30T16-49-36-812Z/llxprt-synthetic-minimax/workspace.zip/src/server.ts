import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// EJS setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Database setup
let db: Database | null = null;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
  });

  let buffer: Uint8Array | null = null;
  
  // Load existing database if it exists
  if (fs.existsSync(DB_PATH)) {
    buffer = new Uint8Array(fs.readFileSync(DB_PATH));
  }

  db = new SQL.Database(buffer);

  // Execute schema
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
  db.exec(schema);
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  }
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.first_name.trim()) {
    errors.first_name = 'First name is required';
  }
  if (!data.last_name.trim()) {
    errors.last_name = 'Last name is required';
  }
  if (!data.street_address.trim()) {
    errors.street_address = 'Street address is required';
  }
  if (!data.city.trim()) {
    errors.city = 'City is required';
  }
  if (!data.state_province.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  if (!data.postal_code.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  }
  if (!data.country.trim()) {
    errors.country = 'Country is required';
  }
  if (!data.email.trim()) {
    errors.email = 'Email is required';
  }
  if (!data.phone.trim()) {
    errors.phone = 'Phone number is required';
  }

  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (international formats)
  const phoneRegex = /^\+?[\d\s()\-]+$/;
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  const postalRegex = /^[A-Za-z0-9\s\-]+$/;
  if (data.postal_code && !postalRegex.test(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  return errors;
}

// Routes

// GET / - Render contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    data: {},
    title: 'Friendly Contact Form'
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    // Validation failed, re-render form with errors
    return res.status(400).render('form', { 
      errors, 
      data: formData,
      title: 'Friendly Contact Form'
    });
  }

  // Validation passed, save to database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.first_name,
      formData.last_name,
      formData.street_address,
      formData.city,
      formData.state_province,
      formData.postal_code,
      formData.country,
      formData.email,
      formData.phone
    ]);

    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (db) {
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;