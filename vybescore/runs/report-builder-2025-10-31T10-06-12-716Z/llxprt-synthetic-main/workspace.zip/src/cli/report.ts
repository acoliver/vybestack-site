#!/usr/bin/env node

import { readFile } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { exit } from 'node:process';

import { getFormatter } from '../utils/formatters.js';
import { parseCliArgs } from '../utils/parsers.js';
import { validateReportData } from '../utils/validation.js';

function main() {
  try {
    const args = parseCliArgs(process.argv);
    const formatter = getFormatter(args.format);

    // Read and parse JSON data file
    readFile(args.dataFile, 'utf8', (err, data) => {
      if (err) {
        console.error(`Error reading file: ${err.message}`);
        exit(1);
      }

      let parsedData;
      try {
        parsedData = JSON.parse(data);
      } catch (parseError) {
        console.error(`Error parsing JSON: ${(parseError as Error).message}`);
        exit(1);
      }

      let reportData;
      try {
        reportData = validateReportData(parsedData);
      } catch (validationError) {
        console.error(`Validation error: ${(validationError as Error).message}`);
        exit(1);
      }

      try {
        const output = formatter.render(reportData, {
          includeTotals: args.includeTotals,
          outputPath: args.outputPath,
        });

        if (args.outputPath) {
          // Write to file
          writeFile(args.outputPath, output)
            .then(() => {
              console.log(`Report written to ${args.outputPath}`);
            })
            .catch(writeError => {
              console.error(`Error writing output file: ${(writeError as Error).message}`);
              exit(1);
            });
        } else {
          // Write to stdout
          console.log(output);
        }
      } catch (renderError) {
        console.error(`Error rendering report: ${(renderError as Error).message}`);
        exit(1);
      }
    });
  } catch (argError) {
    console.error(`Argument error: ${(argError as Error).message}`);
    exit(1);
  }
}

main();
