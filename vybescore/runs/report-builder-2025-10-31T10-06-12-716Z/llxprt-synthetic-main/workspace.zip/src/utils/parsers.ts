import { FormatType } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseCliArgs(args: string[]): CliArgs {
  // Skip first two args (node command and script path)
  const processArgs = args.slice(2);

  if (processArgs.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = processArgs[0];

  const formatIndex = processArgs.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= processArgs.length) {
    throw new Error('Missing required --format argument');
  }

  const formatValue = processArgs[formatIndex + 1];
  if (formatValue !== 'markdown' && formatValue !== 'text') {
    throw new Error(`Unsupported format: ${formatValue}. Supported formats: markdown, text`);
  }

  const format = formatValue as FormatType;

  const outputIndex = processArgs.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < processArgs.length ? processArgs[outputIndex + 1] : undefined;

  const includeTotals = processArgs.includes('--includeTotals');

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}