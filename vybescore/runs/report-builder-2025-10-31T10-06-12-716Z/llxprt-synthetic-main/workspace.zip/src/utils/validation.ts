import { ReportData } from '../types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON data: Expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: Missing or invalid title field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: Missing or invalid summary field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: Missing or invalid entries field');
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: Entry ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: Entry ${i} has invalid label field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: Entry ${i} has invalid amount field`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries.map(entry => ({
      label: entry.label,
      amount: entry.amount,
    })),
  };
}