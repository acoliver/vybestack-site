import { ReportFormatter, ReportData, ReportOptions, ReportEntry } from '../types.js';

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

const calculateTotal = (entries: ReportEntry[]): number => {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
};

export const renderText: ReportFormatter = {
  render(data: ReportData, options: ReportOptions): string {
    const lines = [data.title, '', data.summary, '', 'Entries:', ''];

    data.entries.forEach(entry => {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    });

    if (options.includeTotals) {
      lines.push('', `Total: ${formatAmount(calculateTotal(data.entries))}`);
    }

    return lines.join('\n');
  },
};