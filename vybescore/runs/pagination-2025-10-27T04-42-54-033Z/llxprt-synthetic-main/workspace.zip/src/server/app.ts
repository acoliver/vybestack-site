import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;
      
      // Default values
      const defaultPage = 1;
      const defaultLimit = 5;
      const maxLimit = 50; // Prevent excessive values

      // Parse and validate page parameter
      let page = defaultPage;
      if (pageParam !== undefined) {
        if (!/^\d+$/.test(pageParam)) {
          return res.status(400).json({ error: 'Page parameter must be a positive integer' });
        }
        page = Number(pageParam);
        if (page <= 0) {
          return res.status(400).json({ error: 'Page parameter must be positive' });
        }
      }
      
      // Parse and validate limit parameter
      let limit = defaultLimit;
      if (limitParam !== undefined) {
        if (!/^\d+$/.test(limitParam)) {
          return res.status(400).json({ error: 'Limit parameter must be a positive integer' });
        }
        limit = Number(limitParam);
        if (limit <= 0) {
          return res.status(400).json({ error: 'Limit parameter must be positive' });
        }
        if (limit > maxLimit) {
          return res.status(400).json({ error: `Limit parameter cannot exceed ${maxLimit}` });
        }
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      console.error('Error in /inventory:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
