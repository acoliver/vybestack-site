declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): {
      run(...params: unknown[]): unknown;
      free(): void;
    };
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  export default function initSqlJs(config?: {
    locateFile?: (file: string) => string;
  }): Promise<SqlJsStatic>;
}