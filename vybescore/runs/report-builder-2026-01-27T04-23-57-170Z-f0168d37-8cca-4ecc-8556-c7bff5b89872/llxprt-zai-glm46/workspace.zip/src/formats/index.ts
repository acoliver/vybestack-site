/**
 * Format registry for report renderers
 */

import type { ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatMap: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const supportedFormats = Object.keys(formatMap);
