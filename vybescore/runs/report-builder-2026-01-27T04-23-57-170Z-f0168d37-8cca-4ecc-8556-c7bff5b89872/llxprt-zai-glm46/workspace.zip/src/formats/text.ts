/**
 * Text report formatter
 */

import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export const renderText: ReportRenderer = (data: ReportData, options: RenderOptions): string => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Optional totals
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push('');
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
