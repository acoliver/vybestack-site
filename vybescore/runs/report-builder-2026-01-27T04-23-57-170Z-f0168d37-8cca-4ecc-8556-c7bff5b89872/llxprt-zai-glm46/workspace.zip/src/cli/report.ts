#!/usr/bin/env node

/**
 * Report CLI entry point
 */

import * as fs from 'node:fs';

import { formatMap } from '../formats/index.js';
import type { RenderOptions } from '../types.js';
import { validateReportData } from '../utils/validation.js';

interface CliArgs {
  inputPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputPath = args[0];
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('--format argument is required');
  }
  const format = args[formatIndex + 1];

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : null;

  const includeTotals = args.includes('--includeTotals');

  return { inputPath, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Validate format
    if (!formatMap[args.format]) {
      console.error(`Error: Unsupported format "${args.format}". Supported formats: ${Object.keys(formatMap).join(', ')}`);
      process.exit(1);
    }

    // Read and parse input JSON
    let inputData: unknown;
    try {
      const content = fs.readFileSync(args.inputPath, 'utf-8');
      inputData = JSON.parse(content);
    } catch (err) {
      const error = err as NodeJS.ErrnoException | SyntaxError;
      if ('code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found: ${args.inputPath}`);
      } else if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file: ${args.inputPath}\n  ${error.message}`);
      } else {
        console.error(`Error: Failed to read file: ${args.inputPath}\n  ${error.message}`);
      }
      process.exit(1);
    }

    // Validate data structure
    const data = validateReportData(inputData);

    // Render report
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const renderer = formatMap[args.format];
    const output = renderer(data, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (err) {
    const error = err as Error;
    console.error(`Error: ${error.message}`);
    process.exit(1);
  }
}

main();
