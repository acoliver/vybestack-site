/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, removeDependencies, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let _disposed = false
  
  // Execute the callback initially to establish dependencies
  const prevObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    const newValue = updateFn(value)
    if (value === undefined || newValue !== value) {
      value = newValue
      observer.value = value
    }
  } finally {
    setActiveObserver(prevObserver)
  }
  
  // Override the observer's updateFn to call the callback
  observer.updateFn = (currentValue?: T): T => {
    if (_disposed) return value as T
    try {
      const newValue = updateFn(currentValue)
      if (value === undefined || newValue !== value) {
        value = newValue
        observer.value = value
      }
      return newValue
    } catch (error) {
      console.error('Error in callback update function:', error)
      return value as T
    }
  }
  
  // Return unsubscribe function
  return () => {
    if (!_disposed) {
      _disposed = true
      removeDependencies(observer)
    }
  }
}