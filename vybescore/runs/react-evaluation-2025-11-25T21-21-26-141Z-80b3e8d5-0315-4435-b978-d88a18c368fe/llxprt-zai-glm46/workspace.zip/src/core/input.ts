/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateDependents,
  addDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T>
  if (_equal === undefined) {
    equalFn = (a, b) => a === b
  } else if (typeof _equal === 'boolean') {
    equalFn = _equal ? (a, b) => a === b : () => false
  } else {
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Create a dummy observer for the input to be used in dependency tracking
  const inputObserver: Observer<T> = {
    name: options?.name ? `${options.name}-input` : 'input',
    value,
    updateFn: () => s.value,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this input as a dependency for the active observer
      addDependency(observer as any, inputObserver as any)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    inputObserver.value = nextValue
    if (!equalFn(prevValue, nextValue)) {
      // Update all observers that depend on this input
      updateDependents(inputObserver as any)
    }
    return s.value
  }

  return [read, write]
}