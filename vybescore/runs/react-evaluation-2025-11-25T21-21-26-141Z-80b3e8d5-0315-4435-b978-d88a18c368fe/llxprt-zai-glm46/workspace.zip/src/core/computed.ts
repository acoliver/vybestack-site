/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  addDependency,
  updateDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let _equalFn: EqualFn<T>
  if (_equal === undefined) {
    _equalFn = (a, b) => a === b
  } else if (typeof _equal === 'boolean') {
    _equalFn = _equal ? (a, b) => a === b : () => false
  } else {
    _equalFn = _equal
  }
  void _equalFn // Mark as used to avoid lint error

  // Initialize the observer with the provided initial value or undefined
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const compute = (): T => {
    const prevObserver = getActiveObserver()
    setActiveObserver(o)
    
    try {
      // Call updateFn with the current value
      const newValue = updateFn(o.value)
      o.value = newValue
      
      // Register the dependency - if there's an active observer, it depends on this computed value
      if (prevObserver) {
        addDependency(prevObserver as any, o as any)
      }
      
      return newValue
    } finally {
      setActiveObserver(prevObserver)
    }
  }

  // Override the observer's updateFn to handle cascading updates
  o.updateFn = (_currentValue?: T): T => {
    const prevValue = o.value
    
    // Re-compute value when dependencies change
    const prevObserver = getActiveObserver()
    setActiveObserver(o)
    try {
      const newValue = updateFn(prevValue as T)
      o.value = newValue
      
      // If value changed, update all dependents
      if (!_equalFn(prevValue!, newValue)) {
        updateDependents(o as any)
      }
      
      return newValue
    } finally {
      setActiveObserver(prevObserver)
    }
  }

  // Force initial computation to establish dependencies and set initial value
  const prevObserver = getActiveObserver()
  setActiveObserver(undefined)
  try {
    const initialValue = compute()
    o.value = initialValue
  } finally {
    setActiveObserver(prevObserver)
  }

  // Return a getter that computes on demand but returns cached value when no dependencies are active
  return (): T => {
    // Only recompute if someone is actively tracking dependencies (i.e., during a callback)
    if (getActiveObserver()) {
      return compute()
    } else {
      // Value should always be defined after initial computation
      return o.value!
    }
  }
}