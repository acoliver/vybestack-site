/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<any> | undefined

export function getActiveObserver<T>(): Observer<T> | undefined {
  return activeObserver as Observer<T> | undefined
}

export function setActiveObserver<T>(observer?: Observer<T>): void {
  activeObserver = observer
}

// Registry for dependencies - which observers depend on which subjects
const dependencyRegistry = new Map<Observer<any>, Set<Observer<any>>>()

export function addDependency<T>(observer: Observer<T>, dependency: Observer<T>): void {
  if (!dependencyRegistry.has(dependency as any)) {
    dependencyRegistry.set(dependency as any, new Set())
  }
  dependencyRegistry.get(dependency as any)!.add(observer as any)
}

export function getDependents<T>(observer: Observer<T>): Set<Observer<any>> {
  return dependencyRegistry.get(observer as any) || new Set()
}

export function removeDependencies<T>(observer: Observer<T>): void {
  // Remove this observer from all dependency lists
  for (const [, dependents] of dependencyRegistry.entries()) {
    dependents.delete(observer as any)
  }
  // Remove this observer's own dependency list
  dependencyRegistry.delete(observer as any)
}

export function updateDependents<T>(observer: Observer<T>): void {
  const dependents = getDependents(observer)
  for (const dependent of dependents) {
    if (dependent.updateFn) {
      try {
        dependent.value = dependent.updateFn(dependent.value)
      } catch (error) {
        console.error('Error updating dependent:', error)
      }
    }
  }
}