/**
 * Find words starting with the given prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookbehind to ensure the token is preceded by a digit.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match a digit followed by the token, not at the start of string
  const pattern = new RegExp(`(?:^|\\D)(\\d${escapedToken})`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Extract just the digit+token part (remove the non-digit prefix used for matching)
  return matches.map(match => match.replace(/^\D/, ''));
}

/**
 * Validate password strength:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab", "1212")
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // Pattern: any 2-4 character sequence repeated immediately
  const repeatedPattern = /(.{2,4})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand (::), excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Also check for simpler patterns
  const hasColons = /:/.test(value);
  if (!hasColons) {
    return false;
  }
  
  // Check for IPv6 hex groups
  const ipv6Groups = value.match(/([0-9a-fA-F]{1,4}):/g);
  if (!ipv6Groups) {
    return false;
  }
  
  // Must have at least 2 colons for valid IPv6 (or :: shorthand)
  const colonCount = (value.match(/:/g) || []).length;
  if (colonCount < 2) {
    return false;
  }
  
  // Ensure it's not an IPv4 address (no dots in IPv6 except in IPv4-mapped addresses)
  // But we want to exclude pure IPv4, so check if it looks more like IPv4 than IPv6
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check for IPv6 characteristics
  const hasHexChars = /[a-fA-F]/.test(value);
  const hasDoubleColon = /::/.test(value);
  const hasMultipleColons = /:.*:/.test(value);
  
  // If it has hex groups and multiple colons, it's likely IPv6
  return (hasHexChars || hasDoubleColon || hasMultipleColons) && !ipv4Pattern.test(value);
}
