/**
 * Capitalize the first character of each sentence.
 * - Capitalize after sentence-ending punctuation (.!?)
 * - Insert exactly one space between sentences
 * - Collapse extra spaces sensibly
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces to one, but preserve sentence boundaries
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize first character of string
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize after sentence-ending punctuation (. ! ?)
  result = result.replace(/([.!?])\s*([a-z])/g, (match, punct, char) => {
    return punct + ' ' + char.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text and return them as an array.
 * URLs are returned without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, and www-prefixed URLs
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"{}|^`[\]]+[^\s<>"{}|^`[\].,!?;:]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Force all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 * - But still upgrade scheme even for those URLs
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const pattern = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(pattern, (match, scheme, host, path = '') => {
    const newScheme = 'https://';
    const newPath = path || '';
    
    // Check if path starts with /docs/
    const isDocsPath = newPath.startsWith('/docs/');
    
    // Skip host rewrite for dynamic paths
    const skipRewrite = /\/(cgi-bin|.*\?.*|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(newPath);
    
    if (isDocsPath && !skipRewrite) {
      return newScheme + 'docs.' + host + newPath;
    }
    
    return newScheme + host + newPath;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const pattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(pattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Allow Feb 29 for simplicity
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
