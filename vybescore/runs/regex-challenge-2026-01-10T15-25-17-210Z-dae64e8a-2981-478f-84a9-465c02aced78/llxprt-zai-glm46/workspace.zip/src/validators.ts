export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with robust regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic structure check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [local, domain] = value.split('@');
  
  // Local part: no consecutive dots, no leading/trailing dot
  if (local.startsWith('.') || local.endsWith('.') || local.includes('..')) {
    return false;
  }
  
  // Domain: no underscores, no trailing dot, no consecutive dots
  if (domain.includes('_') || domain.startsWith('.') || domain.endsWith('.') || domain.includes('..')) {
    return false;
  }
  
  // Domain must have at least one dot and TLD at least 2 chars
  const domainParts = domain.split('.');
  if (domainParts.length < 2 || domainParts[domainParts.length - 1].length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove common separators and spaces for validation
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Extract digits only
  const digitsOnly = cleaned.replace(/\D/g, '');
  
  // Check for optional +1 prefix
  let numberDigits = digitsOnly;
  if (numberDigits.startsWith('1') && numberDigits.length > 10) {
    numberDigits = numberDigits.substring(1);
  }
  
  // Must be exactly 10 digits for US number
  if (numberDigits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = numberDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (first digit of 7-digit local number) cannot be 0 or 1
  const exchangeCode = numberDigits[3];
  if (exchangeCode === '0' || exchangeCode === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Main pattern: optional +54, optional trunk 0, optional mobile 9, area code (2-4 digits), subscriber (6-8 digits)
  const pattern = /^(?:\+54)?(0)?9?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(pattern);
  
  if (!match) {
    return false;
  }
  const [, trunk, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // When no country code (+54), trunk prefix (0) is required
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !trunk) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented), apostrophes, hyphens, and spaces
  // Must have at least 2 characters
  // No digits or symbols except apostrophe and hyphen
  const nameRegex = /^[\p{L}\p{M}'][\p{L}\p{M}'\s-]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value) || value.length < 2) {
    return false;
  }
  
  // Reject names with digits (not caught by above regex due to \p{})
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with symbols other than allowed ones (unicode letters, marks, apostrophe, space, hyphen)
  const disallowedSymbolsRegex = /[^\p{L}\p{M}'\s-]/u;
  if (disallowedSymbolsRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let double = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    if (double) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
    double = !double;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx.
 * Checks prefix patterns, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaPattern = /^4\d{12}(\d{3})?$/;
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  
  const validFormat = visaPattern.test(cleaned) || mastercardPattern.test(cleaned) || amexPattern.test(cleaned);
  
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
