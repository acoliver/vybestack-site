import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

/**
 * Renders a report in plain text format
 */
export const renderText: ReportRenderer = (data: ReportData, options: RenderOptions): string => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);

  const lines: string[] = [
    data.title,
    data.summary,
    'Entries:',
    ...data.entries.map(entry => `- ${entry.label}: $${entry.amount.toFixed(2)}`),
  ];

  if (options.includeTotals) {
    lines.push('', `Total: $${total.toFixed(2)}`);
  }

  return lines.join('\n');
};