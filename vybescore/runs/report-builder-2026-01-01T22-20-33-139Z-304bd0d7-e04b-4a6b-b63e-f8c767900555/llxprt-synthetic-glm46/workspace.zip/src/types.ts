/**
 * Interface for a report entry with label and amount
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering the report
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Function signature for report renderers
 */
export type ReportRenderer = (data: ReportData, options: RenderOptions) => string;