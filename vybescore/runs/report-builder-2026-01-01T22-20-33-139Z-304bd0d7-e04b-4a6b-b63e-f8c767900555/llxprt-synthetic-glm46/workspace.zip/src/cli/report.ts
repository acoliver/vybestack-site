#!/usr/bin/env node

import { readFile } from 'node:fs';
import { exit, argv } from 'node:process';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Supported formats and their renderers
const renderers = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

type SupportedFormat = keyof typeof renderers;

function isSupportedFormat(format: string): format is SupportedFormat {
  return format in renderers;
}

function parseArguments(): {
  dataPath: string;
  format: SupportedFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = argv.slice(2);

  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const dataPath = args[0];
  
  // Find format argument
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    exit(1);
  }
  
  const format = args[formatIndex + 1];
  if (!isSupportedFormat(format)) {
    console.error(`Unsupported format: ${format}`);
    exit(1);
  }

  // Find output argument
  const outputIndex = args.findIndex(arg => arg === '--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid or missing label`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid or missing amount`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const { dataPath, format, outputPath, includeTotals } = parseArguments();

    // Read and parse JSON data
    const dataContent = await new Promise<string>((resolve, reject) => {
      readFile(dataPath, 'utf8', (err, content) => {
        if (err) {
          reject(err);
        } else {
          resolve(content);
        }
      });
    });

    const jsonData = JSON.parse(dataContent);
    const reportData = validateReportData(jsonData);

    // Render the report
    const renderer = renderers[format];
    const options: RenderOptions = { includeTotals };
    const output = renderer(reportData, options);

    // Write output
    if (outputPath) {
      await new Promise<void>((resolve, reject) => {
        writeFile(outputPath, output, 'utf8', (err) => {
          if (err) {
            reject(err);
          } else {
            resolve();
          }
        });
      });
    } else {
      console.log(output);
    }
  } catch (error) {
    // Check if it's a file system error and provide more helpful message
    if (error instanceof Error && ('code' in error) && (error as Error & { code: string }).code === 'ENOENT') {
      console.error('Error: File not found');
    } else {
      console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    }
    exit(1);
  }
}

// Import writeFile dynamically to avoid potential issues with ES modules
import { writeFile } from 'node:fs';

// Run the CLI
main();
