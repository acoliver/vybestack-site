/**
 * Capitalizes the first character of each sentence and ensures proper spacing
 * Preserves abbreviations and inserts exactly one space between sentences
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first letter of the text
  let result = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Match sentence endings followed by whitespace and a lowercase letter
  // This pattern will help us capitalize the first letter of each sentence
  result = result.replace(/([.?!])\s+([a-z])/g, (match, ending, letter) => {
    return ending + ' ' + letter.toUpperCase();
  });
  
  // Ensure there's exactly one space between sentences and collapse extra spaces
  result = result.replace(/\s+/g, ' ');
  
  // Handle cases with no space after sentence ending
  result = result.replace(/([.?!])([a-zA-Z])/g, (match, ending, letter) => {
    return ending + ' ' + letter;
  });
  
  return result;
}

/**
 * Extracts URLs from text and returns them as an array
 * Returns URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs (http, https, ftp)
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/g;
  
  // Extract URLs
  const urls = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return urls.map(url => url.replace(/[.!?]+$/, ''));
}

/**
 * Enforces https scheme on all URLs in the text
 * Replaces http:// with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// (but not https:// which already exists)
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://...
 * Moves docs paths to https://docs.example.com/ where applicable
 * Skips host rewrite when path contains dynamic hints like cgi-bin or query strings
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with example.com host
  const urlPattern = /http:\/\/example\.com(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (url) => {
    // Upgrade scheme to https
    let newUrl = url.replace('http://', 'https://');
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const path = newUrl.substring(newUrl.indexOf('/', 8)); // Get path after https://
    
    // Patterns that indicate dynamic content and should prevent host rewrite
    const dynamicIndicators = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/;
    
    // If path starts with /docs/ and doesn't contain dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !dynamicIndicators.test(path)) {
      newUrl = newUrl.replace('https://example.com', 'https://docs.example.com');
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings
 * Returns 'N/A' when the format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month and day ranges
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}

/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  throw new Error('TODO: implement findPrefixedWords');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  throw new Error('TODO: implement findEmbeddedToken');
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  throw new Error('TODO: implement isStrongPassword');
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  throw new Error('TODO: implement containsIPv6');
}