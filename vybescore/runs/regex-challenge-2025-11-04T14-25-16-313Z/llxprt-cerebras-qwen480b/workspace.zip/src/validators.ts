export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure
  if (!value.includes('@')) return false;
  
  // Check for double dots or trailing dots
  if (value.includes('..') || value.endsWith('.') || value.startsWith('.')) return false;
  
  // Regex for validating email addresses
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check if the email matches the regex
  if (!emailRegex.test(value)) return false;
  
  // Split email into local and domain parts
  const [localPart, domainPart] = value.split('@');
  
  // Domain part cannot contain underscores
  if (domainPart.includes('_')) return false;
  
  // Local part must not be empty
  if (!localPart || localPart.length === 0) return false;
  
  // Domain part must not be empty and not start or end with hyphen
  if (!domainPart || domainPart.length === 0 || domainPart.startsWith('-') || domainPart.endsWith('-')) return false;
  
  return true;
}

/**
 * Validates US phone numbers
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove any non-digit characters for length check
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have enough digits (10 digits or 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // Extract the 10-digit core number (without optional country code)
  const coreNumber = digitsOnly.length === 11 ? digitsOnly.substring(1) : digitsOnly;
  
  // Area code cannot start with 0 or 1
  if (coreNumber[0] === '0' || coreNumber[0] === '1') return false;
  
  // Regex for common US phone number formats
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2–4 digits (leading digit 1–9)
 * - Subscriber number (after the area code) must contain 6–8 digits in total
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex patterns for different Argentine phone number formats
  const patterns = [
    // +54 9 11 1234 5678 (mobile with country code)
    /^\+549[1-9]\d{1,3}\d{6,8}$/,
    // +54 341 123 4567 (landline with country code)
    /^\+54[1-9]\d{1,3}\d{6,8}$/,
    // 011 1234 5678 (landline with trunk prefix)
    /^0[1-9]\d{1,3}\d{6,8}$/
  ];
  
  // Check if the value matches any of the patterns
  return patterns.some(pattern => pattern.test(cleanValue));
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Empty values are not valid names
  if (!value || value.trim().length === 0) return false;
  
  // Regex for validating names allowing Unicode letters, hyphens, apostrophes, and spaces
  // Also ensures at least one letter is present
  const nameRegex = /^[\p{L}\s\-']+$/u;
  
  // Check if all characters are valid
  if (!nameRegex.test(value)) return false;
  
  // Check if at least one letter is present
  const hasLetter = /[\p{L}]/u.test(value);
  
  // Name must contain at least one letter
  if (!hasLetter) return false;
  
  // Reject names with patterns like X Æ A-12 (digits in names)
  if (/\d/.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers using Luhn algorithm
 * Accepts Visa/Mastercard/AmEx based on their prefixes and lengths
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check card type based on prefix and length
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/; // 16 digits, starts with 51-55 or 22-27
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  const isVisa = visaRegex.test(cleanValue);
  const isMastercard = mastercardRegex.test(cleanValue);
  const isAmex = amexRegex.test(cleanValue);
  
  // Must match one of the card types
  if (!(isVisa || isMastercard || isAmex)) return false;
  
  // Luhn algorithm implementation
  return runLuhnCheck(cleanValue);
}

/**
 * Implements the Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}