/**
 * Finds words in text that start with a given prefix but excludes exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with the prefix
  // \b ensures word boundaries
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string
 * Uses lookaheads/lookbehinds for precise matching
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern using positive lookbehind to ensure token follows a digit
  // and negative lookahead to ensure it's not at the start of the string
  const pattern = new RegExp(`(?<=\\d)${token}`, 'g');
  
  // Find all matches
  return text.match(pattern) || [];
}

/**
 * Validates passwords according to security requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for repeated sequences (like abab)
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern (simplified but covers most common cases including :: shorthand)
  const ipv6Pattern = /(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)/;
  
  // IPv4 pattern to ensure we exclude IPv4 addresses
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If IPv4 pattern matches, return false
  if (ipv4Pattern.test(value)) return false;
  
  // Return true if IPv6 pattern matches
  return ipv6Pattern.test(value);
}