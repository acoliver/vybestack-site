import type { ReportData } from './types.js';
import { readFileSync } from 'fs';

export function parseAndValidateJson(filePath: string): ReportData {
  let content: string;

  try {
    content = readFileSync(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file: ${filePath}`);
  }

  let data: unknown;

  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error(`Invalid JSON in file: ${filePath}`);
  }

  return validateReportData(data);
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid report data: must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (must be an array)');
  }

  const entries = obj.entries;

  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];

    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${i} missing or invalid "amount" field (must be a number)`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: entries as Array<{ label: string; amount: number }>,
  };
}
