#!/usr/bin/env node

import { parseAndValidateJson } from '../validator.js';
import { getFormatter, type Format } from '../formatters/index.js';
import { writeFileSync } from 'fs';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  let format: Format | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error('Unsupported format');
      }
      format = formatValue as Format;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function main() {
  try {
    const args = parseArgs(process.argv.slice(2));
    const data = parseAndValidateJson(args.inputFile);
    const formatter = getFormatter(args.format);
    const output = formatter.render(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
