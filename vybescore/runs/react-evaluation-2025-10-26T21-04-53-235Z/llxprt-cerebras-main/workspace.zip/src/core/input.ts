/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle the equal function parameter - if boolean true, use Object.is, otherwise use provided function or default to ===
  const equalFn: EqualFn<T> = 
    equal === true ? Object.is : 
    typeof equal === 'function' ? equal : 
    (lhs: T, rhs: T) => lhs === rhs;

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if the value actually changed according to the equality function
    if (!s.equalFn!(s.value, nextValue)) {
      s.value = nextValue
      if (s.observer) updateObserver(s.observer as Observer<unknown>)
    }
    return s.value
  }

  return [read, write]
}
