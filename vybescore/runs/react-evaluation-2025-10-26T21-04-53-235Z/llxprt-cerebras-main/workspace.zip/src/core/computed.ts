/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the equal function parameter - if boolean true, use Object.is, otherwise use provided function or default to ===
  const equalFn: EqualFn<T> = 
    equal === true ? Object.is : 
    typeof equal === 'function' ? equal : 
    (lhs: T, rhs: T) => lhs === rhs;
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Track dependencies during initial computation
  updateObserver(o)

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    // If there's an active observer, we're being accessed within another computed/callback
    if (activeObserver) {
      // Update the observer reference to track dependencies correctly
      const newValue = updateFn(o.value)
      // Only update if the value has changed
      if (!equalFn(o.value!, newValue)) {
        o.value = newValue
      }
    }
    return o.value!
  }

  return getter
}