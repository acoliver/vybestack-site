import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const errors: string[] = [];
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (Number.isNaN(pageNum)) {
        errors.push('page must be a number');
      } else if (pageNum < 1) {
        errors.push('page must be >= 1');
      } else if (pageNum > 1000000) {
        errors.push('page must be <= 1000000');
      } else {
        page = Math.floor(pageNum);
      }
    }

    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (Number.isNaN(limitNum)) {
        errors.push('limit must be a number');
      } else if (limitNum < 1) {
        errors.push('limit must be >= 1');
      } else if (limitNum > 1000) {
        errors.push('limit must be <= 1000');
      } else {
        limit = Math.floor(limitNum);
      }
    }

    if (errors.length > 0) {
      const errorMessage = errors.join(', ');
      res.status(400).json({ error: errorMessage, errors });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
