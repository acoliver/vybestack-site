export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== "string") return "";
  let normalized = text.replace(/([.!?])([a-zA-Z])/g, "$1 $2");
  normalized = normalized.replace(/[ \t]+/g, " ");
  normalized = normalized.replace(/^\s*\p{L}/u, m => m.toUpperCase());
  const abbr = ["Mr","Mrs","Ms","Dr","Prof","Sr","Jr","Gen","Rep","Sen","St","Ave","Blvd","Rd","Lt","Col","Sgt","Capt","etc","eg","ie","vs","approx","dept","univ","assn","av","no","vol","pp","ch","sec","fig","tab"];
  const abbrP = abbr.join("|");
  normalized = normalized.replace(/([.!?]\s+)(\p{L})/gu, (m,p,l) => {
    const before = normalized.substring(0, normalized.indexOf(m));
    const lastW = before.split(/\s+/).pop() || "";
    if (lastW.match(new RegExp("^(" + abbrP + ")\\.?$", "i"))) return m;
    return p + l.toUpperCase();
  });
  normalized = normalized.replace(/(\n\s*)(\p{L})/gu, (m,n,l) => n + l.toUpperCase());
  return normalized.trim();
}

export function extractUrls(text: string): string[] {
  if (!text || typeof text !== "string") return [];
  const urlPattern = /https?:\/\/[^\s]+/g;
  const matches = text.match(urlPattern) || [];
  return matches.map(u => u.replace(/[.,;:!?)\]]+$/, ""));
}

export function enforceHttps(text: string): string {
  if (!text || typeof text !== "string") return "";
  return text.replace(/http:\/\//gi, "https://");
}

export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== "string") return "";
  return text.replace(/(https?):\/\/(example\.com)(\/[^\s]*)?/gi, (m,proto,host,path = "") => {
    if (!path || !path.startsWith("/docs/")) return "https://" + host + path;
    const hints = ["cgi-bin","?","&","=",".jsp",".php",".asp",".aspx",".do",".cgi",".pl",".py"];
    if (hints.some(h => path.includes(h))) return "https://" + host + path;
    return "https://docs.example.com" + path;
  });
}

export function extractYear(value: string): string {
  if (!value || typeof value !== "string") return "N/A";
  const m = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!m) return "N/A";
  const mo = parseInt(m[1],10), da = parseInt(m[2],10);
  if (mo < 1 || mo > 12) return "N/A";
  const dim = [31,29,31,30,31,30,31,31,30,31,30,31];
  if (da < 1 || da > dim[mo-1]) return "N/A";
  return m[3];
}
