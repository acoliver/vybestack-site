export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using RFC-compliant patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Email regex that rejects common issues:
  // - No double dots (..) anywhere
  // - No trailing dot in local or domain part
  // - No underscores in domain
  // - Proper @ structure
  const emailRegex = /^(?![.])(?!.*\.\.)[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?![.])(?!.*\.\.)(?!.*_)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

  // Additional checks for edge cases
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('@.') || value.includes('.@')) return false;
  if (value.includes('..')) return false;

  // Domain part should not have underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) return false;

  // TLD should not start/end with hyphen or have consecutive hyphens
  if (domainPart && domainPart.includes('-')) {
    const tld = domainPart.split('.').pop();
    if (tld && (tld.startsWith('-') || tld.endsWith('-') || tld.includes('--'))) return false;
  }

  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats:
 * - (212) 555-7890
 * - 212-555-7890
 * - 2125557890
 * - Optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // Check length: 10 digits for standard US number, 11 if starting with 1
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Valid: +1 prefix
  } else if (digitsOnly.length === 10) {
    // Valid: standard 10-digit
  } else {
    return false;
  }

  // Extract the actual 10-digit number (remove leading 1 if present)
  const tenDigits = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = tenDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = tenDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;

  // Validate the format matches common patterns
  const patterns = [
    /^\+1\s?\(\d{3}\)\s?\d{3}-\d{4}$/,       // +1 (212) 555-7890
    /^\+1\s?\d{3}-\d{3}-\d{4}$/,             // +1 212-555-7890
    /^\+1\s?\d{3}\s?\d{3}\s?\d{4}$/,        // +1 212 555 7890
    /^\+1\d{10}$/,                            // +12125557890
    /^\(\d{3}\)\s?\d{3}-\d{4}$/,             // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,                   // 212-555-7890
    /^\d{3}\.\d{3}\.\d{4}$/,                 // 212.555.7890
    /^\d{3}\s?\d{3}\s?\d{4}$/,               // 212 555 7890
    /^\d{10}$/,                               // 2125557890
  ];

  const normalizedValue = value.trim();
  return patterns.some(pattern => pattern.test(normalizedValue));
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (landline without country code)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline with trunk prefix)
 *
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - When country code omitted, must begin with trunk prefix 0
 * - Allows single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');

  // Check with country code patterns
  const ccPatterns = [
    /^\+549[1-9]\d{1,2}\d{6,8}$/,  // Mobile: +54 9 XX(N) XXXXXX-XX
    /^\+54[1-9]\d{1,3}\d{6,8}$/,   // Landline: +54 XXX(N) XXXXXX-XX
  ];

  if (ccPatterns.some(p => p.test(normalized))) {
    return true;
  }

  // Check trunk prefix patterns (without country code)
  const trunkPatterns = [
    /^09[1-9]\d{1,2}\d{6,8}$/,   // Mobile with trunk: 0 9 XX(N) XXXXXX-XX
    /^0[1-9]\d{1,3}\d{6,8}$/,    // Landline with trunk: 0 XXX(N) XXXXXX-XX
  ];

  return trunkPatterns.some(p => p.test(normalized));
}

/**
 * Validates personal names allowing:
 * - Unicode letters and accents
 * - Apostrophes (e.g., O'Connor)
 * - Hyphens (e.g., Smith-Jones)
 * - Spaces
 *
 * Rejects:
 * - Digits
 * - Symbols
 * - Names like "X Æ A-12" (contains digits and symbols)
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const trimmed = value.trim();
  if (trimmed.length === 0) return false;

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols (except apostrophe and hyphen), and weird symbols like Æ
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  // Additional check: must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);

  // Should not contain digits
  const hasDigit = /\d/.test(trimmed);

  // Should not contain special symbols (besides allowed apostrophe, hyphen, space)
  const hasOtherSymbols = /[^\p{L}\p{M}'\-\s]/u.test(trimmed);

  return nameRegex.test(trimmed) && hasLetter && !hasDigit && !hasOtherSymbols;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks:
 * - Valid prefix for card type
 * - Correct length
 * - Passes Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[\s-]/g, '');

  // Check if it's all digits
  if (!/^\d+$/.test(digitsOnly)) return false;

  // Check length and prefix for different card types
  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4\d{12}(\d{3}(\d{3})?)?$/;

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mcPattern1 = /^5[1-5]\d{14}$/;
  const mcPattern2 = /^2[2-7][2-9]\d{12}$/;
  const mcPattern3 = /^222[1-9]\d{12}$/;
  const mcPattern4 = /^27[01][0-9]\d{12}$/;
  const mcPattern5 = /^2720\d{12}$/;

  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;

  const validPrefixAndLength =
    visaPattern.test(digitsOnly) ||
    mcPattern1.test(digitsOnly) ||
    mcPattern2.test(digitsOnly) ||
    mcPattern3.test(digitsOnly) ||
    mcPattern4.test(digitsOnly) ||
    mcPattern5.test(digitsOnly) ||
    amexPattern.test(digitsOnly);

  if (!validPrefixAndLength) return false;

  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn algorithm checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));

  let sum = 0;
  let double = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (double) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    double = !double;
  }

  return sum % 10 === 0;
}
