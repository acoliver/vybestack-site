export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  const excSet = new Set(exceptions.map(e => e.toLowerCase()));
  const p = new RegExp('\\b' + prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&') + '[a-zA-Z]*\\b', 'g');
  return (text.match(p) || []).filter(w => !excSet.has(w.toLowerCase()));
}

export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  const esc = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const p = new RegExp('\\d' + esc, 'g');
  return text.match(p) || [];
}

export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  if (/\s/.test(value)) return false;
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/[0-9]/.test(value)) return false;
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  for (let i = 0; i < value.length - 2; i++) {
    for (let len = 2; i + 2*len <= value.length; len++) {
      if (value.substr(i, len) === value.substr(i+len, len)) return false;
    }
  }
  return true;
}

export function containsIPv6(value: string): boolean {
  if (!value) return false;
  const p6 = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;
  if (!p6.test(value)) return false;
  const p4 = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  const m4 = value.match(p4);
  if (m4) {
    const idx = value.indexOf(m4[0]);
    const ctx = value.substring(Math.max(0, idx-2), idx+m4[0].length+2);
    if (!ctx.includes(':')) return false;
  }
  return true;
}
