export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement robust email validation.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) return false;
  
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) return false;
  
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject trailing dots
  if (localPart.endsWith('.') || domain.endsWith('.')) return false;
  
  // Reject leading/trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  // Domain must have at least one dot and valid structure
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  // Each domain part must be valid
  for (const part of domainParts) {
    if (!part || !/^[a-zA-Z0-9-]+$/.test(part)) return false;
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove common separators and whitespace
  const cleanValue = value.replace(/[\s\-()]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleanValue;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  }
  
  // Must be exactly 10 digits for standard US numbers
  if (!/^\d{10}$/.test(digits)) return false;
  
  const areaCode = digits.substring(0, 3);
  const exchange = digits.substring(3, 6);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  if (exchange[0] === '0' || exchange[0] === '1') return false;
  
  // Check if the original format matches one of the allowed patterns
  const allowedPatterns = [
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/, // (212) 555-7890
    /^\+?1?\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/, // 212-555-7890, 212 555 7890
    /^\+?1?\s*\d{10}$/, // 2125557890
  ];
  
  return allowedPatterns.some(pattern => pattern.test(value));
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove whitespace and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // +54 9 11 1234 5678
  // 011 1234 5678  
  // +54 341 123 4567
  // 0341 4234567
  const argentinePhoneRegex = /^(\+54)?9?(\d{2,4})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleanValue)) return false;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, areaCode, subscriber] = match;
  
  // If country code is omitted, must start with trunk prefix 0
  if (!countryCode && !areaCode.startsWith('0')) return false;
  
  // If country code is present, area code should not start with 0
  if (countryCode && areaCode.startsWith('0')) return false;
  
  // Area code validation
  const normalizedAreaCode = countryCode ? areaCode : areaCode.substring(1); // Remove trunk prefix if present
  if (normalizedAreaCode.length < 2 || normalizedAreaCode.length > 4) return false;
  if (!/^[1-9]/.test(normalizedAreaCode)) return false; // Leading digit must be 1-9
  
  // Subscriber number validation (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  if (!/^\d+$/.test(subscriber)) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const trimmedName = value.trim();
  
  // Reject empty names
  if (!trimmedName) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmedName)) return false;
  
  // Reject digits
  if (/\d/.test(trimmedName)) return false;
  
  // Reject multiple consecutive non-letter characters
  if (/(?:['-\s]{2,})/.test(trimmedName)) return false;
  
  // Reject names starting or ending with apostrophe or hyphen
  if (/^['-]|['-]$/.test(trimmedName)) return false;
  
  // Must contain at least one letter
  if (!/[\p{L}]/u.test(trimmedName)) return false;
  
  return true;
}

/**
 * Validate common credit card brands (Visa/Mastercard/AmEx) and run Luhn checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled = doubled - 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[01]\d|6[0-9]\d|7[01]\d|720)\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any supported card type
  const isValidFormat = visaRegex.test(cleanValue) || 
                        mastercardRegex.test(cleanValue) || 
                        amexRegex.test(cleanValue);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
