/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Split into sentences using .?! as delimiters
  // Use positive lookahead to keep the delimiters
  const sentences = text.split(/(?<=[.?!])/);
  
  const capitalizedSentences = sentences.map((sentence) => {
    // Trim leading whitespace for the first character check
    const trimmed = sentence.trim();
    
    if (!trimmed) return sentence;
    
    // Find the first letter character
    const firstCharIndex = sentence.search(/[a-zA-Z\u00C0-\u017F]/);
    
    if (firstCharIndex === -1) return sentence;
    
    // Capitalize the first letter
    const beforeFirstChar = sentence.substring(0, firstCharIndex);
    const firstChar = sentence[firstCharIndex].toUpperCase();
    const rest = sentence.substring(firstCharIndex + 1);
    
    return beforeFirstChar + firstChar + rest;
  });
  
  // Join sentences with exactly one space between them
  // This ensures consistent spacing even if input had irregular spacing
  let result = '';
  for (let i = 0; i < capitalizedSentences.length; i++) {
    const sentence = capitalizedSentences[i];
    
    // Add the sentence
    result += sentence;
    
    // Add single space between sentences if this isn't the last one
    // and the next sentence doesn't start with a delimiter
    if (i < capitalizedSentences.length - 1) {
      const nextSentence = capitalizedSentences[i + 1].trim();
      if (nextSentence && !/^[.\s]/.test(nextSentence)) {
        result += ' ';
      }
    }
  }
  
  // Normalize spacing - collapse multiple spaces to single spaces
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern matching common URL formats
  // Matches http://, https://, and protocol-relative URLs
  const urlRegex = /(?:(?:https?:)?\/\/)?(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation that's likely not part of the URL
    return url.replace(/[.,;:!?)\]}"']+$/g, '');
  }).filter(url => {
    // Filter out matches that are too short to be valid URLs
    return url.length >= 4;
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but not https:// (to avoid double replacement)
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Pattern to match http URLs and capture components
  const urlPattern = /(https?:\/\/)([^\/:]+)(:[0-9]+)?(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, protocol, host, port, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    let newHost = host;
    const newPath = path || '';
    
    // Check if we should rewrite the host for docs
    if (newPath.startsWith('/docs/')) {
      // Check for exceptions that should NOT trigger host rewrite
      const hasDynamicHints = /(cgi-bin|.*\?(?:.*&)?.*=|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(newPath);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        newHost = `docs.${host}`;
      }
    }
    
    return newProtocol + newHost + (port || '') + newPath;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    28, // February (non-leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  // Check for February leap year
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  const maxDay = monthNum === 2 && isLeapYear ? 29 : daysInMonth[monthNum - 1];
  
  if (dayNum < 1 || dayNum > maxDay) return 'N/A';
  
  return year;
}