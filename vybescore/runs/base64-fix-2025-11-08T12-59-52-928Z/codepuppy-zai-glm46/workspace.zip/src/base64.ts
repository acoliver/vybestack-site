/**
 * Validate Base64 input string.
 * Only allows Base64 characters (A-Z, a-z, 0-9, +, /) and optional padding (=).
 * Throws error if invalid characters are found.
 */
function validateBase64(input: string): void {
  // Base64 regex: A-Z, a-z, 0-9, +, /, and optional padding = at the end
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check padding rules: if padding exists, it must be 1 or 2 = at the end
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.slice(paddingIndex);
    if (!/^={1,2}$/.test(padding)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Padding characters can only appear at the end
    if (paddingIndex !== input.length - padding.length) {
      throw new Error('Invalid Base64 input: padding in middle of string');
    }
  }
}

/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Uses the canonical Base64 alphabet with + and / characters.
 * Includes required padding (=) when needed.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Rejects invalid Base64 payloads by throwing an error.
 */
export function decode(input: string): string {
  // Validate input before attempting decode
  validateBase64(input);
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}