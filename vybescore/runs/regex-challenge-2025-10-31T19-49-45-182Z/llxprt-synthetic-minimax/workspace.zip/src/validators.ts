export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to validate Luhn checksum for credit cards
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Regex for email validation
  // Local part: letters, numbers, and certain special chars including +tag
  // Domain: letters, numbers, hyphens (but not starting/ending with hyphen), no underscores, no double/trailing dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1
  if (cleaned.startsWith('+1')) {
    const number = cleaned.substring(2);
    if (number.length !== 10) return false;
    const areaCode = number.substring(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
    return true;
  } else {
    // No +1 prefix, just the 10 digits
    if (cleaned.length !== 10) return false;
    const areaCode = cleaned.substring(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
    return true;
  }
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators for easier processing
  const digits = value.replace(/[\s-]/g, '');
  
  // Pattern to match: [+54][9][0]?[2-4 digit area code][6-8 digit subscriber number]
  // Country code: +54 (optional)
  // Mobile indicator: 9 (optional, only if country code present or before area code)
  // Trunk prefix: 0 (optional, must be before area code)
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits total after area code
  
  // Full pattern matching all valid formats
  const pattern = /^(?:\+54)?(?:9)?(?:0)?([2-9]\d{1,3})(\d{6,8})$/;
  const match = digits.match(pattern);
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Validate subscriber number length: total length of subscriber should be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // Check that when country code is omitted, trunk prefix 0 is present
  if (!digits.startsWith('+54') && !digits.startsWith('0')) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, hyphens
  // Reject digits and special symbols (except ' and -)
  // Pattern: start with letter, then any combination of letters, spaces, apostrophes, hyphens
  const nameRegex = /^(?:[\p{L}][\p{L}\p{M}\s'\-]*[\p{L}\p{M}]|[\p{L}\p{M}])$/u;
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check card type prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // MasterCard: starts with 51-55, or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  
  let isValidType = false;
  
  if (digits.startsWith('4') && (digits.length === 13 || digits.length === 16 || digits.length === 19)) {
    isValidType = true;
  } else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
              digits.startsWith('54') || digits.startsWith('55') || 
              (digits.startsWith('222') && parseInt(digits.substring(0, 4)) <= 2720) ||
              (digits.startsWith('2221') && parseInt(digits.substring(0, 4)) >= 2221)) && digits.length === 16) {
    isValidType = true;
  } else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}