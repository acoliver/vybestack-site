/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize first letter after sentence terminators (.?!)
  // Ensure exactly one space after sentence terminators
  // Collapse multiple spaces while preserving word boundaries
  
  return text
    // First, normalize spaces - replace multiple spaces with single space
    .replace(/\s+/g, ' ')
    // Capitalize first letter of the string
    .replace(/^\s*([a-z])/, (match) => match.toUpperCase())
    // Capitalize first letter after . ? !
    .replace(/([.!?])\s*([a-z])/g, (match, punct, letter) => {
      return punct + ' ' + letter.toUpperCase();
    });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs starting with http:// or https://
  // Include alphanumeric, dots, hyphens, underscores, slashes, etc.
  // Stop at trailing punctuation
  const urlPattern = /\bhttps?:\/\/[^\s<>"']+[^\s<>"'.,!?]/g;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation if present
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with potential docs path
  const urlPattern = /http:\/\/([^\/]+)(\/[^?\s<>"]*)/g;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    const hasDynamicHints = /cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py|[?&]=/.test(match);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite to docs.host
      const newHost = 'docs.' + host;
      return 'https://' + newHost + path;
    } else {
      // Just upgrade scheme to https
      return 'https://' + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format with proper month/day validation
  const pattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(pattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (01-31, rough validation)
  if (day < 1 || day > 31) return 'N/A';
  
  return year;
}