/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary pattern for the prefix
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // We need to get the full match including the digit before it
  // Re-match with the digit to return the complete occurrence
  const fullPattern = new RegExp(`\\d${token}`, 'g');
  const fullMatches = text.match(fullPattern) || [];
  
  return fullMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Check for no immediate repeated sequences (like abab, cdcd)
  // This means no 4-character pattern where characters 1-2 repeat immediately
  if (/(\w{2})\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern matching:
  // - 8 groups of hex digits separated by colons
  // - Can use :: to compress consecutive zeros
  // - Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Compressed form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx with ::
  // Exclude IPv4 addresses (which use dots)
  
  // Pattern to match IPv6 addresses
  // This handles both full and compressed notation
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/;
  const compressedPattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}\b/;
  
  // Check if IPv6 pattern matches
  const hasFullIPv6 = ipv6Pattern.test(value);
  const hasCompressedIPv6 = compressedPattern.test(value);
  
  // Exclude IPv4 addresses (they contain dots)
  const hasIPv4 = /\d+\.\d+\.\d+\.\d+/.test(value);
  
  return (hasFullIPv6 || hasCompressedIPv6) && !hasIPv4;
}