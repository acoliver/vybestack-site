/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Track all active observers for cleanup
const activeObservers = new Set<Observer<any>>();

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Add to active observers
  activeObservers.add(observer);
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from active observers
    activeObservers.delete(observer);
    
    // Clear the observer to stop further updates
    observer.value = value
    observer.updateFn = () => value!
  }
}