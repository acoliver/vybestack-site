/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  setCurrentDependencies,
  setRegisteredDependencies,
  getCurrentDependencies
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let currentValue: T = value as T;
  let stale = true;
  
  const equalFn: EqualFn<T> | undefined = 
    typeof _equal === 'function' ? _equal :
    _equal === false ? () => false : 
    _equal === true || _equal === undefined ? (a, b) => a === b : 
    undefined;
  
  const computedObserver: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (prevVal) => {
      return updateFn(prevVal);
    }
  };
  
  const compute = () => {
    if (!stale) return currentValue;
    
    // Set up dependency tracking
    const deps = new Set<Subject<any>>();
    setCurrentDependencies(deps);
    
    // Run computation to establish dependencies and get new value
    updateObserver(computedObserver);
    currentValue = computedObserver.value as T;
    stale = false;
    
    // Store dependencies for this computed value
    setRegisteredDependencies(computedObserver, deps);
    setCurrentDependencies(undefined);
    
    return currentValue;
  };
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver();
    if (activeObserver) {
      // When this computed value is accessed, register it as a dependency
      const currentDeps = getCurrentDependencies();
      if (currentDeps) {
        const computedSubject: Subject<T> = {
          name: options?.name,
          observer: activeObserver,
          value: currentValue,
          equalFn,
        };
        currentDeps.add(computedSubject);
      }
    }
    
    return compute();
  };
  
  // Initial computation
  compute();
  
  return getter;
}