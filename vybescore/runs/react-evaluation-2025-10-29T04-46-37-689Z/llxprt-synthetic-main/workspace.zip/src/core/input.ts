/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  getCurrentDependencies,
  markStale,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    typeof _equal === 'function' ? _equal :
    _equal === false ? () => false : 
    _equal === true || _equal === undefined ? (a, b) => a === b : 
    undefined;

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this as a dependency of the active observer
      const currentDeps = getCurrentDependencies();
      if (currentDeps) {
        currentDeps.add(s);
      }
      // Set this input's observer to the active observer
      s.observer = observer;
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = s.equalFn ? !s.equalFn(s.value, nextValue) : true;
    if (shouldUpdate) {
      s.value = nextValue;
      // Mark this subject as stale to trigger recomputation of dependents
      markStale(s);
    }
    return s.value;
  }

  return [read, write]
}