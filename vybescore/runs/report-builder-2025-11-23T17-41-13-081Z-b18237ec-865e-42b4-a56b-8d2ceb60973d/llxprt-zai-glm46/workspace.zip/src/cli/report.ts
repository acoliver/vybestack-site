#!/usr/bin/env node

import fs from 'node:fs';
import { type FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { validateReportData } from '../utils.js';

interface CliOptions {
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArguments(): { dataFile: string; options: CliOptions } {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];

  let format: FormatType | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Error: --format requires a value');
      }
      const formatValue = args[i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error('Unsupported format. Supported formats: markdown, text');
      }
      format = formatValue;
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Error: --output requires a value');
      }
      output = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Error: Unknown argument ${arg}`);
    }
  }

  if (!format) {
    throw new Error('Error: --format is required');
  }

  return { dataFile, options: { format, output, includeTotals } };
}

function main(): void {
  try {
    const { dataFile, options } = parseArguments();

    // Read and parse JSON data
    let jsonData: unknown;
    try {
      const jsonContent = fs.readFileSync(dataFile, 'utf-8');
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        throw new Error(`Invalid JSON in file ${dataFile}: ${error.message}`);
      }
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`File not found: ${dataFile}`);
      }
      throw error;
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Render report
    const formatter = formatters[options.format];
    const output = formatter.render(reportData, { includeTotals: options.includeTotals });

    // Write output
    if (options.output) {
      fs.writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
