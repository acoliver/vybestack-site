/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // The getter will recompute the value whenever accessed
  const getter: GetterFn<T> = () => {
    // When this computed value is accessed within another reactive context,
    // we need to track dependencies correctly
    // The actual dependency tracking is handled by the getActiveObserver system
    
    // For computed values that don't depend on inputs, recompute with undefined
    // to trigger the default parameter behavior
    const newValue = updateFn(undefined)
    o.value = newValue
    return o.value
  }
  
  // Compute initial value with undefined as input
  o.value = updateFn(undefined)
  
  return getter
}
