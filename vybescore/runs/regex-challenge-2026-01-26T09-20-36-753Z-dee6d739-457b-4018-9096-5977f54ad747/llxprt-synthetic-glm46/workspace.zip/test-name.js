// Import the actual function to test
import { isValidName } from './dist/src/validators.js';

console.log('Testing isValidName with Jane Doe:');
console.log('Result:', isValidName('Jane Doe'));

// Test the individual components step by step
const value = 'Jane Doe';

// 1. Check basic regex
const nameRegex = /^[\p{L}\p{M}['\-\s]+$/u;
console.log('Regex test result:', nameRegex.test(value));

// 2. Check for at least one letter  
const hasLetter = /[\p{L}\p{M}]/u.test(value);
console.log('Has letter test result:', hasLetter);

// 3. Check trimmed length
const trimmed = value.trim();
console.log('Trimmed length:', trimmed.length);

// 4. Check for digits
const hasDigit = /\d/.test(value);  
console.log('Has digit test result:', hasDigit);

// 5. Overall result
console.log('Overall result:', nameRegex.test(value) && hasLetter && trimmed.length >= 2 && !hasDigit);