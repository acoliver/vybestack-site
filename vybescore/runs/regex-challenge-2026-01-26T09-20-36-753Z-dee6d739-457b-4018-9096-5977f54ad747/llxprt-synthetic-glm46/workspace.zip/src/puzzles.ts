/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix in case it contains regex special characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Create regex to match words starting with the prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const foundWord = match[1];
    
    // Exclude if it's in the exceptions list
    if (!exceptions.includes(foundWord)) {
      matches.push(foundWord);
    }
  }
  
  return matches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token in case it contains regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  // Use lookbehind to match token preceded by a digit but not at start of string
  const tokenRegex = new RegExp(`\\d(${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Return the digit plus token (full match)
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like "abab")
  if (/(..)(\1+)/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns:
  // 1. Full form: x:x:x:x:x:x:x:x
  // 2. With :: shorthand (compressed zeros)
  const ipv6Regex = /((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6})?::(?:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6})?)/;
  
  // Check if it matches IPv6 pattern
  const ipv6Match = value.match(ipv6Regex);
  
  if (!ipv6Match) {
    return false;
  }
  
  // Make sure it's not an IPv4 address (IPv4 addresses in decimal dotted notation)
  const isIPv4 = ipv6Match[0].match(/^\d+\.\d+\.\d+\.\d+$/);
  
  return !isIPv4;
}
