export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9]+([._%+-][a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z]{2,})+$/;
  
  // Basic structure check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in local part
  const [localPart] = value.split('@');
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Check for optional +1 prefix and remove it first
  let processedValue = value;
  
  // Handle the optional +1 prefix specifically
  if (value.startsWith('+1')) {
    // Remove the +1 prefix for validation
    processedValue = value.substring(2);
  }
  
  // Now remove all non-digit characters
  const digits = processedValue.replace(/\D/g, '');
  
  // Check if we have exactly 10 digits after processing
  if (digits.length === 10) {
    return isValidUSPhoneCore(digits);
  }
  
  return false;
}

/**
 * Helper function to validate core 10-digit US phone number
 */
function isValidUSPhoneCore(digits: string): boolean {
  // Check area code first digit (cannot be 0 or 1)
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Overall format validation using regex with common separators
  const normalized = digits.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
  const phoneRegex = /^\(\d{3}\) \d{3}-\d{4}$/;
  
  return phoneRegex.test(normalized);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators except digits
  const digits = value.replace(/[^0-9]/g, '');
  
  // Check if it starts with country code 54
  if (digits.startsWith('54')) {
    const afterCountryCode = digits.substring(2);
    return validateArgentineNumberAfterCountry(afterCountryCode);
  } else {
    // If no country code, must start with trunk prefix 0
    if (!digits.startsWith('0')) {
      return false;
    }
    const afterTrunk = digits.substring(1);
    return validateArgentineNumberAfterCountry(afterTrunk);
  }
}

/**
 * Helper function to validate Argentine phone number after removing country code
 */
function validateArgentineNumberAfterCountry(digits: string): boolean {
  // Check for optional mobile indicator 9
  const remainingDigits = digits.startsWith('9') ? digits.substring(1) : digits;
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCodeLength = 2;
  while (areaCodeLength <= 4 && areaCodeLength < remainingDigits.length) {
    const areaCode = remainingDigits.substring(0, areaCodeLength);
    const subscriberDigits = remainingDigits.substring(areaCodeLength);
    
    // Area code must start with 1-9
    if (areaCode[0] === '0') {
      areaCodeLength++;
      continue;
    }
    
    // Subscriber number must be 6-8 digits
    if (subscriberDigits.length >= 6 && subscriberDigits.length <= 8) {
      return true;
    }
    
    areaCodeLength++;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow Unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check basic structure
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Not just spaces/hyphens/apostrophes - must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Must be at least 2 characters
  const trimmed = value.trim();
  if (trimmed.length < 2) {
    return false;
  }
  
  // Reject obviously invalid names like "X Æ A-12" (contains digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Check if digits only
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check basic format
  const validFormat = visaRegex.test(digits) || mastercardRegex.test(digits) || amexRegex.test(digits);
  
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(digits);
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit
  for (let i = digits.length - 1; i >= 0; i--) {
    const digit = parseInt(digits[i]);
    
    if (isEven) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
