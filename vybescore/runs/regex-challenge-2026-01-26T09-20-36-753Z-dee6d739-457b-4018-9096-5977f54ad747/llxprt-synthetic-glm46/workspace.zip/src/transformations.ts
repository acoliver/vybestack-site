/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split sentences by punctuation marks followed by optional spaces and then a word
  const sentences = text.split(/([.!?]\s*)(?=[a-zA-Z\u00C0-\uFFFF])/);
  
  // Process each sentence
  for (let i = 0; i < sentences.length; i++) {
    if (i % 2 === 1) {
      // This is the punctuation and space separator
      continue;
    }
    
    const sentence = sentences[i];
    
    // Find the first letter character to capitalize
    const firstLetterMatch = sentence.match(/[a-zA-Z\u00C0-\uFFFF]/);
    if (firstLetterMatch) {
      const firstLetterIndex = firstLetterMatch.index;
      if (firstLetterIndex !== undefined) {
        // Capitalize the first letter
        sentences[i] = sentence.substring(0, firstLetterIndex) + 
                      sentence.charAt(firstLetterIndex).toUpperCase() + 
                      sentence.substring(firstLetterIndex + 1);
      }
    }
  }
  
  // Rejoin sentences
  return sentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s<>"{}|\\`[\]]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like period, comma, etc.
  return matches.map(url => {
    const trimmedUrl = url.replace(/[.!?,:;)\]]+$/g, '');
    return trimmedUrl;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/example\.com(\/[^?]*)/gi, (match, path) => {
    // Always upgrade to https
    const secureUrl = match.replace(/^http:/, 'https:');
    
    // Check if path has dynamic content that should skip host rewrite
    const hasDynamicContent = /\/cgi-bin\/|\?|&=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
    
    // If path starts with /docs/ and no dynamic content
    if (path.startsWith('/docs/') && !hasDynamicContent) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
    
    // Otherwise just secure the scheme
    return secureUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Additional validation for day based on month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Index 0 unused
  
  // Check leap year for February
  if (month === 2 && isLeapYear(parseInt(year))) {
    daysInMonth[2] = 29;
  }
  
  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to check if a year is a leap year
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
}
