#!/usr/bin/env node

import fs from 'node:fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): { dataFile: string; options: CLIOptions } {
  if (args.length < 1) {
    showError('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  const options: CLIOptions = {
    format: '',
    includeTotals: false,
  };
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        showError('Missing format argument after --format');
      }
      options.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        showError('Missing output path after --output');
      }
      options.output = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (arg.startsWith('-')) {
      showError(`Unknown option: ${arg}`);
    } else {
      showError(`Unexpected argument: ${arg}`);
    }
  }
  
  if (!options.format) {
    showError('--format is required');
  }
  
  return { dataFile, options };
}

function showError(message: string): never {
  console.error(`Error: ${message}`);
  process.exit(1);
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const dataObj = data as Record<string, unknown>;
  
  if (typeof dataObj.title !== 'string' || !dataObj.title) {
    throw new Error('Invalid report data: missing or empty title');
  }
  
  if (typeof dataObj.summary !== 'string' || !dataObj.summary) {
    throw new Error('Invalid report data: missing or empty summary');
  }
  
  if (!Array.isArray(dataObj.entries) || dataObj.entries.length === 0) {
    throw new Error('Invalid report data: missing or empty entries array');
  }
  
  for (let i = 0; i < dataObj.entries.length; i++) {
    const entry = dataObj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || !entryObj.label) {
      throw new Error(`Invalid entry at index ${i}: missing or empty label`);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${i}: invalid amount`);
    }
  }
  
  return {
    title: dataObj.title,
    summary: dataObj.summary,
    entries: dataObj.entries
  } as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      showError(`Invalid JSON in file ${filePath}: ${error.message}`);
    } else if (error instanceof Error) {
      showError(`${error.message}`);
    } else {
      showError(`Failed to load or parse file ${filePath}`);
    }
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };
  
  switch (options.format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown(data, renderOptions);
    case 'text':
      return renderText(data, renderOptions);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    fs.writeFileSync(outputPath, content, 'utf-8');
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv.slice(2));
    const data = loadReportData(dataFile);
    const output = renderReport(data, options);
    writeOutput(output, options.output);
  } catch (error) {
    if (error instanceof Error) {
      showError(error.message);
    } else {
      showError('An unexpected error occurred');
    }
  }
}

main();