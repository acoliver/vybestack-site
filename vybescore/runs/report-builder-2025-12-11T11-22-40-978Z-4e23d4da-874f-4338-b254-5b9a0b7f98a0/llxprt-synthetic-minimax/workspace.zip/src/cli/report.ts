import { readFileSync, writeFileSync } from "fs";
import { ReportData, Format, RenderOptions } from "../types.js";
import { renderMarkdown } from "../formats/markdown.js";
import { renderText } from "../formats/text.js";

function parseArgs(args: string[]): { 
  dataFile: string; 
  format: Format; 
  output?: string; 
  includeTotals: boolean; 
} {
  if (args.length < 3) {
    console.error("Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]");
    process.exit(1);
  }

  const dataFile = args[2];
  let format: Format = "markdown";
  let output: string | undefined;
  let includeTotals = false;

  // Parse arguments starting from index 3
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === "--format") {
      if (i + 1 >= args.length) {
        console.error("Error: --format requires a value");
        process.exit(1);
      }
      format = args[i + 1] as Format;
      i++; // Skip next argument as it is the format value
    } else if (arg === "--output") {
      if (i + 1 >= args.length) {
        console.error("Error: --output requires a value");
        process.exit(1);
      }
      output = args[i + 1];
      i++; // Skip next argument as it is the output path
    } else if (arg === "--includeTotals") {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  // Validate format
  if (format !== "markdown" && format !== "text") {
    console.error("Error: Unsupported format");
    process.exit(1);
  }

  return { dataFile, format, output, includeTotals };
}

function loadReportData(dataFile: string): ReportData {
  try {
    const content = readFileSync(dataFile, "utf8");
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== "string") {
      throw new Error("Invalid data: title is required and must be a string");
    }
    
    if (!data.summary || typeof data.summary !== "string") {
      throw new Error("Invalid data: summary is required and must be a string");
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error("Invalid data: entries is required and must be an array");
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== "string") {
        throw new Error(`Invalid data: entries[${i}].label is required and must be a string`);
      }
      
      if (typeof entry.amount !== "number") {
        throw new Error(`Invalid data: entries[${i}].amount is required and must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading data file: ${error.message}`);
    } else {
      console.error("Error reading data file: Invalid JSON");
    }
    process.exit(1);
  }
}

function main(): void {
  const args = process.argv;
  const { dataFile, format, output, includeTotals } = parseArgs(args);
  const data = loadReportData(dataFile);
  const options: RenderOptions = { includeTotals };
  
  let formatter;
  switch (format) {
    case "markdown":
      formatter = renderMarkdown;
      break;
    case "text":
      formatter = renderText;
      break;
    default:
      console.error("Error: Unsupported format");
      process.exit(1);
  }
  
  const result = formatter.format(data, options);
  
  if (output) {
    try {
      // If output is provided, write to file
      writeFileSync(output, result);
    } catch (error) {
      console.error(`Error writing output file: ${error instanceof Error ? error.message : "Unknown error"}`);
      process.exit(1);
    }
  } else {
    // Write to stdout
    console.log(result);
  }
}

main();