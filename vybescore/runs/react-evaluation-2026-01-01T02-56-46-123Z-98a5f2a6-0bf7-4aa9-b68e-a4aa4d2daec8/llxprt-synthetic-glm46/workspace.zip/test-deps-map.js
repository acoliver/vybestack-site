// Test to see dependencies
import { createInput, createComputed } from "./src/index.js";
import { dependencies } from "./src/types/dependencies.js";

console.log("Testing dependencies tracking...");

// Create input
const [input, setInput] = createInput(1);
console.log("Created input");

// Create first computed
const timesTwo = createComputed(() => {
  console.log("Computing timesTwo...");
  return input() * 2;
});

console.log("Created timesTwo");
console.log("Dependencies count:", dependencies.size);

// Create second computed that depends on the first
const plusOne = createComputed(() => {
  console.log("Computing plusOne...");
  return timesTwo() + 1;
});

console.log("Created plusOne");
console.log("Dependencies count after plusOne:", dependencies.size);
console.log("Dependency map:");
dependencies.forEach((deps, source) => {
  console.log("  Source:", typeof source, "has", deps.size, "dependents");
});
console.log("Initial values:");
console.log("  input:", input());
console.log("  timesTwo:", timesTwo());
console.log("  plusOne:", plusOne());

// Test update
console.log("\nUpdating input to 2...");
setInput(2);
console.log("After update:");
console.log("  input:", input());
console.log("  timesTwo:", timesTwo());
console.log("  plusOne:", plusOne());
