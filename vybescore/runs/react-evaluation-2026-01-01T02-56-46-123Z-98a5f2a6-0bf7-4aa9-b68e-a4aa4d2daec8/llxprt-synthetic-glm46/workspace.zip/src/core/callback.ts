/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  invalidations 
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let callback: (() => void) | null = null
  
  // Set up the callback context for dependency tracking
  callback = () => {
    if (disposed) return
    
    // For dependency tracking, set this callback as the active observer
    const globalObj = globalThis as typeof globalThis & { __currentComputedObserver?: unknown }
    const prevComputed = globalObj.__currentComputedObserver
    
    try {
      // Set this callback as the current observer
      globalObj.__currentComputedObserver = callback
      
      // Run the update function 
      const result = updateFn(value)
      
      // Update the value
      value = result
      
      return result
    } finally {
      // Restore previous context
      globalObj.__currentComputedObserver = prevComputed
    }
  }
  
  // Run the callback once to establish initial dependencies
  try {
    if (callback) callback()
  } catch (e) {
    console.warn('Failed to initialize callback:', e)
  }
  
  // Register this callback for invalidation notifications
  if (callback) {
    invalidations.add(callback)
  }
  
  return () => {
    if (disposed) return
    
    disposed = true
    
    // Remove from invalidations
    if (callback) {
      invalidations.delete(callback)
    }
  }
}
