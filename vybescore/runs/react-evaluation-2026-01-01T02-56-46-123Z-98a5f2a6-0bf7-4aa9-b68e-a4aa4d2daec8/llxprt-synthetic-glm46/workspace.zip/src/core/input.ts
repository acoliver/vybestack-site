/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

import { notifyDependents, trackDependency, invalidations } from '../types/dependencies-new.js'

function isEqualFn<T>(equal: boolean | EqualFn<T> | undefined): EqualFn<T> | undefined {
  if (equal === true) {
    return Object.is as EqualFn<T>
  }
  if (equal === false || equal === undefined) {
    return undefined
  }
  return equal as EqualFn<T>
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = isEqualFn(equal)
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }
  const subscribers = new Set<() => void>()
  
  const read: GetterFn<T> = () => {
    // Set this input as the active dependency source
    const globalObj = globalThis as typeof globalThis & { __currentComputedObserver?: unknown }
    const activeComputed = globalObj.__currentComputedObserver
    
    if (activeComputed) {
      trackDependency(read, activeComputed)
    }
    
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    s.value = nextValue
    
    // Notify all subscribers
    for (const callback of subscribers) {
      callback()
    }
    
    // Notify all dependent observers - this will invalidate computed values
    notifyDependents(read)
    
    return s.value
  }

  // Add subscription support
  (read as GetterFn<T> & { subscribe: (callback: () => void) => () => void }).subscribe = (callback: () => void) => {
    subscribers.add(callback)
    return () => subscribers.delete(callback)
  }
  
  // Add invalidation registration
  (read as GetterFn<T> & { onInvalidate: (callback: () => void) => () => void }).onInvalidate = (callback: () => void) => {
    invalidations.add(callback)
    return () => invalidations.delete(callback)
  }

  return [read, write]
}
