/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn
} from '../types/reactive.js'

import { notifyDependents, trackDependency, removeDependency } from '../types/dependencies-new.js'

function isEqualFn<T>(equal: boolean | EqualFn<T> | undefined): EqualFn<T> | undefined {
  if (equal === true) {
    return Object.is as EqualFn<T>
  }
  if (equal === false || equal === undefined) {
    return undefined
  }
  return equal as EqualFn<T>
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>
): GetterFn<T> {
  const equalFn = isEqualFn(equal)
  let currentValue = value as T
  let disposed = false
  let dirty = true
  
  // Track dependencies during computation
  const currentDependencies = new Set<unknown>()
  
  const compute = (): T => {
    // Clear previous dependencies
    for (const dep of currentDependencies) {
      removeDependency(dep, getter)
    }
    currentDependencies.clear()
    
    // Set this computed as the active observer during computation
    const globalObj = globalThis as typeof globalThis & { __currentComputedObserver?: unknown }
    const prevComputed = globalObj.__currentComputedObserver
    globalObj.__currentComputedObserver = getter
    
    try {
      // Calculate new value
      const newValue = updateFn(currentValue)
      
      // Compare with equalFn if provided
      if (!equalFn || !equalFn(currentValue, newValue)) {
        currentValue = newValue
      }
      
      // Reset dirty flag
      dirty = false
      
      return currentValue
    } finally {
      // Restore previous context
      globalObj.__currentComputedObserver = prevComputed
    }
  }
  
  const getter: GetterFn<T> = () => {
    if (disposed) {
      if (currentValue === undefined) {
        throw new Error('Computed value is undefined after disposal')
      }
      return currentValue
    }
    
    // Track this computed value as a dependency if accessed within another computed context
    const globalObj = globalThis as typeof globalThis & { __currentComputedObserver?: unknown }
    const activeComputed = globalObj.__currentComputedObserver
    
    // If we're being accessed within another computed context, set up dependency tracking
    if (activeComputed && activeComputed !== getter) {
      currentDependencies.add(activeComputed)
      trackDependency(getter, activeComputed)
    }
    
    // Recompute if dirty
    if (dirty) {
      return compute()
    }
    
    return currentValue
  }
  
  // Add invalidate method
  const invalidate = () => {
    if (disposed) return
    
    dirty = true
    
    // Notify all dependents that this computed has changed
    notifyDependents(getter)
  }
  
  // Add dispose method
  ;(getter as GetterFn<T> & { dispose: () => void }).dispose = () => {
    if (!disposed) {
      disposed = true
      
      // Clean up dependencies
      for (const dep of currentDependencies) {
        removeDependency(dep, getter)
      }
      currentDependencies.clear()
    }
  }
  
  // Initialize global computed observer if not already set
  const globalObj = globalThis as typeof globalThis & { __currentComputedObserver?: unknown }
  if (globalObj.__currentComputedObserver === undefined) {
    try {
      Object.defineProperty(globalObj, '__currentComputedObserver', {
        value: undefined,
        writable: true,
        enumerable: true,
        configurable: true
      })
    } catch (e) {
      // If Object.defineProperty fails, fallback to direct assignment
      globalObj.__currentComputedObserver = undefined
    }
  }
  
  // Register for dependency tracking when accessed
  (getter as GetterFn<T> & { invalidate: () => void }).invalidate = invalidate
  
  // Initial computation
  try {
    compute()
  } catch (e) {
    console.warn('Failed to initialize computed value:', e)
  }
  
  return getter
}
