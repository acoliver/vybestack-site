declare global {
  namespace Viest {
    interface TestContext {}
  }
}
export const describe: (...args: unknown[]) => void
export const it: (...args: unknown[]) => void
export const expect: (...args: unknown[]) => unknown
export const beforeEach: (...args: unknown[]) => void
export const afterEach: (...args: unknown[]) => void
export const beforeAll: (...args: unknown[]) => void
export const afterAll: (...args: unknown[]) => void
export {}