/**
 * Reactive tracking system for dependencies and notifications
 */

export interface DependentObserver {
  notify: () => void
}

export class DependencyTracker {
  private static current: Set<DependentObserver> | null = null
  private static dependencies: Map<unknown, Set<DependentObserver>> = new Map()

  static getCurrent(): Set<DependentObserver> | null {
    return this.current
  }

  static startTracking(observer: DependentObserver): void {
    if (!this.current) {
      this.current = new Set()
    }
    this.current.add(observer)
  }

  static stopTracking(observer: DependentObserver): void {
    if (this.current) {
      this.current.delete(observer)
      if (this.current.size === 0) {
        this.current = null
      }
    }
  }

  static trackDependency(source: unknown): void {
    if (!this.current) return

    if (!this.dependencies.has(source)) {
      this.dependencies.set(source, new Set())
    }

    const dependents = this.dependencies.get(source)!
    for (const observer of this.current) {
      dependents.add(observer)
    }
  }

  static notifyDependents(source: unknown): void {
    const dependents = this.dependencies.get(source)
    if (dependents) {
      for (const observer of dependents) {
        observer.notify()
      }
    }
  }

  static removeDependents(observer: DependentObserver): void {
    for (const dependents of this.dependencies.values()) {
      dependents.delete(observer)
    }
  }
}