/**
 * Shared dependency tracking for reactive primitives
 */

// Map from reactive source to its dependencies
export const dependencies = new Map<unknown, Set<unknown>>()

// Set of invalidation callbacks to run when sources change
export const invalidations = new Set<() => void>()

export function notifyDependents(source: unknown): void {
  const deps = dependencies.get(source)
  if (deps) {
    // Create a copy to avoid issues with simultaneous modifications
    const depsCopy = Array.from(deps)
    for (const observer of depsCopy) {
      // Trigger re-evaluation for dependent observers
      if (typeof observer === 'function') {
        try {
          const typedObserver = observer as { invalidate?: () => void }
          if (typedObserver.invalidate) {
            typedObserver.invalidate()
          }
        } catch (e) {
          console.error('Error invalidating observer:', e)
        }
      }
    }
  }

  // Notify all invalidation callbacks
  for (const callback of invalidations) {
    try {
      callback()
    } catch (e) {
      console.error('Error in invalidation callback:', e)
    }
  }
}

export function trackDependency(source: unknown, observer: unknown): void {
  if (!dependencies.has(source)) {
    dependencies.set(source, new Set())
  }
  dependencies.get(source)!.add(observer)
}

export function removeDependency(source: unknown, observer: unknown): void {
  const deps = dependencies.get(source)
  if (deps) {
    deps.delete(observer)
    if (deps.size === 0) {
      dependencies.delete(source)
    }
  }
}