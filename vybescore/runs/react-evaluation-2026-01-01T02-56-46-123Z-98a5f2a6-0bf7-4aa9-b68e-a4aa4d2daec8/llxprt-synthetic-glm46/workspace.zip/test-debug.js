// Test to debug dependency tracking
import { createInput, createComputed } from "./src/index.js";

console.log("Testing dependency tracking...");

// Create input
const [input, setInput] = createInput(1);
console.log("Created input with value:", input());

// Create computed
const doubled = createComputed(() => {
  console.log("Computing doubled...");
  return input() * 2;
});

console.log("Created computed, value:", doubled());

// Debug dependency tracking
console.log("Before update:");
setInput(2);
console.log("After setting input to 2:");
console.log("input:", input());
console.log("doubled:", doubled());

// Check dependencies
import { dependencies } from "./src/types/dependencies-new.js";
console.log("Dependencies count:", dependencies.size);
console.log("Dependencies entries:");
dependencies.forEach((deps, source) => {
  console.log("  Source has", deps.size, "dependencies");
});
