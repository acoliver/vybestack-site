// Test to debug dependency tracking from one computed to another
import { createInput, createComputed } from "./src/index.js";

console.log("Testing computed-to-computed dependencies...");

// Create input
const [input, setInput] = createInput(1);
console.log("Created input with value:", input());

// Create first computed
const timesTwo = createComputed(() => {
  console.log("Computing timesTwo...");
  return input() * 2;
});

console.log("Created timesTwo, value:", timesTwo());

// Create second computed that depends on the first
const plusOne = createComputed(() => {
  console.log("Computing plusOne...");
  return timesTwo() + 1;
});

console.log("Created plusOne, value:", plusOne());

// Debug dependency tracking
console.log("Before update:");
setInput(2);
console.log("After setting input to 2:");
console.log("input:", input());
console.log("timesTwo:", timesTwo());
console.log("plusOne:", plusOne());

console.log("Before second update:");
setInput(3);
console.log("After setting input to 3:");
console.log("input:", input());
console.log("timesTwo:", timesTwo());
console.log("plusOne:", plusOne());
