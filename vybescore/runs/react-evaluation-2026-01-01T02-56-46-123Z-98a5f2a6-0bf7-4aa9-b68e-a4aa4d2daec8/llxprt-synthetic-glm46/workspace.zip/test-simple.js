// Simple test to debug the reactive system
import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing reactive system...');

// Test 1: Basic input
console.log('Test 1: Basic input');
const [input, setInput] = createInput(1);
console.log('input() =', input()); // Should be 1
setInput(2);
console.log('input() after 2 =', input()); // Should be 2

// Test 2: Computed depending on input
console.log('\nTest 2: Computed depending on input');
const doubled = createComputed(() => input() * 2);
console.log('doubled() =', doubled()); // Should be 4
setInput(3);
console.log('doubled() after input=3 =', doubled()); // Should be 6

// Test 3: Computed depending on computed
console.log('\nTest 3: Computed depending on computed');
const plusOne = createComputed(() => doubled() + 1);
console.log('plusOne() =', plusOne()); // Should be 7
setInput(4);
console.log('doubled() after input=4 =', doubled()); // Should be 8
console.log('plusOne() after input=4 =', plusOne()); // Should be 9

// Test 4: Callback
console.log('\nTest 4: Callback');
let callbackValue = 0;
const unsubscribe = createCallback(() => {
  callbackValue = plusOne();
});
console.log('callbackValue =', callbackValue); // Should be 9
setInput(5);
console.log('callbackValue after input=5 =', callbackValue); // Should be 11

console.log('\nAll tests completed!');