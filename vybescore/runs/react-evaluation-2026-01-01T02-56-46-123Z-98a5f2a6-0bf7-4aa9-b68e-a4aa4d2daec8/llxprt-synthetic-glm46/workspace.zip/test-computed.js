// Simple test to debug the computed system
import { createInput, createComputed } from './src/index.js';

console.log('Testing computed reactivity...');

// Create an input
const [input, setInput] = createInput(1);

// Create computed that depends on input
const doubled = createComputed(() => {
  console.log('Computing doubled...');
  return input() * 2;
});

console.log('Initial values:');
console.log('input =', input()); // Should be 1
console.log('doubled =', doubled()); // Should be 2

console.log('\nUpdating input to 2:');
setInput(2);
console.log('input =', input()); // Should be 2
console.log('doubled =', doubled()); // Should be 4

console.log('\nUpdating input to 3:');
setInput(3);
console.log('input =', input()); // Should be 3
console.log('doubled =', doubled()); // Should be 6

// Test computed depending on computed
console.log('\nTesting computed depending on computed:');
const plusOne = createComputed(() => {
  console.log('Computing plusOne...');
  return doubled() + 1;
});

console.log('After creating plusOne:');
console.log('input =', input());
console.log('doubled =', doubled());
console.log('plusOne =', plusOne());

console.log('\nUpdating input to 4:');
setInput(4);
console.log('input =', input());
console.log('doubled =', doubled());
console.log('plusOne =', plusOne());