/**
 * Capitalizes the first character of each sentence.
 * - Inserts exactly one space between sentences even if input omitted it
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spaces around sentence boundaries
  // Insert space after .!? if followed by a lowercase letter (not an abbreviation)
  let normalized = text.replace(/([.!?])([a-z])/g, '$1 $2');
  
  // Collapse multiple spaces into single space
  normalized = normalized.replace(/\s+/g, ' ').trim();
  
  // Capitalize first letter of each sentence
  // A sentence starts after .!? and at the beginning
  const result = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts URLs from text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern matching common URL formats
  // Matches http://, https://, and www. URLs
  const urlRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    return url.replace(/[.,;:!?)\]"']+$/, '');
  });
}

/**
 * Converts all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s<>"']*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    // Legacy extensions: .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py
    const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|\/|$)/i.test(path);
    const hasCgiBin = /\/cgi-bin\//i.test(path);
    const hasQueryString = /[?&]/.test(path);
    
    // Check if path should be rewritten to docs subdomain
    // Only rewrite if: starts with /docs/ AND has NO dynamic hints
    if (path.startsWith('/docs/') && !hasLegacyExtension && !hasCgiBin && !hasQueryString) {
      return newScheme + 'docs.' + host + path;
    }
    
    // Just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  // Special check for February 29 (must be a leap year)
  if (month === 2 && day === 29) {
    // Leap year check: divisible by 4, but not by 100 unless also by 400
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return match[3];
}
