/**
 * Finds words beginning with the prefix, excluding the listed exceptions.
 * Uses word boundaries to ensure complete word matching.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  const wordPattern = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'gi');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];
    // Check if the word is not in the exceptions list (case-insensitive)
    const isException = exceptions.some(exception => 
      exception.toLowerCase() === word.toLowerCase()
    );
    
    if (!isException && !matches.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Returns the full match including the digit prefix.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, ensuring it's not at the start
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // This pattern looks for any 2-4 character sequence that repeats immediately
  if (/(.{2,4})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Can use :: shorthand for consecutive zero groups
  // - Can include IPv4 mapped addresses (but we want to exclude pure IPv4)
  
  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern (full and shorthand versions)
  // Matches:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8::1, ::1, ::ffff:192.0.2.1 (IPv4-mapped)
  const ipv6Pattern = /(?:^|(?<=\s))([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|::/;
  
  // Also need to handle addresses with :: in the middle
  const ipv6ShorthandPattern = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/i;
  
  return ipv6Pattern.test(value) || ipv6ShorthandPattern.test(value);
}
