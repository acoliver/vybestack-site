#!/usr/bin/env node

import fs from 'node:fs';
import { ReportData, RenderOptions } from '../types.js';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';

const RENDERERS = {
  markdown: new MarkdownRenderer(),
  text: new TextRenderer(),
} as const;

type Format = keyof typeof RENDERERS;

function parseArguments(): { 
  dataPath: string; 
  format: Format; 
  outputPath?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  let format: Format | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        format = args[i + 1] as Format;
        i++; // Skip the format value
        break;
      case '--output':
        outputPath = args[i + 1];
        i++; // Skip the output path
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
    }
  }
  
  if (!format || !RENDERERS[format]) {
    console.error(`Error: Unsupported format "${format || 'undefined'}"`);
    process.exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  const record = data as Record<string, unknown>;
  
  if (!record || typeof record !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  if (typeof record.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }
  
  if (typeof record.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(record.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }
  
  for (const [index, entry] of record.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (typeof entryRecord.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} has missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryRecord.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} has missing or invalid "amount" field (expected number)`);
    }
  }
  
  return data as ReportData;
}

function loadData(path: string): ReportData {
  try {
    const rawData = fs.readFileSync(path, 'utf-8');
    const parsedData = JSON.parse(rawData);
    return validateReportData(parsedData);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in ${path}: ${error.message}`);
    } else if (error instanceof Error && error.message.startsWith('Invalid JSON:')) {
      console.error(`Error: ${error.message}`);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: ${path}`);
    } else {
      console.error(`Error reading file ${path}: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function main(): void {
  const { dataPath, format, outputPath, includeTotals } = parseArguments();
  
  const data = loadData(dataPath);
  const options: RenderOptions = { includeTotals };
  
  const renderer = RENDERERS[format];
  const output = renderer.render(data, options);
  
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output);
      console.log(`Report written to ${outputPath}`);
    } catch (error) {
      console.error(`Error writing to ${outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
