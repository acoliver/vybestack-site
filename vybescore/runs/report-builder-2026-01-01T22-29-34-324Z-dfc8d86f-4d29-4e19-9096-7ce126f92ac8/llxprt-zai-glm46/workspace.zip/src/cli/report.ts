#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const RENDERERS = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let argIndex = 0;
  while (argIndex < args.length) {
    const arg = args[argIndex];

    if (arg === '--format') {
      argIndex++;
      if (argIndex >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      result.format = args[argIndex];
    } else if (arg === '--output') {
      argIndex++;
      if (argIndex >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      result.outputPath = args[argIndex];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: Unknown option: ${arg}`);
      process.exit(1);
    } else if (result.inputFile === '') {
      result.inputFile = arg;
    } else {
      console.error(`Error: Unexpected argument: ${arg}`);
      process.exit(1);
    }

    argIndex++;
  }

  if (result.inputFile === '') {
    console.error('Error: Input file path is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (result.format === '') {
    console.error('Error: --format is required');
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

function main(): void {
  const args = process.argv.slice(2);
  const cliArgs = parseArgs(args);

  // Read and parse JSON file
  let fileContent: string;
  try {
    fileContent = fs.readFileSync(cliArgs.inputFile, 'utf-8');
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading file: ${error.message}`);
    } else {
      console.error('Error reading file');
    }
    process.exit(1);
  }

  let jsonData: unknown;
  try {
    jsonData = JSON.parse(fileContent);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error parsing JSON: ${error.message}`);
    } else {
      console.error('Error parsing JSON');
    }
    process.exit(1);
  }

  // Validate data structure
  let reportData: ReportData;
  try {
    reportData = validateReportData(jsonData);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Invalid report data');
    }
    process.exit(1);
  }

  // Get renderer for specified format
  const renderer = RENDERERS[cliArgs.format as keyof typeof RENDERERS];
  if (!renderer) {
    console.error(`Error: Unsupported format: ${cliArgs.format}`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  // Render report
  const output = renderer(reportData, { includeTotals: cliArgs.includeTotals });

  // Write output
  if (cliArgs.outputPath) {
    try {
      fs.writeFileSync(cliArgs.outputPath, output, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing output file: ${error.message}`);
      } else {
        console.error('Error writing output file');
      }
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
