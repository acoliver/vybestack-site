/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

// Import notifyCallbacks to trigger callback updates when computed values change
import { notifyCallbacks } from './callback.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue) => {
      // Execute the update function to compute new value
      // During execution, this observer will be set as active
      const result = updateFn(currentValue)
      return result
    }
  }

  const getter: GetterFn<T> = () => {
    // Register as dependent observer if there's an active observer
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      // This computed value is being read by another observer
      // The dependency tracking happens automatically when reactive values are read
    }
    
    // Get the current value before computation
    const previousValue = observer.value
    
    // Trigger computation if value is stale or not computed yet
    updateObserver(observer)
    
    // If value changed, trigger callbacks
    if (previousValue !== observer.value) {
      notifyCallbacks()
    }
    
    return observer.value!
  }

  return getter
}
