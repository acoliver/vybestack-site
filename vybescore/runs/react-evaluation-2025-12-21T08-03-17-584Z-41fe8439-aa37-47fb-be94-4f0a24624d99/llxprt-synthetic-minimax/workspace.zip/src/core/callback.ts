/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Store active callback observers using a Set
const callbackObservers = new Set<Observer<unknown>>()

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }

  // Cast to unknown for storage
  const observerRef = observer as Observer<unknown>
  
  // Register observer to track dependencies and enable updates
  callbackObservers.add(observerRef)
  
  // Trigger initial execution to establish dependencies
  updateObserver(observerRef)

  return () => {
    // Immediately remove the observer when unsubscribed
    callbackObservers.delete(observerRef)
  }
}

// Export function to notify all callbacks when dependencies change
export function notifyCallbacks(): void {
  // Create a snapshot of current observers to avoid modification during iteration
  const currentObservers = Array.from(callbackObservers)
  for (const observer of currentObservers) {
    updateObserver(observer)
  }
}
