declare module 'sql.js' {
  interface SqlJsStatic {
    Database: {
      new(data?: Uint8Array): Database;
    };
  }

  interface Database {
    run(query: string, params?: unknown[]): { changes: number };
    exec(query: string): void;
    export(): Uint8Array;
    prepare(query: string): Statement;
    close(): void;
  }

  interface Statement {
    step(): boolean;
    getAsObject(): Record<string, unknown>;
    free(): void;
  }

  function initSqlJs(config?: { locateFile: (file: string) => string }): Promise<SqlJsStatic>;
  
  export = initSqlJs;
}