import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface Database {
  run: (query: string, params?: unknown[]) => { changes: number };
  exec: (query: string) => void;
  export: () => Uint8Array;
}

let db: Database | null = null;
const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<Database> {
  try {
    const initSql = fs.readFileSync('db/schema.sql', 'utf8');
    
    const initSqlJs = await import('sql.js');
    const SQL = await initSqlJs.default();
    
    let database: Database;
    
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      database = new SQL.Database(fileBuffer);
    } else {
      database = new SQL.Database();
      database.exec(initSql);
      
      if (!fs.existsSync('data')) {
        fs.mkdirSync('data', { recursive: true });
      }
      
      const data = database.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
    }
    
    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabaseToDisk(database: Database): void {
  try {
    const data = database.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database to disk:', error);
  }
}

interface FormDataParams {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function validateFormSubmission(formData: FormDataParams): string[] {
  const errors: string[] = [];
  
  // Required fields validation
  if (!formData.firstName?.trim()) {
    errors.push('First name is required');
  }
  
  if (!formData.lastName?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  
  if (!formData.city?.trim()) {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push('State/Province/Region is required');
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push('Postal/Zip code is required');
  }
  
  if (!formData.country?.trim()) {
    errors.push('Country is required');
  }
  
  if (!formData.email?.trim()) {
    errors.push('Email is required');
  } else {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push('Email is not valid');
    }
  }
  
  if (!formData.phone?.trim()) {
    errors.push('Phone number is required');
  } else {
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push('Phone number is not valid');
    }
  }
  
  if (formData.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
    errors.push('Postal code should only contain letters, numbers, spaces, and hyphens');
  }
  
  return errors;
}

function insertFormData(database: Database, formData: FormDataParams): void {
  const query = `
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `;
  
  database.run(query, [
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
}

async function startServer(): Promise<void> {
  try {
    db = await initializeDatabase();
    
    const app = express();
    const port = process.env.PORT || 3535;
    
    app.set('view engine', 'ejs');
    app.set('views', path.join(__dirname, '..', 'src', 'templates'));
    
    app.use(express.static('public'));
    app.use(express.urlencoded({ extended: true }));
    
    app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });
    
    app.get('/thank-you', (req, res) => {
      const firstName = req.query.firstName || 'friend';
      res.render('thank-you', { firstName });
    });
    
    app.post('/submit', (req, res) => {
      const errors = validateFormSubmission(req.body);
      
      if (errors.length > 0) {
        return res.status(400).render('form', {
          errors,
          values: req.body
        });
      }
      
      if (db) {
        insertFormData(db, req.body);
        saveDatabaseToDisk(db);
      }
      
      res.redirect(302, `/thank-you?firstName=${encodeURIComponent(req.body.firstName)}`);
    });
    
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        console.log('Server closed');
        db = null;
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(console.error);
