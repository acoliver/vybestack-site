import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const errors: string[] = [];
    let validatedPage: number | undefined;
    let validatedLimit: number | undefined;
    
    if (pageParam !== undefined) {
      const page = Number(pageParam);
      if (isNaN(page) || !isFinite(page) || page <= 0 || !Number.isInteger(page)) {
        errors.push('page must be a positive integer');
      } else if (page > 1000000) {
        errors.push('page value is excessive');
      } else {
        validatedPage = page;
      }
    }
    
    if (limitParam !== undefined) {
      const limit = Number(limitParam);
      if (isNaN(limit) || !isFinite(limit) || limit <= 0 || !Number.isInteger(limit)) {
        errors.push('limit must be a positive integer');
      } else if (limit > 1000) {
        errors.push('limit value is excessive');
      } else {
        validatedLimit = limit;
      }
    }
    
    if (errors.length > 0) {
      res.status(400).json({ error: 'Invalid parameters', details: errors });
      return;
    }

    const payload = listInventory(db, { page: validatedPage, limit: validatedLimit });
    res.json(payload);
  });

  return app;
}
