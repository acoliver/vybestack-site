import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Serve static files from public directory
app.use('/public', express.static(path.join(__dirname, '../public')));

// Parse form data
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Initialize SQLite database
let db: Database | null = null;

// Configure Express view engine
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Check if database file exists
    const fs = await import('fs');
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const buffer = fs.readFileSync(dbPath);
      db = new SQL.Database(buffer);
    } else {
      db = new SQL.Database();
      
      // Load and execute schema
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.exec(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function validateFormData(data: FormData): { errors: ValidationErrors; isValid: boolean } {
  const errors: ValidationErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`;
    }
  });

  // Email validation (simple regex)
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation (accepts international formats)
  if (data.phone && data.phone.trim() !== '') {
    const phoneRegex = /^@?[\d\s\-()]{7,}$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  return {
    errors,
    isValid: Object.keys(errors).length === 0
  };
}

function insertSubmission(data: FormData): void {
  if (!db) {
    console.error('Database not initialized');
    return;
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.firstName.trim(),
    data.lastName.trim(),
    data.streetAddress.trim(),
    data.city.trim(),
    data.stateProvince.trim(),
    data.postalCode.trim(),
    data.country.trim(),
    data.email.trim(),
    data.phone.trim()
  ]);

  stmt.free();
  
  // Write database back to file
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  const dbData = db.export();
  fs.writeFileSync(dbPath, Buffer.from(dbData));
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render(path.join(__dirname, 'templates/form.ejs'), {
    errors: {},
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const { errors, isValid } = validateFormData(formData);

  if (!isValid) {
    // Re-render form with errors and values
    res.status(400).render(path.join(__dirname, 'templates/form.ejs'), {
      errors,
      values: formData
    });
    return;
  }

  try {
    insertSubmission(formData);
    // Redirect with first name as query parameter
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Failed to insert submission:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Extract first name from query parameters
  const firstName = req.query.firstName as string || 'Friend';
  res.render(path.join(__dirname, 'templates/thank-you.ejs'), {
    firstName
  });
});

// Graceful shutdown handling
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      db.close();
      console.log('Database closed successfully');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  // Handle server errors
  server.on('error', (error) => {
    console.error('Server error:', error);
    gracefulShutdown();
  });
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
