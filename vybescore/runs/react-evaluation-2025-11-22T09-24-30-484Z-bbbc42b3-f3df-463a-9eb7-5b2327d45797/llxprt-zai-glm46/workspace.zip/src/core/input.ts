import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  setActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && s.observers) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      
      // Notify all observers
      if (s.observers) {
        for (const observer of s.observers) {
          updateObserverRecursive(observer)
        }
      }
    }
    return s.value
  }

  return [read, write]
}

function updateObserverRecursive(observer: ObserverR): void {
  const prevObserver = getActiveObserver()
  setActiveObserver(observer as Observer<unknown>)
  try {
    const typedObserver = observer as Observer<unknown>
    
    // Update this observer
    typedObserver.value = typedObserver.updateFn(typedObserver.value)
    
    // Notify all subscribers
    if (typedObserver.subscribers) {
      for (const subscriber of typedObserver.subscribers) {
        updateObserverRecursive(subscriber)
      }
    }
  } finally {
    setActiveObserver(prevObserver)
  }
}
