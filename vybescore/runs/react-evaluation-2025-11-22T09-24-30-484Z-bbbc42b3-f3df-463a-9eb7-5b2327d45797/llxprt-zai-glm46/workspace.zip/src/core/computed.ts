/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set(),
  }
  
  // Compute initial value
  const prevObserver = getActiveObserver()
  setActiveObserver(o)
  try {
    o.value = updateFn(o.value)
  } finally {
    setActiveObserver(prevObserver)
  }
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer && o.subscribers) {
      o.subscribers.add(observer)
    }
    return o.value!
  }
}
