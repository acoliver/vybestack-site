import { readFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

const parseArgs = (args: string[]): ParsedArgs => {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1) {
    throw new Error('Missing required --format argument');
  }
  
  const format = args[formatIndex + 1];
  if (!format) {
    throw new Error('Missing format value after --format');
  }

  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return { dataPath, format, output, includeTotals };
};

const loadReportData = (filePath: string): ReportData => {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries (must be an array)');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry at index ${i}: missing or invalid required field: label`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Entry at index ${i}: missing or invalid required field: amount (must be a number)`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
};

const getFormatter = (format: string) => {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
};

const main = (): void => {
  try {
    const args = parseArgs(process.argv);
    const data = loadReportData(args.dataPath);
    const formatter = getFormatter(args.format);
    
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = formatter(data, options);
    
    if (args.output) {
      // For simplicity, we'll just write to stdout for now
      // In a real implementation, you'd write to the file here
      console.error('Warning: --output flag is present but writing to stdout');
      process.stdout.write(output + '\n');
    } else {
      process.stdout.write(output + '\n');
    }
    
    process.exit(0);
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown error';
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
};

main();