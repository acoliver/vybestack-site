import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, FormatType, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(args: string[]): {
  dataPath: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
} {
  const dataPath = args[0];
  let format: FormatType = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatArg = args[i + 1];
      if (!formatArg) {
        throw new Error('--format requires a value');
      }
      if (formatArg !== 'markdown' && formatArg !== 'text') {
        throw new Error(`Unsupported format: ${formatArg}`);
      }
      format = formatArg;
      i++;
    } else if (arg === '--output') {
      outputPath = args[i + 1];
      if (!outputPath) {
        throw new Error('--output requires a value');
      }
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!dataPath) {
    throw new Error('Data file path is required');
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadData(path: string): ReportData {
  const content = readFileSync(path, 'utf-8');
  let data: unknown;

  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error(`Failed to parse JSON: ${error instanceof Error ? error.message : String(error)}`);
  }

  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid "entries" field (must be an array)');
  }

  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: entry must be an object');
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: entry missing or invalid "label" field (must be a string)');
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: entry missing or invalid "amount" field (must be a number)');
    }
  }

  return data as ReportData;
}

function render(data: ReportData, format: FormatType, options: RenderOptions): string {
  const renderer = formatRenderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer(data, options);
}

function main(): void {
  const args = process.argv.slice(2);

  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs(args);
    const data = loadData(dataPath);
    const output = render(data, format, { includeTotals });

    if (outputPath) {
      writeFileSync(outputPath, output, 'utf-8');
      console.error(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
