#!/usr/bin/env node

import * as fs from 'node:fs';
import type { RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      if (result.dataFile) {
        throw new Error(`Unexpected argument: ${arg}`);
      }
      result.dataFile = arg;
    }

    i++;
  }

  if (!result.dataFile) {
    throw new Error('Missing required argument: <data.json>');
  }

  if (!result.format) {
    throw new Error('Missing required option: --format <format>');
  }

  return result;
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    if (!formatters[args.format]) {
      console.error(`Unsupported format: ${args.format}`);
      process.exit(1);
    }

    const jsonContent = fs.readFileSync(args.dataFile, 'utf-8');
    let jsonData: unknown;

    try {
      jsonData = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to parse JSON file: ${error.message}`);
      }
      throw new Error('Failed to parse JSON file');
    }

    const reportData = validateReportData(jsonData);

    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };

    const renderer = formatters[args.format];
    const output = renderer(reportData, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();

