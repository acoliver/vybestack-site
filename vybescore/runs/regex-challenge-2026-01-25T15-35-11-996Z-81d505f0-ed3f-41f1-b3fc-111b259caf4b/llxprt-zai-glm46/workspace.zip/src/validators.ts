export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Main email pattern: local@domain.tld
  // Local part: allow letters, digits, dots, hyphens, underscores, plus signs
  // Domain: letters, digits, hyphens, dots (but no consecutive dots or trailing dots)
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  // No double dots in local or domain
  if (value.includes('..')) {
    return false;
  }
  
  // No leading or trailing dots in local part
  const [local, domain] = value.split('@');
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // No trailing dots in domain
  if (domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(
  value: string,
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  options?: PhoneValidationOptions
): boolean {
  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');

  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    // Could be 1 at start if total is 11 digits
    digits = digits.slice(1);
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must have trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+?54? - Optional country code +54
  // 9? - Optional mobile indicator
  // 0? - Optional trunk prefix
  // \d{2,4} - Area code (2-4 digits)
  // \d{6,8}$ - Subscriber number (6-8 digits)
  const withCountryCode = /^\+?549?0?[1-9]\d{1,3}\d{6,8}$/;
  const withoutCountryCode = /^9?0[1-9]\d{1,3}\d{6,8}$/;
  
  // Check if it matches either pattern
  if (withCountryCode.test(cleaned)) {
    // Extract area code and validate it
    const match = cleaned.match(/^\+?549?0?([1-9]\d{1,3})\d{6,8}$/);
    if (match) {
      const areaCode = match[1];
      const subscriber = cleaned.slice(-6).length >= 6;
      return areaCode.length >= 2 && areaCode.length <= 4 && subscriber;
    }
  }
  
  if (withoutCountryCode.test(cleaned)) {
    const match = cleaned.match(/^9?0([1-9]\d{1,3})\d{6,8}$/);
    if (match) {
      const areaCode = match[1];
      return areaCode.length >= 2 && areaCode.length <= 4;
    }
  }
  
  return false;
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and X Æ A-12 style names (with digits mixed in)
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Pattern: allow letters (including unicode), accents, apostrophes, hyphens, spaces
  // \p{L} matches any unicode letter
  // \p{M} matches marks (accents, etc.)
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Check for strange patterns like X Æ A-12 (digits mixed with letters)
  // This is more nuanced - we want to reject if there are digits
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length based on card type
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][2-9][0-9]\d{12})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Runs the Luhn algorithm to validate a credit card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
