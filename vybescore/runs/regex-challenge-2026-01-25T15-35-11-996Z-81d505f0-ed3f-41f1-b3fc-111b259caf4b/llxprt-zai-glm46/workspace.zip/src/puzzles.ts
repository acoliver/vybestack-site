/**
 * Matches words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: word boundary, prefix, then word characters
  // Use word boundaries to match whole words
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => 
    !exceptions.some(exc => exc.toLowerCase() === match.toLowerCase())
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Find all matches of digit followed by token
  const digitTokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(digitTokenPattern);

  return matches || [];
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (non-alphanumeric, non-whitespace)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length 10
  if (value.length < 10) {
    return false;
  }

  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }

  // No immediate repeated sequences
  // Check for patterns like abab, abcabc, etc.
  for (let i = 0; i < value.length - 3; i++) {
    // Check for 2-character repeats (abab)
    if (i + 3 < value.length) {
      const pair1 = value.slice(i, i + 2);
      const pair2 = value.slice(i + 2, i + 4);
      if (pair1 === pair2) {
        return false;
      }
    }

    // Check for 3-character repeats (abcabc)
    if (i + 5 < value.length) {
      const triple1 = value.slice(i, i + 3);
      const triple2 = value.slice(i + 3, i + 6);
      if (triple1 === triple2) {
        return false;
      }
    }
  }

  // Check for repeated patterns with any length
  // This catches things like "123123123"
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.slice(i, i + len);
      const next = value.slice(i + len, i + len * 2);
      if (pattern === next) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Check for IPv6 anywhere in the string
  // IPv6 patterns to look for:
  // - Full: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed: 2001:db8::1
  // - Loopback: ::1
  // - All zeros: ::

  // General pattern: look for hex groups separated by colons
  // Must have at least 2 groups of hex digits with colons
  // This will match IPv6 but not IPv4
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{0,4}/;

  // Also match :: notation
  const compressedPattern = /::[0-9a-fA-F]{0,4}/;

  // Check if any pattern matches
  if (ipv6Pattern.test(value) || compressedPattern.test(value)) {
    return true;
  }

  return false;
}
