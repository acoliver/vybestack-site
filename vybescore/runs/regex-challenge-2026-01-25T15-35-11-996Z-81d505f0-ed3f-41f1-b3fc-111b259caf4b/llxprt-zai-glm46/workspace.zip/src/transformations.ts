/**
 * Capitalizes the first character of each sentence.
 * - Inserts exactly one space between sentences if input omitted it
 * - Collapses extra spaces sensibly
 * - Preserves abbreviations when possible (e.g., "Dr. Smith" stays "Dr. Smith")
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence boundaries
  // Replace multiple spaces with single space
  let result = text.replace(/\s+/g, ' ');

  // Ensure space after ., !, ? if followed by a letter
  result = result.replace(/([.!?])([a-z])/gi, '$1 $2');

  // Capitalize first character of the entire text
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Capitalize after sentence boundaries
  // Use negative lookbehind to avoid capitalizing after abbreviations
  // Common abbreviations: Mr, Mrs, Ms, Dr, Prof, Sr, Jr, etc.
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'eg', 'ie', 'St'];
  const abbrPattern = abbreviations.join('|');

  // Split by sentence boundaries but look for abbreviations
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, boundary, letter) => {
    // Check if this is after an abbreviation
    const beforeBoundary = result.substring(0, result.indexOf(boundary) + boundary.length - 1);
    const lastWord = beforeBoundary.split(/\s+/).pop();

    // Skip capitalization if the last word looks like an abbreviation
    if (lastWord && new RegExp(`^(${abbrPattern})$`, 'i').test(lastWord.replace(/[.!?]$/, ''))) {
      return boundary + letter;
    }

    return boundary + letter.toUpperCase();
  });

  // Clean up any remaining multiple spaces
  result = result.replace(/\s+/g, ' ').trim();

  return result;
}

/**
 * Finds URLs in text and returns them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https URLs
  // Match the URL but exclude trailing punctuation
  const urlPattern = /https?:\/\/[^\s<>"()[\]{}|\\^`[\]]+[^\s<>"()[\]{}|\\^`[\].,!?;:]/g;

  const matches = text.match(urlPattern);

  if (!matches) {
    return [];
  }

  // Additional cleanup for trailing characters that might have been included
  return matches.map(url => {
    // Remove any trailing punctuation that slipped through
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * Converts all http:// URLs to https://, leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs for example.com:
 * - Always upgrades http:// to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//gi, 'https://');

  // Pattern to match example.com URLs
  // Group 1: protocol (https://)
  // Group 2: path starting with /docs/
  const urlPattern = /(https:\/\/example\.com)(\/docs\/[^\s<>"()[\]{}|\\^`[\]]*)/gi;

  result = result.replace(urlPattern, (match, host, path) => {
    // Check for dynamic hints that should prevent host rewrite
    const hints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];

    // Check if any hint is in the path
    const hasDynamicHint = hints.some(hint => path.toLowerCase().includes(hint));

    if (hasDynamicHint) {
      // Keep original host but with upgraded protocol
      return host + path;
    }

    // Rewrite to docs.example.com
    return 'https://docs.example.com' + path;
  });

  return result;
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];

  if (day < 1 || day > maxDay) {
    return 'N/A';
  }

  // Special case for February in non-leap years
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }

  return year;
}
