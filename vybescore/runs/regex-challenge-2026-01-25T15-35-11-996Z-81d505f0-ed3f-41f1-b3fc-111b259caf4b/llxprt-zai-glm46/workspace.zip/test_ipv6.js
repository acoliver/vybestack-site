const test = "Address: 2001:db8::1";
const patterns = [
  /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/,
  /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/,
  /^::$/,
  /^::1$/,
  /^:(?::[0-9a-fA-F]{1,4}){1,7}$/,
  /^(?:[0-9a-fA-F]{1,4}:){1,7}:$/,
];

console.log("Testing:", test);
for (let i = 0; i < patterns.length; i++) {
  console.log(`Pattern ${i}:`, patterns[i].test(test.trim()));
}

// Test the embedded pattern
const embedded = /(?:^|[^\d:a-f])(?:(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{0,4}|::)(?:[^\d:a-f]|$)/;
console.log("Embedded pattern:", embedded.test(test));

// Try a simpler pattern
const simple = /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/;
console.log("Simple pattern:", simple.test(test));
