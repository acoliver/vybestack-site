const test = "Address: 2001:db8::1";

// Extract just the IPv6 part
const match = test.match(/([0-9a-fA-F:]+)/);
console.log("Extracted:", match ? match[0] : "none");

// Test if "2001:db8::1" is a valid IPv6
const ipv6 = "2001:db8::1";
const patterns = [
  /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/,
  /^[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{0,4}:[0-9a-fA-F]{0,4}/,
];

console.log("\nTesting just IPv6:", ipv6);
for (let i = 0; i < patterns.length; i++) {
  console.log(`Pattern ${i}:`, patterns[i].test(ipv6));
}
