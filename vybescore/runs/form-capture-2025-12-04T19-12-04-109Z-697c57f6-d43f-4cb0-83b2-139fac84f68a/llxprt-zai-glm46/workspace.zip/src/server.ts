import express, { Request, Response } from 'express';
import * as http from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  general?: string;
}

class FormCaptureApp {
  private app: express.Application;
  private server: http.Server | null = null;
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, '..', 'src', 'templates'));
  }

  private setupRoutes(): void {
    this.app.get('/', this.handleFormGet.bind(this));
    this.app.post('/submit', this.handleSubmit.bind(this));
    this.app.get('/thank-you', this.handleThankYou.bind(this));
  }

  private validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
    const errors: FormErrors = {};

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.firstName = 'First name is required';
    }

    if (!data.lastName?.trim()) {
      errors.lastName = 'Last name is required';
    }

    if (!data.streetAddress?.trim()) {
      errors.streetAddress = 'Street address is required';
    }

    if (!data.city?.trim()) {
      errors.city = 'City is required';
    }

    if (!data.stateProvince?.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }

    if (!data.postalCode?.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    }

    if (!data.country?.trim()) {
      errors.country = 'Country is required';
    }

    if (!data.email?.trim()) {
      errors.email = 'Email is required';
    } else if (!this.isValidEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!data.phone?.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!this.isValidPhone(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
      errors.postalCode = 'Postal code can only contain letters, numbers, spaces, and hyphens';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidPhone(phone: string): boolean {
    // Allow international formats with +, digits, spaces, parentheses, and dashes
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Load existing database or create new one
      let dbData: Uint8Array | null = null;
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        dbData = new Uint8Array(dbFile);
      }

      this.db = new SQL.Database(dbData);

      // Create schema if not exists
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      this.db.run(schema);
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private handleFormGet(req: Request, res: Response): void {
    res.render('form', {
      errors: [],
      values: {}
    });
  }

  private handleSubmit = async (req: Request, res: Response): Promise<void> => {
    const formData: FormData = {
      firstName: req.body.firstName?.trim(),
      lastName: req.body.lastName?.trim(),
      streetAddress: req.body.streetAddress?.trim(),
      city: req.body.city?.trim(),
      stateProvince: req.body.stateProvince?.trim(),
      postalCode: req.body.postalCode?.trim(),
      country: req.body.country?.trim(),
      email: req.body.email?.trim(),
      phone: req.body.phone?.trim()
    };

    const validation = this.validateForm(formData);
    
    if (!validation.isValid) {
      const errorMessages = Object.values(validation.errors);
      res.render('form', {
        errors: errorMessages,
        values: formData
      });
      return;
    }

    try {
      if (!this.db) {
        throw new Error('Database not initialized');
      }

      // Insert into database
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName || '',
        formData.lastName || '',
        formData.streetAddress || '',
        formData.city || '',
        formData.stateProvince || '',
        formData.postalCode || '',
        formData.country || '',
        formData.email || '',
        formData.phone || ''
      ]);

      stmt.free();
      
      // Save database to disk
      this.saveDatabase();

      // Redirect to thank you page
      res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
    } catch (error) {
      console.error('Failed to save submission:', error);
      const errors = ['Failed to save your submission. Please try again.'];
      res.render('form', {
        errors,
        values: formData
      });
    }
  };

  private handleThankYou(req: Request, res: Response): void {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  }

  private async shutdown(): Promise<void> {
    console.log('Shutting down gracefully...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('Express server closed');
      });
    }

    if (this.db) {
      this.db.close();
      console.log('Database connection closed');
    }
  }

  public async start(): Promise<void> {
    try {
      // Initialize database
      await this.initializeDatabase();
      console.log('Database initialized successfully');

      // Start server
      const port = process.env.PORT || 3535;
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });

      // Setup graceful shutdown
      process.on('SIGTERM', this.shutdown.bind(this));
      process.on('SIGINT', this.shutdown.bind(this));

    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }
}

// Start the application
const app = new FormCaptureApp();
app.start().catch(console.error);
