/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim() === '') {
    return text;
  }

  // Replace multiple spaces with a single space, but keep paragraph breaks
  let processed = text.replace(/[\s]+/g, ' ');
  
  // Make sure there's exactly one space after sentence punctuation
  processed = processed.replace(/([.!?])(\S)/g, '$1 $2');
  
  // Split into sentences based on punctuation marks
  // Use positive lookahead to keep the punctuation
  const sentences = processed.split(/(?<=[.!?])/);
  
  // Capitalize each sentence
  const capitalizedSentences = sentences.map((sentence, index) => {
    const trimmed = sentence.trim();
    
    if (!trimmed) return sentence; // Return empty parts as-is
    
    // First character should be capitalized, rest remain the same
    const firstChar = trimmed.charAt(0).toUpperCase();
    const rest = trimmed.substring(1);
    
    // Re-add original leading whitespace if any
    const leadingWhitespace = sentence.match(/^\s*/)?.[0] || '';
    
    // Special case for common abbreviations at start
    const commonAbbreviations = ['e.g.', 'i.e.', 'etc.', 'mr.', 'mrs.', 'dr.', 'prof.', 'sr.', 'jr.', 'st.', 'ave.', 'blvd.'];
    if (index > 0 && commonAbbreviations.some(abbr => trimmed.toLowerCase().startsWith(abbr))) {
      // Don't capitalize if it starts with a common abbreviation
      return sentence;
    }
    
    return leadingWhitespace + firstChar + rest;
  });
  
  // Join sentences back together
  return capitalizedSentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with or without protocol
  // This regex captures http/https, ftp, www, and domain-only URLs
  const urlRegex = /(https?:\/\/|ftp:\/\/|www\.|https?:\/\/www\.)[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:[\/?].*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from matches
  return matches.map(url => {
    // Remove trailing punctuation that's likely not part of the URL
    return url.replace(/[.,;:!?()'"[\]{}]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://, but leave https:// untouched
  // Using negative lookahead to avoid double replacement
  return text.replace(/https?:/g, (match) => {
    return match === 'http:' ? 'https:' : match;
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs and capture path
  const urlRegex = /(https?):\/\/([^/]+)(.*)?/g;
  
  return text.replace(urlRegex, (match, protocol, host, path = '') => {
    // First, always upgrade to https
    const secureProtocol = 'https';
    
    // Check for conditions that should skip host rewrite
    const hasDynamicHints = /(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite to docs.example.com
      const newHost = host.startsWith('www.') ? 
        `docs.${host.substring(4)}` : 
        `docs.${host}`;
      return `${secureProtocol}://${newHost}${path}`;
    }
    
    // Default case: just upgrade the protocol
    return `${secureProtocol}://${host}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string | 'N/A' {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Additional validation for month/day combinations
  // February check (simplified - not accounting for leap years)
  if (month === 2 && day > 28) {
    return 'N/A';
  }
  
  // April, June, September, November have 30 days
  if ([4, 6, 9, 11].includes(month) && day > 30) {
    return 'N/A';
  }
  
  // The rest have 31 days
  if ([1, 3, 5, 7, 8, 10, 12].includes(month) && day > 31) {
    return 'N/A';
  }
  
  return yearStr;
}