export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject if it doesn't match basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks for specific invalid patterns
  // Check for consecutive dots
  if (value.includes('..')) {
    return false;
  }

  // Check for trailing dot in local part or domain
  if (value.endsWith('.') || value.includes('.@') || value.includes('@.')) {
    return false;
  }

  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }

  // Check for valid TLD (last part should be at least 2 characters)
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) {
    return false;
  }

  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the optional leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with optional +1
  if (cleaned.startsWith('+1')) {
    // After +1, we should have exactly 10 digits
    if (cleaned.length !== 13) { // +1 + 10 digits
      return false;
    }
  } else {
    // Should be exactly 10 digits without country code
    if (cleaned.length !== 10) {
      return false;
    }
  }
  
  // Extract the 10-digit number part
  const numberPart = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;
  
  // Area code cannot start with 0 or 1
  if (numberPart[0] === '0' || numberPart[0] === '1') {
    return false;
  }
  
  // Validate the format with a comprehensive regex
  // This regex supports (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and parentheses for validation
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Build regex for Argentine phone numbers
  // +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
  const argentinePhoneRegex = /^(\+54)?(9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, , areaCode, subscriberNumber] = match;
  
  // When country code is omitted, number must begin with trunk prefix 0
  if (!countryCode && !areaCode.startsWith('0')) {
    return false;
  }
  
  // Area code validation
  const actualAreaCode = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (actualAreaCode.length < 2 || actualAreaCode.length > 4) {
    return false;
  }
  
  // Area code must not start with 0
  if (actualAreaCode[0] === '0') {
    return false;
  }
  
  // Subscriber number validation (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\s'-]+$/;
  
  // Must match allowed characters
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (can't be just spaces, apostrophes, or hyphens)
  if (!/[a-zA-Z\u00C0-\u017F]/.test(value)) {
    return false;
  }
  
  // Prevent excessive characters like X Æ A-12
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for repeated special characters (like "--" or "''")
  if (/['-]{2,}/.test(value)) {
    return false;
  }
  
  // Name shouldn't start or end with apostrophe or hyphen
  if (value.startsWith('\'') || value.startsWith('-') || value.endsWith('\'') || value.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Helper function for Luhn algorithm
  const runLuhnCheck = (cardNumber: string): boolean => {
    let sum = 0;
    let isEven = false;
    
    // Process each digit from right to left
    for (let i = cardNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cardNumber[i], 10);
      
      if (isEven) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9;
        }
      }
      
      sum += digit;
      isEven = !isEven;
    }
    
    return sum % 10 === 0;
  };
  
  // Remove all non-digit characters
  const cleanCard = value.replace(/\D/g, '');
  
  // Basic length check for major cards
  if (cleanCard.length < 13 || cleanCard.length > 19) {
    return false;
  }
  
  // Check if it passes basic format validation
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercardRegex = /^(5[1-5][0-9]{14}|2[2-7][0-9]{14})$/;
  const amexRegex = /^3[47][0-9]{13}$/;
  
  // Check if it matches any supported card type
  let isValidFormat = false;
  if (visaRegex.test(cleanCard)) {
    isValidFormat = true;
  } else if (mastercardRegex.test(cleanCard)) {
    isValidFormat = true;
  } else if (amexRegex.test(cleanCard)) {
    isValidFormat = true;
  }
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanCard);
}