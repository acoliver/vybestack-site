/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary pattern with the prefix
  // Using word boundaries (\b) to match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]]/g, '\\$&');
  const prefixedWordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  // Find all words with the prefix
  const matches = text.match(prefixedWordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
  
  // Remove duplicates while preserving order
  const uniqueResults: string[] = [];
  const seen = new Set<string>();
  
  result.forEach(word => {
    const lowerWord = word.toLowerCase();
    if (!seen.has(lowerWord)) {
      seen.add(lowerWord);
      uniqueResults.push(word);
    }
  });
  
  return uniqueResults;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // To match token only when it appears after a digit and not at the beginning of the string
  // We need to use a different approach since lookbehind with capturing is complex
  
  // First, find all potential matches using regex that looks for digit+token
  const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '\\$&');
  const embeddedTokenRegex = new RegExp(`\\d+${escapedToken}`, 'g');
  
  // Find all matches
  const matches = [...text.matchAll(embeddedTokenRegex)];
  
  // Return the full matches (digit+token)
  return matches.map(match => match[0]);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"|,.<>\/?]/.test(value);

  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., "abab")
  for (let i = 0; i < value.length - 2; i++) {
    // Check for repeating 2-character patterns (like "abab", "1212")
    const twoCharPattern = value.substring(i, i + 2);
    if (i + 3 < value.length && value.substring(i + 2, i + 4) === twoCharPattern) {
      return false;
    }
    
    // Check for repeating 3-character patterns (like "abcabc")
    if (i + 5 < value.length) {
      const threeCharPattern = value.substring(i, i + 3);
      if (value.substring(i + 3, i + 6) === threeCharPattern) {
        return false;
      }
    }
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, filter out IPv4 addresses to avoid false positives
  // IPv4 pattern: xxx.xxx.xxx.xxx where xxx is 0-255
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern - this matches both full and shorthand versions
  // Basic structure: 8 groups of 1-4 hex digits separated by colons
  // With possible shorthand: :: (can only appear once)
  const ipv6Pattern = /\b((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::ffff:(?::[0-9]{1,3}\.){3}[0-9]{1,3})\b/;
  
  return ipv6Pattern.test(value);
}