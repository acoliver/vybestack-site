const { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } = require('./dist/validators.js');
const { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } = require('./dist/transformations.js');
const { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } = require('./dist/puzzles.js');

console.log('Testing regex implementations...');

// Test isValidEmail
console.log('\n--- isValidEmail ---');
console.log('user@example.com:', isValidEmail('user@example.com'));
console.log('name+tag@example.co.uk:', isValidEmail('name+tag@example.co.uk'));
console.log('user@@example..com (should be false):', isValidEmail('user@@example..com'));
console.log('user@domain_.com (should be false):', isValidEmail('user@domain_.com'));

// Test isValidUSPhone
console.log('\n--- isValidUSPhone ---');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('2125557890:', isValidUSPhone('2125557890'));
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('012-555-7890 (should be false):', isValidUSPhone('012-555-7890'));

// Test isValidArgentinePhone
console.log('\n--- isValidArgentinePhone ---');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567'));

// Test isValidName
console.log('\n--- isValidName ---');
console.log('Jane Doe:', isValidName('Jane Doe'));
console.log('José María:', isValidName('José María'));
console.log('O\'Connor:', isValidName('O\'Connor'));
console.log('X Æ A-12 (should be false):', isValidName('X Æ A-12'));

// Test isValidCreditCard
console.log('\n--- isValidCreditCard ---');
console.log('4111111111111111 (Visa):', isValidCreditCard('4111111111111111'));
console.log('5500000000000004 (MasterCard):', isValidCreditCard('5500000000000004'));
console.log('378282246310005 (Amex):', isValidCreditCard('378282246310005'));
console.log('1234567890123456 (invalid):', isValidCreditCard('1234567890123456'));

// Test transformations
console.log('\n--- capitalizeSentences ---');
console.log(capitalizeSentences('hello world. how are you? i am fine! great.'));

console.log('\n--- extractUrls ---');
const textWithUrls = 'Visit https://example.com and http://test.org. Also check www.google.com.';
console.log('URLs found:', extractUrls(textWithUrls));

console.log('\n--- enforceHttps ---');
console.log(enforceHttps('Visit http://example.com and https://secure.org.'));

console.log('\n--- rewriteDocsUrls ---');
console.log(rewriteDocsUrls('Visit http://example.com/docs/api and http://example.com/cgi-bin/script.cgi'));

console.log('\n--- extractYear ---');
console.log('12/25/2023 ->', extractYear('12/25/2023'));
console.log('13/01/2022 ->', extractYear('13/01/2022'));

// Test puzzles
console.log('\n--- findPrefixedWords ---');
const text = 'The preposition, prefix, and preschool are different. Pre is not a word.';
console.log(findPrefixedWords(text, 'pre', ['preposition']));

console.log('\n--- findEmbeddedToken ---');
console.log(findEmbeddedToken('123token test 456token token', 'token'));

console.log('\n--- isStrongPassword ---');
console.log('Password123! (valid):', isStrongPassword('Password123!'));
console.log('abABcdcd! (invalid - repeated):', isStrongPassword('abABcdcd!'));
console.log('weak (invalid):', isStrongPassword('weak'));

console.log('\n--- containsIPv6 ---');
console.log('2001:0db8:85a3:0000:0000:8a2e:0370:7334:', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log('::1:', containsIPv6('::1'));
console.log('192.168.1.1:', containsIPv6('192.168.1.1'));

console.log('\nDone!');