import express, { Request, Response } from 'express';
import path from 'path';
import * as initDB from './db';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
let db: import('./db').SqlJsDatabase;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Validation functions
function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalZipCode', 'country', 'email', 'phoneNumber'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phoneNumber && !/^\+?[0-9\s\-()]+$/.test(data.phoneNumber)) {
    errors.phoneNumber = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalZipCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalZipCode)) {
    errors.postalZipCode = 'Please enter a valid postal code';
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', { 
    errors: {}, 
    formData: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName?.trim() || '',
      lastName: req.body.lastName?.trim() || '',
      streetAddress: req.body.streetAddress?.trim() || '',
      city: req.body.city?.trim() || '',
      stateProvinceRegion: req.body.stateProvinceRegion?.trim() || '',
      postalZipCode: req.body.postalZipCode?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phoneNumber: req.body.phoneNumber?.trim() || ''
    };

    const errors = validateFormData(formData);

    if (Object.keys(errors).length > 0) {
      return res.status(400).render('index', {
        errors,
        formData,
        title: 'Contact Form - Please Fix Errors'
      });
    }

    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvinceRegion,
      formData.postalZipCode,
      formData.country,
      formData.email,
      formData.phoneNumber
    ]);

    stmt.free();
    await initDB.saveDatabase(db);

    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).send('Something went wrong!');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

// Error handler
app.use((err: Error, req: Request, res: Response) => {
  console.error(err);
  res.status(500).send('Something went wrong!');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  if (db) {
    await initDB.closeDatabase(db);
  }
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  if (db) {
    await initDB.closeDatabase(db);
  }
  process.exit(0);
});

// Initialize and start server
async function startServer() {
  try {
    db = await initDB.initializeDatabase();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();