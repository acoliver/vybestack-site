import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

export interface SqlJsDatabase {
  exec(sql: string): void;
  prepare(sql: string): SqlJsStatement;
  export(): Uint8Array;
  close(): void;
}

export interface SqlJsStatement {
  run(params: unknown[]): void;
  free(): void;
}

interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => SqlJsDatabase;
}

let SQL: SqlJsModule | null = null;

export async function initializeDatabase(): Promise<SqlJsDatabase> {
  if (!SQL) {
    const initResult = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });
    SQL = initResult as unknown as SqlJsModule;
  }

  let db: SqlJsDatabase;

  if (fs.existsSync(DB_PATH)) {
    const filebuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(filebuffer);
  } else {
    db = new SQL.Database();
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Create table from schema
    const schema = fs.readFileSync(path.join(process.cwd(), 'db', 'schema.sql'), 'utf8');
    db.exec(schema);
  }

  return db;
}

export async function saveDatabase(db: SqlJsDatabase): Promise<void> {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export async function closeDatabase(db: SqlJsDatabase): Promise<void> {
  db.close();
}