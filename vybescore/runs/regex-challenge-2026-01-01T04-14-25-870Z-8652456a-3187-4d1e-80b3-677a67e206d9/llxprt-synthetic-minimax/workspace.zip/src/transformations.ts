/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs with common protocols and domains
  // Allow dots and common URL characters to capture complete domains including TLDs
  const urlPattern = /\b((?:https?|ftp):\/\/[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9])/gi;
  
  const urls: string[] = [];
  const matches = text.match(urlPattern);
  
  if (matches) {
    for (const match of matches) {
      // Clean up trailing punctuation from captured URLs
      let cleanUrl = match.replace(/[.,;!?]+$/g, '');
      
      // Additional cleaning for common punctuation patterns
      cleanUrl = cleanUrl.replace(/["']$/g, '');
      cleanUrl = cleanUrl.replace(/\.$/g, '');
      
      if (cleanUrl.length > 0) {
        urls.push(cleanUrl);
      }
    }
  }
  
  return urls;
}

/**
 * TODO: Capitalize the first character of each sentence.
 */
export function capitalizeSentences(text: string): string {
  // Step 1: Capitalize the first character of the entire text
  let result = text.length > 0 ? text[0].toUpperCase() + text.slice(1) : text;
  
  // Step 2: Capitalize letters that follow sentence endings
  result = result.replace(/([.!?]+)(\s*)([a-z])/g, (match, punct, spaces, letter) => {
    return punct + spaces + letter.toUpperCase();
  });
  
  // Step 3: Clean up extra spaces while preserving sentence structure
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Replace http:// schemes with https:// while leaving secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Pattern to match http:// (case insensitive) but not https://
  const httpPattern = /\bhttp:\/\//gi;
  
  return text.replace(httpPattern, 'https://');
}

/**
 * TODO: For URLs http://example.com/...
 * Always upgrade the scheme to https://.
 * When the path begins with /docs/, rewrite the host to docs.example.com.
 * Skip the host rewrite when the path contains dynamic hints.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const docsUrlPattern = /\b(http):\/\/([^/]+)(\/[^?\s]*)?/gi;
  
  return text.replace(docsUrlPattern, (match, scheme, host, path) => {
    const upgradedScheme = 'https';
    const upgradedPath = path || '';
    
    // Check if this is a docs URL that needs host rewriting
    if (upgradedPath.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
      const hasDynamicHints = dynamicHints.some(hint => upgradedPath.includes(hint));
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        const newHost = host.replace(/^example\.com$/, 'docs.example.com');
        return `${upgradedScheme}://${newHost}${upgradedPath}`;
      }
    }
    
    // Default upgrade just the scheme
    return `${upgradedScheme}://${host}${upgradedPath}`;
  });
}

/**
 * TODO: Return the four-digit year for mm/dd/yyyy.
 * If the string doesn't match that format or month/day are invalid, return N/A.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /\b(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})\b/;
  
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month >= 1 && month <= 12 && day >= 1 && day <= 31) {
    return year;
  }
  
  return 'N/A';
}
