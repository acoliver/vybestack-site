/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowercaseMatch
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token occurrences after digits but not at string start
  // Use positive lookbehind to ensure token is preceded by a digit
  const embeddedPattern = new RegExp(`(?<=\\d)${token}`, 'g');
  
  const matches = text.match(embeddedPattern) || [];
  
  // Additional validation to ensure occurrences are not at string start
  // We'll filter matches by checking the original text context
  const validMatches: string[] = [];
  
  for (const match of matches) {
    // Find all positions where this token occurs
    let pos = 0;
    while (pos >= 0 && pos < text.length) {
      pos = text.indexOf(match, pos);
      if (pos === -1) break;
      
      // Check if this occurrence has a digit before it and is not at the start
      if (pos > 0 && /\d/.test(text[pos - 1])) {
        // Return the full context including the digit
        validMatches.push(text[pos - 1] + match);
      }
      
      pos += 1;
    }
  }
  
  return validMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length requirement (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // Pattern to detect repeating sequences like "abab", "1212", "xyxy"
  const repeatedSequencePattern = /(..+)\1/g;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  // Check for all required character types
  const requirements = {
    uppercase: /[A-Z]/,
    lowercase: /[a-z]/,
    digit: /\d/,
    symbol: /[!@#$%^&*()_+-=[\]{};':"|,.<>/]/
  };
  
  // Check each requirement
  for (const pattern of Object.values(requirements)) {
    if (!pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, quickly reject obvious IPv4 patterns to avoid false positives
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false; // This is IPv4, not IPv6
  }
  
  // IPv6 address patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIpv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/;
  
  // IPv6 with shorthand :: (one or more groups of zeros)
  const shorthandIpv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:)*(?:[a-fA-F0-9]{1,4})?::(?:[a-fA-F0-9]{1,4}:)*[a-fA-F0-9]{1,4}\b/;
  
  // IPv6 with :: anywhere (compressed notation)
  const compressedIpv6Pattern = /\b[a-fA-F0-9]{0,4}:(?:[a-fA-F0-9]{0,4}:)*[a-fA-F0-9]{0,4}\b/;
  
  // IPv6 in URL format with brackets [ipv6:address]
  const urlIpv6Pattern = /\b\[?[a-fA-F0-9:]+\]\]?\b/;
  
  // Combined patterns - prioritize specific matches over general patterns
  const patterns = [
    fullIpv6Pattern,
    shorthandIpv6Pattern,
    compressedIpv6Pattern,
    urlIpv6Pattern
  ];
  
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      // Additional validation to ensure this is actually IPv6 and not accidentally IPv4
      // Remove any found patterns and check if what remains looks like IPv6 components
      const matches = value.match(pattern);
      if (matches) {
        for (const match of matches) {
          // Ensure the match contains colon patterns typical of IPv6
          if (match.includes(':')) {
            // Additional check: IPv6 should have hex digits and colons, not just dots
            if (!match.includes('.') && /[a-fA-F0-9]/.test(match)) {
              return true;
            }
          }
        }
      }
    }
  }
  
  return false;
}
