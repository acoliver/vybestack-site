export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for typical email validation
  // Reject: double dots, trailing dots, domains with underscores
  const emailPattern = /^[a-zA-Z0-9][a-zA-Z0-9._+]*[a-zA-Z0-9]*@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  
  // Additional validation to reject obviously invalid forms
  if (value.includes('..') || value.endsWith('.') || value.includes('@example_')) {
    return false;
  }
  
  return emailPattern.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // Check for valid US phone patterns
  const patterns = [
    // +1 followed by 10 digits
    /^\+1[2-9]\d{2}[2-9]\d{2}\d{4}$/,
    // 10 digits starting with area code 2-9
    /^[2-9]\d{2}[2-9]\d{2}\d{4}$/
  ];

  // Validate area code (cannot start with 0 or 1)
  if (patterns[1].test(digitsOnly) || patterns[0].test(digitsOnly)) {
    return true;
  }

  // Check for various formats with optional +1
  const formatPattern = /^\+?1?[\s()\-]*[2-9]\d{2}[\s()\-]*[2-9]\d{2}[\s\-]*\d{4}$/;
  if (!formatPattern.test(value)) {
    return false;
  }

  // Final validation - ensure exactly 10 digits when +1 prefix is used
  if (value.startsWith('+1')) {
    return /^\+?1?[\s()\-]*[2-9]\d{2}[\s()\-]*[2-9]\d{2}[\s\-]*\d{4}$/.test(value);
  }

  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and parentheses for validation
  const digitsOnly = value.replace(/[\s\-()]/g, '');

  // Pattern for Argentine phone validation
  // Optional +54, area code 2-4 digits (1-9), subscriber 6-8 digits
  // The 9 mobile indicator is truly optional
  const arPattern = /^\+?54[1-9]\d{1,3}\d{6,8}$/;

  if (!arPattern.test(digitsOnly)) {
    return false;
  }

  // Additional validation for trunk prefix requirement when country code is omitted
  if (!value.startsWith('+54')) {
    // When country code is omitted, must begin with trunk prefix 0
    const trunkPattern = /^0[1-9]\d{1,3}\d{6,8}$/;
    if (!trunkPattern.test(digitsOnly)) {
      return false;
    }
  }

  // Validate specific formats with separators
  // Allow for spaces/hyphens within subscriber numbers too
  const formatPattern = /^\+?54[\s\-]*[1-9]\d{1,3}[\s\-]*(?:\d[\s\-]*){6,8}$/;
  return formatPattern.test(value);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern for name validation: unicode letters, spaces, apostrophes, hyphens
  // Reject digits, symbols, and fancy names like "X Æ A-12"
  const namePattern = /^[\p{L}\p{M}\s'\-]+$/u;

  if (!namePattern.test(value)) {
    return false;
  }

  // Additional validation to reject obviously invalid names
  // Check for problematic patterns
  const invalidPatterns = [
    /\d/,  // Contains digits
    /[^\p{L}\p{M}\s'\-]/u,  // Contains non-name characters
    /X\s*Æ\s*A\-12/i,  // Specific pattern mentioned
  ];

  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }

  // Ensure name is not empty and has reasonable length
  return value.trim().length >= 2 && value.trim().length <= 50;
}

/**
 * Helper function to run Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  if (cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }

  // Check for valid card prefixes and lengths
  const cardPatterns = [
    // Visa: starts with 4, length 13, 16, or 19
    /^4\d{12}(\d{3})?(\d{3})?$/,
    // Mastercard: starts with 51-55, length 16
    /^5[1-5]\d{14}$/,
    // AmEx: starts with 34 or 37, length 15
    /^(34|37)\d{13}$/
  ];

  let isValidCard = false;
  for (const pattern of cardPatterns) {
    if (pattern.test(cardNumber)) {
      isValidCard = true;
      break;
    }
  }

  if (!isValidCard) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}
