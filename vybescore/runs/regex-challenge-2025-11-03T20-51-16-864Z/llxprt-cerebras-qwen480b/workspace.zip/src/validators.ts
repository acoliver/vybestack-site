export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern matching.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Check basic email pattern
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns:
  // - Double dots (..) in local part or domain
  // - Trailing dots in local part
  // - Underscores in domain part
  const invalidPatterns = [
    /\.\./, // Double dots anywhere
    /\.$/, // Trailing dot in local part
    /@.*_.*\./ // Underscore in domain
  ];
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix, disallows impossible area codes
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if too short
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Extract area code if 11 digits with +1 prefix
  let areaCode: string;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    areaCode = digitsOnly.substring(1, 4);
  } else if (digitsOnly.length === 10) {
    areaCode = digitsOnly.substring(0, 3);
  } else {
    return false; // Invalid length
  }
  
  // Check for impossible area codes (0 or 1 as first digit)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate the format using regex
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s\-]?\d{3}[\s\-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both mobile and landline formats
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex patterns for different valid formats
  const patterns = [
    /^\+549\d{2}\d{6,8}$/, // +54 9 area subscriber
    /^\+54\d{2,4}\d{6,8}$/, // +54 area subscriber
    /^0\d{2,4}\d{6,8}$/ // 0 area subscriber
  ];
  
  // Check if any pattern matches
  const matchesPattern = patterns.some(pattern => pattern.test(cleanValue));
  if (!matchesPattern) {
    return false;
  }
  
  // Extract area code and subscriber number
  let areaCode = '';
  let subscriberNumber = '';
  
  if (cleanValue.startsWith('+549')) {
    // Mobile with +54 9
    areaCode = cleanValue.substring(4, 6); // Extract first 2 digits after +549
    subscriberNumber = cleanValue.substring(6);
  } else if (cleanValue.startsWith('+54')) {
    // With +54 country code
    const remaining = cleanValue.substring(3);
    // Area code is 2-4 digits, subscriber is 6-8
    areaCode = remaining.substring(0, Math.min(4, remaining.length - 6));
    subscriberNumber = remaining.substring(areaCode.length);
  } else if (cleanValue.startsWith('0')) {
    // With trunk prefix 0
    const remaining = cleanValue.substring(1);
    areaCode = remaining.substring(0, Math.min(4, remaining.length - 6));
    subscriberNumber = remaining.substring(areaCode.length);
  } else {
    return false;
  }
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode.charAt(0) === '0') {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8 || !/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value.trim()) {
    return false;
  }
  
  // Check for X Æ A-12 pattern (names with numbers)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check if only valid characters (unicode letters, space, hyphen, apostrophe)
  const validNamePattern = /^[\p{L}\s\-']+$/u;
  return validNamePattern.test(value);
}

/**
 * Helper function to run Luhn algorithm check
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Remove spaces and iterate from right to left
  const cleanValue = value.replace(/\s/g, '');
  for (let i = cleanValue.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanValue.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers including length, prefix and Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces for validation
  const cleanValue = value.replace(/\s/g, '');
  
  // Visa pattern: 4 followed by 12 or 15 more digits
  const visaPattern = /^4\d{12}(\d{3})?$/;
  
  // Mastercard pattern: 5[1-5] followed by 14 digits or 2[2-7] followed by 14 digits
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // Amex pattern: 34 or 37 followed by 13 digits
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check length, prefix and Luhn algorithm
  if (!(visaPattern.test(cleanValue) || mastercardPattern.test(cleanValue) || amexPattern.test(cleanValue))) {
    return false;
  }
  
  return runLuhnCheck(value);
}