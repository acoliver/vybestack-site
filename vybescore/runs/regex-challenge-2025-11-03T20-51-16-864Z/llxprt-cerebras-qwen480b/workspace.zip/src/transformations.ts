/**
 * Capitalizes the first character of each sentence after punctuation .?!
 * Normalizes space between sentences to one space
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with single space
  let result = text.replace(/\s+/g, ' ');
  
  // Add space after sentence-ending punctuation if missing
  result = result.replace(/([.?!])([a-z])/g, '$1 $2');
  
  // Capitalize first letter of each sentence
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
  
  return result.trim();
}

/**
 * Extracts URLs from text, removing trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Match URLs with various protocols and formats
  const urlPattern = /\b(?:https?|ftp):\/\/[^\s/$.?#].[^\s]*\b/gi;
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.?!,:]$/, ''));
}

/**
 * Replaces http:// with https:// in URLs
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs with /docs/ path to use docs subdomain
 * Upgrades all http:// URLs to https://
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/\bhttp:\/\/([\w.-]+)(\/[^\s]*)/gi, (match, domain, path) => {
    // Upgrade scheme to https
    let newUrl = `https://${domain}${path}`;
    
    // Check if path starts with /docs/ and doesn't contain dynamic elements
    const dynamicIndicators = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
    const hasDynamicIndicator = dynamicIndicators.some(indicator => path.includes(indicator));
    
    if (path.startsWith('/docs/') && !hasDynamicIndicator) {
      // Rewrite to docs subdomain
      newUrl = `https://docs.${domain}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted dates
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}