/**
 * Finds words starting with a given prefix, excluding exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to match words beginning with prefix
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of a string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use positive lookbehind to ensure token follows a digit
  // Use negative lookbehind for beginning of string to ensure it's not at start
  const regex = new RegExp(`(?<=\\d)(${token})\\b`, 'g');
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * Validates passwords based on security criteria
 */
export function isStrongPassword(value: string): boolean {
  // Check basic requirements
  if (value.length < 10) {
    return false;
  }
  
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediately repeated sequences (like abab)
  // Pattern: any sequence of 2+ characters that repeats immediately
  if (/(.+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses while excluding IPv4 addresses
 */
export function containsIPv6(value: string): boolean {
  // Regex pattern for IPv6 addresses (simplified but sufficient for this challenge)
  // Matches full IPv6 addresses, compressed (::) forms, and mixed formats
  const ipv6Pattern = /(?:::[\dA-Fa-f]{1,4}|[\dA-Fa-f]{1,4}::|[\dA-Fa-f]{1,4}:[\dA-Fa-f]{1,4}|(?::[\dA-Fa-f]{1,4}){2,7}|(?:[\dA-Fa-f]{1,4}:){1,6}:[\dA-Fa-f]{1,4}|(?:[\dA-Fa-f]{1,4}:){1,5}(?::[\dA-Fa-f]{1,4}){1,2}|(?:[\dA-Fa-f]{1,4}:){1,4}(?::[\dA-Fa-f]{1,4}){1,3}|(?:[\dA-Fa-f]{1,4}:){1,3}(?::[\dA-Fa-f]{1,4}){1,4}|(?:[\dA-Fa-f]{1,4}:){1,2}(?::[\dA-Fa-f]{1,4}){1,5}|[\dA-Fa-f]{1,4}:(?::[\dA-Fa-f]{1,4}){1,6}|:(?::[\dA-Fa-f]{1,4}){1,7}|::)/;
  
  // Ensure it's not IPv4 (which would have dots)
  if (value.includes('.')) {
    return false;
  }
  
  return ipv6Pattern.test(value);
}