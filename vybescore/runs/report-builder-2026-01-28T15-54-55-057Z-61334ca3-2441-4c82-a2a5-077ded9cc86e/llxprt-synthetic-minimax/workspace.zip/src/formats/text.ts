// Text format renderer
import { Formatter, ReportData, FormatterOptions } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderText: Formatter = (
  data: ReportData,
  options: FormatterOptions
): string => {
  const { entries } = data;
  const { includeTotals } = options;

  let output = `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;

  for (const entry of entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }

  if (includeTotals) {
    const total = calculateTotal(entries);
    output += `Total: ${formatAmount(total)}\n`;
  }

  return output;
};