#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { Formatter, ReportData, CLIOptions, FormatterOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): CLIOptions {
  if (argv.length < 3) {
    throw new Error('Usage: report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const [, , dataFile, ...rest] = argv;
  
  let format = '';
  let output: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 0; i < rest.length; i++) {
    const arg = rest[i];
    
    if (arg === '--format' && i + 1 < rest.length) {
      format = rest[i + 1];
      i++;
    } else if (arg === '--output' && i + 1 < rest.length) {
      output = rest[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return {
    dataFile,
    format: format as 'markdown' | 'text',
    output,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as ReportData;

  if (typeof reportData.title !== 'string' || !reportData.title.trim()) {
    throw new Error('Invalid JSON: "title" must be a non-empty string');
  }

  if (typeof reportData.summary !== 'string' || !reportData.summary.trim()) {
    throw new Error('Invalid JSON: "summary" must be a non-empty string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  if (reportData.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" must not be empty');
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];
    
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    if (typeof entry.label !== 'string' || !entry.label.trim()) {
      throw new Error(`Invalid JSON: entry at index ${i} must have a non-empty "label"`);
    }

    if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
      throw new Error(`Invalid JSON: entry at index ${i} must have a valid "amount" number`);
    }
  }

  return reportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid JSON:')) {
        throw error;
      }
      throw new Error(`Failed to read JSON file: ${error.message}`);
    }
    throw new Error('Failed to parse JSON file');
  }
}

function renderReport(
  data: ReportData,
  format: 'markdown' | 'text',
  options: FormatterOptions
): string {
  const formatters: Record<string, Formatter> = {
    markdown: renderMarkdown,
    text: renderText
  };

  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return formatter(data, options);
}

function writeOutput(output: string, filePath?: string): void {
  if (filePath) {
    writeFileSync(filePath, output);
  } else {
    process.stdout.write(output);
  }
}

// Main execution
try {
  const options = parseArguments(process.argv);
  const data = loadReportData(options.dataFile);
  const formatterOptions: FormatterOptions = {
    includeTotals: options.includeTotals
  };

  const output = renderReport(data, options.format, formatterOptions);
  writeOutput(output, options.output);
} catch (error) {
  const message = error instanceof Error ? error.message : String(error);
  console.error(message);
  process.exit(1);
}
