/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Import the dependency registration helper from computed.ts
import { registerDependency as registerComputedDependency } from './computed.js'

// We need a way to track dependents for inputs too
const dependentsMap = new WeakMap<object, Set<Observer<unknown>>>()

// Override registerDependency to also handle inputs
function registerInputDependency(source: object): void {
  const activeObserver = getActiveObserver()
  if (activeObserver && activeObserver !== source) {
    const deps = dependentsMap.get(source) || new Set()
    deps.add(activeObserver as Observer<unknown>)
    dependentsMap.set(source, deps)
  }
}

/**
 * Helper to update all dependents of a subject
 */
function updateDependents(source: object): void {
  const dependents = dependentsMap.get(source)
  if (dependents && dependents.size > 0) {
    // Use a copy to avoid issues if the set is modified during iteration
    const dependentsCopy = new Set(dependents)
    for (const dependent of dependentsCopy) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Normalize equal parameter
  const equalFn: EqualFn<T> | undefined = 
    equal === true 
      ? (a, b) => a === b 
      : typeof equal === 'function' 
        ? equal 
        : undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    // Register this subject as a dependency of the active observer
    registerInputDependency(s)
    registerComputedDependency(s)  // Also register with computed's helper
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed (if equalFn is provided)
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Trigger update in all dependent observers
    updateDependents(s)
    
    return s.value
  }

  return [read, write]
}
