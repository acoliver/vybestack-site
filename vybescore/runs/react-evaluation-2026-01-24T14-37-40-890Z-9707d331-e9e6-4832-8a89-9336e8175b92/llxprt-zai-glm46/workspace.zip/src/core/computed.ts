/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  markPendingDependents,
  getActiveObserver
} from '../types/reactive.js'

// Use a WeakMap to track which observers depend on which other observers
const dependentsMap = new WeakMap<object, Set<Observer<unknown>>>()

/**
 * Helper to register a dependency
 */
export function registerDependency(source: object): void {
  const activeObserver = getActiveObserver()
  if (activeObserver && activeObserver !== source) {
    const deps = dependentsMap.get(source) || new Set()
    deps.add(activeObserver as Observer<unknown>)
    dependentsMap.set(source, deps)
  }
}

/**
 * Helper to update all dependents of a computed observer
 */
function updateDependents(observer: Observer<unknown>): void {
  const dependents = dependentsMap.get(observer)
  if (dependents && dependents.size > 0) {
    // Use a copy to avoid issues if the set is modified during iteration
    const dependentsCopy = new Set(dependents)
    for (const dependent of dependentsCopy) {
      updateObserver(dependent)
    }
  }
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Compute initial value
  updateObserver(o)

  // Attach the updateDependents function to this observer using a different approach
  Object.defineProperty(o, '_updateDependents', {
    value: () => updateDependents(o as Observer<unknown>),
    writable: false,
    enumerable: false
  })

  const getter = (): T => {
    // Register this computed as a dependency of the active observer
    registerDependency(o)
    return o.value!
  }

  // Wrap the updateFn to mark that dependents should be updated after this observer's value is set
  const originalUpdateFn = o.updateFn
  o.updateFn = function(this: Observer<T>, prevValue?: T): T {
    // Compute the new value
    const result = originalUpdateFn.call(this, prevValue)
    
    // Mark that this observer has pending dependent updates
    markPendingDependents(o as Observer<unknown>)
    
    return result
  }

  return getter
}
