/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  _isWrapped?: boolean // Marker for wrapped computed observers
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

// Track which observers need to update dependents after their value is set
const pendingDependents = new Set<Observer<unknown>>()

export function markPendingDependents(observer: Observer<unknown>): void {
  pendingDependents.add(observer)
}

export function flushPendingDependents(): void {
  for (const observer of pendingDependents) {
    const updateDependents = (observer as Observer<unknown> & { _updateDependents?: () => void })._updateDependents
    if (updateDependents) {
      updateDependents()
    }
  }
  pendingDependents.clear()
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Check if this observer has pending dependent updates
  if (pendingDependents.has(observer as Observer<unknown>)) {
    pendingDependents.delete(observer as Observer<unknown>)
    const updateDependents = (observer as Observer<unknown> & { _updateDependents?: () => void })._updateDependents
    if (updateDependents) {
      updateDependents()
    }
  }
}
