/**
 * Encode plain text to standard Base64.
 * Uses canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Validates input and rejects invalid Base64 with descriptive error messages.
 */
export function decode(input: string): string {
  // Basic validation for valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains forbidden characters');
  }

  // Validate padding is only at the end
  if (/=+/.test(input.replace(/=+$/, ''))) {
    throw new Error('Invalid Base64 input: padding characters found in the middle');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format or corrupted data');
  }
}
