/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  addObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined || equal === false) return undefined
  if (equal === true) {
    return (a: T, b: T) => a === b
  }
  return equal
}

export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = createEqualFn(equal)
  
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(s, observer)
      
      // Track this subject for cleanup in callbacks
      const trackedSubjects = (observer as { __trackedSubjects?: Set<unknown> }).__trackedSubjects
      const isDisposed = (observer as { __disposed?: () => boolean }).__disposed
      if (trackedSubjects && isDisposed && !isDisposed()) {
        trackedSubjects.add(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (!hasChanged) return s.value
    
    s.value = nextValue
    
    // Notify all observers
    notifyObservers(s)
    
    return s.value
  }

  return [read, write]
}
