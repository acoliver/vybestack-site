/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Store subjects we track for cleanup (avoiding type extensions)
  const trackedSubjects = new Set<unknown>()
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove from all subjects we've been added to
    for (const subject of trackedSubjects) {
      if (subject && typeof subject === 'object' && 'observers' in subject) {
        // Use a type guard to ensure this is a valid subject
        const validSubject = subject as { observers: Set<ObserverR> }
        validSubject.observers.delete(observer)
      }
    }
    
    // Mark as disposed
    observer.value = undefined
    observer.updateFn = () => value as T
  }
  
  // Store tracking in a global map (simpler than type extensions)
  ;(observer as Record<string, unknown>).__trackedSubjects = trackedSubjects
  ;(observer as Record<string, unknown>).__disposed = () => disposed
  
  // Register observer to track dependencies and run initial callback
  updateObserver(observer)
  
  return unsubscribe
}