/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  addObserver,
  notifyObservers,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined || equal === false) return undefined
  if (equal === true) {
    return (a: T, b: T) => a === b
  }
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // Create a subject to store the computed value
  const computedSubject: { name?: string; observers: Set<ObserverR>; value: T | undefined; equalFn?: EqualFn<T> } = {
    name: options?.name,
    observers: new Set(),
    value: value as T | undefined,
    equalFn,
  }
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Compute the new value by running the update function
      const newValue = updateFn(prevValue)
      
      // Check if the value actually changed
      if (equalFn && computedSubject.value !== undefined) {
        if (equalFn(computedSubject.value, newValue)) {
          return computedSubject.value
        }
      }
      
      // Update the stored value
      computedSubject.value = newValue
      o.value = newValue
      
      // Notify observers of this computed value
      notifyObservers(computedSubject)
      
      return newValue
    },
  }
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(computedSubject, observer)
      
      // Track this subject for cleanup in callbacks
      const trackedSubjects = (observer as { __trackedSubjects?: Set<unknown> }).__trackedSubjects
      const isDisposed = (observer as { __disposed?: () => boolean }).__disposed
      if (trackedSubjects && isDisposed && !isDisposed()) {
        trackedSubjects.add(computedSubject)
      }
    }
    // Ensure value is computed
    if (computedSubject.value === undefined) {
      updateObserver(o)
    }
    return computedSubject.value as T
  }
  
  // Initial computation
  updateObserver(o)
  
  return getter
}