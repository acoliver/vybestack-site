#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters } from '../formatters/index.js';

function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  let dataPath = '';
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format' && i + 1 < args.length) {
      format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('-') && dataPath === '') {
      dataPath = arg;
    }
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid JSON: entry at index ${i} missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid JSON: entry at index ${i} missing or invalid "amount" field (expected number)`
      );
    }
  }

  return data as ReportData;
}

function main(): void {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const { dataPath, format, outputPath, includeTotals } = parseArgs(args);

  if (!dataPath) {
    console.error('Error: missing data file path');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: missing --format argument');
    process.exit(1);
  }

  if (!(format in formatters)) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }

  let jsonData: unknown;
  try {
    const content = fs.readFileSync(dataPath, 'utf-8');
    jsonData = JSON.parse(content);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`Error reading or parsing JSON file: ${message}`);
    process.exit(1);
  }

  let data: ReportData;
  try {
    data = validateReportData(jsonData);
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`Error: ${message}`);
    process.exit(1);
  }

  const renderer = formatters[format];
  const options: RenderOptions = { includeTotals };
  const output = renderer(data, options);

  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (err) {
      const message = err instanceof Error ? err.message : String(err);
      console.error(`Error writing to output file: ${message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
