import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

interface PaginationControlsProps {
  currentPage: number;
  hasNext: boolean;
  isLoading: boolean;
  onPageChange: (page: number) => void;
}

function PaginationControls({ currentPage, hasNext, isLoading, onPageChange }: PaginationControlsProps) {
  const hasPrevious = currentPage > 1;

  return (
    <div style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem' }}>
      <button 
        onClick={() => onPageChange(currentPage - 1)} 
        disabled={!hasPrevious || isLoading}
      >
        Previous
      </button>
      <span style={{ display: 'flex', alignItems: 'center' }}>
        Page {currentPage}
      </span>
      <button 
        onClick={() => onPageChange(currentPage + 1)} 
        disabled={!hasNext || isLoading}
      >
        Next
      </button>
    </div>
  );
}

function InventoryList({ items }: { items: InventoryItem[] }) {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePageChange = (newPage: number) => {
    setCurrentPage(newPage);
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <p style={{ marginTop: '0.5rem', fontSize: '0.85rem', color: '#666' }}>
        Showing {data.items.length} of {data.total} items
      </p>
      <PaginationControls 
        currentPage={data.page}
        hasNext={data.hasNext}
        isLoading={status === 'ready'}
        onPageChange={handlePageChange}
      />
    </section>
  );
}
