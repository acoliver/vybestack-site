import { createApp } from './src/server/app.js';
import { createDatabase } from './src/server/db.js';

async function testPagination() {
  const db = await createDatabase();
  const app = await createApp(db);

  console.log('Testing pagination API...\n');

  // Test 1: Default parameters
  console.log('Test 1: Default parameters');
  const response1 = await fetch('http://localhost:3333/inventory');
  const data1 = await response1.json();
  console.log(`Status: ${response1.status}`);
  console.log(`Items count: ${data1.items.length}`);
  console.log(`Total: ${data1.total}`);
  console.log(`HasNext: ${data1.hasNext}`);
  console.log(`Item IDs: ${data1.items.map(item => item.id).join(', ')}\n`);

  // Test 2: Explicit page=1 limit=3
  console.log('Test 2: Explicit page=1 limit=3');
  const response2 = await fetch('http://localhost:3333/inventory?page=1&limit=3');
  const data2 = await response2.json();
  console.log(`Status: ${response2.status}`);
  console.log(`Items count: ${data2.items.length}`);
  console.log(`Item IDs: ${data2.items.map(item => item.id).join(', ')}\n`);

  // Test 3: page=2 limit=3
  console.log('Test 3: page=2 limit=3');
  const response3 = await fetch('http://localhost:3333/inventory?page=2&limit=3');
  const data3 = await response3.json();
  console.log(`Status: ${response3.status}`);
  console.log(`Items count: ${data3.items.length}`);
  console.log(`Item IDs: ${data3.items.map(item => item.id).join(', ')}\n`);

  // Test 4: Invalid parameters - should return 400
  console.log('Test 4: Invalid page parameter');
  const response4 = await fetch('http://localhost:3333/inventory?page=abc&limit=5');
  const data4 = await response4.json();
  console.log(`Status: ${response4.status}`);
  console.log(`Error: ${data4.error}\n`);

  // Test 5: Invalid limit - should return 400
  console.log('Test 5: Invalid limit parameter');
  const response5 = await fetch('http://localhost:3333/inventory?page=1&limit=101');
  const data5 = await response5.json();
  console.log(`Status: ${response5.status}`);
  console.log(`Error: ${data5.error}\n`);

  process.exit(0);
}

// Start server first
import('./src/server/server.js').then(async () => {
  // Wait a bit for server to start
  setTimeout(async () => {
    try {
      await testPagination();
    } catch (error) {
      console.error('Test failed:', error);
      process.exit(1);
    }
  }, 1000);
});