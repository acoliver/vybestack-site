/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  let result = text;

  // First, normalize multiple spaces to single space (but preserve structure)
  result = result.replace(/[ \t]+/g, ' ');

  // Ensure exactly one space after sentence-ending punctuation
  // Match ., !, or ? followed by optional spaces, then a letter
  result = result.replace(/([.!?])\s*([a-zA-Z])/g, '$1 $2');

  // Capitalize first character of the string
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());

  // Capitalize after sentence-ending punctuation
  // This is tricky with abbreviations like "Mr." or "Dr."
  // We'll use negative lookbehind to avoid capitalizing after common abbreviations
  // Note: Common abbreviations list kept for reference but not directly used in regex
  const commonAbbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St', 'etc', 'vs'];

  // First pass: capitalize after . ! ?
  result = result.replace(/([.!?])\s+([a-z])/g, (match, punct, letter) => {
    // Check if this follows a common abbreviation
    const beforePunct = result.substring(0, result.indexOf(match)).trim().split(/\s+/).pop() || '';
    const isAfterAbbr = commonAbbreviations.some(abbr => beforePunct === abbr || beforePunct === abbr + '.');

    if (isAfterAbbr) {
      return match; // Don't capitalize after abbreviations
    }
    return punct + ' ' + letter.toUpperCase();
  });

  // Handle case where there's no space after punctuation
  result = result.replace(/([.!?])([a-z])/g, (match, punct, letter) => {
    return punct + ' ' + letter.toUpperCase();
  });

  return result;
}

/**
 * Find URLs in the text and return an array of matched URL strings.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // URL pattern - matches http, https, and www-prefixed URLs
  // Negative lookbehind for @ to avoid matching email addresses
  const urlPattern = /(?<!@)(?:https?:\/\/|www\.)[^\s<>"']+(?:\/[^\s<>"']*)?/gi;

  const matches = text.match(urlPattern) || [];

  // Clean up trailing punctuation from each URL
  return matches.map((url) => {
    // Remove trailing punctuation: .,;:!?) but not if part of the URL
    return url.replace(/[.,;:!?)\]]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Pattern to match http://example.com URLs
  // Capture groups: scheme, everything up to path, full path
  const exampleUrlPattern = /(https?):\/\/example\.com(\/[^\s]*)?/gi;

  return text.replace(exampleUrlPattern, (match, scheme, path = '') => {
    // Always upgrade to https
    const newScheme = 'https';

    // Check if we should skip docs rewrite
    const skipDocsRewrite = shouldSkipDocsRewrite(path);

    if (!skipDocsRewrite && path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return `${newScheme}://docs.example.com${path}`;
    } else if (!skipDocsRewrite && path === '/docs') {
      return `${newScheme}://docs.example.com/docs`;
    } else {
      // Just upgrade scheme
      return `${newScheme}://example.com${path}`;
    }
  });
}

/**
 * Check if a URL path should skip the docs host rewrite.
 * Returns true if path contains dynamic hints or legacy extensions.
 */
function shouldSkipDocsRewrite(path: string): boolean {
  if (!path) {
    return false;
  }

  const lowerPath = path.toLowerCase();

  // Dynamic hints that indicate server-side content
  const dynamicHints = ['cgi-bin', '?', '&', '='];

  // Legacy server-side extensions
  const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];

  // Check for dynamic hints
  for (const hint of dynamicHints) {
    if (lowerPath.includes(hint)) {
      return true;
    }
  }

  // Check for legacy extensions
  for (const ext of legacyExtensions) {
    if (lowerPath.endsWith(ext) || lowerPath.includes(ext + '?') || lowerPath.includes(ext + '&')) {
      return true;
    }
  }

  return false;
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  const trimmed = value.trim();

  // Pattern: mm/dd/yyyy - exactly 2 digits / 2 digits / 4 digits
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = trimmed.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  return year;
}
