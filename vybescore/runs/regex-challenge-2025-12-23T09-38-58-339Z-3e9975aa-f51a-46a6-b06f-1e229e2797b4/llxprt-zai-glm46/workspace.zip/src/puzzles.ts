/**
 * Match words starting with the prefix but excluding banned words (exceptions).
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }

  const results: string[] = [];

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with the prefix
  // Word boundary \b ensures we match whole words only
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[\\w]*)`, 'gi');

  const matches = text.match(wordPattern) || [];

  // Filter out exceptions (case-insensitive)
  for (const match of matches) {
    const lowerMatch = match.toLowerCase();
    const isException = exceptions.some((ex) => ex.toLowerCase() === lowerMatch);

    if (!isException) {
      results.push(match);
    }
  }

  return results;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookbehind to check for a preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  const results: string[] = [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern: token preceded by a digit (using lookbehind)
  // Positive lookbehind (?<=\d) ensures there's a digit before the token
  // The match includes the digit + token combination
  const pattern = new RegExp(`\\d${escapedToken}(?!\\w)`, 'g');

  let match;
  while ((match = pattern.exec(text)) !== null) {
    results.push(match[0]);
  }

  return results;
}

/**
 * Validate passwords according to strong password policy.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must contain at least one symbol/special character
  // Symbols: anything that's not a letter, digit, or whitespace
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // We look for patterns of length 2-4 that repeat
  if (hasRepeatedSequence(value)) {
    return false;
  }

  return true;
}

/**
 * Check if the password contains immediate repeated sequences.
 * Looks for patterns like abab, abcabc, abcdabcd.
 */
function hasRepeatedSequence(password: string): boolean {
  // Check for sequences of length 2-4 that repeat immediately
  for (let seqLen = 2; seqLen <= 4; seqLen++) {
    for (let i = 0; i <= password.length - seqLen * 2; i++) {
      const sequence = password.substring(i, i + seqLen);
      const nextSequence = password.substring(i + seqLen, i + seqLen * 2);

      if (sequence === nextSequence) {
        return true;
      }
    }
  }

  return false;
}

/**
 * Detect IPv6 addresses (including shorthand :: notation).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // First, check if this looks like an IPv4 address - if so, return false
  // IPv4 pattern: 4 groups of 1-3 digits, separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;

  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Look for IPv6 patterns within the text
  const trimmed = value.trim();

  // IPv6 patterns - look for:
  // 1. Multiple groups of hex digits separated by colons
  // 2. Double colon (::) shorthand
  // 3. But NOT pure IPv4 addresses

  // Full IPv6: 8 groups of 1-4 hex digits
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;

  // IPv6 with :: shorthand (not at edges)
  const ipv6ShorthandPattern = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;

  // IPv6 with :: at start
  const ipv6ShorthandStartPattern = /::(?:[0-9a-fA-F]{1,4}:*)+/;

  // IPv6 with :: at end
  const ipv6ShorthandEndPattern = /(?:[0-9a-fA-F]{1,4}:*)+::/;

  // Check if the string contains an IPv6 pattern
  return ipv6FullPattern.test(trimmed) ||
         ipv6ShorthandPattern.test(trimmed) ||
         ipv6ShorthandStartPattern.test(trimmed) ||
         ipv6ShorthandEndPattern.test(trimmed);
}
