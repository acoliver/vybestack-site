export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper format checking.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  const trimmed = value.trim();

  // Basic structure check for common invalid patterns
  if (
    trimmed.includes('..') ||
    trimmed.startsWith('.') ||
    trimmed.endsWith('.') ||
    trimmed.includes('@.') ||
    trimmed.includes('.@')
  ) {
    return false;
  }

  // Email regex pattern:
  // - Local part: alphanumeric, dots, hyphens, underscores, plus signs
  // - @ symbol
  // - Domain: alphanumeric, hyphens (no underscores), dots
  // - TLD: at least 2 letters, supports multi-level (co.uk)
  // Domain cannot have underscores
  if (trimmed.includes('_@') || /@[^@]*_/.test(trimmed)) {
    return false;
  }

  // Cannot have double dots in local or domain part
  if (/\.\./.test(trimmed.replace('@', ''))) {
    return false;
  }

  // Main email pattern
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  if (!emailPattern.test(trimmed)) {
    return false;
  }

  // Split and validate parts
  const parts = trimmed.split('@');
  if (parts.length !== 2) {
    return false;
  }

  const [local, domain] = parts;

  // Local part cannot be empty, start or end with dot
  if (!local || local.startsWith('.') || local.endsWith('.')) {
    return false;
  }

  // Domain cannot have underscores and must have valid structure
  if (!domain || domain.includes('_') || domain.startsWith('-') || domain.endsWith('.') || domain.startsWith('.')) {
    return false;
  }

  // Domain must have at least one dot and valid TLD (2+ chars)
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }

  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2 || !/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }

  // Each domain part must be valid
  for (const part of domainParts) {
    if (!part || part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Options parameter reserved for future use (e.g., allowExtensions)
  void options;
  if (!value || typeof value !== 'string') {
    return false;
  }

  const trimmed = value.trim();

  // Remove all non-digit characters for validation
  const digitsOnly = trimmed.replace(/\D/g, '');

  // Length checks: with country code (11) or without (10)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }

  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }

  // Extract the actual 10-digit number (remove leading 1 if present)
  const tenDigitNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = tenDigitNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = tenDigitNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Validate format matches common patterns
  // Patterns: +1 XXX XXX XXXX, (XXX) XXX-XXXX, XXX-XXX-XXXX, XXXXXXXXXX
  const usPhonePattern = /^\+?1?[\s()-]?\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/;

  return usPhonePattern.test(trimmed);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like:
 * +54 9 11 1234 5678 (mobile with country code)
 * 011 1234 5678 (Buenos Aires, no country code)
 * +54 341 123 4567 (landline with country code)
 * 0341 4234567 (landline, no country code)
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  const trimmed = value.trim();

  // Check for invalid characters (only digits, spaces, hyphens, and leading + allowed)
  if (!/^[\d\s+-]+$/.test(trimmed)) {
    return false;
  }

  // Remove separators (spaces, hyphens) but keep the digits and + for validation
  const cleaned = trimmed.replace(/[\s-]/g, '');

  // When country code is omitted, the number must begin with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }

  // Remove country code for further validation
  const digitsOnly = cleaned.replace(/^\+?54/, '');

  // Now digitsOnly should start with optional 0 (trunk prefix), optional 9 (mobile), then area code
  // The area code should be 2-4 digits (including the trunk prefix 0 if present)
  // And subscriber number should be 6-8 digits

  // Total digits after removing country code should be:
  // With trunk prefix (0): 1 (trunk) + 2-3 (area) + 6-8 (subscriber) = 9-12 digits
  // Or with trunk prefix + mobile (09): 2 (prefix) + 2-3 (area) + 6-8 (subscriber) = 10-13 digits
  // But the area code is counted as 2-4 digits in the spec, so trunk is part of it
  
  const totalDigits = digitsOnly.length;
  if (totalDigits < 8 || totalDigits > 13) {
    return false;
  }

  // Extract components based on the structure
  // Pattern: ^0?9?<area><subscriber>$
  // Where area is 2-4 digits starting with 1-9 (or 0 followed by 1-9)
  // And subscriber is 6-8 digits
  
  // Try to match the pattern and extract area code and subscriber number
  const argPhonePattern = /^(0)?9?(\d{2,4})(\d{6,8})$/;
  const match = digitsOnly.match(argPhonePattern);

  if (!match) {
    return false;
  }

  const [, trunkPrefix, areaCode, subscriberNumber] = match;

  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Area code validation
  // If trunk prefix (0) is present before area code, area code must start with 1-9
  // If trunk prefix is absent (country code present case), area code must start with 1-9
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }

  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // When country code is present, trunk prefix (0) may be present or absent
  // When country code is absent, trunk prefix (0) must be present
  if (!hasCountryCode && !trunkPrefix) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Permits: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and X Æ A-12 style names (with digits)
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  const trimmed = value.trim();

  if (trimmed.length === 0) {
    return false;
  }

  // Name pattern:
  // - Unicode letters (\p{L}) including accented characters
  // - Apostrophes (') for names like O'Connor
  // - Hyphens (-) for hyphenated names
  // - Spaces for multiple names
  // Reject digits and special symbols
  const namePattern = /^[\p{L}'\s-]+$/u;

  if (!namePattern.test(trimmed)) {
    return false;
  }

  // Check for digits (should not be present)
  if (/\d/.test(trimmed)) {
    return false;
  }

  // Should have at least one letter
  if (!/\p{L}/u.test(trimmed)) {
    return false;
  }

  // No consecutive separators
  if (/\s{2,}/.test(trimmed) || /'{2,}/.test(trimmed) || /-{2,}/.test(trimmed)) {
    return false;
  }

  // Cannot start or end with separator
  if (/^[\s'-]/.test(trimmed) || /[\s'-]$/.test(trimmed)) {
    return false;
  }

  // Must have at least 2 characters and at least one letter
  return trimmed.length >= 2;
}

/**
 * Luhn algorithm for credit card checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let doubleDigit = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    doubleDigit = !doubleDigit;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa, Mastercard, AmEx).
 * Checks prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 13, 16 or 19 digits, starts with 4
  const visaPattern = /^4\d{12}(\d{3}(\d{3})?)?$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardPattern = /^(?:5[1-5]\d{2}|2[2-7]\d{2})\d{12}$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;

  const isValidFormat = visaPattern.test(cleaned) ||
                        mastercardPattern.test(cleaned) ||
                        amexPattern.test(cleaned);

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
