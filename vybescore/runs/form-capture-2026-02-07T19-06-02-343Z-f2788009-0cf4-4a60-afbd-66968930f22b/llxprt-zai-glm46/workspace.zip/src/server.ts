import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createRequire } from 'node:module';
import initSqlJs, { Database } from 'sql.js';

const require = createRequire(import.meta.url);

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
// Use src/templates for views to work in both dev and production
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 2;
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  // Check required fields
  for (const field of requiredFields) {
    if (!data[field] || typeof data[field] !== 'string' || data[field].trim().length === 0) {
      const label = field
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, (str) => str.toUpperCase())
        .trim();
      errors.push(`${label} is required`);
    }
  }

  // Validate email format
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please provide a valid email address');
  }

  // Validate phone format
  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please provide a valid phone number (may include +, digits, spaces, parentheses, and dashes)');
  }

  // Validate postal code format
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please provide a valid postal/zip code');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Initialize database
async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs({
    locateFile: (file) => {
      // Use local WASM file from node_modules
      const sqlJsPath = path.dirname(require.resolve('sql.js'));
      return path.join(sqlJsPath, file);
    },
  });

  let database: Database;
  const fs = await import('node:fs');

  if (fs.existsSync(DB_PATH)) {
    // Load existing database
    const buffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(buffer);
  } else {
    // Create new database from schema
    database = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Save initial database
    const data = database.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }

  return database;
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  const data = db.export();
  const buffer = Buffer.from(data);
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  const fs = require('node:fs');
  fs.writeFileSync(DB_PATH, buffer);
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || '',
  };

  const validation = validateForm(formData);

  if (!validation.valid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (!db) {
    return res.status(500).render('form', {
      errors: ['Database not available. Please try again.'],
      values: formData,
    });
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName!,
      formData.lastName!,
      formData.streetAddress!,
      formData.city!,
      formData.stateProvince!,
      formData.postalCode!,
      formData.country!,
      formData.email!,
      formData.phone!,
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission to personalize the thank you message
  let firstName = 'Friend';
  
  if (db) {
    try {
      const result = db.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      if (result.length > 0 && result[0].values.length > 0) {
        firstName = result[0].values[0][0] as string;
      }
    } catch (error) {
      console.error('Error fetching submission:', error);
    }
  }

  res.render('thank-you', { firstName });
});

// Error handling
// eslint-disable-next-line @typescript-eslint/no-unused-vars
app.use((err: Error, req: Request, res: Response, _next: NextFunction) => {
  console.error('Server error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {},
  });
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      db.close();
      db = null;
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }

  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Initialize database and optionally start server
let initializationPromise: Promise<void> | null = null;

async function initialize(): Promise<void> {
  if (!initializationPromise) {
    initializationPromise = (async () => {
      try {
        db = await initDatabase();
        console.log('Database initialized');
      } catch (error) {
        console.error('Failed to initialize database:', error);
        throw error;
      }
    })();
  }
  return initializationPromise;
}

// Start server
async function start(): Promise<void> {
  await initialize();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Store server reference for graceful shutdown
  (app as unknown as Record<string, unknown>).server = server;
}

// Always initialize database
initialize().catch((error) => {
  console.error('Database initialization failed:', error);
});

// Start server if not in test mode
if (process.env.NODE_ENV !== 'test') {
  start();
}

// Export for testing
export default app;
