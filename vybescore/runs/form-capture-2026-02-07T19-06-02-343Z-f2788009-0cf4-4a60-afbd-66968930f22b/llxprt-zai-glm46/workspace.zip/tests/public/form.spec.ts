import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: unknown;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Set test environment
  process.env.NODE_ENV = 'test';
  
  // Import and start the server
  app = (await import('../../src/server.js')).default;
  
  // Wait for server to be ready
  await new Promise(resolve => setTimeout(resolve, 2000));
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    
    const $ = cheerio.load(response.text);
    
    // Check all required fields exist
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
    
    // Check labels are properly associated
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({});
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Should show error messages
    expect($('.error-list').length).toBeGreaterThan(0);
    expect(response.text).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1 555-123-4567',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone!',
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid phone');
  });

  it('accepts international phone formats', async () => {
    const testCases = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '+91 98765 43210',
    ];

    for (const phone of testCases) {
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'John',
          lastName: 'Doe',
          streetAddress: '123 Main St',
          city: 'Springfield',
          stateProvince: 'IL',
          postalCode: '62701',
          country: 'USA',
          email: 'john@example.com',
          phone: phone,
        });
      
      // Should not complain about phone format
      if (response.status === 400) {
        expect(response.text).not.toContain('valid phone');
      }
    }
  });

  it('accepts various postal code formats', async () => {
    const testCases = [
      { code: 'SW1A 1AA', country: 'UK' },
      { code: 'C1000', country: 'Argentina' },
      { code: 'B1675', country: 'Argentina' },
      { code: '62701', country: 'USA' },
    ];

    for (const { code, country } of testCases) {
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          firstName: 'John',
          lastName: 'Doe',
          streetAddress: '123 Main St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: code,
          country: country,
          email: 'john@example.com',
          phone: '+1 555-123-4567',
        });
      
      // Should not complain about postal code format
      if (response.status === 400) {
        expect(response.text).not.toContain('valid postal');
      }
    }
  });

  it('persists submission and redirects', async () => {
    // Clear database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Avenue',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('spam');
    expect(response.text).toContain('identity');
    
    const $ = cheerio.load(response.text);
    expect($('a[href="/"]')).toHaveLength(1);
  });

  it('preserves form values on validation error', async () => {
    const formData = {
      firstName: 'Alice',
      lastName: 'Johnson',
      streetAddress: '789 Pine St',
      city: 'Paris',
      stateProvince: 'Île-de-France',
      postalCode: '75001',
      country: 'France',
      email: 'invalid-email-format',
      phone: '+33 1 23 45 67 89',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check that values are preserved
    expect($('input[name="firstName"]').val()).toBe('Alice');
    expect($('input[name="email"]').val()).toBe('invalid-email-format');
    expect($('input[name="phone"]').val()).toBe('+33 1 23 45 67 89');
  });
});
