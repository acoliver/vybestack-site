import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    function validatePositiveInt(param: string | undefined, paramName: string): number | undefined {
      if (param === undefined) {
        return undefined;
      }
      
      const num = Number(param);
      
      if (param.trim() === '' || isNaN(num)) {
        res.status(400).json({ error: `${paramName} must be a valid number` });
        return undefined;
      }
      
      if (!Number.isInteger(num)) {
        res.status(400).json({ error: `${paramName} must be an integer` });
        return undefined;
      }
      
      if (num <= 0) {
        res.status(400).json({ error: `${paramName} must be greater than 0` });
        return undefined;
      }
      
      if (num > 1000) {
        res.status(400).json({ error: `${paramName} must not exceed 1000` });
        return undefined;
      }
      
      return num;
    }

    const page = validatePositiveInt(pageParam, 'page');
    const limit = validatePositiveInt(limitParam, 'limit');
    
    if (page === undefined && pageParam !== undefined) {
      return;
    }
    
    if (limit === undefined && limitParam !== undefined) {
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
