const BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$/;

/**
 * Validate that a string is valid Base64.
 * Throws an error if the input contains invalid characters or has malformed padding.
 */
function validateBase64(input: string): void {
  if (!BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check if there's padding, and if so, validate it's correct
  const lastPaddingIndex = input.indexOf('=');
  if (lastPaddingIndex !== -1) {
    const padding = input.slice(lastPaddingIndex);
    if (!/^=+$/.test(padding) || padding.length > 2) {
      throw new Error('Invalid Base64 input: malformed padding');
    }

    // If there's padding, the total length should be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  }
}

/**
 * Encode plain text to Base64 using the standard alphabet.
 * Output includes padding characters (=) as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for clearly invalid payloads (illegal characters, malformed padding).
 */
export function decode(input: string): string {
  // Remove whitespace for more forgiving input handling
  const trimmed = input.replace(/\s/g, '');

  // Validate the input is well-formed Base64
  validateBase64(trimmed);

  try {
    return Buffer.from(trimmed, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
