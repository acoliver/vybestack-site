import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';

/**
 * Formats a report in Markdown format
 */
export const renderMarkdown: ReportFormatter = (data: ReportData, options: ReportOptions): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;
  
  const lines: string[] = [];
  
  // Add title
  lines.push(`# ${title}`);
  lines.push('');
  
  // Add summary
  lines.push(summary);
  lines.push('');
  
  // Add entries
  lines.push('## Entries');
  entries.forEach(entry => {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  });
  
  // Add total if requested
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push('');
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
};