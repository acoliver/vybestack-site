#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { resolve } from 'node:path';
import { exit, argv } from 'node:process';
import type { ReportData, ReportOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Displays usage information for the CLI tool
 */
function showUsage(): void {
  console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Arguments:');
  console.error('  <data.json>        Path to JSON file containing report data');
  console.error('  --format <format>  Output format (markdown, text)');
  console.error('  --output <path>    Optional path to write output to file');
  console.error('  --includeTotals    Include total amount calculation');
}

/**
 * Validates and throws detailed error for missing or malformed fields in report data
 */
function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Empty data');
  }

  const record = data as Record<string, unknown>;

  if (typeof record.title !== 'string' || record.title.trim() === '') {
    throw new Error('Invalid report data: title is required and must be a non-empty string');
  }

  if (typeof record.summary !== 'string' || record.summary.trim() === '') {
    throw new Error('Invalid report data: summary is required and must be a non-empty string');
  }

  if (!Array.isArray(record.entries) || record.entries.length === 0) {
    throw new Error('Invalid report data: entries must be a non-empty array');
  }

  record.entries.forEach((entry: unknown, index: number) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry at index ${index} is not an object`);
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (typeof entryRecord.label !== 'string' || entryRecord.label.trim() === '') {
      throw new Error(`Invalid report data: entry at index ${index} has invalid label`);
    }

    if (typeof entryRecord.amount !== 'number' || isNaN(entryRecord.amount)) {
      throw new Error(`Invalid report data: entry at index ${index} has invalid amount`);
    }
  });
}

/**
 * Parses command line arguments using Node's standard library
 */
function parseArgs(args: string[]): { 
  dataPath: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
} {
  const dataPathIndex = args.findIndex(arg => !arg.startsWith('-'));

  if (dataPathIndex === -1) {
    throw new Error('Missing required argument: data file path');
  }

  const dataPath = args[dataPathIndex];

  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('Missing required: --format <format>');
  }

  const format = args[formatIndex + 1] as FormatType;
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}. Supported formats: markdown, text`);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length 
    ? args[outputIndex + 1] 
    : undefined;

  const includeTotals = args.includes('--includeTotals');

  return { dataPath, format, outputPath, includeTotals };
}

/**
 * Reads and parses report data from a JSON file
 */
async function loadReportData(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(resolve(filePath), 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON file: ${error.message}`);
    }
    if (error instanceof Error) {
      throw new Error(`Failed to load report data: ${error.message}`);
    }
    throw new Error('Unknown error occurred while loading report data');
  }
}

/**
 * Main function to execute the CLI tool
 */
async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs(argv.slice(2));
    
    const data = await loadReportData(dataPath);
    const options: ReportOptions = { includeTotals, outputPath };

    // Select formatter based on format
    let output: string;
    switch (format) {
      case 'markdown':
        output = renderMarkdown(data, options);
        break;
      case 'text':
        output = renderText(data, options);
        break;
    }

    // Write output to file or stdout
    if (outputPath) {
      await writeFile(resolve(outputPath), output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    showUsage();
    exit(1);
  }
}

// Execute the CLI
main();