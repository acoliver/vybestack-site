const { createInput, createComputed, createCallback } = require('./dist/index.js');

// Create a simple reactive system
const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);

// Create callback and log when it fires
let callbackCount = 0;
createCallback(() => {
  console.log(`Callback fired! Output value: ${output()}`);
  callbackCount++;
});

console.log(`Initial callback count: ${callbackCount}`);
console.log(`Input value: ${input()}`);
console.log(`Output value: ${output()}`);

// Change the input value
setInput(3);

console.log(`After changing input to 3:`);
console.log(`Input value: ${input()}`);
console.log(`Output value: ${output()}`);
console.log(`Callback count: ${callbackCount}`);