/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<Subject<unknown>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  // Create a snapshot of all observers to notify
  const observersToNotify = Array.from(subject.observers.values())
  
  // Notify all observers
  for (const observer of observersToNotify) {
    // Create a new active observer context to allow dependency tracking during callbacks
    const prevActive = activeObserver
    // Keep activeObserver value to preserve dependencies during callback execution
    try {
      updateObserver(observer as Observer<unknown>)
    } finally {
      activeObserver = prevActive
    }
  }
}

export function addObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
  
  // Track the dependency
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject as Subject<unknown>)
}

export function removeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.observers) return
  subject.observers.delete(observer)
  
  // Remove from dependencies
  if (observer.dependencies) {
    observer.dependencies.delete(subject as Subject<unknown>)
  }
}

export function disposeObserver(observer: ObserverR): void {
  if (!observer.dependencies) return
  const subjects = Array.from(observer.dependencies)
  observer.dependencies.clear()
  for (const subject of subjects) {
    removeObserver(subject, observer)
  }
}
