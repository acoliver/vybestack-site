/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, disposeObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevVal) => {
      // Execute the side effect function
      const returnValue = updateFn(prevVal)
      // Return the return value from the function
      return returnValue as T
    },
  }
  
  // Execute the callback once to establish initial dependencies
  // and to ensure it's registered as an observer
  updateObserver(observer)
  
  // Add a cleanup function that also detaches from dependencies
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Dispose to properly clean up all subscriptions
    disposeObserver(observer)
  }
  
  return unsubscribe
}
