/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: new Set(),
    observers: new Set(),
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from all tracked subjects
    observer.subjects?.forEach(subject => {
      if ('observers' in subject && subject.observers) {
        subject.observers.delete(observer)
      }
    })
    
    // Clear the observer to stop further updates
    observer.subjects?.clear()
    observer.subjects = undefined
    observer.observers?.clear()
    observer.observers = undefined
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
