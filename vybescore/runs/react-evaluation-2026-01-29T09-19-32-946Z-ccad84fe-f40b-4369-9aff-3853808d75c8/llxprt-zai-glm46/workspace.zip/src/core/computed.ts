/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    subjects: new Set(),
    observers: new Set(),
    value,
    updateFn,
  }
  updateObserver(o)
  
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of the active observer
      if (observer.subjects) {
        observer.subjects.add(o)
      }
      o.observers?.add(observer)
    }
    return o.value!
  }
}
