/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  let stale = true
  
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    
    // Register current observer as dependent on this computed value
    if (currentObserver) {
      o.observers!.add(currentObserver)
    }
    
    // Update value if stale (this will register dependencies)
    if (stale) {
      updateObserver(o)
      stale = false
    }
    
    return o.value!
  }
  
  // Initialize the value
  updateObserver(o)
  stale = false
  
  return getter
}