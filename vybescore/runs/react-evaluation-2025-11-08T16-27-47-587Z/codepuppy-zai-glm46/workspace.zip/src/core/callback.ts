/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    observers: new Set(),
  }
  
  let disposed = false
  
  const wrappedUpdateFn: UpdateFn<T> = (prevValue) => {
    if (disposed) return value as T
    return updateFn(prevValue)
  }
  
  observer.updateFn = wrappedUpdateFn
  
  // Execute the callback once to track dependencies and perform initial effect
  updateObserver(observer)
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects that reference it
    // This is a simple approach - in a real system we'd need to track this more carefully
    observer.value = undefined
    // Keep a no-op function to avoid errors
    observer.updateFn = () => value as T
    observer.observers = new Set()
  }
  
  return unsubscribe
}