const text = 'preview prevent prefix';
const prefix = 'pre';
const exceptions = ['prevent'];
console.log('Text:', text);
console.log('Prefix:', prefix);
console.log('Exceptions:', exceptions);

// Test the regex like in the template literal
const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]]/g, '\$&');
console.log('Escaped Prefix:', escapedPrefix);
const wordRegex = new RegExp(`\b${escapedPrefix}\w*`, 'gi');
console.log('Regex:', wordRegex);
const matches = text.match(wordRegex) || [];
console.log('Matches:', matches);

// Test embedded token
const text2 = 'xfoo 1foo foo';
const token = 'foo';
const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '\$&');
console.log('\nToken Text:', text2);
console.log('Token:', token);
console.log('Escaped Token:', escapedToken);
const tokenRegex = new RegExp(`\d${escapedToken}`, 'g');
console.log('Token Regex:', tokenRegex);
const tokenMatches = text2.match(tokenRegex) || [];
console.log('Token Matches:', tokenMatches);