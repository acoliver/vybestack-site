/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences, collapses extra spaces,
 * and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, normalize multiple spaces to single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Then ensure proper spacing after sentence endings
  result = result.replace(/([.!?])(?!\s|$)/g, '$1 ');
  
  // Remove spaces before sentence endings
  result = result.replace(/\s+([.!?])/g, '$1');
  
  // Capitalize after sentence boundaries, considering common abbreviations
  result = result.replace(/(?<![A-Z]\.[A-Z]\.)(?<![A-Z]\.)(?<=[.!?]\s)([a-z])/g, (match, char) => {
    return char.toUpperCase();
  });
  
  // Handle the very first character
  result = result.replace(/^\s*([a-z])/, (match, char) => char.toUpperCase());
  
  // Clean up any double spaces that might have been created
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Comprehensive URL regex
  // Matches http/https, www, domain names with subdomains, paths, query strings, fragments
  const urlRegex = /(https?:\/\/(?:www\.|(?!www))[^\s/$.?#].[^\s]*|www\.[^\s/$.?#].[^\s]*)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each match
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,!?;:)+\]\}]+$/g, '');
  });
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but not https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to rules:
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/(https?:\/\/)([^\/]+)(\/[^\s]*)/gi, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should host-rewrite (has /docs/ path and no dynamic indicators)
    const hasDocsPath = path.startsWith('/docs/');
    const hasDynamicHints = 
      path.includes('cgi-bin') || 
      path.includes('?') || 
      path.includes('&') || 
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/i.test(path);
    
    if (hasDocsPath && !hasDynamicHints) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.' + host + path;
    } else {
      // Just upgrade scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day against month (simple validation - doesn't handle leap years in detail)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day > daysInMonth[month - 1]) {
    // Check for February 29 on leap years (simple check)
    if (month !== 2 || day !== 29 || (parseInt(year, 10) % 4 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
