export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email regex with enhanced restrictions
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for disallowed patterns
  if (value.includes('..')) return false; // Double dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // Leading/trailing dots
  if (value.includes('@.')) return false; // Invalid domain start
  if (value.includes('.@')) return false; // Invalid local end
  if (value.includes('_')) return false; // Underscores not allowed
  
  // Check if domain ends with dot
  const domain = value.split('@')[1];
  if (domain && domain.endsWith('.')) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US numbers, 11 if including country code)
  if (digits.length === 11 && digits.startsWith('1')) {
    // Valid +1 prefix number
    const areaCode = digits.substring(1, 4);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  } else if (digits.length === 10) {
    // Valid 10-digit number
    const areaCode = digits.substring(0, 3);
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  } else {
    return false; // Invalid length
  }
  
  // Comprehensive regex for US phone formats
  const phoneRegex = /^(?:\+1[\s.-]?)?(?:\(?([2-9]\d{2})\)?[\s.-]?)?([2-9]\d{2})[\s.-]?(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area codes are 2-4 digits (leading 1-9), subscriber numbers 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers
  // Optional +54, optional 0 (trunk), optional 9 (mobile), area code (2-4 digits starting 1-9), subscriber (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleanValue)) {
    return false;
  }
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits, starting with 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If no country code, must start with trunk prefix 0
  if (!cleanValue.startsWith('+54') && !value.includes('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'](?:[\p{L}\p{M}'\-\s]*[\p{L}\p{M}'])?$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Reject names with digits or symbols (should be caught by regex, but double-check)
  if (/\d/.test(trimmed)) return false;
  
  // Reject names that are just symbols or contain unusual symbols
  const hasValidChars = /^\s*[\p{L}\p{M}'\-][\p{L}\p{M}'\-\s]*\s*[\p{L}\p{M}'\-]?\s*$/u.test(trimmed);
  if (!hasValidChars) return false;
  
  // Should contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) return false;
  
  return true;
}

/**
 * Helper function: Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // From right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Checks length, prefixes, and passes Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9][3-9]\d|2[3-9]\d{2}|[3-6]\d{3}|7([01]\d|20))\d{12})$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  let isValidPrefix = false;
  
  if (visaRegex.test(cleanValue)) {
    isValidPrefix = true;
  } else if (mastercardRegex.test(cleanValue)) {
    isValidPrefix = true;
  } else if (amexRegex.test(cleanValue)) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) return false;
  
  // Pass Luhn checksum
  return runLuhnCheck(cleanValue);
}
