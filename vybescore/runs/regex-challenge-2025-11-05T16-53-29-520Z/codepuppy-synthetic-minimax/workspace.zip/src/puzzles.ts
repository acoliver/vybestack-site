/**
 * Finds words beginning with a prefix but excluding listed exceptions.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }
  
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]]/g, '\$&');

  
  
  // Create regex to match words starting with the prefix
  const wordRegex = new RegExp(`\b${escapedPrefix}\w*`, 'gi');
  
  
  const matches = text.match(wordRegex) || [];
  
  // Convert to lowercase for comparison, filter out exceptions
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  return matches
    .filter(word => !lowerExceptions.includes(word.toLowerCase()))
    // Remove duplicates while preserving order
    .filter((word, index, self) => self.indexOf(word) === index)
    .map(word => word);
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds as specified.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]]/g, '\$&');

  
  
  // Create regex to match token preceded by a digit (including the digit in the match)
  const tokenRegex = new RegExp(`\d${escapedToken}`, 'g');
  
  
  
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * Validates password strength according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab' should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like 'abab', 'testtest', '123123')
  // This pattern looks for any sequence of 2+ characters that repeats immediately
  if (/(.{2,})\1+/.test(value)) return false;
  
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand (compressing consecutive 0 groups)
  const ipv6Shorthand = /(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with mixed IPv4 embedded (e.g., ::ffff:192.0.2.128)
  const ipv6Mixed = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)(?:\.(25[0-5]|2[0-4]\d|[01]?\d?\d)){3}/;
  
  
  // IPv4 pattern to ensure we don't match IPv4 as IPv6
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d?\d)\b/;
  
  
  // First check for IPv4 and exclude pure IPv4 matches
  if (ipv4Pattern.test(value)) {
    // Check if it's exclusively IPv4
    const matches = value.match(ipv4Pattern);
    const withoutIPv4 = value.replace(ipv4Pattern, '').trim();
    if (withoutIPv4 === '' || !ipv6Full.test(withoutIPv4) && !ipv6Shorthand.test(withoutIPv4) && !ipv6Mixed.test(withoutIPv4)) {
      return false;
    }
  }
  
  // Now check for IPv6 patterns
  return ipv6Full.test(value) || ipv6Shorthand.test(value) || ipv6Mixed.test(value);
}