import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import { FormData } from './types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Database configuration
const DB_FILE_PATH = path.join(__dirname, '../data/submissions.sqlite');
const SCHEMA_FILE_PATH = path.join(__dirname, '../db/schema.sql');

let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  // Accept digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
};

const validatePostalCode = (postalCode: string): boolean => {
  // Accept alphanumeric strings, handle formats like "SW1A 1AA", "C1000", "B1675"
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.replace(/\s/g, '').length >= 3;
};

const validateFormData = (data: FormData): { isValid: boolean; errors: Record<string, string> } => {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalCode', 'country', 'email', 'phoneNumber'
  ];

  requiredFields.forEach(field => {
    if (!data[field]?.trim()) {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phoneNumber && !validatePhone(data.phoneNumber)) {
    errors.phoneNumber = 'Please enter a valid phone number';
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
};

// Database initialization
async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    let dbBuffer: Uint8Array | null = null;
    
    // Load existing database if it exists
    if (fs.existsSync(DB_FILE_PATH)) {
      const buffer = fs.readFileSync(DB_FILE_PATH);
      dbBuffer = new Uint8Array(buffer);
    }
    
    db = new SQL.Database(dbBuffer);
    
    // Run schema if table doesn't exist
    if (dbBuffer === null) {
      const schema = fs.readFileSync(SCHEMA_FILE_PATH, 'utf8');
      db.exec(schema);
      console.log('Database initialized with schema');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    // For testing, don't exit - just log the error
    if (process.env.NODE_ENV !== 'test') {
      process.exit(1);
    }
  }
}

// Save database to file
function saveDatabase(): void {
  if (db) {
    try {
      const data = db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(DB_FILE_PATH, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    title: 'Contact Form - Definitely Not A Scam'
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvinceRegion: req.body.stateProvinceRegion || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phoneNumber: req.body.phoneNumber || ''
  };

  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    // Re-render form with errors and previously entered values
    res.status(400).render('form', {
      errors: validation.errors,
      formData,
      title: 'Contact Form - Fix the errors below'
    });
    return;
  }

  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvinceRegion,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phoneNumber
    ]);
    
    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect('/thank-you');
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { title: 'Thank You! (Or should we say... sorry!)' });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (db) {
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<void> {
  await initDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
  });
}

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default app;