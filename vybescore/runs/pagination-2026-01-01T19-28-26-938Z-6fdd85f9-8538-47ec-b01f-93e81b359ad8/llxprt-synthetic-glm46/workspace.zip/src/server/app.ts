import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;
    
    // Validate page parameter
    let page;
    if (pageParam === undefined) {
      page = 1;
    } else {
      if (!/^\d+$/.test(pageParam)) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
      page = Number(pageParam);
      if (page <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter: must be greater than 0' });
      }
      if (page > 1000) {
        return res.status(400).json({ error: 'Invalid page parameter: must be less than or equal to 1000' });
      }
    }
    
    // Validate limit parameter
    let limit;
    if (limitParam === undefined) {
      limit = 5;
    } else {
      if (!/^\d+$/.test(limitParam)) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }
      limit = Number(limitParam);
      if (limit <= 0) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be greater than 0' });
      }
      if (limit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be less than or equal to 100' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
