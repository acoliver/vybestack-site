import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No items to display.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const hasPrevious = currentPage > 1;
  const hasNext = data.hasNext;

  const goToPrevious = (): void => {
    if (hasPrevious) {
      setCurrentPage(p => p - 1);
    }
  };

  const goToNext = (): void => {
    if (hasNext) {
      setCurrentPage(p => p + 1);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <nav aria-label="Pagination navigation">
        <div style={{ display: 'flex', gap: '10px', alignItems: 'center', marginTop: '20px' }}>
          <button 
            onClick={goToPrevious} 
            disabled={!hasPrevious}
            aria-disabled={!hasPrevious}
          >
            Previous
          </button>
          <span aria-live="polite">
            Page {currentPage} of {Math.ceil(data.total / PAGE_LIMIT)}
          </span>
          <button 
            onClick={goToNext} 
            disabled={!hasNext}
            aria-disabled={!hasNext}
          >
            Next
          </button>
        </div>
        <div style={{ marginTop: '10px', fontSize: '0.9em' }}>
          <span>Showing {data.items.length} of {data.total} items</span>
        </div>
      </nav>
    </section>
  );
}
