#!/usr/bin/env node

import { readFile } from 'node:fs/promises';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputFile = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('-')) {
      if (!result.inputFile) {
        result.inputFile = arg;
      }
    }
  }

  if (!result.inputFile) {
    throw new Error('Input file path is required');
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}

async function readJsonFile(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: root must be an object');
    }

    const reportData = data as Partial<ReportData>;

    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
    }

    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
    }

    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
    }

    for (let i = 0; i < reportData.entries.length; i++) {
      const entry = reportData.entries[i];
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
      }
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid JSON: entry at index ${i} has missing or invalid "amount" field`);
      }
    }

    return reportData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }
}

function getRenderer(format: string) {
  const formatters: Record<string, (data: ReportData, options: { includeTotals: boolean }) => string> = {
    markdown: renderMarkdown,
    text: renderText,
  };

  const renderer = formatters[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return renderer;
}

async function main(): Promise<void> {
  try {
    const args = parseArgs(process.argv.slice(2));

    const data = await readJsonFile(args.inputFile);

    const renderer = getRenderer(args.format);

    const output = renderer(data, { includeTotals: args.includeTotals });

    if (args.outputFile) {
      await writeFile(args.outputFile, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

function writeFile(path: string, content: string, encoding: BufferEncoding): Promise<void> {
  return import('node:fs/promises').then((fs) => fs.writeFile(path, content, encoding));
}

main().catch((error) => {
  console.error(error);
  process.exit(1);
});
