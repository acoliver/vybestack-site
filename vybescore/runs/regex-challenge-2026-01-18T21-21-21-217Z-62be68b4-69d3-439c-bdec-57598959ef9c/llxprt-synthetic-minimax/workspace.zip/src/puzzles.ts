/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary regex for the prefix
  const wordRegex = new RegExp(`\\b${prefix}[\\w]*`, 'gi');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const result = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Need to include the digit in the match to get '1foo' instead of just 'foo'
  const digitTokenRegex = new RegExp(`\\d${token}`, 'g');
  const fullMatches = text.match(digitTokenRegex) || [];
  
  return fullMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check requirements
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};:'"|,.<>?]/.test(value);
  
  // Check for immediate repeated sequences (e.g., abab)
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return hasUppercase && hasLowercase && hasDigit && hasSymbol;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern for IPv6 addresses including shorthand ::
  // This should match IPv6 addresses while excluding IPv4
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  
  // Check if this looks like IPv4 (would contain dots with digits)
  // If it does, it's not IPv6
  const looksLikeIPv4 = /\d+\.\d+\.\d+\.\d+/.test(value);
  
  if (looksLikeIPv4) {
    return false;
  }
  
  return ipv6Regex.test(value);
}
