/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence boundaries followed by optional spaces
  return text.replace(/(^|[.!?]\s*)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s"'<>]+(?=[^\w]|$)/g;
  const matches = text.match(urlRegex) || [];
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving existing https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/\s]+)([^\s]*)/g, (match, host, path) => {
    // Upgrade scheme to https
    let newUrl = 'https://' + host + path;
    
    // Check if path starts with /docs/ and doesn't have dynamic hints
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints and legacy extensions
      const hasDynamicHints = /(cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31) - simplified check
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Return the year portion
  return match[3];
}
