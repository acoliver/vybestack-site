export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  const cleanValue = value.replace(/[\s\-().]/g, '');
  const phoneRegex = /^\+?1?([2-9][0-8][0-9])[2-9][0-9]{2}[0-9]{4}$/;
  return phoneRegex.test(cleanValue);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleanValue = value.replace(/[\s\-().+]/g, '');
  
  // Handle the constraint: when country code (+54) is omitted, 
  // the number must begin with trunk prefix 0
  if (!cleanValue.startsWith('54')) {
    if (!cleanValue.startsWith('0')) {
      return false;
    }
  }
  
  // Pattern: (?:\+?54)?0?9?([1-9][0-9]{1,3})([0-9]{6,8})
  // Optional country code +54
  // Optional trunk 0
  // Optional mobile indicator 9
  // Area code: leading digit 1-9, followed by 1-3 more digits (total 2-4 digits)
  // Subscriber: 6-8 digits
  const phoneRegex = /^54?0?9?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  return phoneRegex.test(cleanValue);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must contain at least 2 characters (after trimming)
  const trimmedValue = value.trim();
  if (trimmedValue.length < 2) {
    return false;
  }
  
  // Reject names that are too long (arbitrary limit)
  if (trimmedValue.length > 100) {
    return false;
  }
  
  return nameRegex.test(trimmedValue);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check length (13, 15, 16, 19 digits)
  if (!/^\d{13,19}$/.test(cleanValue)) {
    return false;
  }
  
  // Check prefixes for major cards
  const cardRegex = /^(?:4\d{12,18}|5[1-5]\d{14}|3[47]\d{13}|6(?:011|5\d{2})\d{12})$/;
  if (!cardRegex.test(cleanValue)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
