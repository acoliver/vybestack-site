import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { dbService } from './database.js';

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string[];
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (UK, Argentina formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/u;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateFormData(data: FormData): { errors: FormErrors; isValid: boolean } {
  const errors: FormErrors = {};
  
  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!validateRequired(data[field])) {
      errors[field] = errors[field] || [];
      errors[field].push('This field is required');
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.email = errors.email || [];
    errors.email.push('Please enter a valid email address');
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.phone = errors.phone || [];
    errors.phone.push('Please enter a valid phone number');
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.postalCode = errors.postalCode || [];
    errors.postalCode.push('Please enter a valid postal code');
  }

  return {
    errors,
    isValid: Object.keys(errors).length === 0
  };
}

// Create Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Set EJS as view engine
app.set('views', path.join(process.cwd(), 'src', 'templates'));
app.set('view engine', 'ejs');

// Route handlers
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    values: {}
  });
});

app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const { errors, isValid } = validateFormData(formData);

    if (!isValid) {
      // Re-render form with errors
      return res.status(400).render('form', {
        errors,
        values: formData
      });
    }

    // Insert into database
    await dbService.insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    });

    // Save database to file
    await dbService.save();

    // Redirect to thank-you page with first name
    res.redirect(302, `/thank-you?name=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    next(error);
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // For demonstration, we'll use session or flash data
  // Since we're redirecting, we'll get the first name from the form
  // In a real app, you'd use sessions or flash messages
  const firstName = req.query.name || req.body?.firstName || 'friend';
  
  res.render('thank-you', {
    firstName: firstName
  });
});

// Error handler
app.use((error: Error, req: Request, res: Response) => {
  console.error('Server error:', error);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
async function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  
  try {
    await dbService.close();
    console.log('Database closed successfully');
    
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Initialize database and start server
async function startServer() {
  try {
    await dbService.initialize();
    console.log('Database initialized successfully');
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Store server reference for graceful shutdown
    const httpServer = server;
    (globalThis as { server?: typeof server }).server = httpServer;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
