import initSqlJs, { SqlJsStatic, Database } from 'sql.js';
import path from 'node:path';
import fs from 'node:fs';

export interface ContactSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseService {
  private db: Database | null = null;
  private dbPath: string;
  private SQL: SqlJsStatic | null = null;

  constructor() {
    this.dbPath = path.resolve('data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    if (!this.SQL) {
      const SqlJs = await initSqlJs.default({
        locateFile: (file: string) => {
          // Load sql.wasm from node_modules/sql.js/dist/
          return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
        }
      });
      this.SQL = SqlJs;
    }

    let buffer: Uint8Array | null = null;
    
    // Load existing database file if it exists
    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      buffer = new Uint8Array(fileBuffer);
    }

    // Create database instance
    if (this.SQL && this.SQL.Database) {
      this.db = new this.SQL.Database(buffer);
    }
    
    // Create table if it doesn't exist
    this.createTable();
  }

  private createTable(): void {
    if (!this.db) return;
    
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    
    this.db.exec(schema);
  }

  async insertSubmission(submission: ContactSubmission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    this.db.run(stmt, [
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    // Get the last insert row ID
    const idResult = this.db.exec("SELECT last_insert_rowid() as id");
    if (Array.isArray(idResult) && idResult.length > 0) {
      const values = idResult[0]?.values;
      if (Array.isArray(values) && values.length > 0) {
        const rowId = values[0][0] as number;
        return rowId;
      }
    }
    return 0;
  }

  async save(): Promise<void> {
    if (!this.db) return;
    
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbService = new DatabaseService();