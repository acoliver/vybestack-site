/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Subject,
  getActiveObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value !== undefined ? value : undefined as T,
    equalFn: undefined,
  }

  const recompute = () => {
    // Clear current dependencies before re-establishing them
    subject.observers.clear()
    
    // Set this computed as the active observer to track dependencies
    // Run the update function and capture its result
    updateObserver(observer)
    
    // Update the subject value with the result from observer
    subject.value = observer.value as T
    
    // Notify dependent observers if dependencies were re-established
    if (subject.observers.size > 0) {
      // Create a copy of observers to avoid issues with observers being modified during notification
      const currentObservers = new Set(subject.observers)
      notifyObservers(currentObservers)
    }
  }

  const computed: GetterFn<T> = (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Add observer to this subject's observers
      subject.observers.add(currentObserver)
      // Track this subject for cleanup in callback context
      if (currentObserver.__observedSubjects) {
        currentObserver.__observedSubjects.add(subject as Subject<unknown>)
      }
    }
    
    // Re-establish current dependencies before accessing
    recompute()
    
    return subject.value
  }

  // Perform initial computation to establish dependencies
  recompute()
  return computed
}
