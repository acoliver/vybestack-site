/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, Subject, getActiveObserver, updateActiveObserver } from '../types/reactive.js'



/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track all subjects this callback is observing for cleanup
  const observedSubjects = new Set<Subject<unknown>>()
  // Attach observed subjects to the observer for automatic tracking
  observer.__observedSubjects = observedSubjects
  
  // Store original subjects since observers can be added/removed during execution
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (val) => {
// Run the update function while observer is active to track dependencies
      const previousObserver = getActiveObserver()
    updateActiveObserver(observer as Observer<unknown>)
    
    try {
      // Clear previous subscriptions first then track new ones
      const previousSubjects = Array.from(observedSubjects)
      for (const subject of previousSubjects) {
        subject.observers.delete(observer as Observer<unknown>)
        observedSubjects.delete(subject)
      }
      
      // Run the update function while observer is active to track dependencies
      const result = originalUpdateFn(val)
      
      // Update observedSubjects with new ones tracked during execution
      // This happens automatically when subjects are accessed via the observer
      
      return result
    } finally {
      // Restore previous observer
      updateActiveObserver(previousObserver)
    }
  }
  
  // Execute callback once to establish dependencies
  try {
    observer.updateFn(value)
  } catch (e) {
    console.error('Initial callback execution failed:', e)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up all subscriptions
    for (const subject of observedSubjects) {
      subject.observers.delete(observer as Observer<unknown>)
    }
    observedSubjects.clear()
  }
}
