/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle the equal parameter properly
  let equalFn: EqualFn<T> | undefined
  if (equal === false) {
    // If false is passed, always notify (no equality check)
    equalFn = undefined
  } else if (typeof equal === 'function') {
    // If a function is passed, use it as equality check
    equalFn = equal
  } else if (equal === true) {
    // If true is passed, default to strict equality
    equalFn = (a, b) => a === b
  } else {
    // Default case: use strict equality
    equalFn = (a, b) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add observer to this subject's observers
      s.observers.add(observer)
      // Track this subject for cleanup in callback context
      if (observer.__observedSubjects) {
        observer.__observedSubjects.add(s as Subject<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldNotify = !s.equalFn || !s.equalFn(s.value, nextValue)
    s.value = nextValue
    if (shouldNotify && s.observers.size > 0) {
      // Create a copy of observers to avoid issues with observers being modified during notification
      const currentObservers = new Set(s.observers)
      notifyObservers(currentObservers)
    }
    return s.value
  }

  return [read, write]
}
