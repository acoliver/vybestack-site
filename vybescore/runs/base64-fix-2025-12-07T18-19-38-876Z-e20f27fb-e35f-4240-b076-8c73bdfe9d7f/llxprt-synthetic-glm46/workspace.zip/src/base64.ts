/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate input is non-empty string
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove whitespace characters that might be present
  const cleanedInput = input.replace(/\s/g, '');

  // Check if the input contains only valid Base64 characters
  // Valid Base64 characters: A-Z, a-z, 0-9, +, /, and = (for padding only at the end)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(cleanedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check if padding is valid (if present, it must be at the end)
  const paddingIndex = cleanedInput.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = cleanedInput.substring(paddingIndex);
    // Padding must be 1 or 2 '=' characters
    if (!/^(==|=)$/.test(padding)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
    // Padding must be at the end
    if (paddingIndex !== cleanedInput.length - padding.length) {
      throw new Error('Invalid Base64 input: padding not at the end');
    }
  }

  try {
    return Buffer.from(cleanedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input: failed to decode');
  }
}
