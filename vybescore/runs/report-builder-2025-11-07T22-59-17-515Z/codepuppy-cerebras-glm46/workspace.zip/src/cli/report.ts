#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { CLIOptions, ParseResult } from '../types.js';
import { parseJsonFile } from '../utils.js';
import { formatRenderers, isFormatSupported } from '../formats/index.js';

function parseArguments(args: string[]): ParseResult<CLIOptions> {
  if (args.length < 2) {
    return {
      success: false,
      error: 'Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    };
  }

  const options: CLIOptions = {
    format: 'markdown', // default, will be overridden
    includeTotals: false
  };

  // Parse arguments manually
  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg.startsWith('--')) {
      if (arg === '--format') {
        i++;
        if (i >= args.length) {
          return { success: false, error: '--format requires a value' };
        }
        const format = args[i];
        if (!isFormatSupported(format)) {
          return { success: false, error: `Unsupported format: ${format}` };
        }
        options.format = format;
      } else if (arg === '--output') {
        i++;
        if (i >= args.length) {
          return { success: false, error: '--output requires a path' };
        }
        options.output = args[i];
      } else if (arg === '--includeTotals') {
        options.includeTotals = true;
      } else {
        return { success: false, error: `Unknown option: ${arg}` };
      }
    } else {
      // This is the data file path - we only expect one
      // We don't need to store it here since we'll handle it separately
    }
    i++;
  }

  return { success: true, data: options };
}

function getDataFilePath(args: string[]): ParseResult<string> {
  // Find the first argument that doesn't start with '--'
  for (const arg of args) {
    if (!arg.startsWith('--')) {
      return { success: true, data: arg };
    }
  }
  return { success: false, error: 'Missing data file path' };
}

function main(): void {
  const args = process.argv.slice(2); // Remove node and script name

  // Parse CLI options
  const cliResult = parseArguments(args);
  if (!cliResult.success) {
    console.error('Error:', cliResult.error);
    process.exit(1);
  }
  const cliOptions = cliResult.data!;

  // Get data file path
  const fileResult = getDataFilePath(args);
  if (!fileResult.success) {
    console.error('Error:', fileResult.error);
    process.exit(1);
  }
  const dataFilePath = fileResult.data!;

  // Read and parse JSON file
  let fileContent: string;
  try {
    fileContent = readFileSync(dataFilePath, 'utf8');
  } catch (error) {
    console.error('Error reading file:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }

  // Parse and validate JSON data
  const dataResult = parseJsonFile(fileContent);
  if (!dataResult.success) {
    console.error('Error:', dataResult.error);
    process.exit(1);
  }
  const reportData = dataResult.data!;

  // Render report
  const renderer = formatRenderers[cliOptions.format];
  const output = renderer(reportData, { includeTotals: cliOptions.includeTotals });

  // Write output
  if (cliOptions.output) {
    try {
      writeFileSync(cliOptions.output, output, 'utf8');
    } catch (error) {
      console.error('Error writing output file:', error instanceof Error ? error.message : 'Unknown error');
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

// Run the CLI
main();