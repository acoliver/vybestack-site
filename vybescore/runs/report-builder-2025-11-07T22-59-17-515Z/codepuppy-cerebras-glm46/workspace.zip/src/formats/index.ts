import { ReportData, RenderOptions, FormatType } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type FormatRenderer = (data: ReportData, options: RenderOptions) => string;

export const formatRenderers: Record<FormatType, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getSupportedFormats(): FormatType[] {
  return Object.keys(formatRenderers) as FormatType[];
}

export function isFormatSupported(format: string): format is FormatType {
  return format in formatRenderers;
}