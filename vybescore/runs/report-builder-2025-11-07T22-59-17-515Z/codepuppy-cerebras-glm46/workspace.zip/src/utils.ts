import { ReportData, ReportEntry, ParseResult } from './types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function validateReportData(data: unknown): ParseResult<ReportData> {
  if (!data || typeof data !== 'object') {
    return { success: false, error: 'Invalid JSON: expected an object' };
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    return { success: false, error: 'Missing or invalid title field (expected string)' };
  }

  if (typeof obj.summary !== 'string') {
    return { success: false, error: 'Missing or invalid summary field (expected string)' };
  }

  if (!Array.isArray(obj.entries)) {
    return { success: false, error: 'Missing or invalid entries field (expected array)' };
  }

  const entries = obj.entries;
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      return { success: false, error: `Invalid entry at index ${i}: expected an object` };
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      return { success: false, error: `Invalid entry at index ${i}: missing or invalid label field (expected string)` };
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      return { success: false, error: `Invalid entry at index ${i}: missing or invalid amount field (expected number)` };
    }
  }

  return {
    success: true,
    data: {
      title: obj.title,
      summary: obj.summary,
      entries: entries.map(e => ({
        label: (e as { label: string }).label,
        amount: (e as { amount: number }).amount
      }))
    }
  };
}

export function parseJsonFile(content: string): ParseResult<ReportData> {
  try {
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    return { success: false, error: `Invalid JSON: ${error instanceof Error ? error.message : 'Unknown error'}` };
  }
}