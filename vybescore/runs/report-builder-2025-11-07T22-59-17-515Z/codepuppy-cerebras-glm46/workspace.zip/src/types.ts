export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface RenderOptions {
  includeTotals: boolean;
}

export type FormatType = 'markdown' | 'text';

export interface CLIOptions {
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

export interface ParseResult<T> {
  success: boolean;
  data?: T;
  error?: string;
}
