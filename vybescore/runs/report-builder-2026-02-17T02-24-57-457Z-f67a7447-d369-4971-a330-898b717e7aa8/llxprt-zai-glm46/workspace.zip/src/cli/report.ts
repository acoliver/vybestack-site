#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { ReportData, RenderOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  let inputFile = '';
  let format: Format = 'markdown';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatValue = args[i + 1];
      if (!formatValue) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }

      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Error: Unsupported format "${formatValue}"`);
        console.error('Supported formats: markdown, text');
        process.exit(1);
      }

      format = formatValue as Format;
      i++;
    } else if (arg === '--output') {
      const outputPathValue = args[i + 1];
      if (!outputPathValue) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }

      outputPath = outputPathValue;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: Unknown option "${arg}"`);
      process.exit(1);
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      console.error(`Error: Unexpected argument "${arg}"`);
      process.exit(1);
    }
  }

  if (!inputFile) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function loadJsonFile(filePath: string): ReportData {
  const resolvedPath = path.resolve(filePath);

  if (!fs.existsSync(resolvedPath)) {
    console.error(`Error: File not found: ${filePath}`);
    process.exit(1);
  }

  const content = fs.readFileSync(resolvedPath, 'utf-8');

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    console.error(`Error: Invalid JSON in file: ${filePath}`);
    if (error instanceof Error) {
      console.error(`  ${error.message}`);
    }
    process.exit(1);
  }

  // Validate data structure
  if (typeof data !== 'object' || data === null) {
    console.error('Error: JSON must be an object');
    process.exit(1);
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error('Error: Missing or invalid "title" field (must be a string)');
    process.exit(1);
  }

  if (typeof obj.summary !== 'string') {
    console.error('Error: Missing or invalid "summary" field (must be a string)');
    process.exit(1);
  }

  if (!Array.isArray(obj.entries)) {
    console.error('Error: Missing or invalid "entries" field (must be an array)');
    process.exit(1);
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${i} must be an object`);
      process.exit(1);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Entry at index ${i} missing or invalid "label" field (must be a string)`);
      process.exit(1);
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Entry at index ${i} missing or invalid "amount" field (must be a number)`);
      process.exit(1);
    }
  }

  return obj as unknown as ReportData;
}

function getFormatter(format: Format) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
  }
}

function main() {
  const args = process.argv.slice(2);
  const { inputFile, format, outputPath, includeTotals } = parseArguments(args);

  const data = loadJsonFile(inputFile);
  const options: RenderOptions = { includeTotals };

  const formatter = getFormatter(format);
  const output = formatter(data, options);

  if (outputPath) {
    fs.writeFileSync(outputPath, output, 'utf-8');
  } else {
    console.log(output);
  }
}

main();
