export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores,
 * and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for consecutive dots anywhere in the email
  if (value.includes('..')) return false;
  
  // Split email into local part and domain part
  const emailParts = value.split('@');
  if (emailParts.length !== 2) return false; // Must have exactly one @ symbol
  
  const [localPart, domain] = emailParts;
  
  // Validate local part
  if (!localPart || localPart.length === 0) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Validate domain part
  if (!domain || domain.length === 0) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('_')) return false; // No underscores in domain
  
  // Split domain into parts to validate TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false; // Must have at least domain and TLD
  
  // Validate TLD (last part) - must be at least 2 letters
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;
  
  // More permissive regex for email validation
  const emailRegex = /^[a-zA-Z0-9.+%-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Extract all digits from the input
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    // Only accept as country code if we have exactly 11 digits with leading 1
    if (phoneNumber.length === 11) {
      phoneNumber = phoneNumber.substring(1);
    } else {
      return false; // Too many digits even after removing country code
    }
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format with regex
  // Accepts: +1 (212) 555-7890, (212) 555-7890, 212-555-7890, 2125557890, etc.
  // Also allows spaces and periods as separators
  const phoneRegex = /^(?:\+1[\s\-\.]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))[\s\-\.]?(\d{3})[\s\-\.]?(\d{4})(?:\s*x\d+)?$/;
  
  // Additional check for extensions if enabled
  if (options?.allowExtensions) {
    const phoneWithExtRegex = /^(?:\+1[\s\-\.]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))[\s\-\.]?(\d{3})[\s\-\.]?(\d{4})(?:\s*[ext#x\.]\s*\d+)?$/;
    return phoneWithExtRegex.test(value);
  }
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles such as:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all separators (spaces, hyphens, periods) for validation
  const normalizedValue = value.replace(/[\s\.\-]/g, '');
  
  // Check if it starts with country code
  const hasCountryCode = normalizedValue.startsWith('+54');
  
  // Remove country code for processing
  let phoneNumber = hasCountryCode ? normalizedValue.substring(3) : normalizedValue;
  
  // Check for mobile indicator (9) immediately after country code or at start (if no country code)
  let isMobile = false;
  if (phoneNumber.startsWith('9')) {
    isMobile = true;
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check for trunk prefix (0)
  let hasTrunkPrefix = false;
  if (phoneNumber.startsWith('0')) {
    hasTrunkPrefix = true;
    phoneNumber = phoneNumber.substring(1);
  }
  
  // When country code is omitted, must begin with trunk prefix 0
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // After processing all prefixes, we should have area code + subscriber number
  const digitsOnly = phoneNumber;
  
  // Total length should be enough for area code (2-4 digits) + subscriber number (6-8 digits)
  if (digitsOnly.length < 8 || digitsOnly.length > 12) return false;
  
  // Extract area code (2-4 digits, first digit 1-9)
  let areaCodeLength = 2; // Start with minimum
  
  // Try to determine area code length based on total remaining digits
  // Subscriber number must be 6-8 digits
  for (let len = 2; len <= 4; len++) {
    const subscriberLength = digitsOnly.length - len;
    if (subscriberLength >= 6 && subscriberLength <= 8) {
      areaCodeLength = len;
      break;
    }
  }
  
  const areaCode = digitsOnly.substring(0, areaCodeLength);
  const subscriberNumber = digitsOnly.substring(areaCodeLength);
  
  // Area code validation
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (!/^[1-9]/.test(areaCode)) return false; // First digit must be 1-9
  
  // Subscriber number validation
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  if (!/^\d+$/.test(subscriberNumber)) return false; // Must be all digits
  
  return true;
}

/**
 * Validates names with unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Name should not be empty after trimming
  if (value.trim().length === 0) return false;
  
  // Reject names with only special characters or multiple consecutive spaces
  if (/^[^\w\s]+$/.test(value)) return false;
  
  // Allow Unicode letters (with accents), apostrophes, hyphens, and spaces
  // \p{L} matches any kind of letter from any language
  // \p{M} matches combining marks (accents)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Reject digits anywhere in the name
  if (/\d/.test(value)) return false;
  
  // Reject special characters and emojis except apostrophe, hyphen, and space
  const specialCharRegex = /[^\p{L}\p{M}'\-\s]/u;
  if (specialCharRegex.test(value)) return false;
  
  // Reject multiple consecutive non-letter characters
  if (/['\-]{2,}/.test(value)) return false;
  
  // Reject names consisting only of spaces or with leading/trailing spaces after trim
  if (value !== value.trim()) return false;
  
  return nameRegex.test(value);
}

/**
 * Luhn algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Checks prefixes, lengths, and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check basic length - most cards are 13-19 digits
  if (cardNumber.length < 13 || cardNumber.length > 19) return false;
  
  // Luhn checksum check
  if (!runLuhnCheck(cardNumber)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55, 2221-2720, length 16
  const mcRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  return visaRegex.test(cardNumber) || mcRegex.test(cardNumber) || amexRegex.test(cardNumber);
}