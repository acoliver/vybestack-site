/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Convert exceptions to a Set for efficient lookup
  const exceptionSet = new Set(exceptions);
  
  // Create regex pattern to find words starting with the prefix
  // \b ensures we match whole words only
  const wordBoundary = '\\b';
  const prefixPattern = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'); // Escape special regex chars
  const wordPattern = `${wordBoundary}${prefixPattern}[a-zA-Z]*`;
  const regex = new RegExp(wordPattern, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions and ensure unique results
  const uniqueWords = new Set<string>();
  matches.forEach(word => {
    const lowercaseWord = word.toLowerCase();
    if (!exceptionSet.has(lowercaseWord) && !exceptionSet.has(word)) {
      uniqueWords.add(word);
    }
  });
  
  return Array.from(uniqueWords);
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to find digit+token combinations
  // We'll match the digit+token and then extract the full match
  const pattern = `\\d${escapedToken}`;
  const regex = new RegExp(pattern, 'g');
  
  const matches = text.match(regex) || [];
  
  // Ensure unique results
  const uniqueTokens = new Set(matches);
  
  return Array.from(uniqueTokens);
}

/**
 * Validates passwords according to strong password policies.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace,
 * and no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212, xyxy)
  // Look for any 2-character pattern that repeats immediately
  const repeatedPattern = /(..)\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Check for longer repeated patterns (e.g., abcabc)
  const longerRepeatedPattern = /(...)\1/;
  if (longerRepeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation with ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns (including shorthand with ::)
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // Compressed IPv6: may contain :: for consecutive zero groups
  // IPv4-mapped IPv6: may contain IPv4 at the end
  const ipv6Patterns = [
    // Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    
    // Compressed IPv6 with :: in various positions
    // :: at start
    /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/,
    // :: in middle
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/,
    // :: at end
    /(?:[0-9a-fA-F]{1,4}:){1,7}::/,
    // :: anywhere
    /(?:[0-9a-fA-F]{1,4}:)::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/,
    
    // IPv4-mapped IPv6: ...:ipv4
    /(?:[0-9a-fA-F]{1,4}:){5,7}[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/,
    // ::ffff:ipv4
    /::ffff:(?:[0-9]{1,3}\.){3}[0-9]{1,3}/
  ];
  
  // Check if any IPv6 pattern matches
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}