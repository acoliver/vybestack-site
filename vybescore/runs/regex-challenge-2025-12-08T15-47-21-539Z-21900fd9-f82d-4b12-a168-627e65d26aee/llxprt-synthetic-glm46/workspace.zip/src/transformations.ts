/**
 * Capitalizes the first character of each sentence after .?! punctuation marks.
 * Inserts exactly one space between sentences even if the input omitted it.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Step 1: Normalize spacing around punctuation
  // Add space after punctuation if missing, but handle common abbreviations
  const abbreviations = ['Mr', 'Mrs', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K'];
  const abbrevPattern = new RegExp(`\\b(${abbreviations.join('|')})\\. `, 'gi');
  
  // First, add spaces after punctuation if they don't exist
  let normalized = text.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  // Handle abbreviations by temporarily replacing them
  const abbrevMarkers: string[] = [];
  let markerIndex = 0;
  normalized = normalized.replace(abbrevPattern, (match) => {
    const marker = `__ABBREV_${markerIndex++}__`;
    abbrevMarkers.push(match);
    return marker;
  });
  
  // Step 2: Collapse multiple spaces into single space
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Step 3: Trim leading and trailing spaces
  normalized = normalized.trim();
  
  // Step 4: Capitalize first character of each sentence
  const sentences = normalized.split(/([.!?]\s*)/);
  let result = '';
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // Restore abbreviation markers
    let restoredPart = part;
    abbrevMarkers.forEach((abbrev, index) => {
      restoredPart = restoredPart.replace(`__ABBREV_${index}__`, abbrev);
    });
    
    // If this is text that starts a sentence and has letters, capitalize it
    if (i === 0 || (i > 0 && /[.!?]\s*/.test(sentences[i-1]))) {
      if (restoredPart.length > 0) {
        // Find first letter and capitalize it
        restoredPart = restoredPart.replace(/([a-zA-Z])/, (match) => match.toUpperCase());
      }
    }
    
    result += restoredPart;
  }
  
  return result;
}

/**
 * Finds all URLs in the text and returns them as an array without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https, www, and domain-only URLs
  const urlRegex = /(https?:\/\/|www\.)[^\s<">]+/gi;
  
  const rawMatches = text.match(urlRegex) || [];
  
  // Clean up each URL to remove trailing punctuation
  return rawMatches.map(url => {
// Remove trailing punctuation that would not be part of a URL
// eslint-disable-next-line no-useless-escape
    return url.replace(/[.,!?;:)\}>]+$/, '');
  });
}

/**
 * Forces all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Find all http:// URLs that don't already have https://
  // Use negative lookbehind to ensure we don't replace https://
  return text.replace(/(?<!https:)http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * 
 * Rules:
 * - Always upgrade the scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com 
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, or legacy extensions)
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match URLs with example.com domain
  const urlRegex = /(https:\/\/)(example\.com)(\/[^\s]*)/g;
  
  result = result.replace(urlRegex, (match, protocol, domain, path) => {
    // Check if path starts with /docs/
    const docsPathPattern = /^\/docs\//;
    
    // Check if we should skip host rewrite
    const skipHostRewritePattern = /(\/cgi-bin|\?(.*)|&(.*)|=.*|\/.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/;
    
    // If path starts with /docs/ and doesn't contain skip patterns, rewrite host
    if (docsPathPattern.test(path) && !skipHostRewritePattern.test(path)) {
      return `${protocol}docs.${domain}${path}`;
    }
    
    // Otherwise, just return the URL with upgraded https
    return match;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const year = match[3];
  
  // Validate month/day combination (basic validation)
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Days in month validation
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  if (isLeapYear && month === 2) {
    if (day > 29) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}