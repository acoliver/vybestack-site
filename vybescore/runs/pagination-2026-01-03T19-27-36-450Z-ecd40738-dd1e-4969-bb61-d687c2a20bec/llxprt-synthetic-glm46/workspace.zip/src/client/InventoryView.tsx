import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  hasNext, 
  onPageChange 
}: { 
  page: number; 
  hasNext: boolean; 
  onPageChange: (page: number) => void;
}): JSX.Element {
  const onPrevious = (): void => onPageChange(page - 1);
  const onNext = (): void => onPageChange(page + 1);

  return (
    <div className="pagination-controls">
      <button 
        onClick={onPrevious}
        disabled={page <= 1}
        aria-label="Previous page"
      >
        Previous
      </button>
      <span className="page-info">Page {page}</span>
      <button 
        onClick={onNext}
        disabled={!hasNext}
        aria-label="Next page"
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState<number>(1);
  
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePageChange = (newPage: number): void => {
    setCurrentPage(newPage);
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const { items, page, hasNext, total } = data;

  return (
    <section>
      <h1>Inventory</h1>
      {items.length === 0 ? (
        <p>No items found.</p>
      ) : (
        <>
          <InventoryList items={items} />
          <PaginationControls 
            page={page} 
            hasNext={hasNext} 
            onPageChange={handlePageChange} 
          />
          <div className="pagination-info">Total items: {total}</div>
        </>
      )}
    </section>
  );
}
