const text = 'xfoo 1foo foo';
const token = 'foo';
const match = text.match(/\d(foo)/);
console.log('match:', match);
if (match) console.log('result:', match[0]);
