/**
 * Capitalizes the first character of each sentence.
 * Handles sentence boundaries with .?! and ensures proper spacing between sentences.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces into a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure space after sentence-ending punctuation if needed
  result = result.replace(/([.!?])(?=[^\s])/g, '$1 ');
  
  // Capitalize first character of each sentence
  // Use regex to find first letter after start or sentence-ending punctuation
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result.trim();
}

/**
 * Extracts URLs from text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with common protocols
  // Supports http, https, ftp, etc.
  // Does not include trailing punctuation like .,!?;:)]}"'
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  
  const urls = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,!?;:)\]\}"']+$/g, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Converts all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs starting with http://example.com/ to HTTPS format.
 * Transforms docs paths to use docs.example.com host while preserving other URLs.
 */
export function rewriteDocsUrls(text: string): string {
  // First, convert all http://example.com URLs to https://
  let result = text.replace(/http:\/\/example\.com\//g, 'https://example.com/');
  
  // Then handle docs path transformation
  // Only transform /docs/ paths if they don't contain dynamic hints
  result = result.replace(
    /(https:\/\/example\.com)(\/docs\/[^\s?]*)(?![?&=\.\w]*[\/](?:cgi-bin|[.|jsp|php|asp|aspx|do|cgi|pl|py]$))/g,
    'https://docs.example.com$2'
  );
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' if the format is invalid or dates are impossible.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Basic validation of months and days - enhanced for February, etc.
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for valid days per month (simple check, doesn't account for leap years)
  const validDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (dayNum > validDays[monthNum - 1]) {
    // Special case for February: check leap year
    if (monthNum === 2 && dayNum === 29) {
      const yearNum = parseInt(year, 10);
      const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
      if (!isLeapYear) {
        return 'N/A';
      }
    } else {
      return 'N/A';
    }
  }
  
  return year;
}