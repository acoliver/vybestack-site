export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implements email validation supporting typical addresses.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex with proper validation:
  // - Local part: letters, digits, plus signs, hyphens, periods (not consecutive or at ends)
  // - Domain: letters, digits, hyphens (no underscores), periods
  // - TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9.+%-]+@[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*([.][a-zA-Z0-9][a-zA-Z0-9-]*)*[.][a-zA-Z]{2,}$/;
  
  // Quick format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // More detailed validation
  const [localPart, domain] = value.split('@');
  
  // No double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // No leading or trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // No underscore in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain shouldn't start or end with a hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Implements US phone number validation supporting common formats and optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  let cleaned = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (US number) or 11 digits (with country code)
  if (cleaned.length < 10 || cleaned.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (US country code)
  if (cleaned.length === 11) {
    if (!cleaned.startsWith('1')) {
      return false;
    }
    // Remove the country code for further validation
    cleaned = cleaned.slice(1);
  }
  
  // Extract area code (first 3 digits)
  const areaCode = cleaned.substring(0, 3);
  
  // Area code can't start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Accept various formats: (212) 555-7890, 212-555-7890, 2125557890, etc.
  const phoneRegex = /^(?:\+1[\s\-]*)*\(?[2-9]\d{2}\)?[\s\-]*[2-9]\d{2}[\s\-]*\d{4}$/;
  
  // Check extensions if allowed
  if (options?.allowExtensions) {
    const phoneWithExtRegex = /^(?:\+1[\s\-]*)*\(?[2-9]\d{2}\)?[\s\-]*[2-9]\d{2}[\s\-]*\d{4}[\s]*x[\s]*\d+$/;
    return phoneRegex.test(value) || phoneWithExtRegex.test(value);
  }
  
  return phoneRegex.test(value);
}

/**
 * Implements Argentine phone number validation covering mobile and landline formats.
 * Handles country code, trunk prefix, mobile indicator, and proper area codes.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Regex pattern for Argentine phone numbers:
  // Optional +54 country code
  // Optional 0 trunk prefix
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?0?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, areaCode, subscriber] = match;
  
  // If country code is omitted, must begin with trunk prefix 0
  if (!countryCode && !cleaned.startsWith('0')) {
    return false;
  }
  
  // Area code validation (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number validation (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and other invalid name patterns.
 */
export function isValidName(value: string): boolean {
  // Regex for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes, hyphens, spaces
  // - At least one character required
  // - No digits or other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  return nameRegex.test(value) && /\p{L}/u.test(value);
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx.
 * Checks prefix and length, and runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Must be numeric
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-9]\d)\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the number matches any supported card format
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn algorithm validation on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Loop through digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
