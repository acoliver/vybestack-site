/**
 * Finds words beginning with the specified prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with prefix
  const prefixPattern = new RegExp(`\\b(${prefix}[a-zA-Z]*)\\b`, 'g');
  
  const words: string[] = [];
  let match;
  
  while ((match = prefixPattern.exec(text)) !== null) {
    const word = match[1];
    
    // Skip if word is in exceptions
    if (!exceptions.includes(word)) {
      // Avoid duplicates
      if (!words.includes(word)) {
        words.push(word);
      }
    }
  }
  
  return words;
}

/**
 * Finds occurrences of a token that appear after a digit and not at string start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find tokens preceded by a digit, excluding at string start
  const results = [];
  
  // Split text into words and check each
  const words = text.split(/\s+/);

  for (const word of words) {
    // Check if the word contains digit+token pattern
    const pattern = new RegExp(`(\\d${token})`);
    const wordMatch = word.match(pattern);
    if (wordMatch) {
      const tokenMatch = wordMatch[1];
      
      // Find the position of word in the original text
      const wordIndex = text.indexOf(word);
      
      // Check if token is at the start of the word and word is not at string start
      const tokenStartInWord = word.indexOf(tokenMatch);
      
      if (tokenStartInWord === 0 && wordIndex > 0) {
        // Word starts with digit+token and word is not at start of text
        results.push(tokenMatch);
      } else if (tokenStartInWord > 0) {
        // Token is embedded within word
        results.push(tokenMatch);
      }
    }
  }

  return results;
}

/**
 * Validates password strength according to specified policy.
 */
export function isStrongPassword(value: string): boolean {
  // Requirements:
  // - At least 10 characters
  // - At least one uppercase letter
  // - At least one lowercase letter
  // - At least one digit
  // - At least one symbol (non-alphanumeric)
  // - No whitespace
  // - No immediate repeated sequences (e.g., abab)
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!(hasUppercase && hasLowercase && hasDigit && hasSymbol)) {
    return false;
  }
  
  // Check for repeated sequences of length 2-3 characters
  // Pattern to detect XYXY, XYXYXY, etc.
  const repeatedPattern = /(.{2,3})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  // Full IPv6 with 8 groups of 1-4 hex digits: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // Compressed IPv6 with :: shorthand: 2001:db8::1
  // IPv6 with embedded IPv4: ::ffff:192.168.0.1
  
  const ipv6Patterns = [
    // Full IPv6 notation (8 groups of 1-4 hex digits)
    /(?<!\d(?:\d{1,3}\.){3})\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b(?!\.\d)/,
    // Compressed notation with ::
    /(?<!\d(?:\d{1,3}\.){3})\b((?:[0-9a-fA-F]{1,4}(?::|$)){0,7})(?::|[0-9a-fA-F]{1,4}){1,8}\b(?!\.\d)/,
    // Border case: just :: (loopback)
    /(?<!\d(?:\d{1,3}\.){3})\b::\b(?!\.\d)/,
    // IPv6 with IPv4 embedded (special case, handle separately)
    /(?<!\d(?:\d{1,3}\.){3})\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];
  
  // Check for IPv4 pattern first to exclude matches
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // If there's an IPv4 pattern, explicitly check if it's part of an IPv6 address
    // This handles cases like ::ffff:192.168.0.1 which should count as IPv6
    const ipv4EmbeddedInIPv6 = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}/;
    return ipv4EmbeddedInIPv6.test(value);
  }
  
  // Check for IPv6 patterns
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
