const text = 'Visit http://example.com today';
const simpleRegex = /(https?:\/\/[^\s]+)/g;
console.log(text.match(simpleRegex));
