/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const wordPattern = new RegExp(`\\b${escapeRegex(prefix)}\\w+\\b`, 'gi');
  const words = text.match(wordPattern) || [];
  
  const uniqueWords = [...new Set(words.map(w => w.toLowerCase()))];
  
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return uniqueWords.filter(word => !exceptionSet.has(word));
}

function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Find occurrences of a token only when it appears immediately after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = escapeRegex(token);
  // Match digit immediately followed by token, using word boundary
  const pattern = new RegExp(`\\b\\d${escapedToken}\\b`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = pattern.exec(text)) !== null) {
    // Ensure match is not at the start of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy.
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (value.length < 10) {
    return false;
  }
  
  if (/\s/.test(value)) {
    return false;
  }
  
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[{};':"|,.<>/?]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  for (let i = 0; i < value.length - 2; i++) {
    const seq1 = value.substring(i, i + 2);
    const seq2 = value.substring(i + 2, i + 4);
    
    if (seq1 === seq2) {
      return false;
    }
  }
  
  for (let i = 0; i < value.length - 3; i++) {
    const seq1 = value.substring(i, i + 3);
    const seq2 = value.substring(i + 3, i + 6);
    
    if (seq1 === seq2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  const ipv4Pattern = /(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  const ipv6DoubleColonPattern = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*/;
  const ipv6MixedPattern = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  const hasIPv6 = ipv6FullPattern.test(value) || ipv6DoubleColonPattern.test(value) || ipv6MixedPattern.test(value);
  
  const hasIPv4 = ipv4Pattern.test(value);
  
  return hasIPv6 && !hasIPv4;
}
