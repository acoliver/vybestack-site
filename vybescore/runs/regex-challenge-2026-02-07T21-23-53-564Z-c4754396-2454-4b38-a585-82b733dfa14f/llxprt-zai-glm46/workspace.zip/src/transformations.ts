/**
 * Capitalize the first character of each sentence.
 * Capitalizes after `.?!`, inserts exactly one space between sentences,
 * collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  let result = text;
  
  // Collapse multiple spaces to single space
  result = result.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence terminators
  result = result.replace(/([.!?])\s*/g, '$1 ');
  
  // Capitalize first character of the string
  result = result.replace(/^([a-z])/, (match) => match.toUpperCase());
  
  // Capitalize first letter after sentence terminators
  result = result.replace(/([.!?]\s+)([a-z])/g, (_, p1, p2) => p1 + p2.toUpperCase());
  
  return result.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlPattern = /(https?:\/\/[^\s<>"()[\]{}]+(?:\/[^\s<>"()[\]{}]*)?)/gi;
  
  const urls = text.match(urlPattern) || [];
  
  return urls.map(url => url.replace(/[.,;:!?)\]}>]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/(https?:\/\/)/gi, '$1').replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for cgi-bin, query strings, or legacy extensions
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Match URLs with scheme, host, and optional path
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    const newScheme = 'https://';
    
    if (!path.startsWith('/docs/')) {
      return newScheme + host + path;
    }
    
    const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasQueryString = /[?&=]/.test(path);
    const hasCgiBin = path.includes('/cgi-bin') || path.includes('/cgi-bin/');
    const hasLegacyExtension = legacyExtensions.some(ext => path.includes(ext));
    
    if (hasQueryString || hasCgiBin || hasLegacyExtension) {
      return newScheme + host + path;
    }
    
    const newHost = host === 'example.com' ? 'docs.example.com' : host.replace(/^www\./, 'docs.');
    
    return newScheme + newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
