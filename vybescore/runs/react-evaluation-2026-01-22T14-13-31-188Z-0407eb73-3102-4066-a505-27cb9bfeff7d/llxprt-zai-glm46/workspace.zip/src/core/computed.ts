/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

interface ComputedObserver<T> extends Observer<T> {
  dependents: Set<ObserverR>
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Store dependents set first
  const dependents: Set<ObserverR> = new Set()
  
  const o: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents,
    notify: function() {
      // Re-compute when dependencies notify this observer
      // Then notify any observers that depend on this computed
      updateObserver(this)
      // Notify dependent observers (if any)
      dependents.forEach((dep: ObserverR) => dep.notify())
    }
  }
  
  // Initial computation
  updateObserver(o)
  
  // Return getter that tracks dependencies
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of the active observer
      // Store the observer reference so it can be notified when this computed changes
      if (!dependents.has(observer)) {
        dependents.add(observer)
      }
    }
    return o.value!
  }
}
