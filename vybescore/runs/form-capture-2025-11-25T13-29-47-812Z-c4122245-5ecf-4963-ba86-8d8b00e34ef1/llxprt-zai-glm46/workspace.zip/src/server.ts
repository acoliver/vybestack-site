// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';

interface Database {
  run(sql: string, ...params: unknown[]): unknown;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): unknown;
  free(): void;
}

interface SqlJsModule {
  Database: new (data?: Uint8Array) => Database;
}

import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';


const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

let db: Database;

async function initializeDatabase() {
  try {
    const SQL: SqlJsModule = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });
    
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
      
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase() {
  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

interface FormData {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function validateSubmission(data: FormData) {
  const errors: Record<string, string> = {};
  
  if (!data.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }
  
  if (!data.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }
  
  if (!data.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!data.postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^[+]?\d[\d\s\-()]*$/.test(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  return errors;
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

app.get('/', (req, res) => {
  res.render('form', {
    errors: {},
    formData: {}
  });
});

app.post('/submit', (req, res) => {
  const errors = validateSubmission(req.body);
  
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData: req.body
    });
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      req.body.first_name.trim(),
      req.body.last_name.trim(),
      req.body.street_address.trim(),
      req.body.city.trim(),
      req.body.state_province.trim(),
      req.body.postal_code.trim(),
      req.body.country.trim(),
      req.body.email.trim(),
      req.body.phone.trim()
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      formData: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

async function startServer() {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to see the form`);
  });
}

// Only start server if this file is run directly and not in test environment
if (import.meta.url === `file://${process.argv[1]}` && process.env.NODE_ENV !== 'test') {
  startServer();
}

// Export app for testing
export { app };