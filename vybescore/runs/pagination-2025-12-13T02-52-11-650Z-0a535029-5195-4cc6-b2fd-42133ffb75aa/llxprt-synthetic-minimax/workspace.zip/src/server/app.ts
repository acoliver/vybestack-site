import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Convert query parameters to numbers with validation
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (!Number.isFinite(parsedPage) || !Number.isInteger(parsedPage)) {
        return res.status(400).json({ error: 'Page must be a valid integer' });
      }
      page = parsedPage;
    }

    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (!Number.isFinite(parsedLimit) || !Number.isInteger(parsedLimit)) {
        return res.status(400).json({ error: 'Limit must be a valid integer' });
      }
      limit = parsedLimit;
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(400).json({ error: error instanceof Error ? error.message : 'Invalid pagination parameters' });
    }
  });

  return app;
}
