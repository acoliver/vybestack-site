// Simple test to understand the reactive system
import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing basic reactive system...');

// Test 1: Basic input
console.log('\nTest 1: Basic input');
const [getValue, setValue] = createInput(1);
console.log('Initial value:', getValue());
setValue(2);
console.log('After set to 2:', getValue());

// Test 2: Computed value
console.log('\nTest 2: Computed value');
const [input, setInput] = createInput(5);
const double = createComputed(() => input() * 2);
console.log('Initial computed:', double());
setInput(10);
console.log('After input set to 10:', double());

// Test 3: Callback
console.log('\nTest 3: Callback');
const [callbackInput, setCallbackInput] = createInput(1);
let callbackValue = 0;
const unsubscribe = createCallback(() => {
  callbackValue = callbackInput() * 3;
});
console.log('Initial callback value:', callbackValue);
setCallbackInput(4);
console.log('After input set to 4:', callbackValue);
unsubscribe();
setCallbackInput(10);
console.log('After unsubscribe and set to 10:', callbackValue);

// Test 4: Comprehensive test like in failing test
console.log('\nTest 4: Comprehensive test');
const [testInput, setTestInput] = createInput(1);
const timesTwo = createComputed(() => testInput() * 2);
const timesThirty = createComputed(() => testInput() * 30);
const sum = createComputed(() => timesTwo() + timesThirty());
console.log('Initial sum:', sum());
setTestInput(3);
console.log('Sum after input set to 3:', sum());

console.log('\nDone!');