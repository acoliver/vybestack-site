// Test to match the exact failing test cases
import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing comprehensive reactive system...');

// Test 1: compute cells can depend on other compute cells
console.log('\nTest 1: compute cells can depend on other compute cells');
const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => input() * 2);
const timesThirty = createComputed(() => input() * 30);
const sum = createComputed(() => timesTwo() + timesThirty());

console.log('Initial sum should be 32:', sum());
console.log('Actual sum:', sum());
setInput(3);
console.log('After setInput(3), sum should be 96:', sum());
console.log('Actual sum:', sum());

// Test 2: compute cells fire callbacks
console.log('\nTest 2: compute cells fire callbacks');
const [input2, setInput2] = createInput(1);
const output = createComputed(() => input2() + 1);
let value = 0;
createCallback(() => (value = output()));
console.log('Initial callback value should be 2:', value);
console.log('Actual callback value:', value);
setInput2(3);
console.log('After setInput2(3), value should be 4:', value);
console.log('Actual callback value:', value);

// Test 3: callbacks can be added and removed
console.log('\nTest 3: callbacks can be added and removed');
const [input3, setInput3] = createInput(11);
const output3 = createComputed(() => input3() + 1);

const values1: number[] = [];
const unsubscribe1 = createCallback(() => values1.push(output3()));
const values2: number[] = [];
createCallback(() => values2.push(output3()));

console.log('Before first change - values1 length:', values1.length);
console.log('Before first change - values2 length:', values2.length);

setInput3(31);
console.log('After setInput3(31) - values1 length should be > 0:', values1.length);
console.log('After setInput3(31) - values1:', values1);
console.log('After setInput3(31) - values2 length should be > 0:', values2.length);
console.log('After setInput3(31) - values2:', values2);

unsubscribe1();
setInput3(41);

console.log('After unsubscribe and setInput3(41) - values1 length should be unchanged:', values1.length);
console.log('After unsubscribe and setInput3(41) - values1:', values1);
console.log('After unsubscribe and setInput3(41) - values2 length should be > values1 length:', values2.length);
console.log('After unsubscribe and setInput3(41) - values2:', values2);

console.log('\nDone!');