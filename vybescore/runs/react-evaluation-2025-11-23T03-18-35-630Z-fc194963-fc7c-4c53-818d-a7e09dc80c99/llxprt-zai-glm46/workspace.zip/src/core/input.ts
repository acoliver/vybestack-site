/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  GetterFn,
  SetterFn,
  Options,
  registerDependency
} from '../types/reactive.js'

function createDefaultEqualFn<T>(): (lhs: T, rhs: T) => boolean {
  return (a: T, b: T): boolean => a === b
}

function normalizeEqualFn<T>(equal?: boolean | ((lhs: T, rhs: T) => boolean)): ((lhs: T, rhs: T) => boolean) | undefined {
  if (equal === true) return createDefaultEqualFn<T>()
  if (equal === false || equal === undefined) return undefined
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: Options
): InputPair<T> {
  const equalFn = normalizeEqualFn(_equal)
  
  // Create a representative observer for this input
  const inputObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => value
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(observer, inputObserver as Observer<unknown>)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      // Update the input observer's value
      inputObserver.value = s.value
      // Trigger updates for all dependent observers
      if (s.observer) {
        updateObserver(s.observer as Observer<T>)
      }
    }
    return s.value
  }

  return [read, write]
}