/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Options,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

function createDefaultEqualFn<T>(): EqualFn<T> {
  return (a: T, b: T): boolean => a === b
}

function normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === true) return createDefaultEqualFn<T>()
  if (equal === false || equal === undefined) return undefined
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const equalFn = normalizeEqualFn(_equal)
  
  // Initial computation to establish dependencies and get initial value
  const compute = (): T => {
    const prevObserver = getActiveObserver()
    // Set this computed as the active observer to track dependencies
    // @ts-ignore - We need to set the active observer internally
    globalThis.activeObserver = o
    
    try {
      const newValue = updateFn(value)
      
      // Update value if it has changed
      if (value === undefined || !equalFn || !equalFn(value, newValue)) {
        value = newValue
        o.value = value
      }
      
      return value
    } finally {
      // Restore previous active observer
      // @ts-ignore
      globalThis.activeObserver = prevObserver
    }
  }
  
  return compute
}