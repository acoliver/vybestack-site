/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, unregisterAllDependencies } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Perform initial execution to establish dependencies
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove all dependencies for this observer
    unregisterAllDependencies(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}