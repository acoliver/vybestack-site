/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observer?: ObserverR | undefined
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Global registry for dependency tracking
const dependencyRegistry = new Map<ObserverR, Set<Observer<unknown>>>()
const reverseDependencyRegistry = new Map<Observer<unknown>, Set<ObserverR>>()

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    
    // Get all observers that depend on this observer
    const dependents = reverseDependencyRegistry.get(observer as Observer<unknown>)
    if (dependents) {
      // Create a copy to avoid issues with Set modification during iteration
      const dependentsArray = Array.from(dependents)
      for (const dependent of dependentsArray) {
        // Check if the dependent is still valid
        if (dependencyRegistry.has(dependent)) {
          updateObserver(dependent as Observer<unknown>)
        }
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function registerDependency(observer: ObserverR, dependency: Observer<unknown>): void {
  // Record that observer depends on dependency
  if (!dependencyRegistry.has(observer)) {
    dependencyRegistry.set(observer, new Set())
  }
  dependencyRegistry.get(observer)!.add(dependency)
  
  // Record reverse mapping for efficient updates
  if (!reverseDependencyRegistry.has(dependency)) {
    reverseDependencyRegistry.set(dependency, new Set())
  }
  reverseDependencyRegistry.get(dependency)!.add(observer)
}

export function unregisterAllDependencies(observer: ObserverR): void {
  // Remove all dependencies for this observer
  const dependencies = dependencyRegistry.get(observer)
  if (dependencies) {
    for (const dependency of dependencies) {
      const dependents = reverseDependencyRegistry.get(dependency)
      if (dependents) {
        dependents.delete(observer)
        if (dependents.size === 0) {
          reverseDependencyRegistry.delete(dependency)
        }
      }
    }
    dependencyRegistry.delete(observer)
  }
}