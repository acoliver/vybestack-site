import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';

let db: Database | null = null;

export default async function initDatabase(): Promise<Database> {
  try {
    // Initialize sql.js
    const SQL = await initSqlJs();
    
    // Read existing database or create new one
    const dbPath = 'data/submissions.sqlite';
    let dbData: Uint8Array;
    
    try {
      const exists = await fs.access(dbPath).then(() => true).catch(() => false);
      if (exists) {
        const data = await fs.readFile(dbPath);
        dbData = new Uint8Array(data);
      } else {
        // Create data directory if it doesn't exist
        await fs.mkdir('data', { recursive: true });
        dbData = new Uint8Array(); // Empty array for new database
      }
    } catch (error) {
      // Create data directory if it doesn't exist
      await fs.mkdir('data', { recursive: true });
      dbData = new Uint8Array();
    }
    
    // Create database instance
    db = new SQL.Database(dbData);
    
    // Run schema initialization
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    
    db.exec(schema);
    
    return db;
  } catch (error) {
    console.error('Database initialization failed:', error);
    throw error;
  }
}

export function getDatabase(): Database | null {
  return db;
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}