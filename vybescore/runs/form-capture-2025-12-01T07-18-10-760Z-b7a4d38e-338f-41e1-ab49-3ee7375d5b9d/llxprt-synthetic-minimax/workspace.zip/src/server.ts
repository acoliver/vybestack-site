import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { Database } from 'sql.js';
import initDatabase from './database.js';
import { validateFormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Initialize database
let db: Database | null = null;

async function startServer() {
  try {
    db = await initDatabase();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../dist/public')));

// View engine setup
app.set('views', path.join(__dirname, '../dist/templates'));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req: express.Request, res: express.Response) => {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      formData,
      title: 'Contact Form - Please Fix Errors'
    });
  }

  try {
    // Insert into database
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Export database to persist changes
    const data = db.export();
    const fs = await import('fs/promises');
    await fs.writeFile('data/submissions.sqlite', Buffer.from(data));
    
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      formData,
      title: 'Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you', { title: 'Thank You!' });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  if (db !== null) {
    await db.close();
  }
  process.exit(0);
});

startServer();