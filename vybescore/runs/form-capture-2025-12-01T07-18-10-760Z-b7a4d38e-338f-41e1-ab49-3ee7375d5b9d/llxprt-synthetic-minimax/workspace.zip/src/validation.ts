export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export function validateFormData(formData: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  if (!formData.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!formData.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!formData.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!formData.city.trim()) {
    errors.city = 'City is required';
  }

  if (!formData.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!formData.postalCode.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!formData.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!formData.email.trim()) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (accepts alphanumeric strings)
  if (formData.postalCode && !isValidPostalCode(formData.postalCode)) {
    errors.postalCode = 'Please enter a valid postal/zip code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidEmail(email: string): boolean {
  // Simple email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Phone number validation - allows digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Accepts alphanumeric postal codes (handles UK "SW1A 1AA" and other formats)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode) && postalCode.length >= 3;
}