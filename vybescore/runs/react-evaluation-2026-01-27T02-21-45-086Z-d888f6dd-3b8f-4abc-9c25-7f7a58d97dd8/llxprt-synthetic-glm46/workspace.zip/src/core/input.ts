/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  GetterFn,
  SetterFn,
  Options,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: Options
): InputPair<T> {
  let currentValue = value
  const listeners = new Set<() => void>()
  const dependentComputeds = new Set<() => void>()
  
  const read: GetterFn<T> = () => {
    // Register this input as a dependency for the current active observer
    const observer = getActiveObserver()
    if (observer && observer.updateFn) {
      // Add this observer as a listener to input changes
      listeners.add(() => {
        // When input changes, trigger observer update
        observer.updateFn(currentValue)
      })
      
      // Check if this is a computed value (has notifyListeners method)
      if ((observer.updateFn as any).notifyListeners) {
        dependentComputeds.add((observer.updateFn as any).notifyListeners)
      }
    }
    return currentValue
  }

  const write: SetterFn<T> = (nextValue) => {
    if (currentValue === nextValue) return nextValue // Skip if no change
    
    currentValue = nextValue
    
    // Notify all listeners about the value change
    for (const listener of listeners) {
      try {
        listener()
      } catch (error) {
        console.error('Input notification error:', error)
      }
    }
    
    // Notify all dependent computed values to recompute
    for (const recompute of dependentComputeds) {
      try {
        recompute()
      } catch (error) {
        console.error('Computed recompute notification error:', error)
      }
    }
    
    return currentValue
  }

  return [read, write]
}
