/**
 * Callback closure implementation for reactive side effects.
 */
import { getActiveObserver } from '../types/reactive.js';
/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback(updateFn, value) {
    let disposed = false;
    const callback = () => {
        if (disposed)
            return;
        try {
            const result = updateFn(value);
        }
        catch (error) {
            console.error('Callback execution error:', error);
        }
    };
    // Register this callback for dependency tracking
    const observer = getActiveObserver();
    // Register callback with current active observer (computed value)
    if (observer && observer.updateFn) {
        // Add callback as listener to the computed value
        const listeners = observer.listeners || new Set();
        listeners.add(callback);
        observer.listeners = listeners;
    }
    // Execute immediately to establish dependencies
    callback();
    // Return unsubscribe function
    return () => {
        if (disposed)
            return;
        disposed = true;
        // Remove callback from listeners
        if (observer && observer.updateFn) {
            const listeners = observer.listeners;
            if (listeners && listeners.has(callback)) {
                listeners.delete(callback);
            }
        }
    };
}
