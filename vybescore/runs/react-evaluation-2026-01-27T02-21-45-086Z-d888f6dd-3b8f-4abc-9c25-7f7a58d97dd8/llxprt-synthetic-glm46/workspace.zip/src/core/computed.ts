/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  let currentValue = value
  const listeners = new Set<() => void>()
  const dependentComputeds = new Set<() => void>()
  
  const getter: GetterFn<T> = () => {
    // If being accessed by an active observer, register this computed as a dependency
    const observer = getActiveObserver()
    if (observer && observer.updateFn) {
      // Add this observer as a listener to computed changes
      const listener = () => {
        // When this computed changes, notify the observer
        observer.updateFn(currentValue)
      }
      listeners.add(listener)
      
      // Check if this is a computed value (has notifyListeners method)
      if ((observer.updateFn as any).notifyListeners) {
        dependentComputeds.add((observer.updateFn as any).notifyListeners)
      }
    }
    
    // Re-compute the value
    try {
      currentValue = updateFn(currentValue)
    } catch (error) {
      console.error('Computed value error:', error)
    }
    
    return currentValue!
  }
  
  const notifyListeners = () => {
    // Re-compute and notify all listeners that this computed value changed
    try {
      currentValue = updateFn(currentValue)
    } catch (error) {
      console.error('Computed recompute error:', error)
      return
    }
    
    // Notify all listeners
    for (const listener of listeners) {
      try {
        listener()
      } catch (error) {
        console.error('Computed notification error:', error)
      }
    }
    
    // Notify all dependent computed values to recompute
    for (const recompute of dependentComputeds) {
      try {
        recompute()
      } catch (error) {
        console.error('Dependent computed recompute notification error:', error)
      }
    }
  }
  
  // Return a getter that notifies listeners when dependencies change
  const wrappedGetter = () => {
    return getter()
  }
  
  // Add method to manually trigger recompute (called by inputs)
  ;(wrappedGetter as any).notifyListeners = notifyListeners
  
  return wrappedGetter as GetterFn<T>
}
