/**
 * Input closure implementation for reactive primitives.
 */
import { getActiveObserver } from '../types/reactive.js';
/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput(value, _equal, options) {
    let currentValue = value;
    const listeners = new Set();
    const dependentComputeds = new Set();
    const read = () => {
        // Register this input as a dependency for the current active observer
        const observer = getActiveObserver();
        if (observer && observer.updateFn) {
            // Add this observer as a listener to input changes
            listeners.add(() => {
                // When input changes, trigger observer update
                observer.updateFn(currentValue);
            });
            // Check if this is a computed value (has notifyListeners method)
            if (observer.updateFn.notifyListeners) {
                dependentComputeds.add(observer.updateFn.notifyListeners);
            }
        }
        return currentValue;
    };
    const write = (nextValue) => {
        if (currentValue === nextValue)
            return nextValue; // Skip if no change
        currentValue = nextValue;
        // Notify all listeners about the value change
        for (const listener of listeners) {
            try {
                listener();
            }
            catch (error) {
                console.error('Input notification error:', error);
            }
        }
        // Notify all dependent computed values to recompute
        for (const recompute of dependentComputeds) {
            try {
                recompute();
            }
            catch (error) {
                console.error('Computed recompute notification error:', error);
            }
        }
        return currentValue;
    };
    return [read, write];
}
