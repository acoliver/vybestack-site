/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subjects?: Set<Subject<unknown>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export { activeObserver }

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite recursion
  if (!observer) return
  
  const previous = activeObserver
  activeObserver = observer
  if (!observer.subjects) observer.subjects = new Set()
  const previousSubjects = new Set(observer.subjects)
  observer.subjects.clear()
  try {
    // Only call updateFn if it exists to prevent recursion
    if (observer.updateFn && typeof observer.updateFn === 'function') {
      observer.value = observer.updateFn(observer.value)
    }
  } finally {
    activeObserver = previous
  }
  
  // Register this observer with all subjects it depends on
  for (const subject of observer.subjects) {
    if (!previousSubjects.has(subject)) {
      // This observer now depends on this subject
      if (!subject.observer || shouldReplaceObserver(subject.observer, observer)) {
        subject.observer = observer
      }
    }
  }
}

function createVirtualSubject<T>(value: T): Subject<T> {
  return {
    value,
    observer: undefined
  }
}

export function shouldReplaceObserver<T>(current: ObserverR | undefined, replacement: Observer<T>): boolean {
  // If current is undefined, always use replacement
  if (!current) return true
  // If current doesn't have a name and replacement does, prefer replacement
  if (!current.name && replacement.name) return true
  if (current.name && !replacement.name) return false
  // If both have names or neither have names, default to replacement
  return true
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observer) {
    // Update the observer for this subject
    updateObserver(subject.observer as Observer<T>)
  }
}

export function cascadeNotifyObservers<T>(initialSubject: Subject<T>): void {
  const visited = new Set<Observer<T>>()
  const subjectsToProcess: Subject<T>[] = [initialSubject]
  
  while (subjectsToProcess.length > 0) {
    const currentSubject = subjectsToProcess.shift()!
    if (!currentSubject.observer) continue
    
    const observer = currentSubject.observer as Observer<T>
    if (visited.has(observer)) continue
    visited.add(observer)
    
    updateObserver(observer)
    
    // For all subjects that this observer depends on, notify them too
    if (observer.subjects) {
      for (const dependentSubject of observer.subjects) {
        // Push as T since we're dealing with typed subjects
        subjectsToProcess.push(dependentSubject as Subject<T>)
      }
    }
  }
}

function findAllObserversForSubject<T>(subject: Subject<T>): Observer<T>[] {
  const observers: Observer<T>[] = []
  // This is a simplified implementation - a more comprehensive one would 
  // traverse the entire dependency graph
  if (subject.observer) {
    observers.push(subject.observer as Observer<T>)
  }
  return observers
}
