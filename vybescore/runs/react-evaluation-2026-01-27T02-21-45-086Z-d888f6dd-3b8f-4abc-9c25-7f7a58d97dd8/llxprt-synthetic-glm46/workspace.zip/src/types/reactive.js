/**
 * Type definitions for the reactive programming system.
 */
let activeObserver;
export function getActiveObserver() {
    return activeObserver;
}
export { activeObserver };
export function updateObserver(observer) {
    // Prevent infinite recursion
    if (!observer)
        return;
    const previous = activeObserver;
    activeObserver = observer;
    if (!observer.subjects)
        observer.subjects = new Set();
    const previousSubjects = new Set(observer.subjects);
    observer.subjects.clear();
    try {
        // Only call updateFn if it exists to prevent recursion
        if (observer.updateFn && typeof observer.updateFn === 'function') {
            observer.value = observer.updateFn(observer.value);
        }
    }
    finally {
        activeObserver = previous;
    }
    // Register this observer with all subjects it depends on
    for (const subject of observer.subjects) {
        if (!previousSubjects.has(subject)) {
            // This observer now depends on this subject
            if (!subject.observer || shouldReplaceObserver(subject.observer, observer)) {
                subject.observer = observer;
            }
        }
    }
}
function createVirtualSubject(value) {
    return {
        value,
        observer: undefined
    };
}
export function shouldReplaceObserver(current, replacement) {
    // If current is undefined, always use replacement
    if (!current)
        return true;
    // If current doesn't have a name and replacement does, prefer replacement
    if (!current.name && replacement.name)
        return true;
    if (current.name && !replacement.name)
        return false;
    // If both have names or neither have names, default to replacement
    return true;
}
export function notifyObservers(subject) {
    if (subject.observer) {
        // Update the observer for this subject
        updateObserver(subject.observer);
    }
}
export function cascadeNotifyObservers(initialSubject) {
    const visited = new Set();
    const subjectsToProcess = [initialSubject];
    while (subjectsToProcess.length > 0) {
        const currentSubject = subjectsToProcess.shift();
        if (!currentSubject.observer)
            continue;
        const observer = currentSubject.observer;
        if (visited.has(observer))
            continue;
        visited.add(observer);
        updateObserver(observer);
        // For all subjects that this observer depends on, notify them too
        if (observer.subjects) {
            for (const dependentSubject of observer.subjects) {
                // Push as T since we're dealing with typed subjects
                subjectsToProcess.push(dependentSubject);
            }
        }
    }
}
function findAllObserversForSubject(subject) {
    const observers = [];
    // This is a simplified implementation - a more comprehensive one would 
    // traverse the entire dependency graph
    if (subject.observer) {
        observers.push(subject.observer);
    }
    return observers;
}
