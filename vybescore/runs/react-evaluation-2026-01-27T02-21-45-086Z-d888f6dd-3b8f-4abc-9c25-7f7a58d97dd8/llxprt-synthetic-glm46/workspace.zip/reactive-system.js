// Direct implementation of reactive system from scratch
// This will help me understand what needs to be implemented

class Subject {
  constructor(value) {
    this._value = value
    this._observers = new Set()
  }
  
  get value() {
    return this._value
  }
  
  set value(newValue) {
    if (this._value !== newValue) {
      this._value = newValue
      this.notify()
    }
  }
  
  subscribe(observer) {
    this._observers.add(observer)
    return () => this._observers.delete(observer)
  }
  
  notify() {
    for (const observer of this._observers) {
      observer()
    }
  }
}

class Computed {
  constructor(fn, dependencies = []) {
    this._fn = fn
    this._dependencies = dependencies
    this._value = undefined
    this._observers = new Set()
    this._dirty = true
    
    // Subscribe to dependencies
    for (const dep of dependencies) {
      dep.subscribe(() => {
        this._dirty = true
        this.notify()
      })
    }
    
    // Compute initial value
    this.recompute()
  }
  
  get value() {
    if (this._dirty) {
      this.recompute()
    }
    return this._value
  }
  
  recompute() {
    this._value = this._fn()
    this._dirty = false
  }
  
  subscribe(observer) {
    this._observers.add(observer)
    return () => this._observers.delete(observer)
  }
  
  notify() {
    if (!this._dirty) return
    for (const observer of this._observers) {
      observer()
    }
  }
}

function createInput(initialValue) {
  const subject = new Subject(initialValue)
  
  const getter = () => subject.value
  const setter = (newValue) => {
    subject.value = newValue
    return newValue
  }
  
  return [getter, setter]
}

function createComputed(fn) {
  // Track dependencies by running the function in a tracking context
  const dependencies = []
  const tracking = {
    addSubject: (subject) => {
      if (!dependencies.includes(subject)) {
        dependencies.push(subject)
      }
    }
  }
  
  const trackedFn = () => {
    // Save current tracking context
    const prevTracking = currentTracking
    currentTracking = tracking
    
    try {
      return fn()
    } finally {
      currentTracking = prevTracking
    }
  }
  
  return new Computed(trackedFn, dependencies)
}

function createCallback(fn) {
  let disposed = false
  
  const callback = () => {
    if (!disposed) {
      fn()
    }
  }
  
  // Run once to establish dependencies
  callback()
  
  return () => {
    disposed = true
    // Unsubscribe from all tracked dependencies
    // (Implementation depends on tracking system)
  }
}

// Global tracking context
let currentTracking = null

// Override built-in get accessors to track dependencies
const originalGetter = Subject.prototype.value.get
Object.defineProperty(Subject.prototype, 'value', {
  get() {
    if (currentTracking) {
      currentTracking.addSubject(this)
    }
    return this._value
  },
  set(newValue) {
    if (this._value !== newValue) {
      this._value = newValue
      this.notify()
    }
  }
})

export { createInput, createComputed, createCallback }

// Test the implementation
console.log('--- Test case 1 ---')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo.value + timesThirty.value)
console.log('Initial sum:', sum.value)
setInput(3)
console.log('After setting to 3, sum:', sum.value)
console.log('Expected: 96')