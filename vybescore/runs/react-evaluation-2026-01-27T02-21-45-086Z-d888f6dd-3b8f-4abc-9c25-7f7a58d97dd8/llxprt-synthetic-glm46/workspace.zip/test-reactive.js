// Quick test to understand what's happening
import { createInput, createComputed, createCallback } from './dist/index.js'

console.log('--- Test case 1 ---')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())
console.log('Initial sum:', sum())
setInput(3)
console.log('After setting to 3, sum:', sum())
console.log('Expected: 96')

console.log('--- Test case 2 ---')
const [input2, setInput2] = createInput(1)
const output2 = createComputed(() => input2() + 1)
let value = 0
createCallback(() => (value = output2()))
console.log('Initial value:', value)
setInput2(3)
console.log('After setting to 3, value:', value)
console.log('Expected: 4')