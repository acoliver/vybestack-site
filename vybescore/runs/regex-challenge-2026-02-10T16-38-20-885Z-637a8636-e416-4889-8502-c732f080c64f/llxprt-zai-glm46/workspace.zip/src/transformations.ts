/**
 * Capitalize the first character of each sentence.
 * - Capitalizes first character after .?!
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces sensibly
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // Split into sentences, but preserve common abbreviations
  // First, handle spacing: normalize multiple spaces to single space
  let result = text.replace(/[ \t]+/g, ' ').trim();

  // Ensure there's always a space after sentence endings if followed by text
  result = result.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');

  // Now capitalize sentences
  // Find sentence boundaries: .!? followed by whitespace or end of string
  const sentenceRegex = /([.!?]\s+|^)([a-z])/g;
  result = result.replace(sentenceRegex, (_, boundary, letter) => boundary + letter.toUpperCase());

  // Capitalize the very first character
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }

  // Clean up any double spaces that might have been created
  result = result.replace(/ +/g, ' ');

  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * Handles http, https, www, and common TLDs. Excludes trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL pattern matching
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])*(?::\d+)?(?:\/[^\s.,!?;:)\]"']*)?/gi;

  const matches = text.match(urlPattern);

  if (!matches) {
    return [];
  }

  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?;:)\]"']+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * - Always upgrade http to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com URLs
  const urlPattern = /http:\/\/example\.com(\/[^\s]*)?/gi;

  return text.replace(urlPattern, (match, path = '') => {
    // Default: just upgrade to https
    let result = 'https://example.com' + path;

    // Check if we should rewrite the host
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const hasDynamicHint = /\/cgi-bin\/|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|\/|$))/i.test(path);

      if (!hasDynamicHint) {
        // Rewrite to docs.example.com
        result = 'https://docs.example.com' + path;
      }
    }

    return result;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
