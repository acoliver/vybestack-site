/**
 * Match words starting with the prefix but excluding banned words.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern: word boundary, prefix, then any word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(ex => ex.toLowerCase() === word.toLowerCase())
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match a digit followed by the token, but not at the start of the string
  // Use a pattern to ensure the token is preceded by a digit somewhere before it
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for required character types
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);

  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }

  // Check for repeated sequences (e.g., abab, 1212, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const sequence = value.substring(i, i + len);
      const nextSequence = value.substring(i + len, i + len * 2);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 * Returns true if IPv6 address is detected, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  const trimmed = value.trim();

  // First, exclude pure IPv4 addresses (no colons or only one colon for port)
  const pureIPv4Pattern = /^(?:(?:\d{1,3}\.){3}\d{1,3})(?::\d+)?$/;
  if (pureIPv4Pattern.test(trimmed)) {
    return false;
  }

  // IPv6 patterns:
  // - Must contain colons (at least 2 for compressed :: or more for full notation)
  // - Full form: 8 groups of 1-4 hex digits separated by colons
  // - Compressed form: with :: shorthand
  // - Can have IPv4 at the end (IPv4-mapped)
  // - Can have zone index like %lo0
  
  // Check for double colon (::) which is unique to IPv6
  if (/::/.test(trimmed)) {
    return true;
  }

  // Pattern for full IPv6 with multiple colons (at least 2 colons)
  // Must have hex digits around the colons
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}/i;
  
  if (ipv6Pattern.test(trimmed)) {
    return true;
  }

  // Check for IPv4-mapped IPv6 addresses
  const ipv4MappedPattern = /::ffff:(?:\d{1,3}\.){3}\d{1,3}/i;
  if (ipv4MappedPattern.test(trimmed)) {
    return true;
  }

  return false;
}
