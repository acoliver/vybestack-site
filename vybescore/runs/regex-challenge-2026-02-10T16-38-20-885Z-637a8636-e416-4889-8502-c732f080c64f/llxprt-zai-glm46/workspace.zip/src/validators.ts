export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with support for international domains.
 * Accepts: name@tag@example.co.uk style addresses
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic structure check
  if (!emailRegex.test(value)) {
    return false;
  }

  // Check for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Split and validate domain parts
  const [, ...domainParts] = value.split('@');

  // Must have exactly one @
  if (domainParts.length !== 1) {
    return false;
  }

  const domain = domainParts[0];
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }

  // Domain parts validation
  const domainLabels = domain.split('.');
  if (domainLabels.length < 2) {
    return false;
  }

  // Each label must be valid
  for (const label of domainLabels) {
    if (label.length === 0) {
      return false;
    }
    if (label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
    if (!/^[a-zA-Z0-9-]+$/.test(label)) {
      return false;
    }
  }

  // TLD must be at least 2 chars
  const tld = domainLabels[domainLabels.length - 1];
  if (tld.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common separators and optional +1 prefix.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890
 * Rejects: area codes starting with 0 or 1, numbers that are too short
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all common separators and spaces
  const cleaned = value.replace(/[\s\-().]/g, '');

  // Handle optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }

  // Must be exactly 10 digits
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code (required if country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - Separators: single spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Must have at least 8 digits total (minimum 2 digit area code + 6 digit subscriber)
  if (cleaned.length < 8) {
    return false;
  }

  // Check for country code +54
  const hasCountryCode = cleaned.startsWith('+54');
  let digits = cleaned;
  
  if (hasCountryCode) {
    digits = cleaned.substring(3); // Remove +54
  }

  // Check for trunk prefix 0 (required if no country code)
  const hasTrunkPrefix = digits.startsWith('0');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  // Remove trunk prefix if present
  if (hasTrunkPrefix) {
    digits = digits.substring(1);
  }

  // Check for mobile indicator 9
  const hasMobileIndicator = digits.startsWith('9');
  if (hasMobileIndicator) {
    digits = digits.substring(1);
  }

  // Now digits should be area code + subscriber number
  // Total length should be 8-12 digits (2-4 area code + 6-8 subscriber)
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }

  // Extract area code (2-4 digits, leading digit 1-9)
  const areaCodeMatch = digits.match(/^([1-9]\d{1,3})(\d+)$/);
  
  if (!areaCodeMatch) {
    return false;
  }

  const areaCode = areaCodeMatch[1];
  const subscriber = areaCodeMatch[2];

  // Validate area code length: 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Validate subscriber number length: 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Accepts: Jane Doe, José María, O'Connor, Smith-Jones
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (value.length === 0) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must contain at least one letter (excluding marks)
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Reject names like "X Æ A-12" that contain digits
  if (/\d/.test(value)) {
    return false;
  }

  // Reject names with only punctuation/spaces
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }

  return true;
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let isEven = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts: Visa (13-16 digits, starts with 4), Mastercard (16 digits, starts with 51-55 or 2221-2720), AmEx (15 digits, starts with 34 or 37)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check card type patterns
  const visaPattern = /^4\d{12}(\d{3})?$/; // 13-16 digits starting with 4
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/; // 16 digits starting with 51-55 or 2221-2720
  const amexPattern = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37

  const isValidFormat = visaPattern.test(cleaned) || mastercardPattern.test(cleaned) || amexPattern.test(cleaned);

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
