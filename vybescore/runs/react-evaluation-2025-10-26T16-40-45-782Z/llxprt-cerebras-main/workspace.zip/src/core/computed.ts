/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equalFn?: EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  updateObserver(o)
  
  const subject = {
    name: options?.name,
    observer: o as Observer<unknown>,
    value: o.value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) subject.observer = activeObserver
    return subject.value as T
  }

  // Update the subject value when observer updates
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    if (equalFn ? !equalFn(subject.value as T, newValue) : subject.value !== newValue) {
      subject.value = newValue
      if (subject.observer) updateObserver(subject.observer as Observer<unknown>)
    }
    return newValue
  }

  return read
}