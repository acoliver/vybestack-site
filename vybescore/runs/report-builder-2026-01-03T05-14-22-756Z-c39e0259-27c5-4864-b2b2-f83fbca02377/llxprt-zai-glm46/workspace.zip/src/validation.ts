import type { ReportData } from './types.js';
import { ValidationError } from './types.js';

/**
 * Validate and parse report data from an unknown value.
 */
export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new ValidationError('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new ValidationError('Missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new ValidationError('Missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new ValidationError('Missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new ValidationError(`Invalid entry at index ${i}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new ValidationError(
        `Invalid entry at index ${i}: missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new ValidationError(
        `Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`
      );
    }

    if (isNaN(entryObj.amount)) {
      throw new ValidationError(
        `Invalid entry at index ${i}: "amount" cannot be NaN`
      );
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries as Array<{ label: string; amount: number }>,
  };
}
