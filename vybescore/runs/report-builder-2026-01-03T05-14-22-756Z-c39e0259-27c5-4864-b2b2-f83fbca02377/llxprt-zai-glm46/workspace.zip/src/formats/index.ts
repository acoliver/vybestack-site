import { renderText } from './text.js';
import { renderMarkdown } from './markdown.js';

/**
 * Report data and options interfaces (re-exported for convenience).
 */
export type { ReportData, RenderOptions } from '../types.js';

/**
 * Format types supported by the report builder.
 */
export type Format = 'text' | 'markdown';

/**
 * Get the renderer function for a given format.
 */
export function getRenderer(format: Format) {
  const renderers = {
    text: renderText,
    markdown: renderMarkdown,
  };

  const renderer = renderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return renderer;
}
