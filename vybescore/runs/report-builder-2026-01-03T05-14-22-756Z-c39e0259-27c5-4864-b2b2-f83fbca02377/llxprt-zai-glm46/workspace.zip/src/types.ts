/**
 * A single entry in the report with a label and monetary amount.
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * The complete report data structure parsed from JSON input.
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering a report.
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Validation error with details about what went wrong.
 */
export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}
