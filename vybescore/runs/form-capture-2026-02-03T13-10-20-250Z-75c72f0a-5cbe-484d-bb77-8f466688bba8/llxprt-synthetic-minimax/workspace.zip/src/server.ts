import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const { default: initSqlJs } = require('sql.js');

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Database setup
interface Database {
  prepare: (query: string) => Statement;
  exec: (query: string) => void;
  export: () => Uint8Array;
}

interface Statement {
  run: (params: string[]) => void;
  free: () => void;
}

let db: Database | null = null;
const dbPath = path.resolve(process.cwd(), 'data/submissions.sqlite');
const schemaPath = path.resolve(process.cwd(), 'db/schema.sql');

async function initializeDatabase(): Promise<void> {
  try {
    // Initialize sql.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        // Use a simple approach to find the WASM file
        const wasmPath = path.resolve(process.cwd(), 'node_modules/sql.js/dist', file);
        return wasmPath;
      }
    });

    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      
      // Load schema and create table if db was just created
      const schema = fs.readFileSync(schemaPath, 'utf8');
      if (db) {
        db.exec(schema);
      }
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  try {
    if (db !== null) {
      const binaryDb = db.export();
      const buffer = Buffer.from(binaryDb);
      fs.writeFileSync(dbPath, buffer);
    }
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Remove common non-digit characters for validation
  const cleanPhone = phone.replace(/[\s\-() +]/g, '');
  return cleanPhone.length >= 7; // Basic length check
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric, spaces, and common postal code characters
  const postalRegex = /^[A-Za-z0-9\s\-/.]{3,10}$/;
  return postalRegex.test(postalCode.trim());
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || value.trim().length === 0) {
      errors.push({
        field: field,
        message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
      });
    }
  });

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return errors;
}

// Express app setup
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render(path.resolve(process.cwd(), 'src/templates/form.ejs'), {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = req.body;
  
  // Validate form data
  const validationErrors = validateFormData(formData);
  
  if (validationErrors.length > 0) {
    // Re-render form with errors and previous values
    res.status(400).render(path.resolve(process.cwd(), 'src/templates/form.ejs'), {
      errors: validationErrors.map(err => err.message),
      values: formData
    });
    return;
  }

  // Insert into database
  try {
    if (db === null || db === undefined) throw new Error('Database not initialized');
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName?.trim() || '',
      formData.lastName?.trim() || '',
      formData.streetAddress?.trim() || '',
      formData.city?.trim() || '',
      formData.stateProvince?.trim() || '',
      formData.postalCode?.trim() || '',
      formData.country?.trim() || '',
      formData.email?.trim() || '',
      formData.phone?.trim() || ''
    ]);

    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render(path.resolve(process.cwd(), 'src/templates/form.ejs'), {
      errors: ['An error occurred while saving your information. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render(path.resolve(process.cwd(), 'src/templates/thank-you.ejs'));
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err.stack);
  res.status(500).send('Something went wrong!');
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  
  if (db) {
    saveDatabase();
  }
  
  if (server && server.close) {
    server.close(() => {
      console.log('Process terminated');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Start server
let server: import('http').Server | null = null;

async function startServer(): Promise<void> {
  await initializeDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  // Handle graceful shutdown
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
