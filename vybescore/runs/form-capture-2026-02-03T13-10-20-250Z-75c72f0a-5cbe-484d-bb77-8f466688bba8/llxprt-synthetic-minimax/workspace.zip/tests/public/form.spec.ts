import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'child_process';

const dbPath = path.resolve('data', 'submissions.sqlite');

let serverProcess: import('child_process').ChildProcessWithoutNullStreams;

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server as a child process
  serverProcess = spawn('node', ['dist/server.js'], {
    stdio: ['ignore', 'pipe', 'pipe']
  });
  
  // Give server time to start
  await new Promise(resolve => setTimeout(resolve, 500));
  
  // Wait for server to be ready by testing a simple request
  let attempts = 0;
  while (attempts < 10) {
    try {
      await request('http://localhost:3535').get('/').expect(200);
      break;
    } catch (error) {
      attempts++;
      await new Promise(resolve => setTimeout(resolve, 200));
    }
  }
});

afterAll(() => {
  // Clean up server process
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
  }
  
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone');
  });

  it('persists submission and redirects', async () => {
    // Test form submission with valid data
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request('http://localhost:3535')
      .post('/submit')
      .type('form')
      .send(formData)
      .expect(302); // Should redirect

    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for missing fields', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        // missing required fields
        lastName: ''
      })
      .expect(400); // Should return validation errors

    expect(response.text).toContain('is required');
  });

  it('validates email format', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      })
      .expect(400);

    expect(response.text).toContain('Please enter a valid email address');
  });

  it('shows thank you page after successful submission', async () => {
    // First submit a form
    await request('http://localhost:3535')
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Los Angeles',
        stateProvince: 'CA',
        postalCode: '90210',
        country: 'USA',
        email: 'jane@example.com',
        phone: '+1 555-987-6543'
      })
      .expect(302);

    // Then check thank you page
    const response = await request('http://localhost:3535')
      .get('/thank-you')
      .expect(200);

    expect(response.text).toContain('Thank you!');
    expect(response.text).toContain('Why did you give your info to a stranger on the internet?');
  });
});
