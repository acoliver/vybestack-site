/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Insert exactly one space between sentences and collapse extra spaces while leaving abbreviations intact.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) return text;
  
  // Process the text to properly capitalize sentences
  const sentenceSeparators = /[.!?]+/;
  const sentences = text.split(sentenceSeparators);
  
  const result: string[] = [];
  let separatorIndex = 0;
  
  const separators = text.match(/[.!?]+/g) || [];
  
  // Process each sentence
  sentences.forEach((sentence, index) => {
    if (sentence.trim()) {
      // Capitalize first non-space character
      const trimmedSentence = sentence.trim();
      const sentencesToProcess = trimmedSentence.split(/\s+/);
      
      // Find the first word with actual content
      for (let i = 0; i < sentencesToProcess.length; i++) {
        const word = sentencesToProcess[i];
        if (word.length > 0) {
          sentencesToProcess[i] = word.charAt(0).toUpperCase() + word.slice(1);
          break;
        }
      }
      
      result.push(sentencesToProcess.join(' '));
    } else {
      // If sentence is empty, just add it back
      result.push(sentence);
    }
    
    // Add the separator and one space
    if (index < separators.length) {
      const separator = separators[separatorIndex++];
      result.push(separator + ' ');
    }
  });
  
  let finalText = result.join('');
  
  // Clean up extra spaces and ensure single space after periods
  finalText = finalText.replace(/\s+/g, ' ');
  finalText = finalText.replace(/\s+([.!?])/g, '$1');
  finalText = finalText.replace(/\s+$/, ''); // Remove trailing space
  
  return finalText;
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  const urlRegex = /(https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&=/*]*))/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  const cleanUrls = matches.map(url => {
    return url.replace(/[.,;:!?)]+$/, ''); // Remove trailing punctuation
  });
  
  return [...new Set(cleanUrls)]; // Remove duplicates while preserving order
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using a regular expression that avoids double conversion
  const httpsUrlRegex = /\bhttp:\/\//g;
  return text.replace(httpsUrlRegex, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Regular expression to match http://example.com URLs
  const urlPattern = /http:\/\/example\.com\/([^\s]+)/g;
  
  // Process each match found
  return text.replace(urlPattern, (match, path) => {
    // Always upgrade scheme to https
    const httpsUrl = match.replace(/^http:\/\//, 'https://');
    
    // Check for dynamic hints that should prevent host rewrite
    // Patterns that indicate dynamic content
    const dynamicHints = /(^|\/)(cgi-bin|\?.*=?(&.*)*)|(\/(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    
    // Check if path begins with /docs/ and doesn't contain dynamic content
    if (path.startsWith('docs/') && !dynamicHints.test(path)) {
      // Rewrite the host to docs.example.com - we need to rebuild the URL
      return `https://docs.example.com/${path}`;
    }
    
    // Just return the upgraded https version
    return httpsUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check if value matches mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for days in month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  // Check if day is valid for the month
  if (day > daysInMonth[month]) return 'N/A';
  
  return year;
}
