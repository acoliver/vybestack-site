export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * US phone number validator supporting common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix
 */
/**
 * Email validator that accepts typical addresses while rejecting invalid patterns.
 * Accepts: name+tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex for validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check email format
  if (!emailRegex.test(value)) return false;
  
  // Additional validation rules
  // No double dots
  if (value.includes('..')) return false;
  
  // No trailing dot in local part
  if (value.split('@')[0].endsWith('.')) return false;
  
  // Domain cannot start or end with a dot
  const domain = value.split('@')[1];
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Domain cannot contain underscores
  if (domain.includes('_')) return false;
  
  return true;
}

export function isValidUSPhone(value: string): boolean {
  // Remove all whitespace and non-digit non-plus characters except parentheses and dashes
  const normalized = value.replace(/[^\d+()-\s]/g, '');
  
  // Check for optional +1 country code
  const hasCountryCode = normalized.startsWith('+1');
  const withoutCountryCode = hasCountryCode ? normalized.substring(2) : normalized;
  
  // Remove all non-digit characters for validation
  const digitsOnly = withoutCountryCode.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number)
  if (digitsOnly.length < 10) return false;
  
  // If exactly 11 digits, first must be 1 (US country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') return false;
  
  // More than 11 digits is invalid for US format
  if (digitsOnly.length > 11) return false;
  
  // Extract the 10-digit phone number
  const phoneNumber = digitsOnly.length === 10 ? digitsOnly : digitsOnly.substring(1);
  
  // Area code validation (can't start with 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if overall format matches one of the accepted patterns
  // Patterns: (212) 555-7890, (212)555-7890, 212-555-7890, 2125557890
  const patterns = [
    /^\+?1?\s*[(]\d{3}[)]\s*\d{3}[-\s]?\d{4}$/, // (212) 555-7890 format
    /^\+?1?\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/, // 212-555-7890 format
    /^\+?1?\s*\d{10}$/ // 2125557890 format
  ];
  
  for (const pattern of patterns) {
    if (pattern.test(normalized)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Argentine phone number validator for landlines and mobile formats:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check for optional country code +54
  const hasCountryCode = normalized.startsWith('+54');
  
  let withoutCountryCode = normalized;
  if (hasCountryCode) {
    withoutCountryCode = normalized.substring(3);
  }
  
  // Check for optional trunk prefix 0 before area code
  let hasTrunkPrefix = false;
  if (withoutCountryCode.startsWith('0')) {
    hasTrunkPrefix = true;
    withoutCountryCode = withoutCountryCode.substring(1);
  }
  
  // When country code is omitted, trunk prefix is required before area code
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for optional mobile indicator 9 between country/trunk and area code
  let areaPart = withoutCountryCode;
  if (areaPart.startsWith('9')) {
    areaPart = areaPart.substring(1);
  }
  
  // Area code must be 2-4 digits with leading digit 1-9
  let areaCode = '';
  let subscriberNumber = '';
  
  // Try to extract area code of 2-4 digits
  for (let len = 4; len >= 2; len--) {
    if (areaPart.length >= len) {
      const potentialAreaCode = areaPart.substring(0, len);
      const potentialSubscriber = areaPart.substring(len);
      
      // Check if area code is valid (leading digit 1-9)
      if (/^[1-9]\d*$/.test(potentialAreaCode) && potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
        areaCode = potentialAreaCode;
        subscriberNumber = potentialSubscriber;
        break;
      }
    }
  }
  
  // If no valid area code found with longer length, try shorter lengths
  if (!areaCode) {
    for (let len = 2; len <= 4; len++) {
      if (areaPart.length >= len) {
        const potentialAreaCode = areaPart.substring(0, len);
        const potentialSubscriber = areaPart.substring(len);
        
        // Check if area code is valid (leading digit 1-9)
        if (/^[1-9]\d{0,3}$/.test(potentialAreaCode) && potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
          areaCode = potentialAreaCode;
          subscriberNumber = potentialSubscriber;
          break;
        }
      }
    }
  }
  
  // Validate components
  if (!areaCode || !/^[1-9]\d{0,3}$/.test(areaCode)) return false;
  if (!subscriberNumber || !/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Personal name validator allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and "X Æ A-12" style names
  const nameRegex = /^[\p{L}\p{M}\s'’-]+$/u;
  
  // Check if contains only allowed characters
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject if contains digits
  if (/\d/.test(value)) return false;
  
  // Reject if contains only special characters and spaces
  const onlySpecialChars = /^[‘’'\s-]+$/.test(value);
  if (onlySpecialChars) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm helper for credit card validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEverySecond = false;
  
  // Process from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    const digit = parseInt(number.charAt(i), 10);
    
    if (isEverySecond) {
      const doubledDigit = digit * 2;
      sum += doubledDigit > 9 ? doubledDigit - 9 : doubledDigit;
    } else {
      sum += digit;
    }
    
    isEverySecond = !isEverySecond;
  }
  
  return sum % 10 === 0;
}

/**
 * Credit card validator accepting Visa/Mastercard/AmEx with proper prefix and length validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits for most cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  // Visa: starts with 4, length 13 or 16 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55, 2221-2720, length 16 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[1-9]\d{3})\d{10})$/;
  
  // American Express: starts with 34 or 37, length 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the supported card types
  const isVisa = visaRegex.test(digitsOnly);
  const isMastercard = mastercardRegex.test(digitsOnly);
  const isAmex = amexRegex.test(digitsOnly);
  
  if (!isVisa && !isMastercard && !isAmex) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}
