/**
 * Finds words starting with a specific prefix but excluding the provided exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape prefix for regex usage
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to match words with the prefix
  const prefixWordRegex = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'g');
  
  const matches: string[] = [];
  const found = new Set<string>();
  
  let match;
  while ((match = prefixWordRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Skip if in exceptions list
    if (exceptions.some(ex => ex.toLowerCase() === word.toLowerCase())) {
      continue;
    }
    
    // Only add unique words
    if (!found.has(word)) {
      found.add(word);
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds for the matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to match digit followed by token
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  return text.match(tokenRegex) || [];
}

/**
 * Validates passwords according to the policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Length check - at least 10 characters
  if (value.length < 10) return false;
  
  // Character type checks
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=\-/{};':"|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
// Check for immediate repeated sequences (like abab)
  // Pattern for any character repeated immediately with 2 characters in between
  const repeatedPattern = /([\w!@#$%^&*()_+=\-/{};':"|,.<>/?])\w?\w?\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, we need to make sure we're not matching IPv4 addresses
  // IPv4 addresses are in the form x.x.x.x where x is 0-255
  const ipv4Pattern = /\b(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  if (ipv4Pattern.test(value)) return false;
  
  // IPv6 pattern
  // IPv6 addresses consist of 8 groups of 4 hexadecimal digits, separated by colons
  // Consecutive groups of zeros can be replaced by ::
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|\b(?:[0-9a-fA-F]{1,4}:){1,7}:|\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b:(?:[0-9a-fA-F]{1,4}:){1,7}\b|(?:[0-9a-fA-F]{1,4}:){1,7}|(?:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})?::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}?/g;
  
  return ipv6Pattern.test(value);
}
