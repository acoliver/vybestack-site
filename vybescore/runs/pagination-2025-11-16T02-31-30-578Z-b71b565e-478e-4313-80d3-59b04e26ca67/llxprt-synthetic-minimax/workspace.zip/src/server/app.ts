import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePaginationParams } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    // Validate pagination parameters
    if (Number.isNaN(page) || Number.isNaN(limit)) {
      return res.status(400).json({ error: 'Page and limit must be valid numbers' });
    }

    const validation = validatePaginationParams(page, limit);
    if (validation.error) {
      return res.status(400).json({ error: validation.error });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
