#!/bin/bash

# Test script for the form capture application

# Start server on port 3536
PORT=3536 node dist/server.js &
SERVER_PID=$!

# Wait for server to start
sleep 3

echo "Testing form submission..."

# Test 1: GET / - Should return the form page
echo "Test 1: GET /"
curl -s http://localhost:3536/ | grep -q "Tell us who you are" && echo "[OK] Form page loaded" || echo " Form page failed"

# Test 2: POST /submit with invalid data - Should return errors
echo -e "\nTest 2: POST /submit with invalid email"
curl -s -X POST http://localhost:3536/submit \
  -d "firstName=John&lastName=Doe&email=invalidemail&phone=+1234567890" \
  | grep -q "Email must be a valid email address" && echo "[OK] Email validation works" || echo " Email validation failed"

# Test 3: POST /submit with valid data - Should redirect
echo -e "\nTest 3: POST /submit with valid data"
curl -s -w "\nHTTP Status: %{http_code}\n" -X POST http://localhost:3536/submit \
  -d "firstName=Jane&lastName=Smith&streetAddress=123 Main St&city=London&stateProvince=England&postalCode=SW1A 1AA&country=UK&email=jane@example.com&phone=+44 20 7946 0958" \
  -o /dev/null

# Test 4: GET /thank-you - Should show thank you page
echo -e "\nTest 4: GET /thank-you"
curl -s http://localhost:3536/thank-you | grep -q "Thank you" && echo "[OK] Thank you page loaded" || echo " Thank you page failed"

# Test 5: Check database file was created
echo -e "\nTest 5: Check database"
if [ -f "data/submissions.sqlite" ]; then
  echo "[OK] Database file created"
  # Check file size is greater than 0
  if [ -s "data/submissions.sqlite" ]; then
    echo "[OK] Database file has content"
  else
    echo " Database file is empty"
  fi
else
  echo " Database file not found"
fi

# Test 6: Test international phone formats
echo -e "\nTest 6: POST /submit with international phone numbers"
curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Carlos&lastName=Garcia&streetAddress=Av. Corrientes 1234&city=Buenos Aires&stateProvince=CABA&postalCode=C1000&country=Argentina&email=carlos@example.com&phone=+54 9 11 1234-5678" \
  -w "\nHTTP Status: %{http_code}\n" \
  -o /dev/null

# Clean up
echo -e "\nShutting down server..."
kill $SERVER_PID
wait $SERVER_PID 2>/dev/null

echo "Tests completed!"
