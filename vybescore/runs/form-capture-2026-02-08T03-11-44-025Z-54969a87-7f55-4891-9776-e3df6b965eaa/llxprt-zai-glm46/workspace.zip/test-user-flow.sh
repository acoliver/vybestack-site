#!/bin/bash

echo "=========================================="
echo "Complete User Flow Test"
echo "=========================================="

# Start server
PORT=3536 node dist/server.js &
SERVER_PID=$!
sleep 2

echo -e "\n1. User visits the form page..."
FORM_HTML=$(curl -s http://localhost:3536/)
if echo "$FORM_HTML" | grep -q "Tell us who you are"; then
  echo "   [OK] Form page loads successfully"
else
  echo "    Form page failed to load"
fi

echo -e "\n2. User fills out the form with valid data..."
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=Emma&lastName=Thompson&streetAddress=221B Baker Street&city=London&stateProvince=England&postalCode=NW1 6XE&country=United Kingdom&email=emma.t@example.com&phone=+44 20 7234 5678" \
  -o /dev/null)

if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] Form submission redirects (302)"
else
  echo "    Form submission failed (HTTP $HTTP_CODE)"
fi

echo -e "\n3. User is redirected to thank you page..."
THANK_YOU=$(curl -s "http://localhost:3536/thank-you?firstName=Emma")
if echo "$THANK_YOU" | grep -q "Thank you, Emma"; then
  echo "   [OK] Thank you page displays with user's name"
else
  echo "    Thank you page failed"
fi

if echo "$THANK_YOU" | grep -q "stranger on the internet"; then
  echo "   [OK] Humorous scam warning is present"
else
  echo "    Humorous scam warning missing"
fi

echo -e "\n4. User decides to submit another form with different data..."
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=Liam&lastName=O'Connor&streetAddress=Main Street&city=Dublin&stateProvince=Leinster&postalCode=D02 Y236&country=Ireland&email=liam@example.com&phone=+353 1 555 1234" \
  -o /dev/null)

if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] Second submission successful"
else
  echo "    Second submission failed (HTTP $HTTP_CODE)"
fi

echo -e "\n5. Verifying database persistence..."
if [ -f "data/submissions.sqlite" ]; then
  FILE_SIZE=$(stat -c%s "data/submissions.sqlite" 2>/dev/null || stat -f%z "data/submissions.sqlite" 2>/dev/null)
  if [ "$FILE_SIZE" -gt 5000 ]; then
    echo "   [OK] Database contains multiple entries (${FILE_SIZE} bytes)"
  else
    echo "    Database too small (${FILE_SIZE} bytes)"
  fi
else
  echo "    Database file not found"
fi

echo -e "\n6. Testing error handling - user submits invalid email..."
ERROR_RESPONSE=$(curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Test&lastName=User&email=notanemail&phone=+1234567890&streetAddress=123&city=Test&stateProvince=Test&postalCode=12345&country=USA")

if echo "$ERROR_RESPONSE" | grep -q "Email must be a valid email address"; then
  echo "   [OK] Error message displayed for invalid email"
else
  echo "    Error message not displayed"
fi

if echo "$ERROR_RESPONSE" | grep -q "value=\"Test\""; then
  echo "   [OK] Form preserves user input after error"
else
  echo "    Form doesn't preserve user input"
fi

echo -e "\n7. Testing international postal codes..."
# UK format
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=Test&lastName=User&email=test@example.com&phone=+44 20 7946 0958&streetAddress=Test&city=London&stateProvince=England&postalCode=SW1A 1AA&country=UK" \
  -o /dev/null)
if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] UK postal code (SW1A 1AA) accepted"
else
  echo "    UK postal code rejected"
fi

# Argentine format
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=Test&lastName=User&email=test@example.com&phone=+54 11 1234-5678&streetAddress=Test&city=Buenos Aires&stateProvince=CABA&postalCode=C1000&country=Argentina" \
  -o /dev/null)
if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] Argentine postal code (C1000) accepted"
else
  echo "    Argentine postal code rejected"
fi

# US format
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=Test&lastName=User&email=test@example.com&phone=+1 212-555-1234&streetAddress=Test&city=New York&stateProvince=NY&postalCode=10001&country=USA" \
  -o /dev/null)
if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] US ZIP code (10001) accepted"
else
  echo "    US ZIP code rejected"
fi

# Shutdown
kill $SERVER_PID
wait $SERVER_PID 2>/dev/null

echo -e "\n=========================================="
echo "User Flow Test Complete!"
echo "=========================================="
