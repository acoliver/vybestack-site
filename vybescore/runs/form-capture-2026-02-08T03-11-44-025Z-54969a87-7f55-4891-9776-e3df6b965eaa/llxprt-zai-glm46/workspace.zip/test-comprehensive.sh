#!/bin/bash

# Comprehensive test script for the form capture application

echo "Starting comprehensive tests..."

# Start server on port 3536
PORT=3536 node dist/server.js &
SERVER_PID=$!

# Wait for server to start
sleep 3

echo "=========================================="
echo "Testing Form Validation"
echo "=========================================="

# Test 1: Empty form submission
echo -e "\n1. Testing empty form submission..."
RESPONSE=$(curl -s -X POST http://localhost:3536/submit -d "")
if echo "$RESPONSE" | grep -q "First name is required"; then
  echo "   [OK] Correctly validates empty first name"
else
  echo "    Failed to validate empty first name"
fi

# Test 2: Invalid email format
echo -e "\n2. Testing invalid email format..."
RESPONSE=$(curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Test&lastName=User&email=invalid&phone=+1234567890&streetAddress=123 Test&city=Test&stateProvince=Test&postalCode=12345&country=USA")
if echo "$RESPONSE" | grep -q "Email must be a valid email address"; then
  echo "   [OK] Correctly validates email format"
else
  echo "    Failed to validate email format"
fi

# Test 3: Invalid phone format
echo -e "\n3. Testing invalid phone format..."
RESPONSE=$(curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Test&lastName=User&email=test@example.com&phone=invalid-phone&streetAddress=123 Test&city=Test&stateProvince=Test&postalCode=12345&country=USA")
if echo "$RESPONSE" | grep -q "Phone number must contain only"; then
  echo "   [OK] Correctly validates phone format"
else
  echo "    Failed to validate phone format"
fi

# Test 4: Invalid postal code format
echo -e "\n4. Testing invalid postal code format..."
RESPONSE=$(curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Test&lastName=User&email=test@example.com&phone=+1234567890&streetAddress=123 Test&city=Test&stateProvince=Test&postalCode=invalid@postal&country=USA")
if echo "$RESPONSE" | grep -q "Postal / Zip code must contain only"; then
  echo "   [OK] Correctly validates postal code format"
else
  echo "    Failed to validate postal code format"
fi

echo -e "\n=========================================="
echo "Testing International Formats"
echo "=========================================="

# Test 5: UK postal code
echo -e "\n5. Testing UK postal code (SW1A 1AA)..."
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=John&lastName=Smith&streetAddress=10 Downing Street&city=London&stateProvince=England&postalCode=SW1A 1AA&country=United Kingdom&email=john@example.com&phone=+44 20 7946 0958" \
  -o /dev/null)
if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] UK postal code accepted"
else
  echo "    UK postal code rejected (HTTP $HTTP_CODE)"
fi

# Test 6: Argentine postal code
echo -e "\n6. Testing Argentine postal code (C1000)..."
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=Maria&lastName=Gonzalez&streetAddress=Av. Corrientes 1234&city=Buenos Aires&stateProvince=CABA&postalCode=C1000&country=Argentina&email=maria@example.com&phone=+54 9 11 1234-5678" \
  -o /dev/null)
if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] Argentine postal code accepted"
else
  echo "    Argentine postal code rejected (HTTP $HTTP_CODE)"
fi

# Test 7: International phone with various formats
echo -e "\n7. Testing various international phone formats..."
HTTP_CODE=$(curl -s -w "%{http_code}" -X POST http://localhost:3536/submit \
  -d "firstName=Pierre&lastName=Dupont&streetAddress= Rue de Rivoli&city=Paris&stateProvince=Ile-de-France&postalCode=75001&country=France&email=pierre@example.com&phone=+33 1 42 86 83 93" \
  -o /dev/null)
if [ "$HTTP_CODE" = "302" ]; then
  echo "   [OK] French phone format accepted"
else
  echo "    French phone format rejected (HTTP $HTTP_CODE)"
fi

echo -e "\n=========================================="
echo "Testing Database Persistence"
echo "=========================================="

# Test 8: Multiple submissions
echo -e "\n8. Testing multiple submissions..."
curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Alice&lastName=Johnson&streetAddress=456 Oak Ave&city=Sydney&stateProvince=NSW&postalCode=2000&country=Australia&email=alice@example.com&phone=+61 2 9374 4000" \
  > /dev/null

curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Bob&lastName=Williams&streetAddress=789 Pine St&city=Tokyo&stateProvince=Tokyo&postalCode=100-0001&country=Japan&email=bob@example.com&phone=+81 3 3224 1234" \
  > /dev/null

if [ -f "data/submissions.sqlite" ]; then
  FILE_SIZE=$(stat -c%s "data/submissions.sqlite" 2>/dev/null || stat -f%z "data/submissions.sqlite" 2>/dev/null)
  if [ "$FILE_SIZE" -gt 100 ]; then
    echo "   [OK] Database file created and has data (${FILE_SIZE} bytes)"
  else
    echo "    Database file too small (${FILE_SIZE} bytes)"
  fi
else
  echo "    Database file not created"
fi

echo -e "\n=========================================="
echo "Testing Thank You Page"
echo "=========================================="

# Test 9: Thank you page
echo -e "\n9. Testing thank you page..."
RESPONSE=$(curl -s "http://localhost:3536/thank-you?firstName=John")
if echo "$RESPONSE" | grep -q "Thank you, John"; then
  echo "   [OK] Thank you page displays name correctly"
else
  echo "    Thank you page doesn't display name"
fi

if echo "$RESPONSE" | grep -q "stranger on the internet"; then
  echo "   [OK] Thank you page has humorous copy"
else
  echo "    Thank you page missing humorous copy"
fi

# Test 10: Form re-rendering with errors
echo -e "\n10. Testing form re-rendering with errors..."
RESPONSE=$(curl -s -X POST http://localhost:3536/submit \
  -d "firstName=Jane&lastName=Doe&email=invalid-email&phone=+1234567890&streetAddress=123 Test&city=Test&stateProvince=Test&postalCode=12345&country=USA")

if echo "$RESPONSE" | grep -q "value=\"Jane\""; then
  echo "   [OK] Form preserves entered values on error"
else
  echo "    Form doesn't preserve entered values"
fi

# Clean up
echo -e "\n=========================================="
echo "Cleanup"
echo "=========================================="
kill $SERVER_PID
wait $SERVER_PID 2>/dev/null

echo -e "\nAll comprehensive tests completed!"
