import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: ReturnType<import('express').Express['listen']>;
let closeServer: (() => void) | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Start the server
  const { app: expressApp, initDatabase } = await import('../../src/server.js');
  await initDatabase();
  server = await new Promise<ReturnType<import('express').Express['listen']>>((resolve) => {
    const srv = expressApp.listen(0, () => resolve(srv));
    closeServer = () => srv.close();
  });
});

afterAll(() => {
  if (closeServer) {
    closeServer();
  }
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');

    const $ = cheerio.load(response.text);

    // Check for all required fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check that form submits to /submit
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="post"]')).toHaveLength(1);

    // Check for labels with proper for attributes
    expect($('label[for="firstName"]').text()).toBe('First name');
    expect($('label[for="lastName"]').text()).toBe('Last name');
    expect($('label[for="email"]').text()).toBe('Email');
    expect($('label[for="phone"]').text()).toBe('Phone number');
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: 'invalid-email',
        phone: '',
      });

    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);

    // Check for error messages
    expect($('.error-list').length).toBeGreaterThan(0);
    const errorText = $('.error-list').text();
    expect(errorText).toContain('required');
    expect(errorText).toContain('valid email');
  });

  it('persists submission and redirects', async () => {
    // The test server runs with its own database context
    // We verify the submission was successful via the redirect behavior
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Baker Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(server)
      .post('/submit')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts international phone formats', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'Maria',
        lastName: 'Gonzalez',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria@example.com',
        phone: '+54 9 11 1234-5678',
      });

    expect(response.status).toBe(302);
  });

  it('accepts various postal code formats', async () => {
    const testCases = [
      { postal: 'SW1A 1AA', country: 'UK' },
      { postal: 'C1000', country: 'Argentina' },
      { postal: 'B1675', country: 'Argentina' },
      { postal: '12345', country: 'US' },
    ];

    for (const testCase of testCases) {
      const response = await request(server)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: testCase.postal,
          country: testCase.country,
          email: 'test@example.com',
          phone: '+1 555-123-4567',
        });

      expect(response.status).toBe(302);
    }
  });

  it('renders thank-you page', async () => {
    const response = await request(server).get('/thank-you');
    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);
    expect($('.thankyou-card').length).toBe(1);
    expect($('a[href="/"]').length).toBe(1);
    // Check for humorous content
    const text = $('body').text();
    expect(text).toMatch(/stranger|internet|spam|identity/i);
  });

  it('rejects invalid email addresses', async () => {
    const invalidEmails = ['not-an-email', '@example.com', 'test@', 'test @example.com'];

    for (const email of invalidEmails) {
      const response = await request(server)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: '12345',
          country: 'Test Country',
          email: email,
          phone: '+1 555-123-4567',
        });

      expect(response.status).toBe(200);
      const $ = cheerio.load(response.text);
      expect($('.error-list').text()).toContain('valid email');
    }
  });

  it('rejects invalid phone numbers', async () => {
    const invalidPhones = ['abc', '123-abc-4567', 'phone!'];

    for (const phone of invalidPhones) {
      const response = await request(server)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'TS',
          postalCode: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone: phone,
        });

      expect(response.status).toBe(200);
      const $ = cheerio.load(response.text);
      expect($('.error-list').text()).toMatch(/phone/i);
    }
  });

  it('preserves user input on validation failure', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Avenue',
        city: 'Testville',
        stateProvince: 'TX',
        postalCode: 'invalid@!',
        country: 'Testland',
        email: 'invalid-email',
        phone: '+1 555-9999',
      });

    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);

    // Check that entered values are preserved
    expect($('input[name="firstName"]').val()).toBe('Jane');
    expect($('input[name="lastName"]').val()).toBe('Smith');
    expect($('input[name="city"]').val()).toBe('Testville');
  });
});
