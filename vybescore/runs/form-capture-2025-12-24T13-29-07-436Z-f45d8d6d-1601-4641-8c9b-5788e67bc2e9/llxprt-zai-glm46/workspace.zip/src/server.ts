import express from 'express';
import { dirname, join } from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';

const __dirname = dirname(fileURLToPath(import.meta.url));
const DB_PATH = join(__dirname, '../data/submissions.sqlite');

interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
let db: Database | null = null;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', join(__dirname, '../views'));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s()\-+]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

function validatePostalCode(postal: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

function validateSubmission(data: Submission): { valid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  if (!data.firstName?.trim()) errors.firstName = 'First name is required';
  if (!data.lastName?.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress?.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city?.trim()) errors.city = 'City is required';
  if (!data.stateProvince?.trim()) errors.stateProvince = 'State/Province/Region is required';
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Postal code must contain only letters, numbers, spaces, and hyphens';
  }
  if (!data.country?.trim()) errors.country = 'Country is required';
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return { valid: Object.keys(errors).length === 0, errors };
}

app.get('/', (_req, res) => {
  res.render('form', { errors: {}, data: {} });
});

app.post('/submit', (req, res) => {
  const data = req.body as Submission;
  const validation = validateSubmission(data);

  if (!validation.valid) {
    return res.status(200).render('form', {
      errors: validation.errors,
      data: data
    });
  }

  if (!db) {
    return res.status(500).send('Database not initialized');
  }

  try {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        data.firstName.trim(),
        data.lastName.trim(),
        data.streetAddress.trim(),
        data.city.trim(),
        data.stateProvince.trim(),
        data.postalCode.trim(),
        data.country.trim(),
        data.email.trim(),
        data.phone.trim()
      ]
    );

    const dataBuffer = db.export();
    writeFileSync(DB_PATH, Buffer.from(dataBuffer));

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: { _form: 'An error occurred while saving your submission. Please try again.' },
      data: data
    });
  }
});

app.get('/thank-you', (_req, res) => {
  res.render('thank-you');
});

async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file) => `node_modules/sql.js/dist/${file}`
  });

  const dataDir = dirname(DB_PATH);
  if (!existsSync(dataDir)) {
    mkdirSync(dataDir, { recursive: true });
  }

  if (existsSync(DB_PATH)) {
    const buffer = readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
    // Don't re-run schema if db exists
  } else {
    db = new SQL.Database();
    const schema = readFileSync(join(__dirname, '../db/schema.sql'), 'utf-8');
    db.exec(schema);
  }
}

let server: ReturnType<typeof app.listen>;

async function startServer() {
  await initDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  server.on('error', (error: NodeJS.ErrnoException) => {
    if (error.syscall !== 'listen') {
      throw error;
    }
    const bind = typeof port === 'string' ? 'Pipe ' + port : 'Port ' + port;
    switch (error.code) {
      case 'EACCES':
        console.error(`${bind} requires elevated privileges`);
        process.exit(1);
        break;
      case 'EADDRINUSE':
        console.error(`${bind} is already in use`);
        process.exit(1);
        break;
      default:
        throw error;
    }
  });
}

function stopServer(): void {
  if (db) {
    db.close();
    db = null;
  }
  if (server) {
    server.close(() => {
      console.log('Server closed gracefully');
      process.exit(0);
    });
  }
}

process.on('SIGTERM', stopServer);
process.on('SIGINT', stopServer);

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, startServer, stopServer, initDatabase };
