/**
 * Base64 alphabet validation regex.
 * Matches strings containing only valid Base64 characters (A-Z, a-z, 0-9, +, /, and optional padding =).
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Checks if a string contains only valid Base64 characters.
 * Accepts both padded and unpadded Base64 input.
 */
function isValidBase64(input: string): boolean {
  // Empty string is considered valid
  if (input.length === 0) {
    return true;
  }
  
  // Must match the Base64 character set
  if (!VALID_BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Padding must only appear at the end
  const paddingStart = input.indexOf('=');
  const hasValidPadding = paddingStart === -1 || input.slice(paddingStart) === '=' || input.slice(paddingStart) === '==';
  if (!hasValidPadding) {
    return false;
  }
  
  // If there's padding, the total length must be a multiple of 4
  // If there's no padding, Node.js can still decode it, so we accept it
  if (paddingStart !== -1) {
    return input.length % 4 === 0;
  }
  
  return true;
}

/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  const buffer = Buffer.from(input, 'utf8');
  return buffer.toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate the input before attempting to decode
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding produced a valid result
    // A length of 0 with non-empty input suggests invalid data
    if (input.length > 0 && buffer.length === 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
