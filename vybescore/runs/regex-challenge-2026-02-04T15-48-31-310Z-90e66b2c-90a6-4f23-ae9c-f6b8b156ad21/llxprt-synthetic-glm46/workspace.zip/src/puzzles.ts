/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex to match whole words that start with the prefix
  // Use b for word boundaries to ensure we match complete words
  const prefixRegex = new RegExp(`\\b${prefix}\\w+`, 'g');
  
  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const results = matches.filter(word => 
    !exceptions.some(exception => 
      exception.toLowerCase() === word.toLowerCase()
    )
  );
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex using lookbehind and lookahead:
  // (?<=\d) - positive lookbehind for a digit (token must be preceded by a digit)
  // [token] - the actual token
  // (?!) - negative lookahead to ensure token is not at start of string
  // g - global flag to find all matches
  const tokenRegex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(tokenRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check required character classes
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\|,.<>\/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  // This looks for any pattern of 2+ characters that appears immediately wiederholt
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) return false;
  
  // Additional check for simple patterns like 1234, abcd, etc.
  const hasSimpleSequence = /(.)\1{2,}/; // Three or more consecutive same characters
  if (hasSimpleSequence.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv4 pattern to exclude (ensure we don't match IPv4 as IPv6)
  const ipv4Pattern = /\\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\b/;
  
  // If it looks like IPv4, it's not IPv6
  if (ipv4Pattern.test(value)) return false;
  
  // IPv6 patterns including shorthand :: notation
  // Full IPv6: eight groups of four hex digits
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: shorthand (compressed format)
  const ipv6Compressed = /(?:[0-9a-fA-F]{1,4}:){1,7}:|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with IPv4 embedded (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check for any IPv6 pattern
  return ipv6Full.test(value) || ipv6Compressed.test(value) || ipv6WithIPv4.test(value);
}
