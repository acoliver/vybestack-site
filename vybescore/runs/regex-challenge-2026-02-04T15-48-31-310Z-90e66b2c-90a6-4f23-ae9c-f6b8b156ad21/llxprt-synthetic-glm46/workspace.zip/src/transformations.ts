/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Normalize multiple spaces to single spaces first
  const normalizedText = text.replace(/\s+/g, ' ');
  
  // Split into sentences based on .?! ending punctuation
  // Use positive lookahead to keep the punctuation with the sentence
  const sentences = normalizedText.split(/(?<=[.!?])(?=\s|$)/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Trim whitespace and check if sentence has content
    const trimmed = sentence.trim();
    if (!trimmed) return '';
    
    // Capitalize the first character
    const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
    
    return capitalized;
  });
  
  // Join sentences with exactly one space between them
  let result = processedSentences.filter(s => s.length > 0).join(' ');
  
  // Ensure single space after punctuation, collapsing extra spaces
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  return result.trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern that matches:
  // - http:// and https:// protocols
  // - domain names with subdomains
  // - paths, query strings, and fragments
  // - optional port numbers
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/g;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  // Clean URLs by removing trailing punctuation
  const cleanedUrls = matches ? matches.map(url => 
    url.replace(/[.,;:!?)\]}]+$/, '')
  ) : [];
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// using regex
  // This will only replace http:// at the beginning of URLs, not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Regex to match http://example.com URLs
  // This captures the protocol, domain, and path
  const urlRegex = /(http:\/\/example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if path should trigger host rewrite
    // Skip host rewrite for paths containing dynamic hints or legacy extensions
    const hasDynamicHints = /cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite host to docs.example.com for /docs/ paths without dynamic hints
      return newProtocol + 'docs.example.com' + path;
    } else {
      // Just upgrade protocol, keep original host
      return newProtocol + 'example.com' + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Regex to match mm/dd/yyyy format and capture groups
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  // Extract year (third capture group)
  return match[3];
}
