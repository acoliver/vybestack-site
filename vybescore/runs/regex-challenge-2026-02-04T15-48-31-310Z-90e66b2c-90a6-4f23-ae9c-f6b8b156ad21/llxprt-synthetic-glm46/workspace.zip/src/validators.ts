export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that:
  // - Allows typical addresses like name@tag@example.co.uk
  // - Rejects double dots, trailing dots
  // - Rejects domains with underscores
  // - Rejects other obviously invalid forms
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for invalid patterns
  const hasDoubleDot = /\.\./;
  const hasTrailingDotLocal = /\.$/;
  const hasUnderscoreInDomain = /_.*@/;
  
  return emailRegex.test(value) && 
         !hasDoubleDot.test(value) && 
         !hasTrailingDotLocal.test(value) && 
         !hasUnderscoreInDomain.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Clean the input to remove separators and spaces
  const cleanNumber = value.replace(/[\s-(\)]/g, '');
  
  // Phone validation regex that supports:
  // - Optional +1 country code
  // - (212) 555-7890, 212-555-7890, 2125557890 formats
  // - Disallows area codes starting with 0 or 1
  const phoneRegex = /^(?:\+?1)?([2-9]\d{2})([2-9]\d{2})\d{4}$/;
  
  // Check minimum length (7 digits without area code, 10 with area code)
  const minLength = 7;
  const maxLength = 11; // 10 digits + optional 1 for country code
  
  return cleanNumber.length >= minLength && 
         cleanNumber.length <= maxLength &&
         phoneRegex.test(cleanNumber);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input by removing spaces, hyphens, and parentheses
  const cleanNumber = value.replace(/[\s-(\)]/g, '');
  
  // Argentine phone validation regex that supports:
  // - Optional country code +54
  // - Optional trunk prefix 0 before area code
  // - Optional mobile indicator 9 between country/trunk and area code
  // - Area code 2-4 digits (leading digit 1-9)
  // - Subscriber number 6-8 digits
  const argentinePhoneRegex = /^(?:\+?54)?(?:0)?(?:9)?([1-9]\d{0,3})(\d{6,8})$/;
  
  // When country code is omitted (no +54), number must begin with trunk prefix 0
  const hasCountryCode = /^\+?54/.test(cleanNumber);
  const hasTrunkPrefix = /^0/.test(cleanNumber);
  
  // Validate format and business rules
  return argentinePhoneRegex.test(cleanNumber) && 
         (hasCountryCode || hasTrunkPrefix);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
// Name validation regex that allows:
  // - Unicode letters and accents
  // - Apostrophes and hyphens
  // - Spaces
  // - Rejects digits, symbols, and special characters
  
  // The regex pattern:
  // ^: start of string
  // [\p{L}]+: one or more unicode letters
  // (?:[ '\-][\p{L}]+)*: zero or more groups of space, apostrophe, or hyphen followed by letters
  // $: end of string
  const nameRegex = /^[\p{L}]+(?:[ '-][\p{L}]+)*$/u;
  
  // Additionally check that the name contains at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  
  return nameRegex.test(value) && hasLetter && value.trim().length > 0;
}

/**
 * Luhn checksum algorithm helper function
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Clean the input by removing spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Card validation regex that supports:
  // - Visa: starts with 4, 13 or 16 digits
  // - Mastercard: starts with 51-55 or 2221-2720, 16 digits  
  // - American Express: starts with 34 or 37, 15 digits
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  const mastercardRegex = /^(?:5[1-5]\d{2}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check against card patterns
  const validPattern = visaRegex.test(cleanNumber) || 
                      mastercardRegex.test(cleanNumber) || 
                      amexRegex.test(cleanNumber);
  
  // Must be digits only and pass Luhn check
  const digitsOnly = /^\d+$/.test(cleanNumber);
  
  return validPattern && digitsOnly && runLuhnCheck(cleanNumber);
}
