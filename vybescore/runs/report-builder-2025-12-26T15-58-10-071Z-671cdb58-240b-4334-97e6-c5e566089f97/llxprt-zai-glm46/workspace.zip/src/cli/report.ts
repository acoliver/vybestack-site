#!/usr/bin/env node

/**
 * Report Builder CLI
 * Renders reports from JSON input in various formats.
 */

import * as fs from 'node:fs';
import { validateReportData } from '../utils.js';
import { getFormatter, supportedFormats } from '../formats/index.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments.
 * Expected format: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */
function parseArgs(argv: string[]): CliArgs {
  if (argv.length < 3) {
    printUsage();
    process.exit(1);
  }

  const args = argv.slice(2);
  const inputFile = args[0];
  const options: CliArgs = {
    inputFile,
    format: '',
    includeTotals: false,
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--format':
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        options.format = args[i];
        break;

      case '--output':
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        options.outputPath = args[i];
        break;

      case '--includeTotals':
        options.includeTotals = true;
        break;

      default:
        console.error(`Error: Unknown option: ${arg}`);
        printUsage();
        process.exit(1);
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    console.error(`Supported formats: ${supportedFormats.join(', ')}`);
    process.exit(1);
  }

  return options;
}

/**
 * Prints usage information.
 */
function printUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Arguments:');
  console.error('  data.json       Path to the JSON file containing report data');
  console.error('');
  console.error('Options:');
  console.error('  --format <fmt>  Output format (required). Supported: markdown, text');
  console.error('  --output <path> Write output to file instead of stdout (optional)');
  console.error('  --includeTotals Include total amount calculation (optional)');
}

/**
 * Reads and parses a JSON file.
 */
function readJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

/**
 * Main entry point.
 */
function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Validate format
    try {
      getFormatter(args.format);
    } catch (error) {
      if (error instanceof Error && error.message.includes('Unsupported format')) {
        console.error(`Error: Unsupported format: ${args.format}`);
        console.error(`Supported formats: ${supportedFormats.join(', ')}`);
        process.exit(1);
      }
      throw error;
    }

    // Read and parse input file
    let rawData: unknown;
    try {
      rawData = readJsonFile(args.inputFile);
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error: ${error.message}`);
      } else {
        console.error('Error: Failed to read input file');
      }
      process.exit(1);
    }

    // Validate report data structure
    const reportData = validateReportData(rawData);

    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    const formatter = getFormatter(args.format);
    const output = formatter(reportData, options);

    // Write output
    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Failed to write output to ${args.outputPath}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
