#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      args.format = argv[++i] || '';
    } else if (arg === '--output') {
      args.output = argv[++i] || '';
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      args.dataFile = arg;
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Format is required (markdown or text)');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Error: Unsupported format '${args.format}'. Supported formats: markdown, text`);
    process.exit(1);
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (typeof data.title !== 'string' || !data.title.trim()) {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (typeof data.summary !== 'string' || !data.summary.trim()) {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string' || !entry.label.trim()) {
        throw new Error(`Entry ${i + 1}: missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File '${filePath}' not found`);
      } else if (error.message.includes('JSON.parse')) {
        console.error('Error: Invalid JSON format');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to load report data');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      // This should not happen due to validation, but safety check
      console.error(`Unsupported format '${format}'. Supported formats: markdown, text`);
      process.exit(1);
      return '';
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);
  
  const data = loadReportData(args.dataFile);
  const options: RenderOptions = { includeTotals: args.includeTotals };
  
  const output = renderReport(data, args.format, options);
  
  if (args.output) {
    try {
      writeFileSync(args.output, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file '${args.output}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();