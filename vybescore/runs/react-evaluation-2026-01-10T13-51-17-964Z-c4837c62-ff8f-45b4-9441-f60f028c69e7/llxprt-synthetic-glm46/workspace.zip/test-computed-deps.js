import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing computed dependencies...');

const [input, setInput] = createInput(1);

const debugTimesTwo = () => {
  const result = input() * 2;
  console.log('times recomputing, input is', input(), 'result is', result);
  return result;
};

const timesTwo = createComputed(debugTimesTwo);

const debugTimesThirty = () => {
  const result = input() * 30;
  console.log('timesThirty recomputing, input is', input(), 'result is', result);
  return result;
};

const timesThirty = createComputed(debugTimesThirty);

let sumCallCount = 0;
const sumComputed = () => {
  sumCallCount++;
  const twoVal = timesTwo();
  const thirtyVal = timesThirty();
  console.log(`sum recomputing #${sumCallCount}, timesTwo=${twoVal}, timesThirty=${thirtyVal}`);
  return twoVal + thirtyVal;
};

const sum = createComputed(sumComputed);

console.log('Initial sum:', sum());
setInput(3);
console.log('Sum after changing input to 3:', sum());