/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Store all dependencies for cleanup
  const dependencies = new Set<Subject<T>>()
  
  // Function to remove this observer from all dependencies
  const removeFromDependencies = (): void => {
    dependencies.forEach(subject => {
      if (subject.observers) {
        subject.observers.delete(observer)
      }
    })
    dependencies.clear()
  }
  
  // Add this observer to any subject that notifies during execution
  const trackDependency = (subject: Subject<T>): void => {
    dependencies.add(subject)
    if (!subject.observers) {
      subject.observers = new Set()
    }
    subject.observers.add(observer)
  }
  
  // Manually hook into all subjects during execution
  // In a real reactive system this would be automatic
  const globalAddObserver = (subject: Subject<T>): void => {
    if (!subject.observers) {
      subject.observers = new Set()
    }
    subject.observers.add(observer)
  }
  // This function is used in the closure to track dependencies
  void globalAddObserver
  
  // Initial execution to track dependencies
  const executeCallback = async (): Promise<void> => {
    // Clear previous dependencies
    removeFromDependencies()
    
    // Run the observer to track new dependencies
    await updateObserver(observer)
    
// Track all active subjects after execution
    // This is a simplified approach
    if (typeof globalThis !== 'undefined') {
      // Use unknown type assertion with proper type guard
      const globalUnknown = globalThis as unknown as Record<string, unknown>
      const activeSubjects = globalUnknown.__activeSubjects
      
      if (activeSubjects instanceof Set) {
        activeSubjects.forEach((subject: unknown) => {
          if (subject && typeof subject === 'object') {
            trackDependency(subject as Subject<T>)
          }
        })
      }
    }
  }
  
  // Initial execution
  void executeCallback()
  
  let disposed = false
  
  const unsubscribe = (): void => {
    if (disposed) return
    disposed = true
    
    // Remove from all tracked dependencies
    removeFromDependencies()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
