/**
 * Core reactivity system implementation with proper dependency tracking.
 */

import { Subject, Observer, updateObserver, getCurrentObserver } from '../types/reactive.js'

// Active dependency tracking
export function trackDependency<T>(subject: Subject<T>): void {
  const currentObserver = getCurrentObserver()
  
  if (currentObserver && subject.observers) {
    subject.observers.add(currentObserver as Observer<T>)
  }
}

export function notifyObservers<T>(subject: Subject<T>): Promise<void> {
  if (subject.observers) {
    // Create a copy to avoid issues with observers modifying the set during iteration
    const observers = Array.from(subject.observers)
    
    // Use Promise to handle async updates
    const updatePromises = observers.map(async observer => {
      try {
        await updateObserver(observer as Observer<T>)
      } catch (error) {
        console.error('Error updating observer:', error)
      }
    })
    
    return Promise.all(updatePromises).then(() => {})
  }
  
  return Promise.resolve()
}