/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  Subject,
  getCurrentObserver,
  setCurrentObserver,
  trackDependency
} from '../types/reactive.js'

import { notifyObservers } from './reactivity-system.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const computedAsSubject = observer as unknown as Subject<T>
  
  // Set up observers set for the computed subject
  if (!computedAsSubject.observers) {
    computedAsSubject.observers = new Set()
  }

  // Track dependencies to know when to recompute
  const dependencies = new Set<Subject<any>>()

  let isUpdating = false
  let needsRecompute = true

  // Create a special observer that will trigger recomputation when dependencies change
  const computedObserver: Observer<any> = {
    name: `computed-notification-${options?.name || 'anonymous'}`,
    updateFn: () => {
      needsRecompute = true
      return observer.value
    }
  }

  // Subscribe to dependency changes
  const subscribeToDependency = (subject: Subject<any>): void => {
    dependencies.add(subject)
    if (!subject.observers) {
      subject.observers = new Set()
    }
    
    // Add both the main observer (for direct recompute) and the notification observer (for marking stale)
    subject.observers.add(computedObserver)
    subject.observers.add(observer)
  }

  // Override notifyObservers to track when dependencies change
  const originalTrackDependency = trackDependency
  const customTrackDependency = (subject: Subject<any>): void => {
    // Track the dependency if not already tracked
    if (!dependencies.has(subject)) {
      subscribeToDependency(subject)
    }
    originalTrackDependency(subject)
  }

  // Store the original computed values getter to see when its dependencies are accessed
  let cachedValue: T
  let hasCachedValue = false

  const getter: GetterFn<T> = () => {
    // When accessed, this computed value needs to be tracked as a dependency
    const currentObserver = getCurrentObserver()
    if (currentObserver) {
      if (!computedAsSubject.observers) {
        computedAsSubject.observers = new Set()
      }
      computedAsSubject.observers.add(currentObserver)
    }
    
    // Ensure dependencies are subscribed to
    dependencies.forEach(subject => {
      if (!subject.observers || !subject.observers.has(computedObserver)) {
        subscribeToDependency(subject)
      }
    })
    
    // Return cached value if available and valid
    if (hasCachedValue && !needsRecompute) {
      return cachedValue
    }
    
    // Compute the value and track dependencies
    const prevObserver = getCurrentObserver()
    setCurrentObserver(observer || undefined)
    
    // Override global tracking mechanism for dependency tracking
    const activeSubjectsKey = '__activeSubjects'
    const originalSubjects = (globalThis as any)[activeSubjectsKey] || new Set()
    const newSubjects = new Set<Subject<any>>()
    ;(globalThis as any)[activeSubjectsKey] = newSubjects
    
    // Temporarily override trackDependency function
    const reactiveModule = (globalThis as any)
    const originalGlobalTrackDependency = reactiveModule.trackDependency
    reactiveModule.trackDependency = customTrackDependency
    
    try {
      observer.value = updateFn(cachedValue)
      cachedValue = observer.value!
      hasCachedValue = true
      needsRecompute = false
      
      // Subscribe to all accessed subjects
      newSubjects.forEach(subject => {
        subscribeToDependency(subject)
      })
      
      return cachedValue
    } finally {
      // Restore everything
      setCurrentObserver(prevObserver || undefined)
      ;(globalThis as any)[activeSubjectsKey] = originalSubjects
      reactiveModule.trackDependency = originalGlobalTrackDependency
    }
  }

  // Initial computation
  getter()

  return getter
}
