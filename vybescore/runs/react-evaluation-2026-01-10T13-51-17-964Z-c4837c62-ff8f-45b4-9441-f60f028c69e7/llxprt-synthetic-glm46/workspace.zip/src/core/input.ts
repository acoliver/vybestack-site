/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  trackDependency
} from '../types/reactive.js'

import { notifyObservers } from './reactivity-system.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal as EqualFn<T>
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    // Track this input as a dependency
    trackDependency(s)
    
    // Also add to global active subjects tracking
    const activeSubjectsKey = '__activeSubjects'
    const activeSubjects = (globalThis as any)[activeSubjectsKey] || new Set()
    activeSubjects.add(s)
    ;(globalThis as any)[activeSubjectsKey] = activeSubjects
    
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      
      // Notify all observers that this value has changed
      void notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
