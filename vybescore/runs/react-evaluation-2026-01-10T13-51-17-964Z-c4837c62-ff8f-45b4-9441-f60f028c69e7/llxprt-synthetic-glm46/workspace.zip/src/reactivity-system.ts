/**
 * Global dependency tracking system.
 */

import { ObserverR } from './types/reactive.js';

export let currentObserver: ObserverR | null = null;

export function getCurrentObserver(): ObserverR | null {
  return currentObserver;
}

export function setCurrentObserver(observer: ObserverR | null): void {
  currentObserver = observer;
}

export function clearCurrentObserver(): void {
  currentObserver = null;
}