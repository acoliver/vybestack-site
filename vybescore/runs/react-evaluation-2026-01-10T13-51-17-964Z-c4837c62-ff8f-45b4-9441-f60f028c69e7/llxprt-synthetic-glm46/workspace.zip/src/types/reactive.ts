/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

// Simple synchronous tracking without complex module loading
export function getCurrentObserver(): ObserverR | null {
  return (globalThis as unknown as Record<string, unknown>).__currentObserver as ObserverR | null || null
}

export function trackDependency<T>(subject: Subject<T>): void {
  const currentObserver = getCurrentObserver()
  if (currentObserver && subject.observers) {
    subject.observers.add(currentObserver)
  }
}

export function setCurrentObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
  ;(globalThis as unknown as Record<string, unknown>).__currentObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): Promise<void> {
  const previous = activeObserver
  activeObserver = observer as ObserverR
  ;(globalThis as unknown as Record<string, unknown>).__currentObserver = observer
  
  try {
    // Access getter functions will track dependencies
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    ;(globalThis as unknown as Record<string, unknown>).__currentObserver = previous || null
  }
  
  return Promise.resolve()
}
