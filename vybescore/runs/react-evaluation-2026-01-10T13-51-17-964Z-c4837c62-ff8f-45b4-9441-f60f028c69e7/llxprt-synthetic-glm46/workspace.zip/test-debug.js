import { createInput, createComputed, createCallback } from './src/index.js'

console.log('Testing dependency tracking...');

const [input, setInput] = createInput(1);
console.log('input() initial:', input());

const timesTwo = createComputed(() => {
  console.log('timesTwo computed, current input:', input());
  return input() * 2;
});

const timesThirty = createComputed(() => {
  console.log('timesThirty computed, current input:', input());
  return input() * 30;
});

const sum = createComputed(() => {
  console.log('sum computed, timesTwo:', timesTwo(), 'timesThirty:', timesThirty());
  return timesTwo() + timesThirty();
});

console.log('sum() initial:', sum());
console.log('Changing input to 3');
setInput(3);
console.log('input() after change:', input());
console.log('sum() after change:', sum());