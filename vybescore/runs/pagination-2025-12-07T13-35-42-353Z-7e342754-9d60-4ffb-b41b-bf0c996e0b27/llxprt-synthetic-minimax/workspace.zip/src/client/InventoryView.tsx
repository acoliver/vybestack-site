import React from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  total, 
  limit, 
  onPageChange 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  total: number; 
  limit: number; 
  onPageChange: (page: number) => void; 
}): JSX.Element {
  const totalPages = Math.ceil(total / limit);
  const canGoPrevious = currentPage > 1;
  const canGoNext = hasNext;

  return (
    <div style={{ display: 'flex', gap: '8px', alignItems: 'center', marginTop: '16px' }}>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={!canGoPrevious}
        style={{ padding: '4px 8px' }}
      >
        Previous
      </button>
      
      <span>Page {currentPage} of {totalPages}</span>
      
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!canGoNext}
        style={{ padding: '4px 8px' }}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = React.useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  // Handle empty state
  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No inventory items found.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={currentPage}
        hasNext={data.hasNext}
        total={data.total}
        limit={data.limit}
        onPageChange={setCurrentPage}
      />
    </section>
  );
}
