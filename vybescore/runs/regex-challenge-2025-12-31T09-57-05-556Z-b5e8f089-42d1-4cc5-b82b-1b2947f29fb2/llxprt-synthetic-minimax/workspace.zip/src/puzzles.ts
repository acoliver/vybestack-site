/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
 
  // Find all matches
  const matches = text.match(prefixPattern) || [];
 
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
 
  const filteredMatches = matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptionsSet.has(lowercaseMatch);
  });
 
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token occurrences after digits and not at beginning
  const matches: string[] = [];
  let index = 0;
 
  // Find all occurrences of the token
  while ((index = text.indexOf(token, index)) !== -1) {
    // Check if not at beginning and preceded by a digit
    if (index > 0 && /\d/.test(text.charAt(index - 1))) {
      // Return the full context (digit + token) as expected by test
      matches.push(text.charAt(index - 1) + token);
    }
    index += token.length;
  }
 
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length requirement: at least 10 characters
  if (value.length < 10) {
    return false;
  }
 
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
 
  // Must contain: one uppercase, one lowercase, one digit, one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  // Simpler symbol pattern to avoid lint errors
  const hasSymbol = /[!@#$%^&*()_+={};:'"|,.<>?]/.test(value);
 
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
 
  // No immediate repeated sequences (e.g., "abab", "1212", "xyzxyz")
  const repeatedSequencePattern = /^(.+)\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
 
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if this looks like an IP address at all
  if (!value.includes(':')) {
    return false;
  }
 
  // IPv6 addresses cannot be all decimal digits (IPv4 characteristic)
  const isAllDecimal = /^[0-9.:]+$/.test(value);
  if (isAllDecimal) {
    return false;
  }
 
  // More flexible IPv6 pattern including shorthand with double colon
  const ipv6Patterns = [
    // Standard notation with potential shortening
    /^(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{0,4}(?::[a-fA-F0-9]{0,4}){0,7}$/,
    // Pattern specifically for double colon shorthand like 2001:db8::1
    /^(?:[a-fA-F0-9]{0,4}:){0,6}[a-fA-F0-9]{0,4}::(?:[a-fA-F0-9]{0,4}:){0,6}[a-fA-F0-9]{0,4}$/,
    // Simple double colon patterns
    /.*::.*/
  ];
 
  // Check against IPv6 patterns
  const matchesPattern = ipv6Patterns.some(pattern => pattern.test(value));
 
  // Additional check: must contain hex digits and colons
  const hasHexAndColons = /[a-fA-F0-9]:/.test(value);
 
  // Exclude pure IPv4 format (dotted decimal)
  const isPureIpv4 = /^[0-9]+(?:\.[0-9]+){3}$/.test(value);
 
  return matchesPattern && hasHexAndColons && !isPureIpv4;
}
