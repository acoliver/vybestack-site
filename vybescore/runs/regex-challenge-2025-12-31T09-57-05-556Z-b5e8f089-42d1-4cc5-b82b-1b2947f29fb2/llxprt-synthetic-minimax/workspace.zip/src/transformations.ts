/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences by finding sentence boundaries
  // Handle cases where sentences are separated by just periods without spaces
  const sentences = text.split(/(?<=[.!?])(?=\s|$|[A-Z])/);
 
  // Capitalize first letter of each sentence
  const result = sentences.map((sentence) => {
    if (sentence.length === 0) return sentence;
 
    // Trim leading spaces and capitalize first letter
    const trimmed = sentence.trimStart();
    if (trimmed.length === 0) return sentence;
 
    const firstChar = trimmed.charAt(0).toUpperCase();
    const rest = trimmed.slice(1);
 
    // Reconstruct sentence with proper spacing
    const leadingSpaces = sentence.match(/^\s+/)?.[0] || '';
    return leadingSpaces + firstChar + rest;
  });
 
  // Join sentences with appropriate spacing
  return result.join('').replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http(s)://, www., or domain.tld
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s)]*[a-zA-Z0-9]*(?:\.[a-zA-Z0-9]+)*[^\s)]*|(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}[^\s)]*[a-zA-Z0-9]*[^\s)]*/g;
 
  const matches = text.match(urlRegex) || [];
 
  // Clean up URLs by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove common trailing punctuation but ensure we keep valid domain endings
    return url.replace(/[.,!?]+$/, '');
  });
 
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using regex
  const httpsRegex = /\bhttp:\/\/[^\s]+/g;
 
  return text.replace(httpsRegex, (match) => match.replace(/^http:\/\//, 'https://'));
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Use a more straightforward approach
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)/g, (match, host, path) => {
    const isDocsPath = path.startsWith('/docs/');
    const hasDynamicHints = /(cgi-bin|\?|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path + match);
 
    if (hasDynamicHints) {
      // Skip host rewrite, only upgrade scheme
      return match.replace(/^http:\/\//, 'https://');
    } else if (isDocsPath) {
      // For docs paths: rewrite host to docs.example.com
      return 'https://docs.' + host + path;
    } else {
      // Upgrade scheme for non-docs URLs
      return 'https://' + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
 
  if (!match) {
    return 'N/A';
  }
 
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
 
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
 
  // Basic year validation (reasonable range)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
 
  return year.toString();
}
