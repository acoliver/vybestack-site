/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  const wordPattern = new RegExp('\\b(' + escapedPrefix + '[a-zA-Z]*)\\b', 'g');
  
  const matches = text.match(wordPattern);
  if (!matches) return [];
  
  // Filter out exceptions and return unique results
  const exceptionsSet = new Set(exceptions);
  const result = matches.filter(match => !exceptionsSet.has(match));
  
  // Return unique values
  return Array.from(new Set(result));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the digit + token combination (e.g., "1foo" for token "foo" after digit "1").
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of digit+token where there's at least one character before the digit
  // Use lookbehind to ensure we're not at the start, and lookahead to ensure token ends properly
  const pattern = new RegExp('(?<=.)(\\d' + escapedToken + ')(?=[^a-zA-Z0-9]|$)', 'g');
  
  const matches = text.match(pattern);
  return matches ? Array.from(new Set(matches)) : [];
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for repeated sequences (e.g., abab, 123123)
  // Only check for sequences of length 2 or more that repeat
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 pattern (various formats including shorthand)
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can replace one or more consecutive groups of zeros
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // Ensure it's not just an IPv4 address
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  if (ipv4Pattern.test(value.trim())) return false;
  
  return ipv6Pattern.test(value);
}
