/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after . ? ! followed by whitespace
 * - Inserts exactly one space between sentences if missing
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First, normalize multiple spaces to single space (but preserve newlines)
  let result = text.replace(/[ \t]+/g, ' ');
  
  // Insert space after sentence endings if missing (when followed by letter)
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first character of the string
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  // Capitalize after . ? ! when followed by a letter
  result = result.replace(/([.!?])['"]?\s+([a-z])/g, (_, punct, letter) => 
    `${punct} ${letter.toUpperCase()}`
  );
  
  // Also capitalize after newline (start of new line)
  result = result.replace(/(\n|\r\n)([a-z])/g, (_, newline, letter) => 
    `${newline}${letter.toUpperCase()}`
  );
  
  return result;
}

/**
 * Find all URLs in the text, returning them without trailing punctuation.
 * Detects http://, https://, and www-prefixed URLs.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL pattern: http://, https://, or www. followed by domain and path
  // Exclude trailing punctuation (.,;!?)
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9\-._~:/?#[@!$&'()*+,;=%]+[a-zA-Z0-9\-_~:/?#@!$&'()*+,=%]/g;
  
  const matches = text.match(urlPattern);
  
  if (!matches) return [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation marks
    return url.replace(/[.,;!?]+$/, '');
  });
}

/**
 * Force all http:// URLs to https://, leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:)(\/\/[^/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Extract hostname without //
    const hostname = host.replace(/^\/\//, '');
    
    // Always upgrade scheme to https
    const newScheme = 'https://';
    
    // Check if path should skip host rewrite
    // Skip if contains cgi-bin, query strings, or legacy extensions
    const skipHostRewrite = /\/cgi-bin\/|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(path);
    
    // Check if path starts with /docs/
    const startsWithDocs = /^\/docs\//i.test(path);
    
    // Rewrite host if path starts with /docs/ and no skip conditions
    if (startsWithDocs && !skipHostRewrite) {
      const newHost = `docs.${hostname}`;
      return `${newScheme}${newHost}${path}`;
    }
    
    // Otherwise just upgrade the scheme
    return `${newScheme}${hostname}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted dates.
 * Returns 'N/A' if format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return yearStr;
}
