export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using RFC 5322-style patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  const [local, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (local.includes('..') || domain.includes('..')) return false;
  
  // Reject trailing/leading dots in local part
  if (local.startsWith('.') || local.endsWith('.')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  // Reject domain starting/ending with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) return false;
  
  // Check that each domain label is valid
  const labels = domain.split('.');
  for (const label of labels) {
    if (label.startsWith('-') || label.endsWith('-')) return false;
    if (!/^[a-zA-Z0-9-]+$/.test(label)) return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects: impossible area codes (leading 0/1), too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits for US number)
  if (digits.length < 10) return false;
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (digits.length === 11 && digits.startsWith('1')) {
    phoneNumber = digits.slice(1);
  } else if (digits.length > 11) {
    return false;
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (first digit of central office code) cannot be 0 or 1
  const exchangeCode = phoneNumber[3];
  if (exchangeCode === '0' || exchangeCode === '1') return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers for mobile and landline formats.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - When country code omitted, must begin with trunk prefix 0
 * - Allows single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces, hyphens, and plus sign for validation
  const normalized = value.replace(/[\s-+]/g, '');
  
  // Full pattern with country code: 54 + optional 9 + area code (2-4 digits) + subscriber (6-8 digits)
  const withCountryMatch = normalized.match(/^54(9)?([1-9]\d{1,3})(\d{6,8})$/);
  
  if (withCountryMatch) {
    const [, , areaCode, subscriber] = withCountryMatch;
    // Area code: 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    // Subscriber: 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    return true;
  }
  
  // Pattern without country code (must start with trunk prefix 0)
  const withoutCountryMatch = normalized.match(/^0([1-9]\d{1,3})(\d{6,8})$/);
  
  if (withoutCountryMatch) {
    const [, areaCode, subscriber] = withoutCountryMatch;
    // Area code: 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    // Subscriber: 6-8 digits
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    return true;
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, and "X Æ A-12" style names with digits.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Name should only contain: unicode letters, apostrophes, hyphens, spaces
  // Must contain at least one letter
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter (not just spaces/apostrophes/hyphens)
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Cannot contain only symbols/spaces
  const trimmed = value.trim();
  if (trimmed.length === 0) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit card numbers.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with prefix, length, and Luhn checksum.
 * Visa: starts with 4, length 13 or 16
 * Mastercard: starts with 51-55 or 2221-2720, length 16
 * AmEx: starts with 34 or 37, length 15
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const normalized = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(normalized)) return false;
  
  const length = normalized.length;
  
  // Visa: 13 or 16 digits, starts with 4
  if ((length === 13 || length === 16) && normalized.startsWith('4')) {
    return runLuhnCheck(normalized);
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (length === 16) {
    if (/^5[1-5]/.test(normalized) || /^2[2-7][0-9]{2}/.test(normalized)) {
      return runLuhnCheck(normalized);
    }
  }
  
  // AmEx: 15 digits, starts with 34 or 37
  if (length === 15 && (normalized.startsWith('34') || normalized.startsWith('37'))) {
    return runLuhnCheck(normalized);
  }
  
  return false;
}
