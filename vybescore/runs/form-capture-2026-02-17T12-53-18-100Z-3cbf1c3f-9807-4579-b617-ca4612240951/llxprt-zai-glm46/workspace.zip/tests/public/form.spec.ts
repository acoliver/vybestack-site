import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server.js';

type ServerInstance = { app: ReturnType<typeof import('express')>; port: number; close: () => Promise<void> };

let serverInstance: ServerInstance | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Start the server
  serverInstance = await startServer();
});

afterAll(async () => {
  if (serverInstance) {
    await serverInstance.close();
  }

  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(serverInstance!.app).get('/');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    const $ = cheerio.load(response.text);

    // Check all form fields exist with proper labels and attributes
    const fields = [
      { id: 'firstName', label: 'First name', name: 'firstName' },
      { id: 'lastName', label: 'Last name', name: 'lastName' },
      { id: 'streetAddress', label: 'Street address', name: 'streetAddress' },
      { id: 'city', label: 'City', name: 'city' },
      { id: 'stateProvince', label: 'State / Province / Region', name: 'stateProvince' },
      { id: 'postalCode', label: 'Postal / Zip code', name: 'postalCode' },
      { id: 'country', label: 'Country', name: 'country' },
      { id: 'email', label: 'Email', name: 'email' },
      { id: 'phone', label: 'Phone number', name: 'phone' },
    ];

    for (const field of fields) {
      // Check input exists
      const input = $(`#${field.id}`);
      expect(input.length).toBeGreaterThan(0);

      // Check name attribute
      expect(input.attr('name')).toBe(field.name);

      // Check associated label
      const label = $(`label[for="${field.id}"]`);
      expect(label.length).toBeGreaterThan(0);
      expect(label.text()).toContain(field.label);
    }

    // Check form action and method
    const form = $('form[action="/submit"]');
    expect(form.length).toBeGreaterThan(0);
    expect(form.attr('method')).toBe('post');
  });

  it('shows validation errors for empty required fields', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: '',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    const errorList = $('.error-list');
    expect(errorList.length).toBeGreaterThan(0);
    expect(errorList.find('li').length).toBeGreaterThan(0);
  });

  it('shows validation errors for invalid email', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'not-a-valid-email',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/email/i);
  });

  it('shows validation errors for invalid phone', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone@#$',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/phone/i);
  });

  it('shows validation errors for invalid postal code', async () => {
    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: 'invalid@#123',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1 555-123-4567',
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/postal/i);
  });

  it('preserves entered values on validation error', async () => {
    const testData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Denver',
      stateProvince: 'CO',
      postalCode: '80202',
      country: 'USA',
      email: 'invalid-email',
      phone: '+1 555-987-6543',
    };

    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send(testData);

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);

    expect($('#firstName').attr('value')).toBe(testData.firstName);
    expect($('#lastName').attr('value')).toBe(testData.lastName);
    expect($('#streetAddress').attr('value')).toBe(testData.streetAddress);
    expect($('#city').attr('value')).toBe(testData.city);
  });

  it('persists submission and redirects on success', async () => {
    const testData = {
      firstName: 'Alice',
      lastName: 'Johnson',
      streetAddress: '789 Pine St',
      city: 'Seattle',
      stateProvince: 'WA',
      postalCode: '98101',
      country: 'USA',
      email: 'alice@example.com',
      phone: '+1 555-111-2222',
    };

    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send(testData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database was created and contains the submission
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles international phone formats', async () => {
    const testData = {
      firstName: 'Bob',
      lastName: 'International',
      streetAddress: '10 Downing St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 2AA',
      country: 'UK',
      email: 'bob@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send(testData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('handles alphanumeric postal codes', async () => {
    const testData = {
      firstName: 'Carlos',
      lastName: 'Garcia',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send(testData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('renders thank-you page', async () => {
    const response = await request(serverInstance!.app).get('/thank-you');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    const $ = cheerio.load(response.text);

    // Check for humorous content
    const bodyText = $('.thankyou-card').text();
    expect(bodyText).toMatch(/thank you/i);
    expect(bodyText).toMatch(/stranger on the internet/i);

    // Check link back to form
    const backLink = $('a[href="/"]');
    expect(backLink.length).toBeGreaterThan(0);
  });

  it('serves external stylesheet', async () => {
    const response = await request(serverInstance!.app).get('/public/styles.css');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/css/);
    expect(response.text).toContain('color-scheme');
    expect(response.text.length).toBeGreaterThan(1000);
  });

  it('allows free-text country input', async () => {
    const testData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '1 Test St',
      city: 'Testville',
      stateProvince: 'Test State',
      postalCode: 'T35T123',
      country: 'Republic of Testlandia',
      email: 'test@test.com',
      phone: '+1 234 567 8900',
    };

    const response = await request(serverInstance!.app)
      .post('/submit')
      .type('form')
      .send(testData);

    expect(response.status).toBe(302);
  });
});
