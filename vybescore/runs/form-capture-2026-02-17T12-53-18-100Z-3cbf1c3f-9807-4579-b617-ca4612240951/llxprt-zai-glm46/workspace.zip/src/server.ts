import express, { Request, Response } from 'express';
import type { Server } from 'node:http';
import path from 'node:path';
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs/promises';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PROJECT_ROOT = path.resolve(__dirname, '..');
const DB_PATH = path.join(PROJECT_ROOT, 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(PROJECT_ROOT, 'db', 'schema.sql');
const DATA_DIR = path.join(PROJECT_ROOT, 'data');

interface FormBody {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
let httpServer: Server | null = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s()-]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postal: string): boolean {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  return postalRegex.test(postal);
}

function validateForm(body: FormBody): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!body.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required.' });
  }

  if (!body.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required.' });
  }

  if (!body.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required.' });
  }

  if (!body.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required.' });
  }

  if (!body.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required.' });
  }

  if (!body.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required.' });
  } else if (!validatePostalCode(body.postalCode.trim())) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code must contain only letters, digits, spaces, and hyphens.',
    });
  }

  if (!body.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required.' });
  }

  if (!body.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required.' });
  } else if (!validateEmail(body.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address.' });
  }

  if (!body.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required.' });
  } else if (!validatePhone(body.phone.trim())) {
    errors.push({
      field: 'phone',
      message: 'Phone number may contain digits, spaces, parentheses, dashes, and a leading +.',
    });
  }

  return errors;
}

async function initDatabase(): Promise<Database> {
  await fs.mkdir(DATA_DIR, { recursive: true });

  let dbBytes: Uint8Array | null = null;
  try {
    const existingDb = await fs.readFile(DB_PATH);
    dbBytes = new Uint8Array(existingDb);
  } catch {
    // Database doesn't exist yet, will create new
  }

  const SQL = await initSqlJs();
  const database = dbBytes ? new SQL.Database(dbBytes) : new SQL.Database();

  // Check if we need to initialize schema
  const tables = database.exec("SELECT name FROM sqlite_master WHERE type='table' AND name='submissions'");
  if (tables.length === 0 || tables[0].values.length === 0) {
    const schema = await fs.readFile(SCHEMA_PATH, 'utf-8');
    database.run(schema);
    await saveDatabase(database);
  }

  return database;
}

async function saveDatabase(database: Database): Promise<void> {
  const data = database.export();
  const buffer = Buffer.from(data);
  await fs.writeFile(DB_PATH, buffer);
}

async function insertSubmission(form: FormBody): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.bind([
    form.firstName?.trim() || '',
    form.lastName?.trim() || '',
    form.streetAddress?.trim() || '',
    form.city?.trim() || '',
    form.stateProvince?.trim() || '',
    form.postalCode?.trim() || '',
    form.country?.trim() || '',
    form.email?.trim() || '',
    form.phone?.trim() || '',
  ]);

  stmt.step();
  stmt.free();

  await saveDatabase(db);
}

async function createApp(): Promise<ReturnType<typeof express>> {
  const app = express();

  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  app.set('view engine', 'ejs');
  app.set('views', path.join(PROJECT_ROOT, 'src', 'templates'));

  app.use('/public', express.static(path.join(PROJECT_ROOT, 'public')));

  app.get('/', (req: Request, res: Response) => {
    res.render('form', { errors: [], values: {} });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const body = req.body as FormBody;
    const errors = validateForm(body);

    if (errors.length > 0) {
      const errorMessages = errors.map((e) => e.message);
      res.status(400).render('form', {
        errors: errorMessages,
        values: body,
      });
      return;
    }

    insertSubmission(body)
      .then(() => {
        res.redirect(302, '/thank-you');
      })
      .catch((err: Error) => {
        console.error('Failed to save submission:', err);
        res.status(500).render('form', {
          errors: ['Failed to save your submission. Please try again.'],
          values: body,
        });
      });
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  });

  app.use((err: Error, req: Request, res: Response) => {
    console.error('Server error:', err);
    res.status(500).render('form', {
      errors: ['An unexpected error occurred. Please try again.'],
      values: {},
    });
  });

  return app;
}

async function startServer(): Promise<{ app: ReturnType<typeof express>; port: number; close: () => Promise<void> }> {
  db = await initDatabase();

  const app = await createApp();
  const port = parseInt(process.env.PORT || '3535', 10);

  httpServer = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  const close = async (): Promise<void> => {
    return new Promise<void>((resolve, reject) => {
      if (!httpServer) {
        resolve();
        return;
      }
      httpServer.close((err) => {
        if (err) {
          reject(err);
        } else {
          resolve();
        }
      });
    }).then(() => {
      if (db) {
        db.close();
        db = null;
      }
    });
  };

  return { app: app, port, close };
}

async function main(): Promise<void> {
  const { close } = await startServer();

  process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully...');
    await close();
    process.exit(0);
  });

  process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully...');
    await close();
    process.exit(0);
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { startServer };
