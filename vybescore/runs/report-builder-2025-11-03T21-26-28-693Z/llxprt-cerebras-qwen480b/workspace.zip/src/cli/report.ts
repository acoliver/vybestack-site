import { readFile } from 'fs/promises';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Define available formatters
const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

// Parse CLI arguments manually
function parseArgs(args: string[]): {
  dataFile?: string;
  format?: string;
  output?: string;
  includeTotals: boolean;
} {
  const result: {
    dataFile?: string;
    format?: string;
    output?: string;
    includeTotals: boolean;
  } = {
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format' && i + 1 < args.length) {
      result.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      result.output = args[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // First non-option argument is treated as the data file
      if (!result.dataFile) {
        result.dataFile = arg;
      }
    }
  }

  return result;
}

// Validate report data
function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  if (!('title' in data) || typeof data.title !== 'string') {
    return false;
  }

  if (!('summary' in data) || typeof data.summary !== 'string') {
    return false;
  }

  if (!('entries' in data) || !Array.isArray(data.entries)) {
    return false;
  }

  for (const entry of data.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }

    if (!('label' in entry) || typeof entry.label !== 'string') {
      return false;
    }

    if (!('amount' in entry) || typeof entry.amount !== 'number') {
      return false;
    }
  }

  return true;
}

// Main CLI function
async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));
  
  // Validate required arguments
  if (!args.dataFile) {
    console.error('Error: data file path is required');
    process.exit(1);
  }
  
  if (!args.format) {
    console.error('Error: format is required');
    process.exit(1);
  }
  
  // Check if the format is supported
  if (!(args.format in formatters)) {
    console.error(`Error: Unsupported format '${args.format}'`);
    process.exit(1);
  }
  
  try {
    // Read and parse JSON data
    const fileContent = await readFile(args.dataFile, 'utf-8');
    const data = JSON.parse(fileContent);
    
    // Validate data structure
    if (!validateReportData(data)) {
      console.error('Error: Invalid data structure in JSON file');
      process.exit(1);
    }
    
    // Render report using selected formatter
    const formatter = formatters[args.format as keyof typeof formatters];
    const output = formatter(data, { includeTotals: args.includeTotals });
    
    // Output to stdout or file
    if (args.output) {
      await writeFile(args.output, output);
      console.log(`Report written to ${args.output}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

// Import writeFile from fs/promises (needs to be at the top level)
import { writeFile } from 'fs/promises';

// Execute main function
main();