/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, capitalize the very first letter of the text
  let result = text.replace(/^([a-z])/, (match) => match.toUpperCase());
  
  // Then, capitalize letters that follow sentence ending punctuation
  // This handles .?! followed by any amount of whitespace (including none)
  result = result.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    return punctuation + spaces + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http, https, and www URLs
  const urlRegex = /\b(?:(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*\.[a-zA-Z]{2,}(?:\/[^\s]*)?)/g;
  
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Remove trailing punctuation that might be attached to URLs
  return matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /http:\/\/([a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]*)\.([a-zA-Z]{2,})(\/[^\s]*)?/g,
    (match, subdomain, domain, path = '') => {
      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Check for dynamic hints or legacy extensions that should skip host rewrite
        const hasDynamicHints = /(\?|&|=)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
        
        if (!hasDynamicHints) {
          // Rewrite host to docs.subdomain.domain
          const newHost = `docs.${subdomain}.${domain}`;
          return `https://${newHost}${path}`;
        }
      }
      
      // Always upgrade to https://
      const originalHost = `${subdomain}.${domain}`;
      return `https://${originalHost}${path}`;
    }
  );
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for days in each month (simplified)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
