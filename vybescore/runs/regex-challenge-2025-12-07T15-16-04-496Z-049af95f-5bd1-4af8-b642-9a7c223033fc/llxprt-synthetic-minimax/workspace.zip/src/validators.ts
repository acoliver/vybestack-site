export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern with proper validation
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const options = _options;
  // Strip all non-digits to validate the number
  const digits = value.replace(/\D/g, '');
  
  // Check length (11 with country code, 10 without)
  if (digits.length === 11 && digits.startsWith('1')) {
    // With country code
    const areaCode = digits.substring(1, 4);
    const exchangeCode = digits.substring(4, 7);
    const number = digits.substring(7);
    return !areaCode.startsWith('0') && !areaCode.startsWith('1') && 
           !exchangeCode.startsWith('0') && !exchangeCode.startsWith('1') &&
           number.length === 4;
  } else if (digits.length === 10) {
    // Without country code
    const areaCode = digits.substring(0, 3);
    const exchangeCode = digits.substring(3, 6);
    const number = digits.substring(6);
    return !areaCode.startsWith('0') && !areaCode.startsWith('1') && 
           !exchangeCode.startsWith('0') && !exchangeCode.startsWith('1') &&
           number.length === 4;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Strip all spaces, hyphens, and other formatting characters
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Optional +54, optional 9 (mobile indicator), optional 0 (trunk), area code (2-4 digits), subscriber (6-8 digits)
  const arPhoneRegex = /^(?:\+54)?(?:9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(arPhoneRegex);
  
  if (!match) return false;
  
  const trunkPrefix = match[1]; // 0 or undefined
  const areaCode = match[2];
  const subscriberNumber = match[3];
  
  // If no country code, must have trunk prefix (0)
  if (!cleaned.startsWith('+54') && !trunkPrefix) {
    return false;
  }
  
  // Check area code length (2-4 digits) and subscriber number length (6-8 digits)
  const totalLength = areaCode.length + subscriberNumber.length;
  return totalLength >= 8 && totalLength <= 12;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern allows: Unicode letters (including accents), spaces, hyphens, apostrophes
  // Rejects: digits, symbols like Æ, and special characters
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  // Additional check to reject obviously fake names
  if (value.includes('Æ') || /[\d!@#$%^&*()_+=[\]{}|;:'",.<>?/`~]/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value.trim());
}

/**
 * TODO: Validate credit card numbers using Luhn algorithm and proper prefixes/lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Strip all non-digits
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) return false;
  
  // Check card type and length
  // Visa: starts with 4, 16 digits
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits  
  // AmEx: starts with 34 or 37, 15 digits
  let isValidLength = false;
  let hasValidPrefix = false;
  
  if (digits.startsWith('4') && digits.length === 16) {
    hasValidPrefix = true;
    isValidLength = true;
  } else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
              digits.startsWith('54') || digits.startsWith('55')) && digits.length === 16) {
    hasValidPrefix = true;
    isValidLength = true;
  } else if ((digits.startsWith('34') || digits.startsWith('37')) && digits.length === 15) {
    hasValidPrefix = true;
    isValidLength = true;
  } else if (digits.length === 16 && (digits.startsWith('2221') || digits.startsWith('2222') || 
             digits.startsWith('2223') || digits.startsWith('2224') || digits.startsWith('2225') ||
             digits.startsWith('2226') || digits.startsWith('2227') || digits.startsWith('2228') || 
             digits.startsWith('2229') || digits.startsWith('223') || digits.startsWith('224') ||
             digits.startsWith('225') || digits.startsWith('226') || digits.startsWith('227') || 
             digits.startsWith('228') || digits.startsWith('229') || digits.startsWith('23') ||
             digits.startsWith('24') || digits.startsWith('25') || digits.startsWith('26') ||
             digits.startsWith('270') || digits.startsWith('271') || digits.startsWith('272'))) {
    hasValidPrefix = true;
    isValidLength = true;
  }
  
  if (!hasValidPrefix || !isValidLength) return false;
  
  // Run Luhn algorithm
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
