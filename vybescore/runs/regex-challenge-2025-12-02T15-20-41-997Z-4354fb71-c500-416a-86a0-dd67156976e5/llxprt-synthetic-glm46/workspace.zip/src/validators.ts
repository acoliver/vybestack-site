export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts: name+tag@example.co.uk, user@domain.com, etc.
 * Rejects: double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(value)) return false;
  
  // Split into local part and domain
  const [localPart, domain] = value.split('@');
  
  // Local part validation
  // Cannot start or end with dots, no consecutive dots
  const localPartRegex = /^(?![.-])(?!.*\.\.)(?=.*[^.]$)[a-zA-Z0-9.+\-_]+$/;
  if (!localPartRegex.test(localPart)) return false;
  
  // Domain validation
  // No underscores, no consecutive dots, must have valid TLD
  const domainRegex = /^(?!.*\.\.)(?=.*[^.]$)(?!.*_)([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) return false;
  
  // Additional checks for domain segments
  const domainSegments = domain.split('.');
  for (const segment of domainSegments) {
    // Each segment cannot start or end with hyphen
    if (/^-|-$/.test(segment)) return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with various formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Additional validation: area code 555 followed by 010-0199 are fictional
  if (areaCode === '555') {
    const exchangeCode = phoneNumber.substring(3, 6);
    const lineNumber = phoneNumber.substring(6, 10);
    if (exchangeCode === '010' && lineNumber.length === 4 && parseInt(lineNumber) <= 199) {
      return false;
    }
  }
  
  // Check if the format matches valid patterns
  const phonePattern = /^(\+1\s?)?(\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  return phonePattern.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters first to check format
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with +54 (country code)
  const hasCountryCode = value.startsWith('+54');
  
  // Check if it starts with 0 (trunk prefix when no country code)
  const hasTrunkPrefix = value.startsWith('0');
  
  if (hasCountryCode) {
    // Format: +54 [9] [area_code] [subscriber]
    const afterCountryCode = digitsOnly.substring(2);
    
    // If the first digit after country code is 9 (mobile indicator)
    const hasMobileIndicator = afterCountryCode.startsWith('9');
    
    if (hasMobileIndicator) {
      // Format: +54 9 [area_code] [subscriber]
      const afterMobileIndicator = afterCountryCode.substring(1);
      // Extract area code (2-4 digits, leading digit 1-9)
      if (afterMobileIndicator.length < 8) return false;
      
      let areaCode;
      let subscriber;
      
      // Try different area code lengths (2-4 digits)
      for (let len = 2; len <= 4; len++) {
        areaCode = afterMobileIndicator.substring(0, len);
        subscriber = afterMobileIndicator.substring(len);
        
        // Validate area code (first digit 1-9)
        if (!/^[1-9]\d{0,3}$/.test(areaCode)) continue;
        
        // Check if subscriber has valid length (6-8 digits)
        if (/^\d{6,8}$/.test(subscriber)) {
          return true;
        }
      }
    } else {
      // Format: +54 [area_code] [subscriber]
      // Extract area code (2-4 digits, leading digit 1-9)
      if (afterCountryCode.length < 8) return false;
      
      let areaCode;
      let subscriber;
      
      // Try different area code lengths (2-4 digits)
      for (let len = 2; len <= 4; len++) {
        areaCode = afterCountryCode.substring(0, len);
        subscriber = afterCountryCode.substring(len);
        
        // Validate area code (first digit 1-9)
        if (!/^[1-9]\d{0,3}$/.test(areaCode)) continue;
        
        // Check if subscriber has valid length (6-8 digits)
        if (/^\d{6,8}$/.test(subscriber)) {
          return true;
        }
      }
    }
  } else if (hasTrunkPrefix) {
    // Format: 0 [area_code] [subscriber]
    const afterTrunkPrefix = digitsOnly.substring(1);
    
    // Extract area code (2-4 digits, leading digit 1-9)
    if (afterTrunkPrefix.length < 8) return false;
    
    let areaCode;
    let subscriber;
    
    // Try different area code lengths (2-4 digits)
    for (let len = 2; len <= 4; len++) {
      areaCode = afterTrunkPrefix.substring(0, len);
      subscriber = afterTrunkPrefix.substring(len);
      
      // Validate area code (first digit 1-9)
      if (!/^[1-9]\d{0,3}$/.test(areaCode)) continue;
      
      // Check if subscriber has valid length (6-8 digits)
      if (/^\d{6,8}$/.test(subscriber)) {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * Validates personal names with unicode support.
 * Accepts: Unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: Digits, symbols, and "X Æ A-12" style names
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim() === '') return false;
  
  // Strip leading/trailing whitespace
  const trimmed = value.trim();
  
  // Names with special characters that look like numbers/symbols (like "X Æ A-12")
  if (/\d/.test(trimmed)) return false;
  
  // Check for problematic symbol sequences like "Æ A-12"
  if (/[ÆØÅæøå]/.test(trimmed) && /[\d-]/.test(trimmed)) return false;
  
  // Check for obviously invalid characters (anything not letter, space, apostrophe, hyphen)
  if (/[^a-zA-Z\u00C0-\u017F\s'’-]/.test(trimmed)) return false;
  
  // Must have at least one letter character
  if (!/[a-zA-Z\u00C0-\u017F]/.test(trimmed)) return false;
  
  // Check for problematic cases like "X Æ A-12" that mix symbols in non-traditional ways
  // Look for special Unicode characters combined with digits
  if (/\d/.test(trimmed)) return false;
  
  // Special check for "X Æ A-12" style names
  if (/[ÆØÅæøå]/.test(trimmed) && /[-]/.test(trimmed)) return false;
  
  return true;
}

/**
 * Validates credit card numbers for major brands using regex patterns and Luhn checksum.
 * Accepts: Visa, Mastercard, AmEx with correct prefix and length
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[-\s]/g, '');
  
  // Must be numeric and within reasonable length (13-19 digits)
  if (!/^\d{13,19}$/.test(cleanNumber)) return false;
  
  // Run Luhn algorithm to check validity
  if (!runLuhnCheck(cleanNumber)) return false;
  
  // Check for major credit card patterns
  // Visa: 4, length 13 or 16
  const visaPattern = /^4(\d{12}|\d{15})$/;
  if (visaPattern.test(cleanNumber)) return true;
  
  // Mastercard: 51-55 or 2221-2720, length 16
  const mcPattern1 = /^5[1-5]\d{14}$/;
  const mcPattern2 = /^2(2[2-9][0-9]|[3-6][0-9]{2}|7([01][0-9]|20))\d{12}$/;
  if (mcPattern1.test(cleanNumber) || mcPattern2.test(cleanNumber)) return true;
  
  // American Express: 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  if (amexPattern.test(cleanNumber)) return true;
  
  return false;
}

/**
 * Helper function to run Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process each digit from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
