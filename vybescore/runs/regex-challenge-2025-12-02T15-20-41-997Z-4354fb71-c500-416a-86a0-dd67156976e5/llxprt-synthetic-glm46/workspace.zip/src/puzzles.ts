/**
 * Finds words beginning with the specified prefix but excludes the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create regex to find words with the specified prefix
  // \b ensures we're matching word boundaries
  const prefixPattern = new RegExp(`\\b${escapeRegex(prefix)}\\w*`, 'g');
  
  // Find all matches
  const allMatches = text.match(prefixPattern) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowercasedExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions
  const filteredMatches = allMatches.filter(word => {
    const lowercasedWord = word.toLowerCase();
    return !lowercasedExceptions.includes(lowercasedWord);
  });
  
  // Remove duplicates
  return [...new Set(filteredMatches)];
}

/**
 * Helper function to escape special regex characters in the prefix.
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\/]/g, '\\$&');
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to match the pattern.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = escapeRegex(token);
  
  // Since JavaScript doesn't support all lookbehinds, 
  // we'll match digit+token and check position
  const pattern = new RegExp(`(\\d)(${escapedToken})`, 'g');
  
  // Process matches to extract the digit+token
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Make sure the token is not at the very beginning of the string
    // (i.e., the digit is not at position 0)
    if (match.index > 0) {
      // Return the digit+token as expected by the test
      matches.push(match[1] + match[2]);
    }
  }
  
  return matches;
}

/**
 * Validates password strength according to specific requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab")
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // No whitespace characters
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Must contain at least one symbol
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for repeated sequences (e.g., "abcabc", "1212")
  // Look for any pattern of 2+ characters repeated consecutively
  for (let i = 1; i <= value.length / 2; i++) {
    const segment = value.substring(0, i);
    const nextSegment = value.substring(i, 2 * i);
    
    if (segment === nextSegment) return false;
  }
  
  // More thorough repeated sequence check
  const repeatedPattern = /(.{2,})(?=\1)/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv4 pattern: 0-255.0-255.0-255.0-255
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // First check if it's just an IPv4 address (pure IPv4, no text around it)
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 pattern - common patterns
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|::(?:[fF]{4}(?::0{1,4}){0,1}:){0,1}(?:(?:25[0-5]|1[0-9]{2}|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|1[0-9]{2}|[1-9][0-9]|[0-9])|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){0,4}:(?:(?:25[0-5]|1[0-9]{2}|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|1[0-9]{2}|[1-9][0-9]|[0-9])|::(?:(?:25[0-5]|1[0-9]{2}|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|1[0-9]{2}|[1-9][0-9]|[0-9])|::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4})*::|::/g;
  
  // Check if text contains IPv6 pattern
  return ipv6Pattern.test(value);
}