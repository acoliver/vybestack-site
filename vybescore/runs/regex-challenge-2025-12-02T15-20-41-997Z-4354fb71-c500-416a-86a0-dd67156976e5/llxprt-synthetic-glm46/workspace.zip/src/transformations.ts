/**
 * Capitalizes the first character of each sentence while handling spacing rules.
 * Insert exactly one space between sentences, collapse extra spaces, and try to preserve abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Simple, direct implementation that satisfies the test requirements
  let result = text;
  
  // 1. Ensure proper spacing after sentence terminators
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // 2. Replace multiple spaces with a single space
  result = result.replace(/\s+/g, ' ');
  
  // 3. Trim leading/trailing spaces
  result = result.trim();
  
  // 4. Capitalize first letter of the entire string
  if (result.length > 0) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  // Capitalize letters after sentence terminators followed by spaces
  result = result.replace(/([.?!]\s+)([a-z])/g, (match, terminator, letter) => {
    return terminator + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts all URLs from the given text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Pattern to match URLs (https, http, www)
  const urlRegex = /https?:\/\/[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation characters that likely aren't part of the URL
    return url.replace(/[.,;!?"'\])}>]+$/, '');
  });

  return cleanedUrls;
}

/**
 * Replaces http: URLs with https: while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace all http: URLs with https:
  return text.replace(/(?<=\s|^)http:\/\//g, 'https://');
}

/**
 * Rewrites URLs with docs paths to use docs subdomain.
 * Always upgrades http: to https:.
 * Rewrites docs.example.com paths while skipping exceptions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  // Pattern to match http://example.com URLs
    const urlRegex = /(https?:\/\/)([^\/\s:]+)(\/[^\s]*)?/gi;

  return text.replace(urlRegex, (match, protocol, hostname, path) => {
    // Always upgrade to https
    const secureProtocol = 'https://';

    // Find the base domain (without subdomains)
    const domainParts = hostname.split('.');
    if (domainParts.length < 2) return protocol + hostname + (path || '');

    const baseDomain = domainParts.slice(-2).join('.'); // e.g., example.com
    const hasWww = domainParts[0] === 'www';

    // If there's no path or it doesn't start with /docs/, just upgrade protocol
    if (!path || !path.startsWith('/docs/')) {
      return secureProtocol + hostname + path;
    }

    // Check for exceptions in the path where we shouldn't rewrite the hostname
    // Skip when path contains dynamic hints or legacy extensions
    const hasDynamicHints = /\/cgi-bin|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/i.test(path);

    if (hasDynamicHints) {
      // Just upgrade protocol, don't rewrite hostname
      return secureProtocol + hostname + path;
    }

    // Rewrite docs.example.com for docs paths
    // If hostname already has docs subdomain, keep it
    if (hostname.startsWith('docs.')) {
      return secureProtocol + hostname + path;
    }

    // Otherwise, rewrite to docs.example.com
    if (hasWww) {
      return `${secureProtocol}docs.${baseDomain}${path}`;
    } else {
      // Domain might have other subdomains
      const subdomains = domainParts.slice(0, -2);
      if (subdomains.length > 0) {
        return `${secureProtocol}docs.${baseDomain}${path}`;
      } else {
        return `${secureProtocol}docs.${baseDomain}${path}`;
      }
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted dates.
 * Returns 'N/A' when the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format (strictly)
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) return 'N/A';
  
  // Extract parts
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified - assumes Gregorian calendar)
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || 
                     (parseInt(year, 10) % 400 === 0);
  
  if (month === 2 && isLeapYear) {
    if (day > 29) return 'N/A';
  } else {
    if (day > daysInMonth[month - 1]) return 'N/A';
  }
  
  
  // Year must be reasonable (between 1000 and 9999)
  const yearNum = parseInt(year, 10);
  if (yearNum < 1000 || yearNum > 9999) return 'N/A';
  
  return year;
}