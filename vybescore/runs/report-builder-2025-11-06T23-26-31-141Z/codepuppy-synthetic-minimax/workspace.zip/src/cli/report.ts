#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  if (args[1] !== '--format') {
    console.error('Expected --format argument');
    process.exit(1);
  }
  
  const format = args[2];
  if (format !== 'markdown' && format !== 'text') {
    console.error('Unsupported format');
    process.exit(1);
  }
  
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse remaining arguments
  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  return {
    dataFile,
    format: format as 'markdown' | 'text',
    outputPath,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate the structure
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Missing or invalid label in entry');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid amount in entry');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Invalid JSON in ${filePath}: ${error.message}`);
    } else {
      console.error(`Error loading report data: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function getFormatter(format: 'markdown' | 'text'): ReportFormatter['render'] {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error('Unsupported format');
  }
}

function main(): void {
  const args = parseArguments();
  const data = loadReportData(args.dataFile);
  const formatter = getFormatter(args.format);
  
  const options: ReportOptions = {
    includeTotals: args.includeTotals
  };
  
  const output = formatter(data, options);
  
  if (args.outputPath) {
    try {
      writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error writing to ${args.outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();