/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  subjects?: Set<Subject<unknown>>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const observerStack: ObserverR[] = []


export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function pushObserver(observer: ObserverR): void {
  observerStack.push(activeObserver!)
  activeObserver = observer
}

export function popObserver(): void {
  activeObserver = observerStack.pop()
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Clear old subjects
  if (observer.subjects) {
    observer.subjects.clear()
  }
  
  const prevValue = observer.value
  pushObserver(observer)
  try {
    observer.value = observer.updateFn(prevValue)
  } finally {
    popObserver()
  }
}

export function addObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.observers.has(observer)) {
    subject.observers.add(observer)
  }
}

export function trackDependency<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer) {
    addObserver(subject, observer)
    // Also track this subject in the observer for cleanup
    if (!observer.subjects) {
      observer.subjects = new Set()
    }
    observer.subjects.add(subject as Subject<unknown>)
  }
}
