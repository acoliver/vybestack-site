/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subjects: new Set(),
  }
  
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Cleanup: remove observer from all tracked subjects
    if (observer.subjects) {
      observer.subjects.forEach(subject => {
        if (subject.observers && subject.observers.has(observer as ObserverR)) {
          subject.observers.delete(observer as ObserverR)
        }
      })
      observer.subjects.clear()
    }
    
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
