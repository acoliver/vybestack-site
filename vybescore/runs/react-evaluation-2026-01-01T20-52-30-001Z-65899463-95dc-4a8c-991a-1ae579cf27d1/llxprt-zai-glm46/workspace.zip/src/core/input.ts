/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  trackDependency
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    trackDependency(s)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn: EqualFn<T> | undefined = typeof _equal === 'function' 
      ? _equal 
      : _equal === true 
        ? (a, b) => a === b 
        : undefined
    
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    // Create a copy of observers to avoid issues if set is modified during iteration
    const observersCopy = Array.from(s.observers)
    
    s.value = nextValue
    
    observersCopy.forEach(observer => {
      updateObserver(observer as Observer<T>)
    })
    
    return s.value
  }

  return [read, write]
}
