/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  EqualFn,
  getActiveObserver,
  addObserver,
  pushObserver,
  popObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set(),
  }
  
  const getterObservers = new Set<ObserverR>()
  
  const getter = (): T => {
    // Track this getter being accessed by current observer
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== o && !getterObservers.has(currentObserver)) {
      getterObservers.add(currentObserver)
      
      // Register current observer with all our dependencies (subjects)
      if (o.subjects) {
        o.subjects.forEach(dep => {
          addObserver(dep, currentObserver)
        })
      }
    }
    return o.value!
  }
  
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue?: T) => {
    // Clear old getter observers
    getterObservers.clear()
    
    pushObserver(o)
    try {
      const result = originalUpdateFn(prevValue)
      o.value = result
      return result
    } finally {
      popObserver()
    }
  }
  
  // Initial computation
  o.updateFn(value)
  
  return getter
}
