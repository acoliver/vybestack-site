import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let testApp: ReturnType<typeof import('express')>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the app and initialize database
  const { app, initializeDatabase } = await import('../../dist/server.js');
  testApp = app;
  await initializeDatabase();
});

afterAll(() => {
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(testApp).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Get in Touch');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check for form submit button
    expect($('button[type="submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Reinitialize database after deleting file
    const { initializeDatabase } = await import('../../dist/server.js');
    await initializeDatabase();
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(testApp)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page', async () => {
    const response = await request(testApp).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank You');
    expect(response.text.toLowerCase()).toContain('spam');
  });

  it('validates required fields', async () => {
    const response = await request(testApp)
      .post('/submit')
      .type('form')
      .send({});
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
  });

  it('validates email format', async () => {
    const response = await request(testApp)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'invalid-email',
        phone: '+44 20 7946 0958'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email');
  });
});
