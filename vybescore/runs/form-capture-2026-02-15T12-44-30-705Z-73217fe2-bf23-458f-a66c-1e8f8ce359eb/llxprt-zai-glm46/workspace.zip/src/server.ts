import express, { type Request, type Response, type Express } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { type Database } from 'sql.js';
import type { Server } from 'node:http';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app: Express = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(__dirname, '../../public')));

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'views'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(formData: FormData): string[] {
  const errors: string[] = [];

  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push('First name is required');
  }

  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push('Last name is required');
  }

  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }

  if (!formData.city || formData.city.trim() === '') {
    errors.push('City is required');
  }

  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }

  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push('Postal code must contain only letters, digits, spaces, and dashes');
  }

  if (!formData.country || formData.country.trim() === '') {
    errors.push('Country is required');
  }

  if (!formData.email || formData.email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!formData.phone || formData.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }

  return errors;
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Check if database file exists
    const fs = await import('node:fs');
    let dbData: Uint8Array | null = null;
    
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      dbData = new Uint8Array(buffer);
    }
    
    db = new SQL.Database(dbData);
    
    // Always read and execute schema to ensure tables exist
    if (fs.existsSync(SCHEMA_PATH)) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      // Split schema into individual statements and execute each
      const statements = schema.split(';').filter((s: string) => s.trim().length > 0);
      for (const statement of statements) {
        try {
          db.run(statement);
        } catch (err) {
          // Ignore errors for existing tables (IF NOT EXISTS should handle this)
          console.warn('Schema execution warning:', err);
        }
      }
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const fs = await import('node:fs');
    const data = db.export();
    const buffer = Buffer.from(data);
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(DB_PATH, buffer);
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    formData: {}, 
    errors: [] 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', { formData, errors });
  }

  // Insert into database
  try {
    const submission: Submission = {
      first_name: formData.firstName!,
      last_name: formData.lastName!,
      street_address: formData.streetAddress!,
      city: formData.city!,
      state_province: formData.stateProvince!,
      postal_code: formData.postalCode!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!
    };

    if (db) {
      db.run(
        `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          submission.first_name,
          submission.last_name,
          submission.street_address,
          submission.city,
          submission.state_province,
          submission.postal_code,
          submission.country,
          submission.email,
          submission.phone
        ]
      );

      await saveDatabase();
    }

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    errors.push('Failed to save submission. Please try again.');
    res.status(500).render('form', { formData, errors });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Start server
async function startServer(): Promise<Server> {
  await initializeDatabase();
  
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('\nShutting down gracefully...');
    server.close(() => {
      console.log('HTTP server closed');
      if (db) {
        db.close();
        console.log('Database connection closed');
      }
      process.exit(0);
    });

    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  return server;
}

// Export for testing
export { app, initializeDatabase };

// Start server if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
