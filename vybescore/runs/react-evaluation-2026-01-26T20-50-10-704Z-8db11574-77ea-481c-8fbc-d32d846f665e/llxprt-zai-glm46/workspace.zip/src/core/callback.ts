/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, setActiveObserver, UpdateFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    _subjects: new Set(),
    _notify() {
      this.value = this.updateFn(this.value)
    }
  }
  
  // Track dependencies and register with subjects
  setActiveObserver(observer)
  observer.value = updateFn(value)
  setActiveObserver(undefined)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    observer._subjects?.clear()
  }
}
