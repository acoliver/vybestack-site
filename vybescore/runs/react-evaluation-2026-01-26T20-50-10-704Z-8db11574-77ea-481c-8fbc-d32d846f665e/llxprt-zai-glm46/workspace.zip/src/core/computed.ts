/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  setActiveObserver,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | unknown,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    _subjects: new Set(),
    _notify() {
      updateObserver(this)
    }
  }
  
  // Initial computation - track dependencies
  setActiveObserver(observer)
  observer.value = updateFn(value)
  setActiveObserver(undefined)
  
  return (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      // The active observer depends on this computed
      // Register this computed's subjects with the active observer
      if (observer._subjects) {
        for (const subject of observer._subjects) {
          if (!activeObserver._subjects) {
            activeObserver._subjects = new Set()
          }
          activeObserver._subjects.add(subject)
          subject.observers.add(activeObserver)
        }
      }
    }
    return observer.value as T
  }
}
