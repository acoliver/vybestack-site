const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]+={0,2}$|^[A-Za-z0-9+/]+$|^$/;

/**
 * Encode plain text to Base64.
 * Implements RFC 4648 Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  // Use the standard base64 encoding which should already follow RFC 4648
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Implements RFC 4648 Base64 decoding with proper input validation.
 */
export function decode(input: string): string {
  // Empty string is valid
  if (input === '') {
    return '';
  }

  // First validate the input contains only valid Base64 characters
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input');
  }

  // Validate padding is only at the end
  const paddingIndex = input.indexOf('=');
  
  // Length validation - for standard Base64 with padding, length should be divisible by 4
  // However, some implementations accept unpadded Base64 where the length might not be divisible by 4
  // We'll still be strict for better RFC compliance
  if (input.length % 4 !== 0) {
    // For unpadded inputs, we can normalize padding and check again
    const normalized = normalizeBase64Padding(input);
    if (normalized.length % 4 !== 0) {
      throw new Error('Invalid Base64 input');
    }
  }
  
  if (paddingIndex !== -1) {
    const paddingSection = input.substring(paddingIndex);
    
    // Only allow '=' characters in padding section
    if (!/^[=]+$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input');
    }
    
    // Maximum 2 padding characters
    if (paddingSection.length > 2) {
      throw new Error('Invalid Base64 padding');
    }
  }

  try {
    // Use standard base64 decoding, not base64url
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Perform round-trip validation to catch edge cases
    // that Buffer.from might silently accept
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedInput = normalizeBase64Padding(input);
    
    if (reencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error; // Re-throw our custom error
    }
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Normalizes base64 padding by removing existing padding and adding the correct amount
 */
function normalizeBase64Padding(base64: string): string {
  const withoutPadding = base64.replace(/=/g, '');
  const padLength = (4 - (withoutPadding.length % 4)) % 4;
  return withoutPadding + '='.repeat(padLength);
}