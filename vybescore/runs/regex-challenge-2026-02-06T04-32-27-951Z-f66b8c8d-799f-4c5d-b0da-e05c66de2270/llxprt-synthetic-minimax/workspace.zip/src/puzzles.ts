/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with prefix
  const wordRegex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const wordMatches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const result = wordMatches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowerMatch
    );
  });
  
  return result;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token that comes after a digit but not at string start
  // (?<!^) ensures we're not at the beginning
  // (?<=\d) ensures there's a digit before the token
  const tokenRegex = new RegExp(`(?<!^)(?<=\\d)${token}(?!\\d)`, 'gi');
  
  // The matches return just the token, but test expects digit+token
  // So we need to capture the full context where token appears after digit
  const fullMatches = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    // Find position and capture preceding digit
    const pos = match.index;
    if (pos > 0 && /\d/.test(text[pos - 1])) {
      fullMatches.push(text[pos - 1] + match[0]);
    }
  }
  
  return fullMatches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for all required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+={};"'\\|,.<>?-]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // Look for any 2-character sequence that repeats immediately
  const hasRepeatedSequence = /(\w{2,})\1/.test(value);
  
  if (hasRepeatedSequence) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern including shorthand notation with ::
  const ipv6Regex = /(?<![0-9.])(([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))(?![0-9.])/;
  
  // Also need to check if IPv4 is present - if so, return false
  const ipv4Regex = /(?<!\d)(\d{1,3}\.){3}\d{1,3}(?!\d)/;
  
  // If it contains IPv4, it's not IPv6
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Test for IPv6 pattern
  return ipv6Regex.test(value);
}
