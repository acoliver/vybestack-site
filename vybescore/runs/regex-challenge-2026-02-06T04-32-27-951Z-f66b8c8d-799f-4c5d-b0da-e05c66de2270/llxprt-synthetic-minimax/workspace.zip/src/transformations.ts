/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, capitalize the very first letter
  const trimmed = text.trim();
  let normalized = trimmed.length > 0 ? trimmed[0].toUpperCase() + trimmed.substring(1) : '';
  
  // Pattern to find sentence endings followed by letters (after any spaces)
  const sentenceEndRegex = /([.!?])\s*([A-Za-z])/g;
  
  // Capitalize first letter after sentence ending
  normalized = normalized.replace(sentenceEndRegex, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https URLs - allow common URL characters
  const urlRegex = /https?:\/\/[^\s"'<>)]+/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation that got caught
  return matches.map(url => url.replace(/[.,;:!?)\]}'"<>]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs with path
  const urlRegex = /http:\/\/([^/\s]+)([^\s]*)/g;
  
  return text.replace(urlRegex, (match, host, path) => {
    // Always upgrade to https
    let result = 'https://' + host;
    
    // Skip host rewrite if path contains dynamic hints
    const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    if (path.startsWith('/docs/') && !hasDynamicHint && !hasQueryString) {
      // Rewrite host to docs.example.com
      result = 'https://docs.' + host.replace(/^www\./, '') + path;
    } else {
      result += path;
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = dateRegex.exec(value.trim());
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Check for leap year in February
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year);
    if (yearNum % 4 !== 0 || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
