export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  // Basic structure check - must have exactly one @ and at least one dot after @
  if (!trimmed.includes('@') || trimmed.indexOf('@') !== trimmed.lastIndexOf('@')) {
    return false;
  }
  
  const [localPart, domainPart] = trimmed.split('@');
  
  // Check local part exists and doesn't start/end with dot
  if (!localPart || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check domain part exists and has at least one dot
  if (!domainPart || !domainPart.includes('.')) {
    return false;
  }
  
  // Domain can't have underscores, can't start with dot, can't have consecutive dots
  if (domainPart.includes('_') || domainPart.startsWith('.') || 
      domainPart.includes('..') || domainPart.endsWith('.')) {
    return false;
  }
  
  // Use regex to check overall structure
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return emailRegex.test(trimmed);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must start with +1 or just digits
  const phoneRegex = /^(?:\+1)?([2-9]\d{2}[2-9]\d{6})$/;
  
  // Check if matches pattern
  const match = phoneRegex.exec(cleaned);
  
  if (!match) {
    return false;
  }
  
  // Extract area code (first 3 digits after optional +1)
  const areaCode = match[1].substring(0, 3);
  const areaCodeFirstDigit = areaCode.charAt(0);
  
  // Area code can't start with 0 or 1 (forbidden NPA/NXX rules)
  if (areaCodeFirstDigit === '0' || areaCodeFirstDigit === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and whitespace, keep only digits, +, and 0
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern can be:
  // 1. +54 (country) + 9 (mobile indicator) + area code (2-4 digits, first 1-9) + subscriber (6-8 digits)
  // 2. 0 (trunk) + area code (2-4 digits, first 1-9) + subscriber (6-8 digits)
  
  const pattern1 = /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const pattern2 = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  return pattern1.test(cleaned) || pattern2.test(cleaned);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters (including accents), spaces, apostrophes, and hyphens
  // Reject digits and symbols
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  return nameRegex.test(value.trim());
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (must be 13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check card type based on prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  let isValidPrefix = false;
  
  if (cleaned.startsWith('4') && [13, 16, 19].includes(cleaned.length)) {
    isValidPrefix = true;
  } else if ((cleaned.startsWith('51') || cleaned.startsWith('52') || 
             cleaned.startsWith('53') || cleaned.startsWith('54') || 
             cleaned.startsWith('55') || (cleaned.startsWith('2221') && 
             parseInt(cleaned.substring(0, 4)) <= 2720) || 
             (cleaned.startsWith('2720') && parseInt(cleaned.substring(0, 4)) <= 2720)) && 
             cleaned.length === 16) {
    isValidPrefix = true;
  } else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && 
             cleaned.length === 15) {
    isValidPrefix = true;
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Perform Luhn checksum
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cleaned.length - 1; i >= 0; i--) {
    let digit = parseInt(cleaned.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
