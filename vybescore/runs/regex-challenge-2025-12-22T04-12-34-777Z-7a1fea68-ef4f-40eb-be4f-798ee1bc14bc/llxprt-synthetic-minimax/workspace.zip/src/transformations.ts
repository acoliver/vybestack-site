/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single space and clean up
  const processed = text.replace(/\s+/g, ' ').trim();
  
  // Find sentence endings followed by content
  // Pattern: sentence ending punctuation followed by optional spaces, then a letter
  const sentenceRegex = /([.!?])(\s*)([A-Za-z])/g;
  
  // Process the text
  let result = processed.replace(sentenceRegex, (match, punctuation, spaces, letter) => {
    // Capitalize the letter and ensure exactly one space
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // For the first sentence (before any punctuation), capitalize the first letter if it's not already
  if (result.length > 0 && /^[a-z]/.test(result.charAt(0))) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https URLs
  const urlRegex = /\bhttps?:\/\/[^\s<>""]*[^\s<>"".!?]/gi;
  const matches = text.match(urlRegex) || [];
  
  // Clean up any trailing punctuation from URLs
  return matches.map(url => url.replace(/[.,!?;]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs using RegExp constructor to avoid escaping issues
  const httpUrlRegex = new RegExp('http://([^/\\s<>"]+)(\\/.*)', 'gi');
  
  return text.replace(httpUrlRegex, (match, domain, path) => {
    let newUrl = 'https://' + domain + path;
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|&|=|cgi-bin)/i.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints && !hasLegacyExtensions) {
      // Rewrite host to docs.domain
      newUrl = 'https://docs.' + domain + path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy with strict validation
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = new Date(parseInt(year, 10), month, 0).getDate();
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }
  
  return year;
}