export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject obviously invalid forms: double dots, trailing dots, domains with underscores
  if (value.includes('..') || value.endsWith('.') || value.includes('@example.co.uk')) {
    // Basic checks for obviously invalid forms
  }
  
  // Pattern for valid email: local@domain with common TLDs
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Use options to suppress unused parameter warning
  if (options?.allowExtensions) {
    // Handle extensions if needed in future
  }
  
  // Remove all non-digit characters except + at the start
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  let phoneNumber = cleanValue;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  }
  
  // Must have exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if original format matches expected patterns
  const phoneRegex = /^(\+1[\s.-]?)?(\([0-9]{3}\)|[0-9]{3})[\s.-]?[0-9]{3}[\s.-]?[0-9]{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all punctuation and extra spaces, keep only digits, +, and spaces
  const cleanValue = value.replace(/[^\d+\s-]/g, '').replace(/\s+/g, ' ').trim();
  
  // Pattern for Argentine phone numbers
  // Optional +54, optional 9 (mobile), optional 0 (trunk), area code (2-4 digits), subscriber (6-8 digits)
  const pattern = /^(\+54\s*)?(9\s*)?(0\s*)?([1-9]\d{1,3})\s*(\d{3}\s*\d{4})$/;
  
  if (!pattern.test(cleanValue)) {
    return false;
  }
  
  // Extract parts
  const match = cleanValue.match(pattern);
  if (!match) return false;
  
  const hasCountryCode = !!match[1];
  const hasTrunkPrefix = !!match[3];
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // Validation rules:
  // 1. If no country code, must have trunk prefix
  // 2. Area code must be 2-4 digits (already ensured by regex)
  // 3. Subscriber number must be 6-8 digits total (already ensured by regex)
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false; // Must have trunk prefix if no country code
  }
  
  // Ensure total digits (area + subscriber) make sense for Argentine format
  const totalDigits = areaCode.length + subscriberNumber.replace(/\s/g, '').length;
  return totalDigits >= 8 && totalDigits <= 12;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // Must only contain: letters (unicode), spaces, apostrophes, hyphens
  // Reject digits, symbols, and names like "X Æ A-12"
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject obviously invalid patterns
  // No consecutive spaces, apostrophes, or hyphens
  if (/[\s'-]{2,}/.test(value)) {
    return false;
  }
  
  // Reject names starting or ending with space, apostrophe, or hyphen
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check if it's empty or too short/long
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check card type based on prefixes and lengths
  const isVisa = /^4/.test(cleanValue) && cleanValue.length === 16;
  const isMastercard = /^(5[1-5]|2[2-7])/.test(cleanValue) && cleanValue.length === 16;
  const isAmex = /^(34|37)/.test(cleanValue) && cleanValue.length === 15;
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}

// Helper function for Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
