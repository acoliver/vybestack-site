/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const prefixRegex = new RegExp(`\\b${prefix.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")}\\w*`, "gi");
  const matches = text.match(prefixRegex) || [];
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, "g");
  return text.match(pattern) || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (value.length < 10 || /\s/.test(value)) return false;
  if (!/[A-Z]/.test(value) || !/[a-z]/.test(value) || !/\d/.test(value)) return false;
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  for (let i = 0; i < value.length - 2; i++) {
    const sequence = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === sequence) return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b|\b::\b|\b[0-9a-fA-F]{1,4}::\b/g;
  const hasIpv6 = ipv6Pattern.test(value);
  if (!hasIpv6) return false;
  
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/g;
  if (ipv4Pattern.test(value)) return false;
  
  return true;
}
