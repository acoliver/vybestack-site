# Fix transformations.ts
with open('src/transformations.ts', 'r') as f:
    content = f.read()

# Fix line 33 - remove unnecessary escapes around quotes and brackets
content = content.replace('const urlPattern = /\\\\bhttps?:\\\\/\\\\/[^\\\\s\\\\"\\'<>()\\\\[\\\\]{}]*[^\\\\s\\\\"\\'<>()\\\\[\\\\]{}.!?]/gi;',
                          'const urlPattern = /\bhttps?:\/\/[^\s"\\'<>()\[\]{}]*[^\s"\\'<>()\[\]{}.!?]/gi;')

# Fix line 51 - remove unnecessary escapes for forward slashes
content = content.replace('return text.replace(/https?:\\\\/\\\\//g, (match) => {',
                          'return text.replace(/https?:\/\//g, (match) => {')

# Fix line 64 - remove unnecessary escapes for forward slashes
content = content.replace('const urlPattern = /\\\\bhttp:\\\\/\\\\/([^\\\\/\\\\s]+)([^\\\\s]*)/gi;',
                          'const urlPattern = /\bhttp:\/\/([^\/\s]+)([^\s]*)/gi;')

# Fix line 90 - remove unnecessary escapes for forward slashes
content = content.replace('const datePattern = /^(\\\\d{2})\\\\/(\\\\d{2})\\\\/(\\\\d{4})$/;',
                          'const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;')

with open('src/transformations.ts', 'w') as f:
    f.write(content)

print("Fixed transformations.ts")