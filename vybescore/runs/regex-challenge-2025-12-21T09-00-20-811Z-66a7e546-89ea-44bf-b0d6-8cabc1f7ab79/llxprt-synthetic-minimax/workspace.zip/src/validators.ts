export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  const email = value.trim();
  
  // Basic structure check: must have exactly one @ and one dot after @
  if (!email.includes('@') || email.split('@').length !== 2) {
    return false;
  }
  
  const [localPart, domainPart] = email.split('@');
  
  // Local part validation
  // Must not be empty, must not start/end with dot, must not have consecutive dots
  if (!localPart || 
      localPart.startsWith('.') || 
      localPart.endsWith('.') || 
      localPart.includes('..')) {
    return false;
  }
  
  // Local part can contain letters, numbers, dots, underscores, hyphens, plus
  const localPattern = /^[a-zA-Z0-9._+-]+$/;
  if (!localPattern.test(localPart)) {
    return false;
  }
  
  // Domain part validation
  // Must not be empty, must not start/end with dot, must not have consecutive dots
  if (!domainPart || 
      domainPart.startsWith('.') || 
      domainPart.endsWith('.') || 
      domainPart.includes('..')) {
    return false;
  }
  
  // Domain must have at least one dot and no underscores
  if (!domainPart.includes('.') || domainPart.includes('_')) {
    return false;
  }
  
  // Domain parts (split by dots) should not be empty
  const domainParts = domainPart.split('.');
  for (const part of domainParts) {
    if (!part || part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  // Domain can contain letters, numbers, dots, hyphens but NO underscores
  const domainPattern = /^[a-zA-Z0-9.-]+$/;
  if (!domainPattern.test(domainPart)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check length - should be 10 or 11 (with country code)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // If 11 digits, first digit must be 1 (country code)
  if (digits.length === 11 && digits[0] !== '1') {
    return false;
  }
  
  // Extract area code (first 3 digits, or last 10 digits if country code present)
  const phoneNumber = digits.length === 11 ? digits.slice(1) : digits;
  const areaCode = phoneNumber.slice(0, 3);
  
  // Area code cannot start with 0 or 1 (impossible area codes)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Basic format validation - ensure the original string has reasonable structure
  // Allow: digits, spaces, hyphens, parentheses, optional + at start
  const formatPattern = /^\+?1?[\s\-()]*\d{3}[\s\-()]*\d{3}[\s\-()]*\d{4}[\s\-()]*$/;
  if (!formatPattern.test(value.trim())) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters for analysis
  const digits = value.replace(/\D/g, '');
  
  // Must have between 10-13 digits (country + mobile + area + subscriber)
  if (digits.length < 10 || digits.length > 13) {
    return false;
  }
  
  // Pattern analysis based on the format rules
  const pattern = /^(?:\+54)?(?:9)?(?:0)?(\d{2,4})(\d{6,8})$/;
  const match = digits.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code first digit must be 1-9 (not 0)
  if (areaCode[0] === '0') {
    return false;
  }
  
  // When no country code provided, must start with trunk prefix 0
  // This means the digits should start with 0
  if (!value.trim().startsWith('+54') && !value.trim().startsWith('0')) {
    return false;
  }
  
  // Validate that the subscriber number is 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Additional format check - ensure reasonable separators
  const formatPattern = /^[\+\d\s-]+$/;
  if (!formatPattern.test(value.trim())) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const name = value.trim();
  
  // Name cannot be empty
  if (!name) {
    return false;
  }
  
  // Check for disallowed characters: digits and special symbols
  // Allow: Unicode letters (including accented), apostrophes, hyphens, spaces
  // Disallow: digits, symbols like @#$%^&*(), etc.
  const invalidCharsPattern = /[\d@#$%^&*()_+={}\[\]|\\:\";'<>?,/`~]/;
  if (invalidCharsPattern.test(name)) {
    return false;
  }
  
  // Allow only letters, spaces, apostrophes, and hyphens
  const validPattern = /^[\p{L}\s'-]+$/u;
  if (!validPattern.test(name)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetterPattern = /\p{L}/u;
  if (!hasLetterPattern.test(name)) {
    return false;
  }
  
  // Reject names that are just spaces, apostrophes, or hyphens
  const nameContent = name.replace(/[\s'-]/g, '');
  if (!nameContent) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm helper for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Must have appropriate length for credit cards (13-19 digits typical)
  if (cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }
  
  // Check for valid credit card patterns
  // Visa: starts with 4, 13 or 16 digits
  const visaPattern = /^4\d{12}(\d{3})?$/;
  // Mastercard: starts with 51-55, exactly 16 digits
  const mastercardPattern = /^5[1-5]\d{14}$/;
  // AmEx: starts with 34 or 37, exactly 15 digits
  const amexPattern = /^3[47]\d{13}$/;
  
  if (!visaPattern.test(cardNumber) && 
      !mastercardPattern.test(cardNumber) && 
      !amexPattern.test(cardNumber)) {
    return false;
  }
  
  // Run Luhn algorithm
  return runLuhnCheck(cardNumber);
}
