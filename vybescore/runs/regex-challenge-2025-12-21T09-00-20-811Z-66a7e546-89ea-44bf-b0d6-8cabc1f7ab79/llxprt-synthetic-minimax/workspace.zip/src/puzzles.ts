/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for the prefix
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    const wordLower = word.toLowerCase();
    return !exceptions.some(exception => 
      wordLower === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use regex to find token after a digit and not at string start
  // Pattern: (?<=^\d) - positive lookbehind to ensure preceded by a digit (but not at string start)
  // We need to capture the digit + token pattern to return full match
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab", "123123", etc.
  // Pattern to match any sequence of 2+ characters followed immediately by the same sequence
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern
  // Supports:
  // - Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Compressed with :: (double colon)
  // - IPv4-mapped IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:dddd.dddd.dddd.dddd
  // Hex groups should be 1-4 hex digits
  
  // More permissive pattern that can appear anywhere in the string
  const ipv6AnywherePattern = /(?:^|[^a-fA-F0-9])(?:(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}|(?:[a-fA-F0-9]{1,4}::){1,7}[a-fA-F0-9]{0,4}|::(?:[a-fA-F0-9]{0,4}:){0,7}[a-fA-F0-9]{0,4}|(?:[a-fA-F0-9]{1,4}:){1,7}::|(?:[a-fA-F0-9]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3})(?:[^a-fA-F0-9]|$)/;
  
  return ipv6AnywherePattern.test(value);
}
