/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure proper sentence separation
  let processed = text.trim();
  
  // Replace multiple spaces with single space
  processed = processed.replace(/\s+/g, ' ');
  
  // Pattern to find sentence boundaries (.?! followed by optional quotes and space)
  // We'll capitalize the letter after sentence endings
  const sentencePattern = /([.!?]+["']?\s*)([a-z])/g;
  
  // Replace with capitalized first letter of each sentence
  processed = processed.replace(sentencePattern, (match, sentenceEnd, firstLetter) => {
    return sentenceEnd + firstLetter.toUpperCase();
  });
  
  // Capitalize the very first character of the text if it's a letter
  if (processed.length > 0 && /[a-z]/.test(processed[0])) {
    processed = processed[0].toUpperCase() + processed.slice(1);
  }
  
  return processed;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http(s):// URLs with common TLDs
  const urlPattern = /\bhttps?:\/\/[^\s"'<>()\[\]{}]*[^\s"'<>()\[\]{}.!?]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation that might be captured
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation at the end
    return url.replace(/[.,!?;]+$/, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https://
  return text.replace(/https?:\/\//g, (match) => {
    if (match === 'https://') {
      return match; // Leave secure URLs unchanged
    }
    return 'https://'; // Upgrade http:// to https://
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs
  const urlPattern = /\bhttp:\/\/([^\/\s]+)([^\s]*)/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Always upgrade scheme to https
    let newUrl = 'https://';
    
    // Check if path should trigger host rewrite
    const hasDynamicContent = /(\?.*|.*\.jsp|.*\.php|.*\.asp|.*\.aspx|.*\.do|.*\.cgi|.*\.pl|.*\.py|cgi-bin)/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicContent) {
      // Rewrite host to docs.<originalhost>
      newUrl += 'docs.' + host + path;
    } else {
      // Keep original host
      newUrl += host + path;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, with some basic month validation)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  // Validate year (reasonable range, say 1900-2100)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  // Return the year as string
  return year.toString();
}
