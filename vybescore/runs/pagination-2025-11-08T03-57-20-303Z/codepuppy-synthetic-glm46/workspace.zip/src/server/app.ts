import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Helper function to validate numeric input
    const validateNumeric = (value: string | undefined, min: number = 1, max: number = 1000): number | undefined | null => {
      if (value === undefined) return undefined;
      
      // Check if value is numeric
      if (!/^\d+$/.test(value.trim())) {
        return null; // Invalid
      }
      
      const num = Number(value.trim());
      
      // Check range
      if (num < min || num > max) {
        return null; // Invalid
      }
      
      return num;
    };

    const page = validateNumeric(pageParam, 1, 1000);
    const limit = validateNumeric(limitParam, 1, 100);

    // Return 400 for invalid parameters
    if (page === null || limit === null) {
      return res.status(400).json({
        error: 'Invalid pagination parameters. page and limit must be positive integers. page ≤ 1000, limit ≤ 100.'
      });
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
