#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];

    if (arg === '--format') {
      args.format = argv[++i];
    } else if (arg === '--output') {
      args.output = argv[++i];
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      if (!args.dataFile) {
        args.dataFile = arg;
      }
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Format is required (use --format <format>)');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      console.error('Error: Invalid data - title is required and must be a string');
      process.exit(1);
    }

    if (!data.summary || typeof data.summary !== 'string') {
      console.error('Error: Invalid data - summary is required and must be a string');
      process.exit(1);
    }

    if (!Array.isArray(data.entries)) {
      console.error('Error: Invalid data - entries is required and must be an array');
      process.exit(1);
    }

    // Validate each entry
    data.entries.forEach((entry, index) => {
      if (!entry.label || typeof entry.label !== 'string') {
        console.error(`Error: Invalid entry at index ${index} - label is required and must be a string`);
        process.exit(1);
      }

      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        console.error(`Error: Invalid entry at index ${index} - amount is required and must be a number`);
        process.exit(1);
      }
    });

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
    } else {
      console.error(`Error reading file: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);

  const data = loadReportData(args.dataFile);
  const options: RenderOptions = { includeTotals: args.includeTotals };

  const output = renderReport(data, args.format, options);

  if (args.output) {
    try {
      writeFileSync(args.output, output);
    } catch (error) {
      console.error(`Error writing output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
