import { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);

  // Blank line after title
  lines.push('');

  // Summary
  lines.push(data.summary);

  // Blank line before entries
  lines.push('');

  // Entries section header
  lines.push('## Entries');

  // Entry bullets
  data.entries.forEach(entry => {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  });

  // Total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalFormatted = total.toFixed(2);
    lines.push('');
    lines.push(`**Total:** $${totalFormatted}`);
  }

  return lines.join('\n');
}