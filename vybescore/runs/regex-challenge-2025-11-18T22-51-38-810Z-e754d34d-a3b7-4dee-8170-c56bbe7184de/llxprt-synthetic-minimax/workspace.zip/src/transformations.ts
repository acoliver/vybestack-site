/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split text into sentences using punctuation (.?!)
  const sentences = text.split(/([.?!]+)\s*/);
  const result: string[] = [];
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    if (sentence.trim() === '') {
      result.push(sentence);
      continue;
    }
    
    if (i === 0 || /^[.?!]+$/.test(sentences[i - 1])) {
      // First sentence or sentence after punctuation - capitalize first letter
      const firstChar = sentence.charAt(0);
      if (firstChar) {
        const capitalized = firstChar.toUpperCase() + sentence.slice(1);
        result.push(capitalized);
      } else {
        result.push(sentence);
      }
    } else {
      // Regular continuation
      result.push(sentence);
    }
  }
  
  return result.join('').replace(/([.?!])([A-Za-z])/g, '$1 $2');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching common protocols
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s<>"']+\b/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation
    const cleaned = url.replace(/[.,;:!?)]*$/g, '');
    return cleaned;
  });
  
  return cleanedUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://, but not https://
  return text.replace(/https?:\/\//gi, match => {
    if (match.toLowerCase() === 'https://') {
      return match; // Keep existing https
    } else {
      return 'https://'; // Convert http to https
    }
  });
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)?/gi, (match, domain, path) => {
    const httpsMatch = 'https://' + domain;
    
    if (!path) {
      return httpsMatch;
    }
    
    // Check for dynamic hints that should skip host rewrite
    const hasDynamicHints = /(\?.*[?&]=)|(\.(cgi|pl|py|jsp|php|asp|aspx|do)\b)|(cgi-bin)/i.test(path);
    
    // Always upgrade to https, but only rewrite host for docs paths without dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      const newHost = 'docs.' + domain;
      return 'https://' + newHost + path;
    }
    
    return httpsMatch + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern for mm/dd/yyyy with proper validation
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (simple validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified)
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (isLeapYear) {
      daysInMonth[1] = 29;
    }
  }
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Validate reasonable year range
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return year.toString();
}