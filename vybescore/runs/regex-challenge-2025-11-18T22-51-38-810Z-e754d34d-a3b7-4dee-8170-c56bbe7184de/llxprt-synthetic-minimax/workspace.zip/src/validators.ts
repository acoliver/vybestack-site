export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function for Luhn checksum validation (used in credit card validation)
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with common patterns
  // Allows name+tag@example.co.uk, rejects double dots, trailing dots, domains with underscores
  
  // Remove leading/trailing whitespace
  value = value.trim();
  
  // Basic structure check: must have @ and dot in domain
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Check for obviously invalid patterns
  const invalidPatterns = [
    /\.\./,           // double dots
    /\.\./,           // double dots (additional check)
    /\..$/,           // trailing dot
    /^@/,             // starts with @
    /@.*@/,           // multiple @ symbols
    /@.*\.\./,        // @ followed by double dots
  ];
  
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return emailRegex.test(value);
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for basic validation
  const cleanValue = value.replace(/\D/g, '');
  
  // Check minimum length
  if (cleanValue.length < 10) {
    return false;
  }
  
  // Extract area code (first 3 digits when country code is present)
  let areaCode: string;
  let remainingDigits: string;
  
  if (cleanValue.length === 11 && cleanValue.startsWith('1')) {
    // Has country code +1
    areaCode = cleanValue.substring(1, 4);
    remainingDigits = cleanValue.substring(4);
  } else if (cleanValue.length === 10) {
    // No country code
    areaCode = cleanValue.substring(0, 3);
    remainingDigits = cleanValue.substring(3);
  } else {
    return false;
  }
  
  // Check area code: first digit cannot be 0 or 1 for US numbers
  if (areaCode.charAt(0) === '0' || areaCode.charAt(0) === '1') {
    return false;
  }
  
  // Check remaining digits: should be 7 digits (3+4 format)
  if (remainingDigits.length !== 7) {
    return false;
  }
  
  // Additional validation: ensure the format matches common US phone patterns
  const phoneRegex = /^(?:\+1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}$/;
  
  // If options.allowExtensions is true, allow extensions
  if (options?.allowExtensions) {
    const extensionRegex = /^(?:\+1[\s.-]?)?(?:\(?\d{3}\)?[\s.-]?)?\d{3}[\s.-]?\d{4}(?:\s*(?:ext|x|extension)\s*\d{1,5})?$/i;
    return extensionRegex.test(value);
  }
  
  return phoneRegex.test(value);
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space/hyphen characters for validation
  // IMPORTANT: Include + in the allowed characters to preserve country code
  const cleanValue = value.replace(/[^\d\s+-]/g, '');
  const digitsOnly = cleanValue.replace(/\D/g, '');
  
  // Check minimum digit count (at least 10 digits for most formats)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Argentine phone number patterns:
  // +54 9 11 1234 5678 (mobile with country code)
  // 011 1234 5678 (Buenos Aires landline)
  // +54 341 123 4567 (mobile with country code, 3-digit area code)
  // 0341 4234567 (landline with 4-digit area code)
  
  const patterns = [
    // +54 9 11 1234 5678 (mobile with country code)
    /^\+54\s*9\s*11\s*\d{4}\s*\d{4}$/,
    
    // +54 9 XXX XXXXXXX (mobile with country code, 3-digit area code)
    /^\+54\s*9\s*[1-9]\d{2}\s*\d{7}$/,
    
    // +54 XXX XXXXXXX (landline with country code, 3-digit area code)
    /^\+54\s*[1-9]\d{2}\s*\d{7}$/,
    
    // +54 XXXX XXXXXXX (landline with country code, 4-digit area code)
    /^\+54\s*[1-9]\d{3}\s*\d{7}$/,
    
    // 09XX XXXXXXX (mobile, no country code)
    /^0\s*9\s*[1-9]\d{2}\s*\d{7}$/,
    
    // 011 XXXXXXXX (Buenos Aires landline)
    /^011\s*\d{8}$/,
    
    // 0XXX XXXXXXX (landline, no country code, 3-digit area code)
    /^0\s*[1-9]\d{2}\s*\d{7}$/,
    
    // 0XXXX XXXXXXX (landline, no country code, 4-digit area code)
    /^0\s*[1-9]\d{3}\s*\d{7}$/,
    
    // Variations with spaces and hyphens
    /^0\s*[1-9]\d{2}\s*[- ]?\d{3}\s*[- ]?\d{4}$/,
    /^0\s*9\s*[1-9]\d{2}\s*[- ]?\d{3}\s*[- ]?\d{4}$/,
    /^\+54\s*[1-9]\d{2}\s*[- ]?\d{3}\s*[- ]?\d{4}$/,
    /^\+54\s*9\s*[1-9]\d{2}\s*[- ]?\d{3}\s*[- ]?\d{4}$/,
    /^0\s*[1-9]\d{3}\s*[- ]?\d{7}$/,
    /^\+54\s*[1-9]\d{3}\s*[- ]?\d{7}$/,
  ];
  
  return patterns.some(pattern => pattern.test(cleanValue));
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  
  // Remove leading/trailing whitespace
  value = value.trim();
  
  if (value.length === 0) {
    return false;
  }
  
  // Pattern allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes (')
  // - Hyphens (-)
  // - Spaces
  // Excludes digits and other symbols
  const nameRegex = /^[\p{L}][\p{L}'-]*(?:\s+[\p{L}][\p{L}'-]*)*$/u;
  
  // Additional check: ensure no "X Æ A-12" style names or purely numeric
  if (/\d/.test(value) || /[^\p{L}\s'’-]/u.test(value)) {
    return false;
  }
  
  // Check for suspicious patterns that might indicate fake names
  const suspiciousPatterns = [
    /^[Ææ]/i,           // Starts with Æ
    /[Ææ]/,             // Contains Æ
    /[\d]/,             // Contains digits
    /^[^a-zA-ZÀ-ÿ]/i,   // Doesn't start with a letter (after trim)
  ];
  
  for (const pattern of suspiciousPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers using regex patterns for major card types and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Card type validation patterns
  const cardPatterns = {
    visa: /^4\d{12}(\d{3})?(\d{3})?$/,              // Visa: 13, 16, or 19 digits
    mastercard: /^5[1-5]\d{14}$/,                   // Mastercard: 16 digits starting with 51-55
    amex: /^3[47]\d{13}$/,                          // American Express: 15 digits starting with 34 or 37
    discover: /^6(?:011|5\d{2})\d{12}$/,            // Discover: 16 digits starting with 6011 or 65
    diners: /^3(?:0[0-5]|[68]\d)\d{11}$/,          // Diners Club: 14 digits starting with 30, 36, or 38
  };
  
  let isValidCard = false;
  
  // Check against all card patterns
  for (const pattern of Object.values(cardPatterns)) {
    if (pattern.test(cleanValue)) {
      isValidCard = true;
      break;
    }
  }
  
  if (!isValidCard) {
    return false;
  }
  
  // Apply Luhn checksum validation
  return runLuhnCheck(cleanValue);
}