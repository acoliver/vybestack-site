/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary regex for the prefix
  const prefixPattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const normalizedMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      normalizedMatch === exception.toLowerCase()
    );
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // We need the full matched strings (digit + token)
  const fullPattern = new RegExp(`\\d${token}`, 'gi');
  return text.match(fullPattern) || [];
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^a-zA-Z0-9]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // This looks for any 2-character sequence repeated immediately
  const repeatedSequencePattern = /(..)\1{1,}/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  // Check for longer repeated patterns like "abcabc"
  const repeatedPatternPattern = /(.{2,})\1{1,}/;
  if (repeatedPatternPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude if it contains IPv4 pattern (dots with 1-3 digits)
  const containsIPv4 = /\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/.test(value);
  if (containsIPv4) {
    return false;
  }
  
  // IPv6 addresses contain :: (double colon) compression marker
  // This is the key characteristic that distinguishes IPv6 from IPv4
  
  // Split by spaces to examine each word
  const words = value.split(/\s+/);
  
  for (const word of words) {
    // Remove any trailing punctuation
    const cleanWord = word.replace(/[.,;:!?)]*$/g, '');
    
    if (cleanWord.length === 0) continue;
    
    // Check if the word contains IPv6 compression marker and valid hex digits
    const ipv6Pattern = /^[0-9a-fA-F:]*::[0-9a-fA-F:]*$/;
    
    if (ipv6Pattern.test(cleanWord)) {
      return true;
    }
  }
  
  return false;
}