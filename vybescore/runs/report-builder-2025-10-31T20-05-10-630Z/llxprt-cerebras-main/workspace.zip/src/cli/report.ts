#!/usr/bin/env node

import { readFile } from 'fs/promises';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals?: boolean;
}

async function parseArgs(): Promise<{ dataFile: string; options: CliOptions }> {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  
  const options: CliOptions = {
    format: 'text'
  };
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Missing format value');
      }
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      options.format = format;
      i++; // Skip next argument
    } else if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Missing output path');
      }
      options.output = args[i + 1];
      i++; // Skip next argument
    } else if (args[i] === '--includeTotals') {
      options.includeTotals = true;
    }
  }
  
  return { dataFile, options };
}

async function loadData(filePath: string): Promise<ReportData> {
  try {
    const data = await readFile(filePath, 'utf-8');
    return JSON.parse(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

async function main() {
  try {
    const { dataFile, options } = await parseArgs();
    const data = await loadData(dataFile);
    
    let output: string;
    
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(data, { includeTotals: options.includeTotals });
        break;
      case 'text':
        output = renderText(data, { includeTotals: options.includeTotals });
        break;
      default:
        throw new Error(`Unsupported format: ${options.format}`);
    }
    
    if (options.output) {
      // In a real implementation, we would write to the file
      // For now, we'll just print to stdout as requested
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'An unknown error occurred');
    process.exit(1);
  }
}

main();