#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters, supportedFormats } from '../formats/index.js';

/**
 * Parses command line arguments using Node's built-in argument parsing
 */
function parseArgs(): { dataPath: string; options: RenderOptions } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  
  // Parse options
  const options: RenderOptions = {
    format: 'text' // default, will be overridden
  };
  
  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i + 1];
      if (!supportedFormats.includes(formatValue as 'markdown' | 'text')) {
        console.error(`Error: Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      options.format = formatValue as 'markdown' | 'text';
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      options.outputPath = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
      i += 1;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }
  
  return { dataPath, options };
}

/**
 * Validates and parses the JSON data file
 */
function loadData(dataPath: string): ReportData {
  try {
    const content = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    // Validate the structure
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid data: expected an object');
    }
    
    const dataObj = data as Record<string, unknown>;
    const { title, summary, entries } = dataObj;
    
    if (typeof title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    
    if (typeof summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    
    if (!Array.isArray(entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    for (const entry of entries) {
      if (!entry || typeof entry !== 'object') {
        throw new Error('Invalid data: each entry must be an object');
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error('Invalid data: each entry must have a label string');
      }
      
      if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
        throw new Error('Invalid data: each entry must have a valid amount number');
      }
    }
    
    return { title, summary, entries } as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in ${dataPath}: ${error.message}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

/**
 * Main CLI execution
 */
function main(): void {
  const { dataPath, options } = parseArgs();
  const data = loadData(dataPath);
  
  // Get the appropriate formatter
  const formatter = formatters[options.format];
  if (!formatter) {
    console.error(`Error: Unsupported format: ${options.format}`);
    process.exit(1);
  }
  
  // Render the report
  const output = formatter.render(data, options);
  
  // Write output
  if (options.outputPath) {
    try {
      writeFileSync(options.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error writing to ${options.outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

// Run the CLI
main();