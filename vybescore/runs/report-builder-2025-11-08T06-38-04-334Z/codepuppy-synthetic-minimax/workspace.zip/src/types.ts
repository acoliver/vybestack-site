/**
 * Report entry data structure
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * CLI options for rendering reports
 */
export interface RenderOptions {
  format: 'markdown' | 'text';
  includeTotals?: boolean;
  outputPath?: string;
}

/**
 * Report renderer interface
 */
export interface ReportRenderer {
  render(data: ReportData, options: RenderOptions): string;
}