import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

/**
 * Formats amount as string with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates total of all entry amounts
 */
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Text report renderer
 */
export function renderText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];
  
  // Title and summary
  lines.push(data.title);
  lines.push(data.summary);
  lines.push('');
  
  // Entries
  lines.push('Entries:');
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  // Total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
}

/**
 * Export the renderer conforming to the ReportRenderer interface
 */
export const textRenderer: ReportRenderer = {
  render: renderText
};