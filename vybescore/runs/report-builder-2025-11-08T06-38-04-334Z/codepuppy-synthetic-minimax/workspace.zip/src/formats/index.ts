import type { ReportRenderer } from '../types.js';
import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';

/**
 * Registry of available report formatters
 */
export const formatters: Record<string, ReportRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer
};

/**
 * List of supported format names
 */
export const supportedFormats = Object.keys(formatters) as (keyof typeof formatters)[];