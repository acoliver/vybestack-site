import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, FormatOptions, FORMATS, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: FormatType;
  output?: string;
  includeTotals: boolean;
}

const parseArgs = (args: string[]): ParsedArgs => {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  const parsed: ParsedArgs = {
    dataFile,
    format: 'markdown' as FormatType,
    includeTotals: false
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const format = args[++i];
      if (!format) {
        throw new Error('--format requires a value');
      }
      if (format !== FORMATS.markdown && format !== FORMATS.text) {
        throw new Error(`Unsupported format '${format}'. Supported formats: ${FORMATS.markdown}, ${FORMATS.text}`);
      }
      parsed.format = format;
    } else if (arg === '--output') {
      const output = args[++i];
      if (!output) {
        throw new Error('--output requires a value');
      }
      parsed.output = output;
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  return parsed;
};

const validateReportData = (data: unknown): ReportData => {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON data: expected an object');
  }

  const reportData = data as ReportData;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON data: title must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON data: summary must be a string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON data: entries must be an array');
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];

    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid JSON data: entries[${i}].label must be a string`);
    }

    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid JSON data: entries[${i}].amount must be a number`);
    }
  }

  return reportData;
};

const getFormatter = (format: FormatType) => {
  switch (format) {
    case FORMATS.markdown:
      return renderMarkdown;
    case FORMATS.text:
      return renderText;
    default:
      throw new Error(`Unsupported format '${format}'. Supported formats: ${FORMATS.markdown}, ${FORMATS.text}`);
  }
};

const main = (): void => {
  try {
    const args = process.argv.slice(2);
    const parsedArgs = parseArgs(args);

    const jsonData = readFileSync(parsedArgs.dataFile, 'utf-8');
    const data = JSON.parse(jsonData);
    const reportData = validateReportData(data);

    const options: FormatOptions = {
      includeTotals: parsedArgs.includeTotals
    };

    const formatter = getFormatter(parsedArgs.format);
    const output = formatter.format(reportData, options);

    if (parsedArgs.output) {
      writeFileSync(parsedArgs.output, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    process.stderr.write(`Error: ${message}\n`);
    process.exit(1);
  }
};

main();