/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) and includes padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string is valid Base64.
 */
function isValidBase64(input: string): boolean {
  // Check empty input
  if (!input) {
    return false;
  }
  
  // Base64 alphabet: A-Z, a-z, 0-9, +, /, and optional padding with =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check if it matches the pattern
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check padding rules: padding can only appear at the end and max 2 characters
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be at the end
    const paddingOnly = input.substring(paddingIndex);
    if (!/^(={1,2})$/.test(paddingOnly)) {
      return false;
    }
    
    // Overall length must be divisible by 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input first
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    // Use standard base64 encoding
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
