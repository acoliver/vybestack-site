import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('validates pagination parameters correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // Test invalid page parameter - non-numeric
    let response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page parameter must be a valid number');

    // Test invalid page parameter - negative
    response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page parameter must be greater than 0');

    // Test invalid page parameter - zero
    response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page parameter must be greater than 0');

    // Test invalid page parameter - excessive
    response = await request(app).get('/inventory?page=1001');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page parameter must not exceed 1000');

    // Test invalid limit parameter - non-numeric
    response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit parameter must be a valid number');

    // Test invalid limit parameter - negative
    response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit parameter must be greater than 0');

    // Test invalid limit parameter - zero
    response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit parameter must be greater than 0');

    // Test invalid limit parameter - excessive
    response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit parameter must not exceed 100');
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // Test default pagination (page 1, limit 5)
    let response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15); // We have 15 items in seed data
    expect(response.body.hasNext).toBe(true);

    // Test specific pagination (page 2, limit 3)
    response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);

    // Test last page with no next
    response = await request(app).get('/inventory?page=5&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(5);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });

  it('returns correct data slices across pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // Get first page
    let response = await request(app).get('/inventory?page=1&limit=3');
    expect(response.status).toBe(200);
    const firstPageIds = response.body.items.map((item: { id: number }) => item.id);
    expect(firstPageIds).toEqual([1, 2, 3]);

    // Get second page
    response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    const secondPageIds = response.body.items.map((item: { id: number }) => item.id);
    expect(secondPageIds).toEqual([4, 5, 6]);

    // Get third page
    response = await request(app).get('/inventory?page=3&limit=3');
    expect(response.status).toBe(200);
    const thirdPageIds = response.body.items.map((item: { id: number }) => item.id);
    expect(thirdPageIds).toEqual([7, 8, 9]);
  });

  it('handles empty result for pages beyond available data', async () => {
    const db = await createDatabase();
    const app = await createApp(db);

    // Request page that doesn't exist
    const response = await request(app).get('/inventory?page=10&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(10);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(0);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });
});
