/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences, collapse extra spaces.
 * Try to preserve abbreviations like "Dr." when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // First, normalize spaces - collapse multiple spaces into one
  let result = text.replace(/[ \t]+/g, ' ');
  
  // Ensure exactly one space after sentence endings (.!?)
  // But be careful with abbreviations
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'i.e', 'e.g', 'St', 'Ave'];
  
  // Add space after sentence terminators if missing
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Capitalize first letter of text
  result = result.replace(/^([a-z])/, (_, char) => char.toUpperCase());
  
  // Capitalize after sentence terminators, but check for abbreviations
  const sentences = result.split(/(?<=[.!?])\s+/);
  
  const capitalized = sentences.map((sentence, index) => {
    if (sentence.length === 0) return '';
    
    // Check if this might be an abbreviation (starts a new sentence but the previous ended with a period)
    if (index > 0) {
      const prevSentence = sentences[index - 1];
      const lastWord = prevSentence?.trim().split(/\s+/).pop()?.toLowerCase();
      if (lastWord && abbreviations.some(abbr => lastWord.startsWith(abbr))) {
        // This might be part of the same thought, don't capitalize
        return sentence.charAt(0).toLowerCase() + sentence.slice(1);
      }
    }
    
    // Capitalize first letter
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  result = capitalized.join(' ');
  
  // Clean up any multiple spaces that might have been introduced
  result = result.replace(/ +/g, ' ');
  
  return result.trim();
}

/**
 * Extract URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: http:// or https:// followed by domain and path
  // Must include domain with at least one dot (e.g., example.com)
  // Exclude trailing punctuation like .,;!?) etc.
  const urlPattern = /https?:\/\/[^\s<>,.!?;:()[\]{}"']+?\.[^\s<>,.!?;:()[\]{}"']+(?<![.,!?;:()[\]{}"'])/g;
  
  const matches = text.match(urlPattern) || [];
  return matches;
}

/**
 * Convert all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for http://example.com/ URLs
  const pattern = /(http:\/\/example\.com\/[^\s]*)/gi;
  
  return text.replace(pattern, (url) => {
    let result = url;
    
    // Always upgrade to https
    result = result.replace(/^http:\/\//i, 'https://');
    
    // Extract path part
    const pathMatch = result.match(/^https:\/\/example\.com(\/.*)$/i);
    
    if (pathMatch) {
      const path = pathMatch[1];
      
      // Check for dynamic hints that should skip host rewrite
      const hasDynamicHint = /[?&=]|\/cgi-bin\/|\/.*\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|\?|$)/i.test(path);
      
      // Check if path starts with /docs/
      const startsWithDocs = /^\/docs\//i.test(path);
      
      if (startsWithDocs && !hasDynamicHint) {
        // Rewrite host to docs.example.com
        result = result.replace(/^https:\/\/example\.com/i, 'https://docs.example.com');
      }
    }
    
    return result;
  });
}

/**
 * Extract year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [
    31, // Jan
    month === 2 ? (isLeapYear(parseInt(year, 10)) ? 29 : 28) : 0, // Feb (handled separately)
    31, // Mar
    30, // Apr
    31, // May
    30, // Jun
    31, // Jul
    31, // Aug
    30, // Sep
    31, // Oct
    30, // Nov
    31  // Dec
  ];
  
  // Handle February
  let maxDay;
  if (month === 2) {
    maxDay = isLeapYear(parseInt(year, 10)) ? 29 : 28;
  } else {
    maxDay = daysInMonth[month - 1];
  }
  
  if (day < 1 || day > maxDay) return 'N/A';
  
  return year;
}

/**
 * Helper to check if a year is a leap year.
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}
