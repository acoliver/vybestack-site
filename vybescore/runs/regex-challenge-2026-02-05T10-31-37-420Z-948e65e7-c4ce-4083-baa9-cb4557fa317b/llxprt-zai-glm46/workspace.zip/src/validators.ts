export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant-ish email validation
  // Local part: letters, digits, and special chars !#$%&'*+/=?^_`{|}~-
  // But no consecutive dots, no leading/trailing dots
  // Domain: letters, digits, hyphens (no underscores), at least one dot
  
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  
  // Additional checks for specific reject patterns
  if (!emailRegex.test(value)) return false;
  
  // Check for double dots in local or domain part
  if (value.includes('..')) return false;
  
  // Check for leading or trailing dots
  const [local, domain] = value.split('@');
  if (local.startsWith('.') || local.endsWith('.')) return false;
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  
  // Domain should not contain underscores
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + at start
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  const digits = cleaned.startsWith('+1') ? cleaned.slice(2) : cleaned.startsWith('+') ? cleaned.slice(1) : cleaned;
  
  // Must be exactly 10 digits for US numbers
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') return false;
  
  // Exchange code (second group of 3) cannot start with 0 or 1
  if (digits[3] === '0' || digits[3] === '1') return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers:
  // Optional +54 country code
  // Optional 0 trunk prefix (required if country code is omitted)
  // Optional 9 mobile indicator (between country/trunk and area code)
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  
  // Pattern with country code: +54 [9] area subscriber
  // The 9 is optional and comes between country code and area code
  const withCountry = /^\+54(?:9)?(\d{2,4})(\d{6,8})$/;
  
  // Pattern without country code: 0 [9] area subscriber (trunk required)
  // The 9 is optional and comes between trunk prefix and area code
  const withoutCountry = /^0(?:9)?(\d{2,4})(\d{6,8})$/;
  
  const matchCountry = cleaned.match(withCountry);
  if (matchCountry) {
    const [, area] = matchCountry;
    // Area code must start with 1-9
    if (area[0] < '1' || area[0] > '9') return false;
    return true;
  }
  
  const matchNoCountry = cleaned.match(withoutCountry);
  if (matchNoCountry) {
    const [, area] = matchNoCountry;
    // Area code must start with 1-9
    if (area[0] < '1' || area[0] > '9') return false;
    return true;
  }
  
  return false;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (value.length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Check for digits in the name (should be rejected)
  if (/\d/.test(value)) return false;
  
  // Reject pure symbols or special characters
  const onlySpecial = /^['\-\s]+$/.test(value);
  if (onlySpecial) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm helper.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: starts with 4, length 13, 16, or 19
  const visa = /^4\d{12}(\d{3}(\d{3})?)?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercard = /^(?:5[1-5]\d{2}|2[2-7]\d{2})\d{12}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amex = /^3[47]\d{13}$/;
  
  const validPrefix = visa.test(cleaned) || mastercard.test(cleaned) || amex.test(cleaned);
  if (!validPrefix) return false;
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
