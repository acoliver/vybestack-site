/**
 * Find words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with the prefix
  // \b ensures word boundary
  const pattern = new RegExp(`\\b(${escapedPrefix}[\\w'-]*)`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const lowerExceptions = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(word => !lowerExceptions.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start.
 * Uses lookahead/lookbehind to ensure token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, use lookahead to ensure we capture the full match
  // The pattern should match the digit + token combination
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength.
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for repeated sequences (e.g., abab, abcabc, 1212)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + 2 * len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Can use :: shorthand (double colon) for consecutive zero groups
  // - Can end with an IPv4 address in the last two groups
  
  // First, exclude pure IPv4 addresses
  // IPv4: four groups of 1-3 digits (0-255) separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Try to match IPv6 at any position in the string
  // Full form: 8 groups of 1-4 hex digits (with colons between them)
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Compressed form with :: (can be at start, middle, or end)
  const ipv6Compressed = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // IPv6 with IPv4 embedded (last two groups are IPv4)
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:){6}(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Compressed IPv6 with IPv4
  const ipv6CompressedWithIPv4 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check for any IPv6 pattern in the value
  if (ipv6Full.test(value)) return true;
  if (ipv6Compressed.test(value)) return true;
  if (ipv6WithIPv4.test(value)) return true;
  if (ipv6CompressedWithIPv4.test(value)) return true;
  
  return false;
}
