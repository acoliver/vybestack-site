const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate that the input string conforms to Base64 encoding rules.
 * Returns true if valid, false otherwise.
 * Accepts both padded and unpadded Base64 strings.
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid Base64
  if (input.length === 0) {
    return false;
  }

  // Check for valid Base64 characters (allowing unpadded strings)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Check padding is only at the end and at most 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return false;
    }
    // If padding is present, total length must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }

  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses the standard Base64 alphabet and rejects invalid input.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding produced valid UTF-8
    // If the input was invalid, Buffer.from may not throw but produce empty or wrong output
    // We verify by checking if we got a valid result
    if (buffer.length === 0 && input.length > 0) {
      // Non-empty input that produces empty buffer is likely invalid
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
