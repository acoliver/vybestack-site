import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';

let server: http.Server;
let app: ReturnType<typeof import('express').Express>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Set a different port for testing to avoid conflicts
  process.env.PORT = '3536';
  
  const serverModule = await import('../../src/server.js');
  app = serverModule.app;
  await serverModule.initializeDatabase();
  
  // Start the server manually
  const PORT = process.env.PORT || 3536;
  server = app.listen(PORT);
  
  // Wait a bit for server to be ready
  await new Promise(resolve => setTimeout(resolve, 500));
});

afterAll(async () => {
  if (server) {
    await new Promise<void>((resolve) => {
      server.close(() => resolve());
    });
  }
  const serverModule = await import('../../src/server.js');
  serverModule.gracefulShutdown();
  
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
  });

  it('shows validation errors for empty fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({});

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Email is required');
  });

  it('shows validation error for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'not-an-email',
        phone: '@1 555-123-4567'
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Please enter a valid email address');
  });

  it('shows validation error for invalid phone', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'john@example.com',
        phone: 'invalid-phone!@#'
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number may contain digits, spaces, parentheses, dashes, and a leading @');
  });

  it('accepts international phone formats', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 High St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane@example.co.uk',
        phone: '@44 20 7946 0958'
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test Ave',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'test@example.com',
        phone: '@54 9 11 1234-5678'
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('Return to the form');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'IL',
        postalCode: '62701',
        country: 'USA',
        email: 'invalid-email',
        phone: '555-1234'
      });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('input[name="firstName"]').val()).toBe('John');
    expect($('input[name="email"]').val()).toBe('invalid-email');
  });
});
