declare module 'sql.js' {
  export interface SqlValue {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    [key: string]: any;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(values?: unknown[]): void;
    get(values?: unknown[]): SqlValue | undefined;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    all(values?: unknown[]): any[];
    free(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    values: any[][];
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  export default function initSqlJs(config?: { locateFile?: (filename: string) => string }): Promise<SqlJsStatic>;
}
