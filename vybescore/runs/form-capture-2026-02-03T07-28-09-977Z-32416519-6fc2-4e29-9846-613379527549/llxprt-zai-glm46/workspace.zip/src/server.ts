import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// When compiled, __dirname will be dist/, but we need to reference src/ for templates
const isDev = fs.existsSync(path.resolve(__dirname, 'templates'));
const TEMPLATES_PATH = isDev 
  ? path.resolve(__dirname, 'templates')
  : path.resolve(__dirname, '../src/templates');
const PUBLIC_PATH = path.resolve(__dirname, '../public');
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/public', express.static(PUBLIC_PATH));

app.set('view engine', 'ejs');
app.set('views', TEMPLATES_PATH);

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^@?[\d\s\-()+]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(data: Partial<FormData>): string[] {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode.trim())) {
    errors.push('Postal / Zip code must contain only letters, digits, spaces, and hyphens');
  }
  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }
  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(data.email.trim())) {
    errors.push('Please enter a valid email address');
  }
  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone.trim())) {
    errors.push('Phone number may contain digits, spaces, parentheses, dashes, and a leading @');
  }

  return errors;
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400);
    res.render('form', {
      errors,
      values: formData
    });
    return;
  }

  if (!db) {
    errors.push('Database not available');
    res.status(500);
    res.render('form', {
      errors,
      values: formData
    });
    return;
  }

  try {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      formData.firstName!.trim(),
      formData.lastName!.trim(),
      formData.streetAddress!.trim(),
      formData.city!.trim(),
      formData.stateProvince!.trim(),
      formData.postalCode!.trim(),
      formData.country!.trim(),
      formData.email!.trim(),
      formData.phone!.trim()
    ]);
    stmt.free();

    const data = db.export();
    const dbBuffer = Buffer.from(data);
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    fs.writeFileSync(DB_PATH, dbBuffer);

    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!.trim())}`);
  } catch (err) {
    errors.push('Failed to save submission');
    res.status(500);
    res.render('form', {
      errors,
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    let dbData: Uint8Array | undefined;

    if (fs.existsSync(DB_PATH)) {
      const dbFile = fs.readFileSync(DB_PATH);
      dbData = new Uint8Array(dbFile);
    }

    db = new SQL.Database(dbData);

    if (dbData === undefined) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
    }
  } catch (err) {
    console.error('Failed to initialize database:', err);
    throw err;
  }
}

let server: ReturnType<typeof app.listen>;

async function startServer() {
  await initializeDatabase();

  server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  process.on('SIGTERM', shutdownAndExit);
  process.on('SIGINT', shutdownAndExit);
}

function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }
  if (db) {
    db.close();
    console.log('Database closed');
  }
}

function shutdownAndExit() {
  gracefulShutdown();
  process.exit(0);
}

// Only start server if this file is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { app, initializeDatabase, gracefulShutdown, startServer };
export default app;
