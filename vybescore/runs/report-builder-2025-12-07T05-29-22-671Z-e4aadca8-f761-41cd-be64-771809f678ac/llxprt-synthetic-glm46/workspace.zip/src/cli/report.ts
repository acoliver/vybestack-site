#!/usr/bin/env node

import { promises as fs } from 'fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 2) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        format = args[i + 1];
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('--output requires a path');
        }
        outputPath = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        throw new Error(`Unknown argument: ${args[i]}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries is required and must be an array');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: entry ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: entry ${index} label is required and must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid data: entry ${index} amount is required and must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs(process.argv.slice(2));

    const dataRaw = await fs.readFile(dataPath, 'utf8');
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(dataRaw);
    } catch (error) {
      throw new Error(`Failed to parse JSON: ${error instanceof Error ? error.message : String(error)}`);
    }

    const data = validateReportData(jsonData);

    const options: RenderOptions = { includeTotals };
    
    let output: string;
    switch (format) {
      case 'markdown':
        output = renderMarkdown(data, options);
        break;
      case 'text':
        output = renderText(data, options);
        break;
      default:
        throw new Error(`Unsupported format: ${format}`);
    }

    if (outputPath) {
      await fs.writeFile(outputPath, output, 'utf8');
      console.error(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();