/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const INVALID_BASE64_INPUT = 'Invalid Base64 input';

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error(INVALID_BASE64_INPUT);
  }

  // Check for correct padding placement - if present, padding must be at the end only
  const paddingStartIndex = input.indexOf('=');
  if (paddingStartIndex !== -1) {
    // Check if there are non-padding characters after padding starts
    for (let i = paddingStartIndex + 1; i < input.length; i++) {
      if (input[i] !== '=') {
        throw new Error(INVALID_BASE64_INPUT);
      }
    }
  }

  try {
    // Convert Buffer manually to validate proper UTF-8
    const buffer = Buffer.from(input, 'base64');
    const decoded = buffer.toString('utf8');
    
    // If buffer contains invalid UTF-8 sequences, handle gracefully
    if (decoded.includes('\ufffd')) {
      throw new Error(INVALID_BASE64_INPUT);
    }
    
    return decoded;
  } catch (error) {
    throw new Error(INVALID_BASE64_INPUT);
  }
}
