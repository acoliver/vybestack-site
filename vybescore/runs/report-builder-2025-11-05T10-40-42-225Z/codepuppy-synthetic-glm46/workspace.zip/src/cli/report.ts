#!/usr/bin/env node

import { writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportOptions } from '../types/index.js';
import { parseJsonFile, validateReportData } from '../utils/validation.js';
import { parseArgs, type CliArgs } from '../utils/args.js';

function main(): void {
  try {
    const args: CliArgs = parseArgs();
    
    // Load and validate data
    const rawData = parseJsonFile(args.dataFile);
    validateReportData(rawData);
    const data: ReportData = rawData as ReportData;
    
    // Prepare render options
    const options: ReportOptions = {
      format: args.format,
      includeTotals: args.includeTotals,
    };
    
    // Render report
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(data, options);
        break;
      case 'text':
        output = renderText(data, options);
        break;
      default:
        // This should never happen due to validation in parseArgs
        throw new Error('Unsupported format');
    }
    
    // Write output
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
    
    process.exit(0);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();