import { readFileSync } from 'fs';
import type { ReportData, ReportEntry } from '../types/index.js';

function validateReportEntry(entry: unknown): entry is ReportEntry {
  if (typeof entry !== 'object' || entry === null) {
    return false;
  }
  const obj = entry as { label?: unknown; amount?: unknown };
  return typeof obj.label === 'string' && typeof obj.amount === 'number';
}

export function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as { title?: unknown; summary?: unknown; entries?: unknown };
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries field');
  }
  
  if (!obj.entries.every(validateReportEntry)) {
    throw new Error('Invalid report data: one or more entries are malformed');
  }
  
  return true;
}

export function parseJsonFile(filePath: string): unknown {
  try {
    const content = readFileSync(filePath, 'utf8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}