export interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const dataFile = args[0];
  if (!dataFile) {
    throw new Error('Data file path is required');
  }
  
  // Parse arguments
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output') {
      outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    throw new Error('--format argument is required');
  }
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error('Unsupported format');
  }
  
  return {
    dataFile,
    format: format as 'markdown' | 'text',
    outputPath,
    includeTotals,
  };
}