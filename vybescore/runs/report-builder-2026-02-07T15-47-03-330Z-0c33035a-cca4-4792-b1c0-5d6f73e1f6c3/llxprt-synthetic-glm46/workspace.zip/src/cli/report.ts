#!/usr/bin/env node

import fs from 'node:fs';

import type { ReportData, ReportOptions, FormatType } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

function parseArguments(): {
  inputPath: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputPath = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('--format is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as FormatType;
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Unsupported format');
    process.exit(1);
  }
  
  return { inputPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid data: each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: entry.label must be a string');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: entry.amount must be a number');
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const { inputPath, format, outputPath, includeTotals } = parseArguments();
    
    if (!fs.existsSync(inputPath)) {
      console.error(`File not found: ${inputPath}`);
      process.exit(1);
    }
    
    const fileContent = fs.readFileSync(inputPath, 'utf-8');
    
    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error('Invalid JSON format');
      process.exit(1);
    }
    
    const reportData = validateReportData(data);
    const options: ReportOptions = { includeTotals };
    
    let result: string;
    if (format === 'markdown') {
      result = markdownRenderer.render(reportData, options);
    } else {
      result = textRenderer.render(reportData, options);
    }
    
    if (outputPath) {
      fs.writeFileSync(outputPath, result, 'utf-8');
    } else {
      console.log(result);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
