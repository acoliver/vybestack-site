import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';
import { validatePaginationParams } from './validation';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;
    
    const validatedParams = validatePaginationParams(pageParam, limitParam);
    
    if (!validatedParams) {
      return res.status(400).json({
        error: 'Invalid page or limit parameters. Page must be a positive integer, limit must be between 1 and 100.'
      });
    }

    const { page, limit } = validatedParams;
    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
