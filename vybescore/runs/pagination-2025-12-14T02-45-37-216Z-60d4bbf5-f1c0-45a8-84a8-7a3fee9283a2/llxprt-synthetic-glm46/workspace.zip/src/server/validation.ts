export function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } | null {
  const DEFAULT_PAGE = 1;
  const DEFAULT_LIMIT = 5;
  const MAX_LIMIT = 100;

  const page = pageParam ? Number(pageParam) : DEFAULT_PAGE;
  const limit = limitParam ? Number(limitParam) : DEFAULT_LIMIT;

  // Validate that page is a positive integer and not excessively large
  if (!Number.isInteger(page) || page < 1 || page > 10000) {
    return null;
  }

  // Validate that limit is a positive integer and within reasonable bounds
  if (!Number.isInteger(limit) || limit < 1 || limit > MAX_LIMIT) {
    return null;
  }

  return { page, limit };
}