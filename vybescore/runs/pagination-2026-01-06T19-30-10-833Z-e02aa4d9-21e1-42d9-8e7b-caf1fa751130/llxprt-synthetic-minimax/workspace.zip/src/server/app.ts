import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Parse and validate page parameter
      let page = 1;
      if (pageParam) {
        const parsedPage = Number(pageParam);
        if (!Number.isInteger(parsedPage) || parsedPage <= 0) {
          return res.status(400).json({ error: 'page must be a positive integer' });
        }
        page = parsedPage;
      }

      // Parse and validate limit parameter
      let limit = 5;
      if (limitParam) {
        const parsedLimit = Number(limitParam);
        if (!Number.isInteger(parsedLimit) || parsedLimit <= 0) {
          return res.status(400).json({ error: 'limit must be a positive integer' });
        }
        if (parsedLimit > 100) {
          return res.status(400).json({ error: 'limit cannot exceed 100' });
        }
        limit = parsedLimit;
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
