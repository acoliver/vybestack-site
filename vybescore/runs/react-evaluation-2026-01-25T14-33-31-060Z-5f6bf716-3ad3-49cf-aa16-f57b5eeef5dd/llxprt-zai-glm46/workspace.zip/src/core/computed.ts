/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // The subject that observers will subscribe to
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value!,
    equalFn: undefined,
  }
  
  updateObserver(o)
  subject.value = o.value!
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      if (!subject.observers.has(observer)) {
        subject.observers.add(observer)
      }
      if (observer.dependencies !== undefined) {
        observer.dependencies.add(subject as never)
      }
    }
    return subject.value
  }

  // Wrap updateObserver to notify our observers when we update
  const originalUpdateFn = o.updateFn
  o.updateFn = (prev) => {
    const result = originalUpdateFn(prev)
    // Update subject value first
    subject.value = result
    // Then notify all observers of this computed value
    for (const obs of subject.observers) {
      if (obs.dependencies !== undefined && obs.dependencies.has(subject as never)) {
        updateObserver(obs as never)
      }
    }
    return result
  }
  
  return getter
}
