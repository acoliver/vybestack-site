export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '').split('').map(Number);
  let sum = 0;
  let isSecond = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isSecond) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isSecond = !isSecond;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate email addresses with comprehensive checks
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex - reject double dots, trailing dots, domains with underscores, etc.
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject if contains double dots or consecutive dots in local or domain part
  if (/\.\./.test(value)) return false;
  
  // Reject if starts with dot or ends with dot in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject if domain contains underscore
  if (/@.*_/.test(value)) return false;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers with common formats and optional +1 prefix
 */
export function isValidUSPhone(value: string): boolean {
  // Check if matches a valid US phone format first
  const phoneRegex = /^(?:\+?1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  if (!phoneRegex.test(value)) return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if has country code (11 digits) or just US number (10 digits)
  if (digitsOnly.length === 11) {
    // Must start with country code 1
    if (!digitsOnly.startsWith('1')) return false;
    
    // Extract area code (digits 2-4)
    const areaCode = digitsOnly.substring(1, 4);
    
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
    
  } else if (digitsOnly.length === 10) {
    // Extract area code (first 3 digits)
    const areaCode = digitsOnly.substring(0, 3);
    
    // Area code cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  } else {
    // Invalid length
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers for landlines and mobiles
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // If no country code, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) return false;
  
  // If has country code, should not have trunk prefix immediately after
  if (cleaned.startsWith('+54') && cleaned.substring(3).startsWith('0')) return false;
  
  // Extract components
  const hasCountryCode = cleaned.startsWith('+54');
  const remaining = hasCountryCode ? cleaned.substring(3) : cleaned;
  
  const hasMobilePrefix = remaining.startsWith('9');
  const areaCodeSection = hasMobilePrefix ? remaining.substring(1) : remaining;
  
  // When no country code, the area code section starts with 0 (trunk prefix)
  // Remove that 0 for area code extraction
  const areaCodeCandidate = !hasCountryCode && areaCodeSection.startsWith('0') 
    ? areaCodeSection.substring(1) 
    : areaCodeSection;
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCode = '';
  let subscriberNumber = '';
  
  // Area code is 2-4 digits
  for (let len = 2; len <= 4; len++) {
    const potentialAreaCode = areaCodeCandidate.substring(0, len);
    const potentialSubscriber = areaCodeCandidate.substring(len);
    
    // Area code must start with 1-9 and subscriber number must be 6-8 digits
    if (/^[1-9]\d{0,2}$/.test(potentialAreaCode) && 
        potentialSubscriber.length >= 6 && 
        potentialSubscriber.length <= 8) {
      areaCode = potentialAreaCode;
      subscriberNumber = potentialSubscriber;
      break;
    }
  }
  
  // If we couldn't find valid area code/subscriber split, reject
  if (!areaCode || !subscriberNumber) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, spaces
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and unconventional characters
  const nameRegex = /^[\p{L}\p{M}''\-\s]+$/u;
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) return false;
  
  // Reject names with consecutive punctuation
  if (/['\-\s]{2,}/.test(value)) return false;
  
  // Reject names starting or ending with punctuation
  if (/^[‘’\-\s]|[‘’\-\s]$/.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length based on card type
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  if (!/^(4\d{12}(?:\d{3})?|5[1-5]\d{14}|3[47]\d{13}|2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/.test(digits)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(value);
}
