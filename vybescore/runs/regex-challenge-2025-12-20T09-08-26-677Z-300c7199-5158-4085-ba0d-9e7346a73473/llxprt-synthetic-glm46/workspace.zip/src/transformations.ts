/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize spacing around sentence endings
  const normalized = text
    // Ensure space after sentence-enders if there isn't one
    .replace(/([.!?])(?=\S)/g, '$1 ')
    // Collapse multiple spaces to single spaces
    .replace(/\s+/g, ' ')
    // Trim leading/trailing spaces
    .trim();
  
  // Capitalize first character of each sentence
  return normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, char) => {
    return prefix + char.toUpperCase();
  });
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern
  const urlRegex = /https?:\/\/([^\s<>"]+|[^\s<>"]*\.[^\s<>"]+)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like .,!?) from each match
  return matches.map(url => url.replace(/[.,!?)\]]+$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  return text.replace(/https?:\/\/example\.com([^\s]*)/g, (match, path) => {
    // Always upgrade to https
    let newUrl = 'https://example.com' + path;
    
    // Check if we should move to docs subdomain
    // Skip if path contains dynamic indicators or legacy extensions
    const dynamicIndicators = /[?=&]|\/cgi-bin\/|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$/;
    
    if (path.startsWith('/docs/') && !dynamicIndicators.test(path)) {
      // Rewrite to docs.example.com
      newUrl = 'https://docs.example.com' + path;
    } else {
      // Just upgrade scheme
      newUrl = 'https://example.com' + path;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const [, month, day, year] = dateMatch;
  
  // Basic validation for month/day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Days per month (simplified - not leap year aware)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (monthNum === 2) {
    // February - check for leap year
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (dayNum > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}
