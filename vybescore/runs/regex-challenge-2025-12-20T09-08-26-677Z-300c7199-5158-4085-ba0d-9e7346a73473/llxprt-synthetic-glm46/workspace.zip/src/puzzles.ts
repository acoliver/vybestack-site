/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex chars in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[\\w-]*`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => 
    !exceptions.some(exception => 
      match.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex chars in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookahead/lookbehind to find token after digit but not at start
  // Include the digit in the match by using a wider group
  const pattern = new RegExp(`\\d${escapedToken}(?=\\b|$)`, 'g');
  
  return [...text.matchAll(pattern)].map(match => match[0]);
}

/**
 * Validate passwords according to the policy.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Must contain at least one symbol 
  if (!/[!@#$%^&*()_\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // This is a simplified check - catching the most common patterns
  if (/(.{1,3})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex patterns (simplified but covers most common forms)
  // Full IPv6: 8 groups of 1-4 hex digits
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // :: shorthand
  const shorthandStart = /::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  const shorthandEnd = /(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4})?/;
  const shorthandMiddle = /(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{0,4}/;
  
  // IPv4-mapped IPv6
  const ipv4Mapped = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Test for any IPv6 pattern
  if (fullIPv6.test(value) || 
      shorthandStart.test(value) || 
      shorthandEnd.test(value) || 
      shorthandMiddle.test(value) || 
      ipv4Mapped.test(value)) {
    
    // Make sure it's not just IPv4 (IPv4 pattern should not match IPv6)
    const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
    const matches = value.match(fullIPv6) || 
                  value.match(shorthandStart) || 
                  value.match(shorthandEnd) || 
                  value.match(shorthandMiddle) || 
                  value.match(ipv4Mapped);
    
    if (matches) {
      return matches.some(match => !ipv4Pattern.test(match));
    }
  }
  
  return false;
}