#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { parseArguments } from './args.js';
import { loadReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function main(): void {
  try {
    const args = parseArguments(process.argv);
    const data = loadReportData(args.dataFile);

    const output = args.format === 'markdown'
      ? renderMarkdown(data, { includeTotals: args.includeTotals })
      : renderText(data, { includeTotals: args.includeTotals });

    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();
