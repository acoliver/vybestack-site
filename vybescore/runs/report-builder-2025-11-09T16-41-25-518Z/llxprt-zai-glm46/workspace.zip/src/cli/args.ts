import type { CliArgs, Format } from '../types.js';

export function parseArguments(args: string[]): CliArgs {
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[2];
  
  if (!dataFile) {
    throw new Error('Missing data file argument');
  }

  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    throw new Error('Missing --format argument');
  }

  const formatValue = args[formatIndex + 1];
  const supportedFormats: Format[] = ['markdown', 'text'];
  
  if (!supportedFormats.includes(formatValue as Format)) {
    throw new Error(`Unsupported format: ${formatValue}. Supported formats: ${supportedFormats.join(', ')}`);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;

  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    format: formatValue as Format,
    outputPath,
    includeTotals,
  };
}