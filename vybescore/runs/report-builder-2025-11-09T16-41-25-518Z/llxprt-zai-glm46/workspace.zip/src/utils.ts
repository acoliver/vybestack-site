import { readFileSync } from 'node:fs';
import type { ReportData, ReportEntry } from './types.js';

export function parseReportData(jsonContent: string): ReportData {
  try {
    const data = JSON.parse(jsonContent) as unknown;
    
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected an object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (!obj.title || typeof obj.title !== 'string') {
      throw new Error('Missing or invalid "title" field (expected string)');
    }
    
    if (!obj.summary || typeof obj.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field (expected string)');
    }
    
    if (!obj.entries || !Array.isArray(obj.entries)) {
      throw new Error('Missing or invalid "entries" field (expected array)');
    }
    
    const entries: ReportEntry[] = [];
    for (const [index, entry] of obj.entries.entries()) {
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid entry at index ${index}: expected object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (!entryObj.label || typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid "label" field (expected string)`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid "amount" field (expected number)`);
      }
      
      entries.push({
        label: entryObj.label,
        amount: entryObj.amount,
      });
    }
    
    return {
      title: obj.title,
      summary: obj.summary,
      entries,
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }
}

export function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    return parseReportData(content);
  } catch (error) {
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}