/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Split text into sentences (keeping delimiters)
  const sentences = text.split(/([.?!]+)/);
  
  // Process sentences to capitalize first letter and fix spacing
  let result = '';
  let inSentence = false;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    // If part is punctuation, add it and set flag for next sentence
    if (/^[.?!]+$/.test(part)) {
      result += part;
      inSentence = true;
      continue;
    }
    
    // If part is whitespace between sentences, replace with single space
    if (/^\s+$/.test(part) && inSentence) {
      result += ' ';
      inSentence = false;
      continue;
    }
    
    // Capitalize first letter of sentences
    if (inSentence) {
      result += part.replace(/^\s*([a-z])/, (match, firstChar) => {
        inSentence = false;
        return firstChar.toUpperCase();
      });
    } else {
      result += part;
    }
  }
  
  // If we started with whitespace, preserve it
  if (/^\s/.test(text)) {
    result = ' ' + result.trimStart();
  }
  
  return result.trimEnd();
}

/**
 * Finds URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // Regex to match URLs with http/https schemes
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:\:[0-9]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:\#(?:[\w.])*)?)?/gi;
  
  // Find all matching URLs
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.?!,:]$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Replace all http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Replace URLs that start with http:// and have /docs/ path
  return text.replace(/http:\/\/([^\/\s]+)\/docs(\/[^\s.?!,:]*)/gi, (match, host, path) => {
    // Check if path contains dynamic hints like cgi-bin, query strings or legacy extensions
    if (path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)/) || path.includes('?') || path.includes('cgi-bin')) {
      // Just upgrade scheme, keep original host
      return `https://${host}/docs${path}`;
    }
    
    // Rewrite to docs subdomain
    return `https://docs.${host}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}