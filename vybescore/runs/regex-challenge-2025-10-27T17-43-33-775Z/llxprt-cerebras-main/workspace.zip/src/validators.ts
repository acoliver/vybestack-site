export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Email regex that rejects double dots, trailing dots in local part or domain
  // and domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check if it matches basic email structure
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Split into local part and domain
  const [localPart, domain] = value.split('@');
  
  // Reject if local part has double dots or ends with dot
  if (localPart.includes('..') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject if domain has underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digits
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 prefix
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check if we have exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check that area code doesn't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digits
  const cleaned = value.replace(/\D/g, '');
  
  // Patterns to match:
  // +54 9 11 1234 5678 -> 5491112345678 (13 digits)
  // 011 1234 5678 -> 01112345678 (11 digits)
  // +54 341 123 4567 -> 543411234567 (12 digits)
  // 0341 4234567 -> 03414234567 (11 digits)
  
  // Check if it's a valid Argentine phone number
  // Either starts with 54 (country code) or 0 (trunk prefix)
  if (cleaned.startsWith('54')) {
    // Has country code, check pattern: 54 + optional 9 + area code (2-4 digits) + subscriber (6-8 digits)
    const withoutCountryCode = cleaned.substring(2);
    
    // Check if it has mobile indicator 9
    let areaCodeStartIndex = 0;
    if (withoutCountryCode.startsWith('9')) {
      areaCodeStartIndex = 1;
    }
    
    // Extract area code (2-4 digits starting with 1-9)
    const areaCodeLength = Math.min(4, withoutCountryCode.length - areaCodeStartIndex);
    let areaCode = '';
    for (let i = areaCodeStartIndex; i < areaCodeStartIndex + areaCodeLength; i++) {
      if (i >= withoutCountryCode.length) break;
      areaCode += withoutCountryCode[i];
      // Check if we've reached an area code of valid length
      if (areaCode.length >= 2 && areaCode[0] !== '0') {
        const subscriberNumber = withoutCountryCode.substring(areaCodeStartIndex + areaCode.length);
        if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
          return true;
        }
      }
    }
    
    return false;
  } else if (cleaned.startsWith('0')) {
    // Has trunk prefix, check pattern: 0 + area code (2-4 digits) + subscriber (6-8 digits)
    const withoutTrunk = cleaned.substring(1);
    
    // Extract area code (2-4 digits starting with 1-9)
    const areaCodeLength = Math.min(4, withoutTrunk.length);
    let areaCode = '';
    for (let i = 0; i < areaCodeLength; i++) {
      if (i >= withoutTrunk.length) break;
      areaCode += withoutTrunk[i];
      // Check if we've reached an area code of valid length
      if (areaCode.length >= 2 && areaCode[0] !== '0') {
        const subscriberNumber = withoutTrunk.substring(areaCode.length);
        if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
          return true;
        }
      }
    }
    
    return false;
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check if it contains digits or symbols (excluding accents, apostrophes, hyphens, and spaces)
  const nameRegex = /^[\\p{L}\\p{M}'\\-\\s]+$/u;
  
  // Check if name has proper structure (not X Æ A-12 style)
  const invalidPattern = /[A-Z]\s*?[Ææ]\s*?[A-Z]\s*?\d+/;
  
  return nameRegex.test(value) && !invalidPattern.test(value);
}

/**
 * Helper function to run Luhn algorithm check
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    return runLuhnCheck(cleaned);
  }
  
  // Mastercard: starts with 5[1-5] or 222[1-9]|22[3-9]|2[3-6]|27[0-1]|2720, length 16
  if ((/^5[1-5]/.test(cleaned) || /^2(?:22[1-9]|2[3-9]|[3-6]|7[0-1]|720)/.test(cleaned)) && cleaned.length === 16) {
    return runLuhnCheck(cleaned);
  }
  
  // American Express: starts with 34 or 37, length 15
  if ((/^34/.test(cleaned) || /^37/.test(cleaned)) && cleaned.length === 15) {
    return runLuhnCheck(cleaned);
  }
  
  return false;
}