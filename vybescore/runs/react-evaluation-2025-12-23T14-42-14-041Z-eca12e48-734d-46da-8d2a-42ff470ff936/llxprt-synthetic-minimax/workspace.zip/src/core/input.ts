/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Source,
  getActiveObserver,
  addDependency,
  notifySource,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const source: Source<T> = {
    value,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addDependency(source, observer)
    }
    return source.value
  }

  const write: SetterFn<T> = (nextValue) => {
    source.value = nextValue
    notifySource(source)
    return source.value
  }

  return [read, write]
}
