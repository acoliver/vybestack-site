/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      // Always execute the callback with the current value to track dependencies
      updateFn(currentValue)
      // Callbacks don't store return values, but we need to return something
      // for the UpdateFn signature. Return the original value.
      return currentValue ?? value as T
    },
  }

  // Set this observer as active to capture dependencies from any reactive reads
  const originalActive = getActiveObserver()
  setActiveObserver(observer as Observer<unknown>)
  
  try {
    // Execute once to establish dependencies
    updateObserver(observer as Observer<unknown>)
  } finally {
    // Restore the original active observer
    setActiveObserver(originalActive)
  }

  let disposed = false

  return () => {
    if (disposed) return
    disposed = true
    
    // Mark as disposed
    observer.disposed = true
  }
}
