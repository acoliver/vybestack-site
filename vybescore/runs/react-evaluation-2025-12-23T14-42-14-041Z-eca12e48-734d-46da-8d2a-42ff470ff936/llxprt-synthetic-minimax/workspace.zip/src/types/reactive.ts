/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface BaseObserver {
  name?: string
  disposed?: boolean
}

export interface Observer<T> extends BaseObserver {
  value?: T
  updateFn: UpdateFn<T>
}

export interface Source<T> {
  value: T
  observers: Set<Observer<unknown>> // Set of observers that depend on this source
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.disposed) return
  
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addDependency<T>(source: Source<T>, observer: Observer<unknown>): void {
  source.observers.add(observer)
}

export function notifySource<T>(source: Source<T>): void {
  const observers = Array.from(source.observers)
  for (const observer of observers) {
    if (!observer.disposed) {
      updateObserver(observer)
    } else {
      source.observers.delete(observer)
    }
  }
}
