import { ReportData, FormatOptions, Formatter } from '../types/report.js';

/**
 * Formats report data as plain text
 */
export const renderText: Formatter = (data: ReportData, options: FormatOptions): string => {
  let output = `${data.title}

`;
  output += `${data.summary}

`;
  output += `Entries:
`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}
`;
  }
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `

Total: $${total.toFixed(2)}`;
  }
  
  return output;
};