#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArgs(args: string[]): CLIOptions & { dataFile: string } {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const options: CLIOptions = {
    format: 'markdown',
    includeTotals: false
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[++i];
      if (format !== 'markdown' && format !== 'text') {
        console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
        process.exit(1);
      }
      options.format = format;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  return { dataFile, ...options };
}

/**
 * Read and parse JSON data file
 */
function readReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid required field: title');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid required field: summary');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries (must be an array)');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'label' field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: missing or invalid 'amount' field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File not found '${filePath}'`);
      } else if (error.message.includes('JSON.parse')) {
        console.error(`Error: Invalid JSON in '${filePath}'`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read data file');
    }
    process.exit(1);
  }
}

/**
 * Main entry point
 */
function main(): void {
  const args = process.argv.slice(2);
  const { dataFile, format, output, includeTotals } = parseArgs(args);
  
  const reportData = readReportData(dataFile);
  
  let outputText: string;
  if (format === 'markdown') {
    outputText = renderMarkdown(reportData, { includeTotals });
  } else if (format === 'text') {
    outputText = renderText(reportData, { includeTotals });
  } else {
    console.error(`Unsupported format`);
    process.exit(1);
  }
  
  if (output) {
    try {
      writeFileSync(output, outputText);
    } catch (error) {
      console.error(`Error: Failed to write output file '${output}'`);
      process.exit(1);
    }
  } else {
    console.log(outputText);
  }
}

main();