import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;
let SQL: SqlJsStatic | null = null;

async function initDatabase(): Promise<void> {
  SQL = await initSqlJs();

  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    const dbBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (!db) throw new Error('Database not initialized');
  
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push('First name is required');
  }

  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.push('City is required');
  }

  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens');
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.push('Country is required');
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

function normalizeFormData(body: unknown): Partial<FormData> {
  const data = body as Record<string, string>;
  return {
    firstName: data.firstName?.trim() || '',
    lastName: data.lastName?.trim() || '',
    streetAddress: data.streetAddress?.trim() || '',
    city: data.city?.trim() || '',
    stateProvince: data.stateProvince?.trim() || '',
    postalCode: data.postalCode?.trim() || '',
    country: data.country?.trim() || '',
    email: data.email?.trim() || '',
    phone: data.phone?.trim() || '',
  };
}

function insertSubmission(data: FormData): void {
  if (!db) throw new Error('Database not initialized');

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone,
  ]);

  stmt.free();
  saveDatabase();
}

async function createServer() {
  const app = express();

  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, '..', 'src', 'templates'));

  app.use('/public', express.static(path.join(__dirname, '..', 'public')));

  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {},
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData = normalizeFormData(req.body);
    const validation = validateForm(formData);

    if (!validation.valid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        values: formData,
      });
    }

    insertSubmission(formData as FormData);

    res.redirect(302, '/thank-you');
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', {
      firstName: 'Friend',
    });
  });

  app.use((err: Error, _req: Request, res: Response) => {
    console.error('Server error:', err);
    res.status(500).send('Internal server error');
  });

  return app;
}

export async function getApp() {
  await initDatabase();
  return createServer();
}

export async function startServer(port: number = 3535) {
  await initDatabase();
  
  const app = await createServer();
  
  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  return server;
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  let server: Awaited<ReturnType<typeof startServer>> | null = null;

  const shutdown = async () => {
    console.log('Shutting down gracefully...');
    if (server) {
      server.close(() => {
        closeDatabase();
        process.exit(0);
      });
    } else {
      closeDatabase();
      process.exit(0);
    }
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);

  startServer(port).then((srv) => {
    server = srv;
  }).catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
