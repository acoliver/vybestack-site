import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { getApp, closeDatabase } from '../../src/server.js';

let app: Awaited<ReturnType<typeof getApp>>;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  app = await getApp();
});

afterAll(() => {
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');

    const $ = cheerio.load(response.text || '');
    expect($('input[name="firstName"]').length).toBeGreaterThan(0);
    expect($('input[name="lastName"]').length).toBeGreaterThan(0);
    expect($('input[name="email"]').length).toBeGreaterThan(0);
    expect($('input[name="phone"]').length).toBeGreaterThan(0);
    expect($('label[for="firstName"]').length).toBeGreaterThan(0);
  });

  it('persists submission and redirects', async () => {
    // Remove database if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(formData);
    
    // Should redirect
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Check database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'not-an-email',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBeGreaterThan(0);
    expect($('.error-list').text()).toContain('required');
  });

  it('validates email format', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'invalid-email',
      phone: '+1 555-123-4567',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('valid email');
  });

  it('validates phone format', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'test@example.com',
      phone: 'invalid-phone!@#',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('Phone number');
  });

  it('validates postal code format', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'Invalid@#$',
      country: 'Test Country',
      email: 'test@example.com',
      phone: '+1 555-123-4567',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('Postal');
  });

  it('shows thank you page after submission', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    const $ = cheerio.load(response.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('a[href="/"]').length).toBeGreaterThan(0);
  });

  it('accepts international phone numbers', async () => {
    const testCases = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '+33 1 42 86 83 42',
    ];

    for (const phone of testCases) {
      const response = await request(app).post('/submit').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone,
      });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });

  it('accepts international postal codes', async () => {
    const testCases = [
      'SW1A 1AA',
      'C1000',
      'B1675',
      '12345',
      '10001',
    ];

    for (const postalCode of testCases) {
      const response = await request(app).post('/submit').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode,
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555-123-4567',
      });

      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    }
  });
});
