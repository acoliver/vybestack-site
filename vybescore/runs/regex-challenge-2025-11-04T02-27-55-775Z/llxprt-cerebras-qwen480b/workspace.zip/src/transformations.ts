/**
 * Capitalizes the first character of each sentence while preserving spacing rules.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Split text by sentence-ending punctuation followed by whitespace or end of string
  const sentences = text.split(/(?<=[.?!])\s*/);
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Trim leading/trailing whitespace and capitalize first letter
    return sentence.trim().replace(/^\w/, char => char.toUpperCase());
  });
  
  // Join sentences with exactly one space
  return processedSentences.filter(s => s.length > 0).join(' ');
}

/**
 * Extracts all URLs from the text and returns them as an array.
 * URLs are returned without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // Regex to match URLs (http/https) and capture them
  // This pattern is relatively simple but should capture most URLs
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*[^\s.,;:!?)\]}]/gi;
  
  // Match all URLs
  const matches = text.match(urlRegex);
  
  // Return array of matches or empty array if none found
  return matches ? matches : [];
}

/**
 * Replaces all http:// URLs with https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Replace http:// with https://, but don't affect https:// URLs
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://...
 * When path begins with /docs/, rewrites host to docs.example.com
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Regex to match URLs that might need rewriting
  // This pattern identifies http URLs and captures:
  // - The protocol (http://)
  // - The host
  // - The path and any query parameters
  return text.replace(/http:\/\/([\w.-]+)(\/[^\s]*)?/gi, (match, host, path = '/') => {
    // Check if path contains dynamic elements that should prevent host rewrite
    const hasDynamicElements = 
      path.includes('cgi-bin') || 
      path.includes('?') || 
      path.includes('&') || 
      path.includes('=') ||
      path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)/i);
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    // Convert to https
    let newUrl = `https://${host}${path}`;
    
    // Rewrite host to docs.example.com if it's a docs path and doesn't contain dynamic elements
    if (isDocsPath && !hasDynamicElements) {
      newUrl = `https://docs.${host}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy date strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Date format regex: mm/dd/yyyy
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day ranges
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}
