export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check for obviously invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.startsWith('.')) {
    return false;
  }

  // Check for underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }

  // Email regex pattern - allows alphanumeric, dots, hyphens, plus signs in local part
  // Allows alphanumeric, dots, hyphens in domain part with proper TLD
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters for length and area code checking
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid length (10 digits or 11 digits with +1 prefix)
  if (digitsOnly.length !== 10 && !(digitsOnly.length === 11 && digitsOnly.startsWith('1'))) {
    return false;
  }
  
  // Extract area code (3 digits after optional country code)
  const areaCodeStartIndex = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(areaCodeStartIndex, areaCodeStartIndex + 3);
  
  // Check if area code is valid (doesn't start with 0 or 1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check format with regex - should match one of the accepted patterns
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s\-]?\d{3}[\s\-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Supports optional country code, trunk prefix, mobile indicator, and separator variations.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Clean the value: remove all spaces and hyphens but keep other characters for validation
  const cleaned = value.replace(/[\s\-]/g, '');
  
  // Define regex for Argentine phone number
  // Explanation:
  // ^(\+54|0)? - Optional country code (+54) or trunk prefix (0)
  // (9)? - Optional mobile indicator
  // ([1-9]\d{1,3}) - Area code (2-4 digits, first digit 1-9)
  // \d{6,8}$ - Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54|0)?(9)?([1-9]\d{1,3})\d{6,8}$/;
  
  // Check if the pattern matches
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract components for further validation
  let phoneNumber = cleaned;
  
  // Handle country code
  if (phoneNumber.startsWith('+54')) {
    phoneNumber = phoneNumber.substring(3);
  } else if (phoneNumber.startsWith('0')) {
    // Must start with trunk prefix when country code is omitted
    phoneNumber = phoneNumber.substring(1);
  } else {
    // If no country code/trunk prefix, it's invalid
    return false;
  }
  
  // Handle mobile indicator
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Extract area code and subscriber number
  // Area code is 2-4 digits, subscriber number is 6-8 digits
  const areaCodeMatch = phoneNumber.match(/^([1-9]\d{1,3})(\d{6,8})$/);
  
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = areaCodeMatch[2];
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Regex pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Spaces, hyphens, and apostrophes
  // - Not allowing digits or other symbols
  const nameRegex = /^[\p{L}\s\-']+$/u;

  // Check if the name matches the pattern
  if (!nameRegex.test(value)) {
    return false;
  }

  // Additional check to reject names like "X Æ A-12"
  // which contain digits or unusual formatting
  const invalidNameRegex = /\d/;
  if (invalidNameRegex.test(value)) {
    return false;
  }

  // Ensure the name is not empty after trimming whitespace
  return value.trim().length > 0;
}

/**
 * Validates credit card numbers using regex for format and Luhn algorithm for checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */

// Helper function to run Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s\-]/g, '');
  
  // Visa: starts with 4, 13 or 16 digits
  // Mastercard: starts with 5, 16 digits
  // AmEx: starts with 34 or 37, 15 digits
  const creditCardRegex = /^(?:4[0-9]{12}(?:[0-9]{3})?|5[1-5][0-9]{14}|3[47][0-9]{13})$/;
  
  // Check if format matches and run Luhn check
  return creditCardRegex.test(cleaned) && runLuhnCheck(cleaned);
}
