export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex.
 * Accepts typical formats like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Basic email format validation
  const emailRegex = /^(?!\.)[^@\s]+@(?!.*\.\.)[A-Za-z0-9-]+(\.[A-Za-z0-9-]+)+$/;
  
  // Reject domains with underscores
  if (/.+_/.test(value)) return false;
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting various formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid lengths
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false;
  }
  
  // Extract area code (skip country code if present)
  const areaCode = digitsOnly.length === 11 
    ? digitsOnly.substring(1, 4)
    : digitsOnly.substring(0, 3);
    
  // Area code validation (can't start with 0 or 1)
  return /^[2-9]\d{2}$/.test(areaCode);
}

/**
 * Validates Argentine phone numbers for both mobile and landlines.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern validation
  const phoneRegex = /^(\+54)?(9)?(0)?[1-9]\d{1,3}\d{6,8}$/;
  if (!phoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract components for validation
  const countryCodeMatch = cleaned.match(/^(\+54)?/);
  const hasCountryCode = countryCodeMatch && countryCodeMatch[0];
  
  const mobileIndicatorMatch = cleaned.slice(hasCountryCode?.length || 0).match(/^(9)?/);
  const hasMobileIndicator = mobileIndicatorMatch && mobileIndicatorMatch[1];
  
  const trunkPrefixMatch = cleaned.slice(hasCountryCode?.length || 0).slice(hasMobileIndicator?.length || 0).match(/^(0)?/);
  const hasTrunkPrefix = trunkPrefixMatch && trunkPrefixMatch[1];
  
  // If country code is omitted, trunk prefix is required
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Area code validation (2-4 digits, not starting with 0)
  const remainingAfterOptional = cleaned.slice(hasCountryCode?.length || 0).slice(hasMobileIndicator?.length || 0).slice(hasTrunkPrefix?.length || 0);
  const areaCodeMatch = remainingAfterOptional.match(/^(\d{2,4})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number validation (6-8 digits)
  const subscriberNumber = remainingAfterOptional.slice(areaCode.length);
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits and symbols, only allows letters, spaces, hyphens, apostrophes.
 */
export function isValidName(value: string): boolean {
  // Check for valid characters only
  if (!/^[\p{L}\p{M}'’\-\s]+$/u.test(value)) return false;
  
  // Not empty after trimming
  return value.trim().length > 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Input must be a string
  if (typeof value !== 'string') return false;
  
  // Remove non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check basic length and prefix
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d{12}|20\d{10})))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(digitsOnly) && !mastercardRegex.test(digitsOnly) && !amexRegex.test(digitsOnly)) {
    return false;
  }
  
  // Luhn algorithm
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digitsOnly.length - 1; i >= 0; i--) {
    let digit = parseInt(digitsOnly[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
