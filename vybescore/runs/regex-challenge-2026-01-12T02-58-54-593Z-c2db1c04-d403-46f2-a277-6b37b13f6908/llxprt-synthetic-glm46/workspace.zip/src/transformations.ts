/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Add space after sentence terminators if missing
  const spacedText = text.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Split by sentence terminators and whitespace
  const sentences = spacedText.split(/([.?!]\s*)/);
  
  // Process sentences - capitalize first character of each sentence
  let result = '';
  let sentenceStart = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const portion = sentences[i];
    
    // If this is a sentence terminator followed by space
    if (/^[.?!]\s*$/.test(portion)) {
      result += portion;
      sentenceStart = true;
      continue;
    }
    
    // If this is a sentence terminator without space
    if (portion === '.' || portion === '?' || portion === '!') {
      result += portion + ' ';
      sentenceStart = true;
      continue;
    }
    
    // Empty string portion
    if (!portion) continue;
    
    // Handle capitalization and collapse spaces
    if (sentenceStart) {
      result += portion.charAt(0).toUpperCase() + portion.slice(1);
      sentenceStart = false;
    } else {
      result += portion;
    }
  }
  
  // Collapse multiple spaces to single spaces
  result = result.replace(/\s+/g, ' ');
  
  // Trim leading/trailing whitespace
  return result.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with http/https protocols
  const urlRegex = /https?:\/\/[^\s<>"']+|[^\s<>"']+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Filter matches to ensure they contain at least one dot and are plausible URLs
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?]+$/g, '');
  }).filter(url => {
    // Basic pattern check - has characters before dot and after dot
    return /^[a-zA-Z0-9._-]+\.[a-zA-Z]{2,}/.test(url) || url.startsWith('http');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then process docs.example.com URLs
  // Pattern: https://example.com/docs/... -> https://docs.example.com/...
  // But skip URLs with cgi-bin, query strings, or certain extensions
  result = result.replace(
    /https:\/\/example\.com(\/docs\/(?!.*(?:\?.*=|&.*=|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)[^/]*).*)/g,
    'https://docs.example.com$1'
  );
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/);
  
  if (dateMatch) {
    return dateMatch[3]; // Return the captured year
  }
  
  return 'N/A';
}
