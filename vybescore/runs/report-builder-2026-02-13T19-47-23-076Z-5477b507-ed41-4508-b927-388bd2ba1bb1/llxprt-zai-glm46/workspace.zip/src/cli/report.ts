#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { ReportData } from '../types.js';
import { getFormatRenderer } from '../formats/index.js';

/**
 * Parse CLI arguments using Node's standard library.
 * Returns an object with parsed options.
 */
function parseArgs(args: string[]): {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  let inputFile = '';
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!inputFile) {
      // First non-option argument is input file
      inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!inputFile) {
    throw new Error('Input file is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Validate and parse JSON input file.
 */
function loadAndValidateInput(filePath: string): ReportData {
  // Resolve path to be absolute
  const absolutePath = path.resolve(filePath);

  // Check file exists
  if (!fs.existsSync(absolutePath)) {
    throw new Error(`File not found: ${filePath}`);
  }

  // Read file
  const content = fs.readFileSync(absolutePath, 'utf-8');

  // Parse JSON
  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error(`Invalid JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
  }

  // Validate structure
  if (!data || typeof data !== 'object') {
    throw new Error('JSON must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Entry at index ${i} is missing or has invalid "label" (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Entry at index ${i} is missing or has invalid "amount" (must be a number)`);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI entry point.
 */
function main(): void {
  try {
    // Parse command line arguments (skip first two: node and script path)
    const args = process.argv.slice(2);
    const { inputFile, format, outputPath, includeTotals } = parseArgs(args);

    // Load and validate input
    const data = loadAndValidateInput(inputFile);

    // Get format renderer
    const renderer = getFormatRenderer(format);

    // Render report
    const output = renderer(data, { includeTotals });

    // Write output
    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

// Run CLI
main();
