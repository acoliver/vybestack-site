/**
 * Shared TypeScript interfaces for the report builder CLI.
 */

/**
 * Represents a single entry in the report.
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Represents the complete report data structure from JSON input.
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering the report.
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Format renderer function signature.
 */
export type FormatRenderer = (data: ReportData, options: RenderOptions) => string;
