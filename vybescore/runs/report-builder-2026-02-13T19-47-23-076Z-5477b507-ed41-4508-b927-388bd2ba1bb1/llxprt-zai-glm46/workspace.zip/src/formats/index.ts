import type { FormatRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Registry of available format renderers.
 * Add new formats here by extending this map.
 */
export const formatRenderers: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Get a format renderer by name.
 * Throws an error if the format is not supported.
 */
export function getFormatRenderer(format: string): FormatRenderer {
  const renderer = formatRenderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}

/**
 * Check if a format is supported.
 */
export function isFormatSupported(format: string): boolean {
  return format in formatRenderers;
}

/**
 * Get list of all supported formats.
 */
export function getSupportedFormats(): string[] {
  return Object.keys(formatRenderers);
}
