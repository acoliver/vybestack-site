/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64.
 */
export function decode(input: string): string {
  // Basic validation: check for invalid characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for proper length after padding (add padding if needed)
  const paddedLength = Math.ceil(input.length / 4) * 4;
  const paddedInput = input.padEnd(paddedLength, '=');

  // Validate that after padding, length is multiple of 4
  if (paddedInput.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: length must be valid after padding');
  }

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
