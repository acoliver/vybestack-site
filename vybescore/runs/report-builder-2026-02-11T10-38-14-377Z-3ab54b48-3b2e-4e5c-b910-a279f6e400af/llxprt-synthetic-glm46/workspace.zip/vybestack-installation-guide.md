# VybeStack Installation and Configuration Guide

## Overview

VybeStack is a decentralized computing platform that allows users to create virtual clusters using edge devices. This guide provides step-by-step instructions for installation, configuration, and deployment.

## Prerequisites

- Git
- Node.js (v14 or higher)
- Docker and Docker Compose
- A Linux/macOS system (or WSL2 on Windows)

## Installation Steps

### 1. Clone the Repository

```bash
git clone https://github.com/vybestack/vybestack-site.git
cd vybestack-site
```

### 2. Install Site Dependencies

```bash
# Install frontend dependencies
npm install

# Install backend dependencies
cd backend
npm install
```

### 3. Environment Configuration

Create environment configuration files:

```bash
# Frontend environment
cp frontend/.env.example frontend/.env.local

# Backend environment
cp backend/.env.example backend/.env.local
```

Edit the environment files with your specific configuration:
- Database connection settings
- API keys and credentials
- Service endpoints

### 4. Database Setup

#### Option A: Using Docker Compose (Recommended)
```bash
cd backend
docker-compose up -d
```

#### Option B: Manual Setup
1. Install PostgreSQL
2. Create database and user as specified in your environment file
3. Run database migrations:
```bash
cd backend
npm run migrate
```

### 5. Build and Start Services

Start the development servers:

```bash
# Terminal 1 - Start frontend
cd frontend
npm run dev

# Terminal 2 - Start backend
cd ../backend
npm run dev
```

For production deployment:

```bash
# Build production assets
npm run build

# Start production server
npm run start
```

## Post-Installation Configuration

### Backend Configuration

1. **Database Configuration**
   - Ensure database connection works
   - Run seed data if needed:
   ```bash
   npm run seed
   ```

2. **API Keys Configuration**
   - Configure blockchain node endpoints
   - Set up authentication secrets
   - Configure external service API keys

3. **Service Discovery**
   - Register services with discovery mechanism
   - Configure service endpoints

### Frontend Configuration

1. **API Endpoints**
   - Set API base URL in environment
   - Configure authentication endpoints

2. **Feature Flags**
   - Enable/disable features as needed
   - Configure experimental features

## Docker Deployment

For containerized deployment:

```bash
# Build Docker images
docker-compose build

# Start the stack
docker-compose up -d
```

For production with Docker Compose:

```bash
# Use production configuration
docker-compose -f docker-compose.prod.yml up -d
```

## Platform-Specific Setup

### Linux

1. Install system dependencies:
```bash
sudo apt-get update
sudo apt-get install -y cmake build-essential git python3
```

2. Ensure Docker permissions:
```bash
sudo usermod -aG docker $USER
# Then log out and back in
```

### MacOS

1. Install Homebrew if not already installed
2. Install dependencies:
```bash
brew install git node docker
```

3. Start Docker Desktop

### Windows (WSL2)

1. Install WSL2: `wsl --install`
2. Install Ubuntu distribution
3. Install dependencies within WSL:
```bash
sudo apt-get update
sudo apt-get install -y git nodejs npm
```

## Verification

To verify your installation:

1. Check service status:
```bash
cd backend
npm run health-check
```

2. Test API endpoints:
```bash
curl http://localhost:3001/api/health
```

3. Access frontend:
Open http://localhost:3000 in your browser

## Troubleshooting

### Common Issues

1. **Port Conflicts**
   - Ensure ports 3000 (frontend) and 3001 (backend) are available
   - Modify configuration if needed

2. **Database Connection Issues**
   - Verify database is running
   - Check connection string in environment variables
   - Ensure database user has correct permissions

3. **Build Failures**
   - Clear node_modules and reinstall:
   ```bash
   rm -rf node_modules package-lock.json
   npm install
   ```

4. **Permission Issues**
   - Ensure Docker daemon permissions
   - Check file permissions in project directory

### Log Locations

- Frontend logs: Console output and browser dev tools
- Backend logs: Console output and /logs directory
- Docker logs: `docker-compose logs [service-name]`

## Advanced Configuration

### Custom Node Setup

For advanced users who want to run their own Vybe network nodes:

1. Install node-specific dependencies
2. Configure node settings in config files
3. Initialize blockchain data:
```bash
npm run node:init
```

### Performance Optimization

1. **Backend Scaling**
   - Configure connection pooling
   - Set up load balancer

2. **Frontend Optimization**
   - Enable code splitting
   - Configure service workers

3. **Database Optimization**
   - Index optimization
   - Query optimization

## Security Considerations

1. **Secret Management**
   - Never commit environment files with real secrets
   - Use secret management in production

2. **Network Security**
   - Configure firewall rules
   - Use HTTPS in production

3. **Container Security**
   - Regular security updates
   - Limit container privileges

## Getting Help

- Check the troubleshooting section for common issues
- Reference the documentation in the /docs directory
- File issues on the GitHub repository
- Join community discussions on Discord/Slack

## Next Steps

After successful installation:

1. Create your first virtual cluster
2. Explore the dashboard features
3. Configure mining settings
4. Set up monitoring and alerting
5. Join the VybeStack community