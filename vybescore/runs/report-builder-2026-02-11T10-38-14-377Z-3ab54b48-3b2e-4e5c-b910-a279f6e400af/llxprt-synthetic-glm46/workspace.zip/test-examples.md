# 基础功能测试

## 1. 基础HTML标签解析

输入：
```html
<h1>标题测试</h1>
<p>段落测试</p>
<ul>
  <li>列表项1</li>
  <li>列表项2</li>
</ul>
```

预期输出：
<h1>标题测试</h1>
<p>段落测试</p>
<ul>
  <li>列表项1</li>
  <li>列表项2</li>
</ul>

## 2. Markdown转义

输入：
```
# 标题
**粗体文本**
- 列表项
```

预期输出：
\# 标题
\*\*粗体文本\*\*
- 列表项

## 3. 图片处理

输入：
```html
<img src="https://example.com/image.jpg" alt="示例图片">
```
预期输出：
<!-- 图片: https://example.com/image.jpg -->示例图片

## 4. 链接处理

输入：
```html
<a href="https://example.com">链接文本</a>
```

预期输出：
链接文本 (https://example.com)

## 5. 混合内容

输入：
```html
<div>
  <h2>子标题</h2>
  <p>包含<a href="#">链接</a>的段落</p>
  <img src="image.png" alt="图片">
</div>
```

预期输出：
<div>
  <h2>子标题</h2>
  <p>包含链接的段落</p>
  <!-- 图片: image.png -->图片
</div>