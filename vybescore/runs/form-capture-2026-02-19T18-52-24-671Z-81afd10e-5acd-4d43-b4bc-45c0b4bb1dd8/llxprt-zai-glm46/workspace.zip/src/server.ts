import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, closeDatabase, insertSubmission, type Submission } from './database.js';
import { validateForm, sanitizeInput, type FormData } from './validation.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || '3535';

const app = express();
let server: ReturnType<typeof app.listen> | null = null;

// Middleware
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Routes
app.get('/', (_req: Request, res: Response): void => {
  res.render('index');
});

interface FormRequestBody {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

app.post('/submit', (req: Request<Record<string, never>, Record<string, never>, FormRequestBody>, res: Response): void => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    res.status(400).render('index', {
      errors: validation.errors,
      formData: formData,
    });
    return;
  }

  // Sanitize and insert into database
  const submission: Submission = {
    first_name: sanitizeInput(formData.firstName!),
    last_name: sanitizeInput(formData.lastName!),
    street_address: sanitizeInput(formData.streetAddress!),
    city: sanitizeInput(formData.city!),
    state_province: sanitizeInput(formData.stateProvince!),
    postal_code: sanitizeInput(formData.postalCode!),
    country: sanitizeInput(formData.country!),
    email: sanitizeInput(formData.email!),
    phone: sanitizeInput(formData.phone!),
  };

  initializeDatabase()
    .then(() => {
      insertSubmission(submission);
      res.redirect(302, '/thank-you');
    })
    .catch((err) => {
      console.error('Database error:', err);
      res.status(500).render('index', {
        errors: { general: 'Failed to save submission. Please try again.' },
        formData: formData,
      });
    });
});

app.get('/thank-you', (_req: Request, res: Response): void => {
  res.render('thank-you');
});

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');

    server = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');

  if (server) {
    server.close(() => {
      console.log('HTTP server closed');
    });
  }

  closeDatabase();
  console.log('Database closed');

  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start the server
startServer();
