export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Simple email regex - accepts common email formats
const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Phone regex: optional leading +, then digits, spaces, parentheses, dashes
const PHONE_REGEX = /^\+?[\d\s()-]+$/;

// Postal code regex: alphanumeric with optional spaces
const POSTAL_CODE_REGEX = /^[A-Za-z0-9\s-]+$/;

export function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required fields
  if (!data.firstName || data.firstName.trim() === '') {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city || data.city.trim() === '') {
    errors.city = 'City is required';
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.stateProvince = 'State / Province / Region is required';
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.postalCode = 'Postal / Zip code is required';
  } else if (!POSTAL_CODE_REGEX.test(data.postalCode.trim())) {
    errors.postalCode = 'Postal code must contain only letters, numbers, spaces, and dashes';
  }

  if (!data.country || data.country.trim() === '') {
    errors.country = 'Country is required';
  }

  if (!data.email || data.email.trim() === '') {
    errors.email = 'Email is required';
  } else if (!EMAIL_REGEX.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.phone = 'Phone number is required';
  } else if (!PHONE_REGEX.test(data.phone.trim())) {
    errors.phone = 'Phone number must contain only digits, spaces, parentheses, dashes, and optional leading +';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
  };
}

export function sanitizeInput(value: string): string {
  return value.trim();
}
