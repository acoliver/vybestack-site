import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

let dbInstance: Database | null = null;
let SQL: SqlJsStatic | null = null;

export async function initializeDatabase(): Promise<Database> {
  if (dbInstance) {
    return dbInstance;
  }

  SQL = await initSqlJs();

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    await loadSchema();
    saveDatabase();
  }

  return dbInstance;
}

async function loadSchema(): Promise<void> {
  if (!dbInstance || !SQL) {
    throw new Error('Database not initialized');
  }

  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  dbInstance.run(schema);
}

export function saveDatabase(): void {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const data = dbInstance.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export function insertSubmission(submission: Submission): number {
  if (!dbInstance) {
    throw new Error('Database not initialized');
  }

  const stmt = dbInstance.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.bind([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone,
  ]);

  stmt.step();
  stmt.free();

  // Get the last inserted row ID
  const result = dbInstance.exec('SELECT last_insert_rowid() as id');
  const lastId = result[0]?.values[0]?.[0] as number;
  
  saveDatabase();
  
  return lastId;
}

export function closeDatabase(): void {
  if (dbInstance) {
    dbInstance.close();
    dbInstance = null;
  }
}

export function getDatabase(): Database | null {
  return dbInstance;
}
