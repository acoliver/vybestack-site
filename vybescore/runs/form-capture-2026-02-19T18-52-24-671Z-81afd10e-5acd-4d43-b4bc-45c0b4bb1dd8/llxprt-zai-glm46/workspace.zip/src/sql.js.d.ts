declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface Statement {
    bind(values: unknown[]): void;
    step(): boolean;
    free(): void;
  }

  const SqlJs: SqlJsStatic;
  export default SqlJs;
}

export function initSqlJs(): Promise<import('sql.js').SqlJsStatic>;
