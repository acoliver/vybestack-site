/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerDependency,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    dependents: new Set(),
  }

  const read: GetterFn<T> = () => {
    // If there's an active observer, this input is being accessed in the context
    // of computing that observer, so we register it as a dependency
    const active = getActiveObserver()
    if (active) {
      registerDependency(subject, active)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    subject.value = nextValue
    
    // Always notify dependents, regardless of whether the value changed
    // The reactive system will handle memoization if needed
    notifyDependents(subject)
    
    return subject.value
  }

  return [read, write]
}
