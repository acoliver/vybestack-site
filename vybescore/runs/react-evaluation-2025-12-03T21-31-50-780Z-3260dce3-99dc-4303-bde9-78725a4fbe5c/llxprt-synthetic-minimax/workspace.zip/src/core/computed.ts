/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  notifyDependentsOfObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value: value,  // Use the provided initial value directly
    updateFn: (prev) => {
      // Clear previous dependencies before recomputing
      if (observer.subjects) {
        observer.subjects.clear()
      }
      
      // Store old value for comparison
      const oldValue = observer.value
      
      // Execute the update function to compute new value
      // This will trigger dependency tracking for any reactive values accessed
      const result = updateFn(prev)
      
      // Set the new value
      observer.value = result
      
      // Notify dependents if the value changed
      if (oldValue !== result) {
        notifyDependentsOfObserver(observer)
      }
      
      return result
    },
    dependents: new Set()
  }

  const getter: GetterFn<T> = () => {
    // When getting the value, we need to trigger recomputation
    // which will also handle dependency tracking
    updateObserver(observer)
    return observer.value!
  }

  // Initial computation - only if no initial value was provided
  if (value === undefined) {
    updateObserver(observer)
  }
  
  return getter
}