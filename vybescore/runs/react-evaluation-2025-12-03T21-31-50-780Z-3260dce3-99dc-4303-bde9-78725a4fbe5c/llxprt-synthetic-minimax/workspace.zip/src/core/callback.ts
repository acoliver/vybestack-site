/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: () => {
      // Execute the user's callback function - during this execution,
      // any reactive values accessed will register this observer as a dependent
      return updateFn(observer.value)
    },
    dependents: new Set(),
    subjects: new Set(),
    name: 'callback'
  }

  // Execute the callback immediately to establish initial dependencies
  updateObserver(observer)
  
  // Return unsubscribe function
  return () => {
    // Clean up dependencies
    if (observer.subjects) {
      for (const subject of observer.subjects) {
        if (subject.dependents) {
          subject.dependents.delete(observer)
        }
      }
      observer.subjects.clear()
    }
  }
}