/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  dependents?: Set<ObserverR>
  subjects?: Set<SubjectR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export interface SubjectR {
  name?: string
  dependents?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
}

// Track dependencies between subjects and observers
export function registerDependency(subject: SubjectR, observer: ObserverR): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
  
  if (!observer.subjects) {
    observer.subjects = new Set()
  }
  observer.subjects.add(subject)
}

export function notifyDependents(subject: SubjectR): void {
  if (subject.dependents) {
    // Create a copy to avoid issues if dependents modify during notification
    const dependentsCopy = new Set(subject.dependents)
    for (const dependent of dependentsCopy) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
}

// Also allow notifying dependents of observers (for computed values)
export function notifyDependentsOfObserver(observer: ObserverR): void {
  if (observer.dependents) {
    // Create a copy to avoid issues if dependents modify during notification
    const dependentsCopy = new Set(observer.dependents)
    for (const dependent of dependentsCopy) {
      updateObserver(dependent as Observer<unknown>)
    }
  }
}

// Get dependents of an observer (for computed values)
export function getDependents(observer: ObserverR): Set<ObserverR> | undefined {
  return observer.dependents
}
