import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load as loadHtml } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import FormServer from '../../src/server.js';

let server: FormServer | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Create a new server instance
  const formServer = new FormServer();
  const port = 3545; // Use a different port to avoid conflicts
  await formServer.start(port);
  server = formServer;
});

afterAll(async () => {
  if (server && server.stop) {
    await server.stop();
  }
  
  // Clean up database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const app = request('http://localhost:3545');
    const response = await app.get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);
    
    const $ = loadHtml(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check for form structure
    expect($('form[action="/submit"][method="POST"]').length).toBe(1);
    expect($('.submit-btn').length).toBe(1);
    expect($('.error-message').length).toBe(0); // No errors on initial load
    
    // Check for CSS styling
    expect($('link[href="/styles.css"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const app = request('http://localhost:3545');
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: '12345',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567'
    };

    const response = await app.post('/submit').send(testData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow redirect and check thank you page
    const thankYouResponse = await app.get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    const $ = loadHtml(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank You');
    expect($('.warning-section').length).toBe(1);
    expect($('.back-btn').length).toBe(1);
  });

  it('validates required fields', async () => {
    const app = request('http://localhost:3545');
    const incompleteData = {
      firstName: 'John',
      // Missing other required fields
    };

    const response = await app.post('/submit').send(incompleteData);
    
    expect(response.status).toBe(400); // Should return 400 for validation errors
    
    const $ = loadHtml(response.text);
    expect($('.error-message').length).toBeGreaterThan(0);
    expect($('.error-message').text()).toContain('required');
  });

  it('validates email format', async () => {
    const app = request('http://localhost:3545');
    const invalidEmailData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: '12345',
      country: 'United States',
      email: 'invalid-email',
      phone: '+1 555 123 4567'
    };

    const response = await app.post('/submit').send(invalidEmailData);
    
    expect(response.status).toBe(400);
    
    const $ = loadHtml(response.text);
    expect($('.error-message').text()).toContain('email');
  });

  it('validates phone number format', async () => {
    const app = request('http://localhost:3545');
    const invalidPhoneData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: '12345',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: 'not-a-phone'
    };

    const response = await app.post('/submit').send(invalidPhoneData);
    
    expect(response.status).toBe(400);
    
    const $ = loadHtml(response.text);
    expect($('.error-message').text()).toContain('phone');
  });

  it('handles international phone and postal formats', async () => {
    const app = request('http://localhost:3545');
    const internationalData = {
      firstName: 'José',
      lastName: 'García',
      streetAddress: 'Calle Mayor 123',
      city: 'Madrid',
      stateProvince: 'Madrid',
      postalCode: '28001',
      country: 'Spain',
      email: 'jose.garcia@ejemplo.es',
      phone: '+34 91 123 4567'
    };

    const response = await app.post('/submit').send(internationalData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('preserves form data on validation error', async () => {
    const app = request('http://localhost:3545');
    const partialData = {
      firstName: 'Jane',
      lastName: 'Smith',
      email: 'jane.smith@example.com'
      // Missing other fields
    };

    const response = await app.post('/submit').send(partialData);
    
    expect(response.status).toBe(400);
    
    const $ = loadHtml(response.text);
    
    // Check that previously entered data is preserved
    expect($('input[name="firstName"]').val()).toBe('Jane');
    expect($('input[name="lastName"]').val()).toBe('Smith');
    expect($('input[name="email"]').val()).toBe('jane.smith@example.com');
  });

  it('serves CSS file correctly', async () => {
    const app = request('http://localhost:3545');
    const response = await app.get('/styles.css');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/css/);
    expect(response.text).toContain('body');
    expect(response.text).toContain('.container');
  });
});