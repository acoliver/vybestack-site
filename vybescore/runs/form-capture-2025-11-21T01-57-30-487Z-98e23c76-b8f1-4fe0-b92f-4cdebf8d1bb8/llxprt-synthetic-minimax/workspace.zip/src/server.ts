import express from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { Server } from 'http';

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private dbPath: string;
  private server: Server | null = null;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve('data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Enable trust proxy for proper IP handling behind reverse proxies
    this.app.set('trust proxy', true);
    
    // Parse URL-encoded bodies (as sent by HTML forms)
    this.app.use(express.urlencoded({ extended: true }));
    
    // Parse JSON bodies
    this.app.use(express.json());
    
    // Serve static files from public directory
    this.app.use(express.static('public'));
    
    // Set EJS as the view engine
    this.app.set('views', path.join(process.cwd(), 'src', 'templates'));
    this.app.set('view engine', 'ejs');
  }

  private setupRoutes(): void {
    // GET / - Render the contact form
    this.app.get('/', (req, res) => {
      res.render('form', {
        errors: {},
        formData: {}
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', (req, res) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = this.validateFormData(formData);

      if (Object.keys(errors).length > 0) {
        // Re-render form with errors and previously entered values
        res.status(400).render('form', {
          errors,
          formData
        });
        return;
      }

      // Save to database
      try {
        this.saveSubmission(formData);
        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Error saving submission:', error);
        res.status(500).render('form', {
          errors: { general: 'An error occurred while saving your submission. Please try again.' },
          formData
        });
      }
    });

    // GET /thank-you - Render thank you page
    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you');
    });
  }

  private validateFormData(data: FormData): ValidationErrors {
    const errors: ValidationErrors = {};

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field].trim() === '') {
        errors[field] = 'This field is required';
      }
    }

    // Email validation
    if (data.email && data.email.trim() !== '') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email)) {
        errors.email = 'Please enter a valid email address';
      }
    }

    // Phone validation (international formats)
    if (data.phone && data.phone.trim() !== '') {
      const phoneRegex = /^\+?[0-9\s\-()]+$/;
      if (!phoneRegex.test(data.phone) || data.phone.replace(/[^\d]/g, '').length < 7) {
        errors.phone = 'Please enter a valid phone number';
      }
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && data.postalCode.trim() !== '') {
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode)) {
        errors.postalCode = 'Please enter a valid postal code';
      }
    }

    return errors;
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file: string) => {
          // Use local WASM file instead of CDN
          return path.resolve('node_modules', 'sql.js', 'dist', file);
        }
      });

      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
        this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private createSchema(): void {
    if (!this.db) return;

    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;

    this.db.exec(schema);
  }

  private saveSubmission(submissionData: FormData): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submissionData.firstName.trim(),
      submissionData.lastName.trim(),
      submissionData.streetAddress.trim(),
      submissionData.city.trim(),
      submissionData.stateProvince.trim(),
      submissionData.postalCode.trim(),
      submissionData.country.trim(),
      submissionData.email.trim(),
      submissionData.phone.trim()
    ]);

    stmt.free();

    // Save database to file
    const dbData = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(dbData));
  }

  public async start(port: number = 3535): Promise<void> {
    await this.initializeDatabase();
    
    return new Promise((resolve, reject) => {
      this.server = this.app.listen(port, (err?: Error) => {
        if (err) {
          reject(err);
        } else {
          console.log(`Server running on port ${port}`);
          resolve();
        }
      });
    });
  }

  public async stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          if (this.db) {
            this.db.close();
            this.db = null;
          }
          console.log('Server stopped');
          resolve();
        });
      } else {
        resolve();
      }
    });
  }
}

// Handle graceful shutdown
const gracefulShutdown = async (signal: string) => {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  if (formServer) {
    await formServer.stop();
  }
  process.exit(0);
};

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Create and start server
const formServer = new FormServer();

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = parseInt(process.env.PORT || '3535', 10);
  formServer.start(port).catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default FormServer;