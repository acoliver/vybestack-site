/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences, collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations that don't end sentences
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Capt', 'Lt', 'Gen', 'Rep', 'Sen', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'eg', 'ie', 'vs', 'approx', 'dept', 'univ'];
  const abbrPattern = new RegExp(`\\b(${abbreviations.join('|')})\\.`, 'g');
  
  // First, protect abbreviations by temporarily replacing them
  let textProtected = text;
  const abbrReplacements: string[] = [];
  let abbrIndex = 0;
  
  textProtected = textProtected.replace(abbrPattern, (match) => {
    const placeholder = `___ABBR${abbrIndex}___`;
    abbrReplacements.push(match);
    abbrIndex++;
    return placeholder;
  });
  
  // Split by sentence boundaries (. ! ?)
  const sentences = textProtected.split(/([.!?]+)/);
  const result: string[] = [];
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    const punctuation = sentences[i + 1] || '';
    
    if (sentence && sentence.trim()) {
      // Capitalize first letter, keep rest as-is
      let capitalized = sentence.trim();
      if (capitalized.length > 0) {
        capitalized = capitalized[0].toUpperCase() + capitalized.slice(1);
      }
      result.push(capitalized + punctuation);
    } else if (punctuation) {
      result.push(punctuation);
    }
  }
  
  // Join with single spaces
  let final = result.join(' ');
  
  // Restore abbreviations
  abbrReplacements.forEach((abbr, idx) => {
    final = final.replace(`___ABBR${idx}___`, abbr);
  });
  
  // Collapse multiple spaces into single space
  final = final.replace(/\s+/g, ' ');
  
  // Remove space before punctuation
  final = final.replace(/\s+([.!?])/g, '$1');
  
  // Ensure exactly one space after sentence-ending punctuation
  final = final.replace(/([.!?])(?=[A-Za-z])/g, '$1 ');
  
  return final.trim();
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, ftp, etc.
  const urlPattern = /(https?:\/\/|ftp:\/\/|www\.)[^\s<>"{}|\\^`[\]]+[^\s<>"{}|\\^`[\].,!?;:]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation that might have been caught
  const cleaned = matches.map(url => url.replace(/[.,!?;:]+$/, ''));
  
  // Deduplicate
  return Array.from(new Set(cleaned));
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Capture groups: full URL, scheme, host, path
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s<>"{}|\\^`[\]]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade scheme
    const newScheme = 'https://';
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicHints = [
        /cgi-bin/,
        /[?&]=/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[/?#]|$)/i
      ];
      
      const shouldSkipHostRewrite = dynamicHints.some(hint => hint.test(path));
      
      if (shouldSkipHostRewrite) {
        // Only upgrade scheme, keep original host
        return newScheme + host + path;
      }
      
      // Rewrite host to docs.example.com
      return newScheme + 'docs.' + host + path;
    }
    
    // Not a docs path, just upgrade scheme
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
