export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical formats like user@example.co.uk and user@tag@example.co.uk (subaddressing)
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Support subaddressing: user@tag@example.co.uk
  // This pattern allows an optional @tag in the local part
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:@[a-zA-Z0-9]+)?@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  // Split by @ to get parts
  const parts = value.split('@');
  
  // For subaddressing (user@tag@example.co.uk), we need at least 3 parts
  // For normal email (user@example.co.uk), we need exactly 2 parts
  if (parts.length < 2) {
    return false;
  }
  
  // Extract local part and domain
  let localPart: string;
  let domain: string;
  
  if (parts.length === 2) {
    // Normal email: user@example.co.uk
    localPart = parts[0];
    domain = parts[1];
  } else {
    // Subaddressing: user@tag@example.co.uk
    // The last part is the domain, everything before is the local part (with tags)
    domain = parts[parts.length - 1];
    localPart = parts.slice(0, parts.length - 1).join('@');
  }
  
  // Local part should not start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // No consecutive dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain should not start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // No consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // Domain must have at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  // TLD must be at least 2 characters
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length (10 digits for US number)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Extract digits only
  const digitsOnly = cleaned.replace(/\+/g, '');
  
  // Handle optional +1 country code
  let areaCode: string;
  let exchange: string;
  
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // With country code
    areaCode = digitsOnly.substring(1, 4);
    exchange = digitsOnly.substring(4, 7);
  } else if (digitsOnly.length === 10) {
    // Without country code
    areaCode = digitsOnly.substring(0, 3);
    exchange = digitsOnly.substring(3, 6);
  } else {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (central office code) cannot start with 0 or 1
  if (exchange[0] === '0' || exchange[0] === '1') {
    return false;
  }
  
  // Validate format matches common patterns
  const formattedPatterns = [
    /^\(\d{3}\)\s*\d{3}-\d{4}$/, // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,        // 212-555-7890
    /^\d{10}$/,                   // 2125557890
    /^\+1\s*\(\d{3}\)\s*\d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+1\s*\d{3}-\d{3}-\d{4}$/,  // +1 212-555-7890
    /^\+1\s*\d{10}$/,             // +1 2125557890
  ];
  
  // Check if the original format matches one of the common patterns
  const hasValidFormat = formattedPatterns.some(pattern => pattern.test(value.trim()));
  
  return hasValidFormat;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, keep track of structure
  const normalized = value.replace(/[\s-]/g, '');
  
  // Match pattern: optional +54, optional 0 trunk prefix, optional 9 mobile indicator, area code, subscriber
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentinePattern = /^(\+54)?(0)?([9])?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = normalized.match(argentinePattern);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, mobileIndicator, areaCode, subscriber] = match;
  
  // If country code is present, trunk prefix can be optional
  // If country code is absent, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Total digits check (country code: 2 if +54, trunk: 1, mobile: 1, area: 2-4, subscriber: 6-8)
  const totalDigits = (countryCode ? '54'.length : 0) + 
                     (trunkPrefix ? trunkPrefix.length : 0) + 
                     (mobileIndicator ? mobileIndicator.length : 0) + 
                     areaCode.length + 
                     subscriber.length;
  
  // Should be reasonable length (10-14 digits total excluding +)
  if (totalDigits < 10 || totalDigits > 14) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Name should not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Should not consist only of separators
  const onlySeparators = /^[\s'-]+$/;
  if (onlySeparators.test(value)) {
    return false;
  }
  
  // Reject names with numbers (like X Æ A-12)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject multiple consecutive separators
  if (/''|--/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length: 13-19 digits (typical credit card lengths)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check valid prefixes for major card types
  const validPatterns = [
    /^4[0-9]{12}([0-9]{3})?$/,           // Visa: starts with 4, length 13 or 16
    /^5[1-5][0-9]{14}$/,                 // Mastercard: starts with 51-55, length 16
    /^2[2-7][0-9]{14}$/,                 // Mastercard (new range): starts with 22-27, length 16
    /^3[47][0-9]{13}$/,                  // American Express: starts with 34 or 37, length 15
    /^6(?:011|5[0-9]{2})[0-9]{12}$/,     // Discover: starts with 6011 or 65, length 16
  ];
  
  const isValidPrefix = validPatterns.some(pattern => pattern.test(cleaned));
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
