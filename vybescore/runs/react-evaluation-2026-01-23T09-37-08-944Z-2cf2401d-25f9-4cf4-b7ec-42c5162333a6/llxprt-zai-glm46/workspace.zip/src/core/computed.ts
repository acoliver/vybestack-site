/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Track that this observer depends on this computed
      const obs = observer as Observer<unknown>
      obs._computedDeps = obs._computedDeps || new Set()
      obs._computedDeps.add(o)

      // Also track the reverse dependency for proper propagation
      const compObs = o as Observer<unknown>
      compObs._dependents = compObs._dependents || new Set()
      compObs._dependents.add(observer)
    }
    return o.value!
  }

  // Wrap updateFn to clear old dependencies
  const wrappedUpdateFn: UpdateFn<T> = (prev?: T) => {
    // Clear old dependencies from subjects
    const oldSubjects = (o as Observer<unknown>)._subjects
    if (oldSubjects) {
      for (const s of oldSubjects) {
        if (s._observers && s._observers.has(o)) {
          s._observers.delete(o)
        }
      }
      oldSubjects.clear()
    }
    (o as Observer<unknown>)._subjects = new Set()

    // Run updateFn to recompute and track new dependencies
    const result = updateFn(prev)

    // Get new subjects that this observer now depends on
    const newSubjects = (o as Observer<unknown>)._subjects || new Set()
    ;(o as Observer<unknown>)._subjects = newSubjects

    return result
  }

  o.updateFn = wrappedUpdateFn

  // Initial computation to establish dependencies
  updateObserver(o)

  return getter
}

