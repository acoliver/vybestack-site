/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Track all callbacks for proper cleanup
const callbackObservers = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }

  // Add observer to the global set
  callbackObservers.add(observer as Observer<unknown>)

  // Register observer to track dependencies
  updateObserver(observer)

  let disposed = false

  return () => {
    if (disposed) return
    disposed = true

    // Remove from tracking
    callbackObservers.delete(observer as Observer<unknown>)

    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
