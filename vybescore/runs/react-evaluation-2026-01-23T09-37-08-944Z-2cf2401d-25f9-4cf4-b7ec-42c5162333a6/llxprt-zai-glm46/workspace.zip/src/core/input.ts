/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined =
    typeof equal === 'function' ? equal : undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    _observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      s._observers!.add(observer)

      // Track which subjects this observer depends on
      const obs = observer as Observer<unknown>
      obs._subjects = obs._subjects || new Set()
      obs._subjects.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (!hasChanged) return s.value

    s.value = nextValue

    // Notify all observers that depend on this subject
    // Convert to array to avoid issues with Set modification during iteration
    const observersToUpdate = Array.from(s._observers!)
    for (const obs of observersToUpdate) {
      updateObserver(obs as Observer<unknown>)
    }

    return s.value
  }

  return [read, write]
}
