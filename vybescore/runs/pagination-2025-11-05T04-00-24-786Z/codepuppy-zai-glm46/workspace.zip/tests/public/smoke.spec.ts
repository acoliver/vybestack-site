import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('validates page parameter - rejects non-numeric values', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('page must be a positive integer');
  });

  it('validates page parameter - rejects zero and negative values', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response1 = await request(app).get('/inventory?page=0');
    expect(response1.status).toBe(400);
    
    const response2 = await request(app).get('/inventory?page=-1');
    expect(response2.status).toBe(400);
  });

  it('validates limit parameter - rejects excessive values', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('limit must be a positive integer (max 100)');
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15); // Based on seed data
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items.length).toBe(5);
  });

  it('paginates correctly across pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get first page
    const response1 = await request(app).get('/inventory?page=1&limit=5');
    expect(response1.status).toBe(200);
    const firstPageIds = response1.body.items.map((item: { id: number }) => item.id);
    expect(firstPageIds).toEqual([1, 2, 3, 4, 5]);
    
    // Get second page
    const response2 = await request(app).get('/inventory?page=2&limit=5');
    expect(response2.status).toBe(200);
    const secondPageIds = response2.body.items.map((item: { id: number }) => item.id);
    expect(secondPageIds).toEqual([6, 7, 8, 9, 10]);
    
    // Get third page
    const response3 = await request(app).get('/inventory?page=3&limit=5');
    expect(response3.status).toBe(200);
    const thirdPageIds = response3.body.items.map((item: { id: number }) => item.id);
    expect(thirdPageIds).toEqual([11, 12, 13, 14, 15]);
    expect(response3.body.hasNext).toBe(false);
  });

  it('returns empty result for page beyond data', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.hasNext).toBe(false);
  });
});
