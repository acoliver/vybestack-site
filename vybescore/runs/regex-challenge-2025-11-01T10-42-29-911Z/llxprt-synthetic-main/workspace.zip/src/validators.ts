export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9]+([+-._][a-zA-Z0-9]+)*@[a-zA-Z0-9]+([-.][a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;
  
  // Check basic email format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for leading or trailing dots
  const parts = value.split('@');
  const localPart = parts[0];
  
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (parts[1].includes('_')) {
    return false;
  }
  
  // Check for trailing dot in domain
  if (parts[1].endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const digits = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must have exactly 10 digits for US phone number
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens
  const normalizedNumber = value.replace(/[ -]/g, '');
  
  // Pattern to match Argentine phone numbers:
  // Optional +54 country code
  // Optional 0 trunk prefix (if no country code)
  // Optional 9 mobile indicator (between country/trunk and area code)
  // Area code: 2-4 digits, starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(9)?(?:(0)|([1-9]\d{1,3}))(\d{6,8})$/;
  
  const match = normalizedNumber.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const countryCode = match[1];
  const trunkPrefix = match[3];
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // If no country code, must have trunk prefix (0) before area code
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Validate area code
  if (areaCode) {
    const areaCodeLength = areaCode.length;
    if (areaCodeLength < 2 || areaCodeLength > 4) {
      return false;
    }
  }
  
  // Validate subscriber number
  const subscriberLength = subscriberNumber.length;
  if (subscriberLength < 6 || subscriberLength > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[a-zA-Z\u00C0-\u00FF\u0100-\u017F\u0180-\u024F'’-]+(?: [a-zA-Z\u00C0-\u00FF\u0100-\u017F\u0180-\u024F'’-]+)*$/;
  
  // Name cannot be empty
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Check against pattern
  return nameRegex.test(value);
}

/**
 * Helper function for Luhn algorithm
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanNumber = value.replace(/\D/g, '');
  
  // Check for Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  
  // Check for Mastercard (16 digits, starts with 51-55 or 2221-2720)
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // Check for AmEx (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleanNumber) && 
      !mastercardRegex.test(cleanNumber) && 
      !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleanNumber);
}
