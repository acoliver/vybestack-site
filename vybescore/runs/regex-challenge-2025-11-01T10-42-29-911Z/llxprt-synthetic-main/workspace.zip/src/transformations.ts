/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Check if string is empty
  if (!text) return text;
  
  // First character of the string should always be capitalized
  let result = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Look for sentence-ending punctuation followed by potential lowercase letters
  const regex = /([.?!])(\s+)([a-z])/g;
  
  // Replace each occurrence with capitalized letter
  result = result.replace(regex, (match, punct, space, letter) => {
    return punct + space + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches http/https, www, and domain-only URLs
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"']+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?/g;
  
  // Find all potential URLs
  const potentialUrls = text.match(urlRegex) || [];
  
  // Process each potential URL to remove trailing punctuation and validate
  return potentialUrls.map(url => {
    // Remove trailing punctuation
    const cleanUrl = url.replace(/[.,;:!?)\]\}]+$/g, '');
    
    // If the URL doesn't start with http://, https://, or www., it might be an incomplete match
    // Add protocol if needed for validation but not for the output
    return cleanUrl;
  }).filter(url => {
    // Basic validation - should contain at least a domain and a TLD
    const domainRegex = /(?:https?:\/\/|www\.)?[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
    return domainRegex.test(url);
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https:// with https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Regex to capture http://example.com/... URLs
  const urlRegex = /(http:\/\/)([a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Always upgrade the scheme to https://
    const newProtocol = 'https://';
    
    // If there's no path or path doesn't start with /docs/, just change the protocol
    if (!path || !path.startsWith('/docs/')) {
      return newProtocol + domain + (path || '');
    }
    
    // Check if path should skip host rewrite (contains dynamic hints or legacy extensions)
    const skipRewritePatterns = [
      /\/(cgi-bin)\//,
      /[?&=]/, // query params
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i // legacy extensions
    ];
    
    const shouldSkipRewrite = skipRewritePatterns.some(pattern => pattern.test(path));
    
    if (shouldSkipRewrite) {
      // Only upgrade the scheme
      return newProtocol + domain + path;
    }
    
    // Rewrite the host to docs.example.com
    const newDomain = 'docs.' + domain;
    
    return newProtocol + newDomain + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const yearStr = match[3]; // Year as string to return
  const year = parseInt(yearStr, 10); // Year as number for calculations
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) ? 29 : 28, // February (leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return yearStr;
}
