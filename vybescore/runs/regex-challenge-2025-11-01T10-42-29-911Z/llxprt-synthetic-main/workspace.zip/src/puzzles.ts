/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex special characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Regex to find words starting with the prefix
  const prefixedWordsRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Filter out exceptions
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  return matches.filter(word => !exceptionSet.has(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a simple regex to find occurrences of digit + token
  const embeddedTokenRegex = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(embeddedTokenRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 3x3x, etc.)
  // This regex matches two identical patterns of length 1-3 characters in immediate succession
  const repeatedSequenceRegex = /(.{1,3})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude IPv4 addresses
  const ipv4Regex = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Basic IPv6 regex that handles common formats
  const ipv6Parts = [
    // Full form with 8 groups of 1-4 hex digits
    '(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}',
    // Short form ending with ::
    '(?:[0-9a-fA-F]{1,4}:){1,7}:',
    // Short form starting with ::
    ':(?:[0-9a-fA-F]{1,4}:){1,7}',
    // Mixed form with IPv4
    '(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}\\.[0-9]{1,3}'
  ];
  
  const ipv6Regex = new RegExp(ipv6Parts.join('|'), 'g');
  
  return ipv6Regex.test(value);
}