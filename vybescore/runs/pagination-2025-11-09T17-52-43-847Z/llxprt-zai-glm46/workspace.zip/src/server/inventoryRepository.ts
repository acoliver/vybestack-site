import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePageLimit(options: { page?: number; limit?: number }): { page: number; limit: number } {
  const MAX_LIMIT = 100;
  
  const page = options.page !== undefined ? options.page : 1;
  const limit = options.limit !== undefined ? options.limit : DEFAULT_LIMIT;
  
  if (typeof page !== 'number' || !isFinite(page) || page <= 0) {
    throw new Error('Page must be a positive number');
  }
  
  if (typeof limit !== 'number' || !isFinite(limit) || limit <= 0) {
    throw new Error('Limit must be a positive number');
  }
  
  if (limit > MAX_LIMIT) {
    throw new Error(`Limit cannot exceed ${MAX_LIMIT}`);
  }
  
  return {
    page: Math.floor(page),
    limit: Math.floor(limit)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const { page, limit } = validatePageLimit(options);

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = page * limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
