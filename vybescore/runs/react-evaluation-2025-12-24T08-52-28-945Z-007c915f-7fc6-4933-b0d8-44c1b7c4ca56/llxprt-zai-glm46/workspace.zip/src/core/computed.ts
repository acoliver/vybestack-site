/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ObserverR, 
  setActiveObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

type Subject = import('../types/reactive.js').Subject<unknown>

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: ObserverR = {
    name: options?.name,
    __subjects: new Set<Subject>(),
    onInvalidate: () => {
      // Re-compute when dependencies change
      const prev = getActiveObserver()
      setActiveObserver(o)
      try {
        currentValue = updateFn(currentValue)
      } finally {
        setActiveObserver(prev)
      }
      // Notify our observers when we change
      computedObservers.forEach(obs => {
        if (obs.onInvalidate) obs.onInvalidate()
      })
    }
  }
  
  const computedObservers = new Set<ObserverR>()
  
  let currentValue: T = value!
  
  // Initial computation to establish dependencies
  const prev = getActiveObserver()
  setActiveObserver(o)
  try {
    currentValue = updateFn(currentValue)
  } finally {
    setActiveObserver(prev)
  }
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      computedObservers.add(observer)
      // Forward this observer to our dependencies
      if (o.__subjects) {
        o.__subjects.forEach(subject => {
          subject.observers.add(observer)
          const obsWithSubjects = observer as { __subjects?: Set<Subject> }
          if (obsWithSubjects.__subjects) {
            obsWithSubjects.__subjects.add(subject)
          }
        })
      }
    }
    return currentValue
  }
  
  return getter
}
