/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ObserverR,
  getActiveObserver,
  addObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Use type assertion for the addObserver call
      addObserver(s as unknown as Subject<unknown>, observer)
      // Also register this observer with our callback's subject tracking
      const obsWithSubjects = observer as { __subjects?: Set<Subject<unknown>> }
      if (obsWithSubjects.__subjects) {
        obsWithSubjects.__subjects.add(s as Subject<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = typeof _equal === 'function' ? _equal : undefined
    const shouldCompare = typeof _equal === 'boolean' ? _equal : true
    
    if (shouldCompare && equalFn) {
      if (equalFn(s.value, nextValue)) return s.value
    } else if (shouldCompare && s.value === nextValue) {
      return s.value
    }
    
    s.value = nextValue
    // Use type assertion for the notifyObservers call
    notifyObservers(s as unknown as Subject<unknown>)
    return s.value
  }

  return [read, write]
}
