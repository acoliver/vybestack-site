/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, ObserverR, setActiveObserver, getActiveObserver } from '../types/reactive.js'

type UpdateFn<T> = import('../types/reactive.js').UpdateFn<T>

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: ObserverR = {
    onInvalidate: () => {
      // Re-run the effect when dependencies change
      updateFn(value)
    },
    __subjects: new Set()
  }
  
  // Track dependencies during initial execution
  const prev = getActiveObserver()
  setActiveObserver(observer)
  try {
    updateFn(value)
  } finally {
    setActiveObserver(prev)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all tracked subjects
    if (observer.__subjects) {
      observer.__subjects.forEach(subject => {
        subject.observers.delete(observer)
      })
      observer.__subjects.clear()
    }
  }
}
