/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate whether a string is valid Base64.
 * Checks for: valid characters, and proper padding placement if padding is present.
 */
function isValidBase64(input: string): boolean {
  const trimmed = input.trim();
  if (trimmed.length === 0) return false;

  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmed)) return false;

  const padIndex = trimmed.indexOf('=');
  if (padIndex !== -1) {
    const padding = trimmed.slice(padIndex);
    if (!/^=+$/.test(padding)) return false;
    if (padding.length > 2) return false;
    if (padIndex < 2) return false;
  }

  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  if (trimmed.length === 0) {
    throw new Error('Failed to decode Base64 input: input is empty');
  }

  if (!isValidBase64(trimmed)) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    const decoded = buffer.toString('utf8');

    if (trimmed.length > 0 && buffer.length === 0) {
      throw new Error('Failed to decode Base64 input: no data decoded');
    }

    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
