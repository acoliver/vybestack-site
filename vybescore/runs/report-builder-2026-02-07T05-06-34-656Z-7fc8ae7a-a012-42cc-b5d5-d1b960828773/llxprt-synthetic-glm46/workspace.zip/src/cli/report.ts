#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { exit, stderr } from 'node:process';
import { validateReportData } from '../utils/validation.js';
import { getRenderer } from '../formats/index.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliOptions {
  if (args.length < 2) {
    stderr.write('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]\n');
    exit(1);
  }

  const filePath = args[0];
  let format = '';
  let output: string | undefined;
  let includeTotals = false;

  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    stderr.write('Error: --format is required\n');
    exit(1);
  }

  return { format, output, includeTotals };
}

function main() {
  try {
    const args = process.argv.slice(2);
    const options = parseArguments(args);
    const filePath = args[0];

    // Read and parse the JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(filePath, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      stderr.write(`Error reading or parsing file "${filePath}": ${error instanceof Error ? error.message : 'Unknown error'}\n`);
      exit(1);
    }

    // Validate the report data
    const reportData = validateReportData(jsonData);

    // Get the appropriate renderer
    const renderer = getRenderer(options.format);
    
    // Render the report
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals,
    };
    
    const output = renderer(reportData, renderOptions);

    // Write output
    if (options.output) {
      try {
        const { writeFileSync } = await import('node:fs');
        writeFileSync(options.output, output, 'utf-8');
        console.log(`Report saved to ${options.output}`);
      } catch (error) {
        stderr.write(`Error writing to file "${options.output}": ${error instanceof Error ? error.message : 'Unknown error'}\n`);
        exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    stderr.write(`Error: ${error instanceof Error ? error.message : 'Unknown error'}\n`);
    exit(1);
  }
}

main();
