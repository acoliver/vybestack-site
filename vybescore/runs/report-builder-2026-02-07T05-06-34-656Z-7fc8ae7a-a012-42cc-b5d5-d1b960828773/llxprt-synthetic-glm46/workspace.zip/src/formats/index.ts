import type { ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const FORMATS: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getRenderer(format: string): ReportRenderer {
  const renderer = FORMATS[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}