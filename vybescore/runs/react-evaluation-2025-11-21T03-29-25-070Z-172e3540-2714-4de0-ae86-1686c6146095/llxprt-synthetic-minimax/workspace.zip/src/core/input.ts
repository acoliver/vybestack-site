/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  addDependent,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    dependents: new Set(),
    value,
    equalFn: undefined,
  }

  // Set up equality function
  if (equal === undefined) {
    // Default: strict equality
    s.equalFn = (lhs, rhs) => lhs === rhs
  } else if (typeof equal === 'boolean') {
    // If boolean provided, use strict equality or always update
    s.equalFn = equal ? ((lhs, rhs) => lhs === rhs) : (() => false)
  } else if (typeof equal === 'function') {
    // Custom equality function
    s.equalFn = equal
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && 'updateFn' in observer) {
      // Register this observer as a dependent of this subject
      addDependent(s, observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    
    if (shouldUpdate) {
      s.value = nextValue
      // Notify all dependents that this value has changed
      notifyDependents(s)
    }
    
    return s.value
  }

  return [read, write]
}
