/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  addDependent,
  notifyDependents,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Store the current value and equality function
  let currentValue = value
  let equalFn: EqualFn<T> | undefined
  
  // Set up equality function for computed value
  if (equal === undefined) {
    equalFn = (lhs, rhs) => lhs === rhs
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? ((lhs, rhs) => lhs === rhs) : (() => false)
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  // Create a subject-like object for dependency tracking
  const subject: Subject<T> = {
    name: options?.name,
    dependents: new Set<Observer<unknown>>(),
    observer: undefined,
    value: value!,
    equalFn: equalFn
  }
  
  // Create the getter that re-evaluates on each call
  const getter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    
    // Register as dependent if there's an active observer
    if (activeObs && 'updateFn' in activeObs) {
      addDependent(subject, activeObs as Observer<unknown>)
    }
    
    // Execute update function to get new value
    const newValue = updateFn(currentValue)
    
    // Check if value has changed and update
    const shouldUpdate = !equalFn || !equalFn(currentValue!, newValue)
    
    if (shouldUpdate) {
      currentValue = newValue
      observer.value = newValue
      // Notify dependents that this computed value changed
      notifyDependents(subject)
    }
    
    return currentValue!
  }
  
  return getter
}
