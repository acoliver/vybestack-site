/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  dependents: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value)
    observer.value = result
    return result
  } finally {
    activeObserver = previous
  }
}

// Add a dependent observer to a subject
export function addDependent<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

// Remove a dependent observer from a subject
export function removeDependent<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  subject.dependents?.delete(observer)
}

// Notify all dependents of a subject that it has changed
export function notifyDependents<T>(subject: Subject<T>): void {
  if (subject.dependents) {
    // Create a copy to avoid issues if dependents modify the set during iteration
    const dependentsCopy = new Set(subject.dependents)
    for (const observer of dependentsCopy) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}

// Helper function to check if a value has changed based on equality function
export function hasValueChanged<T>(current: T, next: T, equalFn?: EqualFn<T>): boolean {
  if (!equalFn) return current !== next
  return !equalFn(current, next)
}
