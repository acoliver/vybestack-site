

/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses standard Base64 alphabet and rejects invalid input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  validateBase64Input(input);
  const workingInput = prepareInputForBuffer(input);

  try {
    const buffer = Buffer.from(workingInput, 'base64');
    const decoded = buffer.toString('utf8');
    
    validateDecodedData(buffer, input);
    
    return decoded;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validates the format and characters of Base64 input.
 */
function validateBase64Input(input: string): void {
  // Check for valid Base64 characters (standard alphabet + padding)
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for correct padding position and format
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If there's padding, it should only be at the end
    const padding = input.slice(paddingIndex);
    if (!/^(={1,2})$/.test(padding)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Ensure there are no non-padding characters after padding
    const afterPadding = input.slice(paddingIndex + padding.length);
    if (afterPadding.length > 0) {
      throw new Error('Invalid Base64 input: characters after padding');
    }
  }
}

/**
 * Prepares input for Buffer.from() by adding padding if needed.
 */
function prepareInputForBuffer(input: string): string {
  const paddingIndex = input.indexOf('=');
  
  // If no padding and length is not divisible by 4, add padding for Buffer to work correctly
  if (paddingIndex === -1 && input.length % 4 !== 0) {
    const paddingNeeded = 4 - (input.length % 4);
    return input + '='.repeat(paddingNeeded);
  }
  
  return input;
}

/**
 * Validates that the decoded data matches the original input.
 */
function validateDecodedData(buffer: Buffer, originalInput: string): void {
  // Additional validation: check if the re-encoded version matches the original (ignoring padding differences)
  // This helps catch corrupted or malformed input
  const reencoded = buffer.toString('base64');
  const normalizedOriginal = originalInput.replace(/=+$/, '');
  const normalizedReencoded = reencoded.replace(/=+$/, '');
  
  if (normalizedReencoded !== normalizedOriginal) {
    throw new Error('Invalid Base64 input: corrupted data');
  }
}
