/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  // Handle equal parameter
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      const newValue = updateFn(currentValue)
      
      // Only update the stored value if it actually changed
      if (!equalFn || value === undefined || !equalFn(value, newValue)) {
        value = newValue
      }
      
      // Always notify dependent observers since dependencies may have changed
      if (o.dependentObservers) {
        for (const dependent of o.dependentObservers) {
          updateObserver(dependent as Observer<unknown>)
        }
      }
      
      return value
    },
  }
  
  // Initial computation
  updateObserver(o)
  
  return (): T => {
    // When accessed, register as dependency for current observer
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== o) {
      // Current observer depends on this computed value
      if (!o.dependentObservers) {
        o.dependentObservers = new Set()
      }
      o.dependentObservers.add(currentObserver)
    }
    
    return value!
  }
}
