/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

import { flushComputedUpdates } from './computed.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Store multiple observers for this input
  const observers = new Set<ObserverR>()
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer)
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Update all observers that depend on this input
    // Convert to array to avoid issues with set modification during iteration
    const observersArray = Array.from(observers)
    observersArray.forEach(obs => {
      if ('updateFn' in obs) {
        updateObserver(obs as Observer<unknown>)
      }
    })
    // Flush computed updates after all direct observers have been updated
    flushComputedUpdates()
    return s.value
  }

  return [read, write]
}
