/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

type ComputedRegistryEntry = {
  observer: Observer<unknown>
  dependentObservers: Set<ObserverR>
}

// Global registry to map getters to their observers
const computedRegistry = new WeakMap<GetterFn<unknown>, ComputedRegistryEntry>()

// Queue for deferred updates
let updateQueue: Observer<unknown>[] = []

export function enqueueComputedUpdate(obs: Observer<unknown>): void {
  updateQueue.push(obs)
}

export function flushComputedUpdates(): void {
  if (updateQueue.length === 0) return
  
  // Deduplicate the queue
  const uniqueObservers = Array.from(new Set(updateQueue))
  updateQueue = []
  
  uniqueObservers.forEach(obs => {
    updateObserver(obs)
  })
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Store observers that depend on this computed value
  const dependentObservers = new Set<ObserverR>()
  
  const getter: GetterFn<T> = (): T => {
    // Register this computed's observer with the active observer
    const activeObs = getActiveObserver()
    if (activeObs) {
      dependentObservers.add(activeObs)
    }
    return o.value as T
  }
  
  // Register the observer and dependent observers with the getter for later lookup
  computedRegistry.set(getter as GetterFn<unknown>, { observer: o as Observer<unknown>, dependentObservers })
  
  // Wrap updateFn to propagate updates to dependent observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T): T => {
    const newValue = originalUpdateFn(prevValue)
    // After updating, enqueue all dependent observers
    dependentObservers.forEach(depObs => {
      if ('updateFn' in depObs) {
        enqueueComputedUpdate(depObs as Observer<unknown>)
      }
    })
    return newValue
  }
  
  // Compute initial value
  updateObserver(o)
  
  return getter
}
