import { FormData, ValidationErrors, ValidationResult } from './types.js';

export function validateFormData(formData: FormData): ValidationResult {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!formData.firstName.trim()) {
    errors.firstName = 'First name is required';
  }

  if (!formData.lastName.trim()) {
    errors.lastName = 'Last name is required';
  }

  if (!formData.streetAddress.trim()) {
    errors.streetAddress = 'Street address is required';
  }

  if (!formData.city.trim()) {
    errors.city = 'City is required';
  }

  if (!formData.stateProvince.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!formData.postalCode.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!formData.country.trim()) {
    errors.country = 'Country is required';
  }

  if (!formData.email.trim()) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(formData.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidEmail(email: string): boolean {
  // Simple email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[0-9\s\-()]{7,}$/;
  return phoneRegex.test(phone);
}