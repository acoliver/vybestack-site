import express, { Request, Response } from 'express';
import path from 'path';
import { validateFormData } from './validation.js';
import { DatabaseManager } from './database.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Database manager
const dbManager = new DatabaseManager(path.join(process.cwd(), 'data', 'submissions.sqlite'));

// Initialize database
await dbManager.initialize();

// Routes
app.get('/', async (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    formData: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validationResult = validateFormData(formData);
  
  if (!validationResult.isValid) {
    return res.status(400).render('form', {
      errors: validationResult.errors,
      formData
    });
  }

  try {
    await dbManager.insertSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while processing your submission. Please try again.' },
      formData
    });
  }
});

app.get('/thank-you', async (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

export default app;
