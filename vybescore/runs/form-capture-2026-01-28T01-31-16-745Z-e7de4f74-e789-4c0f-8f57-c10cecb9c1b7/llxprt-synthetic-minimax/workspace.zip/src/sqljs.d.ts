declare module 'sql.js' {
  interface Database {
    exec(sql: string): void;
    run(sql: string, params?: unknown[]): void;
    get(sql: string, params?: unknown[]): unknown;
    all(sql: string, params?: unknown[]): unknown[];
    close(): void;
    export(): Uint8Array;
    prepare(sql: string): Statement;
  }

  interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }

  interface SqlJsModule {
    Database: new (dbData?: Uint8Array) => Database;
  }

  interface SqlJsFactory {
    (config?: object): Promise<SqlJsModule>;
  }

  const SqlJsFactory: SqlJsFactory;
  export = SqlJsFactory;
}