export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  general?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationErrors;
}

export interface Database {
  run: (sql: string, params?: unknown[]) => void;
  exec: (sql: string) => void;
  get: (sql: string, params?: unknown[]) => unknown;
  all: (sql: string, params?: unknown[]) => unknown[];
  close: () => void;
  export: () => Uint8Array;
  prepare: (sql: string) => Statement;
}

export interface Statement {
  run: (params?: unknown[]) => void;
  free: () => void;
}

export interface SqlJsModule {
  Database: new (dbData?: Uint8Array) => Database;
}

export interface SqlJsFactory {
  (config?: object): Promise<SqlJsModule>;
}