/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = typeof equal === 'function' ? equal : undefined;
  let currentValue: T | undefined = value;
  let disposed = false;
  
  const o: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue!;
      
      // Run the update function to compute new value
      const newValue = updateFn(prevValue);
      
      // If there's an equal function, use it to check if the value actually changed
      if (equalFn && currentValue !== undefined && equalFn(currentValue, newValue)) {
        return currentValue;
      }
      
      currentValue = newValue;
      return newValue;
    },
    dependencies: new Set()
  };

  // Initially compute the value
  updateObserver(o);
  
  const getter: GetterFn<T> = () => {
    if (disposed) {
      throw new Error("Computed value has been disposed");
    }
    
    // Track dependencies when accessed within another observer
    const activeObserver = getActiveObserver();
    if (activeObserver) {
      // Add this observer to the active observer's dependencies
      activeObserver.dependencies.add(o as unknown as Observer<unknown>);
    }
    
    return currentValue!;
  };

  // Add dispose method to clean up
  getter.dispose = () => {
    disposed = true;
    // Clear references to prevent memory leaks
    o.value = undefined;
    o.updateFn = () => currentValue!;
    // Remove this observer from all dependencies
    o.dependencies.forEach(dep => {
      dep.observers.delete(o as unknown as Observer<unknown>);
    });
    o.dependencies.clear();
  };

  return getter;
}