/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set()
  }
  
  // Track if this callback has been unsubscribed
  let disposed = false
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  // Return an unsubscribe function that will stop further updates
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer references to prevent memory leaks
    observer.value = undefined
    observer.updateFn = () => undefined as unknown as T
    // Remove this observer from all dependencies
    observer.dependencies.forEach(dep => {
      dep.observers.delete(observer);
    });
    observer.dependencies.clear();
  }
}