/**
 * Capitalizes the first character of each sentence, with proper spacing.
 */
export function capitalizeSentences(text: string): string {
  // Start with the input text
  let result = '';
  // Track whether the next character should be capitalized
  let capitalizeNext = true;
  
  // Process each character
  for (let i = 0; i < text.length; i++) {
    const char = text[i];
    
    // If this is a sentence ending punctuation, next char should be capitalized
    if (char === '.' || char === '!' || char === '?') {
      capitalizeNext = true;
      result += char;
    } 
    // If we should capitalize and this is a letter, capitalize it
    else if (capitalizeNext && /[a-zA-Z]/.test(char)) {
      result += char.toUpperCase();
      capitalizeNext = false;
    }
    // Just add the character
    else {
      result += char;
    }
  }
  
  // Normalize spacing after punctuation, but be careful with abbreviations
  result = result.replace(/([.?!])\s{1,}/g, '$1 ');
  // Remove multiple spaces
  result = result.replace(/\s+/g, ' ');
  // Trim leading/trailing spaces
  result = result.trim();
  // Handle special case for single word
  if (result === '') return '';
  
  return result;
}

/**
 * Finds URLs in a text, returning matches without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches common URL formats with protocol
  const urlRegex = /https?:\/\/[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9()@:%_+.~#?&//=]*)/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map((url) => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * Replaces http:// with https:// if not already https.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// URLs with https://
  return text.replace(/http:\/\/(\S+)/g, 'https://$1');
}

/**
 * Rewrites URLs with specific patterns.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/* URLs
  const exampleUrlRegex = /http:\/\/example\.com\/([^\s]+)/g;
  
  return text.replace(exampleUrlRegex, (match, pathAndAfter) => {
    // Split path from any trailing punctuation/whitespace
    const path = pathAndAfter.replace(/[.,;:!?]+$/, '');
    
    // Check if this should be redirected to docs.example.com
    const pathStartsWithDocs = path.startsWith('docs/');
    
    // Determine if we should skip host rewrite based on dynamic indicators
    const hasDynamicIndicators = /[?&#]/.test(path) || 
      path.match(/\.(jsp|php|asp|aspx|do|cgi|pl|py)/) ||
      path.includes('cgi-bin');
    
    // If it starts with docs/ and doesn't have dynamic indicators, rewrite the host
    if (pathStartsWithDocs && !hasDynamicIndicators) {
      // Replace the entire URL with https://docs.example.com/{path}
      return `https://docs.example.com/${path}`;
    }
    
    // Otherwise, just upgrade to https
    return `https://example.com/${path}`;
  });
}

/**
 * Extracts the year from a mm/dd/yyyy date string.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation to check if month/day combination is valid
  // Simple validation without considering leap years or month-specific days
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  if (day > 31) {
    return 'N/A';
  }
  
  return year;
}
