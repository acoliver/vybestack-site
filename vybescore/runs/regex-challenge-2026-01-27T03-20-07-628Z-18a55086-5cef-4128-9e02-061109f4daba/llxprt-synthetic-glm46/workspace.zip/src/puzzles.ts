/**
 * Finds words starting with a prefix but excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex to match words starting with the prefix
  const wordRegex = new RegExp(`\\b${prefix}[a-zA-Z0-9_-]*\\b`, 'g');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and return unique matches
  const filteredWords = matches.filter(word => !exceptions.includes(word));
  return [...new Set(filteredWords)];
}

/**
 * Finds tokens that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern to match a digit followed by the token
  const tokenRegex = new RegExp(`\\d+${token}`, 'g');
  const matches = [];
  
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    // Get the full match (digit+token)
    const fullMatch = match[0];
    
    // Check that this is not at the start of the string
    if (match.index > 0) {
      matches.push(fullMatch);
    }
  }
  
  return matches;
}

/**
 * Validates passwords according to security policy.
 */
export function isStrongPassword(value: string): boolean {
  // Check for minimum length (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for whitespace (should not contain any)
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab" or "abcabc"
  for (let len = Math.floor(value.length / 2); len >= 2; len--) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const first = value.substring(i, i + len);
      const second = value.substring(i + len, i + 2 * len);
      if (first === second) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Basic IPv6 regex pattern
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|::[0-9a-fA-F]{1,4}|::|(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}::[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Check if the input contains an IPv6 address
  if (ipv6Pattern.test(value)) {
    // Make sure it's not just an IPv4 address
    const ipv4Pattern = /^(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    
    return !ipv4Pattern.test(value);
  }
  
  return false;
}
