export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};



/**
 * Validates email addresses according to common patterns.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that handles most valid cases while rejecting obvious invalid ones
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for common invalid patterns
  // No consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // No leading or trailing dots in local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Note: options parameter is defined for API compatibility but not used in current implementation
  // Future implementations might use options.allowExtensions for phone number extensions
  
  // Remove all non-digit characters for processing
  // Remove all non-digit characters for processing
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for standard phone, 11 with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If there are 11 digits, first must be '1'
  if (digitsOnly.length === 11 && digitsOnly[0] !== '1') {
    return false;
  }
  
  // Extract the actual 10-digit phone number (last 10 digits)
  const phoneNumber = digitsOnly.slice(-10);
  
  // Check area code (first digit can't be 0 or 1)
  if (phoneNumber[0] === '0' || phoneNumber[0] === '1') {
    return false;
  }
  
  // Also validate the format with optional separators (allow dots too)
  const phoneRegex = /^(\+?1[\s-]?)?(\(\d{3}\)|\d{3})[\s-.]?\d{3}[\s-.]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleanValue = value.replace(/[-\s]/g, '');
  
  // Different regex for when country code is present vs not present
  if (cleanValue.startsWith('+54')) {
    // With country code: +54[9][area-code][subscriber]
    // Country code, optional mobile indicator, area code (2-4 digits, first digit 1-9), subscriber number
    const regexWithCountry = /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/;
    
    if (!regexWithCountry.test(cleanValue)) {
      return false;
    }
    
    const match = cleanValue.match(regexWithCountry);
    if (!match) return false;
    
    const areaCode = match[2];
    const subscriberNumber = match[3];
    
    // Validate area code (2-4 digits)
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    // Validate subscriber number (6-8 digits)
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    
    return true;
  } else {
    // Without country code: 0[area-code][subscriber] or 0[9][area-code][subscriber]
    // Trunk prefix 0, optional mobile indicator, area code (2-4 digits, first digit 1-9), subscriber number
    const regexWithoutCountry = /^0(9)?([1-9]\d{1,3})(\d{6,8})$/;
    
    return regexWithoutCountry.test(cleanValue);
  }
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and invalid patterns like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name validation regex:
  // Allows unicode letters, accents, apostrophes, hyphens, and spaces
  // Rejects digits, symbols, and invalid patterns
  const nameRegex = /^[\p{L}]+[\p{L}\s'’-]*$/u;
  
  // Test against the regex
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for leading/trailing spaces
  if (value !== value.trim()) {
    return false;
  }
  
  // Additional validation for problematic patterns
  // Reject patterns like "X Æ A-12" that contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject multiple consecutive apostrophes or hyphens
  if (/''/.test(value) || /--/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum validation helper function
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      let doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        doubledDigit -= 9;
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for major card types with Luhn checksum.
 * Supports Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Basic length check for major card types
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check prefixes for major card types
  // Visa: 4, 13 or 16 digits
  // Mastercard: 51-55, 2221-2720, 16 digits
  // Amex: 34 or 37, 15 digits
  const visaPattern = /^4(\d{12}|\d{15})$/;
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{13})$/;
  const amexPattern = /^3[47]\d{13}$/;
  
  if (!visaPattern.test(cleanValue) && 
      !mastercardPattern.test(cleanValue) && 
      !amexPattern.test(cleanValue)) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
