#!/usr/bin/env node

import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, RenderOptions } from '../types/report.js';

function printUsage(): void {
  console.log('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.log('');
  console.log('Arguments:');
  console.log('  <data.json>          Path to JSON file with report data');
  console.log('  --format <format>   Output format: markdown or text');
  console.log('  --output <path>     Output file path (optional, defaults to stdout)');
  console.log('  --includeTotals     Include total amounts in output');
  console.log('');
  console.log('Examples:');
  console.log('  node dist/cli/report.js data.json --format markdown');
  console.log('  node dist/cli/report.js data.json --format text --includeTotals');
  console.log('  node dist/cli/report.js data.json --format markdown --output report.md');
}

interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataPath: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script name
  const argsArray = argv.slice(2);
  
  if (argsArray.length < 2) {
    throw new Error('Missing required arguments. See usage below.');
  }

  let i = 0;
  while (i < argsArray.length) {
    const arg = argsArray[i];
    
    if (!arg.startsWith('--')) {
      // First non-flag argument is the data path
      if (!args.dataPath) {
        args.dataPath = arg;
      } else {
        throw new Error(`Unexpected argument: ${arg}`);
      }
    } else if (arg === '--format') {
      if (i + 1 >= argsArray.length) {
        throw new Error('--format requires a value');
      }
      args.format = argsArray[i + 1];
      i++; // Skip the value argument
    } else if (arg === '--output') {
      if (i + 1 >= argsArray.length) {
        throw new Error('--output requires a value');
      }
      args.outputPath = argsArray[i + 1];
      i++; // Skip the value argument
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (arg === '--help' || arg === '-h') {
      printUsage();
      process.exit(0);
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
    
    i++;
  }

  // Validate required arguments
  if (!args.dataPath) {
    throw new Error('Missing data file path');
  }
  if (!args.format) {
    throw new Error('Missing --format option');
  }

  return args;
}

function validateFormat(format: string): void {
  const validFormats = ['markdown', 'text'];
  if (!validFormats.includes(format)) {
    throw new Error(`Unsupported format: ${format}. Valid formats: ${validFormats.join(', ')}`);
  }
}

function readJsonFile(path: string): ReportData {
  if (!existsSync(path)) {
    throw new Error(`File not found: ${path}`);
  }

  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid or missing "title" field in JSON data');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid or missing "summary" field in JSON data');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing "entries" field in JSON data');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${path}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      // This should never happen due to validation above
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    validateFormat(args.format);
    
    const data = readJsonFile(args.dataPath);
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };
    
    const output = renderReport(data, args.format, options);
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : error}`);
    process.exit(1);
  }
}

main();
