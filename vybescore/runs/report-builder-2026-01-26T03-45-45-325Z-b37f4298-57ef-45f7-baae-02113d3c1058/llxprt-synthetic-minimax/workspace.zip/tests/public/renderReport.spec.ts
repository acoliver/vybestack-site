import { describe, expect, it } from 'vitest';
import { renderMarkdown } from '../../src/formats/markdown.js';
import { renderText } from '../../src/formats/text.js';
import type { ReportData, RenderOptions } from '../../src/types/report.js';

describe('report formatters', () => {
  const sampleData: ReportData = {
    title: 'Quarterly Financial Summary',
    summary: 'Highlights include record revenue across regions and a healthy outlook for the next quarter.',
    entries: [
      { label: 'North Region', amount: 12345.67 },
      { label: 'South Region', amount: 23456.78 },
      { label: 'West Region', amount: 34567.89 }
    ]
  };

  describe('renderMarkdown', () => {
    it('should render markdown format without totals', () => {
      const options: RenderOptions = { includeTotals: false };
      const result = renderMarkdown(sampleData, options);
      
      expect(result).toContain('# Quarterly Financial Summary');
      expect(result).toContain('Highlights include record revenue across regions and a healthy outlook for the next quarter.');
      expect(result).toContain('## Entries');
      expect(result).toContain('- **North Region** — $12345.67');
      expect(result).toContain('- **South Region** — $23456.78');
      expect(result).toContain('- **West Region** — $34567.89');
      expect(result).not.toContain('**Total:**');
    });

    it('should render markdown format with totals', () => {
      const options: RenderOptions = { includeTotals: true };
      const result = renderMarkdown(sampleData, options);
      
      expect(result).toContain('**Total:** $70370.34');
      expect(result).toContain('# Quarterly Financial Summary');
      expect(result).toContain('## Entries');
    });
  });

  describe('renderText', () => {
    it('should render text format without totals', () => {
      const options: RenderOptions = { includeTotals: false };
      const result = renderText(sampleData, options);
      
      expect(result).toContain('Quarterly Financial Summary');
      expect(result).toContain('Highlights include record revenue across regions and a healthy outlook for the next quarter.');
      expect(result).toContain('Entries:');
      expect(result).toContain('- North Region: $12345.67');
      expect(result).toContain('- South Region: $23456.78');
      expect(result).toContain('- West Region: $34567.89');
      expect(result).not.toContain('Total:');
    });

    it('should render text format with totals', () => {
      const options: RenderOptions = { includeTotals: true };
      const result = renderText(sampleData, options);
      
      expect(result).toContain('Total: $70370.34');
      expect(result).toContain('Quarterly Financial Summary');
      expect(result).toContain('Entries:');
    });
  });
});
