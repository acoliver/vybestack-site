/**
 * Input closure implementation for reactive primitives.
 */

import type {
  InputPair,
  Subject,
  Observer,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

import { getActiveObserver, notifyObservers, trackSubject } from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<Observer<unknown>>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as dependent on this input
      s.observers.add(observer as Observer<unknown>)
      // Track this subject during dependency collection
      trackSubject(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    // Notify observers if value changed
    if (prevValue !== nextValue) {
      notifyObservers(s as Subject<unknown>)
    }
    return s.value
  }

  return [read, write]
}
