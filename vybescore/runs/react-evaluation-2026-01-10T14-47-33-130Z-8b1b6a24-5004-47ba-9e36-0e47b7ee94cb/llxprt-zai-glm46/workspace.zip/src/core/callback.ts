/**
 * Callback closure implementation for reactive side effects.
 */

import type { UnsubscribeFn, Observer, UpdateFn, Subject } from '../types/reactive.js'

import { updateObserver, beginTracking, endTracking } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Track which subjects this callback depends on
  let dependencies: Set<Subject<unknown>> | undefined
  
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Wrap updateFn to re-run callback when dependencies change
  const wrappedUpdateFn = (prevValue?: T) => {
    // Begin tracking dependencies
    beginTracking()
    try {
      // Run the update function which will register dependencies
      return updateFn(prevValue)
    } finally {
      // End tracking and store/update dependencies
      const newDeps = endTracking()
      if (newDeps) {
        dependencies = newDeps
      }
    }
  }
  
  observer.updateFn = wrappedUpdateFn
  
  // Initial execution to establish dependencies
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from all tracked subjects
    if (dependencies) {
      for (const subj of dependencies) {
        subj.observers.delete(observer as Observer<unknown>)
      }
      dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
