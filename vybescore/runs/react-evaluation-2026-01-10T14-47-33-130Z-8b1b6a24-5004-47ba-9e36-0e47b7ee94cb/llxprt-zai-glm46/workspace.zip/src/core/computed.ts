/**
 * Computed closure implementation for derived values.
 */

import type { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Options,
  Subject
} from '../types/reactive.js'

import { updateObserver, getActiveObserver, beginTracking, endTracking } from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track which subjects this computed depends on
  let dependencies: Set<Subject<unknown>> | undefined
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && dependencies) {
      // When this computed is accessed, register the active observer
      // with all of our dependencies
      for (const subj of dependencies) {
        (subj.observers as Set<Observer<unknown>>).add(observer as Observer<unknown>)
      }
    }
    return o.value!
  }
  
  // Wrap updateFn to track dependencies
  const wrappedUpdateFn = (prevValue?: T) => {
    // Begin tracking which subjects this computed depends on
    beginTracking()
    try {
      // Run the actual update function
      const result = updateFn(prevValue)
      return result
    } finally {
      // End tracking and store dependencies
      dependencies = endTracking()
    }
  }
  
  o.updateFn = wrappedUpdateFn
  
  // Compute initial value (and collect dependencies)
  updateObserver(o)
  
  return getter
}
