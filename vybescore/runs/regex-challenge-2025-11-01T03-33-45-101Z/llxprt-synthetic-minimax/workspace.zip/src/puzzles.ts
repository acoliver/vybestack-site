/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to match words starting with prefix
  // Word boundaries to ensure we match whole words
  const regex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(regex);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => {
    return !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex to find token after a digit
  // Use lookbehind to check it's after a digit
  // We need to escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  throw new Error('TODO: implement findEmbeddedToken');
}');
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(regex);
  return matches ? matches : [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 1212)
  // This checks for any 4-character sequence that repeats immediately
  // For example, abab would match the pattern (ab)\1, but we need to be more general
  // Check for patterns like abab, 1212, xyxy, etc.
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's a basic IPv4 address (which we want to exclude)
  // IPv4 pattern: 4 sets of 1-3 digits separated by dots
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  
  // Check if the entire string is IPv4 (with optional leading/trailing text)
  // We'll search for IPv4 patterns and skip them
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns to match:
  // 1. Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6 = /^(?:[a-f0-9]{1,4}:){7}[a-f0-9]{1,4}$/i;
  
  // 2. IPv6 with :: shorthand (one or more groups of zeros compressed)
  // This is more complex - we need to match patterns with ::
  // Match: start::end where start and end can be empty or hex groups
  const shorthandIPv6 = /^((?:[a-f0-9]{1,4}:)*)(::)((?:[a-f0-9]{1,4}:)*[a-f0-9]{1,4})?$/i;
  
  // 3. Mixed IPv6-IPv4 format (like ::ffff:192.168.1.1)
  const mixedIPv6 = /^(?:[a-f0-9]{1,4}:)+::ffff:(?:\d{1,3}\.){3}\d{1,3}$/i;
  
  // 4. IPv6 with IPv4 at the end (like 2001:db8::192.168.1.1)
  const ipv6WithIPv4 = /^(?:[a-f0-9]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}$/i;
  
  // Check for IPv6 patterns (case insensitive)
  const trimmedValue = value.trim();
  
  if (fullIPv6.test(trimmedValue) || 
      shorthandIPv6.test(trimmedValue) || 
      mixedIPv6.test(trimmedValue) || 
      ipv6WithIPv4.test(trimmedValue)) {
    return true;
  }
  
  return false;
}
