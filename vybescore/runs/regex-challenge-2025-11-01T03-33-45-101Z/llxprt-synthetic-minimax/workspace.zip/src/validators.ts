export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum validation
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return (sum % 10) === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex pattern
  // Allow unicode letters, digits, dots, underscores, plus and hyphens in local part
  // Domain should not have underscores
  // No double dots or trailing dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick length check
  if (value.length > 254) return false;
  
  // Check for obvious issues
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.trim();
  
  // Must start with optional +1
  const usPhoneRegex = /^\+?1?[-.\s()]?\d{3}[-.\s()]?\d{3}[-.\s()]?\d{4}$/;
  
  if (!usPhoneRegex.test(cleanValue)) {
    return false;
  }
  
  // Extract digits for validation
  const digits = cleanValue.replace(/\D/g, '');
  
  // Too short
  if (digits.length < 10) return false;
  
  // Extract area code (first 3 digits)
  let areaCodeStart = 0;
  if (digits.startsWith('1')) {
    areaCodeStart = 1;
  }
  
  const areaCode = digits.substring(areaCodeStart, areaCodeStart + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit, non-space, non-hyphen, non-plus characters
  const cleanValue = value.trim();
  
  // Pattern breakdown:
  // ^\+?54?         - optional +54 country code
  // \s?             - optional space
  // 9?              - optional mobile indicator 9 (after country code)
  // \s?             - optional space  
  // 0?              - optional trunk prefix 0 (before area code)
  // (\d{2,4})       - area code (2-4 digits, first digit 1-9)
  // \s?             - optional space
  // (\d{6,8})$      - subscriber number (6-8 digits total)
  const pattern = /^\+?54?\s?9?\s?0?(\d{2,4})\s?(\d{6,8})$/;
  
  const match = cleanValue.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // When country code is omitted, must begin with trunk prefix 0
  const hasCountryCode = cleanValue.startsWith('+54');
  if (!hasCountryCode && !cleanValue.startsWith('0')) {
    return false;
  }
  
  // Area code must start with 1-9 (already ensured by \d{2,4})
  const areaCodeNum = parseInt(areaCode, 10);
  const firstDigit = parseInt(areaCode.charAt(0), 10);
  
  // Sanity checks
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  if (firstDigit < 1 || firstDigit > 9) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must have at least 2 characters
  if (value.length < 2) return false;
  
  // Allow unicode letters (including accents), apostrophes, hyphens, and spaces
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  // First and last character must be letters
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for special characters that aren't allowed
  // Allow: letters, spaces, apostrophes, hyphens
  const invalidChars = /[0-9!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?~`]/;
  if (invalidChars.test(value)) {
    return false;
  }
  
  // Reject X Æ A-12 style names (contains Æ or numbers)
  if (/Æ/.test(value) || /\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must have between 13 and 19 digits
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check card type prefixes
  // Visa: starts with 4, length 13, 16, or 19
  const isVisa = digits.startsWith('4') && [13, 16, 19].includes(digits.length);
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPrefix = parseInt(digits.substring(0, 2), 10);
  const mastercard4Prefix = parseInt(digits.substring(0, 4), 10);
  const isMastercard = 
    (mastercardPrefix >= 51 && mastercardPrefix <= 55) ||
    (mastercard4Prefix >= 2221 && mastercard4Prefix <= 2720);
  
  // AmEx: starts with 34 or 37, length 15
  const amexPrefix = parseInt(digits.substring(0, 2), 10);
  const isAmEx = (amexPrefix === 34 || amexPrefix === 37) && digits.length === 15;
  
  // Must match at least one card type
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
