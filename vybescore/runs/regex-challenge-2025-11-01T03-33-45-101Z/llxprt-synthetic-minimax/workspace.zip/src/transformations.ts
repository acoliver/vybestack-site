/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Match sentence endings (.?!), then whitespace, then capitalize next letter
  let result = text;
  
  // First, collapse multiple spaces but preserve sentence boundaries
  result = result.replace(/\s+/g, ' ');
  
  // Capitalize first character
  result = result.replace(/^([a-z])/, (match) => match.toUpperCase());
  
  // Capitalize first letter after sentence endings (.?!)
  result = result.replace(/([.!?])([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match HTTP/HTTPS URLs
  const urlRegex = /https?:\/\/[^\s<>"']+/gi;
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from URLs
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?;:]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Use word boundary to avoid matching inside words
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^\/\s]+)(\/[^\s]*)?/gi, (match, host, path = '') => {
    // Check if path contains dynamic hints
    const dynamicHints = /(cgi-bin|\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    
    if (path.startsWith('/docs/') && !dynamicHints.test(path)) {
      // Path starts with /docs and no dynamic hints, rewrite to docs subdomain
      return `https://docs.${host}${path}`;
    } else {
      // Either no /docs prefix or has dynamic hints, just upgrade to https
      return `https://${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate year (reasonable range, e.g., 1900-2100)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return year.toString();
}
