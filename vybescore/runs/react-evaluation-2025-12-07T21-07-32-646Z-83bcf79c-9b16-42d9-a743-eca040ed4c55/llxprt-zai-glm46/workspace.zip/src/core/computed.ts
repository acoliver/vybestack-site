/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  Options,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | ((a: T, b: T) => boolean),
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set()
  }
  
  let dirty = true
  
  const compute = () => {
    const previous = getActiveObserver()
    setActiveObserver(o)
    try {
      o.value = updateFn(o.value)
      dirty = false
    } finally {
      setActiveObserver(previous)
    }
  }
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      // Track this as a dependent observer
      if (o.dependencies && !o.dependencies.has(observer)) {
        o.dependencies.add(observer)
      }
    }
    
    if (dirty) {
      compute()
    }
    
    return o.value!
  }
  
  // Monkey-patch the observer to add notification capabilities
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  ;(o as any).notify = () => {
    dirty = true
    if (o.dependencies) {
      const deps = Array.from(o.dependencies)
      for (const dep of deps) {
        // eslint-disable-next-line @typescript-eslint/no-explicit-any
        updateObserver(dep as any)
      }
    }
  }
  
  return getter
}