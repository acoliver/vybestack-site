/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Options } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(
  updateFn: UpdateFn<T>, 
  value?: T,
  options?: Options
): UnsubscribeFn {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set()
  }
  
  // Execute the callback immediately to establish dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    observer.value = undefined
    observer.updateFn = () => value!
    observer.dependencies = undefined
  }
}