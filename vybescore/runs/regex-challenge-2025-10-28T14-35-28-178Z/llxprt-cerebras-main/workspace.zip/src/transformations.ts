/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences even if the input omitted it.
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Split text into sentences based on ., !, or ? followed by whitespace or end of string
  const sentences = text.split(/([.!?]+)(\s|$)/);
  
  // Process sentences to capitalize first letters
  const result: string[] = [];
  let shouldCapitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    if (shouldCapitalizeNext && sentence.trim()) {
      // Capitalize the first non-whitespace character
      const trimmed = sentence.trimStart();
      const firstCharIndex = sentence.length - trimmed.length;
      const firstChar = trimmed[0].toUpperCase();
      
      result.push(sentence.substring(0, firstCharIndex) + firstChar + trimmed.substring(1));
      shouldCapitalizeNext = false;
    } else {
      result.push(sentence);
    }
    
    // Set flag to capitalize next sentence if this part contains a sentence ending
    if (/[.!?]+$/.test(sentence)) {
      shouldCapitalizeNext = true;
    }
  }
  
  // Join everything and normalize spacing between sentences
  return result.join('').replace(/([.!?]+)(\s*)/g, (match, p1) => p1 + ' ');
}

/**
 * Extracts URLs from text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // This regex pattern matches URLs with http/https schemes
  // It tries to exclude trailing punctuation like .,!,?
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => url.replace(/[.!?]+$/, ''));
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://, but don't touch URLs that are already https
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Skips host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace all http:// with https:// first
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match URLs with docs path that don't contain dynamic elements
  const docsUrlRegex = /https?:\/\/([a-zA-Z0-9.-]+)\/docs\/(?:[^?&=\s]*\.(?:jsp|php|asp|aspx|do|cgi|pl|py))?([^?&=\s]*)/g;
  
  // Replace matching URLs with docs.example.com host
  result = result.replace(docsUrlRegex, (match, host) => {
    // If it has legacy extensions or query parameters, don't rewrite the host
    if (/[?&=]/.test(match) || /\.(?:jsp|php|asp|aspx|do|cgi|pl|py)/.test(match)) {
      return match;
    }
    
    // Rewrite host to docs.example.com
    return match.replace(host, 'docs.' + host);
  });
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) return 'N/A';
  
  return year;
}