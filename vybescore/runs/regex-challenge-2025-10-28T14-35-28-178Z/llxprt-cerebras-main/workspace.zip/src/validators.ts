// Helper function to run Luhn algorithm check
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for basic email structure
  if (!value || typeof value !== 'string') return false;
  
  // Pattern explanation:
  // - Local part (before @): Allow alphanumeric, dots, hyphens, underscores, and plus signs
  //   but disallow consecutive dots and dots at start/end
  // - Domain part (after @): Allow alphanumeric, hyphens, and dots but disallow underscores
  //   and consecutive dots
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check if the email matches basic pattern
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for edge cases
  // Reject double dots
  if (value.includes('..')) return false;
  
  // Reject local part starting or ending with dot
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject domains with underscores
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all non-digit characters except + at the beginning
  let cleanValue = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.substring(2);
  } else if (cleanValue.startsWith('+')) {
    // If there's a + but not +1, it's not a valid US phone number
    return false;
  }
  
  // Check if we have exactly 10 digits left
  if (cleanValue.length !== 10) return false;
  
  // Check that area code doesn't start with 0 or 1
  if (cleanValue[0] === '0' || cleanValue[0] === '1') return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all whitespace and hyphens for easier processing
  let cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for country code +54
  let hasCountryCode = false;
  if (cleanValue.startsWith('+54')) {
    hasCountryCode = true;
    cleanValue = cleanValue.substring(3);
  }
  
  // Check for trunk prefix 0
  let hasTrunkPrefix = false;
  if (cleanValue.startsWith('0')) {
    hasTrunkPrefix = true;
    cleanValue = cleanValue.substring(1);
  }
  
  // If neither country code nor trunk prefix, it's invalid
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator 9
  if (cleanValue.startsWith('9')) {
    cleanValue = cleanValue.substring(1);
  }
  
  // Extract area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = cleanValue.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  cleanValue = cleanValue.substring(areaCode.length);
  
  // Check subscriber number (6-8 digits)
  if (cleanValue.length < 6 || cleanValue.length > 8 || !/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Check for empty string
  if (value.trim() === '') return false;
  
  // Pattern that allows:
  // - Unicode letters (including accented characters)
  // - Spaces
  // - Hyphens
  // - Apostrophes
  // But rejects digits and other symbols
  const nameRegex = /^[\p{L}\s\-']+$/u;
  
  // Additional check to ensure it doesn't contain digits or symbols
  const hasDigitsOrSymbols = /[0-9\-!@#$%^&*()_+=\[\]{}|\\:";?/<>]/;
  
  return nameRegex.test(value) && !hasDigitsOrSymbols.test(value);
}

/**
 * Validates credit card numbers using prefix, length checks and Luhn algorithm.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if it only contains digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Define card type patterns (prefix and length)
  const visaPattern = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardPattern = /^5[1-5]\d{14}$|^2[2-7]\d{14}$/; // 16 digits, starts with 51-55 or 22-27
  const amexPattern = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if it matches any card type pattern
  if (!(visaPattern.test(cleanValue) || mastercardPattern.test(cleanValue) || amexPattern.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleanValue);
}