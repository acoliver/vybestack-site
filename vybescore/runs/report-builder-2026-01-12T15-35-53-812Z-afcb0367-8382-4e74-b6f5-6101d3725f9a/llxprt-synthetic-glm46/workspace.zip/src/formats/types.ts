import type { ReportData, RenderOptions } from '../types.js';

export interface ReportFormatter {
  (data: ReportData, options: RenderOptions): string;
}