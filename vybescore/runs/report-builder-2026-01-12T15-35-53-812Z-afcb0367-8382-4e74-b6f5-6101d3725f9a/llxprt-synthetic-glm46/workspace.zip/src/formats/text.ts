import type { ReportData, RenderOptions } from '../types.js';
import type { ReportFormatter } from './types.js';

export const renderText: ReportFormatter = (data: ReportData, options: RenderOptions): string => {
  const { title, summary, entries } = data;
  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);

  let result = `${title}\n${summary}\nEntries:\n`;

  // Add entries as bullet list
  for (const entry of entries) {
    result += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }

  // Add total if requested
  if (options.includeTotals) {
    result += `Total: $${total.toFixed(2)}`;
  }

  return result;
};