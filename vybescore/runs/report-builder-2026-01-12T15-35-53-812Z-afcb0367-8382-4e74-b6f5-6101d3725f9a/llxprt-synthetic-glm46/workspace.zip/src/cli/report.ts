#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';

import type { ReportData, CLIOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments using Node's parseArgs utility
function parseCliArgs(): CLIOptions {

  const args = process.argv.slice(2);
  const positionals = args.filter(arg => !arg.startsWith('-'));
  
  const dataPath = positionals[0];
  if (!dataPath) {
    console.error('Error: Missing required argument <data.json>');
    process.exit(1);
  }

  let format: string | undefined;
  let output: string | undefined;
  let includeTotals = false;

  // Parse flags manually since parseArgs doesn't support NodeNext well in this context
  for (let i = 1; i < process.argv.length; i++) {
    const arg = process.argv[i];
    if (arg === '--format' || arg === '-f') {
      format = process.argv[++i];
    } else if (arg.startsWith('--format=')) {
      format = arg.substring(9);
    } else if (arg === '--output' || arg === '-o') {
      output = process.argv[++i];
    } else if (arg.startsWith('--output=')) {
      output = arg.substring(9);
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  // Validate format
  const supportedFormats: FormatType[] = ['markdown', 'text'];
  if (!supportedFormats.includes(format as FormatType)) {
    console.error(`Error: Unsupported format '${format}'. Supported formats: markdown, text`);
    process.exit(1);
  }

  return {
    dataPath,
    format: format as FormatType,
    output,
    includeTotals
  };
}

// Validate and parse report data from JSON file
async function loadReportData(dataPath: string): Promise<ReportData> {
  try {
    const jsonData = await readFile(dataPath, 'utf8');
    const data = JSON.parse(jsonData) as ReportData;
    
    // Basic validation
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    // Validate each entry
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid data: each entry must have a label');
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error('Invalid data: each entry must have a numeric amount');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in ${dataPath}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    throw error;
  }
}

// Main application logic
async function main(): Promise<void> {
  try {
    const options = parseCliArgs();
    const data = await loadReportData(options.dataPath);
    
    // Select the appropriate formatter
    const formatters = {
      markdown: renderMarkdown,
      text: renderText
    };
    
    const render = formatters[options.format];
    const report = render(data, { includeTotals: options.includeTotals || false });
    
    // Output the report
    if (options.output) {
      await writeFile(options.output, report, 'utf8');
    } else {
      console.log(report);
    }
  } catch (error) {
    process.exit(1);
  }
}

// Start the application
main();
