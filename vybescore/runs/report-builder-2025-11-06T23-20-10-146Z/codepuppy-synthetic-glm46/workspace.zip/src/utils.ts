import type { ReportData } from './types.js';
import fs from 'node:fs';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: Missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: Missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries as unknown[];
  for (let i = 0; i < entries.length; i++) {
    const entry = entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: Entry ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: Entry ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number' || !Number.isFinite(entryObj.amount)) {
      throw new Error(`Invalid report data: Entry ${i}_missing or invalid "amount" field (expected number)`);
    }
  }

  return obj as unknown as ReportData;
}

export function parseJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw new Error(`Error reading file ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

export function writeFileContent(filePath: string, content: string): void {
  try {
    fs.writeFileSync(filePath, content, 'utf-8');
  } catch (error) {
    throw new Error(`Error writing to ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
  }
}