import type { ReportFormat, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

export const formatters: Record<ReportFormat, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

export function getFormatter(format: string): ReportRenderer {
  const formatter = formatters[format as ReportFormat];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

export function getSupportedFormats(): ReportFormat[] {
  return Object.keys(formatters) as ReportFormat[];
}