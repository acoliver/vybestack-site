#!/usr/bin/env node

import { parseArgs } from './args.js';
import { validateReportData, parseJsonFile, writeFileContent } from '../utils.js';
import { getFormatter } from '../formatters/index.js';
import type { RenderOptions } from '../types.js';

function main(): void {
  try {
    const args = parseArgs();

    // Parse and validate the JSON data
    const rawData = parseJsonFile(args.dataFile);
    const reportData = validateReportData(rawData);

    // Get the appropriate formatter
    const formatter = getFormatter(args.format);

    // Prepare render options
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    // Render the report
    const output = formatter(reportData, options);

    // Write output
    if (args.output) {
      writeFileContent(args.output, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}