export interface CliArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

export function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    throw new Error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const result: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  let i = 0;
  
  // First positional argument: data file
  if (args[i] && !args[i].startsWith('--')) {
    result.dataFile = args[i];
    i++;
  } else {
    throw new Error('Missing required argument: <data.json>');
  }

  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length || !args[i] || args[i].startsWith('--')) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length || !args[i] || args[i].startsWith('--')) {
        throw new Error('--output requires a value');
      }
      result.output = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
    
    i++;
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}