/**
 * Represents a single entry in the report.
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * The full report data structure from JSON input.
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering a report.
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Interface that all formatters must implement.
 */
export interface Formatter {
  render(data: ReportData, options: RenderOptions): string;
}
