#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import type { ReportData } from '../types.js';
import { getFormatter } from '../formatters.js';

/**
 * Parsed CLI arguments.
 */
interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments.
 * Supports: <data.json> --format <format> [--output <path>] [--includeTotals]
 */
function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    switch (arg) {
      case '--format':
        i++;
        if (i >= args.length) {
          throw new Error('--format requires a value');
        }
        result.format = args[i];
        break;

      case '--output':
        i++;
        if (i >= args.length) {
          throw new Error('--output requires a value');
        }
        result.outputPath = args[i];
        break;

      case '--includeTotals':
        result.includeTotals = true;
        break;

      default:
        // Positional argument (input file)
        if (arg.startsWith('--')) {
          throw new Error(`Unknown option: ${arg}`);
        }
        if (result.inputFile) {
          throw new Error(`Multiple input files specified: ${result.inputFile} and ${arg}`);
        }
        result.inputFile = arg;
        break;
    }

    i++;
  }

  if (!result.inputFile) {
    throw new Error('Input file path is required');
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}

/**
 * Validates and parses the JSON report data.
 */
function parseReportData(jsonContent: string): ReportData {
  let data: unknown;

  try {
    data = JSON.parse(jsonContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }

  // Validate structure
  if (typeof data !== 'object' || data === null) {
    throw new Error('Expected a JSON object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Entry at index ${i} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Entry at index ${i} missing or invalid "amount" field (expected number)`);
    }
  }

  return data as ReportData;
}

/**
 * Main CLI entry point.
 */
function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read input file
    let jsonContent: string;
    try {
      jsonContent = readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`Input file not found: ${args.inputFile}`);
      }
      throw error;
    }

    // Parse and validate data
    const data = parseReportData(jsonContent);

    // Get formatter and render
    const formatter = getFormatter(args.format);
    const output = formatter.render(data, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      writeFile(args.outputPath, output, 'utf-8')
        .then(() => {
          process.exit(0);
        })
        .catch((error) => {
          console.error(`Error writing to file: ${error.message}`);
          process.exit(1);
        });
    } else {
      console.log(output);
      process.exit(0);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
