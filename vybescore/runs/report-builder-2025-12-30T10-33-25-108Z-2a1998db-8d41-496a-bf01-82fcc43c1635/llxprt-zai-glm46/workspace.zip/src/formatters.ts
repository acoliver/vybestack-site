import type { Formatter } from './types.js';
import { renderMarkdown } from './formats/markdown.js';
import { renderText } from './formats/text.js';

/**
 * Registry of available formatters by format name.
 */
export const FORMATTERS: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Returns a formatter for the given format name.
 * @throws {Error} if the format is not supported
 */
export function getFormatter(format: string): Formatter {
  const formatter = FORMATTERS[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

/**
 * Lists all supported format names.
 */
export function getSupportedFormats(): string[] {
  return Object.keys(FORMATTERS);
}
