import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

// Import the server module - app will be initialized without starting the server
import { app, initDbForTesting } from '../../src/server.js';
import { Express } from 'express';

beforeAll(async () => {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Initialize the database for testing
  await initDbForTesting();
});

afterAll(() => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that all required form fields exist
    const expectedFields = [
      { id: 'firstName', name: 'firstName' },
      { id: 'lastName', name: 'lastName' },
      { id: 'streetAddress', name: 'streetAddress' },
      { id: 'city', name: 'city' },
      { id: 'stateProvince', name: 'stateProvince' },
      { id: 'postalCode', name: 'postalCode' },
      { id: 'country', name: 'country' },
      { id: 'email', name: 'email' },
      { id: 'phone', name: 'phone' }
    ];
    
    expectedFields.forEach(({ id, name }) => {
      expect($(`#${id}`)).toHaveLength(1);
      const input = $(`#${id}`);
      expect(input.attr('name')).toBe(name);
      
      // Check that labels are correctly associated
      const label = $(`label[for="${id}"]`);
      expect(label).toHaveLength(1);
    });
    
    // Check that form action is correct
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    // Ensure DB doesn't exist before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit valid form data
    const validFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(validFormData);
    
    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toMatch(/^\/thank-you\?firstName=/);
    
    // Verify database was created and contains the submission
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Load and check the database
    const SQL = await initSqlJs();
    const dbFile = fs.readFileSync(dbPath);
    const db = new SQL.Database(dbFile);
    
    const result = db.exec('SELECT * FROM submissions');
    expect(result).toHaveLength(1);
    expect(result[0].values).toHaveLength(1);
    
    const submittedData = result[0].values[0];
    // SQLite columns: id, first_name, last_name, street_address, city, 
    // state_province, postal_code, country, email, phone, created_at
    
    expect(submittedData[1]).toBe(validFormData.firstName); // first_name
    expect(submittedData[2]).toBe(validFormData.lastName); // last_name
    expect(submittedData[3]).toBe(validFormData.streetAddress); // street_address
    expect(submittedData[4]).toBe(validFormData.city); // city
    expect(submittedData[5]).toBe(validFormData.stateProvince); // state_province
    expect(submittedData[6]).toBe(validFormData.postalCode); // postal_code
    expect(submittedData[7]).toBe(validFormData.country); // country
    expect(submittedData[8]).toBe(validFormData.email); // email
    expect(submittedData[9]).toBe(validFormData.phone); // phone
    
    db.close();
  });
  
  it('displays thank-you page with first name', async () => {
    const response = await request(app).get('/thank-you?firstName=Alice');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that the thank-you page contains a greeting with the first name
    expect($('body').text()).toContain('Thank you, Alice!');
    
    // Check that it has a link back to the form
    expect($('a[href="/"]')).toHaveLength(1);
    expect($('a[href="/"]').text()).toContain('Return to the form');
  });
});
