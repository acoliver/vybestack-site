import express, { Express, Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import sql.js for WASM SQLite
import initSqlJs from 'sql.js';
/// <reference path="./sqljs.d.ts" />

// Types for our form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

// Initialize app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Database setup
let db: import('sql.js').Database;
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load sql.js
    const SQL = await initSqlJs();
    
    // Load or create database
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer.buffer);
    } else {
      db = new SQL.Database();
      // Create tables using schema
      const schemaSql = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      db.run(schemaSql);
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: FormData): ValidationResult {
  const errors: string[] = [];
  
  // Check required fields
  if (!formData.firstName.trim()) errors.push('First name is required');
  if (!formData.lastName.trim()) errors.push('Last name is required');
  if (!formData.streetAddress.trim()) errors.push('Street address is required');
  if (!formData.city.trim()) errors.push('City is required');
  if (!formData.stateProvince.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode.trim()) errors.push('Postal/Zip code is required');
  if (!formData.country.trim()) errors.push('Country is required');
  if (!formData.email.trim()) errors.push('Email is required');
  if (!formData.phone.trim()) errors.push('Phone number is required');
  
  // Validate specific formats
  if (formData.email.trim() && !validateEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  
  if (formData.phone.trim() && !validatePhone(formData.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes and a leading +');
  }
  
  if (formData.postalCode.trim() && !validatePostalCode(formData.postalCode)) {
    errors.push('Postal/Zip code can only contain letters, numbers and spaces');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  // Insert into database
  try {
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (
        ?, ?, ?, ?, ?, ?, ?, ?, ?
      )`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    // Save database changes
    saveDatabase();
    
    // Store first name in session or redirect with query param
    // Since we're not using sessions, we'll use a query parameter
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'there';
  res.render('thank-you', { firstName });
});

// Static assets
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Start server
let server: ReturnType<typeof app.listen>;
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle graceful shutdown
    const gracefulShutdown = () => {
      console.log('Received SIGTERM, shutting down gracefully');
      if (server) {
        server.close(() => {
          console.log('Closed express server');
          if (db) {
            db.close();
            console.log('Closed database connection');
          }
          process.exit(0);
        });
      }
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Initialize database for testing
async function initDbForTesting(): Promise<void> {
  if (!db) {
    await initializeDatabase();
  }
}

// For testing purposes - allow importing the app without starting the server
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, server, startServer, initDbForTesting };
