declare module 'sql.js' {
  export interface Database {
    exec(sql: string): unknown[];
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }

  export function initSqlJs(options?: Record<string, unknown>): Promise<{ Database: new (data?: ArrayBuffer) => Database }>;
  
  export default initSqlJs;
}