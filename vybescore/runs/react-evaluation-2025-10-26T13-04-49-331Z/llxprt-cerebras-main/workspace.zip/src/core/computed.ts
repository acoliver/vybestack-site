/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Normalize equal function to either undefined or a proper comparison function
  const equalFn = equal === true || equal === undefined ? undefined :
    equal === false ? () => false :
    equal as EqualFn<T>;

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Create a getter function that manages dependencies
  const getter: GetterFn<T> = () => {
    // Temporarily set this observer as active
    const previousObserver = (globalThis as { activeObserver?: Observer<unknown> }).activeObserver;
    (globalThis as { activeObserver?: Observer<unknown> }).activeObserver = o as Observer<unknown>;
    
    try {
      // Call updateFn with the current value (or undefined)
      // It's the updateFn's responsibility to handle undefined values appropriately
      const newValue = o.updateFn(o.value);
      
      // Check if value actually changed before updating
      if (o.value === undefined) {
        o.value = newValue;
      } else {
        const isEqual = equalFn ? equalFn(o.value as T, newValue) : o.value === newValue;
        if (!isEqual) {
          o.value = newValue;
        }
      }
      
      return o.value as T;
    } finally {
      // Restore previous active observer
      (globalThis as { activeObserver?: Observer<unknown> }).activeObserver = previousObserver;
    }
  };
  
  // Initialize the computed value
  getter();
  
  return getter;
}