import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../dist/server.js';

let server: Awaited<ReturnType<typeof startServer>>['server'];
let app: Awaited<ReturnType<typeof startServer>>['app'];
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  const result = await startServer(0); // Use port 0 to get random available port
  server = result.server;
  app = result.app;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');

    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);

    const $ = cheerio.load(response.text);
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('label[for="firstName"]').text()).toBe('First name');
    expect($('#firstName').length).toBe(1);
    expect($('#firstName').attr('name')).toBe('firstName');
    expect($('label[for="lastName"]').text()).toBe('Last name');
    expect($('#lastName').length).toBe(1);
    expect($('label[for="email"]').text()).toBe('Email');
    expect($('#email').length).toBe(1);
    expect($('label[for="phone"]').text()).toBe('Phone number');
    expect($('#phone').length).toBe(1);
  });

  it('shows validation errors for empty fields', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
  });

  it('shows validation error for invalid email', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'not-an-email',
      phone: '+44 20 7946 0958',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/email/i);
  });

  it('shows validation error for invalid phone', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john@example.com',
      phone: 'invalid-phone!',
    });

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/phone/i);
  });

  it('persists submission and redirects on valid input', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 High Street',
      city: 'Manchester',
      stateProvince: 'North West England',
      postalCode: 'M1 4BT',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 161 234 5678',
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');

    expect(response.status).toBe(200);
    expect(response.text).toMatch(/Thank you/i);
    expect(response.text).toMatch(/stranger on the internet/i);
  });

  it('accepts international phone formats', async () => {
    const formData = {
      firstName: 'Carlos',
      lastName: 'García',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts international postal codes', async () => {
    const formData = {
      firstName: 'Pierre',
      lastName: 'Dupont',
      streetAddress: '123 Rue de Paris',
      city: 'Paris',
      stateProvince: 'Île-de-France',
      postalCode: '75001',
      country: 'France',
      email: 'pierre@example.com',
      phone: '+33 1 23 45 67 89',
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
