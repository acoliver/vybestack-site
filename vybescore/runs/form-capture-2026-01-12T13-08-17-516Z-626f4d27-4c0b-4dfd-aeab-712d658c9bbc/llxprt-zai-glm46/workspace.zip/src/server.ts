import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import { readFile, mkdir, writeFile } from 'node:fs/promises';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface SubmissionBody extends FormValues {}

let db: Database | null = null;
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '../public')));

app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, '../src/templates'));

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    let dbData: Uint8Array | null = null;

    try {
      const fileBuffer = await readFile(DB_PATH);
      dbData = new Uint8Array(fileBuffer);
    } catch {
      // File doesn't exist yet, will create new database
    }

    db = new SQL.Database(dbData ?? undefined);

    // Initialize schema
    const schema = await readFile(SCHEMA_PATH, 'utf-8');
    db.run(schema);
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;
  try {
    const data = db.export();
    const buffer = Buffer.from(data);
    await mkdir(path.dirname(DB_PATH), { recursive: true });
    await writeFile(DB_PATH, buffer);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

function validateForm(body: SubmissionBody): { valid: boolean; errors: string[] } {
  const errors: string[] = [];

  if (!body.firstName?.trim()) errors.push('First name is required');
  if (!body.lastName?.trim()) errors.push('Last name is required');
  if (!body.streetAddress?.trim()) errors.push('Street address is required');
  if (!body.city?.trim()) errors.push('City is required');
  if (!body.stateProvince?.trim()) errors.push('State / Province / Region is required');
  if (!body.postalCode?.trim()) errors.push('Postal / Zip code is required');
  if (!body.country?.trim()) errors.push('Country is required');

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!body.email?.trim()) {
    errors.push('Email is required');
  } else if (!emailRegex.test(body.email.trim())) {
    errors.push('Email must be a valid email address');
  }

  // Phone validation - allow international formats
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!body.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!phoneRegex.test(body.phone.trim())) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return { valid: errors.length === 0, errors };
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: null, values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const body = req.body as SubmissionBody;
  const { valid, errors } = validateForm(body);

  if (!valid) {
    return res.status(400).render('form', { errors, values: body });
  }

  if (!db) {
    return res.status(500).render('form', {
      errors: ['Database error. Please try again.'],
      values: body,
    });
  }

  try {
    db.run(
      `INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        (body.firstName ?? '').trim(),
        (body.lastName ?? '').trim(),
        (body.streetAddress ?? '').trim(),
        (body.city ?? '').trim(),
        (body.stateProvince ?? '').trim(),
        (body.postalCode ?? '').trim(),
        (body.country ?? '').trim(),
        (body.email ?? '').trim(),
        (body.phone ?? '').trim(),
      ]
    );

    await saveDatabase();
  } catch (error) {
    console.error('Database insert error:', error);
    return res.status(500).render('form', {
      errors: ['Failed to save your submission. Please try again.'],
      values: body,
    });
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { firstName: 'Friend' });
});

export async function startServer(port: number = 3535): Promise<{
  server: ReturnType<typeof app.listen>;
  app: typeof app;
}> {
  await initializeDatabase();

  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Handle graceful shutdown
  const shutdown = async (signal: string): Promise<void> => {
    console.log(`Received ${signal}, shutting down gracefully...`);
    server.close(() => {
      console.log('HTTP server closed');
    });

    if (db) {
      db.close();
      db = null;
      console.log('Database connection closed');
    }

    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));

  return { server, app };
}

const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer(port).catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}
