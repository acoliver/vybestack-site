#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, ReportOptions, FormatType } from '../types.js';

// Map format names to renderers
const formatters = {
  markdown: renderMarkdown,
  text: renderText
};

// Parse command line arguments
function parseArgs(processArgs: string[]): { 
  dataPath: string; 
  format: FormatType; 
  outputPath?: string; 
  includeTotals: boolean;
} {
  const [, , dataPath, ...rest] = processArgs;
  
  if (!dataPath) {
    console.error('Error: Missing data file path');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  // Find --format argument
  const formatIndex = rest.indexOf('--format');
  if (formatIndex === -1 || formatIndex === rest.length - 1) {
    console.error('Error: Missing --format argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const formatValue = rest[formatIndex + 1] as FormatType;
  if (!formatters[formatValue as FormatType]) {
    console.error(`Error: Unsupported format "${formatValue}"`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }
  
  // Find --output argument if present
  const outputIndex = rest.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex !== rest.length - 1 
    ? rest[outputIndex + 1] 
    : undefined;
  
  // Check for --includeTotals flag
  const includeTotals = rest.includes('--includeTotals');
  
  return {
    dataPath,
    format: formatValue,
    outputPath,
    includeTotals
  };
}

// Validate report data structure
function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: data must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  const entries = obj.entries as unknown[];
  for (const entry of entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: each entry must have a string label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: each entry must have a number amount');
    }
  }
  
  return data as ReportData;
}

// Main function
async function main(): Promise<void> {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs(process.argv);
    
    // Read and parse JSON data
    const fileContent = await readFile(dataPath, 'utf-8');
    let data: unknown;
    
    try {
      data = JSON.parse(fileContent);
    } catch (parseError) {
      console.error(`Error: Invalid JSON in file "${dataPath}"`);
      console.error('Please check that the file contains valid JSON');
      process.exit(1);
    }
    
    // Validate data structure
    const reportData = validateReportData(data);
    
    // Render report
    const options: ReportOptions = { includeTotals };
    const formatter = formatters[format];
    const output = formatter.render(reportData, options);
    
    // Output result
    if (outputPath) {
      await writeFile(outputPath, output, 'utf-8');
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

// Run main function
main();
