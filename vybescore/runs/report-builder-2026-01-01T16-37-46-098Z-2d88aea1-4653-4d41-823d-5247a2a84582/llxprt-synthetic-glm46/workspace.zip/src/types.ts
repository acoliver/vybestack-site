export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportOptions {
  includeTotals?: boolean;
  output?: string;
}

export type FormatType = 'markdown' | 'text';

export interface Formatter {
  format: FormatType;
  render(data: ReportData, options?: ReportOptions): string;
}