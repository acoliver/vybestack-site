export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Robust email validation using regex.
 * Accepts standard formats but rejects double dots, trailing dots, 
 * domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9](?!.*\.\.)[a-zA-Z0-9._%+*-]{0,63}[a-zA-Z0-9]@[a-zA-Z](?!.*--)[a-zA-Z0-9-]{0,63}[a-zA-Z]\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Domain cannot contain underscores
  const [local, domain] = value.split('@');
  if (domain.includes('_')) {
    return false;
  }
  
  // Cannot have consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * US phone number validation with common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all whitespace for cleaner validation
  const cleanValue = value.replace(/\s+/g, '');
  
  // Regex for US phone numbers
  const phoneRegex = /^(?:\+1)?[2-9]\d{2}[2-9]\d{2}\d{4}$/;
  const phoneWithSeparatorsRegex = /^(?:\+1)?[\s-]*\(?[2-9]\d{2}\)?[\s-]*[2-9]\d{2}[\s-]*\d{4}$/;
  
  // Test both formats
  if (!phoneRegex.test(cleanValue) && !phoneWithSeparatorsRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Argentine phone number validation with mobile/landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex patterns
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?[1-9]\d{1,3}\d{6,8}$/;
  
  // More specific regex with optional mobile indicator 9
  const argentinePhoneWithMobileRegex = /^(?:\+54)?(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  
  return argentinePhoneRegex.test(cleanValue) || argentinePhoneWithMobileRegex.test(cleanValue);
}

/**
 * Name validation allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits and symbols like X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must be at least one character with a letter
  const hasLetterRegex = /\p{L}/u;
  
  return nameRegex.test(value) && hasLetterRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  throw new Error('TODO: implement isValidCreditCard');
}
