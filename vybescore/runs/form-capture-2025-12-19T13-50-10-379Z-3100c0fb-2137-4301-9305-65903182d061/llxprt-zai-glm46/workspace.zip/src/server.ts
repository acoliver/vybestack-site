import express from 'express';
import path from 'path';
import { readFileSync, writeFileSync } from 'fs';
import { createServer } from 'http';
// @ts-expect-error - sql.js doesn't have TypeScript definitions
import initSqlJs from 'sql.js';

// Type declarations for sql.js
interface Database {
  run(sql: string, params?: unknown[]): unknown;
  prepare(sql: string): { run(params: unknown[]): unknown; free(): void };
  export(): Uint8Array;
  close(): void;
}

const port = process.env.PORT ? parseInt(process.env.PORT) : 3535;
const app = express();
const server = createServer(app);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database;

// Initialize SQLite database
async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    
    let dataBuffer;
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    try {
      dataBuffer = readFileSync(dbPath);
      db = new SQL.Database(dataBuffer);
    } catch (error) {
      // Database doesn't exist, create it
      const schema = readFileSync(
        path.join(process.cwd(), 'db', 'schema.sql'),
        'utf8'
      );
      db = new SQL.Database();
      db.run(schema);
      saveDatabase(db, dbPath);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(database: Database, dbPath: string) {
  try {
    const data = database.export();
    writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validate email format
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 5;
}

function isValidPostalCode(postalCode: string): boolean {
  const postalRegex = /^[\w\s-]+$/;
  return postalRegex.test(postalCode.trim()) && postalCode.trim().length > 2;
}

// Validate form data
function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phone && !isValidPhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number (international format accepted)'
    });
  }

  // Postal code validation
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return errors;
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validationErrors = validateFormData(formData);

  if (validationErrors.length > 0) {
    return res.render('form', {
      errors: validationErrors.map(e => e.message),
      values: formData
    });
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, 
      state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();

    // Save database to disk
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    saveDatabase(db, dbPath);

    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
    
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while processing your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  
  if (db) {
    db.close();
    console.log('Database connection closed');
  }
  
  server.close(() => {
    console.log('HTTP server closed');
    process.exit(0);
  });

  // Force close after 10 seconds
  setTimeout(() => {
    console.error('Forced shutdown after timeout');
    process.exit(1);
  }, 10000);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer() {
  try {
    await initializeDatabase();
    
    server.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
