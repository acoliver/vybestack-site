/**
 * Validate if a string is valid Base64 format
 */
function isValidBase64(input: string): boolean {
  // Check if the string contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check padding validity
  const equalsIndex = input.indexOf('=');
  if (equalsIndex !== -1) {
    const paddingLength = input.length - equalsIndex;
    return paddingLength <= 3 && input.length % 4 === 0;
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding
 */
export function encode(input: string): string {
  // Use standard Base64 (not base64url) to get the '+' and '/' characters
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Normalize input by adding padding if missing
  const normalized = input.trim();
  
  // Validate format
  if (!isValidBase64(normalized)) {
    throw new Error('Invalid Base64 format');
  }
  
  try {
    // Add padding if necessary
    const padded = normalized.padEnd(Math.ceil(normalized.length / 4) * 4, '=');
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}