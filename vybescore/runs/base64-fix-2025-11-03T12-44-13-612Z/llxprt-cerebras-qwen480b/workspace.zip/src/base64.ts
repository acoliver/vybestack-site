/** 
 * Encode plain text to Base64 using canonical RFC 4648 Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * @throws {Error} If input is not valid Base64
 */
export function decode(input: string): string {
  // Check if the input is valid Base64 (allowing optional padding)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}