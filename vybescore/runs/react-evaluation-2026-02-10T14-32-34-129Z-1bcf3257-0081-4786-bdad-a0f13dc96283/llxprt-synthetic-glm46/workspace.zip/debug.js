import { createInput, createComputed, createCallback } from './src/index.js';

console.log('=== Testing reactive computation chain ===');

const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => input() * 2);
const timesThirty = createComputed(() => input() * 30);
const sum = createComputed(() => timesTwo() + timesThirty());

console.log('Initial input:', input());
console.log('Initial timesTwo:', timesTwo());
console.log('Initial timesThirty:', timesThirty());
console.log('Initial sum:', sum());

setInput(3);

console.log('After setInput(3):');
console.log('Input:', input());
console.log('timesTwo:', timesTwo());
console.log('timesThirty:', timesThirty());
console.log('sum:', sum());

console.log('=== Testing callbacks ===');

const [input2, setInput2] = createInput(1);
const output = createComputed(() => input2() + 1);
let value = 0;
createCallback(() => (value = output()));
console.log('Initial value:', value);

setInput2(3);
console.log('After setInput2(3):');
console.log('output:', output());
console.log('value:', value);

console.log('=== Testing callback cleanup ===');

const [input3, setInput3] = createInput(11);
const output3 = createComputed(() => input3() + 1);

const values1 = [];
const unsubscribe1 = createCallback(() => values1.push(output3()));
const values2 = [];
createCallback(() => values2.push(output3()));

setInput3(31);

console.log('Before unsubscribe:', values1, values2);
unsubscribe1();
setInput3(41);

console.log('After unsubscribe:', values1, values2);