/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: ObserverR[]
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let activeInputs: Subject<unknown>[] = []

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  activeInputs = []
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Register inputs that were accessed during computation
export function registerInput<T>(input: Subject<T>): void {
  if (activeInputs.indexOf(input as Subject<unknown>) === -1) {
    activeInputs.push(input as Subject<unknown>)
  }
  
  // Expose the current active inputs for cleanup tracking
  const globalWindow = globalThis as unknown as { _lllActiveInputs: Subject<unknown>[] }
  globalWindow._lllActiveInputs = [...activeInputs]
}

// Register observer with all inputs that were accessed
export function registerObserverWithInputs(observer: ObserverR): void {
  activeInputs.forEach(input => {
    if (input.observers.indexOf(observer) === -1) {
      input.observers.push(observer)
    }
  })
  
  // Expose the current active inputs for cleanup tracking
  const globalWindow = globalThis as unknown as { _lllActiveInputs?: Subject<unknown>[] }
  if (globalWindow) {
    globalWindow._lllActiveInputs = [...(activeInputs as Subject<unknown>[])]
  }
}

// Direct registration of an observer with a subject-like object
export function registerDirectObserver<T>(observer: ObserverR, subject: { observers: ObserverR[]; value: T }): void {
  if (subject.observers.indexOf(observer) === -1) {
    subject.observers.push(observer)
  }
}
