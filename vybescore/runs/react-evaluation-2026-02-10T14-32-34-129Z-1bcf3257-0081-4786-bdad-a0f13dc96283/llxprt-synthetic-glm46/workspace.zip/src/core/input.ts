/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR,
  registerInput
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equal parameter - convert boolean to default equality function if needed
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  // Store dependent observers
  const observers: ObserverR[] = []

  const input: Subject<T> = {
    name: options?.name,
    observers,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    registerInput(input)
    return input.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value changed using equality function
    const hasChanged = !equalFn || !equalFn(input.value, nextValue)
    if (!hasChanged) return input.value
  
    input.value = nextValue
    
    // Notify all observers by triggering update
    input.observers.forEach(observer => {
      updateObserver(observer as Observer<unknown>)
    })
    
    return input.value
  }

  return [read, write]
}
