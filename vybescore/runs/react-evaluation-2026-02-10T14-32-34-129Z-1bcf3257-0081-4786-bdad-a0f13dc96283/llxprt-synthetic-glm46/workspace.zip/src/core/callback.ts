/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  registerObserverWithInputs,
  Subject
} from '../types/reactive.js'

export interface CallbackCleanupInfo {
  input: Subject<unknown>
  observerIndex: number
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Store cleanup information for all inputs this callback depends on
  let cleanupInfo: CallbackCleanupInfo[] = []
  
  // Register observer to track dependencies by running it once
  updateObserver(observer)
  
  // Get list of inputs that were accessed and prepare cleanup info
  registerObserverWithInputs(observer)
  
  // Keep track of original observer update function to wrap it for re-registration
  const originalUpdateFn = observer.updateFn
  
  // Wrap the update function to ensure dependencies are re-registered
  observer.updateFn = (curValue?: T) => {
    const result = originalUpdateFn(curValue)
    registerObserverWithInputs(observer)
    
    // Update cleanup info with current dependencies
    const globalWindow = globalThis as unknown as { _lllActiveInputs?: Subject<unknown>[] }
    const freshInputs = globalWindow._lllActiveInputs || []
    cleanupInfo = []
    freshInputs.forEach((input: Subject<unknown>) => {
      const observerIndex = input.observers.indexOf(observer)
      if (observerIndex !== -1) {
        cleanupInfo.push({ input, observerIndex })
      }
    })
    
    return result
  }
  
  // Initial cleanup info after first registration
  const globalWindow = globalThis as unknown as { _lllActiveInputs?: Subject<unknown>[] }
  const initialInputs = globalWindow._lllActiveInputs || []
  cleanupInfo = []
  initialInputs.forEach((input: Subject<unknown>) => {
    const observerIndex = input.observers.indexOf(observer)
    if (observerIndex !== -1) {
      cleanupInfo.push({ input, observerIndex })
    }
  })
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from all dependent inputs' observers lists
    cleanupInfo.forEach(({ input, observerIndex }) => {
      if (input.observers && observerIndex > -1 && observerIndex < input.observers.length) {
        input.observers.splice(observerIndex, 1)
      }
    })
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
