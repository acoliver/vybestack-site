/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  ObserverR,
  registerObserverWithInputs,
  registerInput
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equal parameter - convert boolean to default equality function if needed
  let equalFn: EqualFn<T> | undefined
  if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (_equal === false) {
    equalFn = undefined
  } else if (typeof _equal === 'function') {
    equalFn = _equal
  }

  // Track observers that depend on this computed value
  const observers: ObserverR[] = []

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Create a subject-like object to make computed values work as dependency sources
  const computedSubject = {
    name: options?.name,
    observers,
    value: value as T,
    equalFn
  }

  // Initial computation to set value and establish dependencies
  let initialValue: T
  try {
    initialValue = o.updateFn()
  } catch {
    initialValue = value as T
  }
  computedSubject.value = initialValue
  o.value = initialValue
  registerObserverWithInputs(o)

// When subjects change, we need to recalculate
  const originalObserverUpdate = o.updateFn
  o.updateFn = (curValue?: T): T => {
    const newValue = originalObserverUpdate(curValue)
    
    // Clear the tracking before re-computing dependencies
    const globalWindow = globalThis as unknown as { _lllActiveInputs?: unknown[] }
    if (globalWindow) {
      globalWindow._lllActiveInputs = []
    }
    
    // Re-compute dependencies and register them
    registerObserverWithInputs(o)
    
    // Update the subject's value and notify all observers
    computedSubject.value = newValue
    observers.forEach(observer => {
      updateObserver(observer as Observer<T>)
    })
    
    return newValue
  }

  // Wrap the getter to make this computed value behave like an input for dependency tracking
  const computedGetter = (): T => {
    // Register computed value as an input dependency for tracking
    registerInput(computedSubject)
    
    // Register current observer as dependent on this computed value
    const currentObserver = getActiveObserver()
    if (currentObserver && observers.indexOf(currentObserver) === -1) {
      observers.push(currentObserver)
    }

    // Register as input dependency if active observer exists and we're being accessed
    if (currentObserver) {
      registerSubjectObserver(currentObserver, computedSubject)
    }
    
    // Return current value from subject, not observer (since updates go to subject)
    return computedSubject.value
  }

  return computedGetter
}

// Helper function to register an observer with a computed subject
function registerSubjectObserver<T>(observer: ObserverR, subject: { observers: ObserverR[]; value: T }) {
  if (subject.observers.indexOf(observer) === -1) {
    subject.observers.push(observer)
  }
}
