import { Subject } from './src/types/reactive.js';

export {};
declare global { 
  let _lllActiveInputs: Subject<unknown>[]
}