import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs from 'sql.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

app.set('views', path.resolve('views'));
app.set('view engine', 'ejs');

// Types
interface ContactData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Database types
type SqlParams = (string | number | null | Uint8Array)[];

interface DatabaseConnection {
  prepare: (query: string) => {
    run: (params: SqlParams) => void;
    free: () => void;
  };
  export: () => Uint8Array;
  exec: (schema: string) => void;
}

// Database management
let db: DatabaseConnection | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

async function initializeDatabase(): Promise<DatabaseConnection> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.resolve('node_modules', 'sql.js', 'dist', file)
  });

  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SQL.Database(buffer) as DatabaseConnection;
  } else {
    db = new SQL.Database() as DatabaseConnection;
    
    // Read and execute schema
    const schemaPath = path.resolve('db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      db.exec(schema);
    }
  }
  
  return db;
}

async function saveDatabase(): Promise<void> {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Validation functions
function validateContactData(data: ContactData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof ContactData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field].trim();
    if (!value) {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required` });
    }
  });

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation (allow international formats)
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  if (data.phone && !phoneRegex.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return errors;
}

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('contact', { 
    errors: [], 
    data: {},
    title: 'Contact Us'
  });
});

app.post('/submit', async (req: express.Request, res: express.Response) => {
  try {
    const contactData: ContactData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateContactData(contactData);

    if (errors.length > 0) {
      return res.status(400).render('contact', {
        errors,
        data: contactData,
        title: 'Contact Us - Please Fix Errors'
      });
    }

    if (!db) {
      throw new Error('Database not initialized');
    }

    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      contactData.firstName,
      contactData.lastName,
      contactData.streetAddress,
      contactData.city,
      contactData.stateProvince,
      contactData.postalCode,
      contactData.country,
      contactData.email,
      contactData.phone
    ]);

    stmt.free();
    await saveDatabase();

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Submission error:', error);
    res.status(500).render('contact', {
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
      data: req.body,
      title: 'Contact Us - Error'
    });
  }
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

// Health check endpoint
app.get('/health', (req: express.Request, res: express.Response) => {
  res.json({ status: 'ok' });
});

// Graceful shutdown
async function shutdown() {
  console.log('Shutting down gracefully...');
  
  if (db) {
    await saveDatabase();
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
let serverInstance: ReturnType<typeof app.listen> | null = null;

async function startServer() {
  try {
    db = await initializeDatabase();
    
    serverInstance = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
    
    return serverInstance;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, startServer, serverInstance };

// Start server only if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}
