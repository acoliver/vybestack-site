import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import type { Express } from 'express';
import type { Server as HttpServer } from 'node:http';

// We'll import the server dynamically to avoid circular dependencies
let app: Express;
let server: HttpServer | undefined;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and setup the server
  const serverModule = await import('../../dist/server.js');
  app = serverModule.app;
  
  // Start the server for testing
  if (serverModule.startServer) {
    await serverModule.startServer();
  }
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  // Clean up
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const cheerioModule = await import('cheerio');
    const $ = cheerioModule.load(response.text);
    expect($('form').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(submissionData);
    
    expect(response.status).toBe(302);
    expect(response.header.location).toBe('/thank-you');
    
    // Check that the database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
