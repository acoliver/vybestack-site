import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import { createServer } from 'http';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { setTimeout } from 'timers/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);
const dbPath = join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = join(__dirname, '..', 'db', 'schema.sql');

// Type definitions for form submissions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Server initialization
const app = express();
const server = createServer(app);
let db: initSqlJs.Database | null = null;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 5;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric codes, common internationally
  const postalRegex = /^[a-zA-Z0-9\s-]{3,10}$/;
  return postalRegex.test(postalCode.trim());
}


function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  if (!formData.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Format validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading + are allowed)' });
  }
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code (3-10 alphanumeric characters)' });
  }

  return errors;
}

// Database initialization
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    if (existsSync(dbPath)) {
      // Load existing database
      const fileBuffer = readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      // Create new database with schema
      db = new SQL.Database();
      const schema = readFileSync(schemaPath, 'utf-8');
      db.exec(schema);
      
      // Save the new database
      const data = db.export();
      writeFileSync(dbPath, Buffer.from(data));
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Database operations
function saveSubmission(formData: FormData): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database after insertion
    const data = db.export();
    writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save submission:', error);
    throw error;
  }
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: null,
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body as FormData;
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    // Return validation errors to the form
    const errorMessages = errors.map(e => e.message);
    return res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
  }
  
  try {
    // Save valid submission
    saveSubmission(formData);
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  // We'll use a generic greeting since we don't maintain sessions
  res.render('thank-you', {
    firstName: 'Friend' // Generic greeting
  });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down server...');
  
  if (server) {
    server.close();
  }
  
  if (db) {
    db.close();
  }
  
  await setTimeout(1000); // Give time for cleanup
  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  const port = Number(process.env.PORT) || 3535;
  
  try {
    await initializeDatabase();
    console.log('Database initialized successfully');
    
    server.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
