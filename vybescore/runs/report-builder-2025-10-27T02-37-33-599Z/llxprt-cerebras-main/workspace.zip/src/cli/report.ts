#!/usr/bin/env node

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Define supported formats
const FORMATS = {
  markdown: renderMarkdown,
  text: renderText
};

// Parse command line arguments
function parseArgs(): { 
  dataFile: string; 
  format: string; 
  output?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  const dataFile = args[0];
  
  if (!dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format option is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1];
  
  if (!FORMATS[format]) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 && outputIndex + 1 < args.length ? 
    args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return { dataFile, format, output, includeTotals };
}

// Validate report data structure
function validateData(data: any): data is ReportData {
  if (!data || typeof data !== 'object') {
    return false;
  }
  
  if (typeof data.title !== 'string' || typeof data.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(data.entries)) {
    return false;
  }
  
  for (const entry of data.entries) {
    if (!entry || typeof entry !== 'object') {
      return false;
    }
    if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

// Main function
async function main() {
  try {
    const { dataFile, format, output, includeTotals } = parseArgs();
    
    // Read and parse JSON data
    const dataPath = path.resolve(__dirname, '..', '..', dataFile);
    const jsonData = fs.readFileSync(dataPath, 'utf8');
    const data = JSON.parse(jsonData);
    
    // Validate data structure
    if (!validateData(data)) {
      console.error('Error: Invalid data format in JSON file');
      process.exit(1);
    }
    
    // Render report
    const renderer = FORMATS[format];
    const report = renderer(data, { includeTotals });
    
    // Output report
    if (output) {
      const outputPath = path.resolve(__dirname, '..', '..', output);
      fs.writeFileSync(outputPath, report);
    } else {
      console.log(report);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: ${error}`);
    }
    process.exit(1);
  }
}

main();