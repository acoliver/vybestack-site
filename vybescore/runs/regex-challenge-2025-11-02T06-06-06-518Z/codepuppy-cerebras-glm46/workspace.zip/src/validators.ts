export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with robust regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows letters, digits, dots, pluses, hyphens in local part
  // - Rejects consecutive dots and leading/trailing dots
  // - Rejects underscores in domain
  // - Allows 2-63 character TLD
  const emailRegex = /^[a-zA-Z0-9](?!.*\.\.)([a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;
  
  return emailRegex.test(value) && !value.includes('..') && !value.startsWith('.') && !value.endsWith('.') && !value.includes('_');
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and spaces
  const cleaned = value.replace(/[\s\-\(\)]/g, '');
  
  // Check for optional +1 prefix
  const hasPrefix = cleaned.startsWith('+1');
  const numberPart = hasPrefix ? cleaned.slice(2) : cleaned;
  
  // Basic digit check - should be 10 digits after removing country code
  if (!/^\d{10}$/.test(numberPart)) {
    return false;
  }
  
  const areaCode = numberPart.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Remove the exchange code validation that was too strict
  // Exchange code can start with 0 or 1 in some valid cases
  
  // Full regex validation for common US phone formats
  const phoneRegex = /^(?:\+1[-\s]?)?(?:\(?\d{3}\)?[-\s]?\d{3}[-\s]?\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s\-]/g, '');
  
  // Regex pattern for Argentine phone numbers:
  // ^\+54? - Optional country code
  // 9? - Optional mobile indicator
  // 0? - Optional trunk prefix (required when country code is omitted)
  // (\d{2,4}) - Area code (2-4 digits, leading digit 1-9)
  // \d{6,8} - Subscriber number (6-8 digits)
  // $
  const phoneRegex = /^\+54?9?(0)?[1-9]\d{1,2}\d{6,8}$/;
  
  if (!phoneRegex.test(cleaned)) {
    return false;
  }
  
  // Additional validation: if no country code, must have trunk prefix
  const hasCountryCode = cleaned.startsWith('+54');
  
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Reject digits and most other symbols
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Check if it contains only allowed characters
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that contain numbers or excessive symbols
  if (/\d/.test(value) || /[!@#$%^&*()_+=\[\]{};:"|\\,.<>?/~`]/.test(value)) {
    return false;
  }
  
  // Ensure at least some letters are present
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits and all numeric
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13}|2[2-7]0\d{12}|2[2-7][0-1]\d{12}|2720\d{12})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn checksum validation
  return luhnChecksum(cleaned);
}

/**
 * Helper function for Luhn checksum validation.
 */
function luhnChecksum(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}