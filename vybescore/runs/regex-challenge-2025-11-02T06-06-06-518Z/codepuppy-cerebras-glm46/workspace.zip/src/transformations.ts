/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences and collapse extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with single space
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Ensure proper spacing after sentence endings
  normalized = normalized.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Capitalize first letter of each sentence
  const result = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http/https protocols and common domain patterns
  // Fixed regex to properly match full domain names
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation if present
  return matches.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with domain and optional path
  const urlPattern = /(http:\/\/)([a-zA-Z0-9.-]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, protocol, domain, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if path starts with /docs/ and doesn't contain dynamic indicators
    if (path && path.startsWith('/docs/') && 
        !/(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path)) {
      // Rewrite to docs.example.com
      const newDomain = domain.includes('.') ? `docs.${domain}` : `docs.${domain}.com`;
      return newProtocol + newDomain + path;
    }
    
    // Just upgrade protocol
    return newProtocol + domain + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day range for the month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  // Check for leap year (February 29)
  if (monthNum === 2 && dayNum === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  // Check if day is valid for the month
  if (dayNum > daysInMonth[monthNum]) {
    return 'N/A';
  }
  
  return year;
}