/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const filteredMatches = matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
  
  // Remove duplicates while preserving order
  return [...new Set(filteredMatches)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, _token: string): string[] {
  // Pattern to find digit followed by word characters
  const tokenRegex = /\d\w+/g;
  
  const matches = text.match(tokenRegex) || [];
  
  // Filter for matches that contain the token
  return matches.filter(match => match.includes(_token));
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length requirement
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // This regex looks for any 2+ character sequence repeated immediately
  const repeatedSequenceRegex = /(.{2,})\1+/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that captures all valid IPv6 formats:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8:85a3::8a2e:370:7334
  // - Leading zeros: ::1, ::
  // Does NOT match IPv4 addresses
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|::1?|::/g;
  
  // Check if the string contains IPv6 patterns
  return ipv6Regex.test(value);
}