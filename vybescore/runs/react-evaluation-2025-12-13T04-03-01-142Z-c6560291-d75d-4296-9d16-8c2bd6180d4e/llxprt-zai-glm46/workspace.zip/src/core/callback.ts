/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer } from '../types/reactive'

import { 
  getActiveObserver,
  setActiveObserver,
  getAllDependents,
  getTrackingDependencies
} from '../reactive-system'

const allDependents = getAllDependents()
const trackingDependencies = getTrackingDependencies()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: (value?: T) => T, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Initialize dependents tracking for this callback observer
  allDependents.set(observer as Observer<unknown>, new Set())
  
  // Initialize tracking dependencies for this observer
  trackingDependencies.set(observer, new Set())
  
  // Execute the callback initially to establish dependencies and perform side effect
  const executeCallback = () => {
    if (disposed) return
    
    const previousObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      // Clear previous dependencies and track new ones
      const currentDependencies = trackingDependencies.get(observer)
      if (currentDependencies) {
        currentDependencies.clear()
      }
      
      observer.value = updateFn(observer.value)
      
      // Track new dependencies
      const newDependencies = trackingDependencies.get(observer)
      if (newDependencies) {
        // For each new dependency, register this observer as a dependent
        for (const dependency of newDependencies) {
          let dependents = allDependents.get(dependency)
          if (!dependents) {
            dependents = new Set()
            allDependents.set(dependency, dependents)
          }
          dependents.add(observer as Observer<unknown>)
        }
      }
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Execute immediately to track dependencies and perform side effect
  executeCallback()
  
  // Return unsubscribe function
  return function unsubscribe() {
    if (disposed) return
    disposed = true
    
    // Clean up dependencies from all dependents tracking
    const dependencies = trackingDependencies.get(observer)
    if (dependencies) {
      for (const dependency of dependencies) {
        const dependents = allDependents.get(dependency)
        if (dependents) {
          dependents.delete(observer as Observer<unknown>)
        }
      }
    }
    
    // Remove from global tracking
    allDependents.delete(observer as Observer<unknown>)
    trackingDependencies.delete(observer)
  }
}