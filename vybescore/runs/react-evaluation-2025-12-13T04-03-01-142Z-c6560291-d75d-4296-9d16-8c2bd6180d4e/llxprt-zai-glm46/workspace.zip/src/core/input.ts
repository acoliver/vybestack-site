/**
 * Input closure implementation for reactive state management.
 */

import { 
  GetterFn, 
  SetterFn, 
  InputPair,
  Options,
  EqualFn,
  Observer
} from '../types/reactive'

import { 
  getActiveObserver,
  getAllDependents,
  getTrackingDependencies
} from '../reactive-system'

/**
 * Default equality function that uses strict equality.
 */
function defaultEqualFn<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

const allDependents = getAllDependents()
const trackingDependencies = getTrackingDependencies()

/**
 * Updates an observer by calling its update function
 */
function updateObserver(observer: Observer<unknown>): void {
  const oldValue = observer.value
  observer.value = observer.updateFn(oldValue)
  
  // Notify dependents
  const dependents = allDependents.get(observer)
  if (dependents) {
    for (const dependent of dependents) {
      updateObserver(dependent)
    }
  }
}

/**
 * Creates an input closure that returns a getter/setter pair.
 * The getter can track dependencies when called within a computed or callback.
 * The setter notifies all dependent observers when the value changes.
 */
export function createInput<T>(value: T, equal?: EqualFn<T>, options?: Options): InputPair<T> {
  const equalFn = equal || defaultEqualFn
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (newValue?: T) => newValue as T
  }
  
  // Initialize dependents tracking for this input observer
  allDependents.set(observer as Observer<unknown>, new Set())
  
  // Getter function that tracks dependencies
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    if (activeObserver) {
      // Track this input as a dependency for the active observer
      let dependencies = trackingDependencies.get(activeObserver)
      if (!dependencies) {
        dependencies = new Set<Observer<unknown>>()
        trackingDependencies.set(activeObserver, dependencies)
      }
      dependencies.add(observer as Observer<unknown>)
      
      // Register the active observer as a dependent of this input
      let dependents = allDependents.get(observer as Observer<unknown>)
      if (!dependents) {
        dependents = new Set()
        allDependents.set(observer as Observer<unknown>, dependents)
      }
      dependents.add(activeObserver as Observer<unknown>)
    }
    
    return observer.value as T
  }
  
  // Setter function that notifies dependents when value changes
  const setter: SetterFn<T> = (newValue: T) => {
    // Only update and notify if value actually changed
    if (!equalFn(observer.value as T, newValue)) {
      observer.value = newValue
      
      // Notify all dependent observers
      const dependents = allDependents.get(observer as Observer<unknown>)
      if (dependents) {
        for (const dependent of dependents) {
          updateObserver(dependent)
        }
      }
    }
    
    return newValue
  }
  
  return [getter, setter]
}