/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Options,
  EqualFn
} from '../types/reactive'

import { 
  getActiveObserver,
  setActiveObserver,
  getAllDependents,
  getTrackingDependencies,
  addComputedObserver,
  isComputedObserver
} from '../reactive-system'

/**
 * Default equality function that uses strict equality.
 */
function defaultEqualFn<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

const allDependents = getAllDependents()
const trackingDependencies = getTrackingDependencies()

/**
 * Enhanced update function that properly handles computed observer propagation
 */
function enhancedUpdateObserver(observer: Observer<unknown>): void {
  const oldValue = observer.value
  observer.value = observer.updateFn(oldValue)
  
  // If this is a computed observer, recursively update its dependents
  if (isComputedObserver(observer)) {
    const dependents = allDependents.get(observer)
    if (dependents) {
      for (const dependent of dependents) {
        enhancedUpdateObserver(dependent)
      }
    }
  }
}

/**
 * Creates a computed closure that automatically tracks dependencies
 * and updates when those dependencies change.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>, 
  value?: T, 
  equal?: EqualFn<T>, 
  options?: Options
): GetterFn<T> {
  const equalFn = equal || defaultEqualFn
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn
  }
  
  // Register as a computed observer
  addComputedObserver(observer as Observer<unknown>)
  
  // Initialize dependents tracking for this computed observer
  allDependents.set(observer as Observer<unknown>, new Set())
  
  // Update function that tracks dependencies and computes new value
  function compute(): void {
    const previousObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      // Clear previous dependencies for this observer
      const dependencies = trackingDependencies.get(observer)
      if (dependencies) {
        dependencies.clear()
      }
      
      // Compute new value
      const oldValue = observer.value
      observer.value = updateFn(observer.value)
      
      // Track new dependencies established during computation
      const newDependencies = trackingDependencies.get(observer)
      if (newDependencies) {
        // For each new dependency, register this observer as a dependent
        for (const dependency of newDependencies) {
          let dependents = allDependents.get(dependency)
          if (!dependents) {
            dependents = new Set()
            allDependents.set(dependency, dependents)
          }
          dependents.add(observer as Observer<unknown>)
        }
      }
      
      // If value changed, notify dependents using enhanced update
      if (!equalFn(oldValue as T, observer.value as T)) {
        const dependents = allDependents.get(observer as Observer<unknown>)
        if (dependents) {
          for (const dependent of dependents) {
            enhancedUpdateObserver(dependent)
          }
        }
      }
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Getter function that tracks dependencies and returns current value
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
if (activeObserver) {
      // Register the active observer as a dependent of this computed value
      let dependents = allDependents.get(observer as Observer<unknown>)
      if (!dependents) {
        dependents = new Set()
        allDependents.set(observer as Observer<unknown>, dependents)
      }
      dependents.add(activeObserver as Observer<unknown>)
      
      // Add this computed value as a dependency for the active observer
      let deps = trackingDependencies.get(activeObserver)
      if (!deps) {
        deps = new Set<Observer<unknown>>()
        trackingDependencies.set(activeObserver, deps)
      }
      deps.add(observer as Observer<unknown>)
    }
    
    // Compute if this is the first access
    if (observer.value === undefined) {
      compute()
    }
    
    return observer.value as T
  }
  
  // Initial computation
  compute()
  
  return getter
}