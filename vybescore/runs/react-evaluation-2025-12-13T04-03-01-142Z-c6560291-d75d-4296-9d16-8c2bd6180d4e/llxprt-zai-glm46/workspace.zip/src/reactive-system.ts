/**
 * Central reactive system for managing dependencies and notifications.
 */

import { Observer, ObserverR } from './types/reactive'

// Global active observer tracking
let activeObserver: ObserverR | undefined

// Global dependency tracking
const trackingDependencies = new WeakMap<ObserverR, Set<Observer<unknown>>>()

// Global dependents tracking
const allDependents = new WeakMap<Observer<unknown>, Set<Observer<unknown>>>()

// Registry of computed observers
const computedObservers = new Set<Observer<unknown>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function getTrackingDependencies(): WeakMap<ObserverR, Set<Observer<unknown>>> {
  return trackingDependencies
}

export function getAllDependents(): WeakMap<Observer<unknown>, Set<Observer<unknown>>> {
  return allDependents
}

export function getComputedObservers(): Set<Observer<unknown>> {
  return computedObservers
}

export function addComputedObserver(observer: Observer<unknown>): void {
  computedObservers.add(observer)
}

export function removeComputedObserver(observer: Observer<unknown>): void {
  computedObservers.delete(observer)
}

export function isComputedObserver(observer: Observer<unknown>): boolean {
  return computedObservers.has(observer)
}

export function updateObserver(observer: Observer<unknown>): void {
  const oldValue = observer.value
  observer.value = observer.updateFn(oldValue)
}