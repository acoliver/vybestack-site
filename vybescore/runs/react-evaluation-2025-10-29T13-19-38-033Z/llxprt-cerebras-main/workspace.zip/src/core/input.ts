/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part of an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create the subject
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : undefined,
  }

  // Create getter function
  const read: GetterFn<T> = () => {
    // Track dependency if there's an active observer
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
    }
    return s.value
  }

  // Create setter function
  const write: SetterFn<T> = (nextValue) => {
    // Check if the value has actually changed using the equality function or ===
    const isEqual = s.equalFn ?? ((a: T, b: T) => a === b)
    if (!isEqual(s.value, nextValue)) {
      s.value = nextValue
      // Notify observer if it exists
      if (s.observer) {
        updateObserver(s.observer as Observer<unknown>)
      }
    }
    return s.value
  }

  return [read, write]
}