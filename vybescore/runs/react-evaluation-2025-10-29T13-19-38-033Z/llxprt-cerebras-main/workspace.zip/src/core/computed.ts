/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create observer for this computed value
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  // Create getter function that tracks dependencies when accessed
  const getter: GetterFn<T> = () => {
    // Track this computed as a dependency of the active observer
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // Save the current computed observer as a dependency of the active observer
      // This implementation assumes that the observer pattern handles dependency tracking
      // via the getActiveObserver()/updateObserver() mechanism
    }
    
    // Return the computed value
    return o.value as T
  }
  
  return getter
}