#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData } from '../types.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  let inputFile = '';
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: Unknown option ${arg}`);
      process.exit(1);
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      console.error(`Error: Unexpected argument ${arg}`);
      process.exit(1);
    }
  }

  if (!inputFile) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Invalid JSON: root must be an object');
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error('Error: Invalid report data: missing or invalid "title" field (must be a string)');
    return false;
  }

  if (typeof obj.summary !== 'string') {
    console.error('Error: Invalid report data: missing or invalid "summary" field (must be a string)');
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    console.error('Error: Invalid report data: missing or invalid "entries" field (must be an array)');
    return false;
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Invalid report data: entry at index ${i} must be an object`);
      return false;
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Invalid report data: entry at index ${i} missing or invalid "label" field`);
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Invalid report data: entry at index ${i} missing or invalid "amount" field`);
      return false;
    }
  }

  return true;
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Read input file
  let inputFileContent: string;
  try {
    inputFileContent = fs.readFileSync(args.inputFile, 'utf-8');
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: ${args.inputFile}`);
    } else {
      console.error(`Error: Unable to read file: ${args.inputFile}`);
    }
    process.exit(1);
  }

  // Parse JSON
  let jsonData: unknown;
  try {
    jsonData = JSON.parse(inputFileContent);
  } catch (error) {
    console.error(`Error: Invalid JSON in file: ${args.inputFile}`);
    if (error instanceof Error) {
      console.error(`Details: ${error.message}`);
    }
    process.exit(1);
  }

  // Validate data structure
  if (!validateReportData(jsonData)) {
    process.exit(1);
  }

  const reportData: ReportData = jsonData;

  // Get formatter
  const formatter = formatters[args.format];
  if (!formatter) {
    console.error(`Error: Unsupported format: ${args.format}`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  // Render report
  const output = formatter.render(reportData, { includeTotals: args.includeTotals });

  // Write output
  if (args.outputPath) {
    try {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Unable to write to file: ${args.outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
