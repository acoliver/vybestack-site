import type { ReportData, ReportRenderer, RenderOptions } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderText: ReportRenderer = {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];

    // Title
    lines.push(data.title);
    lines.push('');

    // Summary
    lines.push(data.summary);
    lines.push('');

    // Entries heading
    lines.push('Entries:');

    // Entries
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }

    // Total if requested
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push(`Total: ${formatAmount(total)}`);
    }

    return lines.join('\n');
  },
};
