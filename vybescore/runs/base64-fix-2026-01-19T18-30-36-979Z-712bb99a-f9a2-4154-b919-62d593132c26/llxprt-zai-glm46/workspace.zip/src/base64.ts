/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate whether a string is valid Base64.
 */
function isValidBase64(input: string): boolean {
  // Empty input is not valid
  if (input.length === 0) {
    return false;
  }

  // Check if the string matches Base64 pattern
  // Valid Base64 contains: A-Z, a-z, 0-9, +, /, and = for padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Check padding is valid (only at the end, and correct amount)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end
    const paddingSection = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      return false;
    }

    // Padding length must be 0, 1, or 2
    if (paddingSection.length > 2) {
      return false;
    }

    // Total length with padding must be multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  } else {
    // Without padding, length can be any, but we need to check if it's valid
    // by attempting to decode
  }

  // Try to decode to verify it's actually valid
  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    // Re-encode and compare to catch invalid Base64 that Buffer silently handles
    const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
    // Normalize both for comparison (remove trailing = from reEncoded if input has no padding)
    const normalizedInput = input.replace(/=+$/, '');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    return normalizedInput === normalizedReEncoded;
  } catch {
    return false;
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error if the input is invalid Base64.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
