const INVALID_CHARS_MSG = 'Invalid Base64 input: contains invalid characters';
const TOO_MUCH_PADDING_MSG = 'Invalid Base64 input: too much padding';
const INCORRECT_PADDING_LENGTH_MSG = 'Invalid Base64 input: incorrect padding length';
const EMPTY_INPUT_MSG = 'Invalid Base64 input: empty input';
const MALFORMED_DATA_MSG = 'Invalid Base64 input: malformed data';
const DECODE_ERROR_MSG = 'Failed to decode Base64 input';

/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input characters and padding structure.
 */
function validateBase64Input(normalized: string): void {
  if (normalized.length === 0) {
    throw new Error(EMPTY_INPUT_MSG);
  }

  const paddingIndex = normalized.indexOf('=');
  
  if (paddingIndex === -1) {
    // No padding: verify all characters are valid Base64
    if (!/^[A-Za-z0-9+/]+$/.test(normalized)) {
      throw new Error(INVALID_CHARS_MSG);
    }
    return;
  }

  // If there's padding, verify everything after the first = is also =
  const afterPadding = normalized.substring(paddingIndex);
  if (!/^=+$/.test(afterPadding)) {
    throw new Error(INVALID_CHARS_MSG);
  }

  // Padding can only be 1 or 2 characters
  if (afterPadding.length > 2) {
    throw new Error(TOO_MUCH_PADDING_MSG);
  }

  // Padding can only appear when the total length is a multiple of 4
  if (normalized.length % 4 !== 0) {
    throw new Error(INCORRECT_PADDING_LENGTH_MSG);
  }

  // Verify all characters before padding are valid Base64
  const beforePadding = normalized.substring(0, paddingIndex);
  if (!/^[A-Za-z0-9+/]+$/.test(beforePadding)) {
    throw new Error(INVALID_CHARS_MSG);
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace from the input
  const normalized = input.trim();
  
  validateBase64Input(normalized);

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if the decoding was successful by verifying round-trip
    const checkEncoded = buffer.toString('base64').replace(/=+$/, '');
    const normalizedWithoutPadding = normalized.replace(/=+$/, '');
    
    // If the normalized input (without padding) doesn't match the re-encoded buffer,
    // then the original input was invalid
    if (normalizedWithoutPadding.length > 0 && checkEncoded !== normalizedWithoutPadding) {
      throw new Error(MALFORMED_DATA_MSG);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error(DECODE_ERROR_MSG);
  }
}
