import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database
let db: import('sql.js').Database;
const dbPath = path.resolve('data', 'submissions.sqlite');

async function initDatabase() {
  try {
    const SQL = await initSqlJs();
    
    // Load existing database or create new one
    let data: Uint8Array | undefined;
    if (fs.existsSync(dbPath)) {
      data = fs.readFileSync(dbPath);
    }
    
    db = new SQL.Database(data);
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase() {
  const data = db.export();
  if (!fs.existsSync(path.dirname(dbPath))) {
    fs.mkdirSync(path.dirname(dbPath), { recursive: true });
  }
  fs.writeFileSync(dbPath, Buffer.from(data));
}

// Validation
interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

function validateForm(values: FormValues): string[] {
  const errors: string[] = [];
  
  // Required fields
  if (!values.firstName.trim()) errors.push('First name is required');
  if (!values.lastName.trim()) errors.push('Last name is required');
  if (!values.streetAddress.trim()) errors.push('Street address is required');
  if (!values.city.trim()) errors.push('City is required');
  if (!values.stateProvince.trim()) errors.push('State/Province/Region is required');
  if (!values.postalCode.trim()) errors.push('Postal/Zip code is required');
  if (!values.country.trim()) errors.push('Country is required');
  if (!values.email.trim()) errors.push('Email is required');
  if (!values.phone.trim()) errors.push('Phone number is required');
  
  // Email validation (simple regex)
  if (values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation (digits, spaces, parentheses, dashes, and leading +)
  if (values.phone && !/^\+?[0-9-\s()]+$/.test(values.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }
  
  // Postal code validation (alphanumeric)
  if (values.postalCode && !/^[a-zA-Z0-9\s]+$/.test(values.postalCode)) {
    errors.push('Postal/Zip code can only contain letters and digits');
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} as FormValues 
  });
});

app.post('/submit', (req, res) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(values);
  
  if (errors.length > 0) {
    res.status(400).render('form', { errors, values });
    return;
  }
  
  // Insert into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.push('A technical error occurred. Please try again later.');
    res.status(500).render('form', { errors, values });
  }
});

app.get('/thank-you', (req, res) => {
  // Use a generic greeting since we don't have session state
  res.render('thank-you', { firstName: 'friend' });
});

// Graceful shutdown
async function shutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  if (db) {
    saveDatabase();
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

// Start server
async function start() {
  try {
    await initDatabase();
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, initDatabase, saveDatabase };

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  start();
}
