declare module 'sql.js' {
  interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }

  interface InitSqlJsOptions {
    locateFile?: (file: string) => string;
  }

  function initSqlJs(options?: InitSqlJsOptions): Promise<typeof SqlJs>;
  const SqlJs: {
    Database: typeof Database;
  };

  export = initSqlJs;
  export { Database, Statement };
}