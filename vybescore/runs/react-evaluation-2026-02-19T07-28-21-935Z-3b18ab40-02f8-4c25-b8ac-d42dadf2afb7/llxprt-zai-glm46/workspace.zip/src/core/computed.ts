/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | unknown,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Store observers that depend on this computed value
  const dependentObservers: Observer<unknown>[] = []
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      const obs = activeObserver as Observer<unknown>
      // Register this observer if not already registered
      if (!dependentObservers.includes(obs)) {
        dependentObservers.push(obs)
      }
    }
    return o.value!
  }
  
  // Override updateObserver to trigger dependent observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    o.value = result
    // Trigger all dependent observers
    dependentObservers.forEach(obs => updateObserver(obs))
    return result
  }
  
  // Initial computation
  updateObserver(o)
  
  return getter
}
