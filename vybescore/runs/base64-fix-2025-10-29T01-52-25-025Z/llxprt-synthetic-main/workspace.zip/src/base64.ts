

/**
 * Encode plain text to Base64 using the standard RFC 4648 alphabet.
 * Includes required padding characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 alphabet with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate Base64 format - only allow Standard Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }
  
  // Check for proper padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If padding exists, it should only appear at the end
    if (paddingIndex !== input.lastIndexOf('=')) {
      throw new Error('Invalid Base64 input: padding characters are not correctly positioned');
    }
    
    // Calculate expected padding based on length
    const lengthWithoutPadding = input.replace(/=/g, '').length;
    const expectedPadding = lengthWithoutPadding % 4 ? 4 - (lengthWithoutPadding % 4) : 0;
    
    if (input.length - lengthWithoutPadding !== expectedPadding) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
  } else {
    // No padding: length must be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: length without padding must be a multiple of 4');
    }
  }


  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
