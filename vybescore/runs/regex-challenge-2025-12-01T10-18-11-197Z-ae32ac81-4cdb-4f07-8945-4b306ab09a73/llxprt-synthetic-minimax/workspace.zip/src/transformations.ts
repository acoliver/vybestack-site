/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and ensure proper sentence separation
  const result = text.replace(/\s+/g, ' ').trim();
  
  // Split text into sentences based on sentence-ending punctuation
  const sentences = result.split(/([.!?]+)\s*/);
  
  let processedText = '';
  for (let i = 0; i < sentences.length; i += 2) {
    let sentence = sentences[i];
    const punctuation = sentences[i + 1] || '';
    
    if (sentence.trim()) {
      // Capitalize first letter of each sentence
      sentence = sentence.replace(/^(\s*)([a-zA-Zà-üÀ-Ü])/, (match, whitespace, letter) => {
        return whitespace + letter.toUpperCase();
      });
      
      processedText += sentence;
      if (punctuation) {
        processedText += punctuation + ' ';
      }
    }
  }
  
  return processedText.trim();
}

/**
 * TODO: Extract all URLs from the text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs, capturing them without trailing punctuation
  const urlPattern = /(https?:\/\/)([^\/\s]+)(?:\/[^\s]*)?/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation and normalize www. to http://
  return matches.map(url => {
    // Remove trailing punctuation that shouldn't be part of the URL
    let cleanUrl = url.replace(/[.,!?;]+$/, '');
    
    // Normalize www. URLs to http://
    if (cleanUrl.startsWith('www.')) {
      cleanUrl = 'http://' + cleanUrl;
    }
    
    return cleanUrl;
  });
}

/**
 * TODO: Replace http:// with https://.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with capturing groups
  const urlPattern = /(https?:\/\/)([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Check if path contains dynamic hints or query parameters
    const dynamicHints = /(cgi-bin|\?|&|=|.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    
    if (dynamicHints.test(path)) {
      // Just upgrade to https without changing host
      return 'https://' + host + path;
    } else if (path.startsWith('/docs/')) {
      // Change host to docs.hostname.com and upgrade to https
      const newHost = 'docs.' + host;
      return 'https://' + newHost + path;
    } else {
      // Just upgrade to https without changing host
      return 'https://' + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy format, return 'N/A' if invalid.
 */
export function extractYear(value: string): string {
  const yearMatch = value.match(/^\d{2}\/\d{2}\/(\d{4})$/);
  
  if (!yearMatch) {
    return 'N/A';
  }
  
  const year = yearMatch[1];
  
  // Basic month/day validation
  const month = parseInt(value.substring(0, 2));
  const day = parseInt(value.substring(3, 5));
  
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}