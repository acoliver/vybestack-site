/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern to match words starting with the prefix
  // \b ensures we match word boundaries
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const lowerExceptions = exceptions.map(e => e.toLowerCase());
  
  return matches.filter(word => 
    !lowerExceptions.includes(word.toLowerCase())
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token after a digit and not at the start of string
  // (?<!^) ensures not at start, (?<=\d) ensures after a digit
  // We need to capture the digit too since lookbehind doesn't include it in the match
  
  // Use matchAll to get the positions, then extract the full matches including preceding digits
  const matches = [];
  const regex = new RegExp(`(?<!^)(\\d${token})`, 'gi');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[1]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // Uppercase letter check
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Lowercase letter check
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Digit check
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Symbol check (non-alphanumeric, non-space)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212, aa bb)
  // This pattern looks for repeated character pairs that immediately follow each other
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  // Additional check for more complex repeated patterns like abab, 1212, xyxy
  if (/([a-zA-Z\d])\1[a-zA-Z\d]\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Comprehensive IPv6 pattern that excludes IPv4
  // Matches various IPv6 formats including compressed forms with ::
  const ipv6Pattern = /\b(?:(?:[A-Fa-f0-9]{1,4}:){7}[A-Fa-f0-9]{1,4}|(?:[A-Fa-f0-9]{1,4}:){1,7}:|(?:[A-Fa-f0-9]{1,4}:){1,6}:[A-Fa-f0-9]{1,4}|(?:[A-Fa-f0-9]{1,4}:){1,5}(?::[A-Fa-f0-9]{1,4}){1,2}|(?:[A-Fa-f0-9]{1,4}:){1,4}(?::[A-Fa-f0-9]{1,4}){1,3}|(?:[A-Fa-f0-9]{1,4}:){1,3}(?::[A-Fa-f0-9]{1,4}){1,4}|(?:[A-Fa-f0-9]{1,4}:){1,2}(?::[A-Fa-f0-9]{1,4}){1,5}|[A-Fa-f0-9]{1,4}:(?:(?::[A-Fa-f0-9]{1,4}){1,6})|:((?::[A-Fa-f0-9]{1,4}){1,7}|:)|(?:[A-Fa-f0-9]{1,4}:){6}(?:25[0-5]|2[0-4]\d|[0-1]?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3})\b/i;
  
  // IPv4 pattern to exclude pure IPv4 addresses
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4]\d|[0-1]?\d?\d)(?:\.(?:25[0-5]|2[0-4]\d|[0-1]?\d?\d)){3})\b/;
  
  // If it's a pure IPv4 address, return false
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Check if it matches IPv6 pattern
  return ipv6Pattern.test(value);
}
