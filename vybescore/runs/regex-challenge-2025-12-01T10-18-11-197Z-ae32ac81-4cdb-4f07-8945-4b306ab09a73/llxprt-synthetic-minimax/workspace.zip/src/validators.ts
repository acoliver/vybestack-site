export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove surrounding whitespace
  const trimmed = value.trim();
  
  // Basic email pattern that handles typical cases
  const emailPattern = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])+$/;
  
  if (!emailPattern.test(trimmed)) {
    return false;
  }
  
  // Check for double dots in local part
  if (trimmed.split('@')[0].includes('..')) {
    return false;
  }
  
  // Check for double dots in domain
  const domain = trimmed.split('@')[1];
  if (domain.includes('..')) {
    return false;
  }
  
  // Check for trailing dots
  if (domain.endsWith('.') || domain.includes('@')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except plus sign
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let phoneNumber = cleaned;
  if (cleaned.startsWith('+1')) {
    phoneNumber = cleaned.substring(2);
  }
  
  // Remove any remaining plus signs
  phoneNumber = phoneNumber.replace(/\+/g, '');
  
  // Must be exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Basic format validation using original input
  const formats = [
    /^\(\d{3}\)\s*\d{3}-\d{4}$/,           // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,                 // 212-555-7890
    /^\d{10}$/,                             // 2125557890
    /^\+1\s*\(\d{3}\)\s*\d{3}-\d{4}$/,     // +1 (212) 555-7890
    /^\+1\s*\d{3}-\d{3}-\d{4}$/            // +1 212-555-7890
  ];
  
  return formats.some(format => format.test(value.trim()));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except spaces and plus
  const cleaned = value.replace(/[^\d+\s]/g, '');
  
  // Handle different formats:
  // +54 9 11 1234 5678 (mobile with country code)
  // +54 341 123 4567 (landline with country code)  
  // 011 1234 5678 (mobile without country code)
  // 0341 4234567 (landline without country code)
  
  // Pattern to match Argentine phone numbers
  // Account for subscriber numbers that can be split by spaces
  const patterns = [
    // With country code +54
    /^\+54\s*9?\s*\d{2,4}(\s+\d{3,4})+$/,  // +54 9 11 1234 5678, +54 341 123 4567
    /^\+54\s*\d{2,4}(\s+\d{3,4})+$/,       // +54 11 1234 5678, +54 341 123 4567
    // Without country code but with trunk prefix 0
    /^0\s*9?\s*\d{2,4}(\s+\d{3,4})+$/,      // 011 1234 5678, 0341 4234567
    /^0\d{2,4}(\s+\d{3,4})+$/               // 01112345678, 03414234567
  ];
  
  return patterns.some(pattern => pattern.test(cleaned));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow letters (including unicode), spaces, apostrophes, and hyphens
  // Reject digits and special symbols
  const namePattern = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  if (!namePattern.test(value.trim())) {
    return false;
  }
  
  // Reject names with numbers
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with unusual symbols (beyond space, apostrophe, hyphen)
  if (/[^\p{L}\s'-]/u.test(value)) {
    return false;
  }
  
  // Reject obvious non-name patterns like "X Æ A-12"
  if (/Æ/.test(value) || /A-\d+/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (13-19 digits for most cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for reasonable card number pattern (no repeated digits)
  if (/^(\d)\1+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type and prefix validity
  const cardTypes = {
    // Visa
    visa: /^4/,
    // Mastercard - starts with 51-55 or 2221-2720
    mastercard: /^(5[1-5]|2[2-7])/,
    // American Express - starts with 34 or 37
    amex: /^3[47]/,
    // Discover - starts with 6011, 65, or 644-649
    discover: /^(6011|65|64[4-9])/,
    // JCB - starts with 3528-3588
    jcb: /^35[2-8]/
  };
  
  const isValidType = Object.values(cardTypes).some(pattern => pattern.test(cleaned));
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn algorithm
  return runLuhnCheck(cleaned);
}
