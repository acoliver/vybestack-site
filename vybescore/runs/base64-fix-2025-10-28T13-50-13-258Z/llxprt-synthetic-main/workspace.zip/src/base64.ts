/**
 * Encode plain text to canonical Base64 using RFC 4648.
 * Uses the standard Base64 alphabet with "+" and "/" characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts canonical Base64 with optional padding and rejects invalid input.
 */
export function decode(input: string): string {
  // Check for valid Base64 characters and structure
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for invalid padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end
    if (paddingIndex < input.length - 2) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
    // Padding must consist of 1 or 2 consecutive '=' characters
    const padding = input.substring(paddingIndex);
    if (!/^={1,2}$/.test(padding)) {
      throw new Error('Invalid Base64 input: incorrect padding format');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
