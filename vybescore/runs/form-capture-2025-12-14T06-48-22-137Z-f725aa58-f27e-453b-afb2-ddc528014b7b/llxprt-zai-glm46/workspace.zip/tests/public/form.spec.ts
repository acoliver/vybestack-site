import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { FormServer } from '../../src/server.js';

let server: FormServer;
let app: Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = new FormServer(true); // test mode = true
  app = await server.start();
});

afterAll(async () => {
  if (server) {
    await server.stop();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '90210',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
