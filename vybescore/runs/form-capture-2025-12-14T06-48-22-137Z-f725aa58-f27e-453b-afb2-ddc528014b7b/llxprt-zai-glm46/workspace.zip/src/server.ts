import express, { Express, Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';
import type { SqlJsStatic, Database } from './sqljs-types.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: Express;
  private db: Database | null = null;
  private dbPath: string;
  private server: ReturnType<typeof this.app.listen> | null = null;
  private testMode: boolean = false;

  constructor(testMode = false) {
    this.app = express();
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.testMode = testMode;
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(__dirname, '../public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private setupRoutes(): void {
    this.app.get('/', this.renderForm.bind(this));
    this.app.post('/submit', this.handleSubmit.bind(this));
    this.app.get('/thank-you', this.renderThankYou.bind(this));
  }

  private renderForm(req: Request, res: Response): void {
    const errors = req.query.errors ? JSON.parse(req.query.errors as string) : [];
    const formData = req.query.formData ? JSON.parse(req.query.formData as string) : {};

    res.render('form', {
      errors: errors as ValidationError[],
      formData: formData as Partial<FormData>,
      submitted: false,
    });
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!data.firstName.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!data.lastName.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!data.streetAddress.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!data.city.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!data.stateProvince.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!data.postalCode.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }

    if (!data.country.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!data.email.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else if (!emailRegex.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (!data.phone.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else if (!phoneRegex.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    return errors;
  }

  private handleSubmit(req: Request, res: Response): void {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };

    const errors = this.validateForm(formData);

    if (errors.length > 0) {
      const queryParams = new URLSearchParams({
        errors: JSON.stringify(errors),
        formData: JSON.stringify(formData),
      });
      res.redirect(`/?${queryParams.toString()}`);
      return;
    }

    this.insertSubmission(formData);
    res.redirect('/thank-you');
  }

  private renderThankYou(req: Request, res: Response): void {
    res.render('thank-you');
  }

  private async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      console.error('Database not initialized');
      return;
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          firstName, lastName, streetAddress, city, stateProvince, 
          postalCode, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run(
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvince,
        data.postalCode,
        data.country,
        data.email,
        data.phone
      );

      stmt.free();
      this.saveDatabase();
    } catch (error) {
      console.error('Failed to insert submission:', error);
    }
  }

  private createSchema(): void {
    if (!this.db) return;

    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        firstName TEXT NOT NULL,
        lastName TEXT NOT NULL,
        streetAddress TEXT NOT NULL,
        city TEXT NOT NULL,
        stateProvince TEXT NOT NULL,
        postalCode TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `;

    this.db.run(schema);
  }

  private saveDatabase(): void {
    if (!this.db) {
      console.error('Database not initialized');
      return;
    }

    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL: SqlJsStatic = await initSqlJs();

      if (fs.existsSync(this.dbPath)) {
        const fileData = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(fileData);
      } else {
        this.db = new SQL.Database();
        this.createSchema();
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      this.db = null;
    }
  }

  async start(): Promise<Express> {
    await this.initializeDatabase();

    const port = this.testMode ? 0 : (parseInt(process.env.PORT || '3535', 10));

    if (!this.testMode) {
      this.server = this.app.listen(port, () => {
        console.log(`Form server listening on port ${port}`);
      });

      process.on('SIGTERM', this.stop.bind(this));
    }

    return this.app;
  }

  async stop(): Promise<void> {
    if (this.server) {
      this.server.close();
      this.server = null;
    }

    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export { FormServer };