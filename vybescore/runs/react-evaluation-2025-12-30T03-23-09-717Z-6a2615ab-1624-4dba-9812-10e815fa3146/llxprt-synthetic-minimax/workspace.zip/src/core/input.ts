/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifySubject,
  Options,
  GetterFn,
  SetterFn,
  registerDependency
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    observers: new Set()
  }

  const read: GetterFn<T> = () => {
    // Register current observer as dependent of this subject
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    subject.value = nextValue
    // Notify all observers of this subject
    notifySubject(subject)
    return subject.value
  }

  return [read, write]
}
