/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer = {
    value,
    updateFn: updateFn as UpdateFn<unknown>,
    subjects: new Set()
  }
  
  let disposed = false
  
  const executeCallback = () => {
    if (disposed) return
    updateObserver(observer)
  }
  
  // Initial execution to establish dependencies
  executeCallback()
  
  // Return unsubscribe function that also cleans up dependencies
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up observer from all tracked subjects
    for (const subject of observer.subjects) {
      subject.observers.delete(observer)
    }
    observer.subjects.clear()
  }
}
