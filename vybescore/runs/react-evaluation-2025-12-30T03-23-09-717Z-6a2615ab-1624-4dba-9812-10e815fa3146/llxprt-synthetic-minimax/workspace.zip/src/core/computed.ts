/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer = {
    name: options?.name,
    value,
    updateFn: updateFn as UpdateFn<unknown>,
    subjects: new Set()
  }
  
  const read: GetterFn<T> = () => {
    // Execute update function to recompute value and track dependencies
    const result = updateObserver(observer) as T
    return result
  }

  return read
}
