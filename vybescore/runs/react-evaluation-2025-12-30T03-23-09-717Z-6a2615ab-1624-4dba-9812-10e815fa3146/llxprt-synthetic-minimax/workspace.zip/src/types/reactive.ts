/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core interfaces
export interface Observer<T = unknown> {
  name?: string
  value?: T
  updateFn: UpdateFn<unknown>
  // Track subjects this observer depends on
  subjects: Set<Subject<T>>
}

export interface Subject<T = unknown> {
  name?: string
  value: T
  equalFn?: EqualFn<unknown>
  // Track observers that depend on this subject
  observers: Set<Observer<unknown>>
}

// Global reactive execution context
let activeObserver: Observer<unknown> | undefined = undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function executeObserver<T>(observer: Observer<T> & { value?: T }): T {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    const result = (observer as unknown as { updateFn: UpdateFn<T> }).updateFn(observer.value)
    observer.value = result as T
    return result as T
  } finally {
    activeObserver = previous
  }
}

export function updateObserver<T>(observer: Observer<T> & { value?: T }): T {
  return executeObserver(observer)
}

export function getCurrentObserver(): Observer | undefined {
  return getActiveObserver()
}

// Register dependency relationship
export function registerDependency<T>(
  subject: Subject<T>,
  observer: Observer<unknown>
): T {
  // Establish bidirectional relationship
  subject.observers.add(observer as Observer<T>)
  observer.subjects.add(subject as Subject<unknown>)
  
  return subject.value as T
}

// Notify all observers of a subject when it changes
export function notifySubject<T>(subject: Subject<T>): void {
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    executeObserver(observer as Observer<T> & { value?: T })
  }
}
