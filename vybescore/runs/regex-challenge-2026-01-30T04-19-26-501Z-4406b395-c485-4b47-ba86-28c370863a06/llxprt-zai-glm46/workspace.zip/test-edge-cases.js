// Test edge cases manually
import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/puzzles.js';

console.log('=== Testing Validators ===\n');

// Email tests
console.log('Email:');
console.log('  name@tag@example.co.uk:', isValidEmail('name@tag@example.co.uk'));
console.log('  user@@example.com:', isValidEmail('user@@example.com'));
console.log('  user@domain_.com:', isValidEmail('user@domain_.com'));
console.log('  .user@example.com:', isValidEmail('.user@example.com'));

// US Phone tests
console.log('\nUS Phone:');
console.log('  (212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('  212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('  2125557890:', isValidUSPhone('2125557890'));
console.log('  +1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('  012-555-7890:', isValidUSPhone('012-555-7890'));

// Argentine Phone tests
console.log('\nArgentine Phone:');
console.log('  +54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('  011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('  +54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('  0341 4234567:', isValidArgentinePhone('0341 4234567'));

// Name tests
console.log('\nName:');
console.log('  Jane Doe:', isValidName('Jane Doe'));
console.log('  José María:', isValidName('José María'));
console.log("  O'Connor:", isValidName("O'Connor"));
console.log('  X Æ A-12:', isValidName('X Æ A-12'));

// Credit Card tests
console.log('\nCredit Card:');
console.log('  4111111111111111 (Visa):', isValidCreditCard('4111111111111111'));
console.log('  5500000000000004 (Mastercard):', isValidCreditCard('5500000000000004'));
console.log('  340000000000009 (AmEx):', isValidCreditCard('340000000000009'));
console.log('  4111111111111112 (Invalid Luhn):', isValidCreditCard('4111111111111112'));

console.log('\n=== Testing Transformations ===\n');

// Capitalize sentences
console.log('Capitalize Sentences:');
console.log('  Input: "hello.world.how are you?"');
console.log('  Output:', capitalizeSentences('hello.world.how are you?'));

// Extract URLs
console.log('\nExtract URLs:');
console.log('  Input: "Visit https://example.com/path?q=test and http://test.org!"');
console.log('  Output:', extractUrls('Visit https://example.com/path?q=test and http://test.org!'));

// Enforce HTTPS
console.log('\nEnforce HTTPS:');
console.log('  Input: "http://example.com and https://secure.com"');
console.log('  Output:', enforceHttps('http://example.com and https://secure.com'));

// Rewrite docs URLs
console.log('\nRewrite Docs URLs:');
console.log('  Input: "http://example.com/docs/api and http://example.com/docs/guide?foo=bar"');
console.log('  Output:', rewriteDocsUrls('http://example.com/docs/api and http://example.com/docs/guide?foo=bar'));

// Extract year
console.log('\nExtract Year:');
console.log('  12/25/2023:', extractYear('12/25/2023'));
console.log('  13/01/2023:', extractYear('13/01/2023'));
console.log('  02/30/2023:', extractYear('02/30/2023'));
console.log('  invalid:', extractYear('invalid'));

console.log('\n=== Testing Puzzles ===\n');

// Find prefixed words
console.log('Find Prefixed Words:');
console.log('  Input: "unhappy undo unusual" prefix: "un" exceptions: ["undo"]');
console.log('  Output:', findPrefixedWords('unhappy undo unusual', 'un', ['undo']));

// Find embedded token
console.log('\nFind Embedded Token:');
console.log('  Input: "abc123xyz" token: "xyz"');
console.log('  Output:', findEmbeddedToken('abc123xyz', 'xyz'));

// Strong password
console.log('\nStrong Password:');
console.log('  Pass123!:', isStrongPassword('Pass123!'));
console.log('  Password123!:', isStrongPassword('Password123!'));
console.log('  Pass123@abab:', isStrongPassword('Pass123@abab'));

// IPv6 detection
console.log('\nContains IPv6:');
console.log('  2001:db8::1:', containsIPv6('2001:db8::1'));
console.log('  192.168.1.1:', containsIPv6('192.168.1.1'));
