export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with robust regex.
 * Accepts typical addresses, rejects double dots, trailing dots, underscores in domain.
 */
export function isValidEmail(value: string): boolean {
  // Must have exactly one @
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }
  
  const parts = value.split('@');
  const local = parts[0];
  const domain = parts.slice(1).join('@');
  
  // Local part and domain must not be empty
  if (!local || !domain) {
    return false;
  }
  
  // Reject leading or trailing dot in local part
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Reject trailing dot in domain
  if (domain.endsWith('.')) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject underscore in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Validate local part: allow alphanumeric, dots, hyphens, underscores, and special chars
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localRegex.test(local)) {
    return false;
  }
  
  // Validate domain: alphanumeric, hyphens, dots, no leading/trailing dots in each part
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (!part) {
      return false; // Empty part (consecutive dots or trailing dot)
    }
    if (!/^[a-zA-Z0-9-]+$/.test(part)) {
      return false; // Invalid characters in domain part
    }
    if (part.startsWith('-') || part.endsWith('-')) {
      return false; // Hyphen at start or end of domain part
    }
  }
  
  // Domain TLD must be at least 2 chars
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common separators and optional +1.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally 11 with +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Handle optional +1 prefix
  let areaCode: string;
  let remaining: string;
  
  if (digitsOnly.length === 11) {
    // Must start with 1 for country code
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
    areaCode = digitsOnly.substring(1, 4);
    remaining = digitsOnly.substring(4);
  } else {
    areaCode = digitsOnly.substring(0, 3);
    remaining = digitsOnly.substring(3);
  }
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check exchange code (next 3 digits) - also cannot start with 0 or 1
  if (remaining.length < 7) {
    return false;
  }
  
  const exchangeCode = remaining.substring(0, 3);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate the format matches expected patterns
  const pattern = /^(?:\+?1[-.\s]?)?\(?([2-9][0-9]{2})\)?[-.\s]?([2-9][0-9]{2})[-.\s]?([0-9]{4})(?:\s?(?:ext|ex|x)\s?\d+)?$/i;
  
  if (options?.allowExtensions) {
    return pattern.test(value);
  }
  
  return pattern.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match pattern: optional +54, optional 0, optional 9, area code (2-4 digits starting 1-9), subscriber number (6-8 digits)
  const pattern = /^(?:\+54)?(?:0)?(?:9)?([1-9][0-9]{1,3})([0-9]{6,8})$/;
  
  const match = cleaned.match(pattern);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must start with 0 (trunk prefix)
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !value.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and strange names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Regex pattern: allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must contain at least one letter
  const validNamePattern = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!validNamePattern.test(value)) {
    return false;
  }
  
  // Check that the name contains at least one letter (not just symbols/spaces)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with digits (like "X Æ A-12")
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with symbols (anything other than letters, apostrophes, hyphens, spaces)
  const hasInvalidSymbol = /[^a-zA-Z\u00C0-\u017F\u0400-\u04FF\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF\uAC00-\uD7AF\s'-]/.test(value);
  if (hasInvalidSymbol) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with Luhn checksum.
 * Accepts Visa (13-16 digits, starts with 4), Mastercard (16 digits, starts with 51-55 or 2221-2720), AmEx (15 digits, starts with 34 or 37).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-16 digits
  if (!/^\d{13,16}$/.test(cleaned)) {
    return false;
  }
  
  // Check card type prefixes and lengths
  const isVisa = /^4\d{12}(\d{3})?$/.test(cleaned); // 13 or 16 digits
  const isMastercard = /^(?:5[1-5]\d{14}|(?:2[2-9][0-9]{2}|27[0-1][0-9]|2720)\d{12})$/.test(cleaned); // 16 digits
  const isAmEx = /^3[47]\d{13}$/.test(cleaned); // 15 digits
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
