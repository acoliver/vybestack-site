/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]+)\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(match => {
    // Convert to lowercase for comparison, but preserve original case in output
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => lowerMatch === exception.toLowerCase());
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds to ensure proper positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token (not at string start)
  // Using positive lookbehind to ensure token is after a digit
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenPattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc, 123123)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const repeatPattern = new RegExp(`(.{${len}})\\1+`, 'g');
    if (repeatPattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - Full form: 8 groups of 1-4 hex digits separated by colons
  // - Compressed form: :: can replace one or more consecutive groups of zeros
  // - Can be at word boundaries or surrounded by non-hex characters
  
  // Full IPv6 pattern: 8 groups of hex digits
  const fullIPv6 = /(?:^|\s)(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:\s|$)/;
  
  // Compressed IPv6 pattern with :: (can appear at start, middle, or end)
  const compressedIPv6 = /(?:^|\s)(?:[0-9a-fA-F]{1,4}:)*:(?::[0-9a-fA-F]{1,4})*(?:\s|$)/;
  
  // Check if it matches IPv6 pattern
  const isFullIPv6 = fullIPv6.test(value);
  const isCompressedIPv6 = compressedIPv6.test(value);
  
  if (isFullIPv6 || isCompressedIPv6) {
    // Make sure we're not just matching an IPv4 address
    // Extract potential IPv6-like parts
    const parts = value.split(':');
    
    // If there are enough colons for IPv6 (at least 2 for compressed form)
    if (parts.length >= 2) {
      // If we have IPv6 structure and not just IPv4, return true
      if (value.includes('::') || parts.length > 4) {
        return true;
      }
    }
  }
  
  // Simpler check: look for typical IPv6 patterns
  // Must have at least 2 colons and hex digits
  const hasHexDigits = /[0-9a-fA-F]/.test(value);
  
  // Check if it matches compressed form (contains ::)
  const hasCompressedForm = /::/.test(value);
  
  // Check if it matches full form (8 groups of hex with colons)
  const fullFormMatch = value.match(/^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/);
  
  // Check for various compressed forms
  const compressedFormMatch = value.match(/^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*$/);
  
  if (fullFormMatch || compressedFormMatch || (hasCompressedForm && hasHexDigits)) {
    return true;
  }
  
  // Check for IPv6 in longer text
  const ipv6InText = /(?:^|\s|[()[\]])((?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4})|(?:(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*)(?:\s|[()[\]]|$))/;
  
  return ipv6InText.test(value);
}
