/**
 * Capitalize the first character of each sentence, preserve spacing rules.
 * Capitalizes after .?!, inserts single space between sentences, collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single space
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Capitalize first character
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Find sentence boundaries and capitalize
  // Look for sentence-ending punctuation (. ! ?) followed by optional space and lowercase letter
  const sentenceBoundary = /([.!?])\s*([a-z])/g;
  normalized = normalized.replace(sentenceBoundary, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Collapse multiple spaces that might have been introduced
  normalized = normalized.replace(/\s+/g, ' ');
  
  return normalized;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  const urlPattern = /(https?:\/\/[^\s<>"{}|\\^`[\]]+[^.,!?:;\s<>"{}|\\^`[\]])/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?:;]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https://. When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s<>"{}|\\^`[\]]*)/gi;
  
  return text.replace(urlPattern, (match, schemeAndHost, path) => {
    // Always upgrade to https
    const secureScheme = 'https://';
    
    // Check if we should skip host rewrite (dynamic hints)
    const hasDynamicHints = /\/cgi-bin|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite to docs.example.com for docs paths without dynamic hints
      return secureScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade scheme for non-docs or dynamic paths
      return secureScheme + 'example.com' + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Using 29 for Feb to account for leap years
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
