import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate input
    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    // Check if parameters are valid numbers
    if (pageParam !== undefined && (isNaN(Number(pageParam)) || Number(pageParam) <= 0)) {
      return res.status(400).json({ error: 'Page parameter must be a positive number' });
    }
    
    if (limitParam !== undefined && (isNaN(Number(limitParam)) || Number(limitParam) <= 0 || Number(limitParam) > 100)) {
      return res.status(400).json({ error: 'Limit parameter must be a positive number not exceeding 100' });
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      return res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
