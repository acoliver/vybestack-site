import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Dynamic import for sql.js
const initSqlJs = async () => {
  const sqlModule = await import('sql.js');
  return sqlModule.default();
};

const initDatabase = async () => {
  try {
    const SQL = await initSqlJs();
    
    // Path to database file
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    let db: unknown;
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const dbData = fs.readFileSync(dbPath);
      db = new SQL.Database(dbData.buffer);
      console.log('Loaded existing database from:', dbPath);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read and execute schema
      const schemaPath = path.join(__dirname, '../db/schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        (db as { run: (sql: string) => void }).run(schema);
        console.log('Created new database with schema from:', schemaPath);
      } else {
        throw new Error('Schema file not found at: ' + schemaPath);
      }
      
      // Save the initial database
      const data = (db as { export: () => Uint8Array }).export();
      const dataDir = path.dirname(dbPath);
      
      // Ensure data directory exists
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Saved new database to:', dbPath);
    }
    
    return db;
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
};

export default initDatabase;