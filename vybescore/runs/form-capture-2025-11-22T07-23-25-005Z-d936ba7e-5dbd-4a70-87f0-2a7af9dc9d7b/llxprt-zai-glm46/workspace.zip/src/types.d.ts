declare module 'sql.js' {
  interface Database {
    run(sql: string): void;
    export(): Uint8Array;
    prepare(sql: string): {
      run(...args: unknown[]): void;
    };
    close(): void;
  }

  interface SqlJsModule {
    Database: new (data?: ArrayBuffer) => Database;
  }

  function initSqlJs(): Promise<SqlJsModule>;
  
  export = initSqlJs;
}