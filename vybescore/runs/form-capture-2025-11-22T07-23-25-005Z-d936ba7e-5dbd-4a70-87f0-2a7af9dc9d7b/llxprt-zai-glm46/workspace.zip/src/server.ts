import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initDatabase from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: unknown;
try {
  db = await initDatabase();
} catch (error) {
  console.error('Failed to initialize database:', error);
  process.exit(1);
}

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^[+]?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
};

const validatePostalCode = (postal: string): boolean => {
  // Allow alphanumeric characters, spaces, and hyphens
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
};

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: {},
    formData: {},
    title: 'Friendly International Contact Form'
  });
});

app.post('/submit', (req, res) => {
  const { 
    first_name,
    last_name,
    street_address,
    city,
    state_province,
    postal_code,
    country,
    email,
    phone
  } = req.body;

  const errors: { [key: string]: string } = {};

  // Validation
  if (!first_name?.trim()) errors.first_name = 'First name is required';
  if (!last_name?.trim()) errors.last_name = 'Last name is required';
  if (!street_address?.trim()) errors.street_address = 'Street address is required';
  if (!city?.trim()) errors.city = 'City is required';
  if (!state_province?.trim()) errors.state_province = 'State/Province/Region is required';
  if (!postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  } else if (!validatePostalCode(postal_code)) {
    errors.postal_code = 'Invalid postal code format';
  }
  if (!country?.trim()) errors.country = 'Country is required';
  if (!email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(email)) {
    errors.email = 'Invalid email format';
  }
  if (!phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(phone)) {
    errors.phone = 'Invalid phone number format';
  }

  // If there are errors, re-render the form
  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData: req.body,
      title: 'Friendly International Contact Form'
    });
  }

  // Insert into database
  try {
    const stmt = (db as { prepare: (sql: string) => { run: (...args: string[]) => void } }).prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run(
      first_name.trim(),
      last_name.trim(),
      street_address.trim(),
      city.trim(),
      state_province.trim(),
      postal_code.trim(),
      country.trim(),
      email.trim(),
      phone.trim()
    );

    // Save database to file
    const data = (db as { export: () => Uint8Array }).export();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, Buffer.from(data));

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while saving your submission. Please try again.' },
      formData: req.body,
      title: 'Friendly International Contact Form'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
const gracefulShutdown = (signal: string) => {
  console.log(`\nReceived ${signal}. Shutting down gracefully...`);
  
  if (db) {
    try {
      (db as { close: () => void }).close();
      console.log('Database connection closed.');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  server.close(() => {
    console.log('Express server closed.');
    process.exit(0);
  });

  // Force shutdown after 10 seconds
  setTimeout(() => {
    console.error('Forced shutdown after timeout.');
    process.exit(1);
  }, 10000);
};

const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Handle shutdown signals
process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

export default app;