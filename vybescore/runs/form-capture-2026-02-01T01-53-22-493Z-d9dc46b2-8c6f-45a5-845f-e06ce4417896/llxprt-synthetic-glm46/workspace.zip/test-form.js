#!/usr/bin/env node

// Test script to verify form submission
const http = require('http');
const fs = require('fs');
const path = require('path');

// Helper function to make HTTP requests
const makeRequest = (options, data) => {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let response = '';
      res.on('data', (chunk) => {
        response += chunk;
      });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: response
        });
      });
    });
    req.on('error', reject);
    if (data) {
      req.write(data);
    }
    req.end();
  });
};

async function testFormSubmission() {
  try {
    // Start the server
    console.log('Testing form submission...');
    
    // Test if the server responds
    const homePageResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/',
      method: 'GET'
    });
    
    console.log('Homepage response status:', homePageResponse.statusCode);
    
    // Submit a form
    const formData = 'firstName=Test&lastName=User&streetAddress=123+Test+St&city=TestCity&stateProvince=TestProvince&postalCode=12345&country=TestCountry&email=test%40example.com&phone=%2B1+555-123-4567';
    
    const submitResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': Buffer.byteLength(formData)
      }
    }, formData);
    
    console.log('Submit response status:', submitResponse.statusCode);
    console.log('Submit response headers:', submitResponse.headers);
    
    // Check for redirect
    if (submitResponse.statusCode === 302) {
      console.log('Form submission successful: redirected to thank-you page');
      
      // Follow redirect to thank-you page
      const thankYouResponse = await makeRequest({
        hostname: 'localhost',
        port: 3535,
        path: '/thank-you',
        method: 'GET'
      });
      
      console.log('Thank-you page status:', thankYouResponse.statusCode);
      
      if (thankYouResponse.statusCode === 200) {
        console.log('Thank-you page loaded successfully');
        
        // Check if database was created
        const dbPath = path.resolve('data/submissions.sqlite');
        
        if (fs.existsSync(dbPath)) {
          console.log('Database file created successfully:', dbPath);
        } else {
          console.log('Database file not found:', dbPath);
        }
      }
    }
  } catch (error) {
    console.error('Test failed:', error.message);
  }
}

testFormSubmission();