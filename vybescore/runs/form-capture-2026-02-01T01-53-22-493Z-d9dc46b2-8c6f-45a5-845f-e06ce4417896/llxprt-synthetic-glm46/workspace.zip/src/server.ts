import express from 'express';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';

// Import sql.js
import initSqlJs, { Database } from 'sql.js';

const __dirname = dirname(fileURLToPath(import.meta.url));
const dataDir = join(__dirname, '..', 'data');
const dbPath = join(dataDir, 'submissions.sqlite');

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

// Validation functions
const validateRequired = (value: string, fieldName: string): string | null => {
  if (!value || value.trim() === '') {
    return `${fieldName} is required`;
  }
  return null;
};

const validateEmail = (email: string): string | null => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return 'Email is not valid';
  }
  return null;
};

const validatePhone = (phone: string): string | null => {
  const phoneRegex = /^[\s+\-()\d]*$/;
  if (!phoneRegex.test(phone)) {
    return 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
  }
  return null;
};

const validatePostalCode = (postalCode: string): string | null => {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]*$/;
  if (!postalCodeRegex.test(postalCode)) {
    return 'Postal code can only contain letters, numbers, spaces, and dashes';
  }
  return null;
};

const validateForm = (data: FormData): ValidationResult => {
  const errors: string[] = [];
  
  // Required field validation
  const requiredError = validateRequired(data.firstName || '', 'First name');
  if (requiredError) errors.push(requiredError);
  
  const requiredError2 = validateRequired(data.lastName || '', 'Last name');
  if (requiredError2) errors.push(requiredError2);
  
  const requiredError3 = validateRequired(data.streetAddress || '', 'Street address');
  if (requiredError3) errors.push(requiredError3);
  
  const requiredError4 = validateRequired(data.city || '', 'City');
  if (requiredError4) errors.push(requiredError4);
  
  const requiredError5 = validateRequired(data.stateProvince || '', 'State / Province / Region');
  if (requiredError5) errors.push(requiredError5);
  
  const requiredError6 = validateRequired(data.postalCode || '', 'Postal / Zip code');
  if (requiredError6) errors.push(requiredError6);
  
  const requiredError7 = validateRequired(data.country || '', 'Country');
  if (requiredError7) errors.push(requiredError7);
  
  const requiredError8 = validateRequired(data.email || '', 'Email');
  if (requiredError8) errors.push(requiredError8);
  
  const requiredError9 = validateRequired(data.phone || '', 'Phone number');
  if (requiredError9) errors.push(requiredError9);
  
  // Format validation
  if (data.email) {
    const emailError = validateEmail(data.email);
    if (emailError) errors.push(emailError);
  }
  
  if (data.phone) {
    const phoneError = validatePhone(data.phone);
    if (phoneError) errors.push(phoneError);
  }
  
  if (data.postalCode) {
    const postalError = validatePostalCode(data.postalCode);
    if (postalError) errors.push(postalError);
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
};

// Database initialization
let db: Database | null = null;

const initDatabase = async () => {
  try {
    // Initialize SQL.js
    const SQL = await initSqlJs();
    
    // Create data directory if it doesn't exist
    if (!existsSync(dataDir)) {
      // Simple directory creation using shell command
      await import('child_process').then(({ execSync }) => {
        execSync(`mkdir -p "${dataDir}"`);
      });
    }
    
    if (existsSync(dbPath)) {
      const fileBuffer = readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      const schema = readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf-8');
      db.run(schema);
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
};

const saveDatabase = () => {
  try {
    if (!db) throw new Error('Database not initialized');
    const data = db.export();
    writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
};

const saveSubmission = (formData: FormData) => {
  try {
    if (!db) throw new Error('Database not initialized');
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName || '',
      formData.lastName || '',
      formData.streetAddress || '',
      formData.city || '',
      formData.stateProvince || '',
      formData.postalCode || '',
      formData.country || '',
      formData.email || '',
      formData.phone || ''
    ]);
    
    stmt.free();
    saveDatabase();
  } catch (error) {
    console.error('Failed to save submission:', error);
  }
};

// Express app setup
const app = express();
const port = process.env.PORT || 3535;

// Configure EJS
app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, '..', 'public')));

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData = req.body as FormData;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData
    });
  }
  
  // Save to database
  saveSubmission(formData);
  
  // Redirect to thank you page with first name for personalization
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName || 'friend')}`);
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
const gracefulShutdown = () => {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
  }
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const startServer = async () => {
  await initDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Export server for testing
  if (process.env.NODE_ENV === 'test') {
    process.on('message', (msg: string) => {
      if (msg === 'shutdown') {
        server.close();
      }
    });
  }
  
  return server;
};

// Only start server if not imported for testing
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { startServer };
