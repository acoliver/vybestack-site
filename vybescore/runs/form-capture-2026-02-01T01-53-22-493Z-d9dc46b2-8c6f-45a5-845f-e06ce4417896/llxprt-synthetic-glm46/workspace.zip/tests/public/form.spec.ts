import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { execSync } from 'child_process';
import { spawn } from 'child_process';
import * as cheerio from 'cheerio';

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // Check that the template file exists and contains required form elements
    const templatePath = path.resolve('src', 'templates', 'form.ejs');
    expect(fs.existsSync(templatePath)).toBe(true);
    
    const templateContent = fs.readFileSync(templatePath, 'utf-8');
    const $ = cheerio.load(templateContent);
    
    // Check if the form exists with all required fields
    expect($('form').length).toBe(1);
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    
    // Clean up database file before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Ensure data directory exists
    if (!fs.existsSync(path.dirname(dbPath))) {
      execSync(`mkdir -p ${path.dirname(dbPath)}`);
    }
    
    // Check all the required files exist
    expect(fs.existsSync(path.resolve('src/server.ts'))).toBe(true);
    expect(fs.existsSync(path.resolve('public/styles.css'))).toBe(true);
    
    // Build the server
    execSync('npm run build', { stdio: 'pipe' });
    expect(fs.existsSync(path.resolve('dist/server.js'))).toBe(true);
    
    // Verify database schema exists
    expect(fs.existsSync(path.resolve('db/schema.sql'))).toBe(true);
    
    // Check database file can be created
    try {
      // Just a basic smoke test to ensure the app can initialize without errors
      const child = spawn('node', ['dist/server.js'], {
        env: { ...process.env, PORT: '3537', NODE_ENV: 'test' },
        stdio: 'pipe'
      });
      
      // Give it a moment to start
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      // Clean up
      child.kill('SIGTERM');
      
      expect(true).toBe(true); // Test passes if we get here
    } catch (error) {
      expect.fail('Server failed to start');
    }
  });
});
