/**
 * Validate Base64 input string format.
 * Uses a comprehensive regex to check for valid Base64 characters only.
 * Accepts Base64 with or without padding.
 */
function isValidBase64(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check if the length is valid (without padding, it should be divisible by 4)
  const hasPadding = input.includes('=');
  if (hasPadding) {
    return input.length % 4 === 0;
  } else {
    // For unpadded Base64, try to decode it to see if it's valid
    try {
      // Add padding and see if it decodes successfully
      const padded = input + '='.repeat((4 - input.length % 4) % 4);
      Buffer.from(padded, 'base64').toString('utf8');
      return true;
    } catch {
      return false;
    }
  }
}

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64 strings.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
