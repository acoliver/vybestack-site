/**
 * Computed closure implementation for derived values.
 */

import type { 
  GetterFn, 
  UpdateFn, 
  Subject, 
  EqualFn,
  Observer
} from '../types/reactive.js'

import { updateObserver, getActiveObserver, ObserverR } from '../types/reactive.js'
import { getDependencyMap } from './input.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Computed is both an Observer (tracks dependencies) and a Subject (notifies its own observers)
  const computed = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value: value as T | undefined,
    updateFn,
  } as Subject<T> & Observer<T>
  
  // Track dependencies for this computed value
  const dependencyMap = getDependencyMap()
  const dependencies = new Set<Subject<unknown>>()
  dependencyMap.set(computed as unknown as Observer<unknown>, dependencies)
  
  // Initial computation
  updateObserver(computed as unknown as Observer<T>)
  
  // Return getter that tracks observers
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      computed.observers.add(observer)
      // Track this dependency
      const deps = dependencyMap.get(observer as unknown as Observer<unknown>)
      if (deps) {
        deps.add(computed as unknown as Subject<unknown>)
      }
    }
    return computed.value!
  }
  
  return getter
}
