/**
 * Callback closure implementation for reactive side effects.
 */

import type { Subject } from '../types/reactive.js'
import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'
import { getDependencyMap } from './input.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Track which subjects this observer depends on
  const dependencies = new Set<Subject<unknown>>()
  const dependencyMap = getDependencyMap()
  dependencyMap.set(observer as Observer<unknown>, dependencies)
  
  // Register observer to track dependencies and execute initially
  updateObserver(observer as Observer<unknown>)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all tracked dependencies
    for (const subject of dependencies) {
      subject.observers.delete(observer)
    }
    
    // Clear the dependency map
    dependencyMap.delete(observer as Observer<unknown>)
  }
}
