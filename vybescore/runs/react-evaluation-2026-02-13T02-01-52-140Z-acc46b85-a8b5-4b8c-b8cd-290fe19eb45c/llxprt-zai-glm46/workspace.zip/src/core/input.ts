/**
 * Input closure implementation for reactive primitives.
 */

import type {
  InputPair,
  Subject,
  Observer,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

import { getActiveObserver, updateObserver } from '../types/reactive.js'

// Track dependencies for callback observers to support unsubscription
// Map from observer to the set of subjects it depends on
const dependencyMap = new WeakMap<Observer<unknown>, Set<Subject<unknown>>>()

export function getDependencyMap(): typeof dependencyMap {
  return dependencyMap
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Track this dependency for callbacks
      const deps = dependencyMap.get(observer as Observer<unknown>)
      if (deps) {
        deps.add(s as Subject<unknown>)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers
    for (const observer of s.observers) {
      updateObserver(observer as Observer<unknown>)
    }
    
    return s.value
  }

  return [read, write]
}
