/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;

  // Split into sentences, capitalize each, and rejoin

  // Split into sentences, capitalize each, and rejoin
  let result = text;

  // First, normalize spacing around sentence punctuation
  result = result.replace(/\s+([.!?])/g, '$1'); // Remove space before punctuation
  result = result.replace(/([.!?])(?!\s|$)/g, '$1 '); // Ensure space after punctuation
  result = result.replace(/\s+/g, ' '); // Collapse multiple spaces

  // Capitalize first letter of each sentence
  const sentences = result.split(/([.!?]\s*)/);
  const capitalizedSentences = sentences.map((sentence, index) => {
    // Even indices are sentences, odd indices are punctuation + space
    if (index % 2 === 0 && sentence.length > 0) {
      // Find first letter character and capitalize it
      return sentence.replace(/^(\s*)([a-z])/, (match, spaces, letter) => {
        return spaces + letter.toUpperCase();
      });
    }
    return sentence;
  });

  return capitalizedSentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // URL regex pattern
  // Matches http://, https://, and protocol-relative URLs
  // Captures the full URL but excludes trailing punctuation
  const urlRegex = /\b(?:https?:\/\/|\/\/)[^\s,.!?)]+(?:\.[^\s,.!?)]+)+/g;

  // Find all matches
  const matches = text.match(urlRegex);

  if (!matches) return [];

  // Clean up URLs by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation characters that might have been captured
    return url.replace(/[.,;:!?()[\]{}"']+$/g, '');
  });

  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;

  // Replace http:// with https://, but leave https:// unchanged
  // This regex matches http:// but not https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;

  // Match http://example.com/docs/... and capture components
  const docsUrlRegex = /(http:\/\/example\.com)(\/docs\/[^?\s&"']*(?![\w]*\.(?:jsp|php|asp|aspx|do|cgi|pl|py)(?:[?\s&"']|$)))/g;

  // Replace with https://docs.example.com/docs/...
  return text.replace(docsUrlRegex, 'https://docs.example.com$2');
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Regex for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;

  const match = dateRegex.exec(value);

  if (!match) return 'N/A';

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Additional validation for month/day combinations
  const isValidDate = (month: number, day: number): boolean => {
    // February (account for leap years)
    if (month === 2) {
      const yearNum = parseInt(year, 10);
      const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
      return day <= (isLeapYear ? 29 : 28);
    }

    // April, June, September, November have 30 days
    if ([4, 6, 9, 11].includes(month)) {
      return day <= 30;
    }

    // All other months have 31 days
    return day <= 31;
  };

  if (!isValidDate(month, day)) return 'N/A';

  return year;
}
