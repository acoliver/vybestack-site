export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email validation regex
  // Local part: alphanumeric + allowed special chars, but no consecutive dots or leading/trailing dots
  // Domain: no underscores, valid structure
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  // Additional validation: no consecutive dots, no dots at the beginning or end
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Domain cannot contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
// Remove whitespace and common separators for validation
  let cleaned = value.replace(/[\s\-().]/g, '');

  // Remove optional +1 country code
  if (cleaned.startsWith('+1')) {
    cleaned = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    cleaned = cleaned.substring(1);
  }

  // Must be exactly 10 digits after removing country code
  if (cleaned.length !== 10) return false;
  
  if (!/^\\d{10}$/.test(cleaned)) return false;
  
  // Area code (first digit) cannot start with 0 or 1
  const areaCode = cleaned.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s -]/g, '');
  
  // Alternative regex that requires trunk prefix when country code is omitted
  const withoutCountryCode = /^(?:9)?0([1-9]\d{1,3})(\d{6,8})$/;
  const withCountryCode = /^\+54(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Test both formats
  const match = withCountryCode.exec(cleaned) || withoutCountryCode.exec(cleaned);
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits and start with 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and other invalid characters
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Additional validation: reject obvious problematic patterns
  // No digits
  if (/[0-9]/.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[\p{L}]/u.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let alternate = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + 1;
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s -]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{13}|2[2-7]0\d{12})$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any card type
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}
