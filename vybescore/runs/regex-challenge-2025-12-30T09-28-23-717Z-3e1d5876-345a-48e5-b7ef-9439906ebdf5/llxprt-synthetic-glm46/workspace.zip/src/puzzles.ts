/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];

  // Escape the prefix for regex usage
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create regex pattern to find words starting with the prefix
  // \b matches word boundaries, \w+ matches the rest of the word
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  // Find all matches
  const matches = text.match(wordPattern);

  if (!matches) return [];

  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => {
      const lowerException = exception.toLowerCase();
      return lowerWord === lowerException || lowerWord.startsWith(lowerException);
    });
  });

  // Remove duplicates while preserving order
  const uniqueMatches = Array.from(new Set(filteredMatches));

  return uniqueMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];

// Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Find all positions where this pattern matches
  const matches: string[] = [];
  let match;

  // Find the regex pattern matches first
  const withoutLookbehind = new RegExp(`\\d${escapedToken}`, 'g');
  while ((match = withoutLookbehind.exec(text)) !== null) {
    matches.push(match[0]);
  }

  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Check minimum length (10 characters)
  if (value.length < 10) return false;

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;

  // Check for at least one digit
  if (!/\d/.test(value)) return false;

  // Check for at least one symbol (special character)
if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for no immediate repeated sequences (e.g., "abab", "abcabc")
  // Look for patterns of length 2 or more that repeat immediately
  const repeatedSequencePattern = /(.{2,})\1/g;
  if (repeatedSequencePattern.test(value)) return false;

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

  // IPv6 address patterns - comprehensive regex for IPv6 including shorthand
  // Full IPv6 with all 8 groups: x:x:x:x:x:x:x:x
  // IPv6 with :: compression
  // IPv6 with embedded IPv4: x:x:x:x:x:x:d.d.d.d
  const ipv6Patterns = [
    // Full IPv6 (8 groups of 1-4 hex digits)
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/g,
    // IPv6 with :: compression 
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{1,4}\b/g,
    // IPv6 with :: at end or beginning
    /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/g,
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b/g,
    // IPv6 with embedded IPv4
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/g
  ];

  // First, remove any IPv4 addresses from the text
  const textWithoutIPv4 = value.replace(ipv4Pattern, '');

  // Then check for IPv6 addresses in the remaining text
  return ipv6Patterns.some(pattern => pattern.test(textWithoutIPv4));
}
