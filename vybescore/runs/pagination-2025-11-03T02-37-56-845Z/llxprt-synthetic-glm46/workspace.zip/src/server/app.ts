import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam === undefined) {
      page = 1; // Default value
    } else {
      // Check if it's a valid number greater than 0
      if (!/^\d+$/.test(pageParam) || Number(pageParam) <= 0) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      // Check for excessive value
      if (Number(pageParam) > 1000) {
        return res.status(400).json({ error: 'Page value is too large' });
      }
      page = Number(pageParam);
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam === undefined) {
      limit = 5; // Default value
    } else {
      // Check if it's a valid number greater than 0
      if (!/^\d+$/.test(limitParam) || Number(limitParam) <= 0) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      // Check for excessive value
      if (Number(limitParam) > 100) {
        return res.status(400).json({ error: 'Limit value is too large' });
      }
      limit = Number(limitParam);
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      return res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
