import { useState } from 'react';
import type { InventoryItem, InventoryPage } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  if (items.length === 0) {
    return <p>No inventory items available.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ data }: { data: InventoryPage }) {
  const { page, hasNext, total } = data;
  
  const hasPrevious = page > 1;
  
  return (
    <div>
      <p>
        Showing {page === 1 ? 1 : ((page - 1) * PAGE_LIMIT) + 1} to {' '}
        {Math.min(page * PAGE_LIMIT, total)} of {total} items
      </p>
      <div>
        <button 
          disabled={!hasPrevious} 
          onClick={() => window.location.search = `?page=${page - 1}`}
        >
          Previous
        </button>
        <button 
          disabled={!hasNext} 
          onClick={() => window.location.search = `?page=${page + 1}`}
        >
          Next
        </button>
      </div>
    </div>
  );
}

function getDefaultPage() {
  if (typeof window !== 'undefined') {
    const params = new URLSearchParams(window.location.search);
    const pageParam = params.get('page');
    return pageParam ? Number(pageParam) : 1;
  }
  return 1;
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(getDefaultPage());
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  // Handle page changes from URL
  if (typeof window !== 'undefined') {
    const urlPage = getDefaultPage();
    if (urlPage !== currentPage) {
      setCurrentPage(urlPage);
    }
  }

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls data={data} />
    </section>
  );
}
