/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9]*\\b`, 'g');
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(exc => exc.toLowerCase()));
  return matches.filter(match => !exceptionsSet.has(match.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find occurrences where token appears after a digit and not at the start
  // Return the full match (digit + token)
  const pattern = new RegExp(`(?<!^)(\\d${escapedToken})`, 'g');
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must not contain whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Must not contain immediate repeated sequences like "abab", "12ab12ab", etc.
  // This checks for any sequence of 2+ characters that repeats immediately
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // Check if it's pure IPv4 (digit groups separated by dots, no colons)
  if (/^\s*\d{1,3}(\.\d{1,3}){3}\s*$/.test(value)) return false;
  if (/\b\d{1,3}(\.\d{1,3}){3}\b/.test(value) && !value.includes(':')) return false;
  
  // IPv6 patterns
  const ipv6Patterns = [
    // Compressed format with ::
    /(^|[\s:])(([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:*)*)(?=[\s:]|$)/,
    
    // Standard IPv6 with multiple colons
    /(^|[\s:])(([0-9a-fA-F]{1,4}:)+[0-9a-fA-F]{1,4})(?=[\s:]|$)/,
    
    // IPv4-mapped IPv6
    /(^|[\s:])(([0-9a-fA-F]{1,4}:)+:(\d{1,3}\.){3}\d{1,3})(?=[\s:]|$)/,
    
    // Loopback and unspecified
    /(^|[\s:])(::1|::)(?=[\s:]|$)/
  ];
  
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  // Additional check for IPv6-like patterns
  if (value.includes(':') && /[0-9a-fA-F]/.test(value)) {
    const parts = value.split(':');
    if (parts.length >= 3) {
      const hexParts = parts.filter(part => /^[0-9a-fA-F]+$/.test(part));
      if (hexParts.length >= 2) {
        return true;
      }
    }
  }
  
  return false;
}
