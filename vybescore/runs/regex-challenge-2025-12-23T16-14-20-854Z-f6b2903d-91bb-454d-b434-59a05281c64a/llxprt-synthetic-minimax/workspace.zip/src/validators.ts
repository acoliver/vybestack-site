export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Check for basic structure: local@domain
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])+$/;
  
  // Must not contain double dots
  if (email.includes('..')) return false;
  
  // Must not end with a dot
  if (email.endsWith('.')) return false;
  
  // Must match the basic pattern
  if (!emailRegex.test(email)) return false;
  
  // Split and check domain part
  const parts = email.split('@');
  if (parts.length !== 2) return false;
  
  const domain = parts[1];
  // Check for underscores in domain
  if (domain.includes('_')) return false;
  
  // Check that domain has at least one dot
  if (!domain.includes('.')) return false;
  
  // Check that each domain segment is valid
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.length === 0 || part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading + for country code
  const cleaned = value.trim();
  
  // Check if it starts with +1 (optional)
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2).trim();
  }
  
  // Remove all non-digit characters
  phoneNumber = phoneNumber.replace(/\D/g, '');
  
  // Must be exactly 10 digits
  if (phoneNumber.length !== 10) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // All digits must be valid
  if (!/^\d{10}$/.test(phoneNumber)) return false;
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern explanation:
  // ^\+?54?       - Optional +54 country code
  // (9)?          - Optional mobile indicator 9 (only after country code)
  // 0?            - Optional trunk prefix 0
  // ([1-9]\d{1,3}) - Area code: 2-4 digits, first digit 1-9
  // (\d{6,8})$    - Subscriber number: 6-8 digits
  
  // First check: If no country code, must have trunk prefix
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  // Comprehensive regex pattern
  const pattern = /^(?:\+54)?(?:9)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(pattern);
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // Check mobile indicator placement: if present, must be after +54 or at start
  const mobileIndicatorPos = cleaned.indexOf('9');
  if (mobileIndicatorPos > 0) {
    const beforeNine = cleaned.substring(0, mobileIndicatorPos);
    // Should be either empty (at start) or after +54
    if (beforeNine !== '+54' && beforeNine !== '') return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) return false;
  
  const name = value.trim();
  
  // Allow letters (unicode), spaces, apostrophes, hyphens, accents
  // \p{L} matches any unicode letter
  // Spaces, apostrophes, hyphens are allowed
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  if (!nameRegex.test(name)) return false;
  
  // Must have at least one letter (not just spaces/hyphens/apostrophes)
  const hasLetter = /[\p{L}]/u.test(name);
  if (!hasLetter) return false;
  
  // Reject obviously fake names like "X Æ A-12"
  // This pattern catches sequences that look like codes rather than names
  const suspiciousPattern = /\b[Xx]\s*[Ææ]\s*[Aa]\s*[-−]\s*\d+\b/;
  if (suspiciousPattern.test(name)) return false;
  
  return true;
}

/**
 * Helper function to run Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  // Process from right to left
  for (let i = digits.length - 2; i >= 0; i -= 2) {
    digits[i] *= 2;
    if (digits[i] > 9) {
      digits[i] -= 9;
    }
  }
  
  const sum = digits.reduce((acc, digit) => acc + digit, 0);
  return sum % 10 === 0;
}

/**
 * Check if card number matches Visa pattern
 */
function isVisa(number: string): boolean {
  return /^4(\d{12}|\d{15}|\d{18})$/.test(number);
}

/**
 * Check if card number matches Mastercard pattern
 */
function isMastercard(number: string): boolean {
  return /^5[1-5]\d{14}$/.test(number) || /^2[2-7]\d{12}$/.test(number);
}

/**
 * Check if card number matches AmEx pattern
 */
function isAmex(number: string): boolean {
  return /^3[47]\d{13}$/.test(number);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Must have valid length for credit cards
  if (cardNumber.length < 13 || cardNumber.length > 19) return false;
  
  // Check if it matches any supported card type
  const isValidType = isVisa(cardNumber) || isMastercard(cardNumber) || isAmex(cardNumber);
  if (!isValidType) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}
