/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, normalize whitespace and ensure proper spacing after sentence terminators
  // Split by sentence terminators while preserving them
  const sentences = text.split(/([.!?]+)/);
  
  let result = '';
  
  for (let i = 0; i < sentences.length; i += 2) {
    let sentence = sentences[i];
    const terminator = sentences[i + 1] || '';
    
    if (sentence.trim().length === 0) {
      result += sentence + terminator;
      continue;
    }
    
    // Clean up the sentence: remove extra spaces but preserve meaningful ones
    sentence = sentence.trim().replace(/\s+/g, ' ');
    
    // Capitalize first letter
    sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    
    result += sentence + terminator;
    
    // Add exactly one space after sentence terminator (except for the last one)
    if (i + 2 < sentences.length) {
      result += ' ';
    }
  }
  
  // Remove trailing space if it exists
  return result.trimEnd();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL pattern that matches http/https URLs
  const urlRegex = /https?:\/\/[^\s"'<>)]*[^\s"'<>).,!?]/gi;
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that commonly follows URLs
    return url.replace(/[.,!?;:]?$/g, '');
  });
  
  return [...new Set(cleanUrls)]; // Remove duplicates
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http:// URLs
  // Group 1: protocol (http://)
  // Group 2: domain
  // Group 3: path
  const urlRegex = /(http:\/\/)([^/\s]+)(\/[^\s]*)?/gi;
  
  return text.replace(urlRegex, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    const hasDynamicHints = /(\?|&|=)|(\.(jsp|php|asp|aspx|do|cgi|pl|py)\b)|(cgi-bin)/i.test(path);
    const isDocsPath = path.startsWith('/docs/');
    
    let newDomain = domain;
    if (isDocsPath && !hasDynamicHints) {
      // Convert example.com to docs.example.com
      newDomain = `docs.${domain}`;
    }
    
    return `${newProtocol}${newDomain}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = new Date(year, month, 0).getDate();
  if (day < 1 || day > daysInMonth) return 'N/A';
  
  // Return the year as string
  return match[3];
}