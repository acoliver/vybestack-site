#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { getFormatter } from '../formats/index.js';
import { validateReportData } from '../utils.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  const format = args[formatIndex + 1];
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');

  return { inputFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const inputPath = path.resolve(args.inputFile);
    if (!fs.existsSync(inputPath)) {
      console.error(`Error: file not found: ${args.inputFile}`);
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      const content = fs.readFileSync(inputPath, 'utf-8');
      jsonData = JSON.parse(content);
    } catch (error) {
      const message = error instanceof Error ? error.message : String(error);
      console.error(`Error: failed to parse JSON: ${message}`);
      process.exit(1);
    }

    const data = validateReportData(jsonData);
    const formatter = getFormatter(args.format);

    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = formatter(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
