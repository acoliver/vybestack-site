/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      if (disposed) return prevValue ?? value!
      return updateFn(prevValue)
    },
  }
  
  // Initial execution to track dependencies
  updateObserver(observer)
  
  // Wrap updateFn to track when dependencies change
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    if (disposed) return prevValue ?? value!
    return originalUpdateFn(prevValue)
  }
  
  return () => {
    disposed = true
  }
}
