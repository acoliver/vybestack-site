/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers: Set<ObserverR> = new Set()
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const read = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer)
    }
    return o.value!
  }
  
  // Initial computation
  updateObserver(o)
  
  // Wrap updateFn to propagate updates to dependent observers
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    o.value = newValue
    // Notify all dependent observers
    for (const observer of observers) {
      updateObserver(observer as Observer<T>)
    }
    return newValue
  }
  
  return read
}
