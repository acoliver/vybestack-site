import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

// ES module equivalent of __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = Number(process.env.PORT) || 3535;

// Set up middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup and initialization
let db: Database;

async function initializeDatabase(): Promise<void> {
  const dbPath = path.resolve('data', 'submissions.sqlite');
  const dataDir = path.dirname(dbPath);
  
  // Ensure data directory exists
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  try {
    // Load SQL.js
    const SQL = await initSqlJs({
      locateFile: (file) => `node_modules/sql.js/dist/${file}`
    });
    
    let existingDb = null;
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      existingDb = new SQL.Database(fileBuffer);
    }
    
    // Create or load database
    db = existingDb || new SQL.Database();
    
    // Read schema file
    const schemaPath = path.resolve('db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Execute schema
    db.run(schema);
    
    console.log('Database initialized successfully');
  } catch (err) {
    console.error('Failed to initialize database:', err);
    throw err;
  }
}

// Save database to file
function saveDatabase(): void {
  try {
    const dbPath = path.resolve('data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (err) {
    console.error('Failed to save database:', err);
    throw err;
  }
}

// Type definitions for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: {
    firstName?: string;
    lastName?: string;
    streetAddress?: string;
    city?: string;
    stateProvince?: string;
    postalCode?: string;
    country?: string;
    email?: string;
    phone?: string;
  };
}

// Validate form data
function validateForm(data: FormData): ValidationResult {
  const errors: ValidationResult['errors'] = {};
  
  // Required field validation
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!emailRegex.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!phoneRegex.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }
  
  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[a-zA-Z0-9\s]+$/.test(data.postalCode)) {
    errors.postalCode = 'Postal code can only contain letters and numbers';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Save form submission to database
function saveSubmission(formData: FormData): void {
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
  } catch (err) {
    console.error('Failed to save submission:', err);
    throw err;
  }
}

// Form routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {}, 
    formData: {} 
  });
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

app.post('/submit', (req, res) => {
  const formData: FormData = req.body as FormData;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      formData: formData
    });
  }
  
  try {
    saveSubmission(formData);
    res.redirect('/thank-you');
  } catch (err) {
    console.error('Error saving submission:', err);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while processing your submission. Please try again.' },
      formData: formData
    });
  }
});

// Start the server after database initialization
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();

// Graceful shutdown handler
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);