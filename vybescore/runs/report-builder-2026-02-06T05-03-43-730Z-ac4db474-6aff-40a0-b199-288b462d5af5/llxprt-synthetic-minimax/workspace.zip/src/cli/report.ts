import { readFileSync, writeFileSync } from 'fs';
import { parseArgs } from 'util';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function loadAndValidateData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(rawData) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: Missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i + 1}: Missing or invalid "amount" field`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    if (typeof error === 'object' && error !== null && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function parseCliArgs(): CliOptions {
  const { values } = parseArgs({
    options: {
      format: {
        type: 'string',
      },
      output: {
        type: 'string',
      },
      includeTotals: {
        type: 'boolean',
      },
    },
    allowPositionals: true,
  });

  // Get positional arguments
  const positionalArgs = process.argv.slice(2);
  const dataFileIndex = positionalArgs.findIndex(arg => !arg.startsWith('--'));
  
  if (dataFileIndex === -1) {
    throw new Error('Missing required data file argument');
  }

  const dataFile = positionalArgs[dataFileIndex];
  const format = values.format;
  
  if (!format) {
    throw new Error('Missing required --format argument');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return {
    dataFile,
    format,
    outputPath: values.output,
    includeTotals: values.includeTotals || false,
  };
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  const options = { includeTotals };
  
  if (format === 'markdown') {
    return renderMarkdown(data, options);
  } else {
    return renderText(data, options);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  try {
    const options = parseCliArgs();
    const data = loadAndValidateData(options.dataFile);
    const report = renderReport(data, options.format, options.includeTotals);
    writeOutput(report, options.outputPath);
  } catch (error) {
    const message = typeof error === 'object' && error !== null && 'message' in error 
      ? String(error.message) 
      : 'Unknown error occurred';
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
