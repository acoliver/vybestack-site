/// <reference types="node" />

declare module 'sql.js' {
  interface SqlJsStatic {
    Database: new (buffer?: Uint8Array) => Database;
    default?: SqlJsStatic;
  }

  interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(values: unknown[]): void;
    free(): void;
  }

  export default function initSql(config?: {
    locateFile?: (file: string) => string;
  }): Promise<SqlJsStatic>;
}