/// <reference path="./sql-js.d.ts" />

import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSql from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class DatabaseManager {
  private db: import('sql.js').Database | null = null;
  private dbPath: string;
  private sql: import('sql.js').SqlJsStatic;

  constructor(sql: import('sql.js').SqlJsStatic) {
    this.sql = sql;
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
  }

  async initialize(): Promise<void> {
    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sql.Database(fileBuffer);
    } else {
      this.db = new this.sql.Database();
      this.createSchema();
    }
  }

  private createSchema(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    this.db.exec(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
  }

  async insertSubmission(data: FormData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.state,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);
    
    stmt.free();
    await this.save();
  }

  async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'state', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || value.trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
      });
    }
  });

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  return errors;
}

// Graceful shutdown function
async function gracefulShutdown(signal: string, app: express.Application, dbManager: DatabaseManager) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    await dbManager.close();
    console.log('Database closed successfully.');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

async function startServer() {
  try {
    // Initialize SQL.js
    const sql = await initSql({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });
    
    const app = express();
    const dbManager = new DatabaseManager(sql);

    // Middleware
    app.use(express.urlencoded({ extended: true }));
    app.use(express.json());
    app.use(express.static(path.join(process.cwd(), 'public')));

    // View engine setup
    app.set('view engine', 'ejs');
    app.set('views', path.join(process.cwd(), 'views'));

    // Routes
    app.get('/', (_req: Request, res: Response) => {
      res.render('contact', {
        title: 'Contact Us',
        formData: {},
        validationErrors: []
      });
    });

    app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: Partial<FormData> = {
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          streetAddress: req.body.streetAddress,
          city: req.body.city,
          state: req.body.state,
          postalCode: req.body.postalCode,
          country: req.body.country,
          email: req.body.email,
          phone: req.body.phone
        };

        const errors = validateFormData(formData);
        
        if (errors.length > 0) {
          return res.status(400).render('contact', {
            title: 'Contact Us',
            formData,
            validationErrors: errors
          });
        }

        await dbManager.insertSubmission(formData as FormData);
        
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error processing form submission:', error);
        res.status(500).send('Internal Server Error');
      }
    });

    app.get('/thank-you', (_req: Request, res: Response) => {
      res.render('thank-you', {
        title: 'Thank You!'
      });
    });

    // Error handling middleware
    app.use((err: Error, _req: Request, res: Response) => {
      console.error(err);
      res.status(500).send('Internal Server Error');
    });

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM', app, dbManager));
    process.on('SIGINT', () => gracefulShutdown('SIGINT', app, dbManager));

    // Initialize database
    await dbManager.initialize();
    console.log('Database initialized successfully.');

    // Server startup
    const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Store server instance for cleanup
    (globalThis as unknown as { server: unknown }).server = server;

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
