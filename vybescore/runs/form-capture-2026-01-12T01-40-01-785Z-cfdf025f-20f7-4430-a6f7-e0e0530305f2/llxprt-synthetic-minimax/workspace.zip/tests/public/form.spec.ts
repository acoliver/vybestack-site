import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { spawn, ChildProcess } from 'child_process';

let server: ChildProcess;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Start the dev server
  server = spawn('npm', ['run', 'dev'], {
    stdio: ['pipe', 'pipe', 'pipe'],
    env: { ...process.env, PORT: '3536' }
  });

  // Wait for server to start
  await new Promise((resolve) => {
    let output = '';
    const timeout = setTimeout(() => {
      resolve(true);
    }, 5000);

    server.stdout?.on('data', (data) => {
      output += data.toString();
      if (output.includes('Server running on port')) {
        clearTimeout(timeout);
        resolve(true);
      }
    });

    server.stderr?.on('data', (data) => {
      console.error('Server error:', data.toString());
    });
  });

  // Give it a bit more time to be ready
  await new Promise(resolve => setTimeout(resolve, 1000));
});

afterAll(() => {
  if (server) {
    server.kill('SIGTERM');
  }
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request('http://localhost:3536')
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check that all required fields are present
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="state"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);

    // Check that labels are properly associated
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('label[for="streetAddress"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('label[for="state"]').length).toBe(1);
    expect($('label[for="postalCode"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);

    // Check that submit button exists
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('validates required fields and shows error messages', async () => {
    // Submit empty form
    const response = await request('http://localhost:3536')
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        state: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      })
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Check that form is re-rendered with errors
    expect($('.error-container').length).toBeGreaterThan(0);
    expect($('input[name="firstName"]').val()).toBe('');
    expect($('input[name="lastName"]').val()).toBe('');
  });

  it('validates email format', async () => {
    const response = await request('http://localhost:3536')
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        state: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      })
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Check that email validation error is shown
    expect($('.error-container').length).toBeGreaterThan(0);
  });

  it('accepts valid international phone numbers', async () => {
    const response = await request('http://localhost:3536')
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        state: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'john@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(302); // Should redirect to thank-you

    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts alphanumeric postal codes', async () => {
    const response = await request('http://localhost:3536')
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'London',
        state: 'Greater London',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('persists submission and redirects to thank-you page', async () => {
    // Ensure clean database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request('http://localhost:3536')
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '789 Test Blvd',
        city: 'Testville',
        state: 'Test State',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'test@example.com',
        phone: '+54 9 11 1234-5678'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');

    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Check thank-you page content
    const thankYouResponse = await request('http://localhost:3536')
      .get('/thank-you')
      .expect(200);

    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank You');
    expect($('.playful-warning').length).toBeGreaterThan(0);
    expect($('.playful-warning p').text()).toContain('Why did you give your info to a stranger');
  });
});
