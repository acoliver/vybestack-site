import { ReportData, CliOptions } from '../interfaces.js';
import { Formatter } from './formatter.js';

export const renderText: Formatter = {
  format(data: ReportData, options: CliOptions): string {
    const { title, summary, entries } = data;
    
    // Compute total
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    
    // Format amount with exactly 2 decimal places
    const formatAmount = (amount: number): string => {
      return `$${amount.toFixed(2)}`;
    };
    
    let output = '';
    
    // Title
    output += `${title}\n`;
    
    // Summary
    output += `${summary}\n`;
    
    // Entries heading
    output += `Entries:\n`;
    
    // Bullet list of entries
    for (const entry of entries) {
      output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
    }
    
    // Add total if requested
    if (options.includeTotals) {
      output += `Total: ${formatAmount(total)}\n`;
    }
    
    return output;
  }
};