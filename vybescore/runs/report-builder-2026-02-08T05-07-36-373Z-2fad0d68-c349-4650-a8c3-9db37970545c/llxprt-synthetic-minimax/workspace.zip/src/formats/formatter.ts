import { ReportData, CliOptions } from '../interfaces.js';

export interface Formatter {
  format(data: ReportData, options: CliOptions): string;
}