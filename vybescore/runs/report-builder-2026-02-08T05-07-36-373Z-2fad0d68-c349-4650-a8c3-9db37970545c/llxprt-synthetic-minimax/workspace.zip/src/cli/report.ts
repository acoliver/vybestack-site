#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, CliOptions } from '../interfaces.js';

interface ParsedArgs {
  dataFile?: string;
  format?: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    includeTotals: false
  };

  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (arg === '--format' || arg === '-f') {
      const nextIndex = i + 1;
      if (nextIndex < argv.length) {
        args.format = argv[nextIndex];
        i++; // Skip next since we consumed it
      }
    } else if (arg === '--output' || arg === '-o') {
      const nextIndex = i + 1;
      if (nextIndex < argv.length) {
        args.outputPath = argv[nextIndex];
        i++; // Skip next since we consumed it
      }
    } else if (!arg.startsWith('--') && !args.dataFile) {
      // Assume this is the data file (first non-flag arg)
      args.dataFile = arg;
    }
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Missing data file argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: Missing --format argument');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Error: Unsupported format "${args.format}"`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const jsonData = JSON.parse(rawData) as ReportData;
    
    // Validate required fields
    if (!jsonData.title || !jsonData.summary || !jsonData.entries) {
      throw new Error('Missing required fields: title, summary, entries');
    }
    
    // Validate entries structure
    for (let i = 0; i < jsonData.entries.length; i++) {
      const entry = jsonData.entries[i];
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: expected { label: string, amount: number }`);
      }
    }
    
    return jsonData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
    } else {
      console.error(`Error: Failed to load data from "${filePath}": ${(error as Error).message}`);
    }
    process.exit(1);
  }
}

function getFormatter(format: string) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Error: Unsupported format "${format}"`);
      process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);
  
  const reportData = loadReportData(args.dataFile!);
  const options: CliOptions = {
    format: args.format as 'markdown' | 'text',
    outputPath: args.outputPath,
    includeTotals: args.includeTotals
  };
  
  const formatter = getFormatter(args.format!);
  const output = formatter.format(reportData, options);
  
  if (args.outputPath) {
    try {
      writeFileSync(args.outputPath, output);
    } catch (error) {
      console.error(`Error: Failed to write output to "${args.outputPath}": ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
