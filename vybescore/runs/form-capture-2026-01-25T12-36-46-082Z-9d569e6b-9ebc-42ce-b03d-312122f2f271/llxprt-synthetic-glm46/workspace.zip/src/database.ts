// Database utilities to isolate sql.js import issues
import { join } from 'path';
import { fileURLToPath } from 'url';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';

// Import sql.js using require to avoid ES module issues
const initSqlJs = require('sql.js');

// Use default export from sql.js
const SqlJs = (initSqlJs as any).default;

export async function createDatabase(): Promise<any> {
  // Ensure data directory exists
  if (!existsSync('data')) {
    mkdirSync('data', { recursive: true });
  }

  let fileBuffer: Uint8Array | null = null;
  const dbPath = 'data/submissions.sqlite';

  // Load existing database if it exists
  if (existsSync(dbPath)) {
    console.log(`Loading existing database from ${dbPath}`);
    const fileContent = readFileSync(dbPath);
    fileBuffer = new Uint8Array(fileContent);
  } else {
    console.log('Creating new database');
  }

  // Initialize SQL.js - use the WASM version for better performance
  const SQL = await SqlJs({
    locateFile: (file: string) => {
      if (file === 'sql-wasm.wasm') {
        return join(fileURLToPath(import.meta.url), '..', '..', 'node_modules', 'sql.js', 'dist', file);
      }
      return join(fileURLToPath(import.meta.url), '..', '..', 'node_modules', 'sql.js', 'dist', file);
    }
  });

  // Create database instance using type assertion
  const database = new (SQL as any).Database(fileBuffer);

  // Initialize schema if this is a new database
  if (!fileBuffer) {
    const schemaSql = readFileSync(join(process.cwd(), 'db', 'schema.sql'), 'utf-8');
    database.run(schemaSql);
    console.log('Database schema initialized');
  }

  return {
    db: database,
    saveToDisk: () => {
      const data = database.export();
      writeFileSync(dbPath, Buffer.from(data));
      console.log('Database saved to disk');
    },
    run: database.run.bind(database),
    exec: database.exec.bind(database),
    prepare: database.prepare.bind(database),
    close: database.close.bind(database)
  };
}