// TypeScript declarations for sql.js
declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: any[]): void;
    exec(sql: string): any[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface Statement {
    run(params?: any[]): void;
    free(): void;
  }
  
  export function initSqlJs(options?: any): Promise<typeof SqlJs>;
  
  export const SqlJs: {
    Database: typeof Database;
  };
}