import express from 'express';
import { join } from 'path';
// @ts-ignore
import { createDatabase } from './database.cjs';

// Type definitions for form submissions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrorItem {
  field: string;
  message: string;
}

// Database instance
let databaseWrapper: any = null;

// Validate form data
function validateFormData(formData: FormData): ValidationErrorItem[] {
  const errors: ValidationErrorItem[] = [];

  // Required field validation
  if (!formData.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!formData.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!formData.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!formData.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!formData.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }

  if (!formData.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation using simple regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!emailRegex.test(formData.email.trim())) {
    errors.push({ field: 'email', message: 'Invalid email format' });
  }

  // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s()\-]+$/;
  if (!formData.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!phoneRegex.test(formData.phone.trim())) {
    errors.push({ field: 'phone', message: 'Invalid phone number format' });
  }

  return errors;
}

// Create Express app
async function createApp(): Promise<express.Application> {
  const app = express();

  // Initialize database
  databaseWrapper = await createDatabase();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(join(process.cwd(), 'public')));

  // Set up EJS as the templating engine
  app.set('view engine', 'ejs');
  app.set('views', join(process.cwd(), 'src', 'templates'));

  // GET / - Render the contact form
  app.get('/', (req: express.Request, res: express.Response) => {
    res.render('form', { 
      errors: [], 
      values: {
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      } 
    });
  });

  // POST /submit - Process form submission
  app.post('/submit', (req: express.Request, res: express.Response) => {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate form data
    const errors = validateFormData(formData);

    if (errors.length > 0) {
      // If validation fails, re-render the form with errors
      res.status(400).render('form', { 
        errors: errors.map(e => e.message), 
        values: formData 
      });
      return;
    }

    try {
      if (!databaseWrapper) {
        throw new Error('Database not initialized');
      }

      // Insert into database
      const stmt = databaseWrapper.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim()
      ]);

      stmt.free();
      
      // Save database to disk
      databaseWrapper.saveToDisk();

      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', { 
        errors: ['An unexpected error occurred. Please try again.'], 
        values: formData 
      });
    }
  });

  // GET /thank-you - Thank you page
  app.get('/thank-you', (req: express.Request, res: express.Response) => {
    try {
      if (!databaseWrapper) {
        throw new Error('Database not initialized');
      }

      // Get the most recent submission to extract the first name
      const result = databaseWrapper.exec('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const firstName = (result[0] && result[0].values && result[0].values[0] && result[0].values[0][0]) ? result[0].values[0][0] : 'friend';
      
      res.render('thank-you', { firstName });
    } catch (error) {
      console.error('Error fetching recent submission:', error);
      // Fallback to generic greeting
      res.render('thank-you', { firstName: 'friend' });
    }
  });

  return app;
}

// Start server
async function startServer(): Promise<any> {
  const port = process.env.PORT || 3535;
  
  try {
    const app = await createApp();
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Handle graceful shutdown
    const gracefulShutdown = (signal: string) => {
      console.log(`Received ${signal}, shutting down gracefully`);
      
      // Close the server
      server.close(() => {
        console.log('HTTP server closed');
        
        // Close database connection
        if (databaseWrapper) {
          try {
            databaseWrapper.close();
            console.log('Database connection closed');
          } catch (error) {
            console.error('Error closing database:', error);
          }
        }
        
        // Exit process
        process.exit(0);
      });
    };

    // Listen for SIGTERM
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    return server;
  } catch (error) {
    console.error('Error starting server:', error);
    process.exit(1);
  }
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
