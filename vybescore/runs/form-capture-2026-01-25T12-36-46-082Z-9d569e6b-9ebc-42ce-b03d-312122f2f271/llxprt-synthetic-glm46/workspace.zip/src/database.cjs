// Database utilities to isolate sql.js import issues
const { join } = require('path');
const { readFileSync, writeFileSync, existsSync, mkdirSync } = require('fs');

// Import sql.js using require
const initSqlJs = require('sql.js');

// Use default export from sql.js
const SqlJs = initSqlJs.default;

async function createDatabase() {
  // Ensure data directory exists
  if (!existsSync('data')) {
    mkdirSync('data', { recursive: true });
  }

  let fileBuffer = null;
  const dbPath = 'data/submissions.sqlite';

  // Load existing database if it exists
  if (existsSync(dbPath)) {
    console.log(`Loading existing database from ${dbPath}`);
    const fileContent = readFileSync(dbPath);
    fileBuffer = new Uint8Array(fileContent);
  } else {
    console.log('Creating new database');
  }

  // Initialize SQL.js - use the WASM version for better performance
  const SQL = await SqlJs({
    locateFile: (file) => {
      if (file === 'sql-wasm.wasm') {
        return join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file);
      }
      return join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file);
    }
  });

  // Create database instance
  const database = new SQL.Database(fileBuffer);

  // Initialize schema if this is a new database
  if (!fileBuffer) {
    const schemaSql = readFileSync(join(process.cwd(), 'db', 'schema.sql'), 'utf-8');
    database.run(schemaSql);
    console.log('Database schema initialized');
  }

  return {
    db: database,
    saveToDisk: () => {
      const data = database.export();
      writeFileSync(dbPath, Buffer.from(data));
      console.log('Database saved to disk');
    },
    run: database.run.bind(database),
    exec: database.exec.bind(database),
    prepare: database.prepare.bind(database),
    close: database.close.bind(database)
  };
}

module.exports = { createDatabase };