export declare function createDatabase(): Promise<{
  db: any;
  saveToDisk: () => void;
  run: (sql: string, params?: any[]) => void;
  exec: (sql: string) => any[];
  prepare: (sql: string) => any;
  close: () => void;
}>;