/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, getActiveObserver, setActiveObserver, removeObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Initialize the callback by running it once to track initial dependencies
  const previousActive = getActiveObserver()
  try {
    setActiveObserver(observer as ObserverR)
    observer.value = updateFn(observer.value)
  } finally {
    setActiveObserver(previousActive)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove the observer and its dependencies
    removeObserver(observer)
  }
}