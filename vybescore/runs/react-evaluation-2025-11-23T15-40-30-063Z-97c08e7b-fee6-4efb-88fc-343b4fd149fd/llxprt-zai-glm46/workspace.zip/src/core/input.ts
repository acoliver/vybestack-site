/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  addDependency,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addSubject
} from '../types/reactive.js'

// Default equality function
const defaultEqual: EqualFn<unknown> = (a, b) => a === b

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> = equal === false 
    ? () => false 
    : typeof equal === 'function' 
      ? equal 
      : defaultEqual as EqualFn<T>

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: new Set()
  }

  // Register the subject
  addSubject(s)

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addDependency(activeObserver as Observer<T>, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed according to equality function
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      notifyObservers(s)
    }
    
    return s.value
  }

  return [read, write]
}