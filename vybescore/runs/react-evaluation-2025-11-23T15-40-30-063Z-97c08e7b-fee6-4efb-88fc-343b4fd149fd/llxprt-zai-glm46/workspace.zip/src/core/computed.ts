/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  EqualFn,
  Subject,
  getActiveObserver,
  setActiveObserver,
  addDependency,
  notifyObservers,
  addSubject
} from '../types/reactive.js'

// Default equality function
const defaultEqual: EqualFn<unknown> = (a, b) => a === b

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> = equal === false 
    ? () => false 
    : typeof equal === 'function' 
      ? equal 
      : defaultEqual as EqualFn<T>

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject to hold observers of this computed value
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn,
    observers: new Set()
  }
  
  // Register the subject
  addSubject(subject)
  
  // Override the update function to notify observers and update subject
  const originalUpdateFn = updateFn
  observer.updateFn = (currentValue) => {
    const newValue = originalUpdateFn(currentValue)
    if (!equalFn(currentValue as T, newValue as T)) {
      observer.value = newValue
      subject.value = newValue as T
      notifyObservers(subject)
    }
    return newValue
  }
  
  // Initialize by running once to track dependencies and compute initial value
  const previousObserver = getActiveObserver()
  try {
    setActiveObserver(observer as ObserverR)
    observer.value = observer.updateFn(observer.value)
    subject.value = observer.value as T
  } finally {
    setActiveObserver(previousObserver)
  }
  
  // Create getter function
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      // When accessed by another observer, track this computed as a dependency
      addDependency(activeObserver as Observer<T>, subject)
    }
    
    return observer.value as T
  }
  
  return getter
}