/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<Observer<unknown>>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Global registry to track all subjects and their dependencies
const subjectRegistry = new Set<Subject<unknown>>()
const observerDependencies = new Map<ObserverR, Set<Subject<unknown>>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function addSubject<T>(subject: Subject<T>): void {
  subjectRegistry.add(subject as Subject<unknown>)
}

export function removeSubject<T>(subject: Subject<T>): void {
  subjectRegistry.delete(subject as Subject<unknown>)
}

export function addDependency<T>(observer: Observer<T>, subject: Subject<T>): void {
  if (!observerDependencies.has(observer as ObserverR)) {
    observerDependencies.set(observer as ObserverR, new Set())
  }
  observerDependencies.get(observer as ObserverR)!.add(subject as Subject<unknown>)
  
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer as Observer<unknown>)
}

export function removeDependency<T>(observer: Observer<T>, subject: Subject<T>): void {
  const deps = observerDependencies.get(observer as ObserverR)
  if (deps) {
    deps.delete(subject as Subject<unknown>)
    if (deps.size === 0) {
      observerDependencies.delete(observer as ObserverR)
    }
  }
  
  if (subject.observers) {
    subject.observers.delete(observer as Observer<unknown>)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observers) {
    for (const observer of subject.observers) {
      const previousActive = getActiveObserver()
      try {
        setActiveObserver(observer)
        observer.value = observer.updateFn(observer.value)
      } finally {
        setActiveObserver(previousActive)
      }
    }
  }
}

export function addObserver<T>(_observer: Observer<T>): void {
  // Global registry - simple implementation for now
}

export function removeObserver<T>(_observer: Observer<T>): void {
  // Remove all dependencies for this observer
  const deps = observerDependencies.get(_observer as ObserverR)
  if (deps) {
    for (const subject of deps) {
      if (subject.observers) {
        subject.observers.delete(_observer as Observer<unknown>)
      }
    }
    observerDependencies.delete(_observer as ObserverR)
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  try {
    activeObserver = observer as ObserverR
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}