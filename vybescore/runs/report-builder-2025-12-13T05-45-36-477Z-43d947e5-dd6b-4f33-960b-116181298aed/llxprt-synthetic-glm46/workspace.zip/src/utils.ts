import { ReportData, ReportEntry } from './types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: data must be an object');
  }

  const reportData = data as Record<string, unknown>;

  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be a string)');
  }

  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be a string)');
  }

  if (!reportData.entries || !Array.isArray(reportData.entries)) {
    throw new Error('Missing or invalid "entries" field (must be an array)');
  }

  const entries: ReportEntry[] = reportData.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }

    if (!('label' in entry) || typeof entry.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "label" field`);
    }

    if (!('amount' in entry) || typeof entry.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid "amount" field`);
    }

    return {
      label: entry.label,
      amount: entry.amount,
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries,
  };
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}