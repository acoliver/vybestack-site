import { FormatFunction } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatters: Record<string, FormatFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}