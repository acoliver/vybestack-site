import { ReportData, RenderOptions, FormatFunction } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

export const renderText: FormatFunction = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  
  // Entry list
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};