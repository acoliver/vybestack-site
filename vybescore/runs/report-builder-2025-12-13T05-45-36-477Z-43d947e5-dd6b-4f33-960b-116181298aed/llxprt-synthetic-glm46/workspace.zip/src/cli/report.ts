#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { exit } from 'node:process';
import { validateReportData } from '../utils.js';
import { formatters, getSupportedFormats } from '../formats/index.js';

interface CLIArgs {
  dataFile: string;
  format: string;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CLIArgs {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const dataFile = args[2];
  let format: string | undefined;
  let outputFile: string | undefined;
  let includeTotals = false;

  // Parse command line arguments
  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        exit(1);
      }
      format = args[i + 1];
      i++; // Skip the next argument as it's the value
    } else if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        exit(1);
      }
      outputFile = args[i + 1];
      i++; // Skip the next argument as it's the value
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument ${args[i]}`);
      exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    exit(1);
  }

  return {
    dataFile,
    format,
    outputFile,
    includeTotals,
  };
}

function main(): void {
  try {
    const { dataFile, format, outputFile, includeTotals } = parseArgs(process.argv);

    // Check if format is supported
    if (!getSupportedFormats().includes(format)) {
      console.error(`Error: Unsupported format "${format}"`);
      exit(1);
    }

    // Read and parse JSON data
    let jsonData;
    try {
      const fileContent = readFileSync(dataFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in ${dataFile}`);
      } else {
        console.error(`Error: Could not read file ${dataFile}`);
      }
      exit(1);
    }

    // Validate data
    const reportData = validateReportData(jsonData);

    // Render report
    const formatter = formatters[format];
    const output = formatter(reportData, { includeTotals });

    // Write output
    if (outputFile) {
      writeFileSync(outputFile, output, 'utf-8');
      console.log(`Report written to ${outputFile}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unknown error occurred');
    }
    exit(1);
  }
}

main();