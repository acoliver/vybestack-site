/**
 * Encode plain text to Base64 using canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with proper padding handling and rejects invalid input.
 */
export function decode(input: string): string {
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Failed to decode Base64 input');
  }

  // Add missing padding if necessary
  const paddingNeeded = (4 - normalized.length % 4) % 4;
  const padded = normalized + '='.repeat(paddingNeeded);

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
