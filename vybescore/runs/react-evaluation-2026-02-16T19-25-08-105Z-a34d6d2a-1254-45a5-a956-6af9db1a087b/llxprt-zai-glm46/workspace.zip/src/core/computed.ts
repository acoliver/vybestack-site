/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
    updating: false,
    observers: new Set(),
  }
  
  // The subject that holds this computed's dependencies (observers of this computed)
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  // Track dependencies on first computation
  updateObserver(o)
  
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    // If another observer is active, track this computed as a dependency
    if (activeObserver && activeObserver !== o) {
      s.observers.add(activeObserver)
      // Also add to the observer's observers set for notification
      if (!o.observers) {
        o.observers = new Set()
      }
      o.observers.add(activeObserver)
    }
    return o.value!
  }
  
  return getter
}
