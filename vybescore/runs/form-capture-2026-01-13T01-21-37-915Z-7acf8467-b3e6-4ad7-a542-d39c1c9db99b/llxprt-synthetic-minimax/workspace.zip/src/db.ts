import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

let db: Database | null = null;

const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

// Create data directory if it doesn't exist
const dataDir = path.dirname(DB_PATH);
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

export async function initDatabase(): Promise<void> {
  if (db) return;

  try {
    // Find the local wasm file or directory
    const possiblePaths = [
      path.join(process.cwd(), 'node_modules', 'sql.js', 'dist'),
      path.join(process.cwd(), 'dist', 'sql.js'),
    ];
    
    let wasmDir = '';
    for (const potentialPath of possiblePaths) {
      if (fs.existsSync(potentialPath)) {
        if (fs.statSync(potentialPath).isDirectory()) {
          wasmDir = potentialPath;
        } else {
          // Found the wasm file, use its directory
          wasmDir = path.dirname(potentialPath);
        }
        break;
      }
    }

    const SQL = await initSqlJs({
      locateFile: (file) => {
        if (wasmDir) {
          return path.join(wasmDir, file);
        }
        throw new Error('sql.js WASM file not found');
      }
    });

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      
      // Load and execute schema
      if (fs.existsSync(SCHEMA_PATH)) {
        const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
        db.exec(schema);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw new Error('Database initialization failed');
  }
}

export function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initDatabase() first.');
  }
  return db;
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export function saveDatabase(): void {
  if (!db) return;
  
  const binary = db.export();
  fs.writeFileSync(DB_PATH, Buffer.from(binary));
}