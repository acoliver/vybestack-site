import express, { Request, Response } from 'express';
import path from 'node:path';
import { initDatabase, getDatabase, closeDatabase, saveDatabase } from './db.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validateFormData(data: Record<string, string>): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field checks
  const required: (keyof FormData)[] = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  for (const field of required) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required` });
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  return errors;
}

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'views'));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  const errors: ValidationError[] = [];
  const data: Partial<FormData> = {};
  
  res.status(200).render('form', { errors, data });
});

app.post('/submit', (req: Request, res: Response) => {
  const errors = validateFormData(req.body);
  const data: Partial<FormData> = req.body;

  if (errors.length > 0) {
    return res.status(400).render('form', { errors, data });
  }

  try {
    const db = getDatabase();
    
    // Insert submission into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName?.trim() || '',
      data.lastName?.trim() || '',
      data.streetAddress?.trim() || '',
      data.city?.trim() || '',
      data.stateProvince?.trim() || '',
      data.postalCode?.trim() || '',
      data.country?.trim() || '',
      data.email?.trim() || '',
      data.phone?.trim() || ''
    ]);

    // Save database after insertion
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', { 
      errors: [{ field: 'system', message: 'An error occurred. Please try again.' }], 
      data 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err.stack);
  res.status(500).render('form', { 
    errors: [{ field: 'system', message: 'An error occurred. Please try again.' }], 
    data: {} 
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  closeDatabase();
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer() {
  try {
    await initDatabase();
    
    if (import.meta.url === `file://${process.argv[1]}`) {
      app.listen(PORT, () => {
        console.log(`Server running on port ${PORT}`);
      });
    }
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start server
startServer();

export default app;
