import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../dist/server.js';

let server: import('http').Server;
let testApp: import('express').Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  beforeAll(async () => {
    // Clean up any existing test database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Create test instance
    testApp = app;
    
    // Start test server
    server = testApp.listen(0); // Use random port
  });

  afterAll(async () => {
    if (server && server.close) {
      await new Promise((resolve) => {
        server.close(resolve);
      });
    }
    
    // Clean up test database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  it('renders the form with all fields', async () => {
    const response = await request(testApp)
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);

    // Check for form action
    expect($('form[action="/submit"]').length).toBe(1);
    
    // Check for submit button
    expect($('.submit-btn').length).toBe(1);
    
    // Check that form has POST method
    expect($('form[method="POST"]').length).toBe(1);
  });

  it('handles validation errors properly', async () => {
    // Submit empty form
    const response = await request(testApp)
      .post('/submit')
      .send({})
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Check that error container exists
    expect($('.error-container').length).toBe(1);
    
    // Check that form is re-rendered with errors
    expect($('#firstName').length).toBe(1);
    expect($('.submit-btn').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'Illinois',
      postalCode: '62704',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 217 555 0123'
    };

    const response = await request(testApp)
      .post('/submit')
      .send(formData)
      .expect(302);

    // Check redirect to thank-you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Follow redirect and check thank-you page
    const thankYouResponse = await request(testApp)
      .get('/thank-you')
      .expect(200);

    const $ = cheerio.load(thankYouResponse.text);
    
    // Check for thank-you page content
    expect($('.warning-box').length).toBe(1);
    expect($('.thank-you-content').length).toBe(1);
    expect($('.next-steps').length).toBe(1);
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles international phone and postal formats', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'London',
      stateProvince: 'Greater London',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958'
    };

    const response = await request(testApp)
      .post('/submit')
      .send(formData)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
  });

  it('validates email format', async () => {
    const formData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test Blvd',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'invalid-email',
      phone: '+1 555 123 4567'
    };

    const response = await request(testApp)
      .post('/submit')
      .send(formData)
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Check for validation error
    expect($('.error-container').length).toBe(1);
  });

  it('preserves form data on validation errors', async () => {
    const response = await request(testApp)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Springfield',
        stateProvince: 'Illinois',
        postalCode: '62704',
        country: 'United States',
        email: 'invalid-email',
        phone: '+1 217 555 0123'
      })
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Check that form fields preserve entered values
    expect($('#firstName').attr('value')).toBe('John');
    expect($('#email').attr('value')).toBe('invalid-email');
  });
});
