import request from 'supertest';
import { FormServer } from './dist/server.js';

async function debug() {
  const server = new FormServer();
  await server.start();
  
  // Test GET /
  console.log('Testing GET /');
  try {
    const response = await request(server.app).get('/');
    console.log('Status:', response.status);
    console.log('Headers:', response.headers);
    console.log('Body:', response.text ? response.text.substring(0, 200) : 'undefined');
  } catch (error) {
    console.error('Error:', error.message);
  }
  
  // Test POST /submit with valid data
  console.log('\nTesting POST /submit with valid data');
  const validData = {
    firstName: 'John',
    lastName: 'Doe',
    streetAddress: '123 Main St',
    city: 'Springfield',
    stateProvince: 'IL',
    postalCode: '62701',
    country: 'USA',
    email: 'john@example.com',
    phone: '+1 555-123-4567'
  };
  
  console.log('Sending data:', validData);
  try {
    const response = await request(server.app)
      .post('/submit')
      .set('Content-Type', 'application/x-www-form-urlencoded')
      .send(validData);
    console.log('Status:', response.status);
    console.log('Headers:', response.headers);
    if (response.text) {
      console.log('Full Body:');
      console.log(response.text);
      // Extract error messages if they exist
      const errorMatch = response.text.match(/<ul class="error-list">([\s\S]*?)<\/ul>/);
      if (errorMatch) {
        console.log('Error Messages:', errorMatch[1]);
      }
    } else {
      console.log('Body: undefined');
    }
  } catch (error) {
    console.error('Error:', error.message);
  }
  
  await server.shutdown();
}

debug().catch(console.error);