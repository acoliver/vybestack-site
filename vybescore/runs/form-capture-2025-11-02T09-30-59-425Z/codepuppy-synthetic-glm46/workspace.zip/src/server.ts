import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

// Basic interface for Database
type Database = {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): {
    run(params: unknown[]): void;
    free(): void;
  };
  export(): Uint8Array;
  close(): void;
};

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  public readonly app: express.Application;
  private db: Database | null = null;
  private dbPath: string;
  private server: { close: (callback?: () => void) => void } | null = null;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.resolve(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const sqlModule = await import('sql.js');
      const SQL = await sqlModule.default();
      
      // Create data directory if it doesn't exist
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbFile) as Database;
      } else {
        this.db = new SQL.Database() as Database;
        const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
        this.db.run(schema);
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (this.db) {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field].trim().length === 0) {
        const fieldName = field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
        errors.push({ field, message: `${fieldName} is required` });
      }
    }

    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (data.email && !emailRegex.test(data.email.trim())) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation - allow international formats
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (data.phone && !phoneRegex.test(data.phone.trim())) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    // Postal code validation - alphanumeric
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    if (data.postalCode && !postalRegex.test(data.postalCode.trim())) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', { 
        errors: [], 
        values: {} as Partial<FormData>
      });
    });

    this.app.post('/submit', async (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName?.trim() || '',
        lastName: req.body.lastName?.trim() || '',
        streetAddress: req.body.streetAddress?.trim() || '',
        city: req.body.city?.trim() || '',
        stateProvince: req.body.stateProvince?.trim() || '',
        postalCode: req.body.postalCode?.trim() || '',
        country: req.body.country?.trim() || '',
        email: req.body.email?.trim() || '',
        phone: req.body.phone?.trim() || ''
      };

      const errors = this.validateForm(formData);
      
      if (errors.length > 0) {
        return res.status(400).render('form', {
          errors: errors.map(e => e.message),
          values: formData
        });
      }

      try {
        if (this.db) {
          const stmt = this.db.prepare(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          
          stmt.run([
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvince,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);
          
          stmt.free();
          this.saveDatabase();
        }

        res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData
        });
      }
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { 
        firstName 
      });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown handling
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
  }

  public async shutdown(): Promise<void> {
    console.log('Shutting down server...');
    
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    
    if (this.server) {
      this.server.close(() => {
        console.log('Server closed.');
        process.exit(0);
      });
    }
  }
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new FormServer();
  server.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export FormServer class for testing
export { FormServer };
export default FormServer;