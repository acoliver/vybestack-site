declare module 'sql.js' {
  interface Database {
    run(sql: string, ...params: any[]): void;
    prepare(sql: string): {
      run(params: any[]): void;
      free(): void;
    };
    export(): Uint8Array;
    close(): void;
  }
  
  function initSqlJs(): Promise<{
    Database: new(data?: Uint8Array) => Database;
  }>;
  
  export default initSqlJs;
}