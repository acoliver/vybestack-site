/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Clean up extra spaces but preserve sentence structure
  text = text.trim();
  
  // Pattern to match start OR punctuation, then capture spacing and next character
  // We need to preserve the exact spacing structure
  return text.replace(/(^|[.?!])(\s*)([a-zA-Z0-9])/g, (match, punctuation, spacing, nextChar) => {
    // Keep punctuation + spacing + capitalized character
    return punctuation + spacing + nextChar.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs - http or https with domain and optional path
  const urlPattern = /\bhttps?:\/\/[^\s<>"{}|\\^`[]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that might have been captured
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match individual http URLs, stopping at punctuation or whitespace
  const httpUrlPattern = /http:\/\/[a-zA-Z0-9.-]+(?:\/[a-zA-Z0-9.\-_/?&=,%#]*)?(?=[.,;:!?\s]|$)/gi;
  
  return text.replace(httpUrlPattern, (match) => {
    // Extract the hostname and path from the matched URL
    const urlMatch = /http:\/\/([a-zA-Z0-9.-]+)(\/[a-zA-Z0-9.\-_/?&=,%#]*)?/.exec(match);
    
    if (!urlMatch) {
      return 'https:' + match.substring(5); // fallback
    }
    
    const host = urlMatch[1];
    const path = urlMatch[2] || '';
    
    let newUrl = 'https://' + host + path;
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHints(path)) {
      // If host is already docs.something.com, extract the original domain
      const hostParts = host.split('.');
      if (hostParts[0] === 'docs' && hostParts.length >= 3) {
        // docs.company.com -> company.com (already correct hostname)
        newUrl = 'https://' + host + path;
      } else if (hostParts[0] !== 'docs') {
        // company.com -> docs.company.com, preserve the full path including /docs/
        newUrl = 'https://docs.' + host + path;
      }
      // else: docs.company.com stays as is (already correct)
    }
    
    return newUrl;
  });
}

function hasDynamicHints(path: string): boolean {
  // Check for query string indicators
  if (path.includes('?') || path.includes('&') || path.includes('=')) {
    return true;
  }
  
  // Check for dynamic file extensions
  const dynamicExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
  for (const ext of dynamicExtensions) {
    if (path.includes(ext)) {
      return true;
    }
  }
  
  // Check for cgi-bin
  if (path.includes('cgi-bin')) {
    return true;
  }
  
  return false;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic leap year validation for February
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  // Check for leap year in February
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    if (yearNum % 4 !== 0 || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  // Return the year part
  return year;
}
