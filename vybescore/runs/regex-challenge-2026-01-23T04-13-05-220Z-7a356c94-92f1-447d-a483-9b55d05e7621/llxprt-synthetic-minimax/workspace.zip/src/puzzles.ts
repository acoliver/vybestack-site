/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Pattern to match words starting with the prefix
  // Using word boundaries to ensure complete word matching
  const pattern = new RegExp(`\\b${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  return matches.filter(match => !exceptionsSet.has(match.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of digit followed by token
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'gi');
  const matches: string[] = [];
  
  let match;
  while ((match = pattern.exec(text)) !== null) {
    // Return the full match (digit + token)
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length (10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // Look for patterns where the same 2-4 character sequence repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    const subsequence = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === subsequence) {
      return false;
    }
    
    // Check longer sequences too
    if (i < value.length - 5) {
      const longerSeq = value.substring(i, i + 3);
      if (value.substring(i + 3, i + 6) === longerSeq) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, rule out IPv4 addresses to avoid false positives
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern that handles shorthand notation like ::
  // IPv6 consists of 8 groups of 4 hexadecimal digits, separated by colons
  // Shorthand allows :: to represent consecutive zero groups
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  const ipv6PatternWithShorthand = /\b(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{0,4}\b/;
  
  // Also check for IPv6 in square brackets (like [::1] for IPv6 addresses in URLs)
  const bracketIpv6Pattern = /\[[0-9a-fA-F:]+\]/;
  
  return ipv6Pattern.test(value) || ipv6PatternWithShorthand.test(value) || bracketIpv6Pattern.test(value);
}
