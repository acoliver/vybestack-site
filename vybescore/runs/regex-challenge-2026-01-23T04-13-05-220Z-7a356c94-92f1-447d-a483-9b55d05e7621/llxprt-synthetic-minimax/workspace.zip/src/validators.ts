export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern to match valid email format
  // local part: letters, numbers, dots, underscores, plus signs, hyphens
  // domain: letters, numbers, dots, hyphens (no underscores)
  // TLD: letters only, 2+ chars
  const emailPattern = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't have underscores
  const parts = value.split('@');
  if (parts[1]?.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // Check if starts with +1
  if (cleanValue.startsWith('+1')) {
    return isValidUSPhone(cleanValue.slice(2), options);
  }
  
  // Must be 10 digits for US numbers
  const digitsOnly = cleanValue.replace(/\D/g, '');
  if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - can't start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check exchange code (next 3 digits) - can't start with 0 or 1
  const exchangeCode = digitsOnly.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators but keep structure
  let cleanValue = value.replace(/[\s-]/g, '');
  
  // Check for optional country code +54
  let hasCountryCode = false;
  if (cleanValue.startsWith('+54')) {
    cleanValue = cleanValue.slice(3);
    hasCountryCode = true;
  }
  
  // Check for optional trunk prefix 0 and mobile indicator 9
  let hasTrunkPrefix = false;
  
  if (cleanValue.startsWith('0')) {
    cleanValue = cleanValue.slice(1);
    hasTrunkPrefix = true;
  }
  
  if (cleanValue.startsWith('9')) {
    cleanValue = cleanValue.slice(1);
  }
  
  // Now we should have area code + subscriber number
  const digitsOnly = cleanValue.replace(/\D/g, '');
  
  if (digitsOnly.length < 8 || digitsOnly.length > 12) {
    return false;
  }
  
  // Try different area code lengths (2, 3, 4) and see which one works
  for (let areaCodeLength = 2; areaCodeLength <= 4; areaCodeLength++) {
    // Check if we have enough digits left for subscriber (6-8 digits)
    if (areaCodeLength + 6 > digitsOnly.length || areaCodeLength + 8 < digitsOnly.length) {
      continue;
    }
    
    // Get area code
    const areaCode = digitsOnly.substring(0, areaCodeLength);
    
    // Area code must start with 1-9
    if (areaCode[0] === '0') {
      continue;
    }
    
    // Rest is subscriber number
    const subscriberNumber = digitsOnly.substring(areaCodeLength);
    
    // Subscriber must be 6-8 digits
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      // Validation rules:
      // 1. When no country code, must have trunk prefix (landline format)
      if (!hasCountryCode && !hasTrunkPrefix) {
        continue;
      }
      
      // 2. When has country code, mobile indicator is normal for mobiles
      // 3. When has country code and no mobile indicator, it's still valid (landline or mobile without indicator)
      
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern that allows unicode letters with accents, apostrophes, hyphens, and spaces
  // Rejects digits, symbols, and special character sequences
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Must not contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Must not contain symbols except apostrophe and hyphen
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }
  
  // Must not be empty or just whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Must not be too short (at least 2 characters)
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if empty
  if (digitsOnly.length === 0) {
    return false;
  }
  
  // Check for Visa (starts with 4, 13 or 16 digits)
  const isVisa = /^4\d{12}(\d{3})?$/.test(digitsOnly) || /^4\d{15}$/.test(digitsOnly);
  
  // Check for Mastercard (starts with 5[1-5] or directly 51-55, 16 digits)
  const isMastercard = /^5[1-5]\d{14}$/.test(digitsOnly) || /^5[1-5]\d{2}\d{12}$/.test(digitsOnly);
  
  // Check for AmEx (starts with 34 or 37, 15 digits)
  const isAmEx = /^3[47]\d{13}$/.test(digitsOnly);
  
  // If no card type matches, return false
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = true; // Start doubling from the first digit processed (second from right)
  
  // Process digits from right to left, skipping the checksum digit
  for (let i = digits.length - 2; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Add the checksum digit without processing
  const checksumDigit = parseInt(digits[digits.length - 1], 10);
  sum += checksumDigit;
  
  return sum % 10 === 0;
}
