/**
 * Global dependency registry
 */

// Global callback registry
const globalCallbacks = new Set<() => void>()

export function registerGlobalCallback(fn: () => void): () => void {
  globalCallbacks.add(fn)
  return () => {
    globalCallbacks.delete(fn)
  }
}

export function triggerGlobalCallbacks(): void {
  const callbacks = Array.from(globalCallbacks)
  for (const callback of callbacks) {
    callback()
  }
}