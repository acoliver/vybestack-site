/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Active callback tracking 
const activeCallbacks = new Set<() => void>()

export function addActiveCallback(callback: () => void): void {
  activeCallbacks.add(callback)
}

export function removeActiveCallback(callback: () => void): void {
  activeCallbacks.delete(callback)
}

export function getActiveCallbacks(): (() => void)[] {
  return Array.from(activeCallbacks)
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}
export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

// Simplified tracking system for computed values and callbacks
const computedDependencies = new Map<ObserverR, Set<ObserverR>>()

// Track when an observer accesses another observer
export function trackDependency(from: ObserverR, to: ObserverR): void {
  if (!computedDependencies.has(to)) {
    computedDependencies.set(to, new Set())
  }
  computedDependencies.get(to)!.add(from)
}

// Trigger updates when a reactive value changes
export function triggerUpdates(observer: ObserverR): void {
  const dependents = computedDependencies.get(observer)
  if (dependents) {
    for (const dependent of dependents) {
      markDependentAsDirty(dependent)
    }
  }
  
  // Trigger callbacks after marking dependents as dirty
  triggerCallbacks()
}

// Track dirty state for computed values
const dirtyFlags = new WeakMap<ObserverR, boolean>()

function markDependentAsDirty(observer: ObserverR): void {
  dirtyFlags.set(observer, true)
  
  // Also mark all dependents of this computed as dirty
  const dependents = computedDependencies.get(observer)
  if (dependents) {
    for (const dependent of dependents) {
      markDependentAsDirty(dependent)
    }
  }
}

// Check if computed value needs to be recomputed
export function isDirty(observer: ObserverR): boolean {
  return dirtyFlags.get(observer) === true
}

// Mark computed value as clean
export function markClean(observer: ObserverR): void {
  dirtyFlags.set(observer, false)
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    // Mark observer as clean after update
    markClean(observer)
  } finally {
    activeObserver = previous
  }
}

// Callback execution tracking
let lastCallbackExecutions = 0
let currentCallbackExecutions = 0

// Increment callback execution count
export function incrementCallbackExecutions(): void {
  currentCallbackExecutions++
}

// Get the current execution count
export function getCallbackExecutions(): number {
  return currentCallbackExecutions
}

// Reset to check if callbacks executed
export function resetCallbackExecutions(): void {
  lastCallbackExecutions = currentCallbackExecutions
}

// Trigger callbacks and track execution
export function triggerCallbacks(): void {
  currentCallbackExecutions = 0
  
  // Need to track dependencies for callbacks - execute each as an active observer
  const callbacks = getActiveCallbacks()
  for (const callback of callbacks) {
    if (typeof callback === 'function') {
      try {
        // Execute callback to observe its dependencies
        callback()
        incrementCallbackExecutions()
      } catch (error) {
        // Callback failed, remove it to prevent infinite loops
        removeActiveCallback(callback)
      }
    }
  }
}

// Check if callbacks executed since last reset
export function didCallbacksExecute(): boolean {
  return currentCallbackExecutions > lastCallbackExecutions
}

// Keep track of all computed values to automatically mark them as dirty on changes
const allComputedObservers = new Set<ObserverR>()

export function registerComputed(observer: ObserverR): void {
  allComputedObservers.add(observer)
}

export function markAllComputedDirty(except?: ObserverR): void {
  for (const computed of allComputedObservers) {
    if (computed !== except) {
      markDependentAsDirty(computed)
    }
  }
}
