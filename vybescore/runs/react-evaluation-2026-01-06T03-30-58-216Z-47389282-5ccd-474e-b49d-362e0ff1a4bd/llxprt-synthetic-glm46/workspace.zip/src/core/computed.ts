import type { EqualFn, GetterFn, Options, UpdateFn } from '../types/reactive.js'
import { 
  getActiveObserver, 
  trackDependency, 
  isDirty, 
  updateObserver,
  registerComputed,
  markClean 
} from '../types/reactive.js'

/**
 * Creates a computed value that reacts to dependencies.
 * 
 * @param updateFn - Function that computes the value based on dependencies
 * @param value - Optional initial value
 * @param equal - Optional equality function
 * @param options - Optional configuration options
 * @returns A getter function for the computed value
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Create the observer
  const observer = {
    name: options?.name,
    value: value as T,
    updateFn
  }

  // Register this as a computed value for dirty tracking
  registerComputed(observer)

  // Create getter function
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Track dependency if called within another reactive context
      trackDependency(activeObserver, observer)
    }

    // Check if value needs to be recomputed
    if (isDirty(observer)) {
      // Update the computed value by executing the update function
      updateObserver(observer)
    } else {
      // If not dirty, still check if this is the first access
      if (observer.value === undefined) {
        // Initialize the value on first access
        try {
          // Set this as active observer to track dependencies in the update function
          updateObserver(observer)
          markClean(observer)
        } finally {
          // Restore previous active observer
        }
      }
    }

    return observer.value
  }

  return getter
}
