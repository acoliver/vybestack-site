import type { EqualFn, InputPair, Options, Observer } from '../types/reactive.js'
import { getActiveObserver, trackDependency, triggerUpdates } from '../types/reactive.js'

/**
 * Creates a reactive input with getter/setter functionality.
 * 
 * @param value - Initial value for the input
 * @param equal - Optional equality function to determine if values have changed
 * @param options - Optional configuration options
 * @returns A tuple containing getter and setter functions
 */
export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Default equality function using ===
  const defaultEqual: EqualFn<T> = (a: T, b: T) => a === b
  const equalFn = equal || defaultEqual

  // Create the observer with initial value using Subject type instead of Observer
  const observer: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: (newValue?: T): T => {
      if (newValue !== undefined) {
        return newValue
      }
      return observer.value!
    }
  }

  // Store the custom equality function separately since Observer doesn't include equalFn
  const customEqualFn = equalFn

  // Create getter function
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Track dependency if called within another reactive context
      trackDependency(activeObserver, observer)
    }
    return observer.value!
  }

  // Create setter function
  const setter = (newValue: T): T => {
    // Only update if value has changed
    if (!customEqualFn(observer.value!, newValue)) {
      observer.value = newValue
      // Trigger updates to dependents
      triggerUpdates(observer)
    }
    return observer.value!
  }

  return [getter, setter]
}
