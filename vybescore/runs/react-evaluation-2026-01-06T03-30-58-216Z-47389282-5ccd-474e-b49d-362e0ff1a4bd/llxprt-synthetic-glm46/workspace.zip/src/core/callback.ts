import type { UnsubscribeFn, UpdateFn, Options } from '../types/reactive.js'
import { getActiveObserver, trackDependency, addActiveCallback, removeActiveCallback } from '../types/reactive.js'

/**
 * Creates a side-effect callback that reacts to dependency changes.
 * 
 * @param updateFn - Function that executes when dependencies change
 * @param value - Optional initial value
 * @param options - Optional configuration options
 * @returns An unsubscribe function to clean up the callback
 */
export function createCallback<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  options?: Options
): UnsubscribeFn {
  // Create a wrapper object that fits ObserverR interface for tracking
  const callbackObserver = {
    name: options?.name
  }

  // Create the callback function
  const callback = (): void => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Track dependency using the observer wrapper
      trackDependency(activeObserver, callbackObserver)
    }
    
    // Execute the update function 
    updateFn(value)
  }

  // Register the callback
  addActiveCallback(callback)

  

  // Don't execute immediately - let dependencies be tracked when callbacks are registered

  // Return unsubscribe function
  const unsubscribe = (): void => {
    // Remove the callback from active callbacks
    removeActiveCallback(callback)
  }

  return unsubscribe
}
