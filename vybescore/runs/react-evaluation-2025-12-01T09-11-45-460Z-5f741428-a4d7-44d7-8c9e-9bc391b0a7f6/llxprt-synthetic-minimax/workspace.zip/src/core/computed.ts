/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ReactiveNode, 
  updateObserver,
  addDependency,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const node: ReactiveNode<unknown> = {
    name: options?.name,
    value,
    updateFn: updateFn as UpdateFn<unknown>,
    observers: new Set(),
  }

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== node) {
      // Track dependency
      addDependency(node, activeObserver)
    }
    
    // Evaluate the computed value each time it's accessed
    updateObserver(node)
    
    return node.value as T
  }

  return getter
}