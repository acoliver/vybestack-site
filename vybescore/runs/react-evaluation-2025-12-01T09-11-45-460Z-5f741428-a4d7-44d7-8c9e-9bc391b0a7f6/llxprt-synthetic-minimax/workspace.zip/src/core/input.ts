/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  getActiveObserver,
  notifyObservers,
  addDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ReactiveNode
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  const dependents = new Set<ReactiveNode>()
  let currentValue = value

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this as dependent of the active observer
      addDependency(activeObserver, { 
        value: undefined,
        updateFn: () => {
          // This will be called when the input changes
        }
      } as ReactiveNode)
      dependents.add(activeObserver)
    }
    return currentValue
  }

  const write: SetterFn<T> = (newValue) => {
    const oldValue = currentValue
    currentValue = newValue
    
    // Check if value actually changed
    const hasChanged = !_equal || 
      (typeof _equal === 'function' ? !_equal(oldValue, newValue) : oldValue !== newValue)
    
    if (hasChanged) {
      // Create a copy to avoid modification during iteration
      const currentDependents = new Set(dependents)
      for (const dependent of currentDependents) {
        if (!dependent.isDisposed) {
          notifyObservers(dependent)
        }
      }
    }
    
    return currentValue
  }

  return [read, write]
}