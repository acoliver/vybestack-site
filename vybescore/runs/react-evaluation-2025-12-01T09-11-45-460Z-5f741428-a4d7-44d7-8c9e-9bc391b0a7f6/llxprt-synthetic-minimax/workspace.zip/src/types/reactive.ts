/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Legacy types for compatibility
export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Core reactive system with proper generics
export interface ReactiveNode<TValue = unknown> {
  value?: TValue
  updateFn: UpdateFn<TValue>
  name?: string
  observers?: Set<ReactiveNode<unknown>>
  isComputing?: boolean
  isDisposed?: boolean
}

let activeNode: ReactiveNode<unknown> | undefined = undefined

export function getActiveObserver(): ReactiveNode<unknown> | undefined {
  return activeNode
}

export function setActiveObserver(node: ReactiveNode<unknown> | undefined) {
  activeNode = node
}

export function updateObserver<TValue>(observer: ReactiveNode<TValue>): TValue | undefined {
  const previous = activeNode
  activeNode = observer as ReactiveNode<unknown>
  observer.isComputing = true
  
  try {
    const result = observer.updateFn(observer.value)
    observer.value = result
    return result
  } finally {
    observer.isComputing = false
    activeNode = previous
  }
}

export function notifyObservers(observer: ReactiveNode<unknown>) {
  if (observer.observers) {
    const observers = new Set(observer.observers)
    for (const dependent of observers) {
      if (!dependent.isDisposed) {
        updateObserver(dependent)
        notifyObservers(dependent)
      }
    }
  }
}

export function addDependency(source: ReactiveNode<unknown>, dependent: ReactiveNode<unknown>) {
  if (!source.observers) {
    source.observers = new Set()
  }
  source.observers.add(dependent)
}