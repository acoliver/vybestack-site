/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Handle the equal parameter - if it's a boolean, we use Object.is for true or always return false for false
  const equalFn: EqualFn<T> = typeof equal === 'function' 
    ? equal 
    : (equal === true ? Object.is : () => false);

  // Track observers that depend on this input
  const observers = new Set<Observer<T>>();

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver();
    if (observer) {
      // Add observer to our dependency list
      observers.add(observer as Observer<T>);
    }
    return value;
  };

  const write: SetterFn<T> = (nextValue: T) => {
    // Only update if values are not equal
    if (!equalFn(value, nextValue)) {
      value = nextValue;
      // Notify all dependent observers
      observers.forEach(obs => {
        updateObserver(obs);
      });
    }
    return value;
  };

  return [read, write];
}