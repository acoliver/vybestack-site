/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle the equal parameter - if it's a boolean, we use Object.is for true or always return false for false
  const equalFn: EqualFn<T> = typeof equal === 'function' 
    ? equal 
    : (equal === true ? Object.is : () => false);

  // Track dependents (observers that depend on this computed)
  const dependents = new Set<Observer<T>>();

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Before running the update function, set this observer as the active one
      // to track what it depends on
      const newValue = updateFn(prevValue);
      
      if (!equalFn(observer.value!, newValue)) {
        observer.value = newValue;
        // Notify dependent observers when computed value changes
        dependents.forEach(dep => {
          updateObserver(dep);
        });
      }
      return newValue;
    }
  }

  // Run the initial computation
  updateObserver(observer);

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver();
    if (activeObserver) {
      // Track this computed as a dependency of the active observer
      dependents.add(activeObserver as Observer<T>);
    }
    return observer.value as T;
  };

  return read;
}