/**
 * Validate that a string is valid Base64.
 * Valid Base64 contains only A-Z, a-z, 0-9, +, /, and optional = padding at the end.
 * Uses a simple heuristic: check for valid characters and let Node.js' Buffer handle the actual validation.
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid Base64
  if (input.length === 0) {
    return false;
  }

  // Check for valid characters and padding placement
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }

  // Padding must only appear at the end and be 0, 1, or 2 characters
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const afterPadding = input.substring(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      return false;
    }
    if (afterPadding.length > 2) {
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Trim whitespace from input
  const trimmed = input.trim();

  // Validate Base64 format before attempting to decode
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    // Add padding if missing (Node.js Buffer requires proper padding)
    const normalized = trimmed.padEnd(Math.ceil(trimmed.length / 4) * 4, '=');
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
