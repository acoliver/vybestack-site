#!/usr/bin/env node

import * as fs from 'node:fs';
import type { RenderOptions } from '../types.js';
import { getFormatter, validateFormat, type Format } from '../formatters.js';
import { validateReportData } from '../validators.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  let format: Format = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatArg = args[++i];
      if (!formatArg) {
        throw new Error('Error: --format requires a value');
      }

      if (!validateFormat(formatArg)) {
        throw new Error(`Unsupported format: ${formatArg}`);
      }
      format = formatArg;
    } else if (arg === '--output') {
      outputPath = args[++i];
      if (!outputPath) {
        throw new Error('Error: --output requires a value');
      }
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return { inputFile, format, outputPath, includeTotals };
}

function readJsonFile(filePath: string): unknown {
  const content = fs.readFileSync(filePath, 'utf-8');

  try {
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const rawData = readJsonFile(args.inputFile);
    const data = validateReportData(rawData);

    const options: RenderOptions = { includeTotals: args.includeTotals };
    const formatter = getFormatter(args.format);
    const output = formatter.render(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
