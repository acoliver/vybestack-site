/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet.
 * Uses canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with required padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate Base64 input with a more comprehensive check
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check for valid Base64 characters (A-Z, a-z, 0-9, +, /, =) and proper structure
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for proper padding (if present)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const nonPaddingPart = input.substring(0, paddingIndex);
    if (nonPaddingPart.includes('=')) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
    
    // Can have 1 or 2 padding characters max
    const paddingCount = input.length - paddingIndex;
    if (paddingCount > 3) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // The length before padding must have the correct remainder:
    // - If 1 padding char (=): length % 4 should be 3
    // - If 2 padding chars (==): length % 4 should be 2
    const dataLength = paddingIndex;
    const remainder = dataLength % 4;
    
    if (paddingCount === 1 && remainder !== 3) {
      throw new Error('Invalid Base64 input: invalid length for single padding');
    }
    if (paddingCount === 2 && remainder !== 2) {
      throw new Error('Invalid Base64 input: invalid length for double padding');
    }
  } else {
    // Without padding, the length must be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: invalid length');
    }
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: ensure the Base64 was properly decoded
    // If the original input contained null bytes or invalid UTF-8 sequences,
    // Buffer might still decode the Base64 but the result won't be valid UTF-8
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}