/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
  
  // Create pattern to match words with the prefix
  // \b ensures word boundary at the start
  // \w* matches any additional word characters after the prefix
  // \b ensures word boundary at the end
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(ex => word.toLowerCase() === ex.toLowerCase())
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
  
  // Pattern to match token that:
  // - Is preceded by a digit
  // - Is not at the beginning of the string
  
  // Find all tokens that are preceded by a digit
  const pattern = new RegExp(`(\\d)(${escapedToken})`, 'g');
  const results = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Add the digit + token (full match) to results
    results.push(match[1] + match[2]);
  }
  
  return results;
}

/**
 * Validate password strength with comprehensive requirements.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace,
 * no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (immediate repetition or alternating patterns)
  // For example: abab, 123123, aabbcc, etc.
  for (let i = 0; i < value.length / 2; i++) {
    const segment1 = value.substr(i * 2, 2);
    const segment2 = value.substr(i * 2 + 2, 2);
    
    if (segment1 === segment2) {
      return false;
    }
  }
  
  // Also check for repeating single character sequences (like aaa)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses while ensuring IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Simpler IPv6 pattern that excludes IPv4 by not allowing dots
  // Look for patterns with colons but without dots
  const simplePattern = /([0-9a-fA-F]{1,4}:){2,}[0-9a-fA-F]{1,4}|::/;
  
  // First check for IPv4 pattern to avoid false positives
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // Then check for IPv6 pattern
  return simplePattern.test(value);
}