/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 * Ensures exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences (split on ., ?, ! followed by optional spaces or newlines)
  // Process each sentence to capitalize the first letter
  // Rejoin with single spaces between sentences
  
  const sentences = text.split(/([.?!])/);
  let result = '';
  let needSpace = false;
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    const punctuation = sentences[i + 1];
    
    if (sentence) {
      // Process sentence to capitalize first letter and handle spacing
      const trimmed = sentence.trim();
      const capitalized = trimmed ? trimmed[0].toUpperCase() + trimmed.slice(1) : '';
      
      if (capitalized) {
        if (result && needSpace) {
          result += ' ';
        }
        result += capitalized;
      }
    }
    
    if (punctuation) {
      result += punctuation;
      needSpace = true;
    }
  }
  
  // Fix any remaining spacing issues
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlPattern = /https?:\/\/(?:www\.)?[^\s<>"'|^`{}[\]]+/gi;
  
  const urls = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    // Remove trailing punctuation like . , ; : ? ! ) ] } " '
    const cleanUrl = match[0].replace(/[.,;:?!)\]}'"]+$/g, '');
    urls.push(cleanUrl);
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ when applicable.
 * Skip host rewrite for dynamic hints or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then find URLs that need host rewriting
  // Pattern to find URLs with docs path from example.com
  const docsUrlPattern = /(https:\/\/example\.com\/docs\/[^\s"?']*)/gi;
  
  // Replace these URLs with docs.example.com host when applicable
  result = result.replace(docsUrlPattern, (match) => {
    // Check if the URL contains a query string
    const hasQueryString = match.includes('?');
    
    // Skip host rewrite if query string is present
    if (hasQueryString) {
      return match;
    }
    
    // Check if the path contains dynamic hints or legacy extensions
    const containsDynamicHints = /(cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(match);
    
    if (!containsDynamicHints) {
      // Rewrite the host to docs.example.com
      return match.replace('https://example.com/', 'https://docs.example.com/');
    }
    
    return match; // Return original if dynamic hints detected
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for specific month/day combinations
  // For simplicity, we're not accounting for leap years
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}