export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive checks.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, underscores in domains, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation pattern
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for consecutive dots in local or domain part
  if (value.includes('..') || value.includes('.@') || value.includes('@.')) {
    return false;
  }
  
  // Check for underscore in domain part (not allowed in RFC standards)
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Check for domain that doesn't end with a dot and has at least one dot
  if (!value.match(/^.*@.*\..*[a-zA-Z]$/)) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers with support for multiple formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's a valid length
  // At least 10 digits for standard US number, 11 if includes country code
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Extract 10-digit phone number (with or without country code)
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    // If 11 digits, must start with 1 (US country code)
    if (digitsOnly[0] !== '1') {
      return false;
    }
    phoneNumber = digitsOnly.slice(1);
  }
  
  // Check area code validity (can't start with 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers with complex format validation.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const digitsOnly = value.replace(/[ -]/g, '');
  
  // Check for optional +54 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('+54')) {
    phoneNumber = phoneNumber.substring(3);
  }
  
  // Check for optional trunk prefix 0 before area code
  if (phoneNumber.startsWith('0')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check for optional mobile indicator 9 between country/trunk and area code
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  if (phoneNumber.length >= 8 && phoneNumber.length <= 11) {
    // Try 2-4 digit area code
    for (let i = 2; i <= 4; i++) {
      const areaCode = phoneNumber.substring(0, i);
      const subscriberNumber = phoneNumber.substring(i);
      
      // Area code must not start with 0 and subscriber must be 6-8 digits
      if (areaCode[0] !== '0' && subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * Validate personal names with unicode support.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and 'X Æ A-12' style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accented letters, apostrophes, hyphens, and spaces
  // Reject digits and most special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if value contains any digits or disallowed symbols
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with excessive non-letter characters (like 'X Æ A-12')
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  const nonLetterCount = value.length - letterCount;
  
  // If more than half are non-letters (except spaces), reject
  if (nonLetterCount > letterCount / 2) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Validate credit card numbers based on common formats and Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[ -]/g, '');
  
  // Check if it's all digits and has valid length
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Check length based on card type
  const length = digitsOnly.length;
  const firstDigit = digitsOnly.charAt(0);
  const firstTwo = digitsOnly.substring(0, 2);
  
  // Visa: 13 or 16 digits, starts with 4
  if (firstDigit === '4' && (length === 13 || length === 16)) {
    return runLuhnCheck(digitsOnly);
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (length === 16) {
    if ((firstTwo >= '51' && firstTwo <= '55') || 
        (firstTwo >= '22' && firstTwo.substring(0, 3) >= '222' && firstTwo.substring(0, 3) <= '272')) {
      return runLuhnCheck(digitsOnly);
    }
  }
  
  // American Express: 15 digits, starts with 34 or 37
  if ((firstTwo === '34' || firstTwo === '37') && length === 15) {
    return runLuhnCheck(digitsOnly);
  }
  
  return false;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}