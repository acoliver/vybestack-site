import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number): InventoryState {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  useEffect(() => {
    let cancelled = false;

    async function load(): Promise<void> {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        const response = await fetch(`/inventory?page=${page}&limit=${limit}`);
        if (!response.ok) {
          // Handle HTTP error responses including validation errors (400)
          const errorData = await response.json();
          throw new Error(errorData.error || `Request failed with status ${response.status}`);
        }
        const payload = (await response.json()) as InventoryPage;
        if (!cancelled) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (!cancelled) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    load();

    return () => {
      cancelled = true;
    };
    // FIXED: page and limit are now included in dependency array to trigger reloads
  }, [page, limit]);

  return state;
}
