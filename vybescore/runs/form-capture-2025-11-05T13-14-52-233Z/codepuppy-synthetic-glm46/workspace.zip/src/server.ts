import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Type for sql.js database to avoid using any
type SqlJsDatabase = {
  export(): Uint8Array;
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): SqlJsStatement;
  close(): void;
};

type SqlJsStatement = {
  run(...params: unknown[]): void;
  get(): unknown;
  free(): void;
};

type ExpressServer = {
  close(callback?: () => void): void;
};

class FormCaptureServer {
  private app: express.Application;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: SqlJsDatabase | null = null;
  private port: number;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3000', 10);
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    
    // Serve static files from /public
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    
    // Set EJS as view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Import sql.js dynamically
      const sqlModule = await import('sql.js');
      const initSqlJs = sqlModule.default;
      
      // Initialize SQL.js
      const SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });
      
      let dbBuffer: Uint8Array | undefined = undefined;
      
      // Load existing database if it exists
      if (fs.existsSync(dbPath)) {
        const dbData = fs.readFileSync(dbPath);
        dbBuffer = new Uint8Array(dbData);
      }
      
      // Create or open database
      this.db = new SQL.Database(dbBuffer) as SqlJsDatabase;
      
      // Initialize schema if database is new
      if (!dbBuffer) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        this.db.run(schema);
        await this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    try {
      const data = this.db.export();
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateForm(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields: Array<keyof FormData> = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    requiredFields.forEach(field => {
      if (!data[field] || data[field].trim() === '') {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    });

    // Email validation
    if (data.email) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Phone validation - allows international formats
    if (data.phone) {
      const phoneRegex = /^[+]?[\d\s\-()]+$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.push({
          field: 'phone',
          message: 'Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +'
        });
      }
    }

    // Postal code validation - alphanumeric
    if (data.postalCode) {
      const postalRegex = /^[A-Za-z0-9\s-]+$/;
      if (!postalRegex.test(data.postalCode.trim())) {
        errors.push({
          field: 'postalCode',
          message: 'Postal code can only contain letters, numbers, spaces, and dashes'
        });
      }
    }

    return errors;
  }

  private getFieldDisplayName(field: string): string {
    const displayNames: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return displayNames[field] || field;
  }

  private setupRoutes(): void {
    // GET / - render the form
    this.app.get('/', (req: Request, res: Response) => {
      const errors = (req.query.errors as string) ? JSON.parse(req.query.errors as string) : [];
      const values = (req.query.values as string) ? JSON.parse(req.query.values as string) : {};
      
      res.render('form', {
        errors: errors.map((error: ValidationError) => error.message),
        values
      });
    });

    // POST /submit - handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };



        // Validate form
        const errors = this.validateForm(formData);
        
        if (errors.length > 0) {
          // Re-render form with errors
          const query = new URLSearchParams({
            errors: JSON.stringify(errors),
            values: JSON.stringify(formData)
          });
          return res.redirect(`/?${query.toString()}`);
        }

        if (!this.db) {
          throw new Error('Database not initialized');
        }

        // Insert into database
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run(
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        );
        stmt.free();
        
        // Save database to disk
        await this.saveDatabase();
        
        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).send('Internal server error');
      }
    });

    // GET /thank-you - render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      if (!this.db) {
        res.render('thank-you', { firstName: 'Friend' });
        return;
      }
      
      // Get the most recent submission to extract first name
      try {
        const stmt = this.db.prepare('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
        const result = stmt.get();
        stmt.free();
        
        const firstName = result ? (result as { first_name: string }).first_name : 'Friend';
        res.render('thank-you', { firstName });
      } catch (error) {
        console.error('Error fetching submission:', error);
        res.render('thank-you', { firstName: 'Friend' });
      }
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    return new Promise<void>((resolve, reject) => {
      this.server = this.app.listen(this.port, (error?: Error) => {
        if (error) {
          reject(error);
        } else {
          console.log(`Server running on port ${this.port}`);
          resolve();
        }
      });
    });
  }

  public async stop(): Promise<void> {
    return new Promise<void>((resolve) => {
      if (this.server) {
        this.server.close(() => {
          if (this.db) {
            this.db.close();
          }
          console.log('Server stopped gracefully');
          resolve();
        });
      } else {
        if (this.db) {
          this.db.close();
        }
        resolve();
      }
    });
  }

  public close(): void {
    this.stop();
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private server: ExpressServer | null = null;
}

// Create and start server
const server = new FormCaptureServer();

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await server.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await server.stop();
  process.exit(0);
});

// Start the server
server.start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

// Export for testing
export default server;