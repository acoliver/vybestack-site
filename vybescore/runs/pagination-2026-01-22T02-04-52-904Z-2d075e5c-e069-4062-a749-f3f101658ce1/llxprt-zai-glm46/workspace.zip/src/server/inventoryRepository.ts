import type { Database } from 'sql.js';
import type { InventoryPage, InventoryItem } from '../shared/types';

interface ListOptions {
  page?: number;
  limit?: number;
}

interface ValidationError {
  valid: false;
  error: string;
}

interface ValidatedOptions {
  valid: true;
  page: number;
  limit: number;
}

const DEFAULT_PAGE = 1;
const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function validateOptions(opts: ListOptions): ValidationError | ValidatedOptions {
  const { page, limit } = opts;

  const validatedPage = page ?? DEFAULT_PAGE;
  const validatedLimit = limit ?? DEFAULT_LIMIT;

  if (page !== undefined && (isNaN(page) || !Number.isInteger(page) || page < 1)) {
    return { valid: false, error: 'Invalid page: must be a positive integer' };
  }

  if (limit !== undefined && (isNaN(limit) || !Number.isInteger(limit) || limit < 1)) {
    return { valid: false, error: 'Invalid limit: must be a positive integer' };
  }

  if (validatedLimit > MAX_LIMIT) {
    return { valid: false, error: `Invalid limit: cannot exceed ${MAX_LIMIT}` };
  }

  return { valid: true, page: validatedPage, limit: validatedLimit };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: row.id as number,
    name: row.name as string,
    sku: row.sku as string,
    priceCents: row.price_cents as number,
    createdAt: row.created_at as string
  };
}

export function listInventory(db: Database, opts: ListOptions): InventoryPage | { error: string } {
  const validation = validateOptions(opts);

  if (!validation.valid) {
    return { error: validation.error };
  }

  const { page, limit } = validation;

  const countStmt = db.prepare('SELECT COUNT(*) as total FROM inventory');
  countStmt.step();
  const countResult = countStmt.getAsObject() as Record<string, unknown>;
  const total = countResult.total as number;
  countStmt.free();

  const offset = (page - 1) * limit;
  const stmt = db.prepare('SELECT * FROM inventory ORDER BY id LIMIT :limit OFFSET :offset');
  const items: InventoryPage['items'] = [];

  stmt.bind({ ':limit': limit, ':offset': offset });

  while (stmt.step()) {
    const row = stmt.getAsObject() as Record<string, unknown>;
    items.push(mapRow(row));
  }

  stmt.free();

  const hasNext = offset + items.length < total;

  return {
    items,
    page,
    limit,
    total,
    hasNext
  };
}
