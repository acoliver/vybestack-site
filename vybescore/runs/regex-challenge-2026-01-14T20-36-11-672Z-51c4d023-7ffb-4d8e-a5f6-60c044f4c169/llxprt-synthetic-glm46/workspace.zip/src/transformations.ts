/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text by sentence delimiters (.!?)
  const sentences = text.split(/([.!?])/);
  
  let result = '';
  let inSentence = false;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (i % 2 === 0) {
      // This is sentence text
      if (part.length === 0) {
        continue;
      }
      
      // Capitalize first character if this starts a sentence
      const trimmed = part.trim();
      if (trimmed.length > 0) {
        // Add appropriate spacing
        if (inSentence && result !== '') {
          result += ' ';
        } else if (result !== '') {
          result += ' ';
        }
        
        // Capitalize first character
        const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        result += capitalized;
        
        // Remove extra spaces within sentence
        result = result.replace(/\s+/g, ' ');
      }
    } else {
      // This is a punctuation mark
      if (part.length > 0) {
        result += part;
        inSentence = true;
      }
    }
  }
  
  return result.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching common URL formats
  // Group 1 captures the full URL, Group 2 captures potential trailing punctuation
  const urlPattern = /(https?:\/\/[^\s<>"]+)([,.!?;:]*)/gi;
  
  const urls = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    // Get the URL without trailing punctuation
    const url = match[1];
    urls.push(url);
  }
  
  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First ensure all URLs use https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match https://example.com/... URLs
  const urlPattern = /(https:\/\/example\.com\/[^\s'"<>]*)/gi;
  
  result = result.replace(urlPattern, (match) => {
    // Extract the path part after https://example.com
    const pathMatch = match.match(/^https:\/\/example\.com(.*)$/);
    if (pathMatch) {
      const path = pathMatch[1];
      
// Skip host rewrite if path contains cgi-bin, query strings, or legacy extensions
  const excludePattern = /(\/cgi-bin\/|\?|&|=|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/;
      
      // If path starts with /docs/ and doesn't contain exclusions, rewrite host
      if (path.startsWith('/docs/') && !excludePattern.test(path)) {
        return `https://docs.example.com${path}`;
      }
    }
    
    return match;
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  // Validate month/day combination to catch invalid dates like 02/30
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for days in each month (not accounting for leap years in detail)
  const daysInMonth = [
    31, // January
    28, // February
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  let maxDays = daysInMonth[month - 1];
  
  // Handle leap years for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear) {
      maxDays = 29;
    }
  }
  
  if (day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
