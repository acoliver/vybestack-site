export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper structure and rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic structure check
  if (!emailRegex.test(value)) return false;
  
  // No double dots anywhere
  if (value.includes('..')) return false;
  
  // No dot at start or end of local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain cannot have underscores
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;
  
  // Cannot have dot immediately after @
  if (domainPart.startsWith('.')) return false;
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix
 * Rejects impossible area codes (leading 0/1) and short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have 10 digits (standard) or 11 digits (with +1)
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Remove the leading 1 for validation
    const tenDigits = digitsOnly.substring(1);
    return isValidUSPhoneDigits(tenDigits);
  } else if (digitsOnly.length === 10) {
    return isValidUSPhoneDigits(digitsOnly);
  }
  
  return false;
}

// Helper function to validate 10-digit US phone number
function isValidUSPhoneDigits(digits: string): boolean {
  // Area code cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules: Optional country code +54, optional trunk prefix 0, optional mobile indicator 9,
 * area code 2-4 digits (leading 1-9), subscriber 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const clean = value.replace(/[\s-]/g, '');
  
  // Full regex pattern for Argentine phone numbers
  const phonePattern = /^(\+54)?(9)?([1-9]\d{0,3})(\d{6,8})$/;
  
  // Pattern without country code (must start with 0 trunk prefix)
  const localPattern = /^(0)([1-9]\d{0,3})(\d{6,8})$/;
  
  if (phonePattern.test(clean)) {
    const match = clean.match(phonePattern);
    if (match) {
      const [, countryCode, mobileIndicator, areaCode, subscriber] = match;
      void countryCode; // Mark as used for validation
      void mobileIndicator; // Mark as used for validation
      
      // Area code must be 2-4 digits
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      
      // Subscriber must be 6-8 digits
      if (subscriber.length < 6 || subscriber.length > 8) return false;
      
      return true;
    }
  } else if (localPattern.test(clean)) {
    const match = clean.match(localPattern);
    if (match) {
      const [, trunkPrefix, areaCode, subscriber] = match;
      void trunkPrefix; // Mark as used for validation
      
      // Area code must be 2-4 digits
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      
      // Subscriber must be 6-8 digits
      if (subscriber.length < 6 || subscriber.length > 8) return false;
      
      return true;
    }
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Ensure there's at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Must not start or end with space, hyphen, or apostrophe
  if (/^[ \-']|[ \-']$/.test(value)) return false;
  
  // Must not have multiple consecutive spaces, hyphens, or apostrophes
  if (/[  \-']{2,}/.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleanValue)) return false;
  
  // Check length and prefix for common card types
  // Visa: 13 or 16 digits, starts with 4
  if (/^4(\d{12}|\d{15})$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (/^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]|20)\d{12}))$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Amex: 15 digits, starts with 34 or 37
  if (/^3[47]\d{13}$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}

// Helper function to perform Luhn checksum validation
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
