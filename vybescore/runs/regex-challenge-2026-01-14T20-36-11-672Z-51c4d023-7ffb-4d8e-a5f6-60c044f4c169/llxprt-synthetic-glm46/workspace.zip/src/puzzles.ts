/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with the prefix
  // \b is word boundary
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z'\\-]*`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const result = matches.filter(word => {
    return !exceptions.some(exclusion => 
      word.toLowerCase() === exclusion.toLowerCase()
    );
  });
  
  return result;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a different approach since lookbehind might not be supported
  // Find all occurrences and filter for those that follow a digit
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // One uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // One lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // One digit
  if (!/\d/.test(value)) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // One symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // No immediate repeated sequences of 3 or more characters (e.g., aaa, bbb)
  if (/(.)\1\1+/.test(value)) return false;
  
  // No immediate repeated patterns of 2 characters (e.g., abab, cdcd)
  if (/(..)\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv6 address in a larger string with multiple possible formats
  const ipv6Pattern = /[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){7}|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}::[0-9a-fA-F]{0,4}|::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,7}|[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}::[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}|::/g;
  
  return ipv6Pattern.test(value);
}
