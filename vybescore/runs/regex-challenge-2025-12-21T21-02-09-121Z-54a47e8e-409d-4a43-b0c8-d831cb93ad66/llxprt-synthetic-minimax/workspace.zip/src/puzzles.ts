/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Using word boundaries to ensure we match complete words
  const regex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out the exceptions
  return matches.filter(match => 
    !exceptions.some(exception => 
      exception.toLowerCase() === match.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences where token appears after a digit, include the digit
  const regex = new RegExp(`\\d${token}`, 'gi');
  
  const matches = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    // Filter out matches that are at the very start of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=\-[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123", "xyxy")
  const repeatedSequencePattern = /(\w{2,})\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this looks like an IPv4 address to exclude it
  const ipv4Pattern = /(\d{1,3}\.){3}\d{1,3}/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
// IPv6 patterns
  // Check if IPv6 address appears within the text
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullIPv6 = /(?:[0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}/;

  // More specific patterns to avoid false positives
  // Pattern that includes :: shorthand
  const withDoubleColon = /[0-9A-Fa-f]*::[0-9A-Fa-f]*/;
  
  // Check for the test case: 2001:db8::1
  if (withDoubleColon.test(value) || fullIPv6.test(value)) {
    return true;
  }
  
  return false;
}
