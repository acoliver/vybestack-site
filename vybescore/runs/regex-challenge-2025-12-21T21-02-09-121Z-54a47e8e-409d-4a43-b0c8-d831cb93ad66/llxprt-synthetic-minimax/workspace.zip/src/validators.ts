export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (value.includes('..') || 
      value.endsWith('.') || 
      value.includes('@.') ||
      value.includes('.@') ||
      value.includes('@@') ||
      value.includes('._') ||
      value.includes('@_') ||
      !value.includes('@')) {
    return false;
  }

  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9.+_-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for impossible area codes (leading 0 or 1)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1
  if (digits.length === 11) {
    return digits.startsWith('1');
  }
  
  // If 10 digits, check that first digit is not 0 or 1
  if (digits.length === 10) {
    const areaCode = digits.substring(0, 3);
    return areaCode[0] !== '0' && areaCode[0] !== '1';
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other punctuation for processing
  const cleaned = value.replace(/[\s\-().]/g, '');
  
  // When country code is omitted, must start with 0
  if (!cleaned.startsWith('+54')) {
    if (!value.trim().startsWith('0')) {
      return false;
    }
  }
  
  // Pattern: country/trunk + mobile indicator? + area code (2-4 digits, leading 1-9) + subscriber (6-8 digits)
  const patterns = [
    /^\+54(9)?([1-9]\d{1,3})(\d{6,8})$/, // With country code +54
    /^0(9)?([1-9]\d{1,3})(\d{6,8})$/    // Without country code, with trunk 0
  ];
  
  return patterns.some(pattern => pattern.test(cleaned));
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject if empty or contains digits
  if (!value || /\d/.test(value)) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens, and accents
  // This regex covers most international name formats
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Additional checks: no leading/trailing spaces, no consecutive special chars
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  if (value.includes('  ') || // Multiple consecutive spaces
      value.includes("' '") || // Apostrophe separated by spaces
      value.includes('--') ||  // Multiple consecutive hyphens
      /^\s|\s$/.test(value) || // Leading/trailing spaces
      /[^\p{L}\p{M}\s'-]/u.test(value)) { // Any other invalid characters
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check card type and length requirements
  // Visa: starts with 4, 16 digits
  const visaPattern = /^4\d{15}$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  const mastercard51_55 = /^5[1-5]\d{14}$/;
  const mastercard2221_2720 = /^2[2-7]\d{14}$/;
  
  // AmEx: starts with 34 or 37, 15 digits
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if it matches any valid pattern
  const isValidLengthAndPrefix = visaPattern.test(cardNumber) || 
                                 mastercard51_55.test(cardNumber) || 
                                 mastercard2221_2720.test(cardNumber) || 
                                 amexPattern.test(cardNumber);
  
  if (!isValidLengthAndPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  let sum = 0;
  let alternate = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
}
