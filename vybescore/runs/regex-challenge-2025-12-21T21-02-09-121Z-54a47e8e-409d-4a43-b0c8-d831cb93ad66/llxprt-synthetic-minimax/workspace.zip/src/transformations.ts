/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences based on punctuation followed by whitespace
  const sentences = text.split(/([.!?]+\s+)/);
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    // Check if this is a sentence-ending punctuation segment
    if (/^[.!?]+\s+$/.test(sentence)) {
      // The next segment should be the start of a new sentence
      if (i + 1 < sentences.length) {
        const nextSentence = sentences[i + 1];
        // Capitalize the first letter of the new sentence
        sentences[i + 1] = nextSentence.replace(/^[a-z]/, nextSentence[0].toUpperCase());
      }
    }
  }
  
  // Handle the very first sentence (if text doesn't start with punctuation)
  if (sentences.length > 0 && /^[a-z]/.test(sentences[0])) {
    sentences[0] = sentences[0].replace(/^[a-z]/, sentences[0][0].toUpperCase());
  }
  
  // Collapse extra spaces while preserving abbreviations when possible
  return sentences.join('');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlRegex = /\b(?:(?:https?|ftp):\/\/|www\.)[^\s<>"']+/gi;
  
  const urls = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,!?:;]+$/g, '');
    
    // Add protocol if missing (for www. URLs)
    if (url.startsWith('www.')) {
      url = 'http://' + url;
    }
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\/([^\s<>"']+)/gi, 'https://$1');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match HTTP URLs - fixed regex pattern to properly capture domain and path
  const httpUrlRegex = /http:\/\/([a-zA-Z0-9.-]+)([^\s<>"']*)/gi;
  
  return text.replace(httpUrlRegex, (match, host, path) => {
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should prevent host rewrite
      const dynamicHints = ['cgi-bin'];
      const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
      const hasDynamicHints = dynamicHints.some(hint => path.includes(hint));
      const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
      const hasLegacyExtensions = legacyExtensions.some(ext => path.includes(ext));
      
      if (hasDynamicHints || hasQueryString || hasLegacyExtensions) {
        // Just upgrade to HTTPS without changing host
        return `https://${host}${path}`;
      } else {
        // Rewrite host to docs.host.com
        const docsHost = `docs.${host}`;
        return `https://${docsHost}${path}`;
      }
    } else {
      // Just upgrade to HTTPS for non-docs paths
      return `https://${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12) and day (1-31 for simplicity)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (reasonable range)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return year.toString();
}
