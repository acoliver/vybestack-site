/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependents?: Set<ObserverR>
  subjects?: Set<SubjectR>
  // Make ObserverR compatible with SubjectR for dual-purpose objects
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  subjects?: Set<SubjectR>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  dependents?: Set<ObserverR>
  // Observers can also be subjects for notification purposes
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addDependency(subject: SubjectR, observer: ObserverR): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
}

export function addSubjectDependency(observer: ObserverR, subject: SubjectR): void {
  if (!observer.subjects) {
    observer.subjects = new Set()
  }
  observer.subjects.add(subject)
}

export function notifyObservers(subject: SubjectR): void {
  notifyDependents(subject)
}

export function notifyDependents(subject: SubjectR): void {
  if (subject.dependents) {
    // Create a copy of the dependents set to avoid modification during iteration
    const dependents = new Set(subject.dependents)
    dependents.forEach(observer => {
      // Update the dependent
      updateObserver(observer as Observer<unknown>)
      
      // Continue propagation if the observer has dependents
      if ('dependents' in observer && observer.dependents) {
        observer.dependents.forEach(nestedDependent => {
          notifyDependents(nestedDependent as unknown as SubjectR)
        })
      }
    })
  }
}
