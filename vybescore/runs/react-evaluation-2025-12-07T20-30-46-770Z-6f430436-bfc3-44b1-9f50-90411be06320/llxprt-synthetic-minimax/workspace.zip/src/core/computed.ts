/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const get: GetterFn<T> = () => {
    // Set ourselves as the active observer and compute the value
    const previous = getActiveObserver()
    setActiveObserver(o)
    try {
      // First call: use default parameter behavior by calling without args
      // Subsequent calls: use stored value
      let result: T
      if (getFirstCall) {
        result = updateFn()
        getFirstCall = false
      } else {
        result = updateFn(o.value)
      }
      
      // Store the result
      o.value = result
      return result
    } finally {
      setActiveObserver(previous)
    }
  }

  // Track if this is the first call to enable default parameters
  let getFirstCall = true

  // Initial computation - this also establishes dependencies
  setActiveObserver(o)
  let initialValue: T
  if (getFirstCall) {
    initialValue = updateFn()
    getFirstCall = false
  } else {
    initialValue = updateFn(o.value)
  }
  o.value = initialValue
  setActiveObserver(undefined)
  
  return get
}
