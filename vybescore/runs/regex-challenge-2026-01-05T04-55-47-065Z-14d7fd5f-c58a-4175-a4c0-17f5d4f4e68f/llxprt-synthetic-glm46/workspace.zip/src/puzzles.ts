/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words that start with the prefix
  // \b ensures we match whole words only
  const wordPattern = new RegExp(`\\b${prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\w*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exception words
  return matches.filter(match => !exceptions.includes(match));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex usage (in case it contains special regex characters)
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find tokens that appear after digits, matching the entire word including the digit
  // \b ensures we match whole words
  const pattern = new RegExp(`\\b\\d+${escapedToken}\\b`, 'g');
  
  const results = [];
  let match;
  
  // Execute the regex globally and collect matches
  while ((match = pattern.exec(text)) !== null) {
    // Add the entire match (digit + token) to results
    results.push(match[0]);
    
    // Prevent infinite loops on zero-length matches
    if (match[0].length === 0) {
      pattern.lastIndex++;
    }
  }
  
  return results;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  const hasUppercase = /[A-Z]/.test(value);
  if (!hasUppercase) {
    return false;
  }
  
  // Check for at least one lowercase letter
  const hasLowercase = /[a-z]/.test(value);
  if (!hasLowercase) {
    return false;
  }
  
  // Check for at least one digit
  const hasDigit = /\d/.test(value);
  if (!hasDigit) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  if (!hasSymbol) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  const repeatedSequencePattern = /(.{2,})\1+/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns (including shorthand with ::)
  // Standard IPv6 (8 groups of 4 hex digits)
  const standardIPv6 = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with :: (compressed zeros)
  const compressedIPv6 = /^([0-9a-fA-F]{1,4}:){0,7}:([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with IPv4 embedded (the last two groups are IPv4)
  const ipv6WithIPv4 = /^([0-9a-fA-F]{1,4}:){6}(\d{1,3}\.){3}\d{1,3}$/;
  
  // IPv4 pattern (to exclude)
  const ipv4Pattern = /^(\d{1,3}\.){3}\d{1,3}$/;
  
  // Check if it's an IPv4 address only
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Extract possible IPv6 segments from the text 
  const ipv6Match = value.match(/[0-9a-fA-F:]+/g) || [''];
  
  // Check if any segment is an IPv6 address
  return ipv6Match.some(segment => 
    standardIPv6.test(segment) || 
    compressedIPv6.test(segment) || 
    ipv6WithIPv4.test(segment)
  );
}
