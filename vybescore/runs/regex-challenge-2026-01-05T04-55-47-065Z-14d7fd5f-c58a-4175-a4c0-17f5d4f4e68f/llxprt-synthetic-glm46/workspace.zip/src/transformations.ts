/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Return if empty text
  if (!text) return text;
  
  // Ensure first character is capitalized
  let result = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Find all words after punctuation and capitalize them
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return `${punctuation}${letter.toUpperCase()}`;
  });
  
  // Ensure single space after punctuation
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  // Trim trailing spaces
  return result.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs with common patterns: protocol, domain names, and paths
  // This regex will match URLs without trailing punctuation
  const urlPattern = /(https?:\/\/)?(([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,})(\/[^\s]*)?/g;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Filter and clean each URL to remove trailing punctuation
  return matches.map(url => {
    // Trim trailing punctuation marks
    return url.replace(/[.,;:!?]\s*(?=\s|$)/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// URLs with https://
  // Use negative lookahead to avoid replacing https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, ensure all URLs use https://
  let result = text.replace(/http:\/\/\b/g, 'https://');
  
  // Then handle special case for docs.example.com
  // Pattern: https://example.com/docs/...
  const docsPattern = /(https:\/\/example\.com(\/docs\/[^?\s]*))/;
  
  // Check if the URL contains any of the dynamic hints
  result = result.replace(docsPattern, (match, url) => {
    // Check for dynamic hints in the path
    const dynamicHintsPattern = /(\/(cgi-bin|[?&]|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)))/;
    
    // If dynamic hints are present, don't change the host
    if (url.match(dynamicHintsPattern)) {
      return url;
    }
    
    // Otherwise, replace example.com with docs.example.com
    return url.replace('https://example.com', 'https://docs.example.com');
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match the mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = datePattern.exec(value);
  if (!match) {
    return 'N/A';
  }
  
  // Extract and return the year (4th capture group)
  return match[3];
}
