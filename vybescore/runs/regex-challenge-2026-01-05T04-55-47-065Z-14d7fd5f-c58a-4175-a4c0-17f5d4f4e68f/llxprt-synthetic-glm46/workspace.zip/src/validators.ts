export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Local part: alphanumeric characters + dots + + + - + _
  // Can't start or end with dot, can't have consecutive dots
  // Domain part: alphanumeric characters + hyphens + subdomains
  // TLD: at least 2 characters, no underscores
  const emailPattern = /^[a-zA-Z0-9]+([.\-+\w]*[a-zA-Z0-9])?@[a-zA-Z0-9]+([-\\][a-zA-Z0-9]+)*\.[a-zA-Z]{2,}$/;

  // Check for invalid patterns first
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }

  // Check for underscores in domain
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }

  // Final regex validation
  return emailPattern.test(value);
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleaned = value.replace(/\D/g, '');

  // Minimum length is 10 digits (area code + 7-digit number)
  if (cleaned.length < 10) {
    return false;
  }

  // If 11 digits, must start with country code 1
  if (cleaned.length === 11 && !cleaned.startsWith('1')) {
    return false;
  }

  // If more than 11 digits, invalid
  if (cleaned.length > 11) {
    return false;
  }

  // Extract the last 10 digits (or 11 if starting with 1)
  const phoneNumber = cleaned.length === 11 ? cleaned.substring(1) : cleaned;

  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  // Final validation with pattern matching
  const phonePattern = /^\+?[1]?[-\s]?\(?([2-9]\d{2})\)?[-\s]?([2-9]\d{2})[-\s]?(\d{4})$/;
  return phonePattern.test(value);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, trunk prefix 0, mobile indicator 9.
 * Area code must be 2-4 digits (leading digit 1-9).
 * Subscriber number must contain 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the value: remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Pattern for Argentine phone numbers with optional country, trunk, mobile
  const argentinePhonePattern = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;

  // Test the pattern
  const match = argentinePhonePattern.exec(cleaned);
  if (!match) {
    return false;
  }

  const [, countryCode, mobileIndicator, trunkPrefix, areaCode, subscriberNumber] = match;

  // Country code validation: if present, must be +54
  if (countryCode && countryCode !== '+54') {
    return false;
  }

  // When country code is omitted, must begin with trunk prefix 0
  if (!countryCode && !trunkPrefix) {
    return false;
  }

  // Mobile indicator can only be present when country code is present or with trunk prefix
  if (mobileIndicator && !countryCode && !trunkPrefix) {
    return false;
  }

  // Area code must be 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Area code must start with 1-9 (not 0)
  if (areaCode.startsWith('0')) {
    return false;
  }

  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // Format validation using more flexible pattern
  const phonePattern = /^(\+54[\s-]?)?((9)[\s-]?)?([1-9]\d{0,3})[\s-]?(\d{2,4}[\s-]?\d{4})$/;
  return phonePattern.test(value);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Accepts names like "Jean-Claude", "O'Malley", "José", "张伟" but rejects digits and symbols.
 */
export function isValidName(value: string): boolean {
  // Disallow names with digits or common symbol characters not typical in names
  if (/[0-9]/.test(value) || /[!@#$%^*()_+=.[\]{}|"<>?,./]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters, spaces, hyphens, apostrophes, and accented characters
  // \p{L} matches any unicode letter, \s matches spaces
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  // Must not be just special characters and must have at least one letter
  return namePattern.test(value) && /\p{L}/u.test(value);
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa (starts with 4, 13 or 16 digits), Mastercard (starts with 51-55, 16 digits), 
 * and American Express (starts with 34 or 37, 15 digits).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits and has valid length
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check for valid credit card prefix and length
  const visaPattern = /^4(\d{12}|\d{15})$/; // 13 or 16 digits starting with 4
  const mastercardPattern = /^5[1-5]\d{14}$/; // 16 digits starting with 51-55
  const amexPattern = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  // Run Luhn checksum
  const runLuhnCheck = (cardNumber: string): boolean => {
    let sum = 0;
    let isEven = false;
    
    // Process digits from right to left
    for (let i = cardNumber.length - 1; i >= 0; i--) {
      let digit = parseInt(cardNumber[i], 10);
      
      // Double every second digit (starting from the second last digit)
      if (isEven) {
        digit *= 2;
        // If digit > 9, subtract 9
        if (digit > 9) {
          digit -= 9;
        }
      }
      
      sum += digit;
      isEven = !isEven;
    }
    
    // If the total sum is divisible by 10, it's valid
    return sum % 10 === 0;
  };
  
  // Check pattern validity and Luhn checksum
  const validPattern = visaPattern.test(cleaned) || 
                      mastercardPattern.test(cleaned) || 
                      amexPattern.test(cleaned);
  
  return validPattern && runLuhnCheck(cleaned);
}
