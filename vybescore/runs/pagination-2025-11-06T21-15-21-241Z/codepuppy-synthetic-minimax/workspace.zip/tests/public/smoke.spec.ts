import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns first page with correct pagination', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15); // Based on seed data
    expect(response.body.items).toHaveLength(5);
    expect(response.body.hasNext).toBe(true);
    
    // Check that we get the correct first 5 items (IDs 1-5)
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[4].id).toBe(5);
  });

  it('returns second page with correct offset', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.hasNext).toBe(true);
    
    // Check that we get items 6-10
    expect(response.body.items[0].id).toBe(6);
    expect(response.body.items[4].id).toBe(10);
  });

  it('rejects invalid page parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page must be a positive integer');
  });

  it('rejects invalid limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit must be a positive integer not exceeding 100');
  });

  it('returns last page with correct hasNext flag', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.items).toHaveLength(5);
    expect(response.body.hasNext).toBe(false);
    
    // Check that we get items 11-15
    expect(response.body.items[0].id).toBe(11);
    expect(response.body.items[4].id).toBe(15);
  });

  it('returns empty page when requesting beyond available data', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=100&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(100);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.items).toHaveLength(0);
    expect(response.body.hasNext).toBe(false);
  });

  it('respects default values', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Default pagination
    let response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5); // Default limit
    
    // Only page specified
    response = await request(app).get('/inventory?page=2');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5); // Default limit
    expect(response.body.items).toHaveLength(5);
    
    // Only limit specified
    response = await request(app).get('/inventory?limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1); // Default page
    expect(response.body.limit).toBe(3);
    expect(response.body.items).toHaveLength(3);
  });

  it('handles string numeric inputs correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items).toHaveLength(3);
    expect(response.body.items[0].id).toBe(4); // Should start at item 4: (2-1)*3 = 3 offset
  });
});
