/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws errors for clearly invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: must be a non-empty string');
  }

  // Validate Base64 input - should only contain valid characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  const hasPadding = input.includes('=');
  
  // Remove padding for validation, then add it back
  const withoutPadding = input.replace(/=/g, '');
  
  if (!base64Regex.test(withoutPadding)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Check if padding is correct (if present)
  if (hasPadding) {
    const paddingLength = input.length - withoutPadding.length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    // Validate padding position
    if (withoutPadding.length % 4 === 1) {
      throw new Error('Invalid Base64 input: incorrect padding position');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
