#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { getFormatter, Format } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputFile?: string;
  includeTotals?: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as Format;
  const supportedFormats: Format[] = ['markdown', 'text'];
  
  if (!supportedFormats.includes(format)) {
    console.error(`Error: Unsupported format "${format}". Supported formats: ${supportedFormats.join(', ')}`);
    process.exit(1);
  }
  
  const outputIndex = args.indexOf('--output');
  const outputFile = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');
  
  return {
    inputFile,
    format,
    outputFile,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title');
  }
  
  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries array');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid label`);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${i}: missing or invalid amount`);
    }
  }
  
  return data as ReportData;
}

function main() {
  try {
    const args = parseArguments();
    
    // Read and parse input file
    let fileContent: string;
    try {
      fileContent = readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not read file "${args.inputFile}"`);
      process.exit(1);
    }
    
    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${args.inputFile}"`);
      process.exit(1);
    }
    
    // Validate data structure
    const reportData = validateReportData(jsonData);
    
    // Prepare render options
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    
    // Render report
    const formatter = getFormatter(args.format);
    const output = formatter.render(reportData, options);
    
    // Write output
    if (args.outputFile) {
      try {
        writeFileSync(args.outputFile, output, 'utf-8');
        console.log(`Report written to ${args.outputFile}`);
      } catch (error) {
        console.error(`Error: Could not write to file "${args.outputFile}"`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

main();