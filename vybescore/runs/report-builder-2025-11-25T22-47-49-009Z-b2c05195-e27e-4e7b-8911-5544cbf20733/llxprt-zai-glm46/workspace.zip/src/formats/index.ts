import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type Format = 'markdown' | 'text';

export interface Formatter {
  render: (data: ReportData, options?: RenderOptions) => string;
}

export const formatters: Record<Format, Formatter> = {
  markdown: { render: renderMarkdown },
  text: { render: renderText },
};

export function getFormatter(format: Format): Formatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}