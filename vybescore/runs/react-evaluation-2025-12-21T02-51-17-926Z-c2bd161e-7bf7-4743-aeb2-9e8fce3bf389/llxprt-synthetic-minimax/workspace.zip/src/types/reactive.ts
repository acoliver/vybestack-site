/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const subscriptions = new Map<object, Set<ObserverR>>()
const allObservers = new Set<ObserverR>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
    allObservers.add(observer)
  } finally {
    activeObserver = previous
  }
}

export function subscribe<T>(observer: ObserverR, subject: Subject<T>): void {
  const subjectObj = subject as object
  if (!subscriptions.has(subjectObj)) {
    subscriptions.set(subjectObj, new Set())
  }
  subscriptions.get(subjectObj)!.add(observer)
}

export function unsubscribe<T>(observer: ObserverR, subject: Subject<T>): void {
  const subjectObj = subject as object
  const subjectSubscriptions = subscriptions.get(subjectObj)
  if (subjectSubscriptions) {
    subjectSubscriptions.delete(observer)
  }
}

export function notifyDependents<T>(subject: Subject<T>): void {
  const subjectObj = subject as object
  // Notify observers that explicitly subscribed to this subject
  const dependentObservers = subscriptions.get(subjectObj)
  if (dependentObservers) {
    const observers = new Set(dependentObservers)
    for (const observer of observers) {
      updateObserver(observer as Observer<unknown>)
    }
  }
  
  // Also notify all observers in the system (for callbacks and other reactive constructs)
  const observers = new Set(allObservers)
  for (const observer of observers) {
    if (observer !== subject.observer) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}

export function removeObserver(observer: ObserverR): void {
  allObservers.delete(observer)
  // Also remove from all subscription lists
  for (const observerSet of subscriptions.values()) {
    observerSet.delete(observer)
  }
}
