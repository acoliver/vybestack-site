/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UpdateFn,
  Observer,
  UnsubscribeFn,
  updateObserver,
  removeObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Execute the callback immediately to establish dependencies and perform side effects
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from the global tracking
    removeObserver(observer)
  }
}
