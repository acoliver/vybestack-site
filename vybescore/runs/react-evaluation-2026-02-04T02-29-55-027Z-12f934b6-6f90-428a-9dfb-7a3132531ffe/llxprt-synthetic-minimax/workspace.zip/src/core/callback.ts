/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subscribers: new Set(),
  }
  
  let disposed = false
  
  // Set this observer as active to track dependencies
  const prevActive = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute the callback once to establish dependencies
    observer.updateFn = (prev) => {
      const result = updateFn(prev)
      return result
    }
    observer.updateFn(value)
  } finally {
    setActiveObserver(prevActive)
  }
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all its dependencies' subscribers
    if (observer.dependencies) {
      for (const subject of observer.dependencies) {
        if (subject.subscribers) {
          subject.subscribers.delete(observer)
        }
      }
    }
    
    // Clear subscriptions
    if (observer.subscribers) {
      observer.subscribers.clear()
    }
    observer.dependencies?.clear()
    
    // Neutralize the update function
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
