/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  registerDependency,
  SubjectR,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subscribers: new Set(),
  }
  
  let currentValue = value
  
  const getter: GetterFn<T> = () => {
    // Track dependencies by registering with the active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      registerDependency(observer as unknown as SubjectR, activeObserver)
    }
    
    // Evaluate the function to get the current value
    currentValue = updateFn(currentValue)
    observer.value = currentValue
    
    // Return current value
    return currentValue!
  }
  
  return getter
}
