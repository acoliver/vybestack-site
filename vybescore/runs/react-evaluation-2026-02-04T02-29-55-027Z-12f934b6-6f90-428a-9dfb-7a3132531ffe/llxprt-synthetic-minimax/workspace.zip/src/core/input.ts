/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerDependency,
  notifySubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    subscribers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register dependency between this subject and the active observer
      registerDependency(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const oldValue = s.value
    s.value = nextValue
    
    // Only notify if value actually changed
    if (oldValue !== nextValue) {
      // Notify all subscribers when value changes
      notifySubject(s)
    }
    
    return s.value
  }

  return [read, write]
}
