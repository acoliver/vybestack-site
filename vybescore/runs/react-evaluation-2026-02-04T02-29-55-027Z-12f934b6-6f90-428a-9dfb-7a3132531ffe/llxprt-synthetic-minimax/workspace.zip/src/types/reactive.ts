/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<SubjectR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  subscribers?: Set<ObserverR>
  dependencies?: Set<SubjectR>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  subscribers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
}

export function registerDependency<T extends SubjectR>(subject: T, observer: ObserverR): void {
  // Register the dependency between subject and observer
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject)
  
  // Also register the observer as a subscriber to the subject
  if (!subject.subscribers) {
    subject.subscribers = new Set()
  }
  subject.subscribers.add(observer)
}

export function unregisterDependency<T extends SubjectR>(subject: T, observer: ObserverR): void {
  // Remove dependency between subject and observer
  if (observer.dependencies) {
    observer.dependencies.delete(subject)
  }
  
  // Also unregister the observer as a subscriber from the subject
  if (subject.subscribers) {
    subject.subscribers.delete(observer)
  }
}

export function notifySubject<T>(subject: Subject<T>): void {
  if (subject.subscribers) {
    // Create a copy to avoid iteration issues if subscribers are modified during notification
    const subscribers = new Set(subject.subscribers)
    for (const observer of subscribers) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}
