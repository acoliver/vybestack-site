/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with padding as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string is valid Base64 using the standard alphabet.
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid Base64
  if (!input) return false;
  
  // Only accept Base64 alphabet characters and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,}$/;
  if (!base64Regex.test(input)) return false;
  
  // Check for valid padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be at the end and can only be 1 or 2 '=' characters
    if (paddingIndex < input.length - 2) return false;
    if (input.length - paddingIndex > 2) return false;
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses standard Base64 alphabet and validates input before decoding.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
