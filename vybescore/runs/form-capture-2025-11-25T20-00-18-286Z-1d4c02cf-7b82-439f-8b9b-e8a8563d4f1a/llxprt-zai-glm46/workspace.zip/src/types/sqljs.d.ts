// Type definitions for sql.js
declare module 'sql.js' {
  export type SqlValue = string | number | boolean | Uint8Array | null;
  export type BindParams = SqlValue | SqlValue[] | { [key: string]: SqlValue };
  
  export interface Database {
    exec(sql: string): unknown[];
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface Statement {
    run(params: unknown[]): unknown;
    step(): unknown;
    get(): unknown[];
    bind(params: unknown[]): void;
    free(): void;
  }
  
  export interface SqlJsStatic {
    (options?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
    Database: new (data?: Uint8Array) => Database;
  }
  
  const SqlJs: SqlJsStatic;
  export default SqlJs;
}