import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData | 'general';
  message: string;
}

const app = express();
const PORT = process.env.PORT || 3535;

let db: import('sql.js').Database | null = null;
let server: ReturnType<typeof app.listen> | null = null;
let isShuttingDown = false;

app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

const validateFormData = (data: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];

  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and hyphens' });
  }

  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^[+]?[\d\s\-()]+$/.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }

  return errors;
};

const initializeDatabase = async () => {
  try {
    const SQL = await initSqlJs();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      db = new SQL.Database(dbFile);
      console.log('Database loaded from file');
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
      db.run(schema);
      console.log('Database created with new schema');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

const saveDatabase = async () => {
  if (!db || isShuttingDown) return;
  
  try {
    if (!db) return;
    const data = db.export();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    if (!fs.existsSync(path.dirname(dbPath))) {
      fs.mkdirSync(path.dirname(dbPath), { recursive: true });
    }
    
    fs.writeFileSync(dbPath, data);
    console.log('Database saved to file');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
};

app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validationErrors = validateFormData(formData);

  if (validationErrors.length > 0) {
    return res.status(400).render('form', {
      errors: validationErrors.map(err => err.message),
      values: formData
    });
  }

  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    ]);
    
    stmt.free();
    
    saveDatabase();
    
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
  } catch (error) {
    console.error('Database insertion error:', error);
    return res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

const gracefulShutdown = (signal: string) => {
  if (isShuttingDown) return;
  
  isShuttingDown = true;
  console.log(`
Received ${signal}. Starting graceful shutdown...`);
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
      
      if (db) {
        saveDatabase().then(() => {
          if (db) {
            db.close();
            console.log('Database connection closed');
          }
          process.exit(0);
        }).catch((error) => {
          console.error('Error during database shutdown:', error);
          process.exit(1);
        });
      } else {
        process.exit(0);
      }
    });
  } else {
    process.exit(0);
  }

  setTimeout(() => {
    console.error('Forced shutdown due to timeout');
    process.exit(1);
  }, 10000);
};

const startServer = async () => {
  try {
    await initializeDatabase();
    
    const createdServer = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
    server = createdServer;
    return createdServer;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Server startup failed:', error);
    process.exit(1);
  });
}

export { startServer, app };
