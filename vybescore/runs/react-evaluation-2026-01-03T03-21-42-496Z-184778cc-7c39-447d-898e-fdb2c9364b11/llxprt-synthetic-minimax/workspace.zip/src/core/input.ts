/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerDependency,
  notifyDependents,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: undefined,
    value,
    equalFn: equal,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has actually changed using equality function if provided
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    
    if (!hasChanged) return s.value
    
    s.value = nextValue
    notifyDependents(s)
    return s.value
  }

  return [read, write]
}
