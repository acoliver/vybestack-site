/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  updateObserver,
  getActiveObserver,
  registerDependency,
  EqualFn,
  Subject,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject wrapper for dependency tracking
  const s: Subject<T> = {
    name: options?.name,
    value: value !== undefined ? value : (null as unknown as T),
    observers: new Set(),
  }
  
  // Initial computation
  setActiveObserver(o as Observer<unknown>)
  try {
    value = updateObserver(o)
    s.value = value
  } finally {
    setActiveObserver(undefined)
  }
  
  const getter = (): T => {
    // Register dependency when getter is called by another observer
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(s, observer)
    }
    
    // Force fresh computation
    setActiveObserver(o as Observer<unknown>)
    try {
      o.value = undefined // Clear cache to force recomputation
      const newValue = updateObserver(o)
      s.value = newValue
      return newValue!
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Set up notification functionality
  Object.assign(getter, {
    observers: s.observers,
    value: s.value,
    notifyDependents: (): void => {
      const observers = s.observers ? Array.from(s.observers) : []
      for (const observer of observers) {
        try {
          updateObserver(observer as Observer<unknown>)
        } catch (error) {
          // Skip observers that fail to update
        }
      }
    }
  })
  
  return getter
}
