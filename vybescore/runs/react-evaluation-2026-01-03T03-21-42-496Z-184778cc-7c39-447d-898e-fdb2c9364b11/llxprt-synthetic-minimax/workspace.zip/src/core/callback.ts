/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  setActiveObserver,
  updateObserver,
  getActiveObserver,
  registerDependency,
  Subject,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create an observer for this callback
  const callbackObserver: Observer<T> = {
    value,
    updateFn: (currentValue?: T): T => {
      // Execute the side effect callback
      const result = updateFn(currentValue)
      return result
    }
  }
  
  // Create a subject to represent this callback in the dependency graph
  const callbackSubject: Subject<T> = {
    name: 'callback',
    value: value !== undefined ? value : (null as unknown as T),
    observers: new Set()
  }
  
  let disposed = false
  
  // Function to execute the callback with proper dependency tracking
  const executeCallback = (): void => {
    // Register this callback as an observer of any reactive values accessed
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      registerDependency(callbackSubject, activeObserver)
    }
    
    // Execute the callback in the active observer context to establish dependencies
    setActiveObserver(callbackObserver as Observer<unknown>)
    try {
      value = updateObserver(callbackObserver)
      callbackSubject.value = value
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Set up notification functionality for re-execution
  Object.assign(callbackSubject, {
    notifyDependents: (): void => {
      // When dependencies change, re-execute the callback
      executeCallback()
    }
  })
  
  // Execute callback initially to establish dependencies and trigger side effects
  executeCallback()
  
  // Return unsubscribe function
  return (): void => {
    if (disposed) return
    disposed = true
    
    // Remove this callback from all dependency tracking
    if (callbackSubject.observers) {
      callbackSubject.observers.clear()
    }
  }
}
