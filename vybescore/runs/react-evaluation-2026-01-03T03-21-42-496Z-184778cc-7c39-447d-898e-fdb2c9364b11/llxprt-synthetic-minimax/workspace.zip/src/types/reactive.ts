/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export interface SubjectR {
  name?: string
  observers?: Set<Observer<unknown>> // Track observers that depend on this subject
}

export interface SubjectV<T> {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global state for tracking the active observer during computation
let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  return observer.value!
}

export function registerDependency<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function notifyDependents<T>(subject: Subject<T>): void {
  if (!subject.observers) return
  
  // Create a copy to avoid issues if observers are added/removed during notification
  const observers = Array.from(subject.observers)
  
  for (const observer of observers) {
    updateObserver(observer as Observer<unknown>)
  }
}
