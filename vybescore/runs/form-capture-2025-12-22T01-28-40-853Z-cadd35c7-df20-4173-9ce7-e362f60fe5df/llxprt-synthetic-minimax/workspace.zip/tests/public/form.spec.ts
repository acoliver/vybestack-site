import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase, closeDatabase } from '../../dist/server.js';
import type { Server } from 'node:http';

let server: Server | null = null;
const dbPath = path.resolve(__dirname, '..', '..', 'data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Initialize the database
  await initializeDatabase();
  
  // Start the server
  server = app.listen(0); // Use port 0 to let the system choose an available port
});

afterAll(() => {
  // Clean up database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Close the database
  closeDatabase();
  
  // Close the server
  if (server) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
    
    // Check that form has correct method and action
    expect($('form').attr('method')).toBe('post');
    expect($('form').attr('action')).toBe('/submit');
    
    // Check that all labels are associated with inputs
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('label[for="streetAddress"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('label[for="stateProvince"]').length).toBe(1);
    expect($('label[for="postalCode"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);
  });

  it('shows validation errors for missing required fields', async () => {
    const response = await request(app).post('/submit')
      .send({
        firstName: 'John',
        lastName: '', // Missing last name
        streetAddress: '123 Main St',
        city: '',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '555-123-4567'
      });
    
    expect(response.status).toBe(400); // Should return 400 for validation errors
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
  });

  it('shows validation errors for invalid email format', async () => {
    const response = await request(app).post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email', // Invalid email
        phone: '555-123-4567'
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list').text()).toContain('email');
  });

  it('shows validation errors for invalid phone number', async () => {
    const response = await request(app).post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '12' // Too short phone number
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('.error-list').length).toBe(1);
    expect($('.error-list').text()).toContain('phone');
  });

  it('accepts valid international phone numbers', async () => {
    const validPhoneTests = [
      '+44 20 7946 0958', // UK
      '+54 9 11 1234-5678', // Argentina
      '+1 555-123-4567', // US/Canada
      '+81 90-1234-5678' // Japan
    ];

    for (const phone of validPhoneTests) {
      const response = await request(app).post('/submit')
        .send({
          firstName: 'John',
          lastName: 'Doe',
          streetAddress: '123 Main St',
          city: 'Anytown',
          stateProvince: 'CA',
          postalCode: '12345',
          country: 'USA',
          email: 'john@example.com',
          phone: phone
        });
      
      // Should not show phone validation error (may have other issues though)
      expect(response.status).toBeGreaterThanOrEqual(200).toBeLessThanOrEqual(400);
    }
  });

  it('accepts international postal codes', async () => {
    const validPostalTests = [
      'SW1A 1AA', // UK
      'C1000',    // Argentina Buenos Aires
      'B1675',    // Argentina
      '12345',    // US
      'A1B 2C3'   // Canada
    ];

    for (const postalCode of validPostalTests) {
      const response = await request(app).post('/submit')
        .send({
          firstName: 'John',
          lastName: 'Doe',
          streetAddress: '123 Main St',
          city: 'Anytown',
          stateProvince: 'CA',
          postalCode: postalCode,
          country: 'USA',
          email: 'john@example.com',
          phone: '555-123-4567'
        });
      
      // Should not show postal code validation error
      expect(response.status).toBeGreaterThanOrEqual(200).toBeLessThanOrEqual(400);
    }
  });

  it('persists valid submission and redirects to thank you page', async () => {
    const response = await request(app).post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '555-123-4567'
      });
    
    expect(response.status).toBe(302); // Should redirect
    expect(response.headers.location).toBe('/thank-you');
    
    // Follow redirect to thank you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('.thankyou-card').length).toBe(1);
    expect($('h1').text()).toContain('Thank You');
  });

  it('preserves form data when validation fails', async () => {
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '12345',
      country: 'USA',
      email: 'invalid-email', // This will cause validation error
      phone: '555-123-4567'
    };

    const response = await request(app).post('/submit').send(testData);
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    expect($('#firstName').val()).toBe(testData.firstName);
    expect($('#lastName').val()).toBe(testData.lastName);
    expect($('#email').val()).toBe(testData.email);
  });

  it('creates database file after successful submission', async () => {
    // Ensure database doesn't exist
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(app).post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Somewhere',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'USA',
        email: 'jane@example.com',
        phone: '212-555-9876'
      });
    
    expect(response.status).toBe(302); // Should redirect
    expect(fs.existsSync(dbPath)).toBe(true); // Database file should be created
  });

  it('renders thank you page with humorous copy', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('.thankyou-card').length).toBe(1);
    
    // Check for some of the humorous "scam" references
    const bodyText = $('body').text().toLowerCase();
    expect(bodyText).toMatch(/spam|harvest|legitimate|stranger|internet/);
    expect($('a[href="/"]').length).toBe(1); // Should have link back to form
  });
});
