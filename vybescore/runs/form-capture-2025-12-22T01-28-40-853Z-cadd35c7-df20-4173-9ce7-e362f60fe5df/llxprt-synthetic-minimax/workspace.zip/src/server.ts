import express, { Request, Response } from 'express';
import path from 'path';
import { existsSync, readFileSync, writeFileSync } from 'fs';
import initSqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

const PORT = parseInt(process.env.PORT || '3535', 10);

class DatabaseManager {
  private db: import('sql.js').Database | null = null;
  private dbPath: string;

  constructor(dbPath: string) {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    const SQL = await initSqlJs({
      locateFile: () => {
        return require.resolve('sql.js/dist/sql-wasm.wasm');
      }
    });

    if (existsSync(this.dbPath)) {
      const dbFile = readFileSync(this.dbPath);
      this.db = new SQL.Database(dbFile);
    } else {
      this.db = new SQL.Database();
      this.createSchema();
    }
  }

  private createSchema(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const schema = `CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province_region TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );`;
    
    this.db.exec(schema);
    this.save();
  }

  insertSubmission(data: FormData): void {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvinceRegion,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    this.save();
  }

  save(): void {
    if (!this.db) throw new Error('Database not initialized');
    
    const binaryArray = this.db.export();
    writeFileSync(this.dbPath, Buffer.from(binaryArray));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName?.trim()) errors.firstName = 'First name is required';
  if (!data.lastName?.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress?.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city?.trim()) errors.city = 'City is required';
  if (!data.stateProvinceRegion?.trim()) errors.stateProvinceRegion = 'State/Province/Region is required';
  if (!data.postalCode?.trim()) errors.postalCode = 'Postal code is required';
  if (!data.country?.trim()) errors.country = 'Country is required';
  if (!data.email?.trim()) errors.email = 'Email is required';
  if (!data.phone?.trim()) errors.phone = 'Phone number is required';

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (international formats)
  const phoneRegex = /^\+?[\d\s\-()]{7,20}$/;
  if (data.phone && !phoneRegex.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  if (data.postalCode && !postalRegex.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

async function createServer(): Promise<express.Application> {
  const app = express();
  
  const dbManager = new DatabaseManager(path.join(__dirname, '../data/submissions.sqlite'));
  await dbManager.initialize();

  // Middleware
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'views'));
  
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(__dirname, '../public')));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('index', {
      errors: {},
      data: {}
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);

    if (Object.keys(errors).length > 0) {
      return res.status(400).render('index', {
        errors,
        data: formData
      });
    }

    // Save to database
    try {
      dbManager.insertSubmission(formData);
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('index', {
        errors: { general: 'An error occurred while saving your submission. Please try again.' },
        data: formData
      });
    }
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you');
  });

  // Graceful shutdown
  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    dbManager.close();
    process.exit(0);
  });

  process.on('SIGINT', () => {
    console.log('SIGINT received, shutting down gracefully');
    dbManager.close();
    process.exit(0);
  });

  return app;
}

createServer()
  .then(app => {
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  })
  .catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });