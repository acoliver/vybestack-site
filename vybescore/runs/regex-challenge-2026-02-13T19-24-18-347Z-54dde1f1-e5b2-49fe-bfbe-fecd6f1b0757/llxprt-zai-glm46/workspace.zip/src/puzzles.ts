/**
 * Find words starting with prefix, excluding exceptions.
 * Uses lookahead for exception handling.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Build exceptions pattern - these words should NOT be matched
  const exceptionsPattern = exceptions.length > 0
    ? `(?!(?:${exceptions.map(e => e.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})\\b)`
    : '';
  
  // Pattern: word boundary, not in exceptions list, starts with prefix
  const regex = new RegExp(`${exceptionsPattern}\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * Find token occurrences that appear after a digit and not at string start.
 * Uses lookbehind to check for preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\d${escapedToken}`, `g`);
  const matches = text.match(regex) || [];
  return matches.filter(match => text.indexOf(match) > 0);
}

/**
 * Validate password strength.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;
  
  // Check for immediate repeated sequences (abab, 1212, etc.)
  // Look for patterns of 2-4 characters that repeat immediately
  // Using backreference to detect repetitions
  const repeatedPattern = /(.{1,4})\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses.
 * Handles shorthand notation (::).
 * Ensures IPv4 addresses don't trigger false positives.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that excludes IPv4
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can appear once to represent consecutive zero groups
  
  // First, we need to match IPv6 but not match IPv4 addresses
  // IPv4 pattern: 4 groups of 1-3 digits (0-255)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it's clearly IPv4, return false
  if (ipv4Pattern.test(value)) {
    // But need to check if it might be IPv6 embedded (IPv4-mapped IPv6)
    // IPv6 can end with IPv4 in ::ffff:192.168.1.1 format
    // So we should still check for IPv6 pattern
  }
  
  // IPv6 patterns:
  // 1. Full form: 8 groups of 1-4 hex digits
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // 2. Compressed form with ::
  const compressedIPv6 = /(?:[0-9a-fA-F]{1,4}:)*::(?::[0-9a-fA-F]{1,4})*/;
  
  // 3. Loopback ::1
  const loopbackIPv6 = /::1\b/;
  
  // 4. IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  // This is valid IPv6, not just IPv4
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:)*:(?::[0-9a-fA-F]{1,4}:)*(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Check if any IPv6 pattern matches
  if (fullIPv6.test(value) || compressedIPv6.test(value) || 
      loopbackIPv6.test(value) || ipv6WithIPv4.test(value)) {
    return true;
  }
  
  // Additional check: single :: is valid IPv6
  if (value.includes('::')) {
    // But :: alone or at edges with proper format
    const doubleColonPattern = /(?:::(?::[0-9a-fA-F]{1,4})+|(?:[0-9a-fA-F]{1,4}:)+::)/;
    if (doubleColonPattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
