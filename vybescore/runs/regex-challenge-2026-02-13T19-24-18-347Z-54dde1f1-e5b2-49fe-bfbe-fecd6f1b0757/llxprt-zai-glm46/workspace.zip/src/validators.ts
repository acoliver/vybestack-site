export interface PhoneValidationOptions {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for no consecutive dots
  if (value.includes('..')) return false;
  
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  const [local, domain] = parts;
  
  // Check local part exists and doesn't start/end with dot
  if (!local || local.startsWith('.') || local.endsWith('.')) return false;
  
  // Check domain exists, no underscores, doesn't start/end with dot or hyphen
  if (!domain || domain.includes('_')) return false;
  if (domain.startsWith('.') || domain.startsWith('-') || 
      domain.endsWith('.') || domain.endsWith('-')) return false;
  
  // Basic email regex - allows standard characters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects: impossible area codes (leading 0/1), too short inputs.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digits.length < 10) return false;
  
  // Check for +1 prefix
  let numberDigits: string;
  if (digits.length === 11 && digits.startsWith('1')) {
    numberDigits = digits.slice(1);
  } else if (digits.length === 10) {
    numberDigits = digits;
  } else {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = numberDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = numberDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Validate format with optional separators
  const phoneRegex = /^(?:\+1\s*)?(?:\(\d{3}\)\s*|\d{3}[-\s]?)?\d{3}[-\s]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Supports landlines and mobiles.
 * Optional country code +54, trunk prefix 0, mobile indicator 9.
 * Area code: 2-4 digits, leading digit 1-9.
 * Subscriber number: 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // First check if it starts with 54 (country code) or 0 (trunk)
  const startsWith54 = cleaned.startsWith('+54') || cleaned.startsWith('54');
  const startsWith0 = cleaned.startsWith('0');
  
  // Must have either country code or trunk prefix
  if (!startsWith54 && !startsWith0) return false;
  
  let match: RegExpMatchArray | null;
  
  if (startsWith54) {
    // Remove +54 or 54 prefix
    const withoutCountry = cleaned.replace(/^\+?54/, '');
    // Check for optional mobile indicator 9
    const mobilePrefix = withoutCountry.startsWith('9') ? '9' : '';
    const afterMobile = mobilePrefix ? withoutCountry.slice(1) : withoutCountry;
    
    // Now should have area code + subscriber
    // Area code: 2-4 digits, leading digit 1-9
    // Subscriber: 6-8 digits
    const areaAndSubsRegex = /^(\d{2,4})(\d{6,8})$/;
    match = afterMobile.match(areaAndSubsRegex);
  } else {
    // Starts with 0 (trunk prefix)
    const withoutTrunk = cleaned.slice(1);
    const mobilePrefix = withoutTrunk.startsWith('9') ? '9' : '';
    const afterMobile = mobilePrefix ? withoutTrunk.slice(1) : withoutTrunk;
    
    const areaAndSubsRegex = /^(\d{2,4})(\d{6,8})$/;
    match = afterMobile.match(areaAndSubsRegex);
  }
  
  if (!match) return false;
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] < '1' || areaCode[0] > '9') return false;
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects: digits, symbols, X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Regex that allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes
  // - Hyphens
  // - Spaces
  // But rejects:
  // - Digits
  // - Symbols (except apostrophe and hyphen)
  // - Names like "X Æ A-12" (contains digits and symbols like Æ)
  
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  // Check if it matches the basic pattern
  if (!nameRegex.test(value)) return false;
  
  // Check for at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Check for consecutive non-letter characters (like multiple apostrophes/hyphens)
  const invalidSequence = /['-]{2,}/.test(value);
  if (invalidSequence) return false;
  
  // Reject names that look like "X Æ A-12" style - digits with special symbols
  // Æ is a letter (Latin ligature), but -12 suggests tech-style naming
  if (/\d/.test(value)) return false;
  
  // Check for unusual unicode symbols that might be techy (like Æ combined with numbers)
  // This is a heuristic - if name has special unicode chars AND looks techy
  const hasSpecialUnicode = /[\u00A0-\u00FF\u0100-\u017F\u0180-\u024F]/.test(value);
  if (hasSpecialUnicode) {
    // Still valid if it's just accented letters
    // The no-digits check above handles X Æ A-12 case
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check basic length (13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check card type prefixes and lengths
  // Visa: starts with 4, length 13, 16, or 19
  const visaRegex = /^4\d{12}(?:\d{3})?(?:\d{3})?$/;
  if (visaRegex.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7]\d{2})\d{12}$/;
  if (mastercardRegex.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(digits)) {
    return runLuhnCheck(digits);
  }
  
  return false;
}
