/**
 * Capitalize first character of each sentence.
 * - Insert exactly one space between sentences even if input omitted it
 * - Collapse extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Step 1: Ensure proper spacing after sentence endings
  // Replace punctuation followed by non-space with punctuation + space
  let result = text.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Step 2: Capitalize first character of each sentence
  // Match start of string or after sentence-ending punctuation
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (_match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Step 3: Collapse multiple spaces to single space (but preserve newlines)
  result = result.replace(/[ \t]+/g, ' ');
  
  return result;
}

/**
 * Find all URLs in the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex
  // Matches http://, https://, www.
  // Does not include trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"'(){}|^[\]\\`<>]+[^\s<>"'(){}|^[\]\\`<>.,!?;:]/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation that might have been included
  return matches.map(url => {
    // Remove trailing dots, commas, etc.
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlPattern, (_match, protocolAndHost, path) => {
    // Always upgrade to https
    const secureHost = 'https://example.com';
    
    // Check if path should skip host rewrite
    // Skip if contains cgi-bin, query strings, or legacy extensions
    const skipRewrite = /\/cgi-bin\/|[?&=]|(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/.test(path);
    
    // Check if path starts with /docs/
    if (!skipRewrite && path.startsWith('/docs/')) {
      return 'https://docs.example.com' + path;
    }
    
    // Just upgrade the scheme
    return secureHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) return 'N/A';
  
  return year;
}
