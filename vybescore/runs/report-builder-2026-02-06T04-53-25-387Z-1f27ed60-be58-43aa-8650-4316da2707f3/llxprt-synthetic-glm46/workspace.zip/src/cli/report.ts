#!/usr/bin/env node

import { parseArguments } from '../utils/parse-args.js';
import { loadAndValidateJson } from '../utils/validate-json.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText,
};

async function main() {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    console.error('Supported formats: markdown, text');
    process.exit(1);
    return;
  }
  
  const inputFile = args[0];
  const cliArgs = args.slice(1);
  
  try {
    const options = parseArguments(cliArgs);
    const reportData = await loadAndValidateJson(inputFile);
    
    const formatter = formatRenderers[options.format];
    if (!formatter) {
      console.error(`Unsupported format: ${options.format}`);
      process.exit(1);
      return;
    }
    
    const output = formatter.render(reportData, { includeTotals: options.includeTotals });
    
    if (options.output) {
      const fs = await import('fs/promises');
      await fs.writeFile(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
    
    process.exit(0);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

try {
  main();
} catch (error) {
  console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
  process.exit(1);
}
