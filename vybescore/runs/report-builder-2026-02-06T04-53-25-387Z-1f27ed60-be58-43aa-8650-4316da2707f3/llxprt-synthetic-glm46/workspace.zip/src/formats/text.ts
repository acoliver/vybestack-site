import type { ReportData, FormatOptions, Formatter } from '../types.js';

export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderText: Formatter = {
  render(data: ReportData, options: FormatOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries section
    lines.push('Entries:');
    
    // List entries
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatCurrency(entry.amount)}`);
    }
    
    // Footer with totals if requested
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push(`Total: ${formatCurrency(total)}`);
    }
    
    return lines.join('\n');
  }
};