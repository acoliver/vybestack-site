import type { ReportData, ReportEntry } from '../types.js';

function validateReportEntry(entry: unknown): ReportEntry {
  if (!entry || typeof entry !== 'object') {
    throw new Error('Invalid entry: must be an object');
  }
  
  const entryObj = entry as Record<string, unknown>;
  
  if (typeof entryObj.label !== 'string') {
    throw new Error('Invalid entry: label must be a string');
  }
  
  if (typeof entryObj.amount !== 'number') {
    throw new Error('Invalid entry: amount must be a number');
  }
  
  return {
    label: entryObj.label,
    amount: entryObj.amount,
  };
}

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: must be an object');
  }
  
  const reportObj = data as Record<string, unknown>;
  
  if (typeof reportObj.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof reportObj.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(reportObj.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  const entries = reportObj.entries.map(validateReportEntry);
  
  return {
    title: reportObj.title,
    summary: reportObj.summary,
    entries,
  };
}

export async function loadAndValidateJson(filePath: string): Promise<ReportData> {
  try {
    const fs = await import('fs/promises');
    const content = await fs.readFile(filePath, 'utf-8');
    
    let parsedData;
    try {
      parsedData = JSON.parse(content);
    } catch (parseError) {
      throw new Error(`Failed to parse JSON file: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`);
    }
    
    return validateReportData(parsedData);
  } catch (fileError) {
    if (fileError instanceof Error && fileError.message.startsWith('Failed to parse JSON file:')) {
      throw fileError;
    }
    
    throw new Error(`Failed to read file: ${fileError instanceof Error ? fileError.message : 'Unknown error'}`);
  }
}