import type { CliOptions, FormatType } from '../types.js';

export function parseArguments(args: string[]): CliOptions {
  const options: CliOptions = {
    format: 'markdown' as FormatType,
    includeTotals: false,
  };

  let currentFlag = '';
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      const flagName = arg.slice(2);
      currentFlag = flagName;
    } else if (currentFlag) {
      switch (currentFlag) {
        case 'format':
          if (arg !== 'markdown' && arg !== 'text') {
            throw new Error(`Unsupported format: ${arg}`);
          }
          options.format = arg as FormatType;
          break;
        case 'output':
          options.output = arg;
          break;
      }
      currentFlag = '';
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    }
  }

  return options;
}