import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, '..');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormCaptureApp {
  private app: express.Application;
  private db: Database | null = null;
  private server: ReturnType<typeof this.app.listen> | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: () => path.join(projectRoot, 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm')
      });

      let dbData: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const data = fs.readFileSync(this.dbPath);
        dbData = new Uint8Array(data);
      }

      this.db = new SQL.Database(dbData);

      const schema = fs.readFileSync(path.join(projectRoot, 'db', 'schema.sql'), 'utf8');
      this.db.run(schema);

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;

    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(projectRoot, 'public')));
    // Set views to look in both src and dist/templates for flexibility
    this.app.set('view engine', 'ejs');
    this.app.set('views', [
      path.join(__dirname, 'templates'),
      path.join(projectRoot, 'dist', 'templates')
    ]);
  }

  private validateFormData(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field]!.trim() === '') {
        errors.push({
          field,
          message: `${this.getFieldLabel(field)} is required`
        });
      }
    }

    if (data.email && !this.isValidEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    if (data.phone && !this.isValidPhone(data.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }

    return errors;
  }

  private getFieldLabel(field: string): string {
    const labels: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return labels[field] || field;
  }

  private isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private isValidPhone(phone: string): boolean {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

  private setupRoutes(): void {
    this.app.get('/', this.handleGetForm.bind(this));
    this.app.post('/submit', this.handleSubmit.bind(this));
    this.app.get('/thank-you', this.handleThankYou.bind(this));
  }

  private handleGetForm(req: Request, res: Response): void {
    res.render('form', {
      errors: [],
      values: {}
    });
  }

  private async handleSubmit(req: Request, res: Response): Promise<void> {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = this.validateFormData(formData);

    if (errors.length > 0) {
      res.status(400).render('form', {
        errors: errors.map(e => e.message),
        values: formData
      });
      return;
    }

    try {
      if (!this.db) {
        throw new Error('Database not initialized');
      }

      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim()
      ]);

      stmt.free();
      this.saveDatabase();

      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  }

  private handleThankYou(req: Request, res: Response): void {
    res.render('thank-you', {
      firstName: req.query.firstName || 'friend'
    });
  }

  public async start(port: number = 3535): Promise<void> {
    try {
      await this.initializeDatabase();
      
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      }).on('error', (err: NodeJS.ErrnoException) => {
        if (err.code === 'EADDRINUSE') {
          console.error(`Port ${port} is already in use. Please try a different port.`);
        } else {
          console.error('Server error:', err);
        }
        process.exit(1);
      });

      this.setupGracefulShutdown();
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  private setupGracefulShutdown(): void {
    const shutdown = (signal: string) => {
      console.log(`Received ${signal}. Shutting down gracefully...`);
      
      if (this.server) {
        this.server.close(() => {
          console.log('HTTP server closed');
        });
      }

      if (this.db) {
        this.db.close();
        console.log('Database connection closed');
      }

      process.exit(0);
    };

    process.on('SIGTERM', () => shutdown('SIGTERM'));
    process.on('SIGINT', () => shutdown('SIGINT'));

    process.on('uncaughtException', (error) => {
      console.error('Uncaught Exception:', error);
      shutdown('uncaughtException');
    });

    process.on('unhandledRejection', (reason, promise) => {
      console.error('Unhandled Rejection at:', promise, 'reason:', reason);
      shutdown('unhandledRejection');
    });
  }
}

const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const app = new FormCaptureApp();
app.start(port).catch(console.error);