/**
 * Encode plain text to Base64 using the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check for invalid Base64 characters
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    // Verify the round-trip was successful by encoding and comparing
    const reEncoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReEncoded = reEncoded.replace(/=+$/, ''); // Remove padding for comparison
    
    const normalizedInput = input.replace(/=+$/, ''); // Remove padding for comparison
    
    if (normalizedInput !== normalizedReEncoded) {
      throw new Error('Invalid Base64 input: failed round-trip verification');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}