/**
 * Encode plain text to Base64 using standard Base64 semantics.
 * Returns Base64-encoded string with proper padding when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Rejects invalid input by throwing an error.
 */
export function decode(input: string): string {
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  // Validate input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Add padding if necessary for proper Base64 decoding
  // Base64 strings should be multiple of 4 in length when padded
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  const paddedInput = normalized + '='.repeat(paddingNeeded);

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
