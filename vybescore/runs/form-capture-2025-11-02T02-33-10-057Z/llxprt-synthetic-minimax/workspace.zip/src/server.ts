import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { Database } from 'sql.js';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

// Validation types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data?: FormData;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<void> {
  try {
    const SQLModule = await import('sql.js');
    const initSqlJs = SQLModule.default;
    
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        return path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file);
      },
    });

    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    
    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      db.exec(schema);
      
      // Ensure data directory exists
      const dataDir = path.dirname(DB_PATH);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Save initial database
      const data = db.export();
      fs.writeFileSync(DB_PATH, data);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function validateForm(data: any): ValidationResult {
  const errors: ValidationError[] = [];
  const formData: FormData = {
    firstName: (data.firstName || '').trim(),
    lastName: (data.lastName || '').trim(),
    streetAddress: (data.streetAddress || '').trim(),
    city: (data.city || '').trim(),
    stateProvince: (data.stateProvince || '').trim(),
    postalCode: (data.postalCode || '').trim(),
    country: (data.country || '').trim(),
    email: (data.email || '').trim(),
    phone: (data.phone || '').trim(),
  };

  // Required field validation
  if (!formData.firstName) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  }
  if (!formData.country) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!formData.email) {
    errors.push({ field: 'email', message: 'Email is required' });
  }
  if (!formData.phone) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Email validation
  if (formData.email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
  }

  // Phone validation (digits, spaces, parentheses, dashes, leading +)
  if (formData.phone) {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(formData.phone)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }
  }

  // Postal code validation (alphanumeric)
  if (formData.postalCode) {
    const postalRegex = /^[A-Za-z0-9\s\-]+$/;
    if (!postalRegex.test(formData.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: formData,
  };
}

async function createServer(): Promise<express.Express> {
  await initializeDatabase();

  const app = express();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use(express.static(path.join(__dirname, '..', 'public')));

  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));

  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      data: {},
      title: 'Contact Form',
    });
  });

  app.post('/submit', (req: Request, res: Response) => {
    if (!db) {
      res.status(500).send('Database not initialized');
      return;
    }

    const validation = validateForm(req.body);

    if (!validation.isValid) {
      res.status(200).render('form', {
        errors: validation.errors,
        data: validation.data,
        title: 'Contact Form',
      });
      return;
    }

    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      validation.data!.firstName,
      validation.data!.lastName,
      validation.data!.streetAddress,
      validation.data!.city,
      validation.data!.stateProvince,
      validation.data!.postalCode,
      validation.data!.country,
      validation.data!.email,
      validation.data!.phone,
    ]);

    stmt.free();

    // Save database to disk
    const data = db.export();
    fs.writeFileSync(DB_PATH, data);

    // Redirect to thank-you page
    res.redirect(302, `/thank-you?name=${encodeURIComponent(validation.data!.firstName)}`);
  });

  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = (req.query.name as string) || '';
    res.render('thank-you', {
      firstName,
      title: 'Thank You',
    });
  });

  return app;
}

async function start(): Promise<void> {
  const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const app = await createServer();

  const server = app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });

  // Graceful shutdown
  const gracefulShutdown = (signal: string) => {
    console.log(`\n${signal} received, shutting down gracefully...`);
    
    if (server) {
      server.close(() => {
        console.log('HTTP server closed');
        
        if (db) {
          const data = db.export();
          fs.writeFileSync(DB_PATH, data);
          console.log('Database saved');
          db.close();
        }
        
        process.exit(0);
      });
    } else {
      process.exit(0);
    }
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));

  // Keep a reference to the server for testing
  (globalThis as any).server = server;

  return server;
}

// Only start the server if this file is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { createServer };