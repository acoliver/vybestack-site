import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

interface DatabaseService {
  db: Database | null;
  SQL: SqlJsStatic | null;
  init(): Promise<void>;
  close(): void;
  insertSubmission(data: SubmissionData): void;
  export(): void;
}

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

const databaseService: DatabaseService = {
  db: null,
  SQL: null,

  async init(): Promise<void> {
    this.SQL = await initSqlJs();

    let dbContent: Uint8Array | null = null;

    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      dbContent = new Uint8Array(buffer);
      this.db = new this.SQL.Database(dbContent);
    } else {
      this.db = new this.SQL.Database();
      if (fs.existsSync(SCHEMA_PATH)) {
        const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
        this.db.run(schema);
      }
      this.export();
    }
  },

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  },

  insertSubmission(data: SubmissionData): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone,
    ]);

    stmt.free();
    this.export();
  },

  export(): void {
    if (!this.db) {
      return;
    }

    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }

    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  },
};

export default databaseService;
