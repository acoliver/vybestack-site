import express, { Request, Response } from 'express';
import path from 'node:path';
import database, { SubmissionData } from './database.js';
import { validateFormData, FormData, ValidationResult } from './validator.js';

const app = express();
const PORT = process.env.PORT || 3535;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
// Use absolute path to public directory to ensure it works from both src and dist
app.use(express.static(path.resolve(process.cwd(), 'public')));
app.set('view engine', 'ejs');
// Use absolute path to views directory to ensure it works from both src and dist
app.set('views', path.resolve(process.cwd(), 'src/views'));

interface FormRequestBody {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

function toFormData(body: FormRequestBody): FormData {
  return {
    firstName: body.firstName || '',
    lastName: body.lastName || '',
    streetAddress: body.streetAddress || '',
    city: body.city || '',
    stateProvince: body.stateProvince || '',
    postalCode: body.postalCode || '',
    country: body.country || '',
    email: body.email || '',
    phone: body.phone || '',
  };
}

function toSubmissionData(formData: FormData): SubmissionData {
  return {
    first_name: formData.firstName,
    last_name: formData.lastName,
    street_address: formData.streetAddress,
    city: formData.city,
    state_province: formData.stateProvince,
    postal_code: formData.postalCode,
    country: formData.country,
    email: formData.email,
    phone: formData.phone,
  };
}

app.get('/', (_req: Request, res: Response): void => {
  res.render('form', { formData: {}, errors: [] });
});

app.post('/submit', (req: Request, res: Response): void => {
  const formData = toFormData(req.body);
  const validationResult: ValidationResult = validateFormData(formData);

  if (!validationResult.valid) {
    res.status(400);
    res.render('form', { formData, errors: validationResult.errors });
    return;
  }

  const submissionData = toSubmissionData(formData);
  database.insertSubmission(submissionData);

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response): void => {
  res.render('thank-you');
});

interface Server {
  close: () => void;
  listen: () => Promise<void>;
}

async function startServer(): Promise<Server> {
  await database.init();

  return new Promise<Server>((resolve) => {
    const server = app.listen(PORT, () => {
      console.log(`Server listening on port ${PORT}`);
    });

    const originalClose = server.close.bind(server);
    let isClosing = false;

    function close(): void {
      if (isClosing) {
        return;
      }
      isClosing = true;
      database.close();
      originalClose();
    }

    process.on('SIGTERM', close);
    process.on('SIGINT', close);

    resolve({ close, listen: async () => Promise.resolve() });
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { startServer };
export default app;
