export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for plus signs, various domain formats.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: letters, digits, plus, dots, hyphens, but no consecutive dots or leading/trailing dots
  // Domain part: letters, digits, hyphens, dots, but no underscores or leading/trailing dots
  const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9._%+-]*[a-zA-Z0-9]+)?@[a-zA-Z0-9]+([a-zA-Z0-9-]*[a-zA-Z0-9]+)?(\.[a-zA-Z0-9]+([a-zA-Z0-9-]*[a-zA-Z0-9]+)?)*\.[a-zA-Z]{2,}$/;
  
  // Quick check for invalid patterns
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check for consecutive dots
  if (value.includes('..') || value.includes('.@') || value.includes('@.')) {
    return false;
  }
  
  // Check for domains with underscores
  if (value.includes('_')) {
    // Check if underscore is in domain part (after @)
    const atPos = value.indexOf('@');
    const domain = value.substring(atPos + 1);
    if (domain.includes('_')) {
      return false;
    }
  }
  
  // Check for leading or trailing dots
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Test against regex
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  void options; // Mark parameter as used without eslint directive
  
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Remove leading +1 if present
  const withoutCountryCode = digits.startsWith('1') && digits.length > 10 
    ? digits.substring(1) 
    : digits;
  
  // US phone numbers must have 10 digits
  if (withoutCountryCode.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = withoutCountryCode.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers including landlines and mobiles.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, etc.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[ \-]/g, '');
  
  // Check if it starts with country code +54 or trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = cleaned.startsWith('0');
  
  // If it doesn't start with +54, it must start with 0 (trunk prefix)
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Extract number without prefixes
  let numberPart = cleaned;
  if (hasCountryCode) {
    numberPart = cleaned.substring(3); // Remove +54
  } else if (hasTrunkPrefix) {
    numberPart = cleaned.substring(1); // Remove 0
  }
  
  // Check for mobile indicator (9) after country code/trunk
  let isMobile = false;
  if (numberPart.startsWith('9')) {
    isMobile = true;
    numberPart = numberPart.substring(1); // Remove 9
  }
  
  // Find the area code (2-4 digits, leading digit 1-9)
  let areaCodeLength = 2;
  if (numberPart.length >= 7 && !isMobile) {
    // For landlines, try 2-4 digit area codes
    if (numberPart.substring(2, 3) !== '0') { // Simple heuristic for 3-digit area codes
      areaCodeLength = 3;
    }
  } else if (isMobile && /^11/.test(numberPart)) {
    // Mobile numbers often have 2-digit area codes like 11 for Buenos Aires
    areaCodeLength = 2;
  } else {
    // Try to determine area code length
    if (numberPart.length >= 8) {
      areaCodeLength = Math.min(4, Math.floor(numberPart.length / 3));
    }
  }
  
  // Extract area code
  const areaCode = numberPart.substring(0, areaCodeLength);
  
  // Check area code is valid (2-4 digits, doesn't start with 0)
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4 || areaCode.startsWith('0')) {
    return false;
  }
  
  // Check if area code contains only digits
  if (!/^\d+$/.test(areaCode)) {
    return false;
  }
  
  // Extract subscriber number
  const subscriberNumber = numberPart.substring(areaCodeLength);
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Check if subscriber number contains only digits
  if (!/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates names with unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and strange "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Name regex: simpler approach that works in older JS environments
  // Allow unicode letters, spaces, hyphens, and apostrophes
  // First, check for forbidden characters (digits, most symbols)
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for symbols that shouldn't be in names
  if (/[@#\$%\^&\*\(\)\+=\[\]\{\};:"<>~`]/.test(value)) {
    return false;
  }
  
  // Simple approach: check that name contains only allowed characters
  // and at least one letter
  const hasLetters = /[a-zA-Z\u00C0-\u017F\u0400-\u04FF]/.test(value); // Basic Latin + some European/Cyrillic
  const onlyAllowedChars = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF\s\-'']+$/.test(value);
  
  return hasLetters && onlyAllowedChars && value.trim().length > 0;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Iterate from rightmost digit to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        // Fix: Convert digit to string first
        const digitString = digit.toString();
        digit = digitString
          .split('')
          .reduce((sum, val) => sum + parseInt(val, 10), 0);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) with proper prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Quick validation
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Credit card validation regex
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  // Fix: Simplify the regex to avoid syntax error
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mcRegex = /^(5[1-5]\d{14}|2(2[2-9][1-9]|[3-6]\d{2}|7([01]\d|20))\d{12})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mcRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}