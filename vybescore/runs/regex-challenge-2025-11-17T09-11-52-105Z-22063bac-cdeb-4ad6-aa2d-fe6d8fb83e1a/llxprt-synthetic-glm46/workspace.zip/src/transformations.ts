/**
 * Capitalizes the first character of each sentence after punctuation marks (.?!).
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Handle empty or whitespace-only strings
  if (!text.trim()) {
    return text.trim();
  }
  
  // Simple approach: directly look for sentences using regex
  // First, normalize spaces
  const result = text.replace(/\s+/g, ' ');
  
  // Then capitalize after each sentence delimiter
  return result.replace(/(^|[.!?]\s+)([a-z])/g, (_match, prefix, char) => {
    return prefix + char.toUpperCase();
  });
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // Regex to match URLs with various protocols
  const urlRegex = /(?<![\w])https?:\/\/([a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}([/?][^\s)\]])*(?![\w.,;:!?)\]])/g;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Return unique URLs
  return [...new Set(matches)];
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // Replace http:// with https://, but don't touch https://
  // Use negative lookahead to avoid replacing https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs to use HTTPS and docs subdomain.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // Pattern to match URLs with http:// or https:// scheme
  // Replace with https:// and potentially docs subdomain
  return text.replace(/http:\/\/([^\/\s]+)(\/[^\s]*)/g, (_match, domain, path) => {
    // First, upgrade to HTTPS
    let result = 'https://' + domain + path;
    
    // Check if we should rewrite the host for documentation paths
    // Skip rewrite if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /(cgi-bin|\?|&|=)/.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(path);
    
    // If path starts with /docs/ and doesn't contain dynamic hints or legacy extensions
    if (path.startsWith('/docs/') && !hasDynamicHints && !hasLegacyExtensions) {
      // Rewrite host from example.com to docs.example.com
      result = 'https://docs.' + domain + path;
    }
    
    return result;
  });
}

/**
 * Extracts year from mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Use regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string
  
  // Basic validation for month/day combinations
  // February: max 29 days
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  // April, June, September, November: max 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  // All other months: max 31 days
  if (day > 31) {
    return 'N/A';
  }
  
  return year;
}