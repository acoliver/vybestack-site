/**
 * Finds words starting with the prefix but excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix) {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
  
  // Word boundary regex to find words starting with the prefix
  const wordRegex = new RegExp('\\b' + escapedPrefix + '[a-zA-Z0-9]*\\b', 'g');
  
  // Find all words matching the pattern
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  const result = matches.filter(word => 
    !exceptions.includes(word.toLowerCase())
  );
  
  // Return unique words
  return [...new Set(result)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
  
  // Use a regex to match token preceded by a digit
  // We need to capture both the digit and the token to return the full match
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validates password strength requirements.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_\-\+=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
// Check for immediate repeated sequences (e.g., abab, ababa)
  // Check for patterns like aaa, bbbb
  if (/(.)\1\1/.test(value)) {
    return false;
  }
  
  // Check for alternating patterns like ababab
  if (/([a-zA-Z]{2})\1\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv6 pattern (including shorthand ::)
  // This is a simplified pattern that covers most common IPv6 formats
  const ipv6Pattern = /\b([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|([0-9a-fA-F]{0,4}:){1,7}:/;
  
  // IPv4 pattern (to exclude)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // First check for IPv6
  if (!ipv6Pattern.test(value)) {
    return false;
  }
  
  // If it also matches IPv4, check if it's primarily an IPv6 address
  // Split the string by common delimiters
  const parts = value.split(/[\s,\n]+/);
  
  for (const part of parts) {
    // If this part looks like IPv6 but not IPv4
    const isIPv6 = ipv6Pattern.test(part);
    const isIPv4 = ipv4Pattern.test(part);
    
    if (isIPv6 && !isIPv4) {
      return true;
    }
  }
  
  return false;
}