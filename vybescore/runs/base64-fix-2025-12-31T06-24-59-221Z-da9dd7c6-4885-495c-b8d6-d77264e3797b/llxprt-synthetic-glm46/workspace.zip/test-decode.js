import { decode } from './dist/src/base64.js';

console.log("Testing decode without padding:");
try {
  const result1 = decode('Zm9vL2Jhcg==');
  console.log("With padding:", result1);
} catch (e) {
  console.log("With padding error:", e.message);
}

try {
  const result2 = decode('Zm9vL2Jhcg');
  console.log("Without padding:", result2);
} catch (e) {
  console.log("Without padding error:", e.message);
}

try {
  const result3 = decode('Zm9vL2Jhcg=');
  console.log("Partial padding:", result3);
} catch (e) {
  console.log("Partial padding error:", e.message);
}