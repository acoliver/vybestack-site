// Test all possible single '=' padding scenarios to understand what's valid
import { decode } from './dist/src/base64.js';

const testValues = [
  'Zm9vL2Jhcg==',  // length 11, 11 % 4 = 3, with padding
  'Zm9vL2Jhcg=',   // length 10, 10 % 4 = 2, with padding
  'Zm9vL2Jhcg',    // length 9, 9 % 4 = 1, no padding
];

for (const val of testValues) {
  console.log(`\nTesting: "${val}" (length ${val.length}, remainder ${val.length % 4})`);
  
  // Try with Buffer
  try {
    const bufferResult = Buffer.from(val, 'base64').toString('utf8');
    console.log(`  Buffer result: "${bufferResult}"`);
  } catch (e) {
    console.log(`  Buffer error: ${e.message}`);
  }
  
  // Try with our decode
  try {
    const decodeResult = decode(val);
    console.log(`  Decode result: "${decodeResult}"`);
  } catch (e) {
    console.log(`  Decode error: ${e.message}`);
  }
}