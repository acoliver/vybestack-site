import { decode } from './dist/src/base64.js';

console.log("Testing single '=' padding:");
try {
  const result = decode('Zm9vL2Jhcg=');
  console.log("Single padding:", result);
} catch (e) {
  console.log("Single padding error:", e.message);
}