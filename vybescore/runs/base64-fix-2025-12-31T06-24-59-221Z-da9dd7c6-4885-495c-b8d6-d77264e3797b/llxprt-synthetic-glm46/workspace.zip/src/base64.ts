/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and rejects clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Check if input is empty
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  // Filter out whitespace characters (which are valid in base64)
  const trimmedInput = input.replace(/\s/g, '');
  
  // Check if input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check if padding is correct (not too many padding chars)
  const paddingCount = (trimmedInput.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  // Check if padding characters are only at the end
  const paddingIndex = trimmedInput.indexOf('=');
  if (paddingIndex !== -1 && trimmedInput.substring(paddingIndex).match(/[^=]/)) {
    throw new Error('Invalid Base64 input: padding not at end');
  }
  
  // Length validation:
  // - If padding is present, Buffer handles correct validation silently
  // - We only need to check for clearly invalid cases (remainder === 1 for unpadded input)
  const remainder = trimmedInput.length % 4;
  const hasPadding = trimmedInput.includes('=');
  
  if (!hasPadding && remainder === 1) {
    throw new Error('Invalid Base64 input: incorrect length');
  }

  try {
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
