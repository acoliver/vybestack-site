// Test what Buffer with 'base64' does with single '=' padding
const result1 = Buffer.from('Zm9vL2Jhcg=', 'base64').toString('utf8');
const result2 = Buffer.from('Zm9vL2Jhcg', 'base64').toString('utf8');

console.log("Single padding Buffer result:", result1);
console.log("No padding Buffer result:", result2);