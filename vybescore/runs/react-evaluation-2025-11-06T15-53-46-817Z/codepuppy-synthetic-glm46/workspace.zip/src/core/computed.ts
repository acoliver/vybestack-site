/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

function createDefaultEqualFn<T>(): EqualFn<T> {
  return (a: T, b: T) => a === b
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn: EqualFn<T> = equal === true 
    ? createDefaultEqualFn<T>()
    : equal === false || equal === undefined
    ? () => false
    : equal

  // This will act as both an observer (of its dependencies) and a subject (for its observers)
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }
  
  // The observer that represents this computed value
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev?: T) => {
      // Execute update function while this observer is active,
      // which will cause dependencies to register this observer
      const newValue = updateFn(prev)
      
      if (equalFn && prev !== undefined && equalFn(prev, newValue)) {
        return prev!
      }
      
      // Update the subject's value
      computedSubject.value = newValue
      
      // Notify all observers that depend on this computed value
      for (const obs of computedSubject.observers) {
        updateObserver(obs as Observer<T>)
      }
      
      return newValue
    },
  }
  
  // Compute the initial value
  updateObserver(observer)
  
  // The getter function that returns the computed value
  const getter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    
    // When this computed value is accessed while another observer is active,
    // register the current observer as depending on this computed value
    if (currentObserver && currentObserver !== observer) {
      computedSubject.observers.add(currentObserver)
    }
    
    return computedSubject.value
  }
  
  return getter
}