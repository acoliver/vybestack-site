/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Accepts valid Base64 input with or without padding and validates the input.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate Base64 input format
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validate if a string is valid Base64 according to RFC 4648.
 * Accepts the standard Base64 alphabet with optional padding.
 */
function isValidBase64(input: string): boolean {
  if (!input || typeof input !== 'string') {
    return false;
  }

  // Remove padding for validation of the actual content
  const withoutPadding = input.replace(/=+$/, '');
  
  // Check length is divisible by 4 (after accounting for padding)
  if (input.length % 4 !== 0) {
    return false;
  }

  // Check if remaining characters are valid Base64 alphabet
  const base64Regex = /^[A-Za-z0-9+/]+$/;
  if (!base64Regex.test(withoutPadding)) {
    return false;
  }

  // Check padding placement (padding can only appear at the end)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingOnly = input.substring(paddingIndex);
    // Padding must be all '=' characters
    if (!/^=+$/.test(paddingOnly)) {
      return false;
    }
    
    // Can only have 0, 1, or 2 padding characters
    if (paddingOnly.length > 2) {
      return false;
    }
    
    // If there are 2 padding chars, the length must be divisible by 4
    // (this means we had 3 bytes of input originally)
    const sansPadding = input.substring(0, paddingIndex);
    if (paddingOnly.length === 2 && sansPadding.length % 4 !== 2) {
      return false;
    }
    
    // If there is 1 padding char, the length before padding must be 3 mod 4
    // (this means we had 2 bytes of input originally)
    if (paddingOnly.length === 1 && sansPadding.length % 4 !== 3) {
      return false;
    }
  }

  return true;
}
