/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Signal,
  Observer as ObserverType
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let signalValue = value
  
  const signal: Signal<T> = {
    value: signalValue,
    observers: new Set<ObserverType>(),
    get() {
      // Track current observer as dependent
      const current = getActiveObserver()
      if (current) {
        signal.observers.add(current)
      }
      return signalValue
    },
    set(newValue: T) {
      signalValue = newValue
      // Notify all observers that value has changed
      signal.observers.forEach(observer => {
        observer.updateFn(observer)
      })
      return signalValue
    },
    notify() {
      signal.observers.forEach(observer => {
        observer.updateFn(observer)
      })
    },
    subscribe(observer: ObserverType) {
      signal.observers.add(observer)
      return () => {
        signal.observers.delete(observer)
      }
    },
    unsubscribe(observer: ObserverType) {
      signal.observers.delete(observer)
    }
  }

  const getter: GetterFn<T> = () => {
    return signal.get()
  }

  const setter: SetterFn<T> = (newValue: T) => {
    signalValue = newValue
    // Notify all observers that value has changed
    signal.observers.forEach(observer => {
      observer.updateFn(observer)
    })
    return signalValue
  }

  return [getter, setter]
}
