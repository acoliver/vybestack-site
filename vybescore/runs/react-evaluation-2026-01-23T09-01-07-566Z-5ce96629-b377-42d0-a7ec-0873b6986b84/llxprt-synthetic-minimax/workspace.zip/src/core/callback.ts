/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create a signal to track the callback's value changes
  const callbackValue = _value
  
  const observer: Observer<T> = {
    name: 'callback',
    value: callbackValue,
    updateFn: (obs: Observer<unknown>) => {
      if (disposed) return obs
      
      try {
        // Execute the callback with current value
        updateFn(callbackValue)
      } catch (error) {
        // Log error but don't stop execution
        console.error('Callback error:', error)
      }
      
      return obs
    },
    dispose: () => {
      disposed = true
    }
  }
  
  // Immediately execute the callback to establish dependency tracking
  if (!disposed) {
    try {
      // Set this observer as active to track dependencies
      setActiveObserver(observer)
      updateFn(callbackValue)
    } catch (error) {
      console.error('Initial callback error:', error)
    } finally {
      setActiveObserver(null)
    }
  }
  
  return () => {
    if (disposed) return
    disposed = true
    if (observer.dispose) {
      observer.dispose()
    }
  }
}
