/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  getActiveObserver,
  EqualFn,
  Signal,
  Observer as ObserverType
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  _value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let computedValue: T | undefined = _value
  
  const signal: Signal<T> = {
    value: _value as T, // Use initial value safely
    observers: new Set<ObserverType>(),
    get() {
      // Track current observer as dependent
      const current = getActiveObserver()
      if (current) {
        signal.observers.add(current)
      }
      return computedValue as T
    },
    set(newValue: T) {
      computedValue = newValue
      signal.value = newValue
      // Notify all observers to recompute
      signal.observers.forEach(observer => {
        observer.updateFn(observer)
      })
      return computedValue as T
    },
    notify() {
      signal.observers.forEach(observer => {
        observer.updateFn(observer)
      })
    },
    subscribe(observer: ObserverType) {
      signal.observers.add(observer)
      return () => {
        signal.observers.delete(observer)
      }
    },
    unsubscribe(observer: ObserverType) {
      signal.observers.delete(observer)
    }
  }

  const getter: GetterFn<T> = () => {
    const current = getActiveObserver()
    if (current) {
      signal.observers.add(current)
    }
    
    // Execute update function to compute current value
    // Use initial value if computedValue is undefined, otherwise use current value
    const valueToUse = computedValue !== undefined ? computedValue : _value
    const computedResult = valueToUse !== undefined
      ? updateFn(valueToUse)
      : updateFn()
    
    computedValue = computedResult
    signal.value = computedResult // Keep signal.value in sync
    
    return computedResult
  }
  
  return getter
}
