/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Observer interface
export interface Observer<T = unknown> {
  name?: string
  value?: T
  updateFn: (observer: Observer<unknown>) => Observer<unknown>
  dispose?: () => void
}

// Signal for reactive values
export interface Signal<T = unknown> {
  value: T
  observers: Set<Observer<unknown>>
  get: () => T
  set: (value: T) => T
  notify: () => void
  subscribe: (observer: Observer<unknown>) => () => void
  unsubscribe: (observer: Observer<unknown>) => void
}

// Effect for reactive dependencies
export interface Effect {
  name?: string
  update: () => void
  dispose?: () => void
}

// Observer variations for exports
export interface ObserverR<T = unknown> extends Observer<T> {
  value?: T
}

export interface ObserverV<T = unknown> extends Observer<T> {
  value: T
}

// Subject interface and variations
export interface Subject<T = unknown> {
  name?: string
  observers: Set<Observer<T>>
  value?: T
  notify: () => void
  subscribe?: (observer: Observer<T>) => () => void
  unsubscribe?: (observer: Observer<T>) => void
}

export interface SubjectR<T = unknown> extends Subject<T> {
  value?: T
}

export interface SubjectV<T = unknown> extends Subject<T> {
  value: T
}

// Active observer management
let activeObserver: Observer<unknown> | null = null

export function getActiveObserver(): Observer<unknown> | null {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | null) {
  activeObserver = observer
}
