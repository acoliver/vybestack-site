// Debug script to understand why Argentine phone validation is failing
const testPhone = '+54 341 123 4567';
console.log('Testing with:', testPhone);

// Normalize whitespace
const normalized = testPhone.replace(/\s+/g, ' ').trim();
console.log('Normalized:', normalized);

// Try with more flexible digit grouping
const match = normalized.match(/^(\+54)?\s*(0)?\s*(9)?\s*([1-9]\d{1,3})\s*((?:\d\s*){6,8})$/);
console.log('Match result:', match);

if (match) {
  const [_, countryCode, trunkPrefix, mobileIndicator, areaCode, subscriber] = match;
  console.log('Country code:', countryCode);
  console.log('Trunk prefix:', trunkPrefix);
  console.log('Mobile indicator:', mobileIndicator);
  console.log('Area code:', areaCode);
  console.log('Subscriber:', subscriber);
  
  // Validate area code length (2-4 digits)
  console.log('Area code length check:', areaCode.length >= 2 && areaCode.length <= 4);
  
  // Validate subscriber number (6-8 digits)
  const cleanSubscriber = subscriber.replace(/\s/g, '');
  console.log('Clean subscriber:', cleanSubscriber);
  console.log('Subscriber length check:', cleanSubscriber.length >= 6 && cleanSubscriber.length <= 8);
  
  // Check if country code is present
  console.log('Country code present:', !!countryCode);
  
  // If country code is present, trunk prefix is optional
  // If country code is absent, trunk prefix is required
  console.log('Trunk prefix validation:', !countryCode && !trunkPrefix ? false : true);
}