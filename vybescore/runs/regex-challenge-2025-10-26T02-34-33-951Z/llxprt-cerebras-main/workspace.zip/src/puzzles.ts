/**
 * Finds words in text that start with the given prefix but excludes those in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with the prefix
  const regex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  const lowerExceptions = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !lowerExceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds for matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token only when preceded by a digit (but not at the beginning of the string)
  // We want to return the digit + token combination
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  return text.match(regex) || [];
}

/**
 * Validates passwords based on strength requirements.
 * Must be at least 10 characters long with uppercase, lowercase, digit, and symbol.
 * No whitespace and no immediate repeated sequences (e.g., abab).
 */
export function isStrongPassword(value: string): boolean {
  // Check basic requirements
  if (value.length < 10 || 
      !/[A-Z]/.test(value) || 
      !/[a-z]/.test(value) || 
      !/\d/.test(value) || 
      !/\W|_/.test(value) || 
      /\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This pattern checks if any substring of length 2 or more is immediately followed by itself
  if (/(.+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses don't trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // Regex pattern for IPv6 addresses including shorthand ::
  // This is a simplified pattern; in production, more precise validation would be needed
  const ipv6Regex = /(?:^|(?<=\s))(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))(?=\s|$)/;
  
  // Make sure it's not an IPv4 address
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  return ipv6Regex.test(value) && !ipv4Regex.test(value);
}