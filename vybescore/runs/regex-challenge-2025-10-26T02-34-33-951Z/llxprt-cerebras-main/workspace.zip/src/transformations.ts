/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Inserts exactly one space between sentences, collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, replace multiple spaces with single spaces
  // Then capitalize first letter of each sentence
  return text
    .replace(/\s+/g, ' ')
    .replace(/(^|[\.\?!]\s+)([a-z])/g, (match, p1, p2) => p1 + p2.toUpperCase())
    .trim();
}

/**
 * Finds URLs in the text and returns them as an array.
 * Excludes trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex pattern to match URLs
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.!?,;:]+$/, ''));
}

/**
 * Forces all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:/g, 'https:');
}

/**
 * Rewrites URLs beginning with http://example.com/ to https://...
 * Moves paths beginning with /docs/ to docs.example.com
 * Skips host rewrite when paths contain dynamic elements like cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // Process URLs that match our criteria
  return text.replace(/http:\/\/([\w.-]+)(\/[^\s]*)?/g, (match, host, path = '/') => {
    // Always upgrade to HTTPS
    let secureUrl = `https://${host}${path}`;
    
    // Check for dynamic hints and exclude host rewrite if found
    const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // If path starts with /docs/ and no dynamic hints, rewrite host to docs.example.com
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      secureUrl = `https://docs.${host}${path}`;
    }
    
    // Remove trailing punctuation
    return secureUrl.replace(/[.!?,;:]+$/, '');
  });
}

/**
 * Extracts the year from mm/dd/yyyy string format.
 * Returns 'N/A' when the format is invalid or month/day values are incorrect.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format with validation for month and day ranges
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  // Get the year part
  const year = match[3];
  
  // Additional validation for month/day combinations
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Basic validation for days in months
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Simplified max days (Feb including leap)
  
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}