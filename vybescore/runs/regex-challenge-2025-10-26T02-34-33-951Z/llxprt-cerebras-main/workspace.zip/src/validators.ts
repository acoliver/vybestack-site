export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses based on typical format requirements.
 * Accepts typical addresses such as `name+tag@example.co.uk`.
 * Rejects invalid forms like double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Regex to validate email addresses
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for trailing dots and double dots
  if (!value || value.endsWith('.') || value.includes('..')) {
    return false;
  }
  
  // Check for underscores in domain part
  const [localPart, domainPart] = value.split('@');
  if (!localPart || !domainPart || domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting formats like:
 * (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix. Disallows impossible area codes (leading 0/1).
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Validate format with various separators
  const phoneRegex = /^(\+1\s?)?(\([2-9]\d{2}\)|[2-9]\d{2})[\s\-]?\d{3}[\s\-]?\d{4}$/;
  
  // Clean the phone number by removing non-digits except for '+', then check format
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Validate area code doesn't start with 0 or 1
  const areaCodeCheck = /^(\+1)?([2-9]\d{2})\d{7}$/;
  
  // Check if too short
  if (cleaned.replace(/\+/g, '').length < 10) {
    return false;
  }
  
  return phoneRegex.test(value) && areaCodeCheck.test(cleaned);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Allow whitespace variations in the format
  // Optional country code +54
  // Optional trunk prefix 0 immediately before the area code
  // Optional mobile indicator 9 between country/trunk and area code
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber number: 6-8 digits total
  // When country code is omitted, must begin with trunk prefix 0
  
  // Normalize whitespace
  const normalized = value.replace(/\s+/g, ' ').trim();
  
  // Use a more flexible pattern for subscriber digits
  const match = normalized.match(/^(\+54)?\s*(0)?\s*(9)?\s*([1-9]\d{1,3})\s*((?:\d\s*){6,8})$/);
  
  if (!match) {
    return false;
  }
  
  const [_, countryCode, trunkPrefix, _mobileIndicator, areaCode, subscriber] = match;
  
  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  const cleanSubscriber = subscriber.replace(/\s/g, '');
  if (cleanSubscriber.length < 6 || cleanSubscriber.length > 8) {
    return false;
  }
  
  // If country code is present, trunk prefix is optional
  // If country code is absent, trunk prefix is required
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  if (!value) {
    return false;
  }
  
  // Name regex allowing unicode letters, accents, apostrophes, hyphens, and spaces
  // But rejecting digits and symbols
  const nameRegex = /^[^\d\p{S}]+$/u;
  
  // Additional check to reject X Æ A-12 style names (containing digits)
  if (/\d/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Helper function to run the Luhn algorithm on credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx by prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  // Visa
  if (/^4/.test(cleanValue) && [13, 16, 19].includes(cleanValue.length)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Mastercard
  if ((/^5[1-5]/.test(cleanValue) || /^2[2-7]/.test(cleanValue)) && cleanValue.length === 16) {
    // More precise check for 2221-2720 range
    if (/^2[2-7]/.test(cleanValue)) {
      const prefix = parseInt(cleanValue.substring(0, 4), 10);
      if (prefix < 2221 || prefix > 2720) {
        return false;
      }
    }
    return runLuhnCheck(cleanValue);
  }
  
  // AmEx
  if ((/^34/.test(cleanValue) || /^37/.test(cleanValue)) && cleanValue.length === 15) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}