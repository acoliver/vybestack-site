import express, { Request, Response } from 'express';
import { Server as HttpServer } from 'http';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

type ServerInstance = HttpServer;

class FormServer {
  private app: express.Application;
  private db: Database | null = null;
  private server: ServerInstance | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });

      let dbData: Uint8Array | null = null;
      if (fs.existsSync(this.dbPath)) {
        const fileData = fs.readFileSync(this.dbPath);
        dbData = new Uint8Array(fileData);
      }

      this.db = new SQL.Database(dbData);

      if (!dbData) {
        const schema = fs.readFileSync(
          path.resolve(__dirname, '..', 'db', 'schema.sql'),
          'utf8'
        );
        this.db.run(schema);
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (!this.db) return;

    try {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      fs.writeFileSync(this.dbPath, buffer);
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }

  private validateFormData(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and hyphens' });
    }

    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else if (!/^\+?[0-9\s()\-.]+$/.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, hyphens, and optional leading +' });
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: Partial<FormData> = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        streetAddress: req.body.streetAddress,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone
      };

      const errors = this.validateFormData(formData);

      if (errors.length > 0) {
        res.render('form', {
          errors: errors.map(e => e.message),
          values: formData
        });
        return;
      }

      try {
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName || '',
          formData.lastName || '',
          formData.streetAddress || '',
          formData.city || '',
          formData.stateProvince || '',
          formData.postalCode || '',
          formData.country || '',
          formData.email || '',
          formData.phone || ''
        ]);

        stmt.free();
        this.saveDatabase();

        res.redirect('/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        res.render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData
        });
      }
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', {
        firstName: 'Friend'
      });
    });
  }

  public async start(port: number = 3535): Promise<void> {
    await this.initializeDatabase();
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    }) as unknown as ServerInstance;

    process.on('SIGTERM', () => this.gracefulShutdown());
    process.on('SIGINT', () => this.gracefulShutdown());
  }

  private gracefulShutdown(): void {
    console.log('Shutting down gracefully...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('HTTP server closed');
        if (this.db) {
          this.db.close();
          console.log('Database closed');
        }
        process.exit(0);
      });
    }
  }
}

async function main(): Promise<void> {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  const server = new FormServer();
  
  try {
    await server.start(port);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error('Application error:', error);
    process.exit(1);
  });
}

export default FormServer;
