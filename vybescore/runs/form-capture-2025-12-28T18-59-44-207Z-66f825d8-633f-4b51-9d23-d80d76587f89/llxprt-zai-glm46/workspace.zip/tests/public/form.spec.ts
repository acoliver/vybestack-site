import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server';

let server: { close: () => Promise<void> } | null = null;
let app: unknown = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const result = await startServer();
  server = result.server;
  app = result.app;
});

afterAll(async () => {
  if (server && server.close) {
    await server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
    expect(response.text).toContain('Submit');
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: '+44 20 7946 0958'
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Verify thank you page is accessible
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'invalid-email',
        phone: '+54 9 11 1234-5678'
      });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Email format is invalid');
  });

  it('accepts international phone and postal formats', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Marie',
        lastName: 'Dupont',
        streetAddress: '78 Rue de Rivoli',
        city: 'Paris',
        stateProvince: 'Île-de-France',
        postalCode: '75001',
        country: 'France',
        email: 'marie@example.com',
        phone: '+33 1 42 86 83 45'
      });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
