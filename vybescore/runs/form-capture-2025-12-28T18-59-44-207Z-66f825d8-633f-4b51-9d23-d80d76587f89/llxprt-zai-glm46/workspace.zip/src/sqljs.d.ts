declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer) => Database;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): RunResult;
    exec(sql: string): QueryExecResult[];
    export(): Uint8Array;
    close(): void;
  }

  export interface RunResult {
    columns: string[];
  }

  export interface QueryExecResult extends Array<QueryExecResultModule> {
    columns: string[];
    values: unknown[][];
  }

  export interface QueryExecResultModule {
    [key: string]: unknown;
  }

  export default function initSqlJs(config?: { locateFile?: (filename: string) => string }): Promise<SqlJsStatic>;
}
