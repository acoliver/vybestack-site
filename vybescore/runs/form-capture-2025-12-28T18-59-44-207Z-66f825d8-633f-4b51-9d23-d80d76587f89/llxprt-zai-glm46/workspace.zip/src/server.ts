import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ServerWithClose {
  close: () => Promise<void>;
}

let db: Database | null = null;

// Initialize SQLite database
async function initializeDatabase(): Promise<Database> {
  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Read schema
  const schemaSql = fs.readFileSync(SCHEMA_PATH, 'utf-8');

  let database: Database;
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    // Load existing database
    const buffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(buffer);
  } else {
    // Create new database
    database = new SQL.Database();
    database.run(schemaSql);
    saveDatabase(database);
  }

  return database;
}

// Save database to disk
function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Validate email format
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

// Validate phone number (international formats)
function isValidPhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s() -]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

// Validate postal code (alphanumeric)
function isValidPostalCode(postal: string): boolean {
  const postalRegex = /^[\dA-Za-z\s -]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

// Validate form data
function validateForm(data: FormData): string[] {
  const errors: string[] = [];

  // Required fields
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State / Province / Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal / Zip code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');

  // Email format
  if (data.email?.trim() && !isValidEmail(data.email.trim())) {
    errors.push('Email format is invalid');
  }

  // Phone format
  if (data.phone?.trim() && !isValidPhone(data.phone.trim())) {
    errors.push('Phone number format is invalid (may contain digits, spaces, parentheses, dashes, and a leading +)');
  }

  // Postal code format
  if (data.postalCode?.trim() && !isValidPostalCode(data.postalCode.trim())) {
    errors.push('Postal code format is invalid (may contain letters, digits, spaces, and dashes)');
  }

  return errors;
}

// Create Express app
function createApp(): express.Express {
  const app = express();

  // Parse request bodies
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // Serve static files
  app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

  // Set EJS as view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, 'templates'));

  // Home route - render form
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });

  // Form submission
  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);

    if (errors.length > 0) {
      // Validation failed - redisplay form with errors
      res.status(400).render('form', {
        errors,
        values: formData
      });
      return;
    }

    // Validation successful - insert into database
    if (db) {
      db.run(
        `INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.firstName.trim(),
          formData.lastName.trim(),
          formData.streetAddress.trim(),
          formData.city.trim(),
          formData.stateProvince.trim(),
          formData.postalCode.trim(),
          formData.country.trim(),
          formData.email.trim(),
          formData.phone.trim()
        ]
      );

      // Save database to disk
      saveDatabase(db);
    }

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  });

  // Thank you route
  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  });

  return app;
}

// Start server
async function startServer(): Promise<{ app: express.Express; server: ServerWithClose }> {
  // Initialize database
  db = await initializeDatabase();
  console.log(`Database initialized at ${DB_PATH}`);

  // Create Express app
  const app = createApp();

  // Get port from environment or use default
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

  // Start server
  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Store original close method
  const originalClose = server.close.bind(server);

  // Create close function for graceful shutdown
  const serverWithClose = server as unknown as ServerWithClose;
  serverWithClose.close = () => {
    return new Promise<void>((resolve) => {
      originalClose(() => {
        if (db) {
          db.close();
          db = null;
          console.log('Database connection closed');
        }
        console.log('Server closed');
        resolve();
      });
    });
  };

  // Handle SIGTERM for graceful shutdown
  process.on('SIGTERM', async () => {
    console.log('SIGTERM received, closing server...');
    await serverWithClose.close();
    process.exit(0);
  });

  return { app, server: serverWithClose };
}

// Only start server if this is the main module
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export for testing
export { startServer, createApp, FormData };
