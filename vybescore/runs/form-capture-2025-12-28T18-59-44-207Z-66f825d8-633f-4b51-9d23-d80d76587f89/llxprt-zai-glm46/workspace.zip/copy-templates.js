import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const srcTemplates = path.resolve(__dirname, 'src', 'templates');
const distTemplates = path.resolve(__dirname, 'dist', 'templates');

// Copy templates to dist
if (fs.existsSync(srcTemplates)) {
  fs.mkdirSync(distTemplates, { recursive: true });
  const files = fs.readdirSync(srcTemplates);
  for (const file of files) {
    fs.copyFileSync(
      path.join(srcTemplates, file),
      path.join(distTemplates, file)
    );
  }
  console.log('Templates copied to dist/templates');
}
