export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with robust regex.
 * Accepts: name@tag@example.co.uk
 * Rejects: double dots, trailing dots, underscores in domain
 */
export function isValidEmail(value: string): boolean {
  // Check for double dots anywhere
  if (/\.\./.test(value)) return false;
  
  // Check for trailing dot
  if (/\.$/.test(value)) return false;
  
  // Split by @ and validate structure
  const parts = value.split('@');
  if (parts.length < 2) return false;
  
  // Local part is everything before the last @
  const lastAtIndex = value.lastIndexOf('@');
  const localPart = value.substring(0, lastAtIndex);
  const domain = value.substring(lastAtIndex + 1);
  
  // Local part cannot start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Check for underscore in domain
  if (domain.includes('_')) return false;
  
  // Domain cannot start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) return false;
  
  // Main regex for email validation
  // Local part: allowed chars, dots allowed (but not consecutive or leading/trailing)
  // Domain: subdomains allowed, no underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$/;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common separators and optional +1 prefix.
 * Formats: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.trim();
  
  // Remove all separators to get just the digits
  const digitsOnly = cleaned.replace(/[\s\-.()]/g, '');
  
  // Minimum length check: 10 digits (area code + 7 digit number) or 11 with country code
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // Extract area code (first 3 digits after optional 1)
  const areaCodeStart = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(areaCodeStart, areaCodeStart + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digitsOnly.substring(areaCodeStart + 3, areaCodeStart + 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Full format validation - ensure proper structure with optional separators
  const baseRegex = /^\+?1?[\s\-.]?\(?[2-9]\d{2}\)?[\s\-.]?[2-9]\d{2}[\s\-.]?\d{4}$/;
  
  return baseRegex.test(cleaned);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.replace(/[\s\-.]/g, '');
  
  const argentineRegex = /^(?:\+54)?0?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentineRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits (leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] < '1' || areaCode[0] > '9') return false;
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If country code is omitted, trunk prefix 0 must be present
  const hasCountryCode = cleaned.startsWith('+54');
  
  if (!hasCountryCode && !value.includes('0')) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}'\-\s]*[\p{L}\p{M}]$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Check for symbols (excluding allowed apostrophe, hyphen, space)
  const symbolRegex = /[^\p{L}\p{M}'\-\s]/u;
  if (symbolRegex.test(value)) return false;
  
  return true;
}

/**
 * Luhn algorithm checksum for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let double = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (double) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    double = !double;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx prefixes and lengths + Luhn check).
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');
  
  if (!/^\d{13,19}$/.test(cleaned)) return false;
  
  // Visa: 4, 13 or 16 digits
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 51-55 or 2221-2720, 16 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-2][0-1]\d{12})$/;
  
  // AmEx: 34 or 37, 15 digits
  const amexRegex = /^3[47]\d{13}$/;

  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}
