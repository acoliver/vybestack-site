/**
 * Find words starting with the prefix, excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const prefixRegex = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'gi');
  
  const matches = text.match(prefixRegex) || [];
  
  const uniqueMatches = Array.from(new Set(matches.map(m => m.toLowerCase())));
  
  return uniqueMatches.filter(word => 
    !exceptions.some(exc => exc.toLowerCase() === word)
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit + token combination
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Ensure the match is not at the start of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validate passwords:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Length check
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Character class checks
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;
  
  // Check for repeated sequences (e.g., abab, abcabc)
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const substr1 = value.substring(i, i + len);
      const substr2 = value.substring(i + len, i + len * 2);
      
      if (substr1 === substr2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (supports shorthand ::)
  // This matches hextets separated by colons, allowing ::
  const ipv6Pattern = /(?:^|[^a-f\d.:])([0-9a-f]{1,4}(?::[0-9a-f]{1,4}){1,7}|(?:[0-9a-f]{1,4}:){1,7}:|(?:[0-9a-f]{1,4}:){1,6}:[0-9a-f]{1,4}|(?:[0-9a-f]{1,4}:){1,5}(?::[0-9a-f]{1,4}){1,2}|(?:[0-9a-f]{1,4}:){1,4}(?::[0-9a-f]{1,4}){1,3}|(?:[0-9a-f]{1,4}:){1,3}(?::[0-9a-f]{1,4}){1,4}|(?:[0-9a-f]{1,4}:){1,2}(?::[0-9a-f]{1,4}){1,5}|[0-9a-f]{1,4}:(?::[0-9a-f]{1,4}){1,6}|:(?::[0-9a-f]{1,4}){1,7}|::(?:[0-9a-f]{1,4}:){0,6}[0-9a-f]{1,4})(?![a-f\d.:])/i;
  
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  const hasIPv6 = ipv6Pattern.test(value);
  
  // Also check for IPv4-mapped IPv6 addresses
  const ipv4Mapped = /::ffff:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/i;
  
  if (ipv4Mapped.test(value)) {
    // This is IPv4-mapped IPv6, count as IPv6
    return true;
  }
  
  // Exclude pure IPv4
  if (ipv4Pattern.test(value) && !hasIPv6) {
    return false;
  }
  
  return hasIPv6;
}
