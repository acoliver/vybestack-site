/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences if needed.
 * Collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around sentence boundaries
  let result = text.replace(/\s*([.!?])\s*/g, '$1 ');
  
  // Remove extra spaces within text
  result = result.replace(/[ \t]+/g, ' ');
  
  // Capitalize first character of each sentence
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, char) => {
    return prefix + char.toUpperCase();
  });
  
  // Capitalize very first character if it's lowercase
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  // Trim leading/trailing whitespace
  result = result.trim();
  
  return result;
}

/**
 * Find URLs in text, returning matches without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::\d+)?(?:\/(?:[^\s<\\[()]|\([^)]*\))*)?/gi;

  const matches = text.match(urlRegex) || [];

  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?)\]>]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - For /docs/ paths, rewrite host to docs.example.com
 * - Skip host rewrite for cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/[^\s<]*?)(?=[\s<]|$)/gi, (match, path) => {
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    // Check for dynamic hints that should prevent host rewrite
    const hasCgiBin = /cgi-bin/i.test(path);
    const hasQueryString = /[?&=]/.test(path);
    const hasLegacyExt = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    if (isDocsPath && !hasCgiBin && !hasQueryString && !hasLegacyExt) {
      // Rewrite to docs.example.com
      return `https://docs.example.com${path}`;
    }
    
    // Just upgrade scheme
    return `https://example.com${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' for invalid format.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}
