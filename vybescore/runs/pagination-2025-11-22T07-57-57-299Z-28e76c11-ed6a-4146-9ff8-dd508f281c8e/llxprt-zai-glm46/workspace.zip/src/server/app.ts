import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(pageParam?: string, limitParam?: string): { page: number; limit: number } {
  const DEFAULT_PAGE = 1;
  const DEFAULT_LIMIT = 5;
  const MAX_LIMIT = 100;

  let page = DEFAULT_PAGE;
  let limit = DEFAULT_LIMIT;

  if (pageParam !== undefined) {
    if (pageParam === '' || !/^\d+$/.test(pageParam)) {
      throw new Error('Page must be a positive integer');
    }
    page = Number(pageParam);
    if (page <= 0) {
      throw new Error('Page must be greater than 0');
    }
  }

  if (limitParam !== undefined) {
    if (limitParam === '' || !/^\d+$/.test(limitParam)) {
      throw new Error('Limit must be a positive integer');
    }
    limit = Number(limitParam);
    if (limit <= 0) {
      throw new Error('Limit must be greater than 0');
    }
    if (limit > MAX_LIMIT) {
      throw new Error(`Limit cannot exceed ${MAX_LIMIT}`);
    }
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    try {
      const { page, limit } = validatePaginationParams(pageParam, limitParam);
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Invalid pagination parameters';
      res.status(400).json({ error: errorMessage });
    }
  });

  return app;
}
