import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import type http from 'http';
import { app as expressApp } from '../../dist/server.js';

let server: http.Server | null = null;

beforeAll(async () => {
  return new Promise((resolve) => {
    const serverInstance = expressApp.listen(3536, () => {
      server = serverInstance;
      resolve(undefined);
    });
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  // Clean up test database
  const dbPath = path.resolve('data', 'submissions.sqlite');
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const { app: expressApp } = await import('../../dist/server.js');
    const response = await request(expressApp).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First Name');
    expect(response.text).toContain('Last Name');
    expect(response.text).toContain('Street Address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal/Zip Code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email Address');
    expect(response.text).toContain('Phone Number');
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    const dbPath = path.resolve('data', 'submissions.sqlite');
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const { app: expressApp } = await import('../../dist/server.js');
    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'State',
      postal_code: '12345',
      country: 'Country',
      email: 'john@example.com',
      phone: '+1234567890'
    };

    const response = await request(expressApp)
      .post('/submit')
      .type('form')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for missing required fields', async () => {
    const { app: expressApp } = await import('../../dist/server.js');
    const incompleteData = {
      first_name: 'John'
      // Missing other required fields
    };

    const response = await request(expressApp)
      .post('/submit')
      .type('form')
      .send(incompleteData);

    expect(response.status).toBe(400);
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Street address is required');
  });

  it('shows validation error for invalid email', async () => {
    const { app: expressApp } = await import('../../dist/server.js');
    const invalidEmailData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'State',
      postal_code: '12345',
      country: 'Country',
      email: 'invalid-email', // Invalid email
      phone: '+1234567890'
    };

    const response = await request(expressApp)
      .post('/submit')
      .type('form')
      .send(invalidEmailData);

    expect(response.status).toBe(400);
    expect(response.text).toContain('Please enter a valid email address');
  });
});
