export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export class ValidationService {
  static validateForm(data: Partial<FormData>): ValidationResult {
    const errors: Record<string, string> = {};

    // Required field validation
    const requiredFields = [
      'first_name', 'last_name', 'street_address', 'city', 
      'state_province', 'postal_code', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      const value = data[field as keyof FormData];
      if (!value || value.trim().length === 0) {
        errors[field] = `${this.formatFieldName(field)} is required`;
      }
    }

    // Email validation
    if (data.email && data.email.trim()) {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email.trim())) {
        errors.email = 'Please enter a valid email address';
      }
    }

    // Phone validation
    if (data.phone && data.phone.trim()) {
      const phoneRegex = /^\+?[0-9\s\-()]{7,}$/;
      if (!phoneRegex.test(data.phone.trim())) {
        errors.phone = 'Please enter a valid phone number';
      }
    }

    // Postal code validation (alphanumeric support)
    if (data.postal_code && data.postal_code.trim()) {
      const postalRegex = /^[a-zA-Z0-9\s-]{3,12}$/;
      if (!postalRegex.test(data.postal_code.trim())) {
        errors.postal_code = 'Please enter a valid postal code';
      }
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private static formatFieldName(field: string): string {
    const fieldNames: Record<string, string> = {
      first_name: 'First name',
      last_name: 'Last name',
      street_address: 'Street address',
      state_province: 'State / Province / Region',
      postal_code: 'Postal / Zip code',
      country: 'Country'
    };
    
    return fieldNames[field] || field.charAt(0).toUpperCase() + field.slice(1).replace(/_/g, ' ');
  }
}