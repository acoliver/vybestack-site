import { Request, Response, NextFunction } from 'express';
import { ValidationError } from '../types/index.js';

export const validationMiddleware = (req: Request, res: Response, next: NextFunction) => {
  const { body } = req;
  const errors: ValidationError[] = [];

  // Validate first name
  if (!body.first_name?.trim()) {
    errors.push({ field: 'first_name', message: 'First name is required' });
  }

  // Validate last name
  if (!body.last_name?.trim()) {
    errors.push({ field: 'last_name', message: 'Last name is required' });
  }

  // Validate street address
  if (!body.street_address?.trim()) {
    errors.push({ field: 'street_address', message: 'Street address is required' });
  }

  // Validate city
  if (!body.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  // Validate state/province/region
  if (!body.state_province?.trim()) {
    errors.push({ field: 'state_province', message: 'State/Province/Region is required' });
  }

  // Validate postal code
  if (!body.postal_code?.trim()) {
    errors.push({ field: 'postal_code', message: 'Postal/Zip code is required' });
  }

  // Validate country
  if (!body.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Validate email
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!body.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!emailRegex.test(body.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Validate phone number
  const phoneRegex = /^\+?[\d\s()\-+]+$/;
  if (!body.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!phoneRegex.test(body.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // If there are validation errors, render the form with errors
  if (errors.length > 0) {
    const errorMessages = errors.map(err => err.message);
    return res.status(400).render('form', {
      errors: errorMessages,
      values: body
    });
  }

  next();
};