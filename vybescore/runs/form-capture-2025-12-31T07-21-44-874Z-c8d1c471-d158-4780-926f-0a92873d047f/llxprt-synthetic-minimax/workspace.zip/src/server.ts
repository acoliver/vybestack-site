import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import { DatabaseService } from './services/database.js';
import { validationMiddleware } from './middleware/validation.js';
import { FormData } from './types/index.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
const dbService = new DatabaseService(path.join(__dirname, '../data/submissions.sqlite'));
await dbService.initialize();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', validationMiddleware, async (req, res) => {
  try {
    const formData: FormData = req.body as FormData;
    
    // Save to database
    await dbService.saveSubmission(formData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: ['Internal server error. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Shutting down server...');
  await dbService.close();
  process.exit(0);
});

export { app };

// Only start server if this module is run directly (not imported for tests)
if (process.argv[1] && import.meta.url === `file://${process.argv[1]}`) {
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}
