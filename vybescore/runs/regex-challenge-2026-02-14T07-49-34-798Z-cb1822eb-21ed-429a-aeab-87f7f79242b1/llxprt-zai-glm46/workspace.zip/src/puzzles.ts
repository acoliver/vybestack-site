/**
 * Find words starting with the given prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z0-9_]*)\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  const lowerExceptions = new Set(exceptions.map(e => e.toLowerCase()));
  
  const filtered = matches.filter(word => !lowerExceptions.has(word.toLowerCase()));
  
  return Array.from(new Set(filtered));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to security policy.
 * At least 10 chars, one uppercase, one lowercase, one digit, one symbol, no whitespace, no repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (value.length < 10) {
    return false;
  }
  
  if (/\s/.test(value)) {
    return false;
  }
  
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  if (!/[!@#$%^&*()_+[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const seq1 = value.substring(i, i + len);
      const seq2 = value.substring(i + len, i + len * 2);
      if (seq1 === seq2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  const words = value.split(/\s+/);
  
  for (const word of words) {
    const trimmed = word.trim();
    
    if (ipv4Pattern.test(trimmed)) {
      continue;
    }
    
    if (trimmed.includes(':') && /[0-9a-fA-F]/.test(trimmed)) {
      const colons = (trimmed.match(/:/g) || []).length;
      if (colons >= 2) {
        return true;
      }
      
      if (trimmed.includes('::')) {
        return true;
      }
      
      const parts = trimmed.split(':');
      const validHexParts = parts.filter(p => /^[0-9a-fA-F]{1,4}$/.test(p));
      if (validHexParts.length >= 2) {
        return true;
      }
    }
  }
  
  return false;
}
