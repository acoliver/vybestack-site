/**
 * Capitalize the first character of each sentence, insert exactly one space
 * between sentences, and collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces around sentence boundaries
  let normalized = text.replace(/\s+([.!?])\s*/g, '$1 ');
  
  // Collapse multiple spaces into one, but preserve sentence structure
  normalized = normalized.replace(/[ \t]+/g, ' ');
  
  // Capitalize first character of each sentence
  const result = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Trim leading/trailing whitespace
  return result.trim();
}

/**
 * Extract all URLs from text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https/ftp protocols
  const urlPattern = /(?:https?:|ftp:)?\/\/(?:www\.)?[^\s/$.?#].[^\s]*/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  const cleaned = matches.map(url => {
    return url.replace(/[.,;:!?]+$/, '');
  });
  
  return cleaned;
}

/**
 * Replace http:// with https:// while leaving existing https:// URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite URLs for example.com:
 * - Always upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/(https?:\/\/)(example\.com)(\/[^\s]*)/gi, (match, protocol, host, path) => {
    // Upgrade to https
    const newProtocol = 'https://';
    
    // Check if path should skip host rewrite
    const skipRewritePatterns = [
      /\/cgi-bin\//i,
      /[?&]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#/]|$)/i
    ];
    
    const shouldSkipRewrite = skipRewritePatterns.some(pattern => pattern.test(path));
    
    // Check if path starts with /docs/
    if (!shouldSkipRewrite && /^\/docs\//i.test(path)) {
      return newProtocol + 'docs.example.com' + path;
    }
    
    // Just upgrade protocol
    return newProtocol + host + path;
  });
}

/**
 * Extract four-digit year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
