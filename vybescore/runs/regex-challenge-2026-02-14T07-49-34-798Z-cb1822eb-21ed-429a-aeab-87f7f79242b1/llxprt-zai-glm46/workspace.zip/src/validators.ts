export type PhoneValidationOptions = {
  allowExtensions?: boolean;
}

/**
 * Validate email addresses with robust rules.
 * Accepts: name@tag@example.co.uk (quoted local parts)
 * Rejects: double dots, trailing dots, underscores in domain
 */
export function isValidEmail(value: string): boolean {
  // eslint-disable-next-line no-control-regex
  const emailRegex = /^(?:[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*|"(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21\x23-\x5b\x5d-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])*")@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}|(?:\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-zA-Z0-9-]*[a-zA-Z0-9]:(?:[\x01-\x08\x0b\x0c\x0e-\x1f\x21-\x5a\x53-\x7f]|\\[\x01-\x09\x0b\x0c\x0e-\x7f])+)\]))$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  const [localPart, domain] = value.split('@');
  
  if (!localPart || !domain) {
    return false;
  }

  if (localPart.includes('..') || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  if (domain.includes('..') || domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }

  if (domain.includes('_')) {
    return false;
  }

  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (!/^[a-zA-Z0-9-]+$/.test(part) || part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats and optional +1 country code.
 * Formats: (212) 555-7890, 212-555-7890, 2125557890
 * Rejects: invalid area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  const cleanedValue = value.replace(/[\s()/-]/g, '');
  
  let digits = cleanedValue;
  
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }

  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }

  const exchangeCode = digits.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }

  if (options?.allowExtensions) {
    const extensionMatch = cleanedValue.match(/ext?\s*(\d+)$/i);
    if (extensionMatch) {
      return true;
    }
  }

  return true;
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleanedValue = value.replace(/[\s().]/g, '');
  
  let mainNumber = '';
  
  if (cleanedValue.startsWith('+54')) {
    mainNumber = cleanedValue.substring(3);
  } else if (cleanedValue.startsWith('54') && cleanedValue.length > 10) {
    mainNumber = cleanedValue.substring(2);
  } else {
    if (cleanedValue.startsWith('0')) {
      mainNumber = cleanedValue.substring(1);
    } else {
      return false;
    }
  }

  if (mainNumber.startsWith('9')) {
    mainNumber = mainNumber.substring(1);
  }

  const areaCodeMatch = mainNumber.match(/^(\d{2,4})(\d+)$/);
  if (!areaCodeMatch) {
    return false;
  }

  const [, areaCodeStr, subscriberStr] = areaCodeMatch;
  const areaCode = parseInt(areaCodeStr, 10);
  
  if (areaCode < 10 || areaCode > 9999) {
    return false;
  }

  if (!/^[1-9]/.test(areaCodeStr)) {
    return false;
  }

  if (subscriberStr.length < 6 || subscriberStr.length > 8) {
    return false;
  }

  if (!/^\d+$/.test(subscriberStr)) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  const nameRegex = /^[\p{L}\p{M}'\- ]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }

  if (/\d/.test(value)) {
    return false;
  }

  if (value.trim().length === 0) {
    return false;
  }

  if (/^[\s'-]+$/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Luhn algorithm checksum for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with length, prefix, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  const cleanedValue = value.replace(/[\s/-]/g, '');
  
  if (!/^\d{13,19}$/.test(cleanedValue)) {
    return false;
  }

  const patterns = [
    { prefix: /^4/, length: [13, 16, 19], name: 'Visa' },
    { prefix: /^5[1-5]/, length: [16], name: 'Mastercard' },
    { prefix: /^2[2-7]/, length: [16], name: 'Mastercard' },
    { prefix: /^3[47]/, length: [15], name: 'American Express' },
  ];

  let validPattern = false;
  for (const pattern of patterns) {
    if (pattern.prefix.test(cleanedValue) && pattern.length.includes(cleanedValue.length)) {
      validPattern = true;
      break;
    }
  }

  if (!validPattern) {
    return false;
  }

  return runLuhnCheck(cleanedValue);
}
