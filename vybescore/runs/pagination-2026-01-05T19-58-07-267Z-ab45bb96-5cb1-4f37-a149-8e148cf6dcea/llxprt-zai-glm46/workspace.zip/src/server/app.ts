import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    if (pageParam !== undefined) {
      const page = Number(pageParam);
      if (isNaN(page) || !Number.isInteger(page) || page < 1) {
        return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
      }
      if (page > 1000) {
        return res.status(400).json({ error: 'Page number exceeds maximum allowed value' });
      }
    }

    if (limitParam !== undefined) {
      const limit = Number(limitParam);
      if (isNaN(limit) || !Number.isInteger(limit) || limit < 1) {
        return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
      }
      if (limit > 100) {
        return res.status(400).json({ error: 'Limit exceeds maximum allowed value' });
      }
    }

    const payload = listInventory(db, {
      page: pageParam ? Number(pageParam) : undefined,
      limit: limitParam ? Number(limitParam) : undefined
    });
    res.json(payload);
  });

  return app;
}
