
/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (equal === false) {
    equalFn = undefined
  } else if (equal !== undefined) {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      // Execute the update function to compute the new value
      // During this execution, this observer will be the active one
      // and will track its dependencies
      const newValue = updateFn(currentValue)
      
      // Only update stored value if it actually changed
      const hasChanged = !equalFn || !o.value || !equalFn(o.value, newValue)
      if (hasChanged) {
        o.value = newValue
      }
      return newValue
    },
  }
  
  // Initialize the computed value - this will track dependencies
  updateObserver(o)
  
  let isInitialized = false
  
  return (): T => {
    // If there's an active observer, track this computed value as a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // This computed value should notify the active observer when it changes
      // We need to establish this relationship somehow...
    }
    
    // Always recompute to track dependencies and ensure fresh values,
    // but avoid recomputation during first access (already done during initialization)
    if (isInitialized) {
      updateObserver(o)
    } else {
      isInitialized = true
    }
    
    return o.value!
  }
}
