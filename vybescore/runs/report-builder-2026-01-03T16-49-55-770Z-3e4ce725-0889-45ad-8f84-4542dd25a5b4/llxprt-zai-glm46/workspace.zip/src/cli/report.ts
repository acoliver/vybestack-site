import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { getFormatter, isSupportedFormat } from '../formatters.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const dataFile = args[0];
  if (!dataFile) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('Error: --format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('Error: --output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Error: unknown argument "${arg}"`);
    }
  }

  if (!format) {
    throw new Error('Error: --format is required');
  }

  return { dataFile, format, outputPath, includeTotals };
}

function loadJsonFile(path: string): unknown {
  try {
    const content = fs.readFileSync(path, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Error: malformed JSON in file "${path}": ${error.message}`);
    }
    throw new Error(`Error: unable to read file "${path}": ${(error as Error).message}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    if (!isSupportedFormat(args.format)) {
      throw new Error(`Unsupported format: ${args.format}`);
    }

    const rawData = loadJsonFile(args.dataFile);
    validateReportData(rawData);

    const data = rawData as ReportData;
    const options: RenderOptions = { includeTotals: args.includeTotals };

    const formatter = getFormatter(args.format);
    const output = formatter.render(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(message);
    process.exit(1);
  }
}

main();
