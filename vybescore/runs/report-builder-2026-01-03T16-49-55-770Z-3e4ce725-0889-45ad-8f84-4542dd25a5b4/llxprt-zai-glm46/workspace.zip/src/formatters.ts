import type { Format, Formatter } from './types.js';
import { markdownFormatter } from './formats/markdown.js';
import { textFormatter } from './formats/text.js';

const formatters: Record<Format, Formatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

export function getFormatter(format: Format): Formatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

export function isSupportedFormat(format: string): format is Format {
  return format in formatters;
}
