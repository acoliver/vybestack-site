import initSqlJs from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

// Use dynamic imports to get proper typing
interface SqlJsDatabase {
  exec(sql: string): void;
  run(sql: string, ...params: unknown[]): unknown;
  export(): Uint8Array;
  close(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database file path
const dataDir = path.join(__dirname, '..', '..', 'data');
const dbPath = path.join(dataDir, 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', '..', 'db', 'schema.sql');

// Variables to hold database instance
let db: SqlJsDatabase | null = null;

export const initializeDatabase = async (): Promise<void> => {
  try {
    // Create data directory if it doesn't exist
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Initialize sql.js
    const SQL = await initSqlJs();
    
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database from', dbPath);
    } else {
      // Create new database
      db = new SQL.Database();
      
      // Read and execute schema
      if (fs.existsSync(schemaPath)) {
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db.exec(schema);
        console.log('Created new database and applied schema');
      } else {
        console.error('Schema file not found:', schemaPath);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

export const getDatabase = (): SqlJsDatabase => {
  if (!db) {
    throw new Error('Database not initialized');
  }
  return db;
};

export const saveDatabase = (): void => {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to', dbPath);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
};

export const closeDatabase = (): void => {
  if (db) {
    // Save before closing
    saveDatabase();
    db.close();
    db = null;
    console.log('Database closed');
  }
};