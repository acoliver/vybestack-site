import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, closeDatabase, getDatabase } from './database.js';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Start server with async initialization
(async () => {
  try {
    await initializeDatabase();
    
    // Start server after database is initialized
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown handling
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      closeDatabase();
      process.exit(0);
    };
    
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
    return server;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
})();

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
  
  // Server-side validation
  const errors: string[] = [];
  
  // Required fields validation
  if (!firstName?.trim()) errors.push('First name is required');
  if (!lastName?.trim()) errors.push('Last name is required');
  if (!streetAddress?.trim()) errors.push('Street address is required');
  if (!city?.trim()) errors.push('City is required');
  if (!stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!country?.trim()) errors.push('Country is required');
  if (!email?.trim()) errors.push('Email is required');
  if (!phone?.trim()) errors.push('Phone number is required');
  
  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (email && !emailRegex.test(email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation (allow digits, spaces, parentheses, dashes, and a leading @)
  const phoneRegex = /^@?[0-9\s\-()]+$/;
  if (phone && !phoneRegex.test(phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading @');
  }
  
  // Postal code validation (alphanumeric)
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  if (postalCode && !postalRegex.test(postalCode)) {
    errors.push('Postal code can only contain letters and numbers');
  }
  
  if (errors.length > 0) {
    return res.render('form', { 
      errors, 
      values: { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } 
    });
  }
  
  // Save to database
  try {
    const db = getDatabase();
    db.run(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone]);
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    return res.render('form', { 
})
      errors, 