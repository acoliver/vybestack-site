
import type { ReportData, FormatOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: FormatOptions): string {
  const lines: string[] = [];

  lines.push('# ' + data.title);
  lines.push('');

  lines.push(data.summary);
  lines.push('');

  lines.push('## Entries');
  for (const entry of data.entries) {
    const amount = entry.amount.toFixed(2);
    lines.push('- **' + entry.label + '** — ' + '$' + amount);
  }

  if (options.includeTotals) {
    const total = data.entries.reduce(function(sum: number, entry: typeof data.entries[0]) { return sum + entry.amount; }, 0);
    lines.push('');
    lines.push('**Total:** ' + '$' + total.toFixed(2));
  }

  return lines.join('\n');
}
