#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, FormatOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    inputFile: '',
    format: '',
    includeTotals: false,
  };

  let i = 2;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('-') && result.inputFile === '') {
      result.inputFile = arg;
    } else {
      throw new Error('Unknown argument: ' + arg);
    }
    i++;
  }

  if (result.inputFile === '') {
    throw new Error('Input file is required');
  }

  if (result.format === '') {
    throw new Error('--format is required');
  }

  return result;
}

function loadJsonFile(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content);
    
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string') {
        throw new Error('Entry ' + i + ': missing or invalid label');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry ' + i + ': missing or invalid amount');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON: ' + (error as Error).message);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, options: FormatOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error('Unsupported format: ' + format);
  }
}

function main() {
  try {
    const args = parseArgs(process.argv);
    const data = loadJsonFile(args.inputFile);
    const options: FormatOptions = {
      includeTotals: args.includeTotals,
    };
    const output = renderReport(data, args.format, options);

    if (args.outputPath) {
      writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error: ' + (error as Error).message);
    process.exit(1);
  }
}

main();
