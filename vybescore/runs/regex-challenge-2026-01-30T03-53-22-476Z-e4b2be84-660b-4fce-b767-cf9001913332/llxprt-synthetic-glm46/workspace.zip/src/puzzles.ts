/**
 * Finds words beginning with the specified prefix, excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create word boundary regex to find words with the specified prefix
  const prefixPattern = new RegExp(`\\b${regexEscape(prefix)}[a-zA-Z0-9]*\\b`, 'gi');
  const matches = text.match(prefixPattern) || [];
  
  // Filter out the exceptions
  const filteredMatches = matches.filter(word => 
    !exceptions.some(exception => word.toLowerCase() === exception.toLowerCase())
  );
  
  // Return unique words
  return [...new Set(filteredMatches)];
}

/**
 * Helper function to escape special characters in a regex pattern
 */
function regexEscape(str: string): string {
  return str.replace(/[.*+?^${}()|[\]]/g, '\\$&');
}

/**
 * Returns occurrences of the token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of the token preceded by a digit
  const tokenOccurrences = [];
  let match;
  const tokenRegex = new RegExp(`(\\d${regexEscape(token)})`, 'g');
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Return the full match, including the digit
    const fullMatch = match[0];
    tokenOccurrences.push(fullMatch);
  }
  
  return tokenOccurrences;
}

/**
 * Validates passwords according to security policy:
 * >= 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123", "testtest")
  // This uses a positive lookahead assertion to capture any sequence of 2-6 characters
  // and checks if that sequence is immediately repeated
  if (/(.{2,6})\1/.test(value)) {
    return false;
  }
  
  // All checks passed
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern matches any IPv6 address, including shorthand notation
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  const match = value.match(ipv6Regex);
  if (!match) {
    return false;
  }
  
  // Check if it's an IPv4 address in disguise
  const ipv4Regex = /^[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}$/;
  return !ipv4Regex.test(value);
}
