/**
 * Capitalizes the first character of each sentence, preserving spacing rules.
 * Ensures one space between sentences and collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Step 1: Split the text into sentences
  const regex = /[^.!?]*[.!?]|[^.!?]+$/g;
  const matches = text.match(regex) || [];
  const sentences: string[] = [];
  
  for (const sentence of matches) {
    if (!sentence) continue;
    
    // Trim leading spaces from sentences (except first)
    const trimmedSentence = sentences.length === 0 ? sentence.trimStart() : sentence.trim();
    sentences.push(trimmedSentence);
  }
  
  // Step 2: Capitalize each sentence and reconstruct with proper spacing
  let result = sentences.map((sentence, index) => {
    if (index === 0) {
      // For the first sentence, just capitalize the first letter
      return sentence.replace(/^([a-z])/, (match: string, letter: string) => letter.toUpperCase());
    } else {
      // For subsequent sentences, ensure proper spacing and capitalization
      const firstChar = sentence.charAt(0).toLowerCase();
      if (firstChar >= 'a' && firstChar <= 'z') {
        return ' ' + sentence.replace(/^([a-z])/, (match: string, letter: string) => letter.toUpperCase());
      }
      return ' ' + sentence;
    }
  }).join('');
  
  // Step 3: Collapse multiple spaces while preserving sentence structure
  result = result.replace(/ +/g, ' ');
  
  // Step 4: Capitalize the first letter of the first sentence if needed
  result = result.replace(/^([a-z])/, (match: string, letter: string) => letter.toUpperCase());
  
  return result;
}

/**
 * Extracts URLs from text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching common URL formats
  // Includes protocol, domain with optional subdomains, port, path, query, and fragment
  const urlRegex = /(https?:\/\/|www\.)[^\s<>]+/gi;
  
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * Replaces http:// with https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlRegex = /(http:\/\/example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, protocolDomain, path) => {
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // If the path contains indicators of legacy systems, only upgrade the scheme
      const legacyIndicators = [/\?/, /#/, /cgi-bin/, /\.jsp$/, /\.php$/, /\.asp$/, /\.aspx$/, /\.do$/, /\.cgi$/, /\.pl$/, /\.py$/];
      const hasLegacyIndicators = legacyIndicators.some(indicator => indicator.test(path));
      
      if (hasLegacyIndicators) {
        // Only upgrade scheme, keep host as example.com
        return `https://example.com${path}`;
      } else {
        // Upgrade scheme and change host to docs.example.com
        return `https://docs.example.com${path}`;
      }
    } else {
      // Not a docs path, just upgrade scheme
      return `https://example.com${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' for invalid formats.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Check if month and day are valid
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Check day validity based on month (simplified check, doesn't handle leap years)
  // For a more robust check, we'd need to handle each month's days correctly
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Months with 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  // February basic check (non-leap year)
  if (month === 2 && day > 28) {
    return 'N/A';
  }
  
  return year;
}
