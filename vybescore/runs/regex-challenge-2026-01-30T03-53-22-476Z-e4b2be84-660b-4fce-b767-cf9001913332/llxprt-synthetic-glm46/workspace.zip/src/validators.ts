export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validtes email addresses using regex.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation with some practical limitations
  // Local part: alphanumerics and certain special chars, but no leading/trailing dots, no consecutive dots
  // Domain: alphanumerics and hyphens, but not starting/ending with hyphen, no underscores
  const emailRegex = /^[a-zA-Z0-9](?!.*\.{2})[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]{0,62}[a-zA-Z0-9]@[a-zA-Z0-9](?!.*--)[a-zA-Z0-9-]{0,61}[a-zA-Z0-9](\.[a-zA-Z0-9]([a-zA-Z0-9-]{0,61})[a-zA-Z0-9])*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  // No consecutive dots in local part
  // No dot at start or end of local part
  // No dot at start of domain segments
  const localPartRegex = /^[^@]+/;
  const domainPartRegex = /@(.+)$/;
  
  const localPart = localPartRegex.exec(value)?.[0];
  const domainPart = domainPartRegex.exec(value)?.[1];
  
  if (!localPart || !domainPart) {
    return false;
  }
  
  // No double dots or leading/trailing dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }
  
  // No underscore in domain
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Domain labels should not start or end with hyphen
  const domainLabels = domainPart.split('.');
  for (const label of domainLabels) {
    if (label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers with common formats.
 * Support for (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove spaces and common punctuation to check the core number
  const sanitizedValue = value.replace(/[\s\(\)\-.]/g, '');
  
  // Must be 10 or 11 digits (with optional +1)
  if (!/^\+?1?\d{10}$/.test(sanitizedValue)) {
    return false;
  }
  
  // Extract area code (2nd or 1st digit depending on +1 prefix)
  const areaCode = sanitizedValue.length === 11 
    ? sanitizedValue.substring(2, 5) 
    : sanitizedValue.substring(0, 3);
    
  // Disallow area codes starting with 0 or 1
  if (/^[01]/.test(areaCode)) {
    return false;
  }
  
  // Validate the full format - allow parentheses, hyphens, spaces, dots as separators
  const phoneRegex = /^(?:\+1[\s\-.()]*?)?(?:\(?(\d{3})\)?[\s\-.,]*)?(\d{3})[\s\-.,]*(\d{4})$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens to check the core number structure
  const cleanedValue = value.replace(/[\s\-]/g, '');
  
  // Check for valid patterns:
  // Optional +54, optional 0 trunk prefix, optional 9 for mobile, area code (2-4 digits), subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54)?(0?)(9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = argentinePhoneRegex.exec(cleanedValue);
  
  if (!match) {
    return false;
  }
  
  const countryCode = match[1] || ''; // +54
  const trunkPrefix = match[2] || ''; // 0
  const areaCode = match[4]; // 2-4 digits, not starting with 0
  const subscriberNumber = match[5]; // 6-8 digits
  
  // Area code must be 2-4 digits, starting with 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // If country code is present, trunk prefix is optional
  // If country code is absent, trunk prefix is required
  if (countryCode && trunkPrefix) {
    // If country code is present, trunk prefix must not be present
    return false;
  }
  
  if (!countryCode && !trunkPrefix) {
    // If country code is absent, trunk prefix is required 
    return false;
  }
  
  // Check total format with separators (spaces or hyphens)
  const formatPattern = /^(\+54\s?)?(0?[1-9]\d{0,3}\s?)?(9\s?)?([1-9]\d{0,3})\s?\d{3,4}\s?\d{4}$/;
  
  return formatPattern.test(value);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unconventional names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Names can include Unicode letters, spaces, apostrophes, hyphens, and some diacritical marks
  // But should not contain digits, special symbols, or excessive punctuation
  // This regex matches strings containing only valid name characters
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}\s'-]*[\p{L}\p{M}]$/u;
  
  // Basic format check
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  // Should not contain consecutive dots or punctuation
  if (/[.]{2,}|[']{2,}|[-]{2,}/.test(value)) {
    return false;
  }
  
  // Should not start or end with punctuation
  if (/^[.\s'-]|[.\s'-]$/.test(value)) {
    return false;
  }
  
  // Should not contain digits
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Should reject clearly non-name patterns like "X Æ A-12"
  // Check for combination of unusual characters that don't look like names
  if (/^[A-Z]\s+Æ\s+[A-Z][^\s]*[0-9]*$/.test(value)) {
    return false;
  }
  
  // Should not contain only punctuation or spaces
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  // Name should contain at least one letter from Unicode categories L or M
  const hasValidLetters = /[\p{L}\p{M}]+/u.test(value);
  if (!hasValidLetters) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa (4), Mastercard (51-55, 2221-2720), and AmEx (34, 37).
 * Checks length and formats, then performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // First, clean the input of any spaces or dashes
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Check if the input consists only of digits
  if (!/^\d+$/.test(cleanedValue)) {
    return false;
  }
  
  // Check card type patterns and length
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20|7[0-8]))\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the number matches any of the card type patterns
  const isValidFormat = visaRegex.test(cleanedValue) || 
                       mastercardRegex.test(cleanedValue) || 
                       amexRegex.test(cleanedValue);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanedValue);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.split('').map(Number);
  let sum = 0;
  let isSecondDigit = false;
  
  // Start from the rightmost digit
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    // Double every second digit from the right
    if (isSecondDigit) {
      digit = digit * 2;
      // If doubling results in a two-digit number, sum the digits
      if (digit > 9) {
        digit = digit - 9;
      }
    }
    
    sum += digit;
    isSecondDigit = !isSecondDigit;
  }
  
  // Valid if total is a multiple of 10
  return sum % 10 === 0;
}
