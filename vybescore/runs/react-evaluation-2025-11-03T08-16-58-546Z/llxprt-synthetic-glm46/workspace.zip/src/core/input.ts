/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  trackDependency,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create equality function based on parameters
  let equalFn: EqualFn<T>
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else {
    // Default to strict equality if no equality function provided
    equalFn = (a: T, b: T) => a === b
  }

  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    // Track dependency when this input is read
    trackDependency(s)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed according to equality function
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify all observers of this subject
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}