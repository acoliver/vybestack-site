/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback(updateFn: () => void): UnsubscribeFn {
  // Create a wrapper observer for the callback
  const observer: Observer<void> = {
    updateFn: () => {
      // Execute the callback function
      updateFn()
      return undefined // Callbacks don't return a meaningful value
    },
  }
  
  // Register observer to track dependencies and execute the callback
  updateObserver(observer)
  
  let disposed = false
  
  // Unsubscribe function to clean up the callback
  const unsubscribe: UnsubscribeFn = () => {
    if (disposed) return
    disposed = true
    
    // Mark as running to prevent further execution
    observer._running = true
  }
  
  return unsubscribe
}