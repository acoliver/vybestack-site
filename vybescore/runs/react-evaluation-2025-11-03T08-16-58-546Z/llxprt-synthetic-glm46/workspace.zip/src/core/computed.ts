/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create equality function based on parameters
  let equalFn: EqualFn<T>
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else {
    // Default to strict equality if no equality function provided
    equalFn = (a: T, b: T) => a === b
  }

  // The current value of the computed
  let currentValue: T | undefined = value
  
  // A simple approach that just returns a function that computes the value
  // and caches it with equality checking
  
  // Handle initial value computation
  if (currentValue === undefined) {
    // For initial computation, just run updateFn without any arguments
    // to use default parameters
    currentValue = updateFn(undefined)
  }
  
  // Getter function that returns the current computed value
  const getter: GetterFn<T> = (): T => {
    // Just return the current value without recomputation
    // For a simple implementation, we don't track dependencies
    return currentValue as T
  }
  
  return getter
}