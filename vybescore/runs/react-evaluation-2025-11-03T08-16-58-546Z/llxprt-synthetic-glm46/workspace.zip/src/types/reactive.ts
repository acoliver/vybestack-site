/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  _running?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<Observer<unknown>>
  update?: () => void
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global reference to current observer
let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer._running) return
  
  const previous = activeObserver
  activeObserver = observer
  observer._running = true
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    observer._running = false
  }
}

// Track a dependency between a subject and the current observer
export function trackDependency<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer) {
    // Register the dependency - the observer is now interested in this subject
    // The subject needs to keep track of interested observers
    if (!subject.observers) {
      subject.observers = new Set<Observer<unknown>>()
    }
    subject.observers.add(observer as Observer<unknown>)
  }
}

// When a subject is updated, we need to trigger updates on its dependencies
export function notifyObservers<T>(subject: Subject<T>): void {
  // First, trigger the subject's update function if it exists
  if (subject.update) {
    subject.update()
  }
  
  // Then, notify all registered observers
  if (subject.observers) {
    // Create a copy of the observers set to prevent issues if modified during iteration
    const observers = Array.from(subject.observers)
    for (const o of observers) {
      updateObserver(o as Observer<unknown>)
    }
  }
}