/**
 * Capitalize the first character of each sentence.
 * Preserves abbreviations and handles spacing.
 */
export function capitalizeSentences(text: string): string {
  // Split on sentence boundaries (. ? !) followed by whitespace and lowercase letter
  // We'll use regex to find sentence starts and capitalize them
  return text.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * Extract URLs from text, removing trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, and bare URLs
  // Excludes trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w._~:/?#\]@!$&'()*+,;=%]|(?<!\.|\?|!|,|:|\))\.)+[^\s.?!,:]+/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.?!,:;,]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://..., moving /docs/ paths to docs.example.com.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should rewrite host for docs
    // Skip if path contains cgi-bin, query strings, or legacy extensions
    const skipHostRewrite = /\/cgi-bin|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
    
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.example.com' + path;
    }
    // Just upgrade scheme
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (01-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day (01-31, with some month-specific checks)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (dayNum < 1 || dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}
