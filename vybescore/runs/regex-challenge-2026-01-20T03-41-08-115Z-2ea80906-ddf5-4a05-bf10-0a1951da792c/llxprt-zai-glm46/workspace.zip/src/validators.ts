export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with proper formatting.
 * Accepts typical addresses, rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex: local@domain.tld
  // Local part: allow letters, digits, dots, hyphens, underscores, percent, plus
  // No consecutive dots, no leading/trailing dots
  // Domain: no underscores, proper TLD format
  const emailRegex = /^[a-zA-Z0-9.%+-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots in local part
  const [local, domain] = value.split('@');
  if (local.includes('..') || local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain parts should not start or end with hyphens
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-') || part === '') {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats and optional +1 prefix.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally 11 with +1)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let actualDigits = digitsOnly;
  if (digitsOnly.length === 11) {
    if (digitsOnly.startsWith('1')) {
      actualDigits = digitsOnly.slice(1);
    } else {
      return false;
    }
  } else if (digitsOnly.length > 11) {
    return false;
  }
  
  // Must be exactly 10 digits after country code
  if (actualDigits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = actualDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Central office code (first digit of exchange) cannot be 0 or 1
  if (actualDigits[3] === '0' || actualDigits[3] === '1') {
    return false;
  }
  
  // Check format matches acceptable patterns
  // Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1-212-555-7890, +12125557890
  const formatRegex = /^\+?1?\s*\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/;
  
  return formatRegex.test(value);
}

/**
 * Validate Argentine phone numbers for both landlines and mobiles.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep + if present
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // Optional +54 or 54 (country code)
  // Optional 0 (trunk prefix) - required if country code omitted
  // Optional 9 (mobile indicator)
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+?54)?(?:0)?(?:9)?[1-9]\d{0,2}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Parse components
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  let remaining = cleaned.replace(/^\+?54/, '');
  
  // Check trunk prefix logic
  const hasTrunkPrefix = remaining.startsWith('0');
  if (hasTrunkPrefix) {
    remaining = remaining.slice(1);
  }
  
  // If no country code, trunk prefix is required
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator
  const hasMobileIndicator = remaining.startsWith('9');
  if (hasMobileIndicator) {
    remaining = remaining.slice(1);
  }
  
  // Validate area code (2-4 digits, starting with 1-9)
  // We need to find where area code ends and subscriber begins
  // Total length should be: area (2-4) + subscriber (6-8) = 8-12 digits
  // Or with country code: +54 (2-3 chars) + area (2-4) + subscriber (6-8)
  
  // Simpler approach: extract just the national number
  const nationalNumber = cleaned.replace(/^\+?54/, '').replace(/^0/, '').replace(/^9/, '');
  
  // Area code must be 2-4 digits starting with 1-9
  // Subscriber number must be 6-8 digits
  // So national number must be 8-12 digits
  if (nationalNumber.length < 8 || nationalNumber.length > 12) {
    return false;
  }
  
  // Find area code (first 2-4 digits)
  let areaCodeLength = 0;
  for (let len = 4; len >= 2; len--) {
    const potentialSubscriber = nationalNumber.slice(len);
    if (potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
      areaCodeLength = len;
      break;
    }
  }
  
  if (areaCodeLength === 0) {
    return false;
  }
  
  const areaCode = nationalNumber.slice(0, areaCodeLength);
  const subscriberNumber = nationalNumber.slice(areaCodeLength);
  
  // Area code must start with 1-9
  if (!/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and obviously invalid names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Name must have at least one letter
  // Reject digits and symbols (except apostrophe, hyphen, space)
  const nameRegex = /^[\p{L}'-]+(?:[\s'’][\p{L}'-]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for at least one letter (unicode property \p{L})
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with only special characters
  const lettersOnly = value.replace(/[\s'’-]/g, '');
  if (lettersOnly.length === 0) {
    return false;
  }
  
  // Reject obvious "X Æ A-12" style names (mixing Æ with digits)
  // Actually, let's just reject any name with numbers since we already check for digits
  // But also be careful about names that are too short (like single character)
  if (lettersOnly.length < 2) {
    return false;
  }
  
  // Reject names with excessive special characters
  const specialCharCount = (value.match(/['’-]/g) || []).length;
  if (specialCharCount > 3) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for non-digit characters
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length: Visa/Mastercard (16 digits), AmEx (15 digits)
  if (cleaned.length !== 15 && cleaned.length !== 16) {
    return false;
  }
  
  // Check prefix patterns
  // Visa: starts with 4
  // Mastercard: starts with 51-55 or 2221-2720
  // AmEx: starts with 34 or 37
  const visaRegex = /^4/;
  const mastercardRegex = /^5[1-5]|^2[2-7][0-9]{2}/;
  const amexRegex = /^3[47]/;
  
  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Luhn algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
