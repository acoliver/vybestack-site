// Manual testing file for the regex challenge implementations

import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './src/puzzles.js';

// Validators
console.log('=== Validators ===');
console.log('Emails:');
console.log('user@example.com:', isValidEmail('user@example.com')); // true
console.log('user@@example..com:', isValidEmail('user@@example..com')); // false
console.log('user.name@tag@example.co.uk:', isValidEmail('user.name@tag@example.co.uk')); // false (double @)
console.log('user@example.co.uk:', isValidEmail('user@example.co.uk')); // true
console.log('user.name@sub.example.co.uk:', isValidEmail('user.name@sub.example.co.uk')); // true
console.log('user@_example.com:', isValidEmail('user@_example.com')); // false (underscore)
console.log('user.@example.com:', isValidEmail('user.@example.com')); // false (trailing dot)
console.log('.user@example.com:', isValidEmail('.user@example.com')); // false (leading dot)
console.log('user..name@example.com:', isValidEmail('user..name@example.com')); // false (double dot)

console.log('\nUS Phone:');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890')); // true
console.log('212-555-7890:', isValidUSPhone('212-555-7890')); // true
console.log('2125557890:', isValidUSPhone('2125557890')); // true
console.log('+1-212-555-7890:', isValidUSPhone('+1-212-555-7890')); // true
console.log('012-555-7890:', isValidUSPhone('012-555-7890')); // false (area code starts with 0)
console.log('112-555-7890:', isValidUSPhone('112-555-7890')); // false (area code starts with 1)
console.log('212-055-7890:', isValidUSPhone('212-055-7890')); // false (exchange starts with 0)
console.log('212-155-7890:', isValidUSPhone('212-155-7890')); // false (exchange starts with 1)
console.log('212-555-789:', isValidUSPhone('212-555-789')); // false (too short)

console.log('\nArgentine Phone:');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678')); // true (mobile)
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678')); // true (Buenos Aires)
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567')); // true (Rosario)
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567')); // true
console.log('341 1234567:', isValidArgentinePhone('341 1234567')); // false (no trunk prefix without country code)

console.log('\nNames:');
console.log('Jane Doe:', isValidName('Jane Doe')); // true
console.log('José María López:', isValidName('José María López')); // true (unicode)
console.log("O'Neil:", isValidName("O'Neil")); // true (apostrophe)
console.log('Smith-Jones:', isValidName('Smith-Jones')); // true (hyphen)
console.log('X Æ A-12:', isValidName('X Æ A-12')); // false (digits)
console.log('John123:', isValidName('John123')); // false (digits)
console.log('A:', isValidName('A')); // false (too short)

console.log('\nCredit Cards:');
console.log('4111111111111111:', isValidCreditCard('4111111111111111')); // true (Visa)
console.log('5500000000000004:', isValidCreditCard('5500000000000004')); // true (Mastercard)
console.log('340000000000009:', isValidCreditCard('340000000000009')); // true (AmEx)
console.log('4111111111111112:', isValidCreditCard('4111111111111112')); // false (fails Luhn)

// Transformations
console.log('\n=== Transformations ===');
console.log('Capitalize Sentences:');
console.log(capitalizeSentences('hello world. how are you?')); // "Hello world. How are you?"
console.log(capitalizeSentences('hello world.how are you?')); // "Hello world.How are you?"

console.log('\nExtract URLs:');
console.log(extractUrls('Visit http://example.com today')); // ["http://example.com"]
console.log(extractUrls('Visit http://example.com, and https://test.org!')); // ["http://example.com", "https://test.org"]

console.log('\nEnforce HTTPS:');
console.log(enforceHttps('http://example.com')); // "https://example.com"
console.log(enforceHttps('https://example.com')); // "https://example.com"

console.log('\nRewrite Docs URLs:');
console.log(rewriteDocsUrls('See http://example.com/docs/guide')); // "https://docs.example.com/docs/guide"
console.log(rewriteDocsUrls('See http://example.com/other/path')); // "https://example.com/other/path"
console.log(rewriteDocsUrls('See http://example.com/docs/api.cgi?param=1')); // "https://example.com/docs/api.cgi?param=1" (no host rewrite)

console.log('\nExtract Year:');
console.log(extractYear('01/31/2024')); // "2024"
console.log(extractYear('12/25/2023')); // "2023"
console.log(extractYear('13/01/2024')); // "N/A" (invalid month)
console.log(extractYear('01/32/2024')); // "N/A" (invalid day)
console.log(extractYear('not-a-date')); // "N/A"

// Puzzles
console.log('\n=== Puzzles ===');
console.log('Find Prefixed Words:');
console.log(findPrefixedWords('preview prevent prefix', 'pre', ['prevent'])); // ["preview", "prefix"]

console.log('\nFind Embedded Token:');
console.log(findEmbeddedToken('xfoo 1foo foo', 'foo')); // ["1foo"]

console.log('\nStrong Password:');
console.log('Abcdef!234:', isStrongPassword('Abcdef!234')); // true
console.log('abc123:', isStrongPassword('abc123')); // false (too short, no uppercase, no symbol)
console.log('Abcdef!234abab:', isStrongPassword('Abcdef!234abab')); // false (repeated sequence)

console.log('\nIPv6 Detection:');
console.log('2001:db8::1:', containsIPv6('2001:db8::1')); // true
console.log('192.168.1.1:', containsIPv6('192.168.1.1')); // false
console.log('::ffff:192.168.1.1:', containsIPv6('::ffff:192.168.1.1')); // true (IPv4-mapped IPv6)
