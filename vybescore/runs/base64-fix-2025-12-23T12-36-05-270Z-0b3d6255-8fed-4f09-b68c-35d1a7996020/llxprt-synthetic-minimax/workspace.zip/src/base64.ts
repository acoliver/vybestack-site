/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode standard Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64.
 */
export function decode(input: string): string {
  const cleanInput = input.trim();
  
  // Check if input is empty
  if (!cleanInput) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  // Validate Base64 format - allow both with and without padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(cleanInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Add padding if needed for proper decoding
  const base64WithoutPadding = cleanInput.replace(/=+$/, '');
  if (base64WithoutPadding.length === 0) {
    throw new Error('Invalid Base64 input: only padding characters');
  }
  
  // Calculate required padding
  const paddingNeeded = (4 - (base64WithoutPadding.length % 4)) % 4;
  const paddedInput = base64WithoutPadding + '='.repeat(paddingNeeded);

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
