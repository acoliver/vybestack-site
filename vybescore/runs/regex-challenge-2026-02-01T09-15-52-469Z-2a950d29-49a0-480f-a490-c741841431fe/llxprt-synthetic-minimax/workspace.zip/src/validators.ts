export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Enhanced regex to reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;
  
  // Check for forbidden patterns
  if (value.includes('..')) return false; // Double dots
  if (value.endsWith('.')) return false; // Trailing dot
  if (value.includes('@') && value.split('@')[1].includes('_')) return false; // Domain with underscore
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have 10 digits (or 11 if starting with +1 or 1)
  if (digitsOnly.length < 10) return false;
  if (digitsOnly.length > 11) return false;
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // Extract area code (first 3 digits)
  let areaCodeStart = 0;
  if (digitsOnly.length === 11) areaCodeStart = 1;
  
  const areaCode = digitsOnly.substring(areaCodeStart, areaCodeStart + 3);
  
  // Area code cannot start with 0 or 1 (NANP rules)
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Pattern matching with separators
  const phoneRegex = /^\+?1?[\s.-]?\(?([2-9][0-8][0-9])\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Extract all digits to validate length requirements
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have enough digits (minimum needed for format)
  if (digitsOnly.length < 8) return false; // Area code (2-4) + subscriber (6-8) minimum
  
  // Unified pattern for Argentine phone format
  // Pattern: [+54][optional 9][optional 0]area_code subscriber
  const pattern = /^\+?54\s?(?:9\s?)?(?:0)?([1-9]\d{1,3})[\s.-]?(\d{3,4}[\s.-]?\d{3,4})$/;
  const match = value.match(pattern);
  
  if (match) {
    const areaCode = match[1];
    const subscriber = match[2].replace(/\D/g, '');
    
    // Validate area code: 2-4 digits, leading digit 1-9
    if (areaCode.length >= 2 && areaCode.length <= 4 && areaCode[0] !== '0') {
      // Validate subscriber: 6-8 digits total
      if (subscriber.length >= 6 && subscriber.length <= 8) {
        return true;
      }
    }
  }
  
  // Handle case without country code but with trunk prefix
  const trunkPattern = /^(0)?([1-9]\d{1,3})[\s.-]?(\d{3,4}[\s.-]?\d{3,4})$/;
  const trunkMatch = value.match(trunkPattern);
  
  if (trunkMatch) {
    const hasTrunk = trunkMatch[1] !== undefined;
    const areaCode = trunkMatch[2];
    const subscriber = trunkMatch[3].replace(/\D/g, '');
    
    // When no country code, trunk prefix should be present
    if (!value.startsWith('+54') && hasTrunk) {
      // Validate area code: 2-4 digits, leading digit 1-9
      if (areaCode.length >= 2 && areaCode.length <= 4 && areaCode[0] !== '0') {
        // Validate subscriber: 6-8 digits total
        if (subscriber.length >= 6 && subscriber.length <= 8) {
          return true;
        }
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if string is empty or too short
  if (!value || value.length < 2) return false;
  
  // Check for invalid characters - reject digits
  if (/\d/.test(value)) return false;
  
  // Reject specific sci-fi names patterns
  if (value.includes('X Æ') || value.includes('A-12')) return false;
  
  // Check for valid name structure
  // Must start with a letter, apostrophe, or hyphen
  const firstChar = value.charAt(0);
  if (!/[\p{L}\p{M}’'-]/u.test(firstChar)) return false;
  
  // Must contain valid characters (letters, spaces, apostrophes, hyphens)
  // Allow unicode letters, marks, spaces, apostrophes, and hyphens
  const namePattern = /^[\p{L}\p{M}’'\-\s]+$/u;
  if (!namePattern.test(value)) return false;
  
  // Check for valid apostrophe/hyphen usage (not at start/end)
  const lastChar = value.charAt(value.length - 1);
  
  if (firstChar === "'" || firstChar === "-" || lastChar === "'" || lastChar === "-") {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  const cleanValue = value.replace(/\D/g, '');
  
  // Accept Visa (4), MasterCard (5), AmEx (3[47])
  const cardRegex = /^(?:3[47][0-9]{13}|4[0-9]{12,18}|5[1-5][0-9]{14,16})$/;
  if (!cardRegex.test(cleanValue)) return false;
  
  // Luhn algorithm
  let sum = 0;
  let shouldDouble = false;
  for (let i = cleanValue.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanValue[i]);
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  return sum % 10 === 0;
}
