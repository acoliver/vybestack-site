/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, ensure proper spacing between sentences
  // Replace patterns like ".world" with ". world" to insert required single space
  const spacedText = text.replace(/([.!?])([a-z])/g, '$1 $2');
  
  // Normalize multiple spaces to single space
  const normalizedSpaces = spacedText.replace(/\s+/g, ' ');
  
  // Capitalize first letter of each sentence
  const result = normalizedSpaces.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Enhanced regex to capture URLs with proper boundaries
  const urlRegex = /https?:\/\/[^\s"'<>()[\]{}]+/g;
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation while preserving the URL core
    const cleanUrl = url.replace(/[.,;:!?]+$/g, '');
    return cleanUrl;
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // More precise replacement: only replace http:// URLs, leave https:// alone
  return text.replace(/http:\/\/(?!\/\/)/g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/([^/]+)(\/docs\/[^\s"'<>()[\]{}]*)/g, (match, host, pathWithQuery) => {
    // Check for dynamic hints or legacy extensions that should skip host rewrite
    const dynamicExtensions = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    
    for (const ext of dynamicExtensions) {
      if (pathWithQuery.includes(ext)) {
        // Upgrade scheme to https but keep original host
        return 'https://' + host + pathWithQuery;
      }
    }
    
    // Move docs path to subdomain (docs.example.com) and upgrade scheme
    return 'https://docs.' + host + pathWithQuery;
  }).replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Extract year from mm/dd/yyyy format with validation
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  
  // Validate month and day ranges
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // Additional validation for day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) return 'N/A';
  
  return match[3];
}
