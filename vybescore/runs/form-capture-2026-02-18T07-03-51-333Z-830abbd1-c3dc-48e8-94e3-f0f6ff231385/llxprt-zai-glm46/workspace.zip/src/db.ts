import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';

const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

let db: Database | null = null;

/**
 * Initialize the SQLite database.
 * Creates the database file if it doesn't exist, loads it into memory,
 * and ensures the schema is up to date.
 */
export async function initializeDatabase(): Promise<Database> {
  if (db) {
    return db;
  }

  const SQL = await initSqlJs();

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }

  // Apply schema
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  db.run(schema);

  return db;
}

/**
 * Save the in-memory database to disk.
 * Should be called after each insert to persist data.
 */
export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

/**
 * Insert a form submission into the database.
 * @param submission - The form submission data
 * @returns The ID of the inserted row
 */
export function insertSubmission(submission: {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}): number {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.bind([
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvince,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phone,
  ]);

  stmt.step();
  stmt.free();

  const result = db.exec('SELECT last_insert_rowid() as id');
  const insertedId = result[0].values[0][0] as number;

  // Save to disk immediately after insert
  saveDatabase();

  return insertedId;
}

/**
 * Close the database connection.
 * Should be called on server shutdown to avoid locks.
 */
export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

/**
 * Get the database instance (for testing purposes).
 */
export function getDatabase(): Database | null {
  return db;
}
