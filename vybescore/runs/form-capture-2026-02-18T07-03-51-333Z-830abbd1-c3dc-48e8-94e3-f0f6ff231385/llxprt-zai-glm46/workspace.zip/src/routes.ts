import express, { Request, Response } from 'express';
import { insertSubmission } from './db.js';
import { validateFormSubmission } from './validation.js';

const router = express.Router();

/**
 * GET /
 * Renders the contact form.
 */
export function getForm(req: Request, res: Response): void {
  res.render('form', {
    errors: [],
    formData: {},
  });
}

/**
 * POST /submit
 * Handles form submission, validates input, stores in database,
 * and redirects to thank-you page on success.
 */
export async function submitForm(req: Request, res: Response): Promise<void> {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validationResult = validateFormSubmission(formData);

  if (!validationResult.isValid) {
    // Re-render form with errors and previously entered values
    res.status(400);
    res.render('form', {
      errors: validationResult.errors,
      formData,
    });
    return;
  }

  // Insert into database
  try {
    await insertSubmission(formData);

    // Redirect to thank-you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500);
    res.render('form', {
      errors: [
        {
          field: 'general',
          message: 'An error occurred while saving your submission. Please try again.',
        },
      ],
      formData,
    });
  }
}

/**
 * GET /thank-you
 * Renders the thank-you page.
 */
export function getThankYou(req: Request, res: Response): void {
  res.render('thank-you');
}

// Register routes
router.get('/', getForm);
router.post('/submit', submitForm);
router.get('/thank-you', getThankYou);

export default router;
