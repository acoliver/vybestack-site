export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

/**
 * Validates that a field is not empty after trimming whitespace.
 */
function validateRequired(value: string, fieldName: string): ValidationError | null {
  const trimmed = value.trim();
  if (!trimmed) {
    return {
      field: fieldName,
      message: `${fieldName} is required`,
    };
  }
  return null;
}

/**
 * Simple email validation using a basic regex.
 * Allows common email formats but doesn't attempt to be RFC-compliant.
 */
function validateEmail(value: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(value)) {
    return {
      field: 'email',
      message: 'Please enter a valid email address',
    };
  }
  return null;
}

/**
 * Validates phone number format.
 * Accepts digits, spaces, parentheses, dashes, and optional leading +.
 */
function validatePhone(value: string): ValidationError | null {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!phoneRegex.test(value)) {
    return {
      field: 'phone',
      message: 'Please enter a valid phone number',
    };
  }
  return null;
}

/**
 * Validates postal/zip code.
 * Accepts alphanumeric characters and spaces.
 */
function validatePostalCode(value: string): ValidationError | null {
  const postalRegex = /^[\dA-Za-z\s]+$/;
  if (!postalRegex.test(value)) {
    return {
      field: 'postalCode',
      message: 'Please enter a valid postal/zip code',
    };
  }
  return null;
}

/**
 * Validates all form fields and returns any validation errors.
 */
export function validateFormSubmission(data: {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}): ValidationResult {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields = [
    { value: data.firstName, name: 'First name' },
    { value: data.lastName, name: 'Last name' },
    { value: data.streetAddress, name: 'Street address' },
    { value: data.city, name: 'City' },
    { value: data.stateProvince, name: 'State/Province/Region' },
    { value: data.postalCode, name: 'Postal/Zip code' },
    { value: data.country, name: 'Country' },
    { value: data.email, name: 'Email' },
    { value: data.phone, name: 'Phone number' },
  ];

  for (const field of requiredFields) {
    const error = validateRequired(field.value || '', field.name);
    if (error) {
      errors.push(error);
    }
  }

  // Format-specific validations
  if (data.email && !errors.some((e) => e.field === 'email')) {
    const error = validateEmail(data.email);
    if (error) {
      errors.push(error);
    }
  }

  if (data.phone && !errors.some((e) => e.field === 'phone')) {
    const error = validatePhone(data.phone);
    if (error) {
      errors.push(error);
    }
  }

  if (data.postalCode && !errors.some((e) => e.field === 'postalCode')) {
    const error = validatePostalCode(data.postalCode);
    if (error) {
      errors.push(error);
    }
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}
