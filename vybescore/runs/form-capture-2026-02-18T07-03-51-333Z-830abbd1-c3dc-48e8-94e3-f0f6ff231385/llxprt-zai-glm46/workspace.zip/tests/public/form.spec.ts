import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../src/server.js';
import { initializeDatabase, closeDatabase } from '../../src/db.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize database before tests
  await initializeDatabase();
});

afterAll(async () => {
  // Close database connection
  closeDatabase();

  // Clean up test database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Get In Touch!');

    const $ = cheerio.load(response.text);

    // Check for all required fields
    expect($('input#firstName').length).toBe(1);
    expect($('input#lastName').length).toBe(1);
    expect($('input#streetAddress').length).toBe(1);
    expect($('input#city').length).toBe(1);
    expect($('input#stateProvince').length).toBe(1);
    expect($('input#postalCode').length).toBe(1);
    expect($('input#country').length).toBe(1);
    expect($('input#email').length).toBe(1);
    expect($('input#phone').length).toBe(1);

    // Check form action
    expect($('form[action="/submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    await initializeDatabase();

    const submission = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .send(submission)
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid input', async () => {
    const invalidSubmission = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: '',
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidSubmission);

    expect(response.status).toBe(400);
    expect(response.text).toContain('Please fix the following errors');
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank You');
  });
});
