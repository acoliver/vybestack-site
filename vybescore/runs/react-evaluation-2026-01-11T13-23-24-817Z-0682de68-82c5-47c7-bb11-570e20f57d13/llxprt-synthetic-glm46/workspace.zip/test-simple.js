import { createInput, createComputed, createCallback } from './src/index.js'

console.log("Testing simple reactive case...");

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
createCallback(() => (value = output()))

console.log(`Initial input: ${input()}, output: ${output()}, callback value: ${value}`)
setInput(3)
console.log(`After setInput(3), input: ${input()}, output: ${output()}, callback value: ${value}`)