/**
 * Ref implementation for reactive reference tracking.
 * Used to track subscriptions more robustly.
 */

export interface Ref<T> {
  current: T
}

export function createRef<T>(initial: T): Ref<T> {
  return { current: initial }
}