/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Options,
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  addActiveSubject,
  trackDependency,
  ObserverR,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Create a subject-like object to be able to link as a dependency
  let linkedObserver: Observer<unknown> | undefined
      
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a mock subject to track dependencies with other subjects
  const computedSubject: Subject<T> & { observer: ObserverR | undefined, observers?: Set<ObserverR> } = {
    name: options?.name,
    value: o.value!,
    equalFn: undefined,
    observer: undefined,
    observers: new Set()
  }
  
  // Register this computed value in the global registry
  addActiveSubject(computedSubject as Subject<unknown>)
  
  // Function to update computed value when dependencies change
  const updateComputedValue = () => {
    // Update the computed value
    updateObserver(o)
    computedSubject.value = o.value!
    
    // Notify all observers in the computed subject's observers set, removing duplicates
    if (computedSubject.observers) {
      const uniqueObservers = new Set(computedSubject.observers)
      uniqueObservers.forEach(observer => {
        // For computed values, the observer's updateFn already handles tracking
        // just trigger it without setting active observer context
        observer.updateFn && observer.updateFn()
      })
    }
    
    // If there's something observing this computed value, notify it
    if (linkedObserver) {
      updateObserver(linkedObserver)
    }
  }
  
  // Set up the observer update function for computed value when dependencies change
  computedSubject.observer = {
    updateFn: updateComputedValue
  }
  
  // Track dependencies when this computed value is accessed
  // Use lazy evaluation - only compute when accessed
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    if (observer) {
      // The active observer is observing this computed value
      linkedObserver = observer as Observer<unknown>
      
      // Track this computed value as a dependency if we're in a tracking context
      trackDependency(computedSubject as Subject<unknown>)
      
      // Register this computed with the observer to be notified when dependencies change
      // Prevent duplicates
      if (computedSubject.observers && !computedSubject.observers.has(observer)) {
        computedSubject.observers.add(observer)
      }
      
      // Update in observer context
      updateObserver(o)
      computedSubject.value = o.value!
    } else {
      // Direct access without tracking - just use current value
      if (computedSubject.observer) {
        // If we already have an observer, just trigger the update function without tracking
        const previousActive = getActiveObserver()
        try {
          setActiveObserver(computedSubject.observer)
          const newValue = o.updateFn(o.value)
          o.value = newValue
          computedSubject.value = newValue
        } finally {
          setActiveObserver(previousActive)
        }
      } else {
        // Set up a temporary observer to get the value
        const tempObserver = {
          updateFn: () => o.updateFn(o.value),
          value: o.value
        }
        const newValue = tempObserver.updateFn()
        o.value = newValue
        computedSubject.value = newValue
      }
    }
    
    // Return current value
    return o.value!
  }
  
  // Initial computation to establish dependencies only if we have an initial value
  // Otherwise, the value will be computed lazily when first accessed
  if (value !== undefined) {
    updateObserver(o)
    computedSubject.value = o.value!
  }
  
  return getter
}
