/**
 * Centralized notification system for reactive primitives.
 */

import { ObserverR } from '../types/reactive.js'

/**
 * Notifies observers without creating nested observer contexts
 * which can cause duplicate notifications.
 */
export function notifyObservers(observers: Set<ObserverR>, skipObserver?: ObserverR) {
  const uniqueObservers = new Set<ObserverR>()
  observers.forEach(observer => {
    // Skip the specified observer if provided
    if (observer === skipObserver) return
    // Only add each observer once
    uniqueObservers.add(observer)
  })
  
  // Notify each observer
  uniqueObservers.forEach(observer => {
    if (observer.updateFn) {
      // Directly call the update function without setting active observer context
      observer.updateFn()
    }
  })
}