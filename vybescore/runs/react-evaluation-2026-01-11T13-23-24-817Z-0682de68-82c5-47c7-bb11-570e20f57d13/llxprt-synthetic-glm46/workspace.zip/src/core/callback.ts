/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver, 
  flushSubscription 
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: () => {
      // When dependencies change, this function gets executed
      // We want to execute the original updateFn to trigger the callback
      return updateFn(value)
    },
  }
  
  // Register observer to track dependencies and trigger initial effect
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Store dependencies before clearing observer
    const dependencies = observer._dependencies ? new Set(observer._dependencies) : new Set()
    
    // Remove observer from all dependencies using the flushSubscription function
    dependencies.forEach(dep => {
      flushSubscription(dep as Subject<unknown>, observer)
    })
    
    // Clear the observer to stop further updates
    observer.value = undefined
    // Replace updateFn with no-op to prevent further execution
    observer.updateFn = () => undefined as T
    
    // Clear dependencies as well
    observer._dependencies = new Set()
  }
  
  return unsubscribe
}
