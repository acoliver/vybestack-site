/**
 * Global registry of subscriptions and subjects
 * for more robust tracking.
 */

import { Subject, ObserverR } from '../types/reactive.js'

// Map of subjects and their direct callback observers
const subjectToObservers = new Map<Subject<unknown>, Set<ObserverR>>()

// Map of observers and their subscribed subjects
const observerToSubjects = new Map<ObserverR, Set<Subject<unknown>>>()

/**
 * Records a subscription relationship between an observer and a subject
 */
export function recordSubscription(subject: Subject<unknown>, observer: ObserverR): void {
  // Get current observers for this subject or create new set
  let observers = subjectToObservers.get(subject)
  if (!observers) {
    observers = new Set()
    subjectToObservers.set(subject, observers)
  }
  observers.add(observer)
  
  // Get current subjects for this observer or create new set
  let subjects = observerToSubjects.get(observer)
  if (!subjects) {
    subjects = new Set()
    observerToSubjects.set(observer, subjects)
  }
  subjects.add(subject)
}

/**
 * Removes a subscription relationship
 */
export function removeSubscription(subject: Subject<unknown>, observer: ObserverR): void {
  const observers = subjectToObservers.get(subject)
  if (observers) {
    observers.delete(observer)
    if (observers.size === 0) {
      subjectToObservers.delete(subject)
    }
  }
  
  const subjects = observerToSubjects.get(observer)
  if (subjects) {
    subjects.delete(subject)
    if (subjects.size === 0) {
      observerToSubjects.delete(observer)
    }
  }
}

/**
 * Gets all observers for a subject
 */
export function getObserversForSubject(subject: Subject<unknown>): Set<ObserverR> | undefined {
  return subjectToObservers.get(subject)
}

/**
 * Gets all subjects for an observer
 */
export function getSubjectsForObserver(observer: ObserverR): Set<Subject<unknown>> | undefined {
  return observerToSubjects.get(observer)
}

/**
 * Removes all subscriptions for an observer
 */
export function removeAllSubscriptionsForObserver(observer: ObserverR): void {
  const subjects = observerToSubjects.get(observer)
  if (subjects) {
    subjects.forEach(subject => {
      const observers = subjectToObservers.get(subject)
      if (observers) {
        observers.delete(observer)
        if (observers.size === 0) {
          subjectToObservers.delete(subject)
        }
      }
    })
    observerToSubjects.delete(observer)
  }
}