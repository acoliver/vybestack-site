/**
 * Batcher system to prevent duplicate notifications and
 * allow batching of updates for better performance.
 */

let isBatching = false
let pendingNotifications: (() => void)[] = []

/**
 * Starts a batching context where notifications are queued
 * and executed once after the batch completes.
 */
export function startBatch(): void {
  if (isBatching) return
  isBatching = true
  pendingNotifications = []
}

/**
 * Ends a batching context and executes all queued notifications.
 */
export function endBatch(): void {
  if (!isBatching) return
  isBatching = false
  
  // Execute all pending notifications
  const notifications = pendingNotifications
  pendingNotifications = []
  
  notifications.forEach(notification => {
    try {
      notification()
    } catch (e) {
      console.error('Error during batched notification:', e)
    }
  })
}

/**
 * Safely executes a notification.
 * If batching is active, queues it; otherwise executes immediately.
 */
export function queueNotification(notification: () => void): void {
  if (isBatching) {
    pendingNotifications.push(notification)
  } else {
    notification()
  }
}

/**
 * Executes a callback within a batch context.
 */
export function batch<T>(callback: () => T): T {
  const wasBatching = isBatching
  
  try {
    if (!wasBatching) {
      startBatch()
    }
    
    const result = callback()
    
    if (!wasBatching) {
      endBatch()
    }
    
    return result
  } finally {
    if (!wasBatching && isBatching) {
      endBatch()
    }
  }
}