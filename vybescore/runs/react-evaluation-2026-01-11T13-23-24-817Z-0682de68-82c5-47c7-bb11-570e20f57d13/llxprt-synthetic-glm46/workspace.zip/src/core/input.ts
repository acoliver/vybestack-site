/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addActiveSubject,
  trackDependency,
  ObserverR
} from '../types/reactive.js'

function defaultEqualFn<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = _equal === true 
    ? defaultEqualFn
    : typeof _equal === 'function' 
      ? _equal
      : undefined

  const s: Subject<T> & { observer: ObserverR | undefined, observers?: Set<ObserverR> } = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    observers: new Set()
  }

  // Register this input in the global registry
  addActiveSubject(s as Subject<unknown>)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    
    // Track this subject as a dependency if we're in a tracking context
    if (observer) {
      trackDependency(s as Subject<unknown>)
      
      // Add the observer to our set of observers
      if (s.observers) {
        s.observers.add(observer)
      }
    }
    
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Skip update if equal and equality check passes
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // For each observer, call its update function directly to maintain the observer context
    // This ensures that when the observer function runs, it can track its own dependencies
    if (s.observers && s.observers.size > 0) {
      const uniqueObservers = new Set(s.observers)
      uniqueObservers.forEach(observer => {
        // Only trigger the function without extra context changes
        if (observer.updateFn) {
          observer.updateFn()
        }
      })
    }
    
    return s.value
  }

  return [read, write]
}
