/**
 * Utility functions for reactive programming testing and debugging.
 */

/**
 * Helper to check if a callback appears to be working correctly
 */
export function isCallbackActive(callbackFn: () => void): boolean {
  try {
    // If callback has been unsubscribed, it should be a no-op
    // For a basic check, try applying toString to see if it looks like a no-op
    const fnStr = callbackFn.toString()
    return !fnStr.includes('undefined as T') && !fnStr.includes('() => undefined')
  } catch (e) {
    return false
  }
}