export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  
  try {
    // Start tracking dependencies during this update
    startDependencyTracking()
    const oldDependencies = observer._dependencies || new Set()
    
    // Clear current dependencies and collect new ones
    observer._dependencies = new Set()
    
    // Execute the update function
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue as T
    
    // Get the new dependencies
    const newDependencies = stopDependencyTracking() || new Set()
    observer._dependencies = newDependencies
    
    // Remove this observer from old dependencies that are no longer used
    oldDependencies.forEach(dep => {
      if (!newDependencies.has(dep)) {
        // Remove from observers set
        if (dep.observers) {
          dep.observers.delete(observer)
        }
        
        // If this observer was the single observer reference, clear it
        if (dep.observer === observer) {
          dep.observer = undefined
        }
        
        // Remove from global subscription registry
        removeSubscription(dep, observer)
      }
    })
    
    // For each new dependency, set up the observer relationship
    newDependencies.forEach(dep => {
      // Record subscription in global registry
      recordSubscription(dep, observer)
      
      // Add to observers set for multiple observers support
      if (dep.observers) {
        // Only add if not already present to prevent duplicates
        if (!dep.observers.has(observer)) {
          dep.observers.add(observer)
        }
      }
      
      // Also set up the single observer reference if not already set
      // Important for callbacks to be notified of changes
      if (!dep.observer) {
        dep.observer = observer
      }
    })
  } finally {
    activeObserver = previous
  }
}
