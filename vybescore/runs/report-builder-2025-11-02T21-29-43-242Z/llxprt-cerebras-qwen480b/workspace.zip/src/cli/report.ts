#!/usr/bin/env node

import fs from 'fs';
import { ReportData } from '../interfaces.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Get command line arguments
const args = process.argv.slice(2);

// Parse arguments manually
let dataFile: string | null = null;
let format: string | null = null;
let outputFile: string | null = null;
let includeTotals = false;

for (let i = 0; i < args.length; i++) {
  const arg = args[i];
  
  if (arg === '--format') {
    format = args[++i];
  } else if (arg === '--output') {
    outputFile = args[++i];
  } else if (arg === '--includeTotals') {
    includeTotals = true;
  } else if (!dataFile && !arg.startsWith('--')) {
    dataFile = arg;
  }
}

// Validate required arguments
if (!dataFile) {
  console.error('Error: No data file provided');
  process.exit(1);
}

if (!format) {
  console.error('Error: No format specified');
  process.exit(1);
}

// Validate format
if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format '${format}'`);
  process.exit(1);
}

// Validate file exists
if (!fs.existsSync(dataFile)) {
  console.error(`Error: Data file '${dataFile}' not found`);
  process.exit(1);
}

try {
  // Read and parse JSON data
  const rawData = fs.readFileSync(dataFile, 'utf-8');
  const data: ReportData = JSON.parse(rawData);
  
  // Validate required fields in data
  if (!data.title || !data.summary || !Array.isArray(data.entries)) {
    console.error('Error: Invalid data format. Missing required fields.');
    process.exit(1);
  }
  
  // Validate entries
  for (const entry of data.entries) {
    if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
      console.error('Error: Invalid entry format in data file');
      process.exit(1);
    }
  }
  
  // Render report based on format
  let output: string;
  if (format === 'markdown') {
    output = renderMarkdown(data, { includeTotals });
  } else { // format === 'text'
    output = renderText(data, { includeTotals });
  }
  
  // Write to file or stdout
  if (outputFile) {
    fs.writeFileSync(outputFile, output);
    console.log(`Report written to ${outputFile}`);
  } else {
    console.log(output);
  }
} catch (error) {
  if (error instanceof SyntaxError) {
    console.error('Error: Invalid JSON in data file');
  } else {
    console.error(`Error: ${error}`);
  }
  process.exit(1);
}