#!/usr/bin/env node

import * as fs from 'fs';
import type { ReportData, RenderOptions } from '../types.js';
import { getFormatter, isSupportedFormat } from '../formats/index.js';

/**
 * Parses command-line arguments
 * Format: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */
function parseArgs(args: string[]): {
  filePath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filePath = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  const format = args[formatIndex + 1];
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : null;
  const includeTotals = args.includes('--includeTotals');

  return { filePath, format, outputPath, includeTotals };
}

/**
 * Reads and parses JSON data from a file
 */
function readDataFile(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    // Validate the data structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }

    const reportData = data as Partial<ReportData>;

    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field (expected string)');
    }

    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field (expected string)');
    }

    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field (expected array)');
    }

    for (let i = 0; i < reportData.entries.length; i++) {
      const entry = reportData.entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid data: entry at index ${i} is not an object`);
      }

      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entry at index ${i} has missing or invalid "label" field (expected string)`);
      }

      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entry at index ${i} has missing or invalid "amount" field (expected number)`);
      }
    }

    return reportData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON file: ${filePath}`);
      console.error(`Details: ${error.message}`);
      process.exit(1);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error(`Error: Unknown error reading file: ${filePath}`);
      process.exit(1);
    }
  }
}

/**
 * Main CLI execution
 */
function main(): void {
  // Parse arguments
  const { filePath, format, outputPath, includeTotals } = parseArgs(process.argv);

  // Validate format
  if (!isSupportedFormat(format)) {
    console.error(`Error: Unsupported format: ${format}`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  // Read and validate data
  const data = readDataFile(filePath);

  // Get formatter and render
  const formatter = getFormatter(format);
  const options: RenderOptions = { includeTotals };
  const output = formatter.render(data, options);

  // Write output
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output to: ${outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
