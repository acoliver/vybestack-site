import type { ReportData, RenderOptions, Formatter } from '../types.js';

/**
 * Formats amount as currency with exactly two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Computes the total of all entry amounts
 */
function computeTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Renders report data in Markdown format
 */
export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    lines.push(`**Total:** ${formatAmount(computeTotal(data.entries))}`);
  }

  return lines.join('\n');
}

export const markdownFormatter: Formatter = {
  render: renderMarkdown
};
