import type { Formatter } from '../types.js';
import { markdownFormatter } from './markdown.js';
import { textFormatter } from './text.js';

/**
 * Registry of available formatters
 */
export const formatters: Record<string, Formatter> = {
  markdown: markdownFormatter,
  text: textFormatter
};

/**
 * Validates that a format is supported
 */
export function isSupportedFormat(format: string): boolean {
  return format in formatters;
}

/**
 * Gets a formatter by name
 */
export function getFormatter(format: string): Formatter {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
