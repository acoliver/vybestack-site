/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Normalize input by adding padding if missing
  const normalizedInput = normalizeBase64Padding(input);
  
  // Validate that the input is valid Base64
  if (!isValidBase64(normalizedInput)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Add proper padding to Base64 input if missing.
 */
function normalizeBase64Padding(input: string): string {
  // Remove whitespace
  const trimmed = input.replace(/\s/g, '');
  
  // Check if already properly padded
  if (trimmed.length % 4 === 0) {
    return trimmed;
  }
  
  // Add required padding
  const paddingLength = 4 - (trimmed.length % 4);
  return trimmed + '='.repeat(paddingLength);
}

/**
 * Check if a string is valid Base64.
 */
function isValidBase64(input: string): string {
  // Check that the string contains only valid Base64 characters
  // Base64 valid characters: A-Z, a-z, 0-9, +, /, and = (only for padding at the end)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check that padding is only at the end and padding characters are consecutive
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // All padding characters must be at the end of the string
    for (let i = paddingIndex; i < input.length; i++) {
      if (input[i] !== '=') {
        throw new Error('Invalid Base64 input: incorrect padding');
      }
    }
  }
  
  // Test if the string is valid Base64 by trying to decode it
  try {
    Buffer.from(input, 'base64').toString('utf8');
    return input;
  } catch (error) {
    throw new Error('Invalid Base64 input: cannot decode');
  }
}
