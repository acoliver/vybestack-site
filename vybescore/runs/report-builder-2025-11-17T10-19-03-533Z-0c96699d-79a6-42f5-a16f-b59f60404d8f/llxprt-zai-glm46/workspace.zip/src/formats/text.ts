import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

export const renderText: ReportRenderer = (data: ReportData, options: ReportOptions): string => {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let output = `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;
  
  for (const entry of data.entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (options.includeTotals) {
    output += `Total: $${total.toFixed(2)}\n`;
  }
  
  return output;
};