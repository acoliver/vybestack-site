import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import type { ReportRenderer } from '../types.js';

export const renderers: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getRenderer(format: string): ReportRenderer {
  const renderer = renderers[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}