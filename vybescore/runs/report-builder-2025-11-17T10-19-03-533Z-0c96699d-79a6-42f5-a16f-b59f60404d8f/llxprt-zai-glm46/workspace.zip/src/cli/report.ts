#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFile } from 'node:fs/promises';
import { getRenderer } from '../formats/index.js';
import type { ReportData, ReportOptions } from '../types.js';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    dataPath: '',
    format: '',
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      result.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      result.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!arg.startsWith('-') && !result.dataPath) {
      result.dataPath = arg;
    }
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title field');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries field');
  }

  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid label field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: missing or invalid amount field`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    if (!args.dataPath) {
      console.error('Error: Missing data file path');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    if (!args.format) {
      console.error('Error: Missing format');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.dataPath, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${args.dataPath}: ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error: Could not read file ${args.dataPath}: ${error.message}`);
      } else {
        console.error(`Error: Could not read file ${args.dataPath}`);
      }
      process.exit(1);
    }

    const reportData = validateReportData(jsonData);
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };

    const renderer = getRenderer(args.format);
    const output = renderer(reportData, options);

    if (args.outputPath) {
      try {
        writeFile(args.outputPath, output);
      } catch (error) {
        console.error(`Error: Could not write to file ${args.outputPath}: ${error instanceof Error ? error.message : error}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : error}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}