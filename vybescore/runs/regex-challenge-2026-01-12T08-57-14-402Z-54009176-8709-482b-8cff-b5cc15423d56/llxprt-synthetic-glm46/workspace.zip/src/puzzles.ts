/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a pattern to match whole words starting with the prefix
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');
  
  // Extract all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions and remove duplicates
  const results = matches
    .filter(word => !exceptions.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index);
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Test case expects matches like '1foo' from 'xfoo 1foo foo'
  // Let's try a different approach - find digit+token combinations
  
  // Split text by whitespace and try to match digit+token in each word
  const words = text.split(/\s+/);
  const results: string[] = [];
  
  for (const word of words) {
    // Check if the word contains the token preceded by a digit
    const pattern = new RegExp(`\\d${token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`);
    if (pattern.test(word)) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric character)
  if (!/[!@#$%^&*()_+=\\[\]{};':"\\|,.<>/]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This pattern checks for 2-character sequences that repeat immediately
  if (/(.{2})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern to exclude IPv4 addresses
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if this looks like an IPv4 address
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern (including shorthand ::)
  // Full IPv6 pattern matches all valid IPv6 address forms
  const ipv6Pattern = /(?:^|(?<=[\s(]))((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?:$|(?=[\s)]))/;
  
  // Check if the value contains an IPv6 pattern
  return ipv6Pattern.test(value);
}
