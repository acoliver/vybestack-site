export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation with additional restrictions
  // Accept typical addresses like name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  
  // Base email pattern: local@domain
  const emailPattern = /^.+@.+$/;
  
  // Check if it's a basic email structure
  if (!emailPattern.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Check for double dots in entire email
  if (/\.{2,}/.test(value)) {
    return false;
  }
  
  // Check for leading or trailing dot in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  if (/_/.test(domain)) {
    return false;
  }
  
  // Check for valid local part (letters, digits, plus, dots, hyphens, underscores, apostrophes)
  const localPartPattern = /^[a-zA-Z0-9.+_'-]+$/;
  if (!localPartPattern.test(localPart)) {
    return false;
  }
  
  // Check for valid domain with TLD of at least 2 chars
  const domainPattern = /^[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})*$/;
  if (!domainPattern.test(domain)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length
  if (digits.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (digits.startsWith('1') && digits.length > 10) {
    phoneNumber = digits.substring(1);
  }
  
  // Must be exactly 10 digits after stripping country code
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate format with patterns for common US phone formats
  const patterns = [
    // (212) 555-7890
    /^\(\d{3}\)\s*\d{3}[-.\s]?\d{4}$/,
    // 212-555-7890, 212.555.7890, 212 555 7890
    /^\d{3}[-.\s]\d{3}[-.\s]\d{4}$/,
    // 2125557890
    /^\d{10}$/,
    // +1 212 555 7890, +1-212-555-7890, etc.
    /^\+1\s?\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize by removing spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Pattern with country code (+54)
  // Optional +54 country code
  // Optional mobile indicator 9 
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  const withCountryCodePattern = /^\+54(?:9)?(\d{2,4})(\d{6,8})$/;
  
  // Pattern without country code (must start with 0 trunk prefix)
  // Must have 0 trunk prefix
  // Optional mobile indicator 9
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  const withoutCountryCodePattern = /^0(?:9)?(\d{2,4})(\d{6,8})$/;
  
  const withCountryMatch = normalized.match(withCountryCodePattern);
  const withoutCountryMatch = normalized.match(withoutCountryCodePattern);
  
  if (withCountryMatch) {
    const areaCode = withCountryMatch[1];
    
    // Area code must start with 1-9
    if (/^[0]/.test(areaCode)) {
      return false;
    }
    
    return true;
  } else if (withoutCountryMatch) {
    const areaCode = withoutCountryMatch[1];
    
    // Area code must start with 1-9
    if (/^[0]/.test(areaCode)) {
      return false;
    }
    
    return true;
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Unicode name validation pattern
  // Allow letters from any language, accented characters, apostrophes, hyphens, and spaces
  // Disallow digits, symbols, and special characters
  // Must contain at least one letter
  const namePattern = /^[\p{L}\p{M}'\- ]+$/u;
  
  // Check for digits
  const hasDigits = /\d/.test(value);
  
  // Check for suspicious symbols
  const hasSymbols = /[!@#$%^&*()_+=\\[\]{};:"<>?,./\\|`~]/.test(value);
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  return namePattern.test(value) && 
         !hasDigits && 
         !hasSymbols && 
         hasLetter &&
         value.trim().length > 0;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Luhn algorithm implementation
  let sum = 0;
  let isSecondDigit = false;
  
  // Iterate from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isSecondDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isSecondDigit = !isSecondDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check for valid credit card patterns (Visa, Mastercard, Amex)
  const visaPattern = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardPattern = /^5[1-5]\d{14}$/; // 16 digits
  const amexPattern = /^3[47]\d{13}$/; // 15 digits
  
  // Check if it matches any credit card pattern
  const isValidPrefixLength = visaPattern.test(digits) || 
                              mastercardPattern.test(digits) || 
                              amexPattern.test(digits);
  
  return isValidPrefixLength && runLuhnCheck(value);
}
