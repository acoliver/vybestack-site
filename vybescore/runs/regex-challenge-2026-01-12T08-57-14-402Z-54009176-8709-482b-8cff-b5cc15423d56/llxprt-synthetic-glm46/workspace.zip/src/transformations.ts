/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence after .?!
  // Insert exactly one space between sentences
  // Collapse extra spaces while preserving abbreviations
  
  // Split text into sentences using sentence-ending punctuation
  const sentences = text.split(/([.!?]+)/);
  
  let result = '';
  let inSentence = false;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (i % 2 === 0) {
      // This is a sentence part
      const trimmed = part.replace(/\s+/g, ' ').trim();
      
      if (trimmed.length > 0) {
        if (inSentence) {
          // Add space before new sentence
          result += ' ';
        }
        // Capitalize first character
        result += trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        inSentence = true;
      } else if (!inSentence && i > 0) {
        // This happens at the beginning of the string
        inSentence = true;
      }
    } else {
      // This is punctuation
      result += part;
    }
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http://, https://, and www. URLs
  // Includes domain, optional port, path, query parameters, and anchor
  // Excludes trailing punctuation
  
  // Pattern to match URLs and look ahead for word boundary or the end of string
  const urlPattern = /(https?:\/\/|www\.)[^\s<>"'()]*(?=\b|$)/g;
  
  const matches = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];
    
    // Find the actual end of the URL
    // Look for characters that we can sensibly include in a URL
    const urlEndRegex = /[^\w\-._~:/?#[\]@!$&'()*+,;=%]/;
    const urlEnd = url.search(urlEndRegex);
    
    if (urlEnd > 0) {
      url = url.substring(0, urlEnd);
    }
    
    if (url.length > 0) {
      matches.push(url);
    }
  }
  
  return matches;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// URLs with https://
  // Don't modify URLs that are already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Rewrite http://example.com/ URLs with special handling for docs paths
  return text.replace(/http:\/\/example\.com\/([^?\s]*)/g, (match, path) => {
    // Always upgrade to https
    let newUrl = `https://`;
    
    // For docs paths, rewrite host to docs.example.com
    if (path.startsWith('docs/')) {
      // Check if path contains dynamic content that should prevent host rewrite
      const hasDynamicContent = /\bcgi-bin\b|[?&=]/.test(path) || 
                                /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/.test(path);
      
      if (!hasDynamicContent) {
        newUrl += `docs.example.com`;
      } else {
        newUrl += `example.com`;
      }
    } else {
      newUrl += `example.com`;
    }
    
    // Add the path
    newUrl += `/${path}`;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  
  if (match) {
    // Extract year, month, and day
    const month = parseInt(match[1], 10);
    const day = parseInt(match[2], 10);
    const year = match[3];
    const yearNum = parseInt(year, 10);
    
    // Validate date (accounting for month-specific day limits)
    const maxDaysByMonth = {
      1: 31, 3: 31, 5: 31, 7: 31, 8: 31, 10: 31, 12: 31,
      4: 30, 6: 30, 9: 30, 11: 30,
      2: 28 // Default for non-leap years
    };
    
    // Check if the day is valid for the month
    if (day > (maxDaysByMonth[month as keyof typeof maxDaysByMonth] as number)) {
      // For February, check if it's a leap year
      if (month === 2 && day === 29) {
        // Leap year check (divisible by 4, but not by 100, unless also by 400)
        if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
          return year;
        }
      }
      return 'N/A';
    }
    
    return year;
  }
  
  return 'N/A';
}
