export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Basic structure validation
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for double dots
  if (email.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (email.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't have underscores
  const parts = email.split('@');
  if (parts.length !== 2) return false;
  
  const domain = parts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Check basic email pattern
  return emailPattern.test(email);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  let phone = cleaned;
  if (phone.startsWith('+1')) {
    phone = phone.substring(2);
  } else if (phone.startsWith('1')) {
    phone = phone.substring(1);
  }
  
  // Must be exactly 10 digits for valid US phone
  if (phone.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = phone.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check format patterns
  const patterns = [
    /^\(\d{3}\)\s?\d{3}-?\d{4}$/, // (212) 555-7890
    /^\d{3}-?\d{3}-?\d{4}$/,      // 212-555-7890 or 2125557890
  ];
  
  // Validate against patterns or exact 10 digits
  const isValidPattern = patterns.some(pattern => pattern.test(value));
  const isValidDigits = /^\d{10}$/.test(phone);
  
  return isValidPattern || isValidDigits;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  let phone = cleaned;
  
  // Handle optional country code +54
  if (phone.startsWith('+54')) {
    phone = phone.substring(3);
  }
  
  // Handle trunk prefix 0
  let hasTrunkPrefix = false;
  if (phone.startsWith('0')) {
    hasTrunkPrefix = true;
    phone = phone.substring(1);
  }
  
  // Handle optional mobile indicator 9
  if (phone.startsWith('9')) {
    phone = phone.substring(1);
  }
  
  // If no country code, must have trunk prefix
  if (!cleaned.startsWith('+54') && !hasTrunkPrefix) {
    return false;
  }
  
  // Must have area code (2-4 digits starting with 1-9)
  if (phone.length < 2) return false;
  
  const areaCodeLength = Math.min(4, phone.length - 6); // 6-8 digits for subscriber
  const areaCode = phone.substring(0, areaCodeLength);
  
  // Area code validation
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  const subscriber = phone.substring(areaCodeLength);
  
  // Subscriber number must be 6-8 digits total
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Must contain only digits
  if (!/^\d+$/.test(phone)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty or just whitespace
  const name = value.trim();
  if (!name) return false;
  
  // Reject names with digits
  if (/\d/.test(name)) return false;
  
  // Reject special symbols and unusual characters
  // Allow unicode letters (including accented), spaces, hyphens, apostrophes
  const namePattern = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!namePattern.test(name)) return false;
  
  // Must be at least 2 characters
  if (name.length < 2) return false;
  
  // Must not start or end with special characters (spaces are allowed to be trimmed)
  const trimmed = name.trim();
  if (/^[\s'-]|[\s'-]$/.test(trimmed)) return false;
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check card type prefixes and lengths
  let isValidCardType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digits.startsWith('4')) {
    if (digits.length === 13 || digits.length === 16 || digits.length === 19) {
      isValidCardType = true;
    }
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((digits.startsWith('51') || digits.startsWith('52') || digits.startsWith('53') || 
             digits.startsWith('54') || digits.startsWith('55')) ||
            (digits.startsWith('2221') || digits.startsWith('2222') || digits.startsWith('2223') || 
             digits.startsWith('2224') || digits.startsWith('2225') || digits.startsWith('2226') || 
             digits.startsWith('2227') || digits.startsWith('2228') || digits.startsWith('2229') || 
             digits.startsWith('2230') || digits.startsWith('2231') || digits.startsWith('2232') || 
             digits.startsWith('2233') || digits.startsWith('2234') || digits.startsWith('2235') || 
             digits.startsWith('2236') || digits.startsWith('2237') || digits.startsWith('2238') || 
             digits.startsWith('2239') || digits.startsWith('2240') || digits.startsWith('2241') || 
             digits.startsWith('2242') || digits.startsWith('2243') || digits.startsWith('2244') || 
             digits.startsWith('2245') || digits.startsWith('2246') || digits.startsWith('2247') || 
             digits.startsWith('2248') || digits.startsWith('2249') || digits.startsWith('2250') || 
             digits.startsWith('2251') || digits.startsWith('2252') || digits.startsWith('2253') || 
             digits.startsWith('2254') || digits.startsWith('2255') || digits.startsWith('2256') || 
             digits.startsWith('2257') || digits.startsWith('2258') || digits.startsWith('2259') || 
             digits.startsWith('2260') || digits.startsWith('2261') || digits.startsWith('2262') || 
             digits.startsWith('2263') || digits.startsWith('2264') || digits.startsWith('2265') || 
             digits.startsWith('2266') || digits.startsWith('2267') || digits.startsWith('2268') || 
             digits.startsWith('2269') || digits.startsWith('2270') || digits.startsWith('2271') || 
             digits.startsWith('2272') || digits.startsWith('2273') || digits.startsWith('2274') || 
             digits.startsWith('2275') || digits.startsWith('2276') || digits.startsWith('2277') || 
             digits.startsWith('2278') || digits.startsWith('2279') || digits.startsWith('2280') || 
             digits.startsWith('2281') || digits.startsWith('2282') || digits.startsWith('2283') || 
             digits.startsWith('2284') || digits.startsWith('2285') || digits.startsWith('2286') || 
             digits.startsWith('2287') || digits.startsWith('2288') || digits.startsWith('2289') || 
             digits.startsWith('2290') || digits.startsWith('2291') || digits.startsWith('2292') || 
             digits.startsWith('2293') || digits.startsWith('2294') || digits.startsWith('2295') || 
             digits.startsWith('2296') || digits.startsWith('2297') || digits.startsWith('2298') || 
             digits.startsWith('2299') || digits.startsWith('2300') || digits.startsWith('2301') || 
             digits.startsWith('2302') || digits.startsWith('2303') || digits.startsWith('2304') || 
             digits.startsWith('2305') || digits.startsWith('2306') || digits.startsWith('2307') || 
             digits.startsWith('2308') || digits.startsWith('2309') || digits.startsWith('2310') || 
             digits.startsWith('2311') || digits.startsWith('2312') || digits.startsWith('2313') || 
             digits.startsWith('2314') || digits.startsWith('2315') || digits.startsWith('2316') || 
             digits.startsWith('2317') || digits.startsWith('2318') || digits.startsWith('2319') || 
             digits.startsWith('2320') || digits.startsWith('2321') || digits.startsWith('2322') || 
             digits.startsWith('2323') || digits.startsWith('2324') || digits.startsWith('2325') || 
             digits.startsWith('2326') || digits.startsWith('2327') || digits.startsWith('2328') || 
             digits.startsWith('2329') || digits.startsWith('2330') || digits.startsWith('2331') || 
             digits.startsWith('2332') || digits.startsWith('2333') || digits.startsWith('2334') || 
             digits.startsWith('2335') || digits.startsWith('2336') || digits.startsWith('2337') || 
             digits.startsWith('2338') || digits.startsWith('2339') || digits.startsWith('2340') || 
             digits.startsWith('2341') || digits.startsWith('2342') || digits.startsWith('2343') || 
             digits.startsWith('2344') || digits.startsWith('2345') || digits.startsWith('2346') || 
             digits.startsWith('2347') || digits.startsWith('2348') || digits.startsWith('2349') || 
             digits.startsWith('2350') || digits.startsWith('2351') || digits.startsWith('2352') || 
             digits.startsWith('2353') || digits.startsWith('2354') || digits.startsWith('2355') || 
             digits.startsWith('2356') || digits.startsWith('2357') || digits.startsWith('2358') || 
             digits.startsWith('2359') || digits.startsWith('2360') || digits.startsWith('2361') || 
             digits.startsWith('2362') || digits.startsWith('2363') || digits.startsWith('2364') || 
             digits.startsWith('2365') || digits.startsWith('2366') || digits.startsWith('2367') || 
             digits.startsWith('2368') || digits.startsWith('2369') || digits.startsWith('2370') || 
             digits.startsWith('2371') || digits.startsWith('2372') || digits.startsWith('2373') || 
             digits.startsWith('2374') || digits.startsWith('2375') || digits.startsWith('2376') || 
             digits.startsWith('2377') || digits.startsWith('2378') || digits.startsWith('2379') || 
             digits.startsWith('2380') || digits.startsWith('2381') || digits.startsWith('2382') || 
             digits.startsWith('2383') || digits.startsWith('2384') || digits.startsWith('2385') || 
             digits.startsWith('2386') || digits.startsWith('2387') || digits.startsWith('2388') || 
             digits.startsWith('2389') || digits.startsWith('2390') || digits.startsWith('2391') || 
             digits.startsWith('2392') || digits.startsWith('2393') || digits.startsWith('2394') || 
             digits.startsWith('2395') || digits.startsWith('2396') || digits.startsWith('2397') || 
             digits.startsWith('2398') || digits.startsWith('2399') || digits.startsWith('2400') || 
             digits.startsWith('2401') || digits.startsWith('2402') || digits.startsWith('2403') || 
             digits.startsWith('2404') || digits.startsWith('2405') || digits.startsWith('2406') || 
             digits.startsWith('2407') || digits.startsWith('2408') || digits.startsWith('2409') || 
             digits.startsWith('2410') || digits.startsWith('2411') || digits.startsWith('2412') || 
             digits.startsWith('2413') || digits.startsWith('2414') || digits.startsWith('2415') || 
             digits.startsWith('2416') || digits.startsWith('2417') || digits.startsWith('2418') || 
             digits.startsWith('2419') || digits.startsWith('2420') || digits.startsWith('2421') || 
             digits.startsWith('2422') || digits.startsWith('2423') || digits.startsWith('2424') || 
             digits.startsWith('2425') || digits.startsWith('2426') || digits.startsWith('2427') || 
             digits.startsWith('2428') || digits.startsWith('2429') || digits.startsWith('2430') || 
             digits.startsWith('2431') || digits.startsWith('2432') || digits.startsWith('2433') || 
             digits.startsWith('2434') || digits.startsWith('2435') || digits.startsWith('2436') || 
             digits.startsWith('2437') || digits.startsWith('2438') || digits.startsWith('2439') || 
             digits.startsWith('2440') || digits.startsWith('2441') || digits.startsWith('2442') || 
             digits.startsWith('2443') || digits.startsWith('2444') || digits.startsWith('2445') || 
             digits.startsWith('2446') || digits.startsWith('2447') || digits.startsWith('2448') || 
             digits.startsWith('2449') || digits.startsWith('2450') || digits.startsWith('2451') || 
             digits.startsWith('2452') || digits.startsWith('2453') || digits.startsWith('2454') || 
             digits.startsWith('2455') || digits.startsWith('2456') || digits.startsWith('2457') || 
             digits.startsWith('2458') || digits.startsWith('2459') || digits.startsWith('2460') || 
             digits.startsWith('2461') || digits.startsWith('2462') || digits.startsWith('2463') || 
             digits.startsWith('2464') || digits.startsWith('2465') || digits.startsWith('2466') || 
             digits.startsWith('2467') || digits.startsWith('2468') || digits.startsWith('2469') || 
             digits.startsWith('2470') || digits.startsWith('2471') || digits.startsWith('2472') || 
             digits.startsWith('2473') || digits.startsWith('2474') || digits.startsWith('2475') || 
             digits.startsWith('2476') || digits.startsWith('2477') || digits.startsWith('2478') || 
             digits.startsWith('2479') || digits.startsWith('2480') || digits.startsWith('2481') || 
             digits.startsWith('2482') || digits.startsWith('2483') || digits.startsWith('2484') || 
             digits.startsWith('2485') || digits.startsWith('2486') || digits.startsWith('2487') || 
             digits.startsWith('2488') || digits.startsWith('2489') || digits.startsWith('2490') || 
             digits.startsWith('2491') || digits.startsWith('2492') || digits.startsWith('2493') || 
             digits.startsWith('2494') || digits.startsWith('2495') || digits.startsWith('2496') || 
             digits.startsWith('2497') || digits.startsWith('2498') || digits.startsWith('2499') || 
             digits.startsWith('2500') || digits.startsWith('2501') || digits.startsWith('2502') || 
             digits.startsWith('2503') || digits.startsWith('2504') || digits.startsWith('2505') || 
             digits.startsWith('2506') || digits.startsWith('2507') || digits.startsWith('2508') || 
             digits.startsWith('2509') || digits.startsWith('2510') || digits.startsWith('2511') || 
             digits.startsWith('2512') || digits.startsWith('2513') || digits.startsWith('2514') || 
             digits.startsWith('2515') || digits.startsWith('2516') || digits.startsWith('2517') || 
             digits.startsWith('2518') || digits.startsWith('2519') || digits.startsWith('2520') || 
             digits.startsWith('2521') || digits.startsWith('2522') || digits.startsWith('2523') || 
             digits.startsWith('2524') || digits.startsWith('2525') || digits.startsWith('2526') || 
             digits.startsWith('2527') || digits.startsWith('2528') || digits.startsWith('2529') || 
             digits.startsWith('2530') || digits.startsWith('2531') || digits.startsWith('2532') || 
             digits.startsWith('2533') || digits.startsWith('2534') || digits.startsWith('2535') || 
             digits.startsWith('2536') || digits.startsWith('2537') || digits.startsWith('2538') || 
             digits.startsWith('2539') || digits.startsWith('2540') || digits.startsWith('2541') || 
             digits.startsWith('2542') || digits.startsWith('2543') || digits.startsWith('2544') || 
             digits.startsWith('2545') || digits.startsWith('2546') || digits.startsWith('2547') || 
             digits.startsWith('2548') || digits.startsWith('2549') || digits.startsWith('2550') || 
             digits.startsWith('2551') || digits.startsWith('2552') || digits.startsWith('2553') || 
             digits.startsWith('2554') || digits.startsWith('2555') || digits.startsWith('2556') || 
             digits.startsWith('2557') || digits.startsWith('2558') || digits.startsWith('2559') || 
             digits.startsWith('2560') || digits.startsWith('2561') || digits.startsWith('2562') || 
             digits.startsWith('2563') || digits.startsWith('2564') || digits.startsWith('2565') || 
             digits.startsWith('2566') || digits.startsWith('2567') || digits.startsWith('2568') || 
             digits.startsWith('2569') || digits.startsWith('2570') || digits.startsWith('2571') || 
             digits.startsWith('2572') || digits.startsWith('2573') || digits.startsWith('2574') || 
             digits.startsWith('2575') || digits.startsWith('2576') || digits.startsWith('2577') || 
             digits.startsWith('2578') || digits.startsWith('2579') || digits.startsWith('2580') || 
             digits.startsWith('2581') || digits.startsWith('2582') || digits.startsWith('2583') || 
             digits.startsWith('2584') || digits.startsWith('2585') || digits.startsWith('2586') || 
             digits.startsWith('2587') || digits.startsWith('2588') || digits.startsWith('2589') || 
             digits.startsWith('2590') || digits.startsWith('2591') || digits.startsWith('2592') || 
             digits.startsWith('2593') || digits.startsWith('2594') || digits.startsWith('2595') || 
             digits.startsWith('2596') || digits.startsWith('2597') || digits.startsWith('2598') || 
             digits.startsWith('2599') || digits.startsWith('2600') || digits.startsWith('2601') || 
             digits.startsWith('2602') || digits.startsWith('2603') || digits.startsWith('2604') || 
             digits.startsWith('2605') || digits.startsWith('2606') || digits.startsWith('2607') || 
             digits.startsWith('2608') || digits.startsWith('2609') || digits.startsWith('2610') || 
             digits.startsWith('2611') || digits.startsWith('2612') || digits.startsWith('2613') || 
             digits.startsWith('2614') || digits.startsWith('2615') || digits.startsWith('2616') || 
             digits.startsWith('2617') || digits.startsWith('2618') || digits.startsWith('2619') || 
             digits.startsWith('2620') || digits.startsWith('2621') || digits.startsWith('2622') || 
             digits.startsWith('2623') || digits.startsWith('2624') || digits.startsWith('2625') || 
             digits.startsWith('2626') || digits.startsWith('2627') || digits.startsWith('2628') || 
             digits.startsWith('2629') || digits.startsWith('2630') || digits.startsWith('2631') || 
             digits.startsWith('2632') || digits.startsWith('2633') || digits.startsWith('2634') || 
             digits.startsWith('2635') || digits.startsWith('2636') || digits.startsWith('2637') || 
             digits.startsWith('2638') || digits.startsWith('2639') || digits.startsWith('2640') || 
             digits.startsWith('2641') || digits.startsWith('2642') || digits.startsWith('2643') || 
             digits.startsWith('2644') || digits.startsWith('2645') || digits.startsWith('2646') || 
             digits.startsWith('2647') || digits.startsWith('2648') || digits.startsWith('2649') || 
             digits.startsWith('2650') || digits.startsWith('2651') || digits.startsWith('2652') || 
             digits.startsWith('2653') || digits.startsWith('2654') || digits.startsWith('2655') || 
             digits.startsWith('2656') || digits.startsWith('2657') || digits.startsWith('2658') || 
             digits.startsWith('2659') || digits.startsWith('2660') || digits.startsWith('2661') || 
             digits.startsWith('2662') || digits.startsWith('2663') || digits.startsWith('2664') || 
             digits.startsWith('2665') || digits.startsWith('2666') || digits.startsWith('2667') || 
             digits.startsWith('2668') || digits.startsWith('2669') || digits.startsWith('2670') || 
             digits.startsWith('2671') || digits.startsWith('2672') || digits.startsWith('2673') || 
             digits.startsWith('2674') || digits.startsWith('2675') || digits.startsWith('2676') || 
             digits.startsWith('2677') || digits.startsWith('2678') || digits.startsWith('2679') || 
             digits.startsWith('2680') || digits.startsWith('2681') || digits.startsWith('2682') || 
             digits.startsWith('2683') || digits.startsWith('2684') || digits.startsWith('2685') || 
             digits.startsWith('2686') || digits.startsWith('2687') || digits.startsWith('2688') || 
             digits.startsWith('2689') || digits.startsWith('2690') || digits.startsWith('2691') || 
             digits.startsWith('2692') || digits.startsWith('2693') || digits.startsWith('2694') || 
             digits.startsWith('2695') || digits.startsWith('2696') || digits.startsWith('2697') || 
             digits.startsWith('2698') || digits.startsWith('2699') || digits.startsWith('2700') || 
             digits.startsWith('2701') || digits.startsWith('2702') || digits.startsWith('2703') || 
             digits.startsWith('2704') || digits.startsWith('2705') || digits.startsWith('2706') || 
             digits.startsWith('2707') || digits.startsWith('2708') || digits.startsWith('2709') || 
             digits.startsWith('2710') || digits.startsWith('2711') || digits.startsWith('2712') || 
             digits.startsWith('2713') || digits.startsWith('2714') || digits.startsWith('2715') || 
             digits.startsWith('2716') || digits.startsWith('2717') || digits.startsWith('2718') || 
             digits.startsWith('2719') || digits.startsWith('2720'))) {
    if (digits.length === 16) {
      isValidCardType = true;
    }
  }
  // American Express: starts with 34 or 37, length 15
  else if (digits.startsWith('34') || digits.startsWith('37')) {
    if (digits.length === 15) {
      isValidCardType = true;
    }
  }
  
  if (!isValidCardType) {
    return false;
  }
  
  // Apply Luhn checksum
  return runLuhnCheck(digits);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
