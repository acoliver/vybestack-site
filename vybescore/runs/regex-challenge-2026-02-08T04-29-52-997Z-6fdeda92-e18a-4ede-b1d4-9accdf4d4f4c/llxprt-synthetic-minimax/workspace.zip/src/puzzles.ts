/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to match words starting with prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => {
    const matchLower = match.toLowerCase();
    const prefixLower = prefix.toLowerCase();
    return !exceptions.some(exception => 
      matchLower.startsWith(prefixLower) && 
      matchLower === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token after a digit and not at start
  // Use a simpler approach: find all occurrences where token is preceded by a digit
  const contextPattern = new RegExp(`\\d${escapedToken}`, 'gi');
  
  const matches = text.match(contextPattern) || [];
  
  // Return matches with their preceding digit context
  return matches.map(match => match);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Length requirement: at least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()\-_=+[{\]}|;:'",<.>/?~`]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., 'abab')
  // This looks for any 2-character sequence that repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    const sequence = value[i] + value[i + 1];
    const nextChars = value[i + 2] + value[i + 3];
    if (sequence === nextChars) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 address patterns
  // Full notation: 8 groups of 4 hex digits separated by colons
  // Shortened notation: :: for consecutive zeros
  // Mixed notation: can end with IPv4 address
  
  // Pattern to match IPv6 addresses (excluding IPv4)
  const ipv6Pattern = /(?:^|[\s:])((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?=[\s:]|$)/i;
  
  // Pattern to specifically exclude pure IPv4 addresses
  const pureIpv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  
  // Check if string contains IPv6 pattern but is not pure IPv4
  const containsIpv6 = ipv6Pattern.test(value);
  const isPureIpv4 = pureIpv4Pattern.test(value.trim());
  
  return containsIpv6 && !isPureIpv4;
}
