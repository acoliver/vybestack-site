/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  return text
    // Capitalize first letter after sentence endings or start of text
    .replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
      return prefix + letter.toUpperCase();
    });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern that matches http/https URLs
  const urlPattern = /\bhttps?:\/\/[^\s<>"{}|\\^`[]+/gi;
  
  const urls = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return urls.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http URLs
  const httpUrlPattern = /\bhttp:\/\/[^\s<>"{}|\\^`[]+/gi;
  
  return text.replace(httpUrlPattern, (url) => {
    // Always upgrade scheme to https
    let newUrl = url.replace(/^http:\/\//, 'https://');
    
    // Extract URL parts
    const urlMatch = newUrl.match(/^https?:\/\/([^/]+)(.*)$/);
    if (!urlMatch) return newUrl;
    
    const host = urlMatch[1];
    const pathAndQuery = urlMatch[2];
    
    // Check if path begins with /docs/ and doesn't contain dynamic hints
    if (pathAndQuery.startsWith('/docs/')) {
      // Check for dynamic hints in the path
      const hasDynamicHints = /(\?|=|&|\.(jsp|php|asp|aspx|do|cgi|pl|py)\b|cgi-bin)/i.test(pathAndQuery);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com, but preserve the original domain
        // Extract domain parts and replace subdomain with 'docs'
        const domainParts = host.split('.');
        if (domainParts.length >= 2) {
          const tld = domainParts.pop();
          const sld = domainParts.pop();
          const newHost = `docs.${sld}.${tld}`;
          newUrl = `https://${newHost}${pathAndQuery}`;
        }
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (!isLeapYear && day > 28) return 'N/A';
    if (isLeapYear && day > 29) return 'N/A';
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Validate day range (1-31)
  if (day < 1 || day > 31) return 'N/A';
  
  // Return the year as string
  return year.toString();
}
