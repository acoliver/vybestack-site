/**
 * Find words starting with a prefix, excluding specified exceptions.
 * - Words are sequences of word characters (letters, digits, underscore)
 * - Case-sensitive matching
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern: word boundary, prefix, more word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');

  const matches = text.match(pattern) || [];

  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * - Uses lookbehind to ensure token is preceded by a digit
 * - Uses lookahead to ensure token is not at the start of string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Lookbehind for a digit, match the token, and ensure not at start with negative lookbehind
  // Actually, the requirement says "after a digit and not at the start of the string"
  // So we need: (?<=\d)token - token preceded by digit
  // And we need to ensure it's not at the start (which would mean there's no character before it)
  // The lookbehind (?<=\d) already ensures there's a digit before, which means it's not at start

  // To return the full match including the digit, we need to capture it
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate passwords according to strong password policy.
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) {
    return false;
  }

  // Minimum length: 10 characters
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // A repeated sequence is a pattern of 2+ characters that repeats immediately
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const seq = value.substring(i, i + len);
      const nextSeq = value.substring(i + len, i + 2 * len);
      if (seq === nextSeq) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand with ::) while excluding IPv4 addresses.
 * - IPv6 addresses consist of hex groups separated by colons
 * - Supports shorthand :: for consecutive zero groups
 * - Rejects IPv4 addresses like 192.168.1.1
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  // First, explicitly exclude IPv4 addresses
  // IPv4: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Check if the whole thing looks like IPv4
    const trimmed = value.trim();
    if (ipv4Pattern.test(trimmed)) {
      // Validate the octets are 0-255
      const octets = trimmed.split('.');
      const allValid = octets.every(oct => {
        const num = parseInt(oct, 10);
        return num >= 0 && num <= 255;
      });

      if (allValid) {
        return false; // It's a valid IPv4 address
      }
    }
  }

  // IPv6 patterns:
  // Full form: 8 groups of 1-4 hex digits separated by colons
  // Examples: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // Shorthand: :: can replace one or more consecutive groups of zeros
  // Examples: 2001:db8::1, ::1, fe80::1

  // Pattern 1: Full IPv6 (8 groups of 1-4 hex digits)
  const fullIpv6Pattern =
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;

  // Pattern 2: IPv6 with :: shorthand (but not starting with : which could be other stuff)
  // This handles cases like 2001:db8::1 or fe80::1ff:fe23:4567:890a
  const shorthandIpv6Pattern =
    /\b(?:[0-9a-fA-F]{1,4}:)*:(?::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})?\b/;

  // Pattern 3: IPv6 starting with ::
  const leadingShorthandPattern = /\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{0,4}\b/;

  // Pattern 4: IPv6 ending with ::
  const trailingShorthandPattern = /\b(?:[0-9a-fA-F]{1,4}:){1,7}::\b/;

  // Check for embedded IPv4 in IPv6 (e.g., ::ffff:192.168.1.1)
  const embeddedIpv4Pattern =
    /::ffff:(?:\d{1,3}\.)+\d{1,3}/i;

  // But we want to return true for IPv6 even with embedded IPv4
  // So check for that pattern too
  const ipv6WithEmbeddedIpv4 =
    /(?:[0-9a-fA-F]{1,4}:){1,4}:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/;

  return (
    fullIpv6Pattern.test(value) ||
    shorthandIpv6Pattern.test(value) ||
    leadingShorthandPattern.test(value) ||
    trailingShorthandPattern.test(value) ||
    embeddedIpv4Pattern.test(value) ||
    ipv6WithEmbeddedIpv4.test(value)
  );
}
