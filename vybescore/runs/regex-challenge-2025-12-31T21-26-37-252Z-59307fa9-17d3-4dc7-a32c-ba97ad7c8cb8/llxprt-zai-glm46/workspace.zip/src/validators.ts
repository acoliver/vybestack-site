export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Luhn checksum algorithm helper function
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate email addresses according to common patterns.
 * - Accepts standard formats like user@example.com, user+tag@example.co.uk
 * - Rejects double dots, trailing dots, leading dots, domains with underscores
 * - Rejects obviously invalid forms like @@, .., missing @
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check - must have exactly one @
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }

  const [localPart, domain] = value.split('@');

  // Local part validation
  // - Cannot be empty or start/end with dot
  // - Cannot have consecutive dots
  // - Cannot contain invalid characters
  if (
    !localPart ||
    localPart.length === 0 ||
    localPart.startsWith('.') ||
    localPart.endsWith('.') ||
    localPart.includes('..')
  ) {
    return false;
  }

  // Local part: allow alphanumeric, plus common special characters
  const localPartRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localPartRegex.test(localPart)) {
    return false;
  }

  // Domain validation
  if (!domain || domain.length === 0) {
    return false;
  }

  // Domain cannot start/end with dot or hyphen, cannot have consecutive dots
  if (
    domain.startsWith('.') ||
    domain.endsWith('.') ||
    domain.startsWith('-') ||
    domain.endsWith('-') ||
    domain.includes('..')
  ) {
    return false;
  }

  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }

  // Domain parts: labels separated by dots
  // Each label: alphanumeric and hyphens, but not starting/ending with hyphen
  // TLD must be at least 2 chars
  const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  if (!domainRegex.test(domain)) {
    return false;
  }

  // TLD (last part) must be at least 2 characters
  const tld = domain.split('.').pop() || '';
  if (tld.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * - Accepts (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Rejects impossible area codes (leading 0 or 1)
 * - Rejects too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Extract digits only
  const digits = value.replace(/\D/g, '');

  // Check length - should be 10 digits (US number) or 11 with country code 1
  if (digits.length === 11 && digits.startsWith('1')) {
    // Valid with +1 country code
  } else if (digits.length === 10) {
    // Valid 10-digit number
  } else {
    return false;
  }

  // Get the actual 10-digit number (strip leading 1 if present)
  const tenDigits = digits.length === 11 ? digits.slice(1) : digits;

  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = tenDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = tenDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  // Validate format with common separators
  // Formats: (XXX) XXX-XXXX, XXX-XXX-XXXX, XXX XXX XXXX, XXXXXXXXXX, +1 prefix
  const phoneRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  if (!phoneRegex.test(value.trim())) {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers for mobile and landline formats.
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Without country code, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) but keep other characters
  const normalized = value.replace(/[\s-]/g, '');

  // Argentine phone regex breakdown:
  // Optional +54 country code
  // If no country code, must have trunk prefix 0
  // Optional mobile indicator 9 after country code or trunk prefix
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits

  // Pattern: +54 0? 9? areaCode subscriber
  // OR: 0 9? areaCode subscriber (when country code omitted)
  const argPhoneRegex = /^(\+54)?(0)?(9)?(\d{2,4})(\d{6,8})$/;
  const match = normalized.match(argPhoneRegex);

  if (!match) {
    return false;
  }

  const [, countryCode, trunkPrefix, , areaCode, subscriber] = match;

  // If country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }

  // Area code must start with 1-9 and be 2-4 digits
  if (!areaCode || areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') {
    return false;
  }

  // Subscriber must be 6-8 digits
  if (!subscriber || subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  // Total digits check (area code + subscriber = 8-11 digits)
  const totalDigits = areaCode.length + subscriber.length;
  if (totalDigits < 8 || totalDigits > 11) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * - Allows unicode letters, accents, apostrophes, hyphens, spaces
 * - Rejects digits, symbols, and strange names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Name should not be empty or just whitespace
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Trim for validation
  const trimmed = value.trim();

  // Minimum length check (at least 1 character)
  if (trimmed.length < 1) {
    return false;
  }

  // Check for digits - reject if any digits present
  if (/\d/.test(trimmed)) {
    return false;
  }

  // Check for certain symbols that shouldn't be in names
  // Allow letters (including unicode), apostrophes, hyphens, spaces
  // Also allow common accented characters
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!nameRegex.test(trimmed)) {
    return false;
  }

  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) {
    return false;
  }

  // Reject obviously strange patterns like "X Æ A-12" (already caught by digit check above)
  // But also check for excessive special characters vs letters
  const specialChars = (trimmed.match(/['-]/g) || []).length;
  const letters = (trimmed.match(/[\p{L}\p{M}]/gu) || []).length;

  // Name shouldn't be mostly special characters
  if (specialChars > letters) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers.
 * - Accepts Visa (starts with 4, 13-16 digits)
 * - Accepts Mastercard (starts with 51-55 or 2221-2720, 16 digits)
 * - Accepts AmEx (starts with 34 or 37, 15 digits)
 * - Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Extract digits only
  const digits = value.replace(/\D/g, '');

  // Check Visa: starts with 4, length 13-16
  const visaRegex = /^4\d{12,15}$/;

  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mcRegex1 = /^5[1-5]\d{14}$/;
  const mcRegex2 = /^(222[1-9]|22[3-9][0-9]|2[3-6][0-9]{2}|27[01][0-9]|2720)\d{12}$/;

  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const isValidFormat =
    visaRegex.test(digits) ||
    mcRegex1.test(digits) ||
    mcRegex2.test(digits) ||
    amexRegex.test(digits);

  if (!isValidFormat) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(digits);
}
