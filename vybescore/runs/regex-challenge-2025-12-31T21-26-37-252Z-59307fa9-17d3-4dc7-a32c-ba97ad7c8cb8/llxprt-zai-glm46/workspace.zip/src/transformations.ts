/**
 * Capitalize the first character of each sentence.
 * - Sentences end with ., !, or ?
 * - Insert exactly one space between sentences if missing
 * - Collapse extra spaces sensibly
 * - Try to leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }

  // First, normalize spacing: collapse multiple spaces into one
  let result = text.replace(/[ \t]+/g, ' ');

  // Ensure exactly one space after sentence endings if there's no space
  // Common abbreviations to avoid treating as sentence ends
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'vs', 'i.e', 'e.g'];

  // Split by sentence terminators, but be careful with abbreviations
  // Use negative lookbehind for abbreviations (when supported)
  // For better compatibility, we'll use a different approach

  // Step 1: Add space after punctuation if missing (before capital letter)
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');

  // Step 2: Capitalize first character of string
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Step 3: Capitalize after sentence terminators
  // Look for .!? followed by space(s) and lowercase letter
  // Be careful to skip abbreviations
  const sentenceEndRegex = new RegExp(`([.!?]\\s+)([a-z])`, 'g');

  result = result.replace(sentenceEndRegex, (match, punct, letter) => {
    // Check if this might be an abbreviation
    const beforePunct = result.substring(0, result.indexOf(match));
    const lastWords = beforePunct.split(/\s+/).slice(-2).join(' ');

    const isAbbr = abbreviations.some(abbr => lastWords.endsWith(abbr));

    if (isAbbr) {
      return match; // Don't capitalize after abbreviation
    }

    return punct + letter.toUpperCase();
  });

  // Step 4: Collapse multiple spaces that might have been created
  result = result.replace(/ +/g, ' ');

  // Step 5: Ensure space after punctuation if it's missing before a capital
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');

  return result;
}

/**
 * Extract all URLs from the text.
 * - Returns URLs without trailing punctuation
 * - Detects http://, https://, and www. patterns
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // URL pattern - matches http://, https://, and www.
  // Uses negative lookahead to avoid trailing punctuation
  const urlRegex =
    /(?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=%]*[a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=%]/gi;

  const matches = text.match(urlRegex) || [];

  // Remove trailing punctuation from each URL
  return matches.map(url => {
    return url.replace(/[,.)!:;?]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https:// (but not https://)
  // Using negative lookahead to avoid matching https://
  return text.replace(/http:\/\/(?!s)/gi, 'https://');
}

/**
 * Rewrite URLs from http://example.com/... to https://...
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints: cgi-bin, query strings, legacy extensions
 * - Always upgrade scheme to https
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // Pattern for example.com URLs with optional http/https
  // Match the scheme, host, and path
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade scheme to https
    const newScheme = 'https://';

    // Check if we should skip the host rewrite
    // Dynamic hints: cgi-bin, query strings (? & =), legacy extensions
    const skipRewrite =
      path.includes('/cgi-bin') ||
      path.includes('?') ||
      path.includes('.jsp') ||
      path.includes('.php') ||
      path.includes('.asp') ||
      path.includes('.aspx') ||
      path.includes('.do') ||
      path.includes('.cgi') ||
      path.includes('.pl') ||
      path.includes('.py');

    // If path starts with /docs/ and no skip conditions, rewrite host
    if (path.startsWith('/docs/') && !skipRewrite) {
      return newScheme + 'docs.example.com' + path;
    }

    // Otherwise just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * - Returns the four-digit year if format matches and month/day are valid
 * - Returns 'N/A' for invalid formats or dates
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);

  if (!dateMatch) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [
    0,
    31, // Jan
    29, // Feb (allow leap year)
    31, // Mar
    30, // Apr
    31, // May
    30, // Jun
    31, // Jul
    31, // Aug
    30, // Sep
    31, // Oct
    30, // Nov
    31, // Dec
  ];

  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  // Special check for Feb 29 in non-leap years
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear =
      (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;

    if (!isLeapYear) {
      return 'N/A';
    }
  }

  return year;
}
