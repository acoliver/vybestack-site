/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary pattern with the prefix
  // Use word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive matching)
  const filteredMatches = matches.filter(match => {
    const matchLower = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === matchLower.toLowerCase()
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token after a digit (but not at string start)
  // We need to capture the digit + token combination
  const matches = text.match(new RegExp(`\\d${token}`, 'gi')) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // Pattern: any 2-character sequence followed by the same 2 characters
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if the entire value is clearly an IPv4 address (exclude these)
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address patterns - check if value contains IPv6 anywhere
  // Pattern 1: Full IPv6 with 8 groups of 4 hex digits
  const fullIPv6 = /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/;
  
  // Pattern 2: IPv6 with compressed groups (contains ::)
  const compressedStart = /([0-9a-fA-F]{1,4}:){1,7}:/;
  const compressedEnd = /:([0-9a-fA-F]{1,4}:){1,7}/;
  const compressedMiddle = /:([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}:/;
  const flexibleCompressed = /([0-9a-fA-F]{0,4}:){0,7}:([0-9a-fA-F]{0,4}:){0,7}/;
  
  // Test against all patterns
  if (fullIPv6.test(value) || compressedStart.test(value) || compressedEnd.test(value) || compressedMiddle.test(value) || flexibleCompressed.test(value)) {
    return true;
  }
  
  // Additional check for IPv6 with embedded IPv4 notation
  const embeddedIPv4 = /([0-9a-fA-F]{1,4}:){6}(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/;
  if (embeddedIPv4.test(value)) {
    return true;
  }
  
  return false;
}
