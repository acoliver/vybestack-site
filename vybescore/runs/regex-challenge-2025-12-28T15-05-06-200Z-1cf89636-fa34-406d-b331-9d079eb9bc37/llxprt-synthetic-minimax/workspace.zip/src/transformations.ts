/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, ensure proper spacing between sentences
  // Replace multiple spaces with single space
  let processed = text.replace(/\s+/g, ' ');
  
  // Pattern to identify sentence boundaries: followed by space, then capital/lowercase
  // This captures .?! followed by sentences
  processed = processed.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    // Capitalize the letter after the punctuation and spacing
    return punctuation + spaces + letter.toUpperCase();
  });
  
  // Handle the first sentence (no preceding punctuation)
  processed = processed.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  return processed;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern to match common URL formats
  // This will match http://, https://, and www. URLs
  const urlPattern = /https?:\/\/[^\s<>"']+|www\.[^\s<>"']+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  const cleanedUrls = matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,;!?]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but leave https:// and other schemes untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const urlPattern = /http:\/\/[^\s<>"']+/gi;
  
  return text.replace(urlPattern, (url) => {
    // Check if it has dynamic hints or legacy extensions
    const hasDynamicHints = /(\?|&|=)|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(url);
    
    // Always upgrade scheme to https://
    let rewrittenUrl = url.replace(/^http:\/\//i, 'https://');
    
    // Only rewrite host for docs paths without dynamic hints
    if (/\/docs\//i.test(url) && !hasDynamicHints) {
      // Extract the full path starting from /docs to preserve structure
      const docsMatch = url.match(/\/docs.*$/i);
      if (docsMatch) {
        const path = docsMatch[0]; // This includes /docs and everything after
        rewrittenUrl = 'https://docs.example.com' + path;
      }
    }
    
    return rewrittenUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (simplified validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap year for February
  if (month === 2) {
    const isLeapYear = parseInt(year) % 4 === 0 && (parseInt(year) % 100 !== 0 || parseInt(year) % 400 === 0);
    const maxDay = isLeapYear ? 29 : 28;
    if (day < 1 || day > maxDay) {
      return 'N/A';
    }
  } else {
    if (day < 1 || day > daysInMonth[month - 1]) {
      return 'N/A';
    }
  }
  
  // Return the year if format and values are valid
  return year;
}
