export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Allow typical formats like name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain parts (but allow in local part)
  const domainParts = value.split('@')[1]?.split('.') || [];
  for (const part of domainParts) {
    if (part.includes('_')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and whitespace for processing
  const cleaned = value.replace(/[\s-().]/g, '');
  
  // Check for optional +1 prefix
  const phoneRegex = /^\+?1?(\d{10})$/;
  const match = cleaned.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  // Extract the 10-digit number
  const number = match[1];
  
  // Check area code (first 3 digits) cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Basic length check - must be exactly 10 digits after +1 and separators
  return number.length === 10;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and punctuation for validation
  const cleaned = value.replace(/[\s\-.]/g, '');
  
  // Pattern components:
  // Optional country code: +54
  // Optional trunk prefix: 0 (when no country code)
  // Optional mobile indicator: 9 (between country/trunk and area code)
  // Area code: 2-4 digits (first digit 1-9)
  // Subscriber number: remaining digits, total 6-8 digits
  
  const phonePatterns = [
    // With country code +54
    /^\+54(\d{9,10})$/,  // +54 followed by 9-10 digits (mobile or landline)
    /^\+549(\d{8})$/,   // +54 followed by mobile indicator 9 and 8 digits
    /^\+549(\d{2,4})(\d{6,7})$/, // +54, mobile indicator 9, area code 2-4 digits, subscriber 6-7 digits
    
    // Without country code, must start with trunk prefix 0
    /^0(\d{8,9})$/,     // 0 followed by 8-9 digits (area code + subscriber)
    /^0(\d{2,4})(\d{6,7})$/, // 0, area code 2-4 digits, subscriber 6-7 digits
    /^09(\d{8})$/,      // 09 followed by 8 digits (mobile format)
    /^09(\d{2,4})(\d{6,7})$/ // 09, area code 2-4 digits, subscriber 6-7 digits
  ];
  
  // Test against all patterns
  for (const pattern of phonePatterns) {
    const match = cleaned.match(pattern);
    if (match) {
      // Validate area code structure if present
      const fullNumber = match[1] || (match[2] ? match[1] + match[2] : '');
      if (fullNumber.length >= 8 && fullNumber.length <= 11) {
        return true;
      }
    }
  }
  
  // More specific validation for Argentina
  // Check if it's a valid mobile (9XX) or landline format
  const specificPatterns = [
    /^\+549(\d{8})$/,      // +54 9XXXXXXXX (mobile)
    /^\+549(\d{2,4})(\d{6,7})$/, // +54 9XX XXXXXXX (mobile with area)
    /^09(\d{8})$/,         // 09XXXXXXXX (mobile trunk)
    /^09(\d{2,4})(\d{6,7})$/,   // 09XX XXXXXXX (mobile trunk with area)
    /^\+54(\d{2,4})(\d{6,7})$/, // +54XX XXXXXXX (landline with country)
    /^0(\d{2,4})(\d{6,7})$/,    // 0XX XXXXXXX (landline trunk)
  ];
  
  for (const pattern of specificPatterns) {
    if (pattern.test(cleaned)) {
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject names with digits or symbols (except apostrophes, hyphens, and spaces)
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject X Æ A-12 style names
  
  // Check if it contains any digits or prohibited symbols
  const invalidPattern = /[\dÆØÅæøå`~!@#$%^&*()_=+[\\]{}\\|;:'",.<>\/?]/;
  
  if (invalidPattern.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const letterPattern = /[\p{L}]/u;
  if (!letterPattern.test(value)) {
    return false;
  }
  
  // Check for reasonable name structure
  // Allow letters, spaces, apostrophes, and hyphens
  const validPattern = /^[\p{L}\s'-]+$/u;
  if (!validPattern.test(value)) {
    return false;
  }
  
  // Reject names that are too short or start/end with invalid characters
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject names starting or ending with apostrophes or hyphens
  if (value.match(/^['-]|['-]$/)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any spaces or hyphens for processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Validate prefixes and lengths for common card types
  const cardPatterns = [
    // Visa: starts with 4, 13-19 digits
    /^4\d{12,18}$/,
    // MasterCard: starts with 51-55 or 2221-2720, 16 digits
    /^5[1-5]\d{14}$/,
    /^2[2-7]\d{14}$/,
    // American Express: starts with 34 or 37, 15 digits
    /^3[47]\d{13}$/
  ];
  
  let isValidFormat = false;
  for (const pattern of cardPatterns) {
    if (pattern.test(cleaned)) {
      isValidFormat = true;
      break;
    }
  }
  
  if (!isValidFormat) {
    return false;
  }
  
  // Apply Luhn checksum algorithm
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i));
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
