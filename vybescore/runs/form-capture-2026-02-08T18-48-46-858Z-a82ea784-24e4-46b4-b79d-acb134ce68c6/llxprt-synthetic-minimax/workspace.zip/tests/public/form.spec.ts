import { describe, expect, it } from 'vitest';
import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';

describe('friendly form (public smoke)', () => {
  it('should build successfully', async () => {
    // Simple build verification
    const build = spawn('npm', ['run', 'build'], {
      cwd: process.cwd(),
      stdio: 'pipe'
    });
    
    return new Promise((resolve, reject) => {
      build.on('close', (code: number) => {
        if (code === 0) {
          resolve(void 0);
        } else {
          reject(new Error(`Build failed with code ${code}`));
        }
      });
    });
  });

  it('should have required compiled files', async () => {
    // Check essential compiled files exist
    const distPath = path.resolve('dist');
    const serverJs = path.resolve('dist', 'server.js');
    const templatesPath = path.resolve('dist', 'templates');
    
    expect(fs.existsSync(distPath)).toBe(true);
    expect(fs.existsSync(serverJs)).toBe(true);
    expect(fs.existsSync(templatesPath)).toBe(true);
  });

  it('should have all EJS templates', async () => {
    // Check templates exist
    const formTemplate = path.resolve('dist', 'templates', 'form.ejs');
    const thankYouTemplate = path.resolve('dist', 'templates', 'thank-you.ejs');
    
    expect(fs.existsSync(formTemplate)).toBe(true);
    expect(fs.existsSync(thankYouTemplate)).toBe(true);
  });

  it('should have database schema', async () => {
    // Check database schema exists
    const schemaPath = path.resolve('db', 'schema.sql');
    expect(fs.existsSync(schemaPath)).toBe(true);
    
    const schemaContent = fs.readFileSync(schemaPath, 'utf8');
    expect(schemaContent).toContain('submissions');
    expect(schemaContent).toContain('first_name');
  });

  it('should have CSS styling', async () => {
    // Check CSS exists and has content
    const cssPath = path.resolve('public', 'styles.css');
    expect(fs.existsSync(cssPath)).toBe(true);
    
    const cssContent = fs.readFileSync(cssPath, 'utf8');
    expect(cssContent.length).toBeGreaterThan(100);
    expect(cssContent).toContain('.form-shell');
  });
});
