import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';
import { join } from 'path';

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private sql: SqlJsStatic | null = null;
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    if (this.sql === null) {
      this.sql = await initSqlJs();
    }

    let dbExists = existsSync(this.dbPath);

    if (dbExists) {
      // Load existing database
      const dbFile = readFileSync(this.dbPath);
      this.db = new this.sql!.Database(dbFile);
    } else {
      // Create new database
      this.db = new this.sql!.Database();
      
      // Read and execute schema
      const schemaSql = readFileSync(this.schemaPath, 'utf8');
      this.db.exec(schemaSql);

      // Write the database file to disk
      this.writeDatabase();
      dbExists = true;
    }
  }

  async insertSubmission(data: SubmissionData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const sql = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    this.db.run(sql, [
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);

    // Write changes to disk after each insert
    this.writeDatabase();
  }

  private writeDatabase(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const binaryDb = this.db.export();
    writeFileSync(this.dbPath, Buffer.from(binaryDb));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default DatabaseManager;