import express from 'express';
import { join } from 'path';
import { fileURLToPath } from 'url';
import { dirname } from 'path';
import DatabaseManager from './database.js';
import { validateFormData, type FormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = parseInt(process.env.PORT || '3535', 10);

// Initialize database
const dbManager = new DatabaseManager();

app.set('view engine', 'ejs');
app.set('views', join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(join(__dirname, '..', 'public')));

// Routes

// GET / - Render form
app.get('/', (req, res) => {
  res.status(200).render('form', {
    errors: [],
    values: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    // Validation failed - re-render form with errors
    return res.status(400).render('form', {
      errors: validation.errors,
      values: validation.values
    });
  }

  // Validation successful - store in database
  try {
    const submissionData = {
      first_name: validation.values.firstName!,
      last_name: validation.values.lastName!,
      street_address: validation.values.streetAddress!,
      city: validation.values.city!,
      state_province: validation.values.stateProvince!,
      postal_code: validation.values.postalCode!,
      country: validation.values.country!,
      email: validation.values.email!,
      phone: validation.values.phone!
    };

    dbManager.insertSubmission(submissionData);
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error storing submission:', error);
    return res.status(500).render('form', {
      errors: ['An error occurred while storing your submission. Please try again.'],
      values: validation.values
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req, res) => {
  res.status(200).render('thank-you', {
    firstName: req.query.firstName || 'friend'
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  dbManager.close();
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
