export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
  values: Partial<FormData>;
}

export function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  const values: Partial<FormData> = {};

  // Validate first name
  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  } else {
    values.firstName = data.firstName.trim();
  }

  // Validate last name
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  } else {
    values.lastName = data.lastName.trim();
  }

  // Validate street address
  if (!data.streetAddress?.trim()) {
    errors.push('Street address is required');
  } else {
    values.streetAddress = data.streetAddress.trim();
  }

  // Validate city
  if (!data.city?.trim()) {
    errors.push('City is required');
  } else {
    values.city = data.city.trim();
  }

  // Validate state/province/region
  if (!data.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  } else {
    values.stateProvince = data.stateProvince.trim();
  }

  // Validate postal code (accept alphanumeric strings)
  if (!data.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push('Postal code contains invalid characters');
  } else {
    values.postalCode = data.postalCode.trim();
  }

  // Validate country
  if (!data.country?.trim()) {
    errors.push('Country is required');
  } else {
    values.country = data.country.trim();
  }

  // Validate email
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!isValidEmail(data.email.trim())) {
    errors.push('Please enter a valid email address');
  } else {
    values.email = data.email.trim();
  }

  // Validate phone (allow international formats)
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!isValidPhone(data.phone.trim())) {
    errors.push('Please enter a valid phone number');
  } else {
    values.phone = data.phone.trim();
  }

  return {
    isValid: errors.length === 0,
    errors,
    values
  };
}

function isValidEmail(email: string): boolean {
  // Simple email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Must contain at least some digits and be reasonably sized
  const digitsOnly = phone.replace(/\D/g, '');
  
  if (digitsOnly.length < 7) {
    return false;
  }
  
  // Allow international format with +, @, spaces, parentheses, dashes
  // Basic validation that it's not completely malformed
  const hasValidChars = /^[+\d\s()\-@]+$/.test(phone);
  const hasDigits = /\d/.test(phone);
  
  return hasValidChars && hasDigits;
}