import fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { getFormatter } from '../formats/index.js';

function parseArgs(args: string[]): {
  dataFile: string;
  format: string;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  let dataFile = '';
  let format = 'markdown';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format') {
      i++;
      format = args[i];
    } else if (arg === '--output') {
      i++;
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!dataFile) {
      dataFile = arg;
    }
  }

  if (!dataFile) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid data: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: entry at index ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid data: entry at index ${index} missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid data: entry at index ${index} missing or invalid "amount" field (expected number)`);
    }

    return { label: entryObj.label, amount: entryObj.amount };
  });

  return { title: obj.title, summary: obj.summary, entries };
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const { dataFile, format, outputPath, includeTotals } = parseArgs(args);

    const fileContent = fs.readFileSync(dataFile, 'utf-8');
    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof Error) {
        throw new Error(`Failed to parse JSON: ${error.message}`);
      }
      throw new Error('Failed to parse JSON');
    }

    const reportData = validateData(data);

    const renderer = getFormatter(format);
    const options: RenderOptions = { includeTotals };
    const output = renderer(reportData, options);

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();
