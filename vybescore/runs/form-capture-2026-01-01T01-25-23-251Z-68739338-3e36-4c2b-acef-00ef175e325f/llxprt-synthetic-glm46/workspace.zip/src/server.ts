import express from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { fileURLToPath } from 'url';

// Set __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Type definitions for app state
interface FormData {
  firstName: string | null;
  lastName: string | null;
  streetAddress: string | null;
  city: string | null;
  stateProvince: string | null;
  postalCode: string | null;
  country: string | null;
  email: string | null;
  phone: string | null;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Configure middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Determine if we're running from source or dist
const isDistRun = __dirname.includes('dist');
const publicDir = isDistRun 
  ? path.join(__dirname, '../public') 
  : path.join(__dirname, '../../public');

app.use(express.static(publicDir));

// Set view engine to EJS
app.set('view engine', 'ejs');

let templatesDir;
if (isDistRun) {
  // When running from dist, templates should be in dist/src/templates
  templatesDir = path.join(__dirname, 'templates');
} else {
  // When running from source, templates are in src/templates
  templatesDir = path.join(__dirname, 'templates');
}

app.set('views', templatesDir);

// Initialize SQLite database
let db: Database;
const DATA_DIR = path.join(__dirname, '../data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');

// Initialize database function
async function initDatabase() {
  // Create data directory if it doesn't exist
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }
  
  // Determine where to find the node_modules and schema files
  const isDistRun = __dirname.includes('dist');
  const nodeModulesPath = isDistRun
    ? path.join(__dirname, '../node_modules')
    : path.join(__dirname, '../../node_modules');
  
  // Initialize sql.js
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(nodeModulesPath, `sql.js/dist/${file}`)
  });
  
  // Load existing database or create new one
  let databaseBuffer: Uint8Array | null = null;
  try {
    if (fs.existsSync(DB_PATH)) {
      const data = fs.readFileSync(DB_PATH);
      databaseBuffer = new Uint8Array(data);
    }
  } catch (error) {
    // If file doesn't exist or can't be read, we'll create a new one
    console.error('Error loading database, will create a new one:', error);
  }
  
  // Create or load database
  db = new SQL.Database(databaseBuffer);
  
  // Find schema.sql in either src or dist location
  let schemaPath;
  if (isDistRun) {
    schemaPath = path.join(__dirname, '../db/schema.sql');
    if (!fs.existsSync(schemaPath)) {
      schemaPath = path.join(__dirname, '../../db/schema.sql');
    }
  } else {
    schemaPath = path.join(__dirname, '../db/schema.sql');
  }
  
  // Create submissions table if it doesn't exist
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.run(schema);
  
  console.log('Database initialized successfully');
}

// Save database to disk
function saveDatabase() {
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Error saving database:', error);
  }
}

// Copy assets to dist folder during build if needed
function copyAssetsToDist() {
  // This is only needed when running from dist
  const isDistRun = __dirname.includes('dist');
  if (!isDistRun) return;
  
  try {
    const projectRoot = path.resolve(__dirname, '../..');
    const distRoot = path.join(__dirname, '..');
    
    // Source paths
    const srcTemplates = path.join(projectRoot, 'src', 'templates');
    const srcPublic = path.join(projectRoot, 'public');
    const srcDb = path.join(projectRoot, 'db');
    
    // Destination paths
    const distTemplates = path.join(distRoot, 'src', 'templates');
    const distPublic = path.join(distRoot, 'public');
    const distDb = path.join(distRoot, 'db');
    
    // Create directories if they don't exist
    if (!fs.existsSync(distTemplates)) fs.mkdirSync(distTemplates, { recursive: true });
    if (!fs.existsSync(distPublic)) fs.mkdirSync(distPublic, { recursive: true });
    if (!fs.existsSync(distDb)) fs.mkdirSync(distDb, { recursive: true });
    
    // Copy template files
    if (fs.existsSync(srcTemplates)) {
      const templateFiles = fs.readdirSync(srcTemplates);
      templateFiles.forEach(file => {
        fs.copyFileSync(
          path.join(srcTemplates, file),
          path.join(distTemplates, file)
        );
      });
    }
    
    // Copy public files
    if (fs.existsSync(srcPublic)) {
      const publicFiles = fs.readdirSync(srcPublic);
      publicFiles.forEach(file => {
        const srcPath = path.join(srcPublic, file);
        const destPath = path.join(distPublic, file);
        
        if (fs.statSync(srcPath).isDirectory()) {
          if (!fs.existsSync(destPath)) fs.mkdirSync(destPath, { recursive: true });
          // Recursively copy subdirectory
          const subFiles = fs.readdirSync(srcPath);
          subFiles.forEach(subFile => {
            fs.copyFileSync(
              path.join(srcPath, subFile),
              path.join(destPath, subFile)
            );  
          });
        } else {
          fs.copyFileSync(srcPath, destPath);
        }
      });
    }
    
    // Copy db files
    if (fs.existsSync(srcDb)) {
      const dbFiles = fs.readdirSync(srcDb);
      dbFiles.forEach(file => {
        fs.copyFileSync(
          path.join(srcDb, file),
          path.join(distDb, file)
        );
      });
    }
  } catch (error) {
    console.error('Error copying assets to dist:', error);
  }
}

// Validate form data
function validateFormData(data: FormData): string[] {
  const errors: string[] = [];
  
  // Check required fields
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  }
  
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  }
  
  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else {
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email.trim())) {
      errors.push('Please provide a valid email address');
    }
  }

  // Postal code validation - allow alphanumeric
  if (data.postalCode && !/^[a-zA-Z0-9\s]+$/.test(data.postalCode.trim())) {
    errors.push('Postal/Zip code should only contain letters and numbers');
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else {
    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = new RegExp('^\\+?[\\d\\s()\\-]+$');
    if (!phoneRegex.test(data.phone.trim())) {
      errors.push('Please provide a valid phone number');
    }
  }
  
  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    values: {},
    errors: []
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || null,
    lastName: req.body.lastName || null,
    streetAddress: req.body.streetAddress || null,
    city: req.body.city || null,
    stateProvince: req.body.stateProvince || null,
    postalCode: req.body.postalCode || null,
    country: req.body.country || null,
    email: req.body.email || null,
    phone: req.body.phone || null
  };
  
  const errors = validateFormData(formData);
  
  if (errors.length > 0) {
    // Render form with errors and entered values
    return res.status(400).render('form', {
      values: formData,
      errors
    });
  }
  
  // Insert data into database
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName?.trim() || '',
      formData.lastName?.trim() || '',
      formData.streetAddress?.trim() || '',
      formData.city?.trim() || '',
      formData.stateProvince?.trim() || '',
      formData.postalCode?.trim() || '',
      formData.country?.trim() || '',
      formData.email?.trim() || '',
      formData.phone?.trim() || ''
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName || '')}`);
  } catch (error) {
    console.error('Error inserting data:', error);
    errors.push('An error occurred while saving your submission. Please try again.');
    res.status(500).render('form', {
      values: formData,
      errors
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', {
    firstName
  });
});

// Start server
async function startServer() {
  // Copy assets for dist folder
  copyAssetsToDist();
  
  await initDatabase();
  
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
  
  // Graceful shutdown
  const gracefulShutdown = () => {
    console.log('Shutting down gracefully...');
    if (db) db.close();
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
  
  return server;
}

// Start the server
startServer().catch(err => {
  console.error('Failed to start server:', err);
  process.exit(1);
});
