export interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

export function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with optional spaces
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

export function validateRequired(value: string): boolean {
  return Boolean(value && value.trim().length > 0);
}

export function validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  if (data.firstName !== undefined && !validateRequired(data.firstName)) {
    errors.firstName = 'First name is required';
  }

  if (data.lastName !== undefined && !validateRequired(data.lastName)) {
    errors.lastName = 'Last name is required';
  }

  if (data.streetAddress !== undefined && !validateRequired(data.streetAddress)) {
    errors.streetAddress = 'Street address is required';
  }

  if (data.city !== undefined && !validateRequired(data.city)) {
    errors.city = 'City is required';
  }

  if (data.stateProvince !== undefined && !validateRequired(data.stateProvince)) {
    errors.stateProvince = 'State / Province / Region is required';
  }

  if (data.postalCode !== undefined) {
    if (!validateRequired(data.postalCode)) {
      errors.postalCode = 'Postal / Zip code is required';
    } else if (!validatePostalCode(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  if (data.country !== undefined && !validateRequired(data.country)) {
    errors.country = 'Country is required';
  }

  if (data.email !== undefined) {
    if (!validateRequired(data.email)) {
      errors.email = 'Email is required';
    } else if (!validateEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  if (data.phone !== undefined) {
    if (!validateRequired(data.phone)) {
      errors.phone = 'Phone number is required';
    } else if (!validatePhone(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  const isValid = Object.keys(errors).length === 0;

  return { isValid, errors };
}