import express, { Request, Response } from 'express';
import path from 'node:path';
import { initializeDatabase, insertSubmission, saveDatabase, closeDatabase, Submission } from './db.js';
import { validateForm, FormData } from './validation.js';

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone
    };

    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      // Re-render form with errors
      const errors = Object.values(validation.errors);
      return res.status(400).render('form', { 
        errors, 
        values: formData 
      });
    }

    // Insert submission into database
    const submission: Submission = {
      first_name: formData.firstName!,
      last_name: formData.lastName!,
      street_address: formData.streetAddress!,
      city: formData.city!,
      state_province: formData.stateProvince!,
      postal_code: formData.postalCode!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!
    };

    insertSubmission(submission);
    saveDatabase();

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('form', { 
      errors: ['An unexpected error occurred. Please try again.'], 
      values: req.body 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // For simplicity, using a generic greeting. In a real app, you might
  // store this in a session or query parameter
  res.render('thank-you', { firstName: 'friend' });
});

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    const gracefulShutdown = (): void => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        closeDatabase();
        console.log('Server closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch((error) => {
  console.error('Server startup failed:', error);
  process.exit(1);
});
