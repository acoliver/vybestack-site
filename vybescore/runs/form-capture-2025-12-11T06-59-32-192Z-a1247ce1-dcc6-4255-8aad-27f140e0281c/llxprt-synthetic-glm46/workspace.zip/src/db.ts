import fs from 'node:fs';
import path from 'node:path';

interface Database {
  export(): Uint8Array;
  close(): void;
  prepare(sql: string): Statement;
  exec(sql: string): { columns: string[]; values: unknown[][] }[];
}

interface Statement {
  run(params: unknown[]): void;
  free(): void;
}

let db: Database | null = null;

export interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function initializeDatabase(): Promise<Database> {
    // Need to use dynamic import for ESM modules
  const sqlJsModule = await import('sql.js') as { default: () => Promise<{ Database: new (data?: Uint8Array) => Database }> };
  const sqlJs = await sqlJsModule.default();
  const dbPath = path.resolve('data', 'submissions.sqlite');
  const schemaPath = path.resolve('db', 'schema.sql');
  
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Read schema
  const schema = fs.readFileSync(schemaPath, 'utf8');
  
  // Load existing database or create new one
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new sqlJs.Database(buffer);
  } else {
    db = new sqlJs.Database();
  }
  
  // Apply schema (CREATE TABLE IF NOT EXISTS)
  db.exec(schema);
  
  return db;
}

export function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db;
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized.');
  }
  
  const dbPath = path.resolve('data', 'submissions.sqlite');
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

export function insertSubmission(submission: Submission): number {
  const database = getDatabase();
  const stmt = database.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    submission.first_name,
    submission.last_name,
    submission.street_address,
    submission.city,
    submission.state_province,
    submission.postal_code,
    submission.country,
    submission.email,
    submission.phone
  ]);
  
  stmt.free();
  
  // Get the last inserted row ID
  const result = database.exec("SELECT last_insert_rowid() as id");
  return result[0].values[0][0] as number;
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}