declare module 'sql.js' {
  interface Database {
    exec(sql: string): Array<{
      columns: Array<string>;
      values: Array<Array<unknown>>;
    }>;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }

  interface Config {
    locateFile?: (file: string) => string;
  }

  function init(config?: Config): Promise<InitSqlJsInterface>;

  interface InitSqlJsInterface {
    Database: new (data?: ArrayBuffer) => Database;
  }

  export default init;
}