/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences even if input omitted it.
 * Collapse extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces (but not within sentences)
  let normalized = text.replace(/[ \t]+/g, ' ').trim();

  // Add space after sentence endings if missing
  normalized = normalized.replace(/([.!?])([^ \s\n])/g, '$1 $2');

  // Split by sentence endings, capitalize, and rejoin
  const sentences: string[] = [];
  let currentSentence = '';

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];

    if (char === '.' || char === '!' || char === '?') {
      currentSentence += char;
      sentences.push(currentSentence);
      currentSentence = '';
    } else {
      currentSentence += char;
    }
  }

  if (currentSentence) {
    sentences.push(currentSentence);
  }

  // Capitalize first letter of each sentence
  const result = sentences
    .map((sentence) => {
      if (sentence.length === 0) return '';
      // Find the first letter
      const match = sentence.match(/[a-zA-Z\u00C0-\u00FF]/);
      if (match && match.index !== undefined) {
        const firstLetterIndex = match.index;
        const firstLetter = sentence[firstLetterIndex];
        return (
          sentence.slice(0, firstLetterIndex) +
          firstLetter.toUpperCase() +
          sentence.slice(firstLetterIndex + 1)
        );
      }
      return sentence;
    })
    .join('');

  return result;
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/(?:www\.)?[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s\])}"',>.!?;:]*)?/g;

  const matches = text.match(urlRegex);

  if (!matches) {
    return [];
  }

  return matches.map((url) => {
    return url.replace(/[.,;:!?)\]}'">]+$/, '');
  });
}

/**
 * Replace http:// with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs to use subdomain.
 */
export function rewriteDocsUrls(text: string): string {
  const urlPattern = /(http:\/\/example\.com)(\/[^\s]*)/g;

  return text.replace(urlPattern, (match, protocolAndHost, path) => {
    const secureHost = 'https://example.com';

    const skipRewritePatterns = [
      /\/cgi-bin/,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/,
    ];

    const shouldSkipRewrite = skipRewritePatterns.some((pattern) => pattern.test(path));

    if (shouldSkipRewrite) {
      return secureHost + path;
    }

    if (path.startsWith('/docs/')) {
      return 'https://docs.example.com' + path;
    }

    return secureHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy format.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  if (month < 1 || month > 12) {
    return 'N/A';
  }

  const daysInMonth: Record<number, number> = {
    1: 31,
    2: 29,
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31,
  };

  const maxDays = daysInMonth[month];
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }

  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear =
      (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }

  return year;
}
