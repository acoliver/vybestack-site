/**
 * Find words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create regex to find words starting with prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w+)\\b`, 'g');

  const matches = text.match(wordRegex);

  if (!matches) {
    return [];
  }

  // Filter out exceptions
  return matches.filter((word) => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Look for digit followed by token, not at the start of string
  // Return the full match including the digit
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');

  const matches = text.match(pattern);

  if (!matches) {
    return [];
  }

  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, abcabc, 1212)
  // Look for patterns of length 2-6 that repeat immediately
  for (let len = 2; len <= 6; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const segment = value.slice(i, i + len);
      const nextSegment = value.slice(i + len, i + 2 * len);
      if (segment === nextSegment) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern with shorthand support
  // Full form: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can replace one or more consecutive zero groups
  // Can include IPv4 embedded address at the end

  // First, check for IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }

  // Simpler IPv6 pattern for common cases
  const simpleIpv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/; // Full form
  const shorthandPattern = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/; // With ::

  if (simpleIpv6Pattern.test(value) || shorthandPattern.test(value)) {
    return true;
  }

  // More comprehensive pattern for various IPv6 formats
  const comprehensivePattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  const comprehensiveMatch = value.match(comprehensivePattern);

  if (comprehensiveMatch) {
    // Verify it's actually an IPv6 format by checking structure
    const candidate = comprehensiveMatch[0];
    const colonCount = (candidate.match(/:/g) || []).length;
    if (colonCount >= 2 && colonCount <= 7) {
      // Make sure it contains hex digits and colons
      if (/[0-9a-fA-F]:/.test(candidate)) {
        return true;
      }
    }
  }

  // Check for :: shorthand specifically
  if (/::/.test(value) && /[0-9a-fA-F]/.test(value)) {
    return true;
  }

  return false;
}
