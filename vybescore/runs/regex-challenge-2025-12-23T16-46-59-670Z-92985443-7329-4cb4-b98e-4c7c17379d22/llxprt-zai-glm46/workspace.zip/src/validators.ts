export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\s/g, '').split('').map(Number);
  let sum = 0;
  let isSecond = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isSecond) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isSecond = !isSecond;
  }

  return sum % 10 === 0;
}

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Check for obviously invalid patterns first
  if (/\.\.|@.*@|@.*\._|_$|^\s|\s$/.test(value)) {
    return false;
  }

  // Main email regex pattern
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~+-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~+-]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional validation: domain cannot contain underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }

  // Reject if domain part starts or ends with a dot or hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-') || part === '') {
      return false;
    }
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // Check minimum length (area code + 7 digits = 10, or 11 with country code)
  if (digitsOnly.length < 10) {
    return false;
  }

  // If starts with 1 (country code), the next digit (area code start) cannot be 0 or 1
  // If no country code, the first digit (area code start) cannot be 0 or 1
  let areaCodeStart: string;
  if (digitsOnly.length === 11 && digitsOnly[0] === '1') {
    areaCodeStart = digitsOnly[1];
  } else if (digitsOnly.length === 10) {
    areaCodeStart = digitsOnly[0];
  } else if (digitsOnly.length > 11) {
    // Optionally allow extensions if specified
    if (options?.allowExtensions) {
      if (digitsOnly.length === 11 && digitsOnly[0] === '1') {
        areaCodeStart = digitsOnly[1];
      } else if (digitsOnly.length >= 10) {
        areaCodeStart = digitsOnly[0];
      } else {
        return false;
      }
    } else {
      return false;
    }
  } else {
    return false;
  }

  // Area code cannot start with 0 or 1
  if (areaCodeStart === '0' || areaCodeStart === '1') {
    return false;
  }

  // Validate the format with various separators
  const phoneRegex = /^\+?1?[\s-]?\(?[2-9]\d{2}\)?[\s-]?\d{3}[\s-]?\d{4}(?:\s?(?:ext|ex|x)\.?\s?\d+)?$/i;

  return phoneRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for easier parsing
  const cleaned = value.replace(/[\s-]/g, '');

  // Match patterns with optional country code, trunk prefix, mobile indicator
  // +54 [9] [area code] [subscriber]
  // 0[area code] [subscriber]
  const argentinaPhoneRegex = /^(?:\+54)?(?:0|9)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(argentinaPhoneRegex);

  if (!match) {
    return false;
  }

  const areaCode = match[1];
  const subscriber = match[2];

  // Area code must be 2-4 digits (already captured by regex)
  // Subscriber must be 6-8 digits (already captured by regex)
  // Both checks handled by regex

  // Validate the structure is correct
  const areaCodeDigits = areaCode.length;
  if (areaCodeDigits < 2 || areaCodeDigits > 4) {
    return false;
  }

  const subscriberDigits = subscriber.length;
  if (subscriberDigits < 6 || subscriberDigits > 8) {
    return false;
  }

  // Area code leading digit must be 1-9 (handled by regex)

  // When country code is omitted, must begin with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Check for digits or invalid symbols
  if (/\d|[<>{}[\]\\^$|?*!@#%&+=]/.test(value)) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must contain at least one letter
  const nameRegex = /^[\p{L}'\-.]+(?:[\s][\p{L}'\-.]+)*$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Check there's at least one unicode letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Check length (13-19 digits for various card types)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }

  // Check prefixes and lengths for different card types
  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4\d{12}(\d{3}(\d{3})?)?$/;

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7][0-9]{13})$/;

  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;

  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
