import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { createServer, shutdown } from '../../src/server.js';

let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  app = await createServer();
});

afterAll(() => {
  shutdown();
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app).post('/submit').send({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'invalid-email',
      phone: 'invalid-phone!!!',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you').query({
      firstName: 'Alice',
    });

    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you, Alice');
  });
});
