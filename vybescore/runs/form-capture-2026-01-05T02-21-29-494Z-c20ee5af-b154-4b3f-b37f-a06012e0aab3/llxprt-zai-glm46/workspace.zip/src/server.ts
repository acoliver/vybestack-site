import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface SqlJsType {
  Database: new (data?: ArrayBuffer | number[]) => Database;
}

let SQL: SqlJsType | null = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
let db: Database | null = null;

app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[(]?\d+[)]?[-\s\d]*$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCode.trim().length > 0 && postalRegex.test(postalCode);
}

function validateForm(data: Partial<FormData>): string[] {
  const errors: string[] = [];
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field];
    if (!value || (typeof value === 'string' && value.trim().length === 0)) {
      const label = field
        .replace(/([A-Z])/g, (match) => ` ${match.toLowerCase()}`)
        .trim();
      const capitalizedLabel = label.charAt(0).toUpperCase() + label.slice(1);
      errors.push(`${capitalizedLabel} is required`);
    }
  }

  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number');
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return errors;
}

function initializeDatabase(): Database {
  const dbDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
  }

  if (!SQL) {
    throw new Error('SQL.js not initialized');
  }

  let dbInstance: Database;
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    const arrayBuffer = buffer.buffer.slice(buffer.byteOffset, buffer.byteOffset + buffer.byteLength);
    dbInstance = new SQL.Database(arrayBuffer);
  } else {
    dbInstance = new SQL.Database();
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req, res) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone,
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400).render('form', {
      errors,
      values: formData,
    });
    return;
  }

  if (!db) {
    errors.push('Database not available. Please try again.');
    res.status(500).render('form', {
      errors,
      values: formData,
    });
    return;
  }

  try {
    db.run(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );

    saveDatabase(db);

    res.redirect(302, '/thank-you');
  } catch (error) {
    errors.push('Failed to save submission. Please try again.');
    res.status(500).render('form', {
      errors,
      values: formData,
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string | undefined;
  res.render('thank-you', { firstName: firstName || 'friend' });
});

function createServer(): Promise<express.Express> {
  return new Promise((resolve, reject) => {
    initSqlJs()
      .then((sqlJs: SqlJsType) => {
        SQL = sqlJs;
        db = initializeDatabase();
        resolve(app);
      })
      .catch((error: unknown) => {
        reject(error);
      });
  });
}

function startServer(port: number): Promise<void> {
  return new Promise((resolve, reject) => {
    createServer()
      .then(() => {
        app.listen(port, () => {
          resolve();
        });
      })
      .catch((error) => {
        reject(error);
      });
  });
}

function shutdown(): void {
  if (db) {
    db.close();
    db = null;
  }
}

process.on('SIGTERM', () => {
  shutdown();
  process.exit(0);
});

process.on('SIGINT', () => {
  shutdown();
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

  startServer(port).then(() => {
    console.log(`Server running on http://localhost:${port}`);
  });
}

export { app, startServer, shutdown, createServer };
