declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: new (data?: ArrayBuffer | number[]) => Database;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    get(params?: unknown[]): unknown[] | null;
    all(params?: unknown[]): unknown[][];
    free(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface RunResult {
    changes: number;
    lastInsertRowid: number | bigint;
  }

  const initSqlJs: () => Promise<SqlJsStatic>;
  export default initSqlJs;

  // Add export for the namespace
  export namespace SqlJsStatic {}
}
