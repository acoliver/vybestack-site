const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate that the input string contains only valid Base64 characters.
 * Throws an error if the input contains invalid characters.
 */
function validateBase64Input(input: string): void {
  // Check for invalid characters
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for incorrect padding placement
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const afterPadding = input.slice(paddingIndex);
    if (!/^[=]+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }

    // Padding can only be 1 or 2 characters
    if (afterPadding.length > 2) {
      throw new Error('Invalid Base64 input: invalid padding length');
    }

    // Total length with padding must be a multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  } else if (input.length % 4 !== 0) {
    // Without padding, length doesn't need to be a multiple of 4
    // but we'll add padding for decoding
  }
}

/**
 * Encode plain text to Base64 using the canonical alphabet.
 * Output includes padding characters (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate input before attempting to decode
  validateBase64Input(trimmed);

  try {
    // Node.js Buffer can handle Base64 with or without padding
    const buffer = Buffer.from(trimmed, 'base64');

    // If the input was valid but produced empty buffer, that's suspicious
    // (unless the input itself was empty or just padding)
    if (trimmed.length > 0 && !trimmed.startsWith('=') && buffer.length === 0) {
      throw new Error('Failed to decode Base64 input: produced empty result');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
