import { useEffect, useState, useRef } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number): InventoryState {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;

    async function load(): Promise<void> {
      setState((prev) => ({ ...prev, status: 'loading', error: null }));
      try {
        const url = new URL('/inventory', window.location.origin);
        url.searchParams.set('page', page.toString());
        url.searchParams.set('limit', limit.toString());
        
        const response = await fetch(url.toString());
        if (!response.ok) {
          let errorMessage = `Request failed with status ${response.status}`;
          try {
            const errorData = await response.json();
            if (errorData.error) {
              errorMessage = errorData.error;
            }
          } catch {
            // Use default error message if response isn't valid JSON
          }
          throw new Error(errorMessage);
        }
        const payload = (await response.json()) as InventoryPage;
        if (mountedRef.current) {
          setState({ status: 'ready', data: payload, error: null });
        }
      } catch (error) {
        if (mountedRef.current) {
          const message = error instanceof Error ? error.message : 'Unknown error';
          setState({ status: 'error', data: null, error: message });
        }
      }
    }

    // Load on mount and when page/limit change
    load();

    return () => {
      mountedRef.current = false;
    };
  }, [page, limit]);

  return state;
}
