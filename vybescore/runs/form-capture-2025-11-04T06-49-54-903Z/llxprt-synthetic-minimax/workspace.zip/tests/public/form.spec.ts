import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: any;
let app: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and start the server
  const { default: serverModule } = await import('../../dist/server.js');
  app = serverModule;
  
  // Get the server instance (it's stored on globalThis)
  server = (globalThis as any).server;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check for all required fields
    expect($('#first_name').length).toBe(1);
    expect($('#last_name').length).toBe(1);
    expect($('#street_address').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#state_province').length).toBe(1);
    expect($('#postal_code').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
    
    // Check that form has correct attributes
    expect($('form[method="POST"]').length).toBe(1);
    expect($('form').attr('action')).toBe('/submit');
  });

  it('persists submission and redirects', async () => {
    // Verify database doesn't exist
    expect(fs.existsSync(dbPath)).toBe(false);
    
    const response = await request(app)
      .post('/submit')
      .send({
        first_name: 'John',
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'Anytown',
        state_province: 'State',
        postal_code: '12345',
        country: 'Country',
        email: 'john.doe@example.com',
        phone: '+1 234 567 8900'
      })
      .expect(302); // Expect redirect

    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
