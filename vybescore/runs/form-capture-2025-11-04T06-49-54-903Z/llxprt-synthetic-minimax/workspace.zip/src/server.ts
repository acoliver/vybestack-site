import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// EJS setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Database setup
let db: Database | null = null;
const dbPath = path.join(__dirname, '..', '..', 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(__dirname, '..', '..', 'node_modules', 'sql.js', 'dist', file),
  });

  try {
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      db = new SQL(new Uint8Array(dbBuffer));
    } else {
      db = new SQL();
      // Create table
      const schema = `
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province TEXT NOT NULL,
          postal_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone TEXT NOT NULL,
          created_at TEXT NOT NULL DEFAULT (datetime('now'))
        );
      `;
      db.exec(schema);
    }
  } catch (error) {
    console.error('Database initialization error:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) {
    return;
  }

  const data = db.export();
  const buffer = Buffer.from(data);
  const dir = path.dirname(dbPath);
  
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  
  fs.writeFileSync(dbPath, buffer);
}

// Validation functions
interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handles UK "SW1A 1AA" and Argentine formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Check required fields
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field].trim()) {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email.trim() && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone.trim() && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation
  if (data.postal_code.trim() && !validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  return errors;
}

// Routes

// GET / - Render form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    data: {
      first_name: '',
      last_name: '',
      street_address: '',
      city: '',
      state_province: '',
      postal_code: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    // Re-render form with errors
    return res.status(400).render('form', {
      errors,
      data: formData
    });
  }

  // Insert into database
  const stmt = db!.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    formData.first_name.trim(),
    formData.last_name.trim(),
    formData.street_address.trim(),
    formData.city.trim(),
    formData.state_province.trim(),
    formData.postal_code.trim(),
    formData.country.trim(),
    formData.email.trim(),
    formData.phone.trim()
  ]);

  stmt.free();
  saveDatabase();

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response, _next: unknown) => {
  console.error(err);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`\n${signal} received. Shutting down gracefully...`);
  
  if (db) {
    saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
initializeDatabase()
  .then(() => {
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Store server reference for testing
    (globalThis as typeof globalThis & { server?: any }).server = server;
  })
  .catch((error) => {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  });

export default app;