declare module 'sql.js' {
  export interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    close(): void;
    export(): Uint8Array;
  }

  export interface Statement {
    run(params: string[]): void;
    free(): void;
  }

  export interface SqlJsStatic {
    new (buffer?: Uint8Array): Database;
  }

  const initSqlJs: (config: { locateFile: (file: string) => string }) => Promise<SqlJsStatic>;
  export default initSqlJs;
}