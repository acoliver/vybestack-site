import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Parse and validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const parsedPage = Number(pageParam);
      if (!Number.isInteger(parsedPage) || parsedPage <= 0) {
        return res.status(400).json({ error: 'Invalid page parameter' });
      }
      page = parsedPage;
    }

    // Parse and validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const parsedLimit = Number(limitParam);
      if (!Number.isInteger(parsedLimit) || parsedLimit <= 0 || parsedLimit > 100) {
        return res.status(400).json({ error: 'Invalid limit parameter' });
      }
      limit = parsedLimit;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
