import express, { Request, Response } from 'express';
import { join } from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_PATH = join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = join(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;
let isServerStarted = false;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }

  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode.trim())) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens');
  }

  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }

  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(data.email.trim())) {
    errors.push('Email must be valid');
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone.trim())) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();

    const dataDir = join(process.cwd(), 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    if (fs.existsSync(DB_PATH)) {
      const dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  try {
    if (db) {
      const stmt = db.prepare(`
        INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim(),
      ]);

      stmt.free();
      saveDatabase();
    }

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', {
    firstName: 'Friend',
  });
});

let server: ReturnType<typeof app.listen> | null = null;

async function startServer(): Promise<void> {
  if (isServerStarted) {
    return;
  }

  await initializeDatabase();

  app.set('views', join(process.cwd(), 'src', 'templates'));
  app.set('view engine', 'ejs');

  app.use('/public', express.static(join(process.cwd(), 'public')));

  return new Promise<void>((resolve) => {
    server = app.listen(PORT, () => {
      console.log(`Server is listening on port ${PORT}`);
      isServerStarted = true;
      resolve();
    });
  });
}

async function stopServer(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }

  if (server) {
    return new Promise<void>((resolve) => {
      server!.close(() => {
        console.log('Server has been stopped');
        isServerStarted = false;
        resolve();
      });
    });
  }
}

process.on('SIGTERM', async () => {
  console.log('SIGTERM signal received: closing HTTP server');
  await stopServer();
  process.exit(0);
});

// Only auto-start if not imported by tests
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, startServer, stopServer };
