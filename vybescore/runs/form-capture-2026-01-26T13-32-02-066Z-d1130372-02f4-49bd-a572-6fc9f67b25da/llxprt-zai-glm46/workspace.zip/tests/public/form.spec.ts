import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

let stopServer: (() => Promise<void>) | null = null;
const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

beforeAll(async () => {
  const { startServer, stopServer: stop } = await import('../../dist/server.js');
  await startServer();
  stopServer = stop;
});

afterAll(async () => {
  if (stopServer) {
    await stopServer();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
