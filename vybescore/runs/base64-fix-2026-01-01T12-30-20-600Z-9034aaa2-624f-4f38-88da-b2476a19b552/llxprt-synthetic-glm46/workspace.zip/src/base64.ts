/**
 * Encoding constants
 */
const PADDING_CHAR = '=';

/**
 * Validate that a string is valid Base64
 */
function isValidBase64(input: string): boolean {
  // Check if input contains only valid Base64 characters
  const base64Pattern = /^[A-Za-z0-9+/]+={0,2}$/;
  if (!base64Pattern.test(input)) return false;
  
  // Check that padding occurs only at the end and最多2个
  const paddingIndex = input.indexOf(PADDING_CHAR);
  if (paddingIndex !== -1) {
    const padding = input.substring(paddingIndex);
    if (!/={1,2}$/.test(padding)) return false;
    
    // Check that padding length is correct for the string length
    const totalLength = input.replace(/=/g, '').length;
    if (totalLength % 4 === 1) return false; // Invalid padding length
  }
  
  return true;
}

/**
 * Encode plain text to standard Base64 with padding
 */
export function encode(input: string): string {
  try {
    return Buffer.from(input, 'utf8').toString('base64');
  } catch (error) {
    throw new Error('Failed to encode input to Base64');
  }
}

/**
 * Decode Base64 text back to plain UTF-8
 */
export function decode(input: string): string {
  // Validate Base64 input
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
