# Pagination Component Library

A comprehensive collection of pagination components built with React and TypeScript. This library includes three different pagination patterns suitable for various use cases.

## Components

1. **Numeric Pagination** - Classic page number navigation with ellipsis for large page ranges
2. **Load More Pagination** - Button-based pagination with optional auto-loading and item count display
3. **Prev/Next Pagination** - Simple previous/next navigation with page indicators

## Features

- Fully TypeScript with comprehensive type safety
- Accessibility compliant with ARIA labels
- Fully customizable styling and behavior
- Responsive design
- Extensive test coverage with React Testing Library
- Zero dependencies (no external UI libraries)
- Compatible with modern React versions

## Quick Start

```bash
npm install
npm test
npm run build
```

## Component Usage Examples

### Numeric Pagination

```tsx
import { NumericPagination } from './components/NumericPagination';

<NumericPagination
  currentPage={1}
  totalPages={10}
  onPageChange={(page) => setCurrentPage(page)}
  maxVisiblePages={7}
/>
```

### Load More Pagination

```tsx
import { LoadMorePagination } from './components/LoadMorePagination';

<LoadMorePagination
  currentPage={1}
  totalPages={10}
  onPageChange={(page) => setCurrentPage(page)}
  canLoadMore={true}
  autoLoad={false}
  itemCount={50}
  itemsPerPage={5}
/>
```

### Prev/Next Pagination

```tsx
import { PrevNextPagination } from './components/PrevNextPagination';

<PrevNextPagination
  currentPage={1}
  totalPages={10}
  onPageChange={(page) => setCurrentPage(page)}
/>
```

## Customization

All components support these optional props:

- `className` - Custom CSS class name
- `showFirstLast` (NumericPagination) - Show first/last page buttons
- `showPageNumbers` (PrevNextPagination) - Show page numbers
- `buttonLabels` - Custom labels for buttons
- `ariaLabels` - Custom ARIA labels
- `styles` - Custom styling functions

## Testing

The library includes comprehensive tests covering all components:

```bash
npm test
```

The test suite covers:
- Component rendering
- All user interactions
- Edge cases and boundary conditions
- Accessibility features
- Custom props and styling

## Development

```bash
# Install dependencies
npm install

# Run tests
npm test

# Build the project
npm run build

# Run the demo
npm run dev
```

## Browser Compatibility

- Chrome 80+
- Firefox 78+
- Safari 13+
- Edge 80+

## License

MIT