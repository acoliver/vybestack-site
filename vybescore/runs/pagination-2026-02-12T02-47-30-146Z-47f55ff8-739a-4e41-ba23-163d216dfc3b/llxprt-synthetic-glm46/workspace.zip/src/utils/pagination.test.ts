import { PaginateResult, PaginateOptions } from './pagination';
import { calculateTotalPages, createPagination } from './pagination';

describe('Pagination Utils', () => {
  describe('calculateTotalPages', () => {
    it('should return correct number of pages', () => {
      expect(calculateTotalPages(0, 10)).toBe(0);
      expect(calculateTotalPages(10, 10)).toBe(1);
      expect(calculateTotalPages(11, 10)).toBe(2);
      expect(calculateTotalPages(25, 10)).toBe(3);
    });

    it('should handle edge cases', () => {
      expect(calculateTotalPages(1, 1)).toBe(1);
      expect(calculateTotalPages(5, 2)).toBe(3);
      expect(calculateTotalPages(100, 25)).toBe(4);
    });

    it('should return 0 when totalItems is 0', () => {
      expect(calculateTotalPages(0, 5)).toBe(0);
      expect(calculateTotalPages(0, 10)).toBe(0);
    });
  });

  describe('createPagination', () => {
    it('should create pagination with default limit', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 1);
      
      expect(result.data).toHaveLength(10);
      expect(result.meta.total).toBe(25);
      expect(result.meta.page).toBe(1);
      expect(result.meta.limit).toBe(10);
      expect(result.meta.totalPages).toBe(3);
    });

    it('should create pagination with custom limit', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 1, 5);
      
      expect(result.data).toHaveLength(5);
      expect(result.meta.limit).toBe(5);
      expect(result.meta.totalPages).toBe(5);
    });

    it('should return correct page data', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 2, 10);
      
      expect(result.data).toHaveLength(10);
      expect(result.data[0]).toEqual({ id: 11 });
      expect(result.data[9]).toEqual({ id: 20 });
    });

    it('should handle last page with fewer items', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 3, 10);
      
      expect(result.data).toHaveLength(5);
      expect(result.data[0]).toEqual({ id: 21 });
      expect(result.data[4]).toEqual({ id: 25 });
    });

    it('should handle empty data array', () => {
      const result = createPagination([], 1, 10);
      
      expect(result.data).toHaveLength(0);
      expect(result.meta.total).toBe(0);
      expect(result.meta.totalPages).toBe(0);
    });

    it('should handle pages beyond range', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 5, 10);
      
      expect(result.data).toHaveLength(0);
      expect(result.meta.page).toBe(5);
    });

    it('should include pagination links', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 2, 10);
      
      expect(result.links.first).toBe('?page=1&limit=10');
      expect(result.links.prev).toBe('?page=1&limit=10');
      expect(result.links.next).toBe('?page=3&limit=10');
      expect(result.links.last).toBe('?page=3&limit=10');
    });

    it('should not include prev link on first page', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 1, 10);
      
      expect(result.links.prev).toBe('');
    });

    it('should not include next link on last page', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const result = createPagination(mockData, 3, 10);
      
      expect(result.links.next).toBe('');
    });

    it('should accept options parameter', () => {
      const mockData = Array.from({ length: 25 }, (_, i) => ({ id: i + 1 }));
      const options: PaginateOptions = {
        route: '/api/products',
        queryParams: { category: 'electronics' }
      };
      const result = createPagination(mockData, 2, 10, options);
      
      expect(result.data).toHaveLength(10);
      expect(result.links.first).toBe('/api/products?page=1&limit=10&category=electronics');
      expect(result.links.prev).toBe('/api/products?page=1&limit=10&category=electronics');
      expect(result.links.next).toBe('/api/products?page=3&limit=10&category=electronics');
      expect(result.links.last).toBe('/api/products?page=3&limit=10&category=electronics');
    });
  });
});