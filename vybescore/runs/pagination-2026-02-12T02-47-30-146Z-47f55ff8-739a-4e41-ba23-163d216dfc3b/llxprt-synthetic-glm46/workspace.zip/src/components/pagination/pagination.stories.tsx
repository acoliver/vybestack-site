import type { Meta, StoryObj } from "@storybook/react";
import { fn } from "@storybook/test";
import { Pagination } from "~/components/pagination";

const meta = {
  title: "Components/Pagination",
  component: Pagination,
  parameters: {
    layout: "centered",
  },
  tags: ["autodocs"],
  argTypes: {
    currentPage: {
      control: { type: "number", min: 1 },
      description: "Current active page",
    },
    totalPages: {
      control: { type: "number", min: 1 },
      description: "Total number of pages",
    },
    onPageChange: {
      action: "page changed",
      description: "Callback when page changes",
    },
    className: {
      control: { type: "text" },
      description: "Additional CSS classes",
    },
    size: {
      control: "select",
      options: ["sm", "md", "lg"],
      description: "Size of the pagination component",
    },
    showFirstLast: {
      control: { type: "boolean" },
      description: "Whether to show first/last page buttons",
    },
    showPrevNext: {
      control: { type: "boolean" },
      description: "Whether to show previous/next buttons",
    },
    maxVisiblePages: {
      control: { type: "number", min: 1 },
      description: "Maximum number of visible page numbers",
    },
    disabled: {
      control: { type: "boolean" },
      description: "Whether the pagination is disabled",
    },
    ariaLabel: {
      control: "text",
      description: "ARIA label for the pagination component",
    },
  },
  args: {
    currentPage: 1,
    totalPages: 10,
    onPageChange: fn(),
  },
} satisfies Meta<typeof Pagination>;

export default meta;
type Story = StoryObj<typeof meta>;

// Default story
export const Default: Story = {
  args: {
    currentPage: 1,
    totalPages: 10,
  },
};

// With many pages
export const ManyPages: Story = {
  args: {
    currentPage: 5,
    totalPages: 50,
    maxVisiblePages: 7,
  },
};

// Small size
export const Small: Story = {
  args: {
    currentPage: 3,
    totalPages: 10,
    size: "sm",
  },
};

// Large size
export const Large: Story = {
  args: {
    currentPage: 3,
    totalPages: 10,
    size: "lg",
  },
};

// Without first/last buttons
export const NoFirstLast: Story = {
  args: {
    currentPage: 3,
    totalPages: 10,
    showFirstLast: false,
  },
};

// Without prev/next buttons
export const NoPrevNext: Story = {
  args: {
    currentPage: 3,
    totalPages: 10,
    showPrevNext: false,
  },
};

// Disabled state
export const Disabled: Story = {
  args: {
    currentPage: 3,
    totalPages: 10,
    disabled: true,
  },
};

// On first page
export const FirstPage: Story = {
  args: {
    currentPage: 1,
    totalPages: 10,
  },
};

// On last page
export const LastPage: Story = {
  args: {
    currentPage: 10,
    totalPages: 10,
  },
};

// Custom styling
export const CustomStyling: Story = {
  args: {
    currentPage: 3,
    totalPages: 10,
    className: "border-2 border-blue-500 rounded-lg",
  },
};

// With custom ARIA labels
export const CustomAria: Story = {
  args: {
    currentPage: 3,
    totalPages: 10,
    ariaLabel: "Product navigation",
  },
};