import { button } from "$lib/components/button";
import { cn } from "$lib/utils/cn";

export { Pagination };

type PaginationProps = {
  currentPage: number;
  totalPages: number;
  siblingCount?: number;
  showFirstLast?: boolean;
  truncateThreshold?: number;
  onPageChange?: (page: number) => void;
  size?: "sm" | "md" | "lg";
  variant?: "default" | "outline" | "ghost";
  className?: string;
  disabled?: boolean;
  "aria-label"?: string;
};

export function Pagination(props: PaginationProps) {
  const {
    currentPage,
    totalPages,
    siblingCount = 1,
    showFirstLast = true,
    truncateThreshold = 3,
    onPageChange,
    size = "md",
    variant = "default",
    className,
    disabled,
    "aria-label": ariaLabel,
  } = props;

  const pagination = usePagination({
    currentPage,
    totalCount: totalPages,
    siblingCount,
    showFirstLast,
    truncateThreshold,
  });

  const onPrevious = () => {
    if (currentPage > 1 && !disabled) {
      onPageChange?.(currentPage - 1);
    }
  };

  const onNext = () => {
    if (currentPage < totalPages && !disabled) {
      onPageChange?.(currentPage + 1);
    }
  };

  const onPage = (page: number) => {
    if (page !== currentPage && !disabled) {
      onPageChange?.(page);
    }
  };

  return (
    <nav
      aria-label={ariaLabel || "Pagination navigation"}
      class={cn("flex items-center gap-1", className)}
    >
      {showFirstLast && (
        <Button
          variant={variant}
          size={size}
          onClick={() => onPage(1)}
          disabled={disabled || currentPage === 1}
          aria-label="First page"
        >
          First
        </Button>
      )}

      <Button
        variant={variant}
        size={size}
        onClick={onPrevious}
        disabled={disabled || currentPage === 1}
        aria-label="Previous page"
      >
        Previous
      </Button>

      <div class="flex items-center gap-1">
        {pagination.map((page, index) => {
          if (page === "DOTS") {
            return (
              <span class="px-3" aria-hidden key={`dots-${index}`}>
                ...
              </span>
            );
          }

          return (
            <Button
              variant={page === currentPage ? "default" : variant}
              size={size}
              onClick={() => onPage(page as number)}
              disabled={disabled}
              aria-current={page === currentPage ? "page" : undefined}
              aria-label={`Page ${page}`}
              key={page}
            >
              {page}
            </Button>
          );
        })}
      </div>

      <Button
        variant={variant}
        size={size}
        onClick={onNext}
        disabled={disabled || currentPage === totalPages}
        aria-label="Next page"
      >
        Next
      </Button>

      {showFirstLast && (
        <Button
          variant={variant}
          size={size}
          onClick={() => onPage(totalPages)}
          disabled={disabled || currentPage === totalPages}
          aria-label="Last page"
        >
          Last
        </Button>
      )}
    </nav>
  );
}

function usePagination(params: {
  currentPage: number;
  totalCount: number;
  siblingCount: number;
  showFirstLast: boolean;
  truncateThreshold: number;
}): (number | "DOTS")[] {
  const { currentPage, totalCount, siblingCount, truncateThreshold } = params;

  const range = (start: number, end: number): number[] => {
    const length = end - start + 1;
    return Array.from({ length }, (_, idx) => idx + start);
  };

  const paginationRange = (): (number | "DOTS")[] => {
    const totalPageNumbers = siblingCount + 5; // first + last + current + siblingCount

    if (totalPageNumbers >= totalCount) {
      return range(1, totalCount);
    }

    const leftSiblingIndex = Math.max(currentPage - siblingCount, 1);
    const rightSiblingIndex = Math.min(
      currentPage + siblingCount,
      totalCount
    );

    const shouldShowLeftDots = leftSiblingIndex > 2;
    const shouldShowRightDots = rightSiblingIndex < totalCount - 2;

    if (!shouldShowLeftDots && shouldShowRightDots) {
      const leftItemCount = 3 + 2 * siblingCount;
      const leftRange = range(1, leftItemCount);
      return [...leftRange, "DOTS", totalCount];
    }

    if (shouldShowLeftDots && !shouldShowRightDots) {
      const rightItemCount = 3 + 2 * siblingCount;
      const rightRange = range(totalCount - rightItemCount + 1, totalCount);
      return [1, "DOTS", ...rightRange];
    }

    if (shouldShowLeftDots && shouldShowRightDots) {
      const middleRange = range(leftSiblingIndex, rightSiblingIndex);
      return [1, "DOTS", ...middleRange, "DOTS", totalCount];
    }

    return range(1, totalCount);
  };

  return paginationRange();
}

function Button(props: {
  children: any;
  variant?: "default" | "outline" | "ghost";
  size?: "sm" | "md" | "lg";
  disabled?: boolean;
  onClick?: () => void;
  "aria-label"?: string;
  "aria-current"?: "page";
  class?: string;
}) {
  const {
    variant = "default",
    size = "md",
    disabled = false,
    onClick,
    class: className,
    children,
    ...rest
  } = props;

  const sizeClasses = {
    sm: "h-8 w-8 text-sm",
    md: "h-10 w-10 text-sm",
    lg: "h-12 w-12 text-base",
  };

  const variantClasses = {
    default: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
    outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
    ghost: "hover:bg-accent hover:text-accent-foreground",
  };

  return (
    <button
      class={cn(
        "inline-flex items-center justify-center whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50",
        sizeClasses[size],
        variantClasses[variant],
        disabled && "opacity-50 cursor-not-allowed",
        className
      )}
      disabled={disabled}
      onClick={onClick}
      {...rest}
    >
      {children}
    </button>
  );
}