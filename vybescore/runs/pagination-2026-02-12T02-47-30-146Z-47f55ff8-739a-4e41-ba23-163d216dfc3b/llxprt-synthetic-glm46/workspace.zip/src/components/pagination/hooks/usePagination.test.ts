import { renderHook } from '@testing-library/react';
import { describe, it, expect } from 'vitest';
import { usePagination } from './usePagination';

describe('usePagination hook', () => {
  it('should return correct range when current page is in middle', () => {
    const { result } = renderHook(() => 
      usePagination(10, 5, 7)
    );
    expect(result.current.range).toEqual([3, 4, 5, 6, 7]);
    expect(result.current.canGoBack).toBe(true);
    expect(result.current.canGoNext).toBe(true);
    expect(result.current.showLeftEllipsis).toBe(true);
    expect(result.current.showRightEllipsis).toBe(true);
  });

  it('should return range at the beginning when page is near the start', () => {
    const { result } = renderHook(() => 
      usePagination(10, 2, 7)
    );
    expect(result.current.range).toEqual([1, 2, 3, 4, 5, 6, 7]);
    expect(result.current.canGoBack).toBe(true);
    expect(result.current.canGoNext).toBe(true);
    expect(result.current.showLeftEllipsis).toBe(false);
    expect(result.current.showRightEllipsis).toBe(true);
  });

  it('should return range at the end when page is near the last page', () => {
    const { result } = renderHook(() => 
      usePagination(10, 9, 7)
    );
    expect(result.current.range).toEqual([4, 5, 6, 7, 8, 9, 10]);
    expect(result.current.canGoBack).toBe(true);
    expect(result.current.canGoNext).toBe(true);
    expect(result.current.showLeftEllipsis).toBe(true);
    expect(result.current.showRightEllipsis).toBe(false);
  });

  it('should handle single page', () => {
    const { result } = renderHook(() => 
      usePagination(1, 1, 5)
    );
    expect(result.current.range).toEqual([1]);
    expect(result.current.canGoBack).toBe(false);
    expect(result.current.canGoNext).toBe(false);
    expect(result.current.showLeftEllipsis).toBe(false);
    expect(result.current.showRightEllipsis).toBe(false);
  });

  it('should handle small page ranges without ellipsis', () => {
    const { result } = renderHook(() => 
      usePagination(5, 3, 7)
    );
    expect(result.current.range).toEqual([1, 2, 3, 4, 5]);
    expect(result.current.canGoBack).toBe(true);
    expect(result.current.canGoNext).toBe(true);
    expect(result.current.showLeftEllipsis).toBe(false);
    expect(result.current.showRightEllipsis).toBe(false);
  });

  it('should handle current page being first', () => {
    const { result } = renderHook(() => 
      usePagination(10, 1, 7)
    );
    expect(result.current.range).toEqual([1, 2, 3, 4, 5, 6, 7]);
    expect(result.current.canGoBack).toBe(false);
    expect(result.current.canGoNext).toBe(true);
  });

  it('should handle current page being last', () => {
    const { result } = renderHook(() => 
      usePagination(10, 10, 7)
    );
    expect(result.current.range).toEqual([4, 5, 6, 7, 8, 9, 10]);
    expect(result.current.canGoBack).toBe(true);
    expect(result.current.canGoNext).toBe(false);
  });
});