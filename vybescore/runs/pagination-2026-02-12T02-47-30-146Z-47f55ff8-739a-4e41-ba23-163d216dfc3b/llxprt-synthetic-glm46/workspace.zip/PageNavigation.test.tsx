import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import { vi } from 'vitest';
import { fetchPageData } from '@/services/api';
import PageNavigation from './PageNavigation';

// Mock the API service
vi.mock('@/services/api', () => ({
  fetchPageData: vi.fn(),
}));

// Mock window.location
Object.defineProperty(window, 'location', {
  value: {
    pathname: '/test-page',
    search: '',
  },
  writable: true,
});

// Test data
const mockPreviousPage = { id: 'prev', title: 'Previous Page', path: '/previous' };
const mockNextPage = { id: 'next', title: 'Next Page', path: '/next' };
const mockContent = '<h1>Page Content</h1>';

describe('PageNavigation Component', () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  describe('Basic rendering', () => {
    test('renders correctly with default state', () => {
      render(<PageNavigation />);
      expect(screen.getByText('Page not found')).toBeInTheDocument();
    });

    test('renders loading state', () => {
      render(<PageNavigation isLoading={true} />);
      expect(screen.getByText('Loading...')).toBeInTheDocument();
    });

    test('renders error state', () => {
      const errorMessage = 'Test error message';
      render(<PageNavigation error={errorMessage} />);
      expect(screen.getByText(errorMessage)).toBeInTheDocument();
    });
  });

  describe('Content display', () => {
    test('displays HTML content correctly', async () => {
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: mockContent } } },
        previousPage: { data: mockPreviousPage },
        nextPage: { data: mockNextPage },
      });

      render(<PageNavigation />);
      
      await waitFor(() => {
        expect(screen.getByRole('heading', { name: /page content/i })).toBeInTheDocument();
      });
    });

    test('displays plain text content', async () => {
      const textContent = 'This is plain text content';
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: textContent } } },
        previousPage: { data: mockPreviousPage },
        nextPage: { data: mockNextPage },
      });

      render(<PageNavigation />);
      
      await.waitFor(() => {
        expect(screen.getByText(textContent)).toBeInTheDocument();
      });
    });
  });

  describe('Navigation functionality', () => {
    test('displays previous and next page navigation', async () => {
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: mockContent } } },
        previousPage: { data: mockPreviousPage },
        nextPage: { data: mockNextPage },
      });

      render(<PageNavigation />);
      
      await waitFor(() => {
        expect(screen.getByText('Previous Page')).toBeInTheDocument();
        expect(screen.getByText('Next Page')).toBeInTheDocument();
      });
    });

    test('does not display navigation when no previous/next page available', async () => {
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: mockContent } } },
        previousPage: { data: null },
        nextPage: { data: null },
      });

      render(<PageNavigation />);
      
      await waitFor(() => {
        expect(screen.queryByText('Previous')).not.toBeInTheDocument();
        expect(screen.queryByText('Next')).not.toBeInTheDocument();
      });
    });

    test('navigates to previous page when previous link is clicked', async () => {
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: mockContent } } },
        previousPage: { data: mockPreviousPage },
        nextPage: { data: mockNextPage },
      });

      const mockNavigate = vi.fn();
      
      render(<PageNavigation onNavigate={mockNavigate} />);
      
      await waitFor(() => {
        expect(screen.getByText('Previous Page')).toBeInTheDocument();
      });
      
      fireEvent.click(screen.getByText('Previous Page'));
      expect(mockNavigate).toHaveBeenCalledWith('/previous');
    });

    test('navigates to next page when next link is clicked', async () => {
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: mockContent } } },
        previousPage: { data: mockPreviousPage },
        nextPage: { data: mockNextPage },
      });

      const mockNavigate = vi.fn();
      
      render(<PageNavigation onNavigate={mockNavigate} />);
      
      await waitFor(() => {
        expect(screen.getByText('Next Page')).toBeInTheDocument();
      });
      
      fireEvent.click(screen.getByText('Next Page'));
      expect(mockNavigate).toHaveBeenCalledWith('/next');
    });
  });

  describe('Keyboard navigation', () => {
    test('navigates correctly with keyboard shortcuts', async () => {
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: mockContent } } },
        previousPage: { data: mockPreviousPage },
        nextPage: { data: mockNextPage },
      });

      const mockNavigate = vi.fn();
      
      render(<PageNavigation onNavigate={mockNavigate} />);
      
      await waitFor(() => {
        expect(screen.getByText('Previous Page')).toBeInTheDocument();
      });
      
      // Simulate keyboard navigation for previous page
      fireEvent.keyDown(document, { key: 'ArrowUp' });
      expect(mockNavigate).toHaveBeenCalledWith('/previous');
      
      mockNavigate.mockClear();
      
      // Simulate keyboard navigation for next page
      fireEvent.keyDown(document, { key: 'ArrowDown' });
      expect(mockNavigate).toHaveBeenCalledWith('/next');
    });
  });

  describe('Responsive behavior', () => {
    test('displays truncated titles in mobile view', async () => {
      const longTitle = 'This is a very long title that should be truncated on mobile devices to ensure proper layout';
      (fetchPageData as any).mockResolvedValueOnce({
        content: { data: { attributes: { content: mockContent } } },
        previousPage: { data: { ...mockPreviousPage, title: longTitle } },
        nextPage: { data: mockNextPage },
      });

      // Mock window.innerWidth to simulate mobile view
      Object.defineProperty(window, 'innerWidth', {
        writable: true,
        configurable: true,
        value: 500,
      });
      
      render(<PageNavigation />);
      
      await waitFor(() => {
        const prevButton = screen.getByText(/This is a very long title/);
        expect(prevButton).toBeInTheDocument();
        // In a real implementation, we would check if text is truncated
      });
    });
  });
});