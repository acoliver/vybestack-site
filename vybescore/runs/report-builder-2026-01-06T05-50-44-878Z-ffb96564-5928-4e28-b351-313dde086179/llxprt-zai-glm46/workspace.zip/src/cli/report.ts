#!/usr/bin/env node

import * as fs from 'node:fs';
import { getFormatter, type Format } from '../formatters.js';
import { validateReportData } from '../validator.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];

  let format: Format = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatValue = args[i + 1];
      if (!formatValue) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }

      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }

      format = formatValue as Format;
      i++;
    } else if (arg === '--output') {
      const outputValue = args[i + 1];
      if (!outputValue) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }

      outputPath = outputValue;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  return { inputFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv);

    // Read and parse JSON file
    let jsonString: string;
    try {
      jsonString = fs.readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      const nodeError = error as NodeJS.ErrnoException;
      if (nodeError.code === 'ENOENT') {
        console.error(`Error: file not found: ${args.inputFile}`);
      } else {
        console.error(`Error: failed to read file: ${args.inputFile}`);
      }
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(jsonString);
    } catch (error) {
      console.error(`Error: invalid JSON in file: ${args.inputFile}`);
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(jsonData);

    // Get formatter and render
    const formatter = getFormatter(args.format);
    const output = formatter.render(reportData, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const errorMessage = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${errorMessage}`);
    process.exit(1);
  }
}

main();
