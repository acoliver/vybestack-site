import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { Server } from 'http';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database file path
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Initialize the database
let db: Database;
let server: Server;

async function initializeDatabase() {
  const SQL = await initSqlJs({
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
  });
  
  let dbData: Uint8Array | null = null;
  if (fs.existsSync(dbPath)) {
    dbData = fs.readFileSync(dbPath);
  }
  
  db = new SQL.Database(dbData);
  
  // Create submissions table if it doesn't exist
  const createTableSQL = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
  db.run(createTableSQL);
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\\d\\s\\-\\(\\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[A-Za-z0-9\\s\\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone,
  } = req.body;
  
  const errors: string[] = [];
  
  // Validation
  if (!firstName) errors.push('First name is required.');
  else if (firstName.trim().length === 0) errors.push('First name cannot be empty.');
  
  if (!lastName) errors.push('Last name is required.');
  else if (lastName.trim().length === 0) errors.push('Last name cannot be empty.');
  
  if (!streetAddress) errors.push('Street address is required.');
  else if (streetAddress.trim().length === 0) errors.push('Street address cannot be empty.');
  
  if (!city) errors.push('City is required.');
  else if (city.trim().length === 0) errors.push('City cannot be empty.');
  
  if (!stateProvince) errors.push('State/Province is required.');
  else if (stateProvince.trim().length === 0) errors.push('State/Province cannot be empty.');
  
  if (!postalCode) errors.push('Postal code is required.');
  else if (!validatePostalCode(postalCode)) errors.push('Invalid postal code format.');
  
  if (!country) errors.push('Country is required.');
  
  if (!email) errors.push('Email is required.');
  else if (!validateEmail(email)) errors.push('Invalid email format.');
  
  if (!phone) errors.push('Phone number is required.');
  else if (!validatePhone(phone)) errors.push('Invalid phone number format.');
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: req.body,
    });
  }
  
  // Insert into database
  const stmt = db.prepare(
    'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
  );
  stmt.run([
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone,
  ]);
  stmt.free();
  
  // Write database back to disk
  const data = db.export();
  const dirPath = path.dirname(dbPath);
  if (!fs.existsSync(dirPath)) {
    fs.mkdirSync(dirPath, { recursive: true });
  }
  fs.writeFileSync(dbPath, data);
  
  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req as any).session?.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully...');
  if (server) {
    server.close(() => {
      console.log('Express server closed.');
    });
  }
  
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, data);
    db.close();
    console.log('SQLite database closed.');
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start the server
async function startServer() {
  await initializeDatabase();
  server = app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
  });
  
  // For testing purposes, we don't want to exit when port is in use
  server.on('error', (err: any) => {
    if (err.code === 'EADDRINUSE') {
      console.log(`Port ${port} is already in use. Server might be running in another process.`);
      // Only exit if we're not in test environment
      if (process.env.NODE_ENV !== 'test') {
        process.exit(1);
      }
    } else {
      console.error('Server error:', err);
    }
  });
  
  return server;
}

// Export for testing
export { app, startServer };

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Error starting server:', err);
    process.exit(1);
  });
}

export default app;