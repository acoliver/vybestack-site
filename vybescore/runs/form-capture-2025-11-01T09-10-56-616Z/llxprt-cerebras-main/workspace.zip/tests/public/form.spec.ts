import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';
import express from 'express';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let server: any;
let app: express.Application;
const dbPath = path.resolve(__dirname, '..', '..', 'data', 'submissions.sqlite');

beforeAll(async () => {
  // Set test environment
  process.env.NODE_ENV = 'test';
  
  // Import the server and start it
  const serverModule = await import('../../src/server');
  app = serverModule.app;
  server = await serverModule.startServer();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up the database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check that all required form fields are present
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Make sure database file doesn't exist before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Submit form data
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1 555 123 4567'
      });
    
    // Check that we get a redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.header.location).toBe('/thank-you');
    
    // Check that data was persisted to database
    const dbExists = fs.existsSync(dbPath);
    expect(dbExists).toBe(true);
  });
  
  it('shows validation errors for invalid email', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'invalid-email',
        phone: '+1 555 123 4567'
      });
    
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    expect($('.error-list').text()).toContain('Invalid email format');
  });
  
  it('accepts international postal codes and phone numbers', async () => {
    // Submit form data with international formats
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'Maria',
        lastName: 'Garcia',
        streetAddress: 'Calle Falsa 123',
        city: 'Buenos Aires',
        stateProvince: 'Buenos Aires',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria.garcia@example.com',
        phone: '+54 9 11 1234-5678'
      });
    
    // Check that we get a redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.header.location).toBe('/thank-you');
    
    // Submit another form with different international formats
    const response2 = await request(server)
      .post('/submit')
      .send({
        firstName: 'James',
        lastName: 'Smith',
        streetAddress: '10 Downing Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'james.smith@example.com',
        phone: '+44 20 7946 0958'
      });
    
    // Check that we get a redirect to thank-you page
    expect(response2.status).toBe(302);
    expect(response2.header.location).toBe('/thank-you');
  });
  
  it('shows thank-you page with humor and first name', async () => {
    const response = await request(server).get('/thank-you');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('h1').text()).toContain('Thank you'); // Will have firstName once we pass it in submit
    expect($('p').text()).toContain('somewhere safe(ish)');
    expect($('p').text()).toContain('stranger on the internet');
  });
});