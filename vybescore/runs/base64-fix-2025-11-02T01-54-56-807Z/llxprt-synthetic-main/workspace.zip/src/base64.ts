/**
 * Encode plain text to Base64 using canonical RFC 4648 Base64.
 * Uses the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using canonical RFC 4648 Base64.
 * Accepts standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Check for valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for correct structure:
  // 1. Padding can only appear at the end
  // 2. If there's one ' ', it must be followed by a second '=' or be the last character
  // 3. If there are two '=', they must be at the very end
  // 4. Total string length must be a multiple of 4
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // All remaining characters after the first padding must all be '='
    if (!input.slice(paddingIndex).match(/^={1,2}$/)) {
      throw new Error('Invalid Base64 input: incorrect padding placement');
    }
    
    // Check if padding length is correct (1 or 2)
    const paddingLength = input.length - paddingIndex;
    if (paddingLength < 1 || paddingLength > 2) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
  }
  
  // Total length must be a multiple of 4
  if (input.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: length not a multiple of 4');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    // Additional check: if the string contains only '=', it should fail
    if (input.match(/^={1,2}$/)) {
      throw new Error('Invalid Base64 input: contains only padding');
    }
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
