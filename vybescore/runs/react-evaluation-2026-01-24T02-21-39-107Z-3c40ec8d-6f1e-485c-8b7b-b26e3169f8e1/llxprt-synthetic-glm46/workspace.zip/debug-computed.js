#!/usr/bin/env node

// Debug script to understand computed behavior
console.log('Testing computed behavior step by step...')

const createComputed = (updateFn, value, _equal, options) => {
  const observer = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set()
  }
  
  // Initialize the computed value
  console.log('Initial value:', value)
  if (value === undefined) {
    console.log('Running updateFn with undefined to initialize...')
    const initialValue = observer.updateFn(undefined)
    console.log('Got initial value:', initialValue)
    if (initialValue !== undefined) {
      observer.value = initialValue
    }
    console.log('Observer value after init:', observer.value)
  }
  
  let callCount = 0
  const getter = () => {
    callCount++
    console.log(`Getter called ${callCount} times, current value:`, observer.value)
    return observer.value
  }
  
  return getter
}

// Test case
const updateFn = (x = 3) => {
  console.log('updateFn called with:', x)
  const result = x * 2
  console.log('updateFn result:', result)
  return result
}

console.log('Creating computed without initial value...')
const computed = createComputed(updateFn)
console.log('First call to computed():')
const result = computed()
console.log('Final result:', result)
console.log('Expected: 6')
console.log('Test passes:', result === 6)