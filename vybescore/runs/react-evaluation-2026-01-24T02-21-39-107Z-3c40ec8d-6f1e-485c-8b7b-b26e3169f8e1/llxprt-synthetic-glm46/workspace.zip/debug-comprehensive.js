#!/usr/bin/env node

// Debug script to understand computed update behavior
console.log('Testing computed update behavior...')

// Create simple reactive system
let activeObserver = undefined

const getActiveObserver = () => activeObserver

const updateObserver = (observer) => {
  const previous = activeObserver
  activeObserver = observer
  try {
    console.log('updateObserver: calling updateFn with value:', observer.value)
    const result = observer.updateFn(observer.value)
    console.log('updateObserver: updateFn returned:', result)
    if (result !== undefined) {
      observer.value = result
      console.log('updateObserver: observer.value updated to:', observer.value)
    }
  } finally {
    activeObserver = previous
  }
}

const createComputed = (updateFn, value, _equal, options) => {
  const observer = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Initialize the computed value
  console.log('Initializing computed with value:', value)
  if (observer.value === undefined) {
    console.log('Running updateFn with undefined to initialize...')
    const initialValue = observer.updateFn(undefined)
    console.log('Got initial value:', initialValue)
    if (initialValue !== undefined) {
      observer.value = initialValue
    }
    console.log('Observer value after init:', observer.value)
  }
  
  const getter = () => {
    const prevObserver = getActiveObserver()
    if (prevObserver) {
      console.log('Computed getter: tracking dependency from observer', prevObserver.name || 'unnamed')
      observer.dependencies.clear()
      observer.dependencies.add(prevObserver)
    }
    
    console.log('Computed getter: returning cached value:', observer.value)
    return observer.value
  }
  
  return getter
}

const createInput = (value) => {
  const subject = {
    name: 'input',
    observers: new Set(),
    value,
  }
  
  const read = () => {
    const observer = getActiveObserver()
    if (observer) {
      console.log('Input read: adding observer', observer.name || 'unnamed', 'to dependencies')
      subject.observers.add(observer)
    }
    return subject.value
  }
  
  const write = (nextValue) => {
    console.log('Input write: updating value from', subject.value, 'to', nextValue)
    const prevValue = subject.value
    subject.value = nextValue
    
    if (prevValue !== nextValue) {
      console.log('Input write: notifying', subject.observers.size, 'observers')
      for (const observer of subject.observers) {
        console.log('Input write: notifying observer', observer.name || 'unnamed')
        updateObserver(observer)
      }
    }
    
    return subject.value
  }
  
  return [read, write]
}

// Test the comprehensive case
console.log('=== Testing compute cells can depend on other compute cells ===')

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('timesTwo recomputing: input() =', input(), '* 2')
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('timesThirty recomputing: input() =', input(), '* 30')
  return input() * 30
})
const sum = createComputed(() => {
  console.log('sum recomputing: timesTwo() =', timesTwo(), '+ timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('\n=== Initial values ===')
console.log('input = 1')
console.log('Expected: sum = 32 (1*2 + 1*30)')
const initialSum = sum()
console.log('Actual sum =', initialSum)

console.log('\n=== Changing input to 3 ===')
setInput(3)
console.log('Expected: sum = 96 (3*2 + 3*30)')
const newSum = sum()
console.log('Actual sum =', newSum)

console.log('\n=== Analysis ===')
console.log('The issue: computed values are not being automatically updated when dependencies change')
console.log('When setInput(3) is called, it should notify observers, which should trigger recomputation')