#!/usr/bin/env node

// Test the actual implementation
console.log('Testing actual implementation with reactive tracking...')

// Import the actual compiled functions
const fs = require('fs')
const path = require('path')

// Helper to execute TypeScript code in JavaScript environment
const ts = require('typescript')

// Compile and execute TypeScript in memory
function runTypeScript(filePath) {
  const content = fs.readFileSync(path.join(__dirname, filePath), 'utf8')
  
  // Transpile TypeScript to JavaScript
  const jsCode = ts.transpile(content, {
    target: ts.ScriptTarget.ES2020,
    module: ts.ModuleKind.ESNext,
    esModuleInterop: true,
    allowSyntheticDefaultImports: true
  })
  
  return eval(`(() => { ${jsCode} })()`)
}

const reactiveModule = runTypeScript('src/types/reactive.ts')
const inputModule = runTypeScript('src/core/input.ts')
const computedModule = runTypeScript('src/core/computed.ts')
const callbackModule = runTypeScript('src/core/callback.ts')

console.log('=== Testing compute cells can depend on other compute cells ===')

const [input, setInput] = inputModule.createInput(1)
const timesTwo = computedModule.createComputed(() => {
  console.log('timesTwo recomputing: input() =', input(), '* 2')
  return input() * 2
}, undefined, undefined, { name: 'timesTwo' })

const timesThirty = computedModule.createComputed(() => {
  console.log('timesThirty recomputing: input() =', input(), '* 30')
  return input() * 30
}, undefined, undefined, { name: 'timesThirty' })

const sum = computedModule.createComputed(() => {
  console.log('sum recomputing: timesTwo() =', timesTwo(), '+ timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
}, undefined, undefined, { name: 'sum' })

console.log('\n=== Initial values ===')
console.log('input = 1')
console.log('expected: sum = 32 (1*2 + 1*30)')
const initialSum = sum()
console.log('actual sum =', initialSum)

console.log('\n=== Changing input to 3 ===')
setInput(3)
console.log('expected: sum = 96 (3*2 + 3*30)')
const newSum = sum()
console.log('actual sum =', newSum)