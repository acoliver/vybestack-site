#!/usr/bin/env node

// Simple test script
console.log('Testing computed with initial value...')

const createComputed = (updateFn, value, _equal, options) => {
  const observer = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set()
  }
  
  const getter = () => {
    // Just return the cached value
    return observer.value
  }
  
  // Initialize computed value
  if (value === undefined) {
    // Update with initial default value by passing undefined
    const initialValue = observer.updateFn(undefined)
    if (initialValue !== undefined) {
      observer.value = initialValue
    }
  }
  
  return getter
}

let activeObserver = undefined

const getActiveObserver = () => activeObserver

const updateObserver = (observer) => {
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value)
    if (result !== undefined) {
      observer.value = result
    }
  } finally {
    activeObserver = previous
  }
}

// Test case
console.log('Testing updateFn behavior...')

const updateFn = (x = 3) => {
  console.log('updateFn called with:', x)
  const result = x * 2
  console.log('updateFn result:', result)
  return result
}

const computed = createComputed(updateFn)
const result = computed()

console.log('Final result:', result)
console.log('Expected: 6')
console.log('Test passes:', result === 6)