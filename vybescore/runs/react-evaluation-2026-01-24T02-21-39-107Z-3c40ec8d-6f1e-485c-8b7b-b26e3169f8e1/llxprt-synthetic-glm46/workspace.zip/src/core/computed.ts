/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  const getter = (): T => {
    const prevObserver = getActiveObserver()
    if (prevObserver) {
      // Clear previous dependencies
      o.dependencies!.clear()
      o.dependencies!.add(prevObserver)
      
      // Register this observer as an observer on all dependent subjects
      // We need to recompute to track dependencies
      updateObserver(o)
    }
    
    return o.value!
  }
  
  
  
  // Initialize the computed value by running updateFn if no value provided
  if (value === undefined) {
    // Run updateFn with undefined to get initial value
    // The computed observer becomes the active observer while initializing
    const initialValue = o.updateFn(undefined)
    if (initialValue !== undefined) {
      o.value = initialValue
    }
  }
  
  return getter
}
