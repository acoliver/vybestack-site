#!/usr/bin/env node

// Simple test to check reactive behavior
console.log('Testing reactive behavior manually...')

// Simple reactive system without circular dependency issues
const reactive = {
  activeObserver: null,
}

const getActiveObserver = () => reactive.activeObserver

const createInput = (value) => {
  const subject = {
    name: 'input',
    observers: new Set(),
    value,
  }
  
  const read = () => {
    const observer = getActiveObserver()
    if (observer) {
      console.log('Input read: tracking dependency')
      subject.observers.add(observer)
    }
    return subject.value
  }
  
  const write = (nextValue) => {
    console.log('Input write: updating from', subject.value, 'to', nextValue)
    subject.value = nextValue
    
    // Directly notify all observers
    console.log('Input write: notifying', subject.observers.size, 'observers')
    for (const observer of subject.observers) {
      console.log('Input write: updating observer', observer.name || 'unnamed')
      observer.update()
    }
    
    // Recursively notify dependent observers of the changed observers
    const notifiedObservers = new Set(subject.observers)
    let moreToUpdate = true
    
    while (moreToUpdate) {
      moreToUpdate = false
      const currentNotified = new Set(notifiedObservers)
      
      for (const changedObserver of currentNotified) {
        for (const dependentObserver of changedObserver.dependents || []) {
          if (!notifiedObservers.has(dependentObserver)) {
            console.log('Input write: cascading update to', dependentObserver.name || 'unnamed')
            dependentObserver.update()
            notifiedObservers.add(dependentObserver)
            moreToUpdate = true
          }
        }
      }
    }
    return subject.value
  }
  
  return [read, write]
}

const createComputed = (updateFn, options) => {
  const observer = {
    name: options?.name,
    value: undefined,
    updateFn,
    dependents: new Set(),
    update() {
      console.log('Computed update: recomputing', this.name)
      reactive.activeObserver = this
      try {
        const result = this.updateFn(this.value)
        if (result !== undefined) {
          this.value = result
        }
        console.log('Computed update: new value for', this.name, 'is', this.value)
      } finally {
        reactive.activeObserver = null
      }
    }
  }
  
  // Initialize
  observer.update()
  
  const getter = () => {
    const prevObserver = getActiveObserver()
    if (prevObserver) {
      console.log('Computed getter: tracking dependency for', prevObserver.name)
      prevObserver.dependents.add(observer)
    }
    return observer.value
  }
  
  return getter
}

// Test case
console.log('=== Test: compute cells can depend on other compute cells ===')

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2, { name: 'timesTwo' })
const timesThirty = createComputed(() => input() * 30, { name: 'timesThirty' })
const sum = createComputed(() => timesTwo() + timesThirty(), { name: 'sum' })

console.log('\nInitial: input=1')
console.log('Expected sum = 32, actual sum =', sum())

console.log('\nChanging input to 3...')
setInput(3)
console.log('Expected sum = 96, actual sum =', sum())