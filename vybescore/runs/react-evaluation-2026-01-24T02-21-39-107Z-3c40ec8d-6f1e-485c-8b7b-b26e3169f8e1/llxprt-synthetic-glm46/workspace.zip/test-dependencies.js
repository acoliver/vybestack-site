#!/usr/bin/env node

// Simple test script to check reactive dependency tracking
console.log('Testing simple dependencies...')

// Simple reactive system
let activeObserver = undefined

const getActiveObserver = () => activeObserver

const updateObserver = (observer) => {
  const previous = activeObserver
  activeObserver = observer
  try {
    console.log('updateObserver: calling updateFn with value:', observer.value)
    const result = observer.updateFn(observer.value)
    console.log('updateObserver: updateFn returned:', result)
    if (result !== undefined) {
      observer.value = result
    }
  } finally {
    activeObserver = previous
  }
}

const notifyObservers = (subject) => {
  console.log('notifyObservers:', subject.observers.size, 'observers to notify')
  for (const observer of subject.observers) {
    console.log('notifyObservers: notifying observer', observer.name || 'unnamed')
    updateObserver(observer)
  }
}

const createInput = (value) => {
  const subject = {
    name: 'input',
    observers: new Set(),
    value,
  }
  
  const read = () => {
    const observer = getActiveObserver()
    if (observer) {
      console.log('Input read: adding observer to dependencies')
      subject.observers.add(observer)
      
      // Add the input to the observer's dependencies
      if (observer.dependencies) {
        observer.dependencies.add(subject)
      }
    }
    return subject.value
  }
  
  const write = (nextValue) => {
    console.log('Input write: updating value from', subject.value, 'to', nextValue)
    subject.value = nextValue
    notifyObservers(subject)
    return subject.value
  }
  
  return [read, write]
}

const createComputed = (updateFn, value, _equal, options) => {
  const observer = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Initialize the computed value
  console.log('Initializing computed', options?.name, 'with value:', value)
  if (observer.value === undefined) {
    console.log('Running updateFn with undefined to initialize...')
    const initialValue = observer.updateFn(undefined)
    console.log('Got initial value:', initialValue)
    if (initialValue !== undefined) {
      observer.value = initialValue
    }
    console.log('Observer value after init:', observer.value)
  }
  
  const getter = () => {
    const prevObserver = getActiveObserver()
    if (prevObserver) {
      console.log('Computed getter: tracking dependency from observer', prevObserver.name || 'unnamed')
      observer.dependencies.clear()
      observer.dependencies.add(prevObserver)
    }
    
    console.log('Computed getter: returning cached value:', observer.value)
    return observer.value
  }
  
  return getter
}

console.log('=== Testing compute cells can depend on other compute cells ===')

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('timesTwo recomputing: input() =', input(), '* 2')
  return input() * 2
}, undefined, undefined, { name: 'timesTwo' })

const timesThirty = createComputed(() => {
  console.log('timesThirty recomputing: input() =', input(), '* 30')
  return input() * 30
}, undefined, undefined, { name: 'timesThirty' })

const sum = createComputed(() => {
  console.log('sum recomputing: timesTwo() =', timesTwo(), '+ timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
}, undefined, undefined, { name: 'sum' })

console.log('\n=== Initial values ===')
console.log('input = 1')
console.log('expected: sum = 32 (1*2 + 1*30)')
const initialSum = sum()
console.log('actual sum =', initialSum)

console.log('\n=== Changing input to 3 ===')
setInput(3)
console.log('expected: sum = 96 (3*2 + 3*30)')
const newSum = sum()
console.log('actual sum =', newSum)

console.log('\n=== Analysis ===')
console.log('The issue: when setInput(3) is called, it should notify all dependent observers')
console.log('Currently, only direct observers get notified, not chained dependencies')