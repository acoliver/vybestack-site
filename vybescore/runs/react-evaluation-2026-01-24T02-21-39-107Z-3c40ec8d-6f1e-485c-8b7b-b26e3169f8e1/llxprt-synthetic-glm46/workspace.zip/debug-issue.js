#!/usr/bin/env node

// Simplified test for the createComputed function from our actual implementation
console.log('Testing createComputed with initialization...')

// Simple simulation based on our current implementation
const createComputed = (updateFn, value, _equal, options) => {
  const o = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Initialize the computed value by running updateFn if no value provided
  if (o.value === undefined) {
    // This is how our current implementation should work
    const initialValue = o.updateFn(undefined)  // Should be called with undefined, gets 3, returns 6
    if (initialValue !== undefined) {
      o.value = initialValue
    }
  }
  
  const getter = () => {
    const prevObserver = getActiveObserver()
    if (prevObserver) {
      o.dependencies.clear()
      o.dependencies.add(prevObserver)
    }
    
    // Always update the computed value when accessed
    updateObserver(o)
    
    return o.value
  }
  
  return getter
}

let activeObserver = undefined

const getActiveObserver = () => activeObserver

const updateObserver = (observer) => {
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value)
    if (result !== undefined) {
      observer.value = result
    }
  } finally {
    activeObserver = previous
  }
}

// Test case - this mimics the failing test
const updateFn = (x = 3) => {
  console.log('updateFn called with:', x, '(typeof:', typeof x, ')')
  const result = x * 2
  console.log('updateFn result:', result)
  return result
}

console.log('=== Test Case Analysis ===')

console.log('\n1. Initialization phase:')
console.log('   - createComputed called with undefined value')
console.log('   - updateFn called with undefined (parameter defaults to 3)')
console.log('   - Expected result: 6')

console.log('\n2. Access phase:')
console.log('   - computed() called')
console.log('   - updateObserver called with observer.value=6')
console.log('   - updateFn called with observer.value=6')
console.log('   - Expected result: 12')

console.log('\n=== Running Test ===')
const computed = createComputed(updateFn)  // value is undefined
console.log('Before first call, observer initialized with updateFn(undefined) -> should be 6')
const result = computed()
console.log('After computed() call, result =', result, '(expected: 6, but we get 12 due to double call)')
console.log("The issue: updateObserver calls updateFn again with value=6, so 6*2=12")