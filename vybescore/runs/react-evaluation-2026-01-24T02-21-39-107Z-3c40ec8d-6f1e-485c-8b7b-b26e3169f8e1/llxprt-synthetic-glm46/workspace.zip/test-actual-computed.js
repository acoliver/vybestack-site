#!/usr/bin/env node

// Test script to debug actual computed implementation
console.log('Testing actual computed implementation...')

// Import the actual implementation
const fs = require('fs')
const path = require('path')

// Read and evaluate the reactive types
const reactivePath = path.join(__dirname, 'src/types/reactive.ts')
const reactiveContent = fs.readFileSync(reactivePath, 'utf8')

// Convert TypeScript to JavaScript for evaluation
const reactiveJs = reactiveContent
  .replace(/export type/g, 'const')
  .replace(/export function/g, 'function')
  .replace(/: \w+/g, '')
  .replace(/<T>/g, '')
  .replace(/<T,>/g, '')
  .replace(/const getActiveObserver/, 'function getActiveObserver/')
  .replace(/const updateObserver/, 'function updateObserver/')
  .replace(/const notifyObservers/, 'function notifyObservers/')
  .replace(/const notifyDependents/, 'function notifyDependents/')

eval(reactiveJs)

// Read and evaluate the computed implementation
const computedPath = path.join(__dirname, 'src/core/computed.ts')
let computedContent = fs.readFileSync(computedPath, 'utf8')

// Convert TypeScript to JavaScript for evaluation
computedContent = computedContent
  .replace(/import.*from/g, '//import') // Remove imports
  .replace(/: \w+/g, '')
  .replace(/<T>/g, '')
  .replace(/<T,>/g, '')
  .replace(/\blet\b/g, 'const') // Simplify for eval
  .replace(/export function/g, 'function')

// Since we removed imports, we need to provide the functions directly
// Simplify the reactive system for testing
let activeObserver = undefined

const getActiveObserver = () => activeObserver

const updateObserver = (observer) => {
  const previous = activeObserver
  activeObserver = observer
  try {
    const result = observer.updateFn(observer.value)
    if (result !== undefined) {
      observer.value = result
    }
  } finally {
    activeObserver = previous
  }
}

// Now evaluate the computed implementation
eval(`
${computedContent}

// Test case
const updateFn = (x = 3) => {
  console.log('updateFn called with:', x)
  const result = x * 2
  console.log('updateFn result:', result)
  return result
}

console.log('Testing actual implementation...')
const computed = createComputed(updateFn)
console.log('Call computed():')
const result = computed()
console.log('Final result:', result)
console.log('Expected: 6')
console.log('Test passes:', result === 6)
`)