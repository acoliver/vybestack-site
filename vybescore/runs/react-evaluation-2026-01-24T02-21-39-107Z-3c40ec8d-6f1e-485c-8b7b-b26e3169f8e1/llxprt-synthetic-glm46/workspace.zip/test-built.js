#!/usr/bin/env node

// Test with the actual built modules
console.log('Testing actual built modules...')

// Try to import the built modules
try {
  // Import the actual built modules
  const { createInput, createComputed, createCallback } = require('./index.js')

  console.log('=== Test: compute cells can depend on other compute cells ===')

  const [input, setInput] = createInput(1)
  const timesTwo = createComputed(() => input() * 2)
  const timesThirty = createComputed(() => input() * 30)
  const sum = createComputed(() => timesTwo() + timesThirty())

  console.log('\nInitial: input=1')
  console.log('Expected sum = 32, actual sum =', sum())

  console.log('\nChanging input to 3...')
  setInput(3)
  console.log('Expected sum = 96, actual sum =', sum())

} catch (error) {
  console.log('Error importing built modules:', error.message)
  console.log('Trying to test with TypeScript compilation...')
  
  // Fallback: test with ts-node
  const { execSync } = require('child_process')
  try {
    const result = execSync('npx tsx --test', { encoding: 'utf8', cwd: process.cwd() })
    console.log('Test result:', result)
  } catch (error) {
    console.log('Direct test failed, error:', error.message)
  }
}