import { FormCaptureApp } from './dist/server.js';
import request from 'supertest';
import fs from 'fs';
import path from 'path';

const dbPath = path.resolve('data', 'submissions.sqlite');

async function debugSubmitTest() {
  try {
    console.log('Creating app...');
    const server = new FormCaptureApp();
    
    console.log('Initializing app...');
    await server.initialize();
    
    console.log('Getting app...');
    const app = server.getApp();
    
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
      console.log('Removed existing database');
    }
    
    console.log('Making valid submission...');
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);
    
    if (response.status === 400 || response.status === 500) {
      console.log('Error response (first 2000 chars):', response.text.substring(0, 2000));
      
      // Look for error messages
      if (response.text.includes('error-list')) {
        const errorMatch = response.text.match(/<ul class="error-list">([\s\S]*?)<\/ul>/);
        if (errorMatch) {
          console.log('Error messages found:', errorMatch[1]);
        }
      }
    } else {
      console.log('Success! Database file created:', fs.existsSync(dbPath));
    }
    
    await server.stop();
  } catch (error) {
    console.error('Error:', error);
  }
}

debugSubmitTest();