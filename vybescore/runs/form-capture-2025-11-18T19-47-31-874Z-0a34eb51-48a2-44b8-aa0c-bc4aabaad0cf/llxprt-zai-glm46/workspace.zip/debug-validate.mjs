import { FormCaptureApp } from './dist/server.js';

async function debugValidation() {
  try {
    console.log('Creating app...');
    const server = new FormCaptureApp();
    
    console.log('Initializing app...');
    await server.initialize();
    
    // Test validation manually
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    console.log('Test data:', testData);
    
    // Access private method for testing
    const formData = testData;
    const errors = [];
    
    if (!formData.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    
    if (!formData.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    
    if (!formData.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    
    if (!formData.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    
    if (!formData.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    
    if (!formData.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    } else if (!/^[A-Za-z0-9\s-]+$/.test(formData.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and hyphens' });
    }
    
    if (!formData.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    
    if (!formData.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }
    
    if (!formData.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else if (!/^\+?[\d\s-()]+$/.test(formData.phone)) {
      errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +' });
    }
    
    console.log('Validation errors:', errors.length);
    console.log('Errors:', errors);
    
    await server.stop();
  } catch (error) {
    console.error('Error:', error);
  }
}

debugValidation();