import { FormCaptureApp } from './dist/server.js';
import request from 'supertest';
import fs from 'fs';
import path from 'path';

const dbPath = path.resolve('data', 'submissions.sqlite');

async function debugRaw() {
  try {
    console.log('Creating app...');
    const server = new FormCaptureApp();
    
    console.log('Initializing app...');
    await server.initialize();
    
    console.log('Getting app...');
    const app = server.getApp();
    
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
      console.log('Removed existing database');
    }
    
    console.log('Testing raw request...');
    
    const response = await request(app)
      .post('/submit')
      .set('Content-Type', 'application/x-www-form-urlencoded')
      .send('firstName=John&lastName=Doe&streetAddress=123+Main+St&city=London&stateProvince=England&postalCode=SW1A+1AA&country=United+Kingdom&email=john.doe%40example.com&phone=%2B44+20+7946+0958');
    
    console.log('Response status:', response.status);
    console.log('Response location header:', response.headers.location);
    
    if (response.status === 302) {
      console.log('Success! Redirecting to:', response.headers.location);
      console.log('Database file created:', fs.existsSync(dbPath));
    } else {
      console.log('Error - full response:');
      console.log(response.text);
    }
    
    await server.stop();
  } catch (error) {
    console.error('Error:', error);
  }
}

debugRaw();