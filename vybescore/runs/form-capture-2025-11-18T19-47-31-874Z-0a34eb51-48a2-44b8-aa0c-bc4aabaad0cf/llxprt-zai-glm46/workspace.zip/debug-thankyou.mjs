import { FormCaptureApp } from './dist/server.js';
import request from 'supertest';

async function debugThankYou() {
  try {
    console.log('Creating app...');
    const server = new FormCaptureApp();
    
    console.log('Initializing app...');
    await server.initialize();
    
    console.log('Getting app...');
    const app = server.getApp();
    
    console.log('Making request to /thank-you...');
    const response = await request(app).get('/thank-you');
    
    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);
    
    if (response.status !== 200) {
      console.log('Error response:');
      console.log(response.text.substring(0, 1000));
    } else {
      console.log('Success! Response contains:');
      console.log('- "Thank":', response.text.includes('Thank'));
      console.log('- "spam" (case-insensitive):', response.text.toLowerCase().includes('spam'));
      console.log('First 500 chars:', response.text.substring(0, 500));
    }
    
    await server.stop();
  } catch (error) {
    console.error('Error:', error);
  }
}

debugThankYou();