const { FormCaptureApp } = require('./dist/server.js');
const request = require('supertest');

async function debugTest() {
  try {
    console.log('Creating app...');
    const server = new FormCaptureApp();
    
    console.log('Initializing app...');
    await server.initialize();
    
    console.log('Getting app...');
    const app = server.getApp();
    
    console.log('Making request...');
    const response = await request(app).get('/');
    
    console.log('Response status:', response.status);
    console.log('Response headers:', response.headers);
    console.log('Response body length:', response.text.length);
    console.log('First 500 chars of response:', response.text.substring(0, 500));
    
    await server.stop();
  } catch (error) {
    console.error('Error:', error);
  }
}

debugTest();