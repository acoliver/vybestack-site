import express from 'express';
import { join, dirname } from 'path';
import { fileURLToPath } from 'url';
/// <reference path="./sqljs.d.ts" />
import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync } from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormCaptureApp {
  private app: express.Application;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private server: any;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: import('sql.js').Database | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = join(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
  }

  private setupMiddleware(): void {
    this.app!.use(express.urlencoded({ extended: true }));
    this.app!.use(express.static(join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', join(__dirname, '..', 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    const SQL = await initSqlJs();
    
    let dbBuffer: Uint8Array | null = null;
    
    if (existsSync(this.dbPath)) {
      const data = readFileSync(this.dbPath);
      dbBuffer = new Uint8Array(data);
    }
    
    this.db = new SQL.Database(dbBuffer || undefined);
    
    if (!dbBuffer) {
      this.db!.run(readFileSync(join(__dirname, '..', 'db', 'schema.sql'), 'utf8'));
    }
  }

  private saveDatabase(): void {
    const data = this.db!.export();
    writeFileSync(this.dbPath, Buffer.from(data));
  }

  private validateFormData(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }

    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    } else if (!/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, numbers, spaces, and hyphens' });
    }

    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else if (!/^\+?[\d\s-()]+$/.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +' });
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    this.app.post('/submit', (req, res) => {
      const formData = req.body as FormData;
      const errors = this.validateFormData(formData);

      if (errors.length > 0) {
        res.status(400).render('form', {
          errors: errors.map(e => e.message),
          values: formData
        });
        return;
      }

      try {
        const stmt = this.db!.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province, 
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);

        stmt.free();
        this.saveDatabase();

        res.redirect('/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: formData
        });
      }
    });

    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you');
    });

    this.app.use((req, res) => {
      res.status(404).render('form', {
        errors: ['Page not found'],
        values: {}
      });
    });
  }

  public getApp(): express.Application {
    return this.app;
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    this.setupRoutes();

    const port = process.env.PORT || 3535;
    this.server = this.app.listen(port, () => {
      console.log(`Form capture server running on port ${port}`);
    });
  }

  public async initialize(): Promise<void> {
    await this.initializeDatabase();
    this.setupRoutes();
  }

  public async stop(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
    
if (this.server) {
      return new Promise<void>((resolve) => {
        this.server!.close(() => {
          console.log('Server stopped gracefully');
          resolve();
        });
      });
    }
  }
}
const app = new FormCaptureApp();

process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await app.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await app.stop();
  process.exit(0);
});

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  app.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { FormCaptureApp, FormData, ValidationError };
