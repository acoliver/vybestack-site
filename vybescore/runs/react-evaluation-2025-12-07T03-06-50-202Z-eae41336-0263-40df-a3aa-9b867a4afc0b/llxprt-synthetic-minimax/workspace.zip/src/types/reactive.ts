/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Track which observers depend on which subjects for efficient updates
const dependencies = new WeakMap<object, Set<object>>()
const subscriptions = new WeakMap<object, Set<object>>()
let isUpdating = false

// Store a reference to the active observer globally for callbacks
export let activeObserver: ObserverR | undefined = undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): T {
  const previous = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Re-evaluate the observer's value
    observer.value = observer.updateFn(observer.value)
    
    // If this observer is a callback (has no name), the side effect is the updateFn itself
    // For computed values (with name), just return the value
  } finally {
    setActiveObserver(previous)
  }
  
  return observer.value!
}

export function trackDependency<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  // Track subject -> observer relationship
  if (!dependencies.has(subject)) {
    dependencies.set(subject, new Set())
  }
  dependencies.get(subject)!.add(observer)
  
  // Track observer -> subject relationship for cleanup
  if (!subscriptions.has(observer)) {
    subscriptions.set(observer, new Set())
  }
  subscriptions.get(observer)!.add(subject)
}

export function updateDependencies(subject: Subject<unknown>): void {
  if (isUpdating) return // Prevent circular updates
  isUpdating = true
  
  try {
    const observers = dependencies.get(subject)
    if (observers) {
      // Convert to array to avoid modification during iteration
      const observerArray = Array.from(observers)
      observerArray.forEach(observer => {
        // Trigger re-evaluation of the observer
        updateObserver(observer as Observer<unknown>)
      })
    }
  } finally {
    isUpdating = false
  }
}

export function cleanupDependencies(observer: Observer<unknown>): void {
  const subjects = subscriptions.get(observer)
  if (subjects) {
    subjects.forEach(subject => {
      const dependentSet = dependencies.get(subject)
      if (dependentSet) {
        dependentSet.delete(observer)
        if (dependentSet.size === 0) {
          dependencies.delete(subject)
        }
      }
    })
    subscriptions.delete(observer)
  }
}