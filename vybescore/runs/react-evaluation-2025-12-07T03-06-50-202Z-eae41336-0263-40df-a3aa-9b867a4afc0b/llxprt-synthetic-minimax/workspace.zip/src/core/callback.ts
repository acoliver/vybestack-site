/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, cleanupDependencies, getActiveObserver, setActiveObserver, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Make this observer active temporarily to establish dependencies
  const previousActive = getActiveObserver()
  
  try {
    // Set this observer as active to establish dependencies
    setActiveObserver(observer)
    
    // Execute the callback initially to establish dependencies
    // This will cause the callback to read reactive values and establish dependencies
    updateObserver(observer)
  } finally {
    // Restore the previous active observer
    setActiveObserver(previousActive)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up dependencies to prevent memory leaks
    cleanupDependencies(observer as Observer<unknown>)
  }
}