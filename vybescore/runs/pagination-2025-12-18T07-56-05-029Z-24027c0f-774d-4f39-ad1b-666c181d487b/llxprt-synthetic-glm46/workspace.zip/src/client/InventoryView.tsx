import type { InventoryItem } from '../shared/types';
import { useState } from 'react';
import { useInventory } from './useInventory';

interface PaginationControlsProps {
  currentPage: number;
  hasNext: boolean;
  onPrevious: () => void;
  onNext: () => void;
}

function PaginationControls({ currentPage, hasNext, onPrevious, onNext }: PaginationControlsProps): JSX.Element {
  return (
    <div className="pagination-controls">
      <button 
        onClick={onPrevious} 
        disabled={currentPage <= 1}
      >
        Previous
      </button>
      <span>Page {currentPage}</span>
      <button 
        onClick={onNext} 
        disabled={!hasNext}
      >
        Next
      </button>
    </div>
  );
}
const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);

  const handlePrevious = (): void => {
    if (page > 1) {
      setPage(page - 1);
    }
  };

  const handleNext = (): void => {
    if (data?.hasNext) {
      setPage(page + 1);
    }
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        currentPage={page} 
        hasNext={data.hasNext}
        onPrevious={handlePrevious}
        onNext={handleNext}
      />
    </section>
  );
}
