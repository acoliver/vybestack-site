import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationParams(
  pageParam: number | undefined,
  limitParam: number | undefined
): { page: number; limit: number } {
  const page = pageParam !== undefined ? Math.floor(pageParam) : 1;
  const limit = limitParam !== undefined ? Math.floor(limitParam) : DEFAULT_LIMIT;

  if (pageParam !== undefined && (isNaN(pageParam) || pageParam < 1 || !Number.isInteger(pageParam))) {
    throw new Error('Invalid page parameter: must be a positive integer');
  }

  if (limitParam !== undefined && (isNaN(limitParam) || limitParam < 1 || !Number.isInteger(limitParam))) {
    throw new Error('Invalid limit parameter: must be a positive integer');
  }

  if (limit > MAX_LIMIT) {
    throw new Error(`Invalid limit parameter: cannot exceed ${MAX_LIMIT}`);
  }

  return { page, limit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const { page, limit } = validatePaginationParams(options.page, options.limit);

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = offset + limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
