#!/bin/bash
# Comprehensive Pagination Test Script
# This script tests all pagination scenarios

echo "=== Pagination API Test Suite ==="
echo ""

# Colors for output
GREEN='\033[0;32m'
RED='\033[0;31m'
NC='\033[0m' # No Color

# Function to test a request and check status
test_request() {
  local description="$1"
  local url="$2"
  local expected_status="$3"

  echo "Test: $description"
  response=$(curl -s -w "\n%{http_code}" "$url")
  http_code=$(echo "$response" | tail -n1)
  body=$(echo "$response" | head -n-1)

  if [ "$http_code" -eq "$expected_status" ]; then
    echo -e "${GREEN}[OK] PASS${NC} - HTTP $http_code"
    echo "Response: $body"
  else
    echo -e "${RED} FAIL${NC} - Expected HTTP $expected_status, got HTTP $http_code"
    echo "Response: $body"
  fi
  echo ""
}

# Start server in background
echo "Starting server..."
npm run dev:server > /tmp/server.log 2>&1 &
SERVER_PID=$!
sleep 3

# Check if server started
if ! curl -s http://localhost:3333/inventory > /dev/null; then
  echo "Failed to start server. Check /tmp/server.log"
  exit 1
fi

echo "Server started (PID: $SERVER_PID)"
echo ""

# Run tests
echo "=== Valid Pagination Tests ==="
test_request "Default (no params)" "http://localhost:3333/inventory" 200
test_request "Page 1, limit 5" "http://localhost:3333/inventory?page=1&limit=5" 200
test_request "Page 2, limit 5" "http://localhost:3333/inventory?page=2&limit=5" 200
test_request "Page 3, limit 5" "http://localhost:3333/inventory?page=3&limit=5" 200
test_request "Page 1, limit 10" "http://localhost:3333/inventory?page=1&limit=10" 200
test_request "Page 4 (beyond data)" "http://localhost:3333/inventory?page=4&limit=5" 200

echo "=== Validation Error Tests (HTTP 400) ==="
test_request "Page = 0" "http://localhost:3333/inventory?page=0" 400
test_request "Page = -1" "http://localhost:3333/inventory?page=-1" 400
test_request "Page = abc" "http://localhost:3333/inventory?page=abc" 400
test_request "Page = 1.5" "http://localhost:3333/inventory?page=1.5" 400
test_request "Limit = 0" "http://localhost:3333/inventory?limit=0" 400
test_request "Limit = -5" "http://localhost:3333/inventory?limit=-5" 400
test_request "Limit = xyz" "http://localhost:3333/inventory?limit=xyz" 400
test_request "Limit = 101 (exceeds max)" "http://localhost:3333/inventory?limit=101" 400

echo "=== Test Suite Complete ==="

# Cleanup
kill $SERVER_PID
echo "Server stopped (PID: $SERVER_PID)"
