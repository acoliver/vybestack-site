/**
 * Capitalizes the first character of each sentence.
 * Ensures proper spacing after sentence terminators (. ? !) while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Common abbreviations that might end with a period
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K'];
  const abbrPattern = abbreviations.join('|');
  
  // Process text while preserving abbreviations
  let result = text;
  
  // First, protect abbreviations with temporary placeholders
  const placeholders: Record<string, string> = {};
  let placeholderIndex = 0;
  
  result = result.replace(new RegExp(`\\b(${abbrPattern})\\.`, 'g'), (match) => {
    const placeholder = `__ABBR_${placeholderIndex}__`;
    placeholders[placeholder] = match;
    placeholderIndex++;
    return placeholder;
  });
  
  // Split by sentence terminators, preserving them
  const parts = result.split(/([.?!])/);
  const capitalizedParts: string[] = [];
  let capitalizationNeeded = true;
  
  for (let i = 0; i < parts.length; i++) {
    const part = parts[i];
    
    if (part === '.' || part === '?' || part === '!') {
      // This is a punctuation mark
      capitalizedParts.push(part);
      capitalizationNeeded = true;
    } else if (part.length > 0 && capitalizationNeeded) {
      // This is a sentence fragment that needs capitalization
      const cleanedPart = part.replace(/\s+/g, ' ').trim();
      
      // Find the first letter character
      const firstLetterMatch = cleanedPart.match(/[a-zA-Z]/);
      
      if (firstLetterMatch && firstLetterMatch.index !== undefined) {
        const firstLetterIndex = firstLetterMatch.index;
        const before = cleanedPart.substring(0, firstLetterIndex);
        const letter = cleanedPart.substring(firstLetterIndex, firstLetterIndex + 1).toUpperCase();
        const after = cleanedPart.substring(firstLetterIndex + 1);
        
        capitalizedParts.push(before + letter + after);
      } else {
        capitalizedParts.push(cleanedPart);
      }
      
      capitalizationNeeded = false;
    } else if (part.length > 0) {
      // This is a sentence fragment in the middle (no capitalization needed)
      capitalizedParts.push(part.replace(/\s+/g, ' ').trim());
    }
    // Skip empty parts
  }
  
  // Join the parts, ensure exactly one space after punctuation
  let finalResult = '';
  for (let i = 0; i < capitalizedParts.length; i++) {
    const part = capitalizedParts[i];
    finalResult += part;
    
    // If this is punctuation and the next part exists and isn't just empty
    if (['.', '?', '!'].includes(part) && i < capitalizedParts.length - 1 && capitalizedParts[i + 1].trim() !== '') {
      finalResult += ' ';
    }
  }
  
  // Restore abbreviations
  for (const [placeholder, original] of Object.entries(placeholders)) {
    finalResult = finalResult.replace(placeholder, original);
  }
  
  // Clean up extra spaces
  finalResult = finalResult.replace(/\s+/g, ' ').trim();
  
  return finalResult;
}

/**
 * Extracts URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Regex pattern for URL detection with better handling of punctuation at the end
  // Matches http/https, ftp, and other common protocols
  // Negative lookahead to avoid capturing trailing punctuation
  const urlRegex = /(https?:\/\/|ftp:\/\/|www\.)[^\s\])}<>]+\.(?:[a-zA-Z]{2,})\/?[^\s\])}<>]*[^\s\])}<>.,?!:]/g;
  
  // Extract matches and clean up trailing punctuation
  const matches = text.match(urlRegex) || [];
  const cleanedMatches = matches.map(url => {
    // Remove trailing punctuation that would not be part of the URL
    return url.replace(/[.,?!:]+$/, '');
  });
  
  // Use Set to remove duplicates
  return [...new Set(cleanedMatches)];
}

/**
 * Replaces http:// URLs with https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://... and moves docs paths to https://docs.example.com/...
 * For URLs with dynamic hints like cgi-bin, query strings, or legacy extensions, only upgrades the scheme.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // First, ensure all http URLs become https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Process each example.com URL in the text
  const urlRegex = /(https:\/\/example\.com\/[^\s\]]*)/g;
  
  result = result.replace(urlRegex, (fullMatch, url) => {
    try {
      // Extract the path and query from the URL
      const parsedUrl = new URL(url);
      const path = parsedUrl.pathname;
      const search = parsedUrl.search;
      
      // Check if the path contains dynamic hints or legacy extensions
      const dynamicHints = /(cgi-bin|\?|=|&|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/;
      
      if (dynamicHints.test(path) || dynamicHints.test(search)) {
        // Dynamic URL - only upgraded scheme, keep original host
        return url;
      }
      
      // Check if path begins with /docs/
      if (path.startsWith('/docs/')) {
        return `https://docs.example.com${path}${search}`;
      }
      
      // Regular URL, just keep as is with https
      return url;
    } catch (error) {
      // If URL parsing fails, just return the original
      return url;
    }
  });
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Check for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation for day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  if (month === 2) {
    const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
