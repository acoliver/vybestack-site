export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using comprehensive regex patterns.
 * Accepts typical email formats while rejecting common invalid patterns.
 */
export function isValidEmail(value: string): boolean {
  if (!value) return false;
  
  // Enhanced email regex that follows RFC 5322 guidelines more closely
  // Local part: a-zA-Z0-9 and allowed special chars, but not consecutive dots, not starting/ending with dot
  // Domain: a-zA-Z0-9 with hyphens allowed in middle, no underscores, no consecutive dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional validation checks for edge cases
  const localPart = value.split('@')[0];
  const domain = value.split('@')[1];
  
  // Basic structure check using regex
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject trailing dots in local part
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // Reject leading dots in local part
  if (localPart.startsWith('.')) {
    return false;
  }
  
  // Reject consecutive dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject domains with underscores (not allowed in domain names)
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domains starting or ending with hyphen
  if (domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (starting with 0 or 1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value) return false;
  
  // Check if there's a + sign and handle it properly
  const hasPlusSign = value.startsWith('+');
  let processedValue = value;
  
  if (hasPlusSign) {
    // Only handle +1 country code, reject others
    if (!value.startsWith('+1')) {
      return false;
    }
    // Remove the + for processing
    processedValue = value.substring(1);
  }
  
  // Remove common separators and whitespace
  const cleaned = processedValue.replace(/[\s\-()]/g, '');
  
  // Check for optional 1 country code (after removing +)
  const hasCountryCode = cleaned.startsWith('1');
  const numberPart = hasCountryCode ? cleaned.substring(1) : cleaned;
  
  // Must have exactly 10 digits after removing country code
  if (!/^\d{10}$/.test(numberPart)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = numberPart.substring(0, 3);
  
  // Area codes starting with 0 or 1 are invalid (NANP standards)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check total length constraints (minimum valid length)
  if (value.replace(/[\s\-()]/g, '').length < 10) return false;
  
  // Optional: handle extensions if allowed
  if (options?.allowExtensions && cleaned.length > 10) {
    const extensionPart = cleaned.substring(10);
    // Extension must be numeric and reasonable length
    if (!/^\d+$/.test(extensionPart) || extensionPart.length > 6) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for both mobile and landline formats.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Handles optional country code, trunk prefix, mobile indicator, and various separators.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Check for non-digit characters beyond valid separators
  if (/[^0-9+\s-]/.test(value)) {
    return false;
  }
  
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Extract components manually for better validation
  const countryCodeMatch = cleaned.match(/^(\+54)?/);
  const countryCode = countryCodeMatch ? countryCodeMatch[1] : '';
  let remaining = countryCode ? cleaned.substring(3) : cleaned; // Remove +54 if present
  
  // For 011 area code (Buenos Aires): If it's preceded by country code, there should be no trunk prefix
  // If no country code, trunk prefix 0 must be present
  let trunkPrefix = '';
  if (remaining.startsWith('0')) {
    trunkPrefix = '0';
    remaining = remaining.substring(1);
  }
  
  // When country code is omitted, trunk prefix must be present
  if (!countryCode && trunkPrefix === '') {
    return false;
  }
  
  // Check for mobile indicator (optional prefix 9)
  if (remaining.startsWith('9')) {
    remaining = remaining.substring(1);
  }
  
  // Extract area code (2-4 digits, starting with 1-9)
  const areaCodeMatch = remaining.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = remaining.substring(areaCode.length);
  
  // Area code validation - must be 2-4 digits with leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must contain exactly 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // Make sure we've consumed the entire string
  if (subscriberNumber.length !== remaining.substring(areaCode.length).length) {
    return false;
  }
  
  // Additional validation: ensure the total length is reasonable
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid formats like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim() === '') return false;
  
  // Unicode regex that accepts letters, accents, apostrophes, hyphens, and spaces
  // \p{L} - any letter
  // \p{M} - combining marks (accents, diacritics)
  const nameRegex = /^[\p{L}\p{M}]+(?:['\s-][\p{L}\p{M}]+)*$/u;
  
  // Check if the entire string matches the valid name pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with consecutive separators (like "John  Doe" or "Mary--Smith")
  if (/(['\s-])\1/.test(value)) {
    return false;
  }
  
  // Reject names that are too short (must have at least 2 characters after trimming)
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject names that are too long (reasonable max length for personal names)
  if (value.length > 100) {
    return false;
  }
  
  // Additional validation: ensure at least one letter component
  const lettersOnly = value.replace(/['\s-]/g, '');
  if (lettersOnly.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and AmEx.
 * Checks valid prefixes and lengths, then runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove spaces and dashes from the card number
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check valid prefixes and lengths for major card types
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14}|2[2-9]\d{15})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  return (visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned))
    && runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process each digit from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        sum += (digit % 10) + 1;
      } else {
        sum += digit;
      }
    } else {
      sum += digit;
    }
    
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
