/**
 * Finds words beginning with a specified prefix, excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a set of exceptions for O(1) lookup
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Word boundary regex pattern to match whole words
  const wordRegex = /\b\w+\b/g;
  const words = text.match(wordRegex) || [];
  
  // Filter words that start with the prefix and are not exceptions
  const prefixedWords = words
    .filter(word => word.toLowerCase().startsWith(prefix.toLowerCase()))
    .filter(word => !exceptionSet.has(word.toLowerCase()));
  
  // Return unique words
  return [...new Set(prefixedWords)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Use lookahead to match token only when preceded by a digit
  // and not at the start of the string
  const regex = new RegExp(`(?<=\\d)${escapeRegExp(token)}`, 'g');
  const matches = [];
  
  while (regex.lastIndex < text.length) {
    const match = regex.exec(text);
    if (!match) break;
    
    // Include the match and the preceding digit
    matches.push(text.substring(match.index - 1, match.index + token.length));
  }
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Helper function to escape special regex characters in the token.
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Validates passwords according to a strong password policy.
 * Requires at least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace,
 * and no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, 1212, xyxy)
  // Pattern to detect any character sequence repeated 2+ times in succession
  // This will catch patterns like abab, abcabc, 1212, etc.
  for (let i = 2; i <= value.length / 2; i++) {
    for (let j = 0; j <= value.length - i * 2; j++) {
      const sequence1 = value.substring(j, j + i);
      const sequence2 = value.substring(j + i, j + i * 2);
      
      if (sequence1 === sequence2) {
        return false;
      }
    }
  }
  
  // Additional check for repeated single characters (like aaaaaa)
  if (/(.)\1\1\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) and ensures IPv4 addresses don't trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 patterns
  // Full format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // Compressed format with :: (shortening sequences of zeros)
  // IPv4-mapped IPv6: ::ffff:192.0.2.128
  const ipv6WithPortRegex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}/;
  
  // Also check for the compressed version with :: that might include port numbers
  // ::1, ::ffff:192.168.0.1, 2001:db8::1, etc.
  const ipv6CompressedRegex = /::[fF]{4}:(?:\d{1,3}\.){3}\d{1,3}|::1|(?:[0-9a-fA-F]{1,4}:){1,7}:|:(?:[0-9a-fA-F]{1,4}:){1,7}|:/;
  
  // Check for IPv6 patterns
  if (ipv6WithPortRegex.test(value) || ipv6CompressedRegex.test(value)) {
    return true;
  }
  
  // Let's also check for the compressed format manually
  const parts = value.split(' ');
  for (const part of parts) {
    // Check for IPv6 pattern with colons
    if (part.includes(':')) {
      // Ensure this is not just an IPv4 address
      if (!/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(part)) {
        // Check for compressed IPv6 patterns like :: or with hex characters
        if (/::/.test(part) || /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/.test(part)) {
          return true;
        }
      }
    }
  }
  
  return false;
}
