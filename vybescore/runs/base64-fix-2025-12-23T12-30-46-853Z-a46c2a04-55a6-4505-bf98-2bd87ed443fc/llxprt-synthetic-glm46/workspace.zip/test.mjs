import { encode } from "./dist/src/base64.js"; console.log(encode("a").endsWith("="))
