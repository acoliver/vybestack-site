console.log(encode("hello")); import { encode } from "./src/base64.js";
