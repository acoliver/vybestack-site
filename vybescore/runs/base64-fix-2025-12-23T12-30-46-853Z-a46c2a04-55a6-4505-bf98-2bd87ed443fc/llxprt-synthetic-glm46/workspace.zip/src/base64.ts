const INVALID_BASE64_ERROR = 'Invalid Base64 input: contains invalid characters';

/**
 * Encode plain text to Base64 using standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with valid characters and optional padding.
 * Throws error for clearly invalid payloads.
 */
export function decode(input: string): string {
  // Basic validation: ensure only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  // Only check for clearly invalid padding cases:
  // 1. Padding characters not at the end: e.g. "=aGVsbG8="
  if (input.indexOf('=') !== -1 && !/^[A-Za-z0-9+/]+={0,2}$/.test(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  // 2. Invalid padding length (more than 2): e.g. "aGVsbG8==="
  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
