/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // First, capitalize the first character of the text
  let result = text;
  
  // Find sentence boundaries (. ! ?) and capitalize the next letter
  // We need to handle:
  // 1. After . ! ? followed by space(s) and then a letter
  // 2. Collapse extra spaces between sentences to exactly one space
  // 3. Leave abbreviations intact when possible (e.g., Mr., Dr., etc.)
  
  // Step 1: Normalize multiple spaces to single spaces
  result = result.replace(/[ \t]+/g, ' ');
  
  // Step 2: Capitalize after sentence boundaries, but not after abbreviations
  // We'll use a callback to check if it's an abbreviation
  result = result.replace(/([.!?])\s*([a-z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Step 3: Capitalize the very first character
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https/ftp protocols
  // Also matches domains without protocol (www.example.com)
  const urlPattern = /(?:https?:\/\/|ftp:\/\/)?(?:www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s.,!?:;()[\]{}"']*)?/gi;
  
  const matches: string[] = [];
  let match;
  
  const regex = new RegExp(urlPattern);
  while ((match = regex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation (but not query string chars like ?, &, =)
    // Check if the trailing char is part of a query string
    const hasQueryString = /[?&]/.test(url);
    const lastChar = url.slice(-1);
    const isPunctuation = /[.,!?:;()[\]{}"']/.test(lastChar);
    
    if (isPunctuation && !hasQueryString) {
      url = url.slice(0, -1);
    }
    
    // Ensure it's a valid URL (has at least one dot)
    if (url.includes('.') || url.startsWith('http')) {
      matches.push(url);
    }
  }
  
  return matches;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 */
export function rewriteDocsUrls(text: string): string {
  // First upgrade any http://example.com URLs to https
  // For URLs with /docs/ path and no dynamic hints, also rewrite host to docs.example.com
  return text.replace(/http:\/\/example\.com(\/[^\s]*)/gi, (match, path) => {
    // Check if this is a docs path
    if (!path.startsWith('/docs/')) {
      // Just upgrade scheme
      return 'https://example.com' + path;
    }
    
    // Check for query strings
    const hasQueryString = /[?&]/.test(path);
    
    // Check for legacy extensions in the filename
    const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
    
    // Check for cgi-bin
    const hasCgiBin = path.includes('cgi-bin');
    
    // Skip host rewrite if any dynamic hints are present
    if (hasQueryString || hasLegacyExtension || hasCgiBin) {
      return 'https://example.com' + path;
    }
    
    // Rewrite to docs.example.com
    return 'https://docs.example.com' + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
