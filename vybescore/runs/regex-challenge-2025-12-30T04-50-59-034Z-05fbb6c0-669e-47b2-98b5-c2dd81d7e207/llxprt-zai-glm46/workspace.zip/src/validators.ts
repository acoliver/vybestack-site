export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation - accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local part or domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject leading dot in local part
  if (value.startsWith('.') || value.startsWith('@')) {
    return false;
  }
  
  // Reject domains with underscores
  const domain = value.split('@')[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject trailing dot in local part (before @)
  const [local] = value.split('@');
  if (local.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * US phone number validation supporting common separators and optional +1
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must be exactly 10 digits (US number) or 11 digits (with country code 1)
  const isValidLength = digits.length === 10 || (digits.length === 11 && digits.startsWith('1'));
  
  if (!isValidLength) {
    return false;
  }
  
  // Extract the 10-digit number
  const tenDigits = digits.length === 11 ? digits.slice(1) : digits;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = tenDigits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = tenDigits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Argentine phone number validation covering mobile/landline formats
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, etc.)
  const cleaned = value.replace(/[-\s]/g, '');
  
  // Optional +54 country code
  // Optional 0 trunk prefix (required if country code is omitted)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  
  // Country code present: +54, trunk optional, mobile optional
  const withCountryRegex = /^\+54(0?)(9?)\d{2,4}\d{6,8}$/;
  // Without country code: must have trunk 0, mobile optional
  const withoutCountryRegex = /^0(9?)\d{2,4}\d{6,8}$/;
  
  if (withCountryRegex.test(cleaned)) {
    return validateArgentineParts(cleaned, true);
  }
  
  if (withoutCountryRegex.test(cleaned)) {
    return validateArgentineParts(cleaned, false);
  }
  
  return false;
}

function validateArgentineParts(value: string, hasCountryCode: boolean): boolean {
  let rest = value;
  
  // Remove country code
  if (hasCountryCode) {
    rest = rest.slice(3); // Remove +54
  }
  
  // Remove trunk prefix
  if (rest.startsWith('0')) {
    rest = rest.slice(1);
  }
  
  // Remove mobile indicator if present
  if (rest.startsWith('9')) {
    rest = rest.slice(1);
  }
  
  // Now rest should be area code + subscriber
  // Area code is 2-4 digits, subscriber is 6-8 digits
  const minTotal = 2 + 6; // 8
  const maxTotal = 4 + 8; // 12
  
  if (rest.length < minTotal || rest.length > maxTotal) {
    return false;
  }
  
  // Area code must start with 1-9
  if (rest[0] < '1' || rest[0] > '9') {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'-]+(?:\s[\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // Reject names with digits (shouldn't happen due to regex, but double check)
  if (/\d/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm helper
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length and prefix
  const isValidLengthAndPrefix = 
    // Visa: 13-19 digits, starts with 4
    (/^4\d{12,18}$/.test(cleaned)) ||
    // Mastercard: 16 digits, starts with 51-55 or 2221-2720
    (/^(?:5[1-5]\d{2}|2[2-7]\d{2})\d{12}$/.test(cleaned)) ||
    // AmEx: 15 digits, starts with 34 or 37
    (/^3[47]\d{13}$/.test(cleaned));
  
  if (!isValidLengthAndPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
