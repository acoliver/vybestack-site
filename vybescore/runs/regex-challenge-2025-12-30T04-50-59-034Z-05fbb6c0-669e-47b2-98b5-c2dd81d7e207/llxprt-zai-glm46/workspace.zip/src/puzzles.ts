/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex use
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[0];
    
    // Only include if not in exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token preceded by a digit (using positive lookbehind)
  // Also ensure it's not at the start of the string
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Return the full match (digit + token)
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // We look for any pattern of length 2-4 that repeats
  for (let patternLen = 2; patternLen <= 4; patternLen++) {
    for (let i = 0; i <= value.length - patternLen * 2; i++) {
      const pattern = value.slice(i, i + patternLen);
      const nextChunk = value.slice(i + patternLen, i + patternLen * 2);
      if (pattern === nextChunk) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude IPv4 addresses
  // IPv4 pattern: four groups of 1-3 digits separated by dots
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 patterns - need to match:
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons (e.g., 2001:db8::1)
  // Shorthand with :: for compressed zeros
  
  // Full IPv6 pattern
  const ipv6FullPattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with shorthand :: (can appear anywhere)
  const ipv6ShorthandPattern = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:?)*/;
  
  // Check for IPv6 pattern
  if (ipv6FullPattern.test(value) || ipv6ShorthandPattern.test(value)) {
    // Make sure it's not actually an IPv4 address
    if (!ipv4Pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
