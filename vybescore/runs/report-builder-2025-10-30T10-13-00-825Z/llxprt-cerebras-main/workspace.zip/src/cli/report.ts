#!/usr/bin/env node

import * as fs from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): { 
  dataFile: string; 
  format: string; 
  outputFile?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  const dataFile = args[0];
  
  if (!dataFile) {
    console.error('Error: Data file not provided');
    process.exit(1);
  }
  
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: Format not specified');
    process.exit(1);
  }
  const format = args[formatIndex + 1];
  
  if (!['markdown', 'text'].includes(format)) {
    console.error(`Error: Unsupported format '${format}'`);
    process.exit(1);
  }
  
  const outputFile = args.includes('--output') ? 
    args[args.indexOf('--output') + 1] : undefined;
    
  const includeTotals = args.includes('--includeTotals');
  
  return { dataFile, format, outputFile, includeTotals };
}

function loadData(filePath: string): ReportData {
  try {
    const rawData = fs.readFileSync(filePath, 'utf8');
    const data: ReportData = JSON.parse(rawData);
    
    // Validate data structure
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry structure');
      }
    }
    
    return data;
  } catch (err: unknown) {
    if (err instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file '${filePath}'`);
    } else if (err instanceof Error) {
      console.error(`Error: ${err.message}`);
    } else {
      console.error(`Error: Unknown error occurred while loading data`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  const options = { includeTotals };
  
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main() {
  const { dataFile, format, outputFile, includeTotals } = parseArguments();
  const data = loadData(dataFile);
  const output = renderReport(data, format, includeTotals);
  
  if (outputFile) {
    fs.writeFileSync(outputFile, output, 'utf8');
  } else {
    console.log(output);
  }
}

main();