/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ReactiveNode,
  getActiveNode,
  setActiveNode,
  trackDependency,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const node: ReactiveNode<T> = {
    value: value as T,
    observers: new Set(),
    name: options?.name,
  }
  
  const compute = () => {
    const previous = getActiveNode()
    setActiveNode(node as ReactiveNode<unknown>)
    try {
      node.value = updateFn(node.value)
    } finally {
      setActiveNode(previous)
    }
  }
  
  node.update = compute
  
  const getter: GetterFn<T> = () => {
    const active = getActiveNode()
    if (active) {
      // This node is being accessed during a computation
      // Track the dependency
      trackDependency(node)
    }
    return node.value
  }
  
  // Initial computation
  compute()
  
  return getter
}
