/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  ReactiveNode,
  getActiveNode,
  trackDependency,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const node: ReactiveNode<T> = {
    value,
    observers: new Set(),
    name: options?.name,
  }

  const read: GetterFn<T> = () => {
    const active = getActiveNode()
    if (active) {
      trackDependency(node)
    }
    return node.value
  }

  const write: SetterFn<T> = (nextValue) => {
    node.value = nextValue
    notifyObservers(node)
    return node.value
  }

  return [read, write]
}
