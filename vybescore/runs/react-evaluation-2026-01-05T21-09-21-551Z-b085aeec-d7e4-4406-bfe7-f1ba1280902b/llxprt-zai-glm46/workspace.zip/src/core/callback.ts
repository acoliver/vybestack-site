/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, UpdateFn, ReactiveNode, getActiveNode, setActiveNode, ComputationFn } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let currentValue: T | undefined = value
  
  const run: ComputationFn = () => {
    if (disposed) return
    currentValue = updateFn(currentValue)
  }
  
  const node: ReactiveNode<T> = {
    value: currentValue as T,
    observers: new Set(),
    update: run,
  }
  
  // Establish dependencies during initial run
  const previous = getActiveNode()
  setActiveNode(node as ReactiveNode<unknown>)
  try {
    // Run the callback to establish dependencies via reactive getters
    currentValue = updateFn(currentValue)
  } finally {
    setActiveNode(previous)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    node.update = undefined // Prevent future updates
  }
}
