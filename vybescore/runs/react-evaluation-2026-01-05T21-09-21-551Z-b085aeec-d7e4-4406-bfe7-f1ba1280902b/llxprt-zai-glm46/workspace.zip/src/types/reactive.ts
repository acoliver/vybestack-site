/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Reactive node that can be observed
export type ReactiveNode<T> = {
  value: T
  observers: Set<ReactiveNode<unknown>>
  name?: string
  update?: () => void
}

// Computation function that updates a reactive node
export type ComputationFn = () => void

let activeNode: ReactiveNode<unknown> | undefined

export function getActiveNode(): ReactiveNode<unknown> | undefined {
  return activeNode
}

export function setActiveNode(node: ReactiveNode<unknown> | undefined): void {
  activeNode = node
}

export function trackDependency<T>(dependency: ReactiveNode<T>): void {
  if (activeNode) {
    dependency.observers.add(activeNode)
  }
}

export function notifyObservers<T>(node: ReactiveNode<T>): void {
  // Process observers in order to propagate changes
  const processed = new Set<ReactiveNode<unknown>>()
  const queue = Array.from(node.observers)
  
  while (queue.length > 0) {
    const observer = queue.shift()!
    
    if (processed.has(observer)) {
      continue
    }
    processed.add(observer)
    
    // Trigger update
    if (observer.update) {
      observer.update()
    }
    
    // Notify observers of this observer
    for (const nextObserver of observer.observers) {
      if (!processed.has(nextObserver)) {
        queue.push(nextObserver)
      }
    }
  }
}
