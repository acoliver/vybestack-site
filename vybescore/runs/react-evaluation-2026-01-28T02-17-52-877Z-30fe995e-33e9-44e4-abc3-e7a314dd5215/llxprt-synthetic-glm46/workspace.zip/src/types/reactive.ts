/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent recursive updates
  if (activeObserver === observer) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Subject registry to track all active subjects and their observers
export const subjectRegistry = new WeakMap<object, Set<ObserverR>>()

export function getSubjectObservers(subject: object): Set<ObserverR> | undefined {
  return subjectRegistry.get(subject)
}

export function addSubjectObserver(subject: object, observer: ObserverR): void {
  let observers = subjectRegistry.get(subject)
  if (!observers) {
    observers = new Set()
    subjectRegistry.set(subject, observers)
  }
  observers.add(observer)
}

export function removeSubjectObserver(subject: object, observer: ObserverR): void {
  const observers = subjectRegistry.get(subject)
  if (observers) {
    observers.delete(observer)
  }
}

// Global active subjects tracking for dependency management
const activeSubjects = new Set<object>()

export function registerActiveSubject(subject: object): void {
  activeSubjects.add(subject)
}

export function getActiveSubjects(): Set<object> {
  return new Set(activeSubjects)
}

// Global dependency tracking for callbacks
let currentSubjectOperations: { add: Set<object>, remove: Set<object> } | undefined

export function clearSubjectOperations(): void {
  currentSubjectOperations = undefined
}

export function getSubjectOperations(): { add: Set<object>, remove: Set<object> } | undefined {
  return currentSubjectOperations
}
