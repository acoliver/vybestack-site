/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, removeSubjectObserver, getActiveSubjects, getSubjectObservers, subjectRegistry } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Track which subjects this callback observes
  const observedSubjects = new Set<object>()
  
  const callbackObserver: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if (disposed) return currentValue!
      
      // Clear previous tracking and start fresh
      observedSubjects.clear()
      
      // Execute the user's callback function  
      const result = updateFn(currentValue)
      
      // Register this callback with all subjects it accessed during execution
      const activeSubjects = getActiveSubjects()
      activeSubjects.forEach(subject => {
        if (!observedSubjects.has(subject)) {
          addSubjectObserver(subject, callbackObserver)
          observedSubjects.add(subject)
        }
      })
      
      return result
    }
  }
  
  const addSubjectObserver = (subject: object, observer: Observer<T>) => {
    let observers = getSubjectObservers(subject)
    if (!observers) {
      observers = new Set()
      subjectRegistry.set(subject, observers)
    }
    observers.add(observer)
  }
  
  // Register the callback to track its dependencies
  updateObserver(callbackObserver)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove callback from all subjects it observed
    observedSubjects.forEach(subject => {
      removeSubjectObserver(subject, callbackObserver)
    })
    
    // Clear the observer to stop further updates
    callbackObserver.value = undefined
    callbackObserver.updateFn = () => value!
  }
}
