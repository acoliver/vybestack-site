/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerActiveSubject,
  addSubjectObserver,
  getSubjectObservers
} from '../types/reactive.js'


export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }
  
  registerActiveSubject(s)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) addSubjectObserver(s, observer)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (nextValue !== s.value) {
      s.value = nextValue
      const observers = getSubjectObservers(s)
      if (observers) {
        observers.forEach(observer => {
          updateObserver(observer as Observer<T>)
        })
      }
    }
    return s.value
  }

  return [read, write]
}
