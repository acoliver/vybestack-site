#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, RenderOptions } from '../types/report.js';

function printError(message: string): void {
  console.error(message);
  process.exit(1);
}

function parseArgs(args: string[]): { 
  filePath: string; 
  format: string; 
  output?: string; 
  includeTotals: boolean 
} {
  if (args.length < 2) {
    printError('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  let filePath = '';
  let format = '';
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--')) {
      if (arg === '--format') {
        format = args[++i] || '';
      } else if (arg === '--output') {
        output = args[++i] || '';
      } else if (arg === '--includeTotals') {
        includeTotals = true;
      } else {
        printError(`Unknown option: ${arg}`);
      }
    } else if (!arg.startsWith('--')) {
      filePath = arg;
    }
  }

  if (!filePath) {
    printError('Missing data file path');
  }

  if (!format) {
    printError('Missing --format option');
  }

  if (format !== 'markdown' && format !== 'text') {
    printError(`Unsupported format: ${format}`);
  }

  return { filePath, format, output, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null || Array.isArray(data)) {
    throw new Error('Data must be a JSON object');
  }

  const objData = data as Record<string, unknown>;

  if (typeof objData.title !== 'string') {
    throw new Error('Missing or invalid "title" field (must be string)');
  }

  if (typeof objData.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field (must be string)');
  }

  if (!Array.isArray(objData.entries)) {
    throw new Error('Missing or invalid "entries" field (must be array)');
  }

  if (objData.entries.length === 0) {
    throw new Error('"entries" array cannot be empty');
  }

  for (const entry of objData.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Each entry must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Each entry must have a string "label" field');
    }

    if (typeof entryObj.amount !== 'number' || !isFinite(entryObj.amount)) {
      throw new Error('Each entry must have a number "amount" field');
    }
  }

  return true;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      printError(`Invalid JSON: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && (error as { code?: string }).code === 'ENOENT') {
      printError(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  if (format === 'markdown') {
    return renderMarkdown(data, options);
  } else if (format === 'text') {
    return renderText(data, options);
  } else {
    printError(`Unsupported format: ${format}`);
    return ''; // unreachable
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      printError(`Failed to write output file: ${(error as Error).message}`);
    }
  } else {
    console.log(content);
  }
}

// Main execution
const args = process.argv.slice(2);
const { filePath, format, output, includeTotals } = parseArgs(args);

const reportData = loadReportData(filePath);
const renderOptions: RenderOptions = { includeTotals };
const renderedContent = renderReport(reportData, format, renderOptions);

writeOutput(renderedContent, output);
