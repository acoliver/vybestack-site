import { ReportData, RenderOptions } from '../types/report.js';

export function renderText(data: ReportData, options: RenderOptions): string {
  const entries = data.entries.map(entry => {
    const formattedAmount = entry.amount.toFixed(2);
    return `- ${entry.label}: $${formattedAmount}`;
  });

  let output = `${data.title}\n`;
  output += `${data.summary}\n`;
  output += `Entries:\n`;
  output += `${entries.join('\n')}\n`;

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = total.toFixed(2);
    output += `Total: $${formattedTotal}\n`;
  }

  return output;
}