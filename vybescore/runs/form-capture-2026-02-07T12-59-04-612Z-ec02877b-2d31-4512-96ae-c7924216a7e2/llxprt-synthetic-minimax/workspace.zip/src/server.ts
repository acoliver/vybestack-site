import express, { Request, Response } from 'express';
import path from 'node:path';
import { DatabaseManager } from './database.js';

const PORT = process.env.PORT || 3535;

// Main application function
async function createApp(): Promise<express.Application> {
  const app = express();
  
  // Initialize database
  const dbManager = new DatabaseManager();
  await dbManager.initialize();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use('/public', express.static(path.join(process.cwd(), 'public')));

  // View engine setup
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'views'));

  // Types for form data and validation
  interface FormData {
    first_name: string;
    last_name: string;
    street_address: string;
    city: string;
    state_province: string;
    postal_code: string;
    country: string;
    email: string;
    phone: string;
  }

  interface ValidationErrors {
    [key: string]: string;
  }

  function validateForm(data: FormData): { errors: ValidationErrors; isValid: boolean } {
    const errors: ValidationErrors = {};

    // Required field validation
    const requiredFields = [
      'first_name', 'last_name', 'street_address', 'city',
      'state_province', 'postal_code', 'country', 'email', 'phone'
    ];

    requiredFields.forEach(field => {
      if (!data[field as keyof FormData]?.trim()) {
        errors[field] = 'This field is required';
      }
    });

    // Email validation (simple regex)
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone validation - accept international formats
    if (data.phone && !/^\+?[\d\s\-()]+$/.test(data.phone.trim())) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation - alphanumeric with spaces
    if (data.postal_code && !/^[\w\s-]+$/.test(data.postal_code.trim())) {
      errors.postal_code = 'Please enter a valid postal code';
    }

    return {
      errors,
      isValid: Object.keys(errors).length === 0
    };
  }

  // GET / - Render contact form
  app.get('/', (req: Request, res: Response) => {
    res.render('contact', {
      title: 'Contact Us',
      errors: {},
      data: {}
    });
  });

  // POST /submit - Handle form submission
  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);

    if (!validation.isValid) {
      // Re-render form with errors and previously entered data
      return res.status(400).render('contact', {
        title: 'Contact Us - Please Fix Errors',
        errors: validation.errors,
        data: formData
      });
    }

    // Insert submission into database
    try {
      dbManager.insertSubmission(formData);
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error inserting submission:', error);
      res.status(500).render('contact', {
        title: 'Contact Us - Error',
        errors: { general: 'Sorry, there was an error processing your submission. Please try again.' },
        data: formData
      });
    }
  });

  // GET /thank-you - Thank you page
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  });

  return app;
}

// Export the app creation function for testing
export { createApp };

// Graceful shutdown function
function gracefulShutdown(server: import('http').Server, signal: string): void {
  console.log(`Received ${signal}, shutting down gracefully...`);
  
  // Note: dbManager closure would need to be handled differently
  // in this async context, but for now we'll log the shutdown
  
  server.close(() => {
    console.log('Server closed.');
    process.exit(0);
  });
  
  setTimeout(() => {
    console.log('Timeout reached, forcing shutdown...');
    process.exit(1);
  }, 10000);
}

// Start server function
async function startServer(): Promise<void> {
  try {
    const app = await createApp();

    // Start server
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Handle termination signals
    process.on('SIGTERM', () => gracefulShutdown(server, 'SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown(server, 'SIGINT'));

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
startServer();
