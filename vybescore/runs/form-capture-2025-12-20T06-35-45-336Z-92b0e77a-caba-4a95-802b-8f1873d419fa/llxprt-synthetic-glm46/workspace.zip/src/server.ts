import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const schemaPath = path.join(__dirname, '../db/schema.sql');

const port = process.env.PORT || 3535;
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

let db: Database | null = null;

// Database initialization
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });

    let dbBuffer: Uint8Array | null = null;

    if (fs.existsSync(dbPath)) {
      console.log('Loading existing database');
      const data = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(data);
    } else {
      console.log('Creating new database');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db = new SQL.Database();
      db.run(schema);
      const data = db.export();
      db.close();
      fs.writeFileSync(dbPath, Buffer.from(data));
      dbBuffer = new Uint8Array(data);
    }

    db = new SQL.Database(dbBuffer);
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Function to save the database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }
}

// Form validation
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

function validateForm(formData: FormData): ValidationResult {
  const errors: string[] = [];

  // Check required fields
  if (!formData.firstName.trim()) errors.push('First name is required');
  if (!formData.lastName.trim()) errors.push('Last name is required');
  if (!formData.streetAddress.trim()) errors.push('Street address is required');
  if (!formData.city.trim()) errors.push('City is required');
  if (!formData.stateProvince.trim()) errors.push('State/Province/Region is required');
  if (!formData.postalCode.trim()) errors.push('Postal/Zip code is required');
  if (!formData.country.trim()) errors.push('Country is required');
  if (!formData.email.trim()) errors.push('Email is required');
  if (!formData.phone.trim()) errors.push('Phone number is required');

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (formData.email.trim() && !emailRegex.test(formData.email.trim())) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (formData.phone.trim() && !phoneRegex.test(formData.phone.trim())) {
    errors.push('Please enter a valid phone number');
  }

  return {
    isValid: errors.length === 0,
    errors,
  };
}

// Routes
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: express.Request, res: express.Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province, 
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim(),
      ]);

      stmt.free();
      saveDatabase();
    } catch (error) {
      console.error('Error inserting into database:', error);
      return res.status(500).render('form', {
        errors: ['An error occurred while processing your submission. Please try again.'],
        values: formData,
      });
    }
  }

  // Redirect to thank you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName.trim())}`);
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
async function startServer() {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}. Closing server...`);
    server.close(() => {
      console.log('Server closed');
      if (db) {
        db.close();
        console.log('Database closed');
        process.exit(0);
      }
    });
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
