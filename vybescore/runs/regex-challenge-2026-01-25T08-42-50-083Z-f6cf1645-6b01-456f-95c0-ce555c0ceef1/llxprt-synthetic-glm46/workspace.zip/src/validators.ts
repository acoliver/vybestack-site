export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in the local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Ensure valid local part structure
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('.')) {
    const localParts = localPart.split('.');
    for (const part of localParts) {
      if (part.length === 0) {
        return false;
      }
    }
  }
  
  // Ensure domain has valid structure
  const domainParts = domainPart.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  // Check TLD is only letters
  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]+$/.test(tld)) {
    return false;
  }
  
  // Ensure domain doesn't start or end with hyphen
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + for validation
  const digitsOnly = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1 (optional country code)
  const hasCountryCode = digitsOnly.startsWith('+1');
  const phoneNumber = hasCountryCode ? digitsOnly.substring(2) : digitsOnly;
  
  // Phone number should be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code for validation
  const areaCode = phoneNumber.substring(0, 3);
  
  // Reject impossible area codes (leading 0 or 1)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check if the entire value matches common US phone formats
  const commonFormats = [
    /^\(\d{3}\) \d{3}-\d{4}$/, // (212) 555-7890
    /^\d{3}-\d{3}-\d{4}$/,     // 212-555-7890
    /^\d{10}$/,                // 2125557890
    /^\+1 \(\d{3}\) \d{3}-\d{4}$/, // +1 (212) 555-7890
    /^\+1 \d{3}-\d{3}-\d{4}$/,     // +1 212-555-7890
    /^\+1\d{10}$/               // +12125557890
  ];
  
  // Check if the format matches one of the common patterns (with optional extension)
  const cleanedForExtension = value.replace(/\s+ext\.\s*\d+.*$/i, '');
  const formatMatch = commonFormats.some(regex => {
    if (options?.allowExtensions && value.match(regex)) {
      return true;
    }
    return regex.test(cleanedForExtension);
  });
  
  if (!formatMatch) {
    // If no format match, try a more flexible approach
    const flexRegex = /^(\+1[\s-]?)?(\(?(\d{3})\)?[\s-]?)?(\d{3})[\s-]?(\d{4})(\s*ext\.?\s*\d+)?$/;
    if (!flexRegex.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone pattern with optional country code, trunk prefix, and mobile indicator
  // +54 9 11 1234 5678
  // 011 1234 5678
  // +54 341 123 4567
  // 0341 4234567
  const argentinePhoneRegex = /^(\+54)?(9)?(\d{2,4})(\d{6,8})$/;
  
  // Also handle the case with trunk prefix (0) before area code when country code is omitted
  const withTrunkPrefixRegex = /^0(\d{2,4})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned) && !withTrunkPrefixRegex.test(cleaned)) {
    // Try a more specific pattern
    const specificRegex = /^(\+54)?(9)?0?(\d{2,4})[\s-]?(\d{6,8})$/;
    if (!specificRegex.test(value)) {
      return false;
    }
  }
  
  // Extract area code and subscriber number
  let areaCode: string;
  let subscriberNumber: string;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (match) {
    areaCode = match[3];
    subscriberNumber = match[4];
  } else {
    const trunkMatch = cleaned.match(withTrunkPrefixRegex);
    if (!trunkMatch) {
      return false;
    }
    areaCode = trunkMatch[1];
    subscriberNumber = trunkMatch[2];
  }
  
  // Area code must be 2-4 digits with leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // If no country code (+54), the number must begin with trunk prefix (0)
  if (!cleaned.startsWith('+54') && !value.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Reject names that start or end with space, apostrophe, or hyphen
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  // Reject digits and symbols (except letters, spaces, apostrophes, hyphens, and unicode letters)
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject obviously invalid patterns like "X Æ A-12" (contains numbers)
  if (/\d/.test(value)) {
    return false;
  }
  
// Reject too many consecutive non-letter characters
  if (/['-]{2,}/.test(value)) {
    return false;
  }
  
  // Reject multiple spaces in a row
  if (/ {2,}/.test(value)) {
    return false;
  }
  
  // Check that there's at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Credit card number must be between 13 and 19 digits
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check valid prefixes and lengths for major cards
  const visaRegex = /^4\d{12}(\d{3})?$/;               // 13 or 16 digits, starts with 4
  const masterCardRegex = /^5[1-5]\d{14}$/;             // 16 digits, starts with 51-55
  const masterCardNewRegex = /^2(2[2-9]\d|3[0-5]\d|4[0-9]\d|5[01]\d|6[0-9]\d)\d{12}$/; // New Mastercard ranges
  const amexRegex = /^3[47]\d{13}$/;                    // 15 digits, starts with 34 or 37
  
  if (!visaRegex.test(cleaned) && 
      !masterCardRegex.test(cleaned) && 
      !masterCardNewRegex.test(cleaned) && 
      !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Luhn algorithm checksum
  return runLuhnCheck(cleaned);
}

// Helper function for Luhn algorithm
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
