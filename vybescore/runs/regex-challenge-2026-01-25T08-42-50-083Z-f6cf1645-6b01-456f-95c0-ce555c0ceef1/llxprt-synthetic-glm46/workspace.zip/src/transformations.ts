/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations that shouldn't trigger sentence capitalization
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'i.e', 'e.g', 'vs', 'p.m', 'a.m', 'U.S', 'U.K'];
  
  // First, collapse multiple spaces while preserving sentence breaks
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence endings when needed
  result = result.replace(/([.?!])(?=[a-zA-Z])/g, '$1 ');
  
  // Split into sentences using a more sophisticated approach
  // This handles potential abbreviations correctly
  let sentences: string[] = [];
  let sentenceStart = 0;
  
  for (let i = 0; i < result.length; i++) {
    const char = result[i];
    
    // Check if this is a sentence terminator (. ? !)
    if (char === '.' || char === '?' || char === '!') {
      // Look ahead to see if this likely ends a sentence (next character is space or end of string)
      const nextChar = result[i + 1];
      const nextNextChar = result[i + 2];
      
      // Handle abbreviation cases by checking common patterns
      const isAbbreviation = (i > 0 && result[i - 1] === '.') || // Check if it's part of an abbreviation
                            abbreviations.some(abbr => {
                              const index = result.lastIndexOf(abbr, i);
                              return index !== -1 && index + abbr.length === i &&
                                    !(nextChar === ' ' || nextChar === '\n' || 
                                      (nextChar === undefined && nextNextChar >= 'A' && nextNextChar <= 'Z'));
                            });
      
      // If not an abbreviation and next character signifies end of sentence, extract sentence
      if (!isAbbreviation && (nextChar === ' ' || nextChar === undefined || nextChar === '\n')) {
        const sentence = result.substring(sentenceStart, i + 1).trim();
        if (sentence.length > 0) {
          sentences.push(sentence);
          sentenceStart = i + 1;
          
          // Skip following space if present
          if (nextChar === ' ') {
            sentenceStart++;
          }
        }
      }
    }
  }
  
  // Add any remaining text as the last sentence
  if (sentenceStart < result.length) {
    const remaining = result.substring(sentenceStart).trim();
    if (remaining.length > 0) {
      sentences.push(remaining);
    }
  }
  
  // Capitalize the first character of each sentence
  sentences = sentences.map(sentence => {
    if (sentence.length === 0) {
      return sentence;
    }
    
    const firstChar = sentence.charAt(0);
    const rest = sentence.slice(1);
    
    // Capitalize first character if it's a letter
    if (firstChar >= 'a' && firstChar <= 'z') {
      return firstChar.toUpperCase() + rest;
    }
    
    return sentence;
  });
  
  // Join sentences back together with single spaces
  return sentences.join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http, https, www, and domain-only URLs
  // This regex is comprehensive but avoids the most problematic patterns
  const urlRegex = /https?:\/\/(www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b([-a-zA-Z0-9@:%_+.~#?&//=]*)/g;
  
  // Also match URLs starting with www. (http:// implied)
  const wwwRegex = /www\.[a-zA-Z0-9-]+\.[a-zA-Z0-9-._~:/?#[\]@!$&'()*+,;=%]*/g;
  
  // Find all matches
  const httpMatches = text.match(urlRegex) || [];
  const wwwMatches = text.match(wwwRegex) || [];
  
  // Combine and deduplicate
  const allMatches = [...httpMatches, ...wwwMatches];
  const uniqueMatches = Array.from(new Set(allMatches));
  
  // Remove trailing punctuation
  return uniqueMatches.map(url => url.replace(/[.,;:!?)\]}]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't touch https:// URLs
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match any URL with http:// or https:// scheme
  const urlRegex = /(https?:\/\/)([^/]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, protocol, host, path) => {
    // Always upgrade the scheme to https://
    const newProtocol = 'https://';
    
    // Check if we should skip host rewrite (dynamic hints or legacy extensions)
    const skipHostRewrite = 
      path.includes('cgi-bin') || 
      path.includes('?') || 
      path.includes('&') || 
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/i.test(path);
    
    // If the path begins with /docs/ and we should not skip host rewrite, rewrite the host
    if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Extract domain from host (e.g., "example.com" from "www.example.com")
      const domainMatch = host.match(/^(?:www\.)?([^:/]+)/);
      const domain = domainMatch ? domainMatch[1] : host;
      return newProtocol + 'docs.' + domain + path;
    }
    
    // Otherwise, just upgrade the scheme
    return newProtocol + host + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format where mm is 01-12, dd is valid day for that month
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for February leap year
  if (month === 2) {
    const isLeapYear = (parseInt(year) % 4 === 0 && parseInt(year) % 100 !== 0) || parseInt(year) % 400 === 0;
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
