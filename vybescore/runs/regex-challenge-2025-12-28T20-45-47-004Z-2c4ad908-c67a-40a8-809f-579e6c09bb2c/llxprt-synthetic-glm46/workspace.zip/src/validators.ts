

/**
 * Validates email addresses with proper format checks.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z]{2,})+$/;
  
  // Basic format check
  if (!emailRegex.test(email)) return false;
  
  // Reject double dots
  if (/\.\./.test(email)) return false;
  
  // Reject trailing dots in local part
  if (email.startsWith('.') || email.includes('@.')) return false;
  
  // Reject domains with underscores
  const domain = email.split('@')[1];
  if (domain && domain.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting (212) 555-7890, 212-555-7890, 2125557890,
 * with optional +1 prefix. Rejects impossible area codes (leading 0/1).
 */
export function isValidUSPhone(phone: string): boolean {
  // Remove all non-digit characters first
  const digits = phone.replace(/\D/g, '');

  // Handle optional +1 prefix
  if (digits.startsWith('1')) {
    if (digits.length === 11) {
      // 1 + area code + 7 digits
      const areaCode = digits.substring(1, 4);
      // Area code cannot start with 0 or 1
      if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
      return true;
    }
    return false; // Too long with +1 prefix
  }

  // Must be exactly 10 digits without country code
  if (digits.length !== 10) return false;

  const areaCode = digits.substring(0, 3);
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;

  return true;
}

/**
 * Validates Argentine phone numbers.
 * Supports landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 */
export function isValidArgentinePhone(phone: string): boolean {
  // Remove all non-digit characters
  const digits = phone.replace(/\D/g, '');

  // Handle with country code
  if (digits.startsWith('54')) {
    // +54 [optional 9] area_code subscriber_number
    const remaining = digits.substring(2); // Remove '54'

    // Handle optional mobile indicator 9
    let startIndex = 0;
    if (remaining.startsWith('9')) {
      startIndex = 1;
    }

    const afterCountryCode = remaining.substring(startIndex);

    // Area code must be 2-4 digits, leading digit 1-9
    let areaCodeLength = 2;
    for (; areaCodeLength <= 4; areaCodeLength++) {
      if (afterCountryCode.length >= areaCodeLength + 6) { // At least 6 subscriber digits
        const areaCode = afterCountryCode.substring(0, areaCodeLength);
        if (!areaCode.startsWith('0') && /^[1-9]\d*$/.test(areaCode)) {
          const subscriber = afterCountryCode.substring(areaCodeLength);
          // Subscriber number must be 6-8 digits
          if (subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber)) {
            return true;
          }
        }
      }
    }

    return false;
  }

  // Without country code - must start with trunk prefix 0
  if (!digits.startsWith('0')) return false;

  const afterTrunk = digits.substring(1); // Remove leading '0'

  // Area code must be 2-4 digits, leading digit 1-9
  for (let areaCodeLength = 2; areaCodeLength <= 4; areaCodeLength++) {
    if (afterTrunk.length >= areaCodeLength + 6) { // At least 6 subscriber digits
      const areaCode = afterTrunk.substring(0, areaCodeLength);
      if (!areaCode.startsWith('0') && /^[1-9]\d*$/.test(areaCode)) {
        const subscriber = afterTrunk.substring(areaCodeLength);
        // Subscriber number must be 6-8 digits
        if (subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber)) {
          return true;
        }
      }
    }
  }

  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(name: string): boolean {
  // Allow unicode letters (including accented), apostrophes, hyphens, and spaces
  // Reject digits, symbols, and non-name characters
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  return nameRegex.test(name.trim()) && name.trim().length > 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(cardNumber: string): boolean {
  // Remove non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  // Card length must be 13-19 digits
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check for valid prefixes (Visa, Mastercard, AmEx)
  const visaRegex = /^4/;
  const mastercardRegex = /^5[1-5]|^2(2[2-9]|[3-6]|7[01]|720)/;
  const amexRegex = /^3[47]/;
  
  if (!visaRegex.test(digits) && !mastercardRegex.test(digits) && !amexRegex.test(digits)) {
    return false;
  }
  
  // Luhn checksum algorithm
  let sum = 0;
  let shouldDouble = false;
  
  // Start from the rightmost digit
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
