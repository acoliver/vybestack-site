/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, add space after delimiters if needed
  const processedText = text.replace(/([.!?])(?=\S)/g, '$1 ');

  // Split to handle sentence by sentence
  // This regex splits on punctuation boundaries
  const sentences = processedText.split(/([.!?]\s+)/);

  let result = '';

  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];

    // Check if this is a sentence (not just punctuation)
    if (!/^[.!?]+$/.test(sentence) && sentence.trim()) {
      // Capitalize the first character
      const firstChar = sentence.charAt(0).toUpperCase();
      const rest = sentence.slice(1);
      result += firstChar + rest;
    } else {
      // This is punctuation, just add it
      result += sentence;
    }
  }

  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches URLs but doesn't match them if they have trailing punctuation
  const urlRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"')]+)(?=[^\w/.:-]|$)/gi;
  const urls: string[] = [];
  let match;

  while ((match = urlRegex.exec(text)) !== null) {
    urls.push(match[1].replace(/[^\w/.:-]+$/g, '')); // Remove trailing punctuation if any
  }

  return urls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/\bhttps?:\/\/example\.com(\/[^\s]*)/gi, (match, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';

    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /\/cgi-bin|[?&=&]/.test(path);
    const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/.test(path);

    if (path.startsWith('/docs/') && !hasDynamicHints && !hasLegacyExtensions) {
      // Rewrite the host to docs.example.com
      return newProtocol + 'docs.example.com' + path;
    }

    // Still upgrade protocol to https but don't change the host
    return newProtocol + 'example.com' + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Regular expression to extract mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.trim().match(dateRegex);

  if (match) {
    // Extract year part
    return match[3];
  }

  return 'N/A';
}
