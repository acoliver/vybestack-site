/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  const wordRegex = new RegExp(`\\b(${prefix}[a-zA-Z]*)\\b`, 'gi');
  
  const results: string[] = [];
  let match;
  
  while ((match = wordRegex.exec(text)) !== null) {
    const word = match[1].toLowerCase();
    
    // Check if the word is in the exceptions list
    const isException = exceptions.some(exception => word === exception.toLowerCase());
    
    if (!isException) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape any regex special characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Simple approach: find digit+token pattern
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const results: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Get the full match
    results.push(match[0]);
  }
  
  return results;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(password: string): boolean {
  // Password must be at least 10 characters
  if (password.length < 10) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(password)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(password)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(password)) return false;
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*(),.?":{}|<>]/.test(password)) return false;
  
  // Cannot contain whitespace
  if (/\s/.test(password)) return false;
  
  // Cannot contain immediate repeated sequences (like abab, 123123)
  const repeatedSequenceRegex = /(.{2,})\1/g;
  if (repeatedSequenceRegex.test(password)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(text: string): boolean {
  // IPv6 address pattern (simplified for broad matching)
  const ipv6Regex = /\b(([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}|(([0-9A-Fa-f]{1,4}:){1,6}:)|(([0-9A-Fa-f]{1,4}:){1,7}:)|(([0-9A-Fa-f]{1,4}:){1,5}(:[0-9A-Fa-f]{1,4}){1,2})|(([0-9A-Fa-f]{1,4}:){1,4}(:[0-9A-Fa-f]{1,4}){1,3})|(([0-9A-Fa-f]{1,4}:){1,3}(:[0-9A-Fa-f]{1,4}){1,4})|(([0-9A-Fa-f]{1,4}:){1,2}(:[0-9A-Fa-f]{1,4}){1,5})|([0-9A-Fa-f]{1,4}:((:[0-9A-Fa-f]{1,4}){1,6})|:((:[0-9A-Fa-f]{1,4}){1,7}|:))|(::[Ff]{4}:((25[0-5]|(2[0-4]|1\d)\d|[0-9]?\d)\.){3}(25[0-5]|(2[0-4]|1\d)\d|[0-9]?\d))|::[0-9A-Fa-f]{1,4}|:[0-9A-Fa-f]{1,4})\b/g;

  return ipv6Regex.test(text);
}
