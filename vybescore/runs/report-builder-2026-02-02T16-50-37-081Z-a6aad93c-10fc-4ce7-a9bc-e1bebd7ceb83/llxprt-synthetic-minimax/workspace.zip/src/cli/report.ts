#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { formatters } from '../formats/index.js';
import { CLIOptions, ReportData, ReportEntry } from '../types/report.js';

function parseArguments(args: string[]): CLIOptions {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputPath = args[0];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++;
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format option is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return {
    inputPath,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const jsonData = data as Record<string, unknown>;

  if (typeof jsonData.title !== 'string' || !jsonData.title.trim()) {
    throw new Error('Invalid JSON: "title" field is required and must be a non-empty string');
  }

  if (typeof jsonData.summary !== 'string' || !jsonData.summary.trim()) {
    throw new Error('Invalid JSON: "summary" field is required and must be a non-empty string');
  }

  if (!Array.isArray(jsonData.entries) || jsonData.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" field is required and must be a non-empty array');
  }

  const entries: ReportEntry[] = [];
  
  for (let i = 0; i < jsonData.entries.length; i++) {
    const entry = jsonData.entries[i];
    
    if (!entry || typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      throw new Error(`Invalid JSON: entries[${i}].label must be a non-empty string`);
    }

    if (typeof entryObj.amount !== 'number' || !isFinite(entryObj.amount)) {
      throw new Error(`Invalid JSON: entries[${i}].amount must be a finite number`);
    }

    entries.push({
      label: entryObj.label as string,
      amount: entryObj.amount as number
    });
  }

  return {
    title: jsonData.title as string,
    summary: jsonData.summary as string,
    entries
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const jsonData = JSON.parse(content);
    return validateReportData(jsonData);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file "${filePath}": ${error.message}`);
    } else if (error && typeof error === 'object' && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    } else if (error instanceof Error) {
      throw error;
    } else {
      throw new Error(`Failed to read file "${filePath}": ${error}`);
    }
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      throw new Error(`Failed to write output file "${outputPath}": ${error}`);
    }
  } else {
    process.stdout.write(content + (content.endsWith('\n') ? '' : '\n'));
  }
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const options = parseArguments(args);
    const reportData = loadReportData(options.inputPath);
    
    const formatter = formatters[options.format];
    const output = formatter.format(reportData, options.includeTotals);
    
    writeOutput(output, options.outputPath);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(message);
    process.exit(1);
  }
}

main();
