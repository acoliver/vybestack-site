import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { Formatter } from './markdown.js';

export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

export type SupportedFormat = keyof typeof formatters;