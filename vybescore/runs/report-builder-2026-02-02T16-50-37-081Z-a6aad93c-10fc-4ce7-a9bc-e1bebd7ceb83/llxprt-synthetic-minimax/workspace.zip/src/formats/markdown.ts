import { ReportData } from '../types/report.js';

export interface Formatter {
  format(data: ReportData, includeTotals: boolean): string;
}

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

export const renderMarkdown: Formatter = {
  format(data: ReportData, includeTotals: boolean): string {
    let output = `# ${data.title}\n\n`;
    output += `${data.summary}\n\n`;
    output += `## Entries\n`;
    
    for (const entry of data.entries) {
      output += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
    }
    
    if (includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      output += `\n**Total:** ${formatAmount(total)}`;
    }
    
    return output;
  }
};