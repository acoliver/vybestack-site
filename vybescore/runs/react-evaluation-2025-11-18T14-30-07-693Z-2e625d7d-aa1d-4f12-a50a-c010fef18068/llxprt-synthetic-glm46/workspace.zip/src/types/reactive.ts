/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverV<T = unknown> = {
  value?: T
  updateFn: UpdateFn<T>
  dirty?: boolean
  subjects?: Subject<T>[]
  observers?: Observer<T>[]
}

export type ObserverR = {
  name?: string
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR<T = unknown> = {
  name?: string
  observers: Observer<T>[]
}

export type SubjectV<T> = {
  value?: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR<T> & SubjectV<T>

// Computed subjects act as both observers and subjects
export type ComputedSubject<T> = Observer<T> & Subject<T> & {
  subjects: Subject<T>[]
  observers: Observer<T>[]
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): void {
  activeObserver = observer as Observer<unknown>
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
    observer.dirty = false
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observers || subject.observers.length === 0) return
  
  // Create a copy of observers to avoid issues if the array changes during iteration
  const currentObservers = [...subject.observers]
  
  // Update each observer
  currentObservers.forEach(observer => {
    if (observer.dirty !== undefined) {
      observer.dirty = true
      updateObserver(observer)
      
      // If observer is also a computed subject, notify its observers
      if (observer.subjects && observer.observers) {
        const subjectAsObserver = observer as Subject<T>
        notifyObservers(subjectAsObserver)
      }
    }
  })
}