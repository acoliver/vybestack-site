/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  ComputedSubject,
  Subject,
  Observer,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a computed that acts as both Observer and Subject
  const computed: ComputedSubject<T> = {
    name: options?.name,
    value,
    updateFn,
    dirty: true,
    subjects: [],  // dependencies
    observers: []  // dependents
  }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // If an observer is accessing this computed, track dependencies
    if (activeObserver && activeObserver !== computed) {
      // Ensure subjects array exists
      if (!activeObserver.subjects) activeObserver.subjects = []
      
      // Track this computed as a dependency of the active observer
      if (!activeObserver.subjects.includes(computed as Subject<unknown>)) {
        activeObserver.subjects.push(computed as Subject<unknown>)
      }
      
      // Register the active observer as dependent on this computed
      if (!computed.observers.includes(activeObserver as Observer<T>)) {
        computed.observers.push(activeObserver as Observer<T>)
      }
    }
    
    // Recompute if dirty
    if (computed.dirty || computed.value === undefined) {
      // Clear old dependencies
      computed.subjects = []
      
      // Set this as the active observer to capture dependencies during update
      setActiveObserver(computed)
      updateObserver(computed)
      
      computed.dirty = false
    }
    
    return computed.value as T
  }
  
  // Initial computation to establish dependencies
  updateObserver(computed)
  
  // Register this computed observer with all subjects it depends on
  if (computed.subjects) {
    computed.subjects.forEach((subject) => {
      if (!subject.observers.includes(computed)) {
        subject.observers.push(computed)
      }
    })
  }
  
  return getter
}