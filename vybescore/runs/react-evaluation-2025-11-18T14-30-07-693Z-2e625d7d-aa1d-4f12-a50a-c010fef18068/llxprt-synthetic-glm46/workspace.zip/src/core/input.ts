/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer with this subject
      if (!s.observers.includes(observer as Observer<T>)) {
        s.observers.push(observer as Observer<T>)
      }
      
      // Register this subject for the observer
      if (!observer.subjects) observer.subjects = []
      if (!observer.subjects.includes(s as Subject<unknown>)) {
        observer.subjects.push(s as Subject<unknown>)
      }
    }
    return s.value!
  }

  const write: SetterFn<T> = (nextValue) => {
    const changed = s.value !== nextValue
    s.value = nextValue
    if (changed) {
      notifyObservers(s as Subject<unknown>)
    }
    return s.value
  }

  return [read, write]
}