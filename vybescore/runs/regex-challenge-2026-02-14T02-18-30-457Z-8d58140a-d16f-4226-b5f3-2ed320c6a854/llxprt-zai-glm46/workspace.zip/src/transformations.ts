/**
 * Capitalize the first character of each sentence.
 * - Insert exactly one space between sentences if input omitted it
 * - Collapse extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Insert space after punctuation if missing
  normalized = normalized.replace(/([.!?])([a-z])/g, '$1 $2');
  
  // Capitalize first letter of string
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence boundaries (., !, ?)
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Extract URLs from text.
 * - Return all detected URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, ftp, ftps, www
  // Includes query strings and fragments
  // Excludes trailing punctuation (., ,, !, ;, :, ), ]) but not ? or = which are valid in URLs
  const urlPattern = /(?:https?:\/\/|ftp:\/\/|ftps:\/\/|www\.)[^\s<>,!;:()\]]+(?:[^\s<>,!;:()\]])/g;
  
  const matches = text.match(urlPattern);
  return matches || [];
}

/**
 * Force all http URLs to https.
 * - Leave already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for paths containing dynamic hints (cgi-bin, ?, &, =) or legacy extensions
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/...
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/g;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check for dynamic hints that should skip host rewrite
    const dynamicHints = ['cgi-bin', '?', '&', '='];
    const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    const hasLegacyExtension = legacyExtensions.some(ext => path.endsWith(ext));
    
    // If docs path and no dynamic hints/legacy extensions, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint && !hasLegacyExtension) {
      return newProtocol + 'docs.example.com' + path;
    }
    
    // Otherwise just upgrade protocol
    return newProtocol + host + path;
  });
}

/**
 * Extract year from mm/dd/yyyy format.
 * - Return 'N/A' if format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
