/**
 * Find words starting with prefix, excluding exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  // Word boundary at start, then prefix, then word characters
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of token after a digit, not at string start.
 * Uses lookahead/lookbehind
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: token preceded by digit AND token not at start of string
  // Include the digit in the match
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validate strong password.
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase, lowercase, digit, symbol
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  if (!/[a-z]/.test(value)) {
    return false;
  }
  if (!/\d/.test(value)) {
    return false;
  }
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (abab, abcabc, etc.)
  // Check for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);
      if (segment === nextSegment) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses, excluding IPv4.
 * - Supports shorthand (::)
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (supports shorthand ::)
  // Must have at least 2 colons for IPv6
  // Groups of hex digits separated by colons
  // Can have :: for shorthand
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}/;
  
  // Check for IPv6 addresses
  const ipv6Matches = value.match(ipv6Pattern);
  if (!ipv6Matches) {
    return false;
  }
  
  // Make sure we're not just seeing an IPv4 address
  // IPv4: ddd.ddd.ddd.ddd where d is 0-9
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  
  // Check each match to see if it's actually IPv6
  for (const match of ipv6Matches) {
    // IPv6 must contain colons and must not be a pure IPv4 format
    if (match.includes(':') && !ipv4Pattern.test(match.trim())) {
      return true;
    }
  }
  
  return false;
}
