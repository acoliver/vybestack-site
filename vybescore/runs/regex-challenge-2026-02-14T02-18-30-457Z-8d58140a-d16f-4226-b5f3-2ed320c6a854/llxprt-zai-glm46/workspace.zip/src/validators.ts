export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * - Reject double dots (..), trailing dots
 * - Reject domains with underscores
 * - Accept typical formats like name@tag@example.co.uk (subaddressing)
 */
export function isValidEmail(value: string): boolean {
  // Main pattern: local@domain.tld
  // Local part allows: letters, digits, dots, hyphens, underscores, plus
  // But no consecutive dots or trailing/leading dots
  // Domain: letters, digits, hyphens (no underscores), subdomains allowed
  const emailPattern = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~+-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~+-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional checks
  const [local, domain] = value.split('@');
  
  // No double dots in local part
  if (local.includes('..')) {
    return false;
  }
  
  // No trailing or leading dots in local part
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * - Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 country code
 * - Rejects area codes starting with 0 or 1
 * - Rejects invalid lengths
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Strip all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (area code 3 digits + prefix 3 digits + line number 4 digits = 10)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let number = digitsOnly;
  if (number.startsWith('1') && number.length > 10) {
    number = number.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (number.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = number.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  // Check for extensions if enabled
  if (options?.allowExtensions) {
    // Extensions are already handled by the digit stripping above
    return true;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * - Landlines and mobiles
 * - Optional country code +54
 * - Optional trunk prefix 0 (immediately before area code when country code omitted)
 * - Optional mobile indicator 9 (between country/trunk and area code)
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Separators: space or hyphen
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Try with +54 first
  // Pattern 1: +54 with 09 or 9 prefix (mobile)
  let match = /^\+54(?:09|9)([1-9]\d{1,3})(\d{6,8})$/.exec(cleaned);
  if (match) {
    const [, areaCode, subscriber] = match;
    // Mobile numbers need 7-8 digits
    if (areaCode.length >= 2 && areaCode.length <= 4 &&
        subscriber.length >= 7 && subscriber.length <= 8) {
      return true;
    }
  }
  
  // Pattern 2: +54 without prefix (landline, area code cannot start with 9)
  match = /^\+54([1-8]\d{1,3})(\d{6,8})$/.exec(cleaned);
  if (match) {
    const [, areaCode, subscriber] = match;
    if (areaCode.length >= 2 && areaCode.length <= 4 &&
        subscriber.length >= 6 && subscriber.length <= 8) {
      return true;
    }
  }
  
  // Try without +54 (requires trunk prefix 0)
  match = /^0(?:9)?([1-9]\d{1,3})(\d{6,8})$/.exec(cleaned);
  if (match) {
    const [, areaCode, subscriber] = match;
    if (areaCode.length >= 2 && areaCode.length <= 4 &&
        subscriber.length >= 6 && subscriber.length <= 8) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validate personal names.
 * - Allow unicode letters, accents, apostrophes, hyphens, spaces
 * - Reject digits, symbols, and "X Æ A-12" style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters (including accented), apostrophes, hyphens, spaces
  // Must have at least one letter
  // No digits, no special symbols except apostrophe and hyphen
  const namePattern = /^[\p{L}'\-\s]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers using Luhn checksum.
 * - Accept Visa (starts with 4, 13 or 16 digits)
 * - Accept Mastercard (starts with 51-55, 16 digits)
 * - Accept AmEx (starts with 34 or 37, 15 digits)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const digits = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Check length and prefix for known card types
  const visa = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercard = /^5[1-5]\d{14}$/; // 16 digits
  const amex = /^3[47]\d{13}$/; // 15 digits
  
  if (!visa.test(digits) && !mastercard.test(digits) && !amex.test(digits)) {
    return false;
  }
  
  // Luhn checksum
  return runLuhnCheck(digits);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
