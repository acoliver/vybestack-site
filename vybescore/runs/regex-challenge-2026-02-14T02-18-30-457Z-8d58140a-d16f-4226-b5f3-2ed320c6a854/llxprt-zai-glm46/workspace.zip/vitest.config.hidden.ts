import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/hidden/**/*.spec.ts'],
    environment: 'node',
    globals: true,
    resolve: {
      alias: {
        '@workspace': './src'
      }
    }
  }
});
