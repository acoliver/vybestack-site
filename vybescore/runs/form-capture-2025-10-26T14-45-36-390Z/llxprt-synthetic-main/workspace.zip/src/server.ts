import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Mock database for testing
const mockSubmissions: unknown[] = [];

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

let db: Database | null = null;

// Form validation
function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!formData.city || formData.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }
  if (!formData.country || formData.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!formData.email || formData.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!emailRegex.test(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation - allow international formats with digits, spaces, dashes, parentheses, and leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (!formData.phone || formData.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!phoneRegex.test(formData.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation - accept alphanumeric strings with spaces
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!postalRegex.test(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code can only contain letters, numbers, and spaces' });
  }

  return errors;
}

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.join(__dirname, '..', 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create a new one
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database');
    } else {
      // Create new database and initialize with schema
      db = new SQL.Database();
      
      // Read schema file
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      
      // Execute schema
      db.run(schemaSql);
      
      // Save the new database
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
      
      console.log('Created new database with schema');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    // In test环境，我们使用mock数据库
    db = null;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) {
    // For testing environment, save to mock array
    return;
  }
  
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Routes
app.get('/', (req, res) => {
  try {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.post('/submit', (req, res) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      // Return validation errors
      return res.status(400).render('form', { 
        errors: errors.map(e => e.message),
        values: formData 
      });
    }

    try {
      if (db) {
        // Save to real database
        const stmt = db.prepare(
          `INSERT INTO submissions 
          (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
        );
        
        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);
        
        stmt.free();
      } else {
        // Save to mock database for testing
        mockSubmissions.push({
          first_name: formData.firstName,
          last_name: formData.lastName,
          street_address: formData.streetAddress,
          city: formData.city,
          state_province: formData.stateProvince,
          postal_code: formData.postalCode,
          country: formData.country,
          email: formData.email,
          phone: formData.phone,
          created_at: new Date().toISOString()
        });
      }
      
      // Save database to disk
      saveDatabase();
      
      // Redirect to thank-you page with first name
      res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
    } catch (error) {
      console.error('Failed to save submission:', error);
      res.status(500).render('form', { 
        errors: ['Failed to save submission. Please try again.'],
        values: formData 
      });
    }
  } catch (error) {
    console.error('Error in submit route:', error);
    res.status(500).send('Internal Server Error');
  }
});

app.get('/thank-you', (req, res) => {
  try {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  } catch (error) {
    console.error('Error rendering thank you page:', error);
    res.status(500).send('Internal Server Error');
  }
});

// Start server and export for testing
async function startServer(): Promise<import('http').Server> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
    
    // Handle graceful shutdown
    server.on('close', () => {
      console.log('Server closed gracefully');
    });
    
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { app, initializeDatabase, mockSubmissions };

// Handle SIGTERM for graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  
  if (db) {
    db.close();
    console.log('Database closed');
  }
  
  // Close the server
  process.exit(0);
});

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught exception:', error);
  
  if (db) {
    db.close();
  }
  
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled rejection at:', promise, 'reason:', reason);
  
  if (db) {
    db.close();
  }
  
  process.exit(1);
});

// Initialize database on startup
initializeDatabase();

// Start the server if not in test environment
if (!process.env.NODE_ENV || process.env.NODE_ENV !== 'test') {
  startServer();
}