import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const __DIRNAME = path.resolve(__dirname, '..', '..');

let app: express.Express;
let server: import('http').Server;

beforeAll(async () => {
  // Create a simple test-only Express app directly in the test file
  app = express();
  app.use('/public', express.static(path.resolve(__DIRNAME, 'public')));
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__DIRNAME, 'src', 'templates'));
  
  // Create mock database for testing
  const mockSubmissions: Record<string, string>[] = [];
  
  // Form validation helper
  function validateForm(formData: Record<string, string>): string[] {
    const errors: string[] = [];
    
    if (!formData.firstName || formData.firstName.trim() === '') {
      errors.push('First name is required');
    }
    if (!formData.lastName || formData.lastName.trim() === '') {
      errors.push('Last name is required');
    }
    if (!formData.streetAddress || formData.streetAddress.trim() === '') {
      errors.push('Street address is required');
    }
    if (!formData.city || formData.city.trim() === '') {
      errors.push('City is required');
    }
    if (!formData.stateProvince || formData.stateProvince.trim() === '') {
      errors.push('State/Province/Region is required');
    }
    if (!formData.postalCode || formData.postalCode.trim() === '') {
      errors.push('Postal/Zip code is required');
    }
    if (!formData.country || formData.country.trim() === '') {
      errors.push('Country is required');
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!formData.email || formData.email.trim() === '') {
      errors.push('Email is required');
    } else if (!emailRegex.test(formData.email)) {
      errors.push('Please enter a valid email address');
    }
    
    // Phone validation - allow international formats
    if (!formData.phone || formData.phone.trim() === '') {
      errors.push('Phone number is required');
    }
    
    return errors;
  }
  
  // Routes
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  });

  app.post('/submit', (req, res) => {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      return res.status(400).render('form', { 
        errors,
        values: formData 
      });
    }

    // Save to mock database
    mockSubmissions.push({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone,
      created_at: new Date().toISOString()
    });
    
    // Redirect to thank-you page
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  });

  app.get('/thank-you', (req, res) => {
    const firstName = req.query.firstName as string || 'Friend';
    res.render('thank-you', { firstName });
  });
  
  // Start the server on a random port for testing
  server = app.listen(0);
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for form elements
    expect($('form[method="post"][action="/submit"]')).toHaveLength(1);
    
    // Check for required fields
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check for submit button
    expect($('button[type="submit"]')).toHaveLength(1);
    
    // Check for proper labels  
    const firstNameLabel = $('label').filter((i, el) => $(el).attr('for') === 'firstName');
    const lastNameLabel = $('label').filter((i, el) => $(el).attr('for') === 'lastName');
    const emailLabel = $('label').filter((i, el) => $(el).attr('for') === 'email');
    const phoneLabel = $('label').filter((i, el) => $(el).attr('for') === 'phone');
    
    expect(firstNameLabel).toHaveLength(1);
    expect(lastNameLabel).toHaveLength(1);
    expect(emailLabel).toHaveLength(1);
    expect(phoneLabel).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    const dbPath = path.resolve(__DIRNAME, 'data', 'submissions.sqlite');
    
    // Clean up before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'SW1A 1AA',  // Using UK postal code format
      country: 'Test Country',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'  // Using UK phone number format
    };
    
    const response = await request(app)
      .post('/submit')
      .set('Content-Type', 'application/x-www-form-urlencoded')
      .send(submissionData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    expect(response.headers.location).toContain('firstName=John');
    
    // Follow the redirect
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    expect($('h1').text()).toContain('John');
  });
});