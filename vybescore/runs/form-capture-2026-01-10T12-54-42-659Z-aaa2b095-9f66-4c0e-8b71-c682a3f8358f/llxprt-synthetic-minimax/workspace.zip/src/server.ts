import express, { Request, Response } from 'express';
import * as path from 'path';
import DatabaseManager from './database.js';
import { ContactFormValidator, ValidationResult } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('views', path.join(process.cwd(), 'src', 'templates'));
app.set('view engine', 'ejs');

// Database manager instance
const dbManager = new DatabaseManager();

// Initialize database on startup
async function initializeServer() {
  try {
    await dbManager.initialize();
    console.log(`Server starting on port ${PORT}`);
    
    const server = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });

    // Graceful shutdown handling
    const gracefulShutdown = async () => {
      console.log('Received shutdown signal, closing server...');
      try {
        await dbManager.close();
        server.close(() => {
          console.log('Server closed gracefully');
          process.exit(0);
        });
      } catch (error) {
        console.error('Error during graceful shutdown:', error);
        process.exit(1);
      }
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

  } catch (error) {
    console.error('Failed to initialize server:', error);
    process.exit(1);
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    data: {}, 
    errors: {} 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    // Extract form data
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate form data
    const validation: ValidationResult = ContactFormValidator.validate(formData);

    if (!validation.isValid) {
      // If validation fails, re-render form with errors
      return res.status(400).render('form', {
        data: formData,
        errors: validation.errors
      });
    }

    // Insert submission into database
    await dbManager.insertSubmission(formData);

    // Redirect to thank you page on successful submission
    res.redirect(302, '/thank-you');
    
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('form', {
      data: req.body,
      errors: { _global: 'An error occurred while processing your request. Please try again.' }
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Start the server
initializeServer();
