export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export class ContactFormValidator {
  private static readonly EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  private static readonly PHONE_REGEX = /^\+?[0-9\s\-()]+$/;

  static validate(data: Partial<ContactFormData>): ValidationResult {
    const errors: Record<string, string> = {};

    // Required field validation
    const requiredFields: Array<keyof ContactFormData> = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      const value = data[field];
      if (!value || typeof value !== 'string' || value.trim() === '') {
        errors[field] = `${this.formatFieldName(field)} is required`;
      }
    }

    // Email validation
    if (data.email && typeof data.email === 'string') {
      if (!this.EMAIL_REGEX.test(data.email)) {
        errors.email = 'Please enter a valid email address';
      }
    }

    // Phone validation
    if (data.phone && typeof data.phone === 'string') {
      // Validate international phone formats
      if (!this.PHONE_REGEX.test(data.phone)) {
        errors.phone = 'Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional +)';
      }
    }

    // Postal code validation (should accept alphanumeric)
    if (data.postalCode && typeof data.postalCode === 'string') {
      // Should accept alphanumeric including spaces (UK format) and alphanumeric only
      const postalPattern = /^[A-Za-z0-9\s-]+$/;
      if (!postalPattern.test(data.postalCode)) {
        errors.postalCode = 'Please enter a valid postal code (letters and numbers only)';
      }
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private static formatFieldName(field: string): string {
    return field
      .replace(/([A-Z])/g, ' $1') // Add space before capital letters
      .replace(/^./, str => str.toUpperCase()) // Capitalize first letter
      .trim();
  }
}