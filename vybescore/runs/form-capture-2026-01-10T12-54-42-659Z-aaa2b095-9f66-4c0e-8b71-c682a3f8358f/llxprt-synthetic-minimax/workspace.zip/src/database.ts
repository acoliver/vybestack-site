import initSqlJs, { Database as SqlJsDatabase, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: SqlJsDatabase | null = null;
  private dbPath: string;
  private schemaPath: string;
  private sqlJs: Promise<SqlJsStatic> | null = null;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  async initialize(): Promise<void> {
    try {
      // Initialize sql.js as a promise
      this.sqlJs = initSqlJs();

      let dbBuffer: Uint8Array | undefined;

      // Load existing database if it exists
      if (fs.existsSync(this.dbPath)) {
        const buffer = fs.readFileSync(this.dbPath);
        dbBuffer = new Uint8Array(buffer);
      }

      // Initialize database with or without existing data
      const sqlJsStatic = await this.sqlJs!;
      this.db = new sqlJsStatic.Database(dbBuffer);

      // Create table if it doesn't exist using schema
      const schema = fs.readFileSync(this.schemaPath, 'utf-8');
      this.db.exec(schema);

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  async insertSubmission(data: FormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const stmt = this.db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.bind([
        data.firstName,
        data.lastName,
        data.streetAddress,
        data.city,
        data.stateProvince,
        data.postalCode,
        data.country,
        data.email,
        data.phone
      ]);

      stmt.step();
      stmt.free();

      // Export database to file after insert
      await this.save();

      console.log('Submission inserted successfully');
      return this.db.getRowsModified();
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Export database to file
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db !== null) {
      try {
        await this.save();
        this.db.close();
        this.db = null;
        console.log('Database closed successfully');
      } catch (error) {
        console.error('Failed to close database:', error);
        throw error;
      }
    }
  }
}

export default DatabaseManager;