import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as path from 'path';
import * as fs from 'fs';
import { spawn, ChildProcess } from 'child_process';

let serverProcess: ChildProcess | null = null;
let baseUrl: string;

beforeAll(async () => {
  // Start the server as a child process
  const serverPath = path.resolve('dist', 'server.js');
  
  serverProcess = spawn('node', [serverPath], {
    env: { ...process.env, PORT: '3535' }
  });

  // Wait for server to start
  await new Promise((resolve) => {
    setTimeout(resolve, 3000); // Give server time to initialize
  });
  
  baseUrl = `http://localhost:${process.env.PORT || 3535}`;
});

afterAll(() => {
  if (serverProcess) {
    serverProcess.kill();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await request(baseUrl).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('firstName');
    expect(response.text).toContain('lastName');
    expect(response.text).toContain('streetAddress');
    expect(response.text).toContain('city');
    expect(response.text).toContain('stateProvince');
    expect(response.text).toContain('postalCode');
    expect(response.text).toContain('country');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
  });

  it('shows thank you page after successful submission', async () => {
    // Clean up any existing database
    const dbPath = path.resolve('data', 'submissions.sqlite');
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'Anystate',
      postalCode: '12345',
      country: 'Testland',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(baseUrl)
      .post('/submit')
      .send(testData);

    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('validates required fields and shows errors', async () => {
    // Submit empty form
    const response = await request(baseUrl)
      .post('/submit')
      .send({});

    // Should return 400 with form errors
    expect(response.status).toBe(400);
    expect(response.text).toContain('is required');
  });

  it('validates email format', async () => {
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'Anystate',
      postalCode: '12345',
      country: 'Testland',
      email: 'invalid-email', // Invalid email
      phone: '+1 555-123-4567'
    };

    const response = await request(baseUrl)
      .post('/submit')
      .send(testData);

    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });

  it('accepts international phone formats', async () => {
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'Anystate',
      postalCode: '12345',
      country: 'Testland',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958' // UK format
    };

    const response = await request(baseUrl)
      .post('/submit')
      .send(testData);

    expect(response.status).toBe(302);
  });

  it('accepts alphanumeric postal codes', async () => {
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'Anystate',
      postalCode: 'SW1A 1AA', // UK postal code
      country: 'Testland',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(baseUrl)
      .post('/submit')
      .send(testData);

    expect(response.status).toBe(302);
  });
});
