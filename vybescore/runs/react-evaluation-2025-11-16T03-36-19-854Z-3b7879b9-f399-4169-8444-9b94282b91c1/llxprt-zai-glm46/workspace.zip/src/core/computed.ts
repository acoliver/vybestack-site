/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'


function createDefaultEqualFn<T>(): EqualFn<T> {
  return (lhs: T, rhs: T) => lhs === rhs
}

function normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (equal === true) return createDefaultEqualFn<T>()
  if (equal === false) return undefined
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = normalizeEqualFn(equal)
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
  }
  
  // Set up the computed value
  const updateComputed = (currentValue?: T): T => {
    if (o.disposed) return currentValue!
    
    const observer = getActiveObserver()
    if (observer) {
      // Link observers to create dependency chain
      o.observer = observer
    }
    
    const newValue = updateFn(currentValue)
    const previousValue = o.value
    
    // Check if value actually changed
    const hasChanged = !equalFn || !equalFn(previousValue!, newValue!)
    if (hasChanged) {
      o.value = newValue
      
      // Trigger update for any observer watching this computed value
      if (o.observer && !o.observer.disposed) {
        // Use microtask to defer update and prevent cycles
        Promise.resolve().then(() => {
          if (o.observer && !o.observer.disposed) {
            updateObserver(o.observer as Observer<unknown>)
          }
        })
      }
    }
    
    return newValue
  }
  
  o.updateFn = updateComputed
  
  // Initialize by computing the value
  updateObserver(o)
  
  return (): T => {
    // Get the current observer (the one reading this computed value)
    const observer = getActiveObserver()
    if (observer) {
      // Link the observer to this computed value
      o.observer = observer
    }
    
    // Return the current value
    return o.value!
  }
}
