/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, UpdateFn, updateObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> & { disposed: boolean } = {
    value,
    updateFn,
    disposed: false,
  }
  
  // Create the actual callback function that executes side effects
  const executeCallback = (currentValue?: T): T => {
    if (observer.disposed) return currentValue!
    
    const active = getActiveObserver()
    if (active) {
      // Link this callback to the active observer to create dependency chain
      observer.observer = active
    }
    
    // Execute the side effect
    return updateFn(currentValue)
  }
  
  observer.updateFn = executeCallback
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Clear references to stop further updates and prevent memory leaks
    observer.value = undefined
    observer.observer = undefined
    observer.updateFn = () => value!
  }
}
