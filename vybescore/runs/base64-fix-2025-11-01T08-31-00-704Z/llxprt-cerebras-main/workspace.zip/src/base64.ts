/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding (=).
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws an error for invalid payloads.
 */
export function decode(input: string): string {
  // Validate Base64 format (allowing optional padding)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
