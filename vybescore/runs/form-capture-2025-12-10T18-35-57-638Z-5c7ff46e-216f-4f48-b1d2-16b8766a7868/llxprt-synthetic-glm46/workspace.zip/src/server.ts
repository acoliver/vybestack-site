import express from 'express';
import path from 'path';
import fs from 'fs';
import url from 'url';
import initSqlJs from 'sql.js';

const __dirname = path.dirname(url.fileURLToPath(import.meta.url));
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

// Initialize Express app
const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set up EJS engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// SQLite database instance
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any | null = null;

// Initialize database
async function initializeDatabase() {
  try {
    // Read schema
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Create or load database
    let dbBuffer: Buffer | null = null;
    
    try {
      // Try to load existing database
      dbBuffer = fs.readFileSync(dbPath);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SQL = (await initSqlJs()) as any;
    db = new SQL.Database(dbBuffer);
      console.log('Loaded existing database');
    } catch (err) {
      // Database doesn't exist, create new one
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const SQL = (await initSqlJs()) as any;
    db = new SQL.Database();
      console.log('Created new database');
      
      // Execute schema
      db!.exec(schema);
      console.log('Database schema initialized');
      
      // Save initial database
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase() {
  if (!db) return;
  
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Write database to disk
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Form validation
function validateForm(body: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required field validation
  if (!body.firstName?.trim()) errors.push('First name is required');
  if (!body.lastName?.trim()) errors.push('Last name is required');
  if (!body.streetAddress?.trim()) errors.push('Street address is required');
  if (!body.city?.trim()) errors.push('City is required');
  if (!body.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!body.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!body.country?.trim()) errors.push('Country is required');
  if (!body.email?.trim()) errors.push('Email is required');
  if (!body.phone?.trim()) errors.push('Phone number is required');
  
  // Email validation (simple regex)
  if (body.email && !emailPattern.test(body.email.trim())) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation (allows international formats)
  if (body.phone && !phonePattern.test(body.phone.trim())) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation (alphanumeric)
  if (body.postalCode && !postalCodePattern.test(body.postalCode.trim())) {
    errors.push('Please enter a valid postal code');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Validation patterns
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const phonePattern = /^[+]?[0-9\s()-]+$/;
const postalCodePattern = /^[a-zA-Z0-9\s-]+$/;

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const validationResult = validateForm(req.body);
  
  if (!validationResult.isValid) {
    return res.status(400).render('form', {
      errors: validationResult.errors,
      values: req.body
    });
  }
  
  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?
    `);
    
    stmt.run([
      req.body.firstName.trim(),
      req.body.lastName.trim(),
      req.body.streetAddress.trim(),
      req.body.city.trim(),
      req.body.stateProvince.trim(),
      req.body.postalCode.trim(),
      req.body.country.trim(),
      req.body.email.trim(),
      req.body.phone.trim()
    ]);
    
    stmt.free();
    
    // Save database
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you?' + new URLSearchParams({
      firstName: req.body.firstName.trim()
    }).toString());
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'there';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown() {
  console.log('\nStarting graceful shutdown...');
  
  if (db) {
    saveDatabase();
    // db.close();
    db = null;
    console.log('Database closed');
  }
  
  if (server) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (server as any).close(() => {
      console.log('Express server closed');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Start server
const port = process.env.PORT || 3535;
let server: unknown | null = null;

async function startServer() {
  await initializeDatabase();
  
  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle graceful shutdown
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});