import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initDatabase, closeDatabase, insertSubmission } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Determine the project root (works for both dev and compiled)
const isCompiled = __dirname.endsWith('dist');
const projectRoot = isCompiled ? path.join(__dirname, '..') : path.join(__dirname, '..');

const app = express();
const PORT = process.env.PORT || '3535';

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(projectRoot, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(projectRoot, 'src', 'views'));

// Types
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Phone numbers can contain digits, spaces, parentheses, dashes, and a leading +
  const phoneRegex = /^[+\d\s()\-,+]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Postal codes accept alphanumeric strings (UK "SW1A 1AA", Argentine "C1000" or "B1675")
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateRequired(value: string): boolean {
  return typeof value === 'string' && value.trim().length > 0;
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!formData.firstName || !validateRequired(formData.firstName)) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!formData.lastName || !validateRequired(formData.lastName)) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!formData.streetAddress || !validateRequired(formData.streetAddress)) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!formData.city || !validateRequired(formData.city)) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!formData.stateProvince || !validateRequired(formData.stateProvince)) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!formData.postalCode || !validateRequired(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code contains invalid characters' });
  }

  if (!formData.country || !validateRequired(formData.country)) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!formData.email || !validateRequired(formData.email)) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!formData.phone || !validateRequired(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number contains invalid characters' });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('index', {
      errors,
      formData
    });
  }

  // Insert into database
  insertSubmission({
    first_name: formData.firstName!,
    last_name: formData.lastName!,
    street_address: formData.streetAddress!,
    city: formData.city!,
    state_province: formData.stateProvince!,
    postal_code: formData.postalCode!,
    country: formData.country!,
    email: formData.email!,
    phone: formData.phone!
  });

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
async function shutdown() {
  console.log('\nShutting down gracefully...');
  await closeDatabase();
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start() {
  try {
    await initDatabase();
    const server = app.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Auto-start if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  start();
}

export { app, start, shutdown };
