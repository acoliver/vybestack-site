/**
 * Encode plain text to Base64 using the canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Remove whitespace and validate Base64 format
  const trimmed = input.replace(/\s/g, '');
  
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }

  // Check for invalid padding
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end and can be 1 or 2 characters
    const paddingChars = trimmed.slice(paddingIndex);
    if (!/^(={1,2})$/.test(paddingChars)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Check if padding length is valid - total length must be divisible by 4
    if (trimmed.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect padding length');
    }
  } else {
    // No padding - allow Node.js to handle it since Buffer supports unpadded Base64
    // Node.js Buffer can decode unpadded Base64 strings successfully
  }

  try {
    return Buffer.from(trimmed, 'base64').toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}