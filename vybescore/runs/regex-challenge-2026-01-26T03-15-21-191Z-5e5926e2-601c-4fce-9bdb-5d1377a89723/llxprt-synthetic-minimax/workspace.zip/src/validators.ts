export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Supports typical formats like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for common invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot
  if (value.endsWith('.')) {
    return false;
  }
  
  // Extract domain part and check for underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, /* eslint-disable @typescript-eslint/no-unused-vars */ _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have 10 or 11 digits (with optional country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Strip country code if present to validate national number
  const nationalDigits = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Validate format with common US phone patterns
  const phoneRegex = /^\+?1?[\s-.]?\(?([2-9][0-9]{2})\)?[\s-.]?([0-9]{3})[\s-.]?([0-9]{4})$/;
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  // Extract area code from the cleaned number
  const areaCode = nationalDigits.substring(0, 3);
  
  // Reject impossible area codes (leading 0 or 1)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other separators for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if number starts with +54 (country code) or 0 (trunk prefix)
  const hasCountryCode = cleanValue.startsWith('+54');
  const hasTrunkPrefix = cleanValue.startsWith('0');
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Extract the relevant part of the number
  let remainingNumber = cleanValue;
  if (hasCountryCode) {
    remainingNumber = remainingNumber.slice(3); // Remove +54
  }
  
  // Check for mobile indicator (9) after country code
  if (hasCountryCode && remainingNumber.startsWith('9')) {
    remainingNumber = remainingNumber.slice(1); // Remove mobile indicator
  }
  
  // Now we should have area code + subscriber number
  if (remainingNumber.length < 8 || remainingNumber.length > 12) {
    return false;
  }
  
  // Parse area code and subscriber number
  const areaCodeLength = remainingNumber.length <= 9 ? 2 : remainingNumber.length <= 10 ? 3 : 4;
  const areaCode = remainingNumber.substring(0, areaCodeLength);
  const subscriberNumber = remainingNumber.substring(areaCodeLength);
  
  // Validate area code: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  if (!/^[0-9]+$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  if (!/^[0-9]+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for obviously invalid patterns first
  // Reject names containing digits
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  // Reject stylized patterns like "X Æ A-12"
  if (/[ÆŒ]/i.test(value)) {
    return false;
  }
  
  // Must start with a letter
  if (!/^[\p{L}]/u.test(value)) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Pattern matches: start with letter, followed by allowed characters
  const nameRegex = /^[\p{L}]+(?:[\s'-][\p{L}]+)*$/u;
  
  // Additional check: no immediate repeated sequences (like abab)
  if (/([a-zA-Z]{2,})\1/i.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
// Helper function to run Luhn checksum
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers using prefix checks and Luhn algorithm
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Must have reasonable length for credit card
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check card type prefixes and lengths
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercardRegex = /^5[1-5][0-9]{14}$/;
  const amexRegex = /^3[47][0-9]{13}$/;
  
  let isValidCardType = false;
  
  if (visaRegex.test(digits)) {
    // Visa: 13, 16, or 19 digits starting with 4
    isValidCardType = true;
  } else if (mastercardRegex.test(digits)) {
    // Mastercard: 16 digits starting with 51-55
    isValidCardType = true;
  } else if (amexRegex.test(digits)) {
    // AmEx: 15 digits starting with 34 or 37
    isValidCardType = true;
  }
  
  if (!isValidCardType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
