/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a pattern that matches words starting with the prefix
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const results = matches.filter(word => {
    const cleanWord = word.toLowerCase();
    const normalizedPrefix = prefix.toLowerCase();
    return !exceptions.some(exception => 
      cleanWord.startsWith(normalizedPrefix) && 
      cleanWord === exception.toLowerCase()
    );
  });
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token that appears after a digit and not at start of string
  // Should return the full occurrence (digit + token) like "1foo"
  // Example: 'xfoo 1foo foo' with token 'foo' should return ['1foo']
  
  // Use capturing group to get digit + token combination
  const pattern = new RegExp(`(?<!^)(\\d)${token}`, 'g');
  
  // Find matches where digit is followed by token (not at start of string)
  const matches = text.match(pattern) || [];
  
  // Return the full occurrences (digit + token)
  return matches.map(match => match);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Must not have immediate repeated sequences (like abab)
  // Check for patterns like abab, 1212, etc.
  if (/(.{2,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, reject if it's clearly an IPv4 address
  // IPv4 pattern: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 addresses can have various formats:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shortened with ::: 2001:db8::1
  // - Mixed with IPv4: ::ffff:192.168.1.1
  // - No leading zeros required
  
  // Pattern for IPv6 with proper structure
  // Handles shortened notation (::) and full notation
  const ipv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)$/i;
  
  // Simple check: if string contains colons and not dots, likely IPv6
  if (value.includes(':') && !value.includes('.')) {
    // Basic validation: must have proper number of groups when split by colons
    const groups = value.split(':');
    if (groups.length >= 3 && groups.length <= 8) {
      // Check if all groups are valid hex (except for :: shorthand)
      const isValidIPv6 = groups.every(group => 
        group === '' || /^[0-9a-fA-F]*$/.test(group)
      );
      if (isValidIPv6) {
        return true;
      }
    }
  }
  
  // Check for mixed IPv6/IPv4 format (like ::ffff:192.168.1.1)
  if (value.includes(':') && value.includes('.')) {
    // Pattern for IPv4-mapped IPv6
    const mixedPattern = /^::(ffff:)?([0-9]{1,3}\.){3}[0-9]{1,3}$/i;
    if (mixedPattern.test(value)) {
      return true;
    }
  }
  
  // Use regex pattern as final check
  return ipv6Pattern.test(value);
}
