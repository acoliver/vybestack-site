/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces - collapse multiple spaces to single
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Use regex to find sentence endings and process
  return normalized.replace(/(^|[.!?]\s*)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern to match common URL formats
  const urlPattern = /\b(?:(?:https?|ftp):\/\/|www\.)[^\s<>"']+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that commonly follows URLs in text
    return url.replace(/[.,!?;:)\]]+$/, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only if it's not already https
  // First check if it's already https:// to avoid double replacement
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with capture groups
  const urlPattern = /http:\/\/([^/]+)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, host, path) => {
    // Always upgrade to https
    let newUrl = `https://${host}${path}`;
    
    // Check if path contains dynamic hints that should preserve the original host
    const dynamicHints = /(?:cgi-bin|\?[^\s]*|&[^\s]*|=[^\s]*|\.(?:jsp|php|asp|aspx|do|cgi|pl|py))/i;
    
    if (path.startsWith('/docs/') && !dynamicHints.test(path)) {
      // Rewrite host to docs.example.com for docs paths without dynamic hints
      const domainMatch = host.match(/^([^.]+\.[^.]+)/);
      if (domainMatch) {
        const baseDomain = domainMatch[1];
        newUrl = `https://docs.${baseDomain}${path}`;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on the month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2 && ((parseInt(year) % 4 === 0 && parseInt(year) % 100 !== 0) || parseInt(year) % 400 === 0)) {
    if (day < 1 || day > 29) {
      return 'N/A';
    }
  } else if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
