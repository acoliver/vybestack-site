#!/usr/bin/env node

/**
 * Main CLI entry point for the Report Builder tool.
 * Parses command-line arguments, validates input, and renders reports.
 */

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIOptions {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(argv: string[]): CLIOptions {
  let dataPath = '';
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Skip node and script path
  for (let i = 2; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg.startsWith('--')) {
      const key = arg.slice(2);
      const nextArg = argv[i + 1];
      
      if (nextArg && !nextArg.startsWith('--')) {
        if (key === 'format') {
          format = nextArg;
        } else if (key === 'output') {
          outputPath = nextArg;
        }
        i++;
      } else {
        if (key === 'includeTotals') {
          includeTotals = true;
        }
      }
    } else {
      dataPath = arg;
    }
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const report = data as Record<string, unknown>;

  // Validate title
  if (typeof report.title !== 'string' || report.title.trim() === '') {
    throw new Error('Invalid report data: title must be a non-empty string');
  }

  // Validate summary
  if (typeof report.summary !== 'string' || report.summary.trim() === '') {
    throw new Error('Invalid report data: summary must be a non-empty string');
  }

  // Validate entries
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  const entries = report.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${index} must be an object`);
    }

    const item = entry as Record<string, unknown>;

    if (typeof item.label !== 'string' || item.label.trim() === '') {
      throw new Error(`Invalid report data: entry at index ${index} must have a non-empty label`);
    }

    if (typeof item.amount !== 'number' || !isFinite(item.amount)) {
      throw new Error(`Invalid report data: entry at index ${index} must have a valid amount`);
    }

    return {
      label: item.label,
      amount: item.amount
    };
  });

  return {
    title: report.title,
    summary: report.summary,
    entries
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid report data:')) {
        throw error;
      }
      if (error.message.startsWith('ENOENT:')) {
        throw new Error(`Cannot read file: ${filePath}`);
      }
      throw new Error(`Failed to parse JSON: ${error.message}`);
    }
    throw new Error('Unknown error while loading data');
  }
}

function getFormatter(format: string) {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const options = parseArguments(process.argv);
    
    const data = loadReportData(options.dataPath);
    const formatter = getFormatter(options.format);
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals
    };

    const output = formatter(data, renderOptions);

    if (options.outputPath) {
      writeFileSync(options.outputPath, output);
      process.exit(0);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    }
    console.error('An unknown error occurred');
    process.exit(1);
  }
}

main();