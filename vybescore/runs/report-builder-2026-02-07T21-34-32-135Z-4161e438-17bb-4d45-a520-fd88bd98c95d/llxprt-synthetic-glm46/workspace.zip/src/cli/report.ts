#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, FormatOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

function parseArgs(): { dataPath: string; format: string; outputPath?: string; includeTotals: boolean; } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataPath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    return false;
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string' || typeof reportData.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(reportData.entries)) {
    return false;
  }
  
  for (const entry of reportData.entries) {
    if (typeof entry !== 'object' || !entry) {
      return false;
    }
    
    const entryData = entry as Record<string, unknown>;
    
    if (typeof entryData.label !== 'string' || typeof entryData.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function main(): void {
  const { dataPath, format, outputPath, includeTotals } = parseArgs();
  
  try {
    const fileContent = readFileSync(dataPath, 'utf8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      console.error('Error: Invalid report data format');
      process.exit(1);
    }
    
    const options: FormatOptions = { includeTotals };
    
    const formatter = format === 'markdown' ? markdownFormatter : textFormatter;
    const output = formatter.render(data, options);
    
    if (outputPath) {
      writeFileSync(outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON format');
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    process.exit(1);
  }
}

main();
