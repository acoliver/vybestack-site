/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  // Use standard base64 encoding (not base64url) and preserve padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard Base64 decoding.
 */
export function decode(input: string): string {
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  // Validate input length is compatible with Base64 (0, 2, or 3 remainder)
  // Remainder 1 is invalid (would need 3 padding chars, but base64 doesn't use that)
  const modulo = normalized.length % 4;
  if (modulo === 1) {
    throw new Error('Invalid Base64 input: length remainder must be 0, 2, or 3');
  }
  
  // Validate characters are in Base64 alphabet
  const validChars = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validChars.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
