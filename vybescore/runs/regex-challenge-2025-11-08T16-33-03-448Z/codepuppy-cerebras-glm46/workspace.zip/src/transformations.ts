/**
 * Capitalize the first character of each sentence after punctuation marks.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible and maintains sensible spacing.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Trim leading/trailing whitespace and normalize internal whitespace
  const result = text.trim().replace(/\s+/g, ' ')
  
  // Split into sentences, handling abbreviations carefully
  // We'll use a more nuanced approach to avoid splitting after common abbreviations
  const sentences: string[] = [];
  let currentSentence = '';
  
  for (let i = 0; i < result.length; i++) {
    const char = result[i];
    currentSentence += char;
    
    // Check if we have sentence-ending punctuation
    if (/[.?!]/.test(char)) {
      // Check if this might be an abbreviation (simplified check)
      const nextChar = i < result.length - 1 ? result[i + 1] : '';
      
      // Don't split if punctuation is followed by a lowercase letter (likely abbreviation)
      if (nextChar && /[a-z]/.test(nextChar)) {
        continue;
      }
      
      // Don't split for common abbreviations like Mr., Dr., etc.
      const wordsBefore = result.substring(Math.max(0, i - 5), i).toLowerCase();
      const isAbbreviation = /^(mr|ms|mrs|dr|prof|sr|jr|st|etc|e\.g|i\.e|vs)\.$/.test(wordsBefore);
      
      if (!isAbbreviation) {
        sentences.push(currentSentence);
        currentSentence = '';
        // Skip any whitespace after punctuation
        while (i + 1 < result.length && /\s/.test(result[i + 1])) {
          i++;
        }
      }
    }
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence);
  }
  
  // Capitalize each sentence and join with single spaces
  const capitalizedSentences = sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return '';
    
    // Find the first letter to capitalize
    const firstLetterIndex = trimmed.search(/[a-zA-Z]/);
    if (firstLetterIndex === -1) return trimmed;
    
    const before = trimmed.substring(0, firstLetterIndex);
    const letter = trimmed[firstLetterIndex].toUpperCase();
    const after = trimmed.substring(firstLetterIndex + 1);
    
    return before + letter + after;
  });
  
  return capitalizedSentences.join(' ');
}

/**
 * Extract all URLs from text without trailing punctuation.
 * Supports http, https, ftp protocols and various domain formats.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // Comprehensive URL regex pattern
  const urlRegex = /\b((?:https?|ftp):\/\/[^\s<>"']+(?=\b|$))/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation that's unlikely to be part of the URL
    return url.replace(/[.,;:!?)\]\}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Replace all http:// URL schemes with https:// while leaving existing https URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Use negative lookbehind to avoid matching https://
  // Replace http:// with https:// when not preceded by 's'
  return text.replace(/(?<!s)http:\/\//g, 'https://');
}

/**
 * Rewrite URLs with complex rules for example.com documentation paths.
 * - Always upgrade to https://
 * - Move /docs/ paths to docs.example.com host
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }

  // Regex to match example.com URLs
  // Captures: protocol, subdomain, path, query
  const exampleUrlRegex = /(https?):\/\/((?:www\.)?example\.com)(\/[^\s]*?)(\?[^\s]*)?(?=[\s<>"']|$)/gi;
  
  return text.replace(exampleUrlRegex, (match, protocol, domain, path, query) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if we should skip the docs rewrite
    const skipDocsRewrite = /(?:cgi-bin|[?&=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/i.test(path + (query || ''));
    
    if (path.startsWith('/docs/') && !skipDocsRewrite) {
      // Rewrite to docs.example.com, keep the docs path
      return `${newProtocol}://docs.example.com${path}${query || ''}`;
    } else {
      // Just upgrade the protocol
      return `${newProtocol}://${domain}${path}${query || ''}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' for invalid formats or dates.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Strict regex for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (simplified - not considering century rules)
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  
  let maxDays = daysInMonth[monthNum - 1];
  if (monthNum === 2 && isLeapYear) {
    maxDays = 29;
  }
  
  if (dayNum > maxDays) {
    return 'N/A';
  }
  
  return year;
}
