export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses supporting typical formats while rejecting common invalid patterns.
 * Accepts: name+tag@example.co.uk, user.name@domain.com
 * Rejects: double dots, trailing dots, domains with underscores, consecutive @ symbols
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Core email regex with strict validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check basic format first
  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional validation rules
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }

  // No trailing dot in local or domain part
  if (value.endsWith('.')) {
    return false;
  }

  // No leading or trailing dots in local part
  const [localPart, domainPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  // No underscores in domain part
  if (domainPart.includes('_')) {
    return false;
  }

  // Domain must have at least one dot
  if (!domainPart.includes('.')) {
    return false;
  }

  // Domain labels must be valid
  const domainLabels = domainPart.split('.');
  for (const label of domainLabels) {
    if (label.length === 0 || label.length > 63) {
      return false;
    }
    // Domain labels cannot start or end with hyphen
    if (label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
  }

  // Top-level domain must be at least 2 characters
  const tld = domainLabels[domainLabels.length - 1];
  if (tld.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting various formats.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
 * Rejects: area codes starting with 0/1, invalid patterns, too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, 11 if includes country code)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }

  // If 11 digits, must start with +1
  if (digits.length === 11 && !digits.startsWith('1')) {
    return false;
  }

  // Extract the 10-digit US number (remove country code if present)
  const usNumber = digits.length === 11 ? digits.slice(1) : digits;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = usNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Central office code (next 3 digits) cannot start with 0 or 1
  const centralOffice = usNumber.slice(3, 6);
  if (centralOffice[0] === '0' || centralOffice[0] === '1') {
    return false;
  }

  // Validate format using regex
  const phoneRegex = /^(\+1[\s.-]?)?(\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  
  return phoneRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Accepts: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules: Optional +54, optional trunk prefix 0, optional mobile indicator 9,
 * area code 2-4 digits (leading 1-9), subscriber number 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Regex pattern for Argentine phone numbers
  // ^(?:\+54)? - Optional country code
  // 0? - Optional trunk prefix (when no country code)
  // 9? - Optional mobile indicator
  // ([2-9]\d{1,3}) - Area code: 2-4 digits, leading digit 1-9
  // (\d{6,8})$ - Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(0?)(9?)([2-9]\d{1,3})(\d{6,8})$/;
  
  const match = digits.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const [, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // When country code is omitted, trunk prefix must be present
  if (!digits.startsWith('54') && !trunkPrefix) {
    return false;
  }
  
  // When country code is present, trunk prefix should not be present
  if (digits.startsWith('54') && trunkPrefix) {
    return false;
  }

  // Area code must be 2-4 digits (already enforced by regex)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Subscriber number must be 6-8 digits (already enforced by regex)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // Total digits should be reasonable (10-12 digits including country code)
  if (digits.length < 10 || digits.length > 13) {
    return false;
  }

  return true;
}

/**
 * Validate personal names supporting unicode letters, accents, apostrophes, hyphens, and spaces.
 * Accepts: Jean-Claude Van Damme, María José, O'Connor
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check for empty or whitespace-only names
  if (value.trim().length === 0) {
    return false;
  }

  // Unicode letter pattern that supports:
  // - Basic letters (A-Z, a-z)
  // - Accented letters (Unicode \p{L})
  // - Apostrophes for names like O'Connor
  // - Hyphens for hyphenated names
  // - Spaces for multi-part names
  // Names must contain at least one letter
  const nameRegex = /^[\p{L}][\p{L}'\s-]*[\p{L}]$/u;
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }

  // Additional validation: reject names with digits
  if (/\d/.test(value)) {
    return false;
  }

  // Reject names with consecutive punctuation
  if (/['][']|[-][-]/.test(value)) {
    return false;
  }

  // Reject names that start or end with apostrophe or hyphen
  const trimmed = value.trim();
  if (trimmed.startsWith("'") || trimmed.endsWith("'") || 
      trimmed.startsWith('-') || trimmed.endsWith('-')) {
    return false;
  }

  // Reject names with multiple consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }

  // Must contain at least one letter (beyond what regex ensures)
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and American Express.
 * Uses Luhn checksum validation and card-specific rules.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens
  const cleanCard = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cleanCard)) {
    return false;
  }

  // Visa: 13, 16, or 19 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15}|\d{18})$/;
  
  // Mastercard: 16 digits, starts with 51-55, 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  // Check card format
  const isValidFormat = visaRegex.test(cleanCard) || 
                       mastercardRegex.test(cleanCard) || 
                       amexRegex.test(cleanCard);
  
  if (!isValidFormat) {
    return false;
  }

  // Luhn checksum validation
  return runLuhnCheck(cleanCard);
}

/**
 * Helper function to perform Luhn algorithm checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
