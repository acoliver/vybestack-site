/**
 * Find words beginning with the specified prefix, excluding listed exceptions.
 * Uses word boundaries and case-insensitive matching.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }

  // Split text into words using simple word boundaries
  const words = text.match(/\b\w+\b/g) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter words that start with the prefix and aren't in exceptions
  const results = words
    .filter(word => word.toLowerCase().startsWith(prefix.toLowerCase()))
    .map(word => word.toLowerCase())
    .filter(word => !lowerExceptions.includes(word))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
  
  return results;
}

/**
 * Find token occurrences that appear after a digit and not at string start.
 * Returns the full token including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }

  // Find all occurrences of the token
  const results: string[] = [];
  let index = text.indexOf(token);
  
  while (index !== -1) {
    // Check if token is not at the start of string
    if (index > 0) {
      // Check if the character before the token is a digit
      const prevChar = text[index - 1];
      if (/\d/.test(prevChar)) {
        // Include the digit in the result
        results.push(prevChar + token);
      }
    }
    
    // Find next occurrence
    index = text.indexOf(token, index + 1);
  }
  
  return results;
}

/**
 * Validate password strength with complex requirements.
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., 'abab' should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Minimum length requirement
  if (value.length < 10) {
    return false;
  }

  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }

  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\|,.<>\/?]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (like 'abab')
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment1 = value.substring(i, i + len);
      const segment2 = value.substring(i + len, i + len * 2);
      
      if (segment1 === segment2) {
        return false;
      }
    }
  }

  // Check for longer repeated patterns (optional, more comprehensive)
  // This catches things like 'abcabc' or '123123'
  const repeatedPatternRegex = /(.{2,})\1+/;
  if (repeatedPatternRegex.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detect IPv6 addresses including shorthand notation (::), excluding IPv4 addresses.
 * Supports various IPv6 formats: full, zero-compressed, embedded IPv4, etc.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv4 regex to ensure we don't match IPv4 addresses
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If the entire string is a valid IPv4 address, return false
  if (ipv4Regex.test(value.trim())) {
    return false;
  }

  // IPv6 regex patterns (use word boundaries to avoid partial matches)
  
  // Standard IPv6: 8 groups of 1-4 hex digits
  const standardIpv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Zero-compressed IPv6 with :: (various group counts)
  const compressedIpv6 = /\b(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: at start or end
  const edgeCompressedIpv6 = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::\b/;
  
  // IPv6 with embedded IPv4
  const ipv6WithIpv4 = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check if any IPv6 pattern matches
  return standardIpv6.test(value) || 
         compressedIpv6.test(value) || 
         edgeCompressedIpv6.test(value) || 
         ipv6WithIpv4.test(value);
}
