

/**
 * Encode plain text to Base64.
 * Uses standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Uses standard Base64 alphabet with proper validation.
 */
export function decode(input: string): string {
  try {
    // Remove any whitespace that might have been added
    const cleaned = input.replace(/\s/g, '');
    
    // Validate that the input contains only valid Base64 characters
    // Valid Base64 characters: A-Z, a-z, 0-9, +, /, and padding = 
    if (!/^[A-Za-z0-9+/]*={0,2}$/.test(cleaned)) {
      throw new Error('Invalid Base64 input: contains illegal characters');
    }
    
    // Check that padding is at the end and properly formatted
    const paddingMatch = cleaned.match(/=+$/);
    if (paddingMatch) {
      const padding = paddingMatch[0].length;
      // Valid padding lengths are 1 or 2, and must be at the end
      if (padding > 2) {
        throw new Error('Invalid Base64 input: too much padding');
      }
    }
    
    return Buffer.from(cleaned, 'base64').toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.startsWith('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
