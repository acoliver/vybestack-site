#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { validateReportData, type CLIOptions, type ReportData } from '../types.js';

function printErrorAndExit(message: string): never {
  console.error(message);
  process.exit(1);
}

function parseArguments(): CLIOptions {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    printErrorAndExit('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  if (!dataPath.endsWith('.json')) {
    printErrorAndExit('Input file must be a JSON file');
  }

  let format: 'markdown' | 'text' | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse named arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        printErrorAndExit('--format requires a value (markdown or text)');
      }
      
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        printErrorAndExit(`Unsupported format: ${nextArg}`);
      }
      
      format = nextArg as 'markdown' | 'text';
      i++; // Skip the value argument
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        printErrorAndExit('--output requires a file path');
      }
      outputPath = nextArg;
      i++; // Skip the value argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      printErrorAndExit(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    printErrorAndExit('--format is required (markdown or text)');
  }

  return {
    format,
    outputPath,
    includeTotals
  };
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    if (!validateReportData(data)) {
      printErrorAndExit('Invalid report data structure');
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        printErrorAndExit(`File not found: ${filePath}`);
      } else if (error.message.includes('JSON')) {
        printErrorAndExit('Invalid JSON in input file');
      } else {
        printErrorAndExit(error.message);
      }
    }
    printErrorAndExit('Failed to load input data');
  }
}

function renderReport(options: CLIOptions, dataPath: string): string {
  const data = loadAndValidateData(dataPath);
  const renderOptions = {
    ...options,
    data
  };

  if (options.format === 'markdown') {
    return renderMarkdown(renderOptions);
  } else {
    return renderText(renderOptions);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      printErrorAndExit(`Failed to write output file: ${outputPath}`);
    }
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const options = parseArguments();
    const dataPath = process.argv[2];
    
    if (!dataPath) {
      printErrorAndExit('Input JSON file path is required');
    }

    const report = renderReport(options, dataPath);
    writeOutput(report, options.outputPath);
  } catch (error) {
    if (error instanceof Error) {
      printErrorAndExit(error.message);
    }
    printErrorAndExit('An unexpected error occurred');
  }
}

main();
