import { RenderOptions, formatAmount, calculateTotal } from '../types.js';

export function renderText(options: RenderOptions): string {
  const { data, includeTotals } = options;
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  
  // Render each entry
  data.entries.forEach(entry => {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  });

  // Total if requested
  if (includeTotals) {
    lines.push('');
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
}