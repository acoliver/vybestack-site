export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CLIOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

export interface RenderOptions extends CLIOptions {
  data: ReportData;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Input data must be a valid JSON object');
  }

  const report = data as ReportData;

  if (!report.title || typeof report.title !== 'string') {
    throw new Error('Missing or invalid "title" field');
  }

  if (!report.summary || typeof report.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field');
  }

  if (!report.entries || !Array.isArray(report.entries)) {
    throw new Error('Missing or invalid "entries" field');
  }

  if (report.entries.length === 0) {
    throw new Error('Entries array cannot be empty');
  }

  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    
    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error(`Entry ${i + 1}: missing or invalid "label" field`);
    }

    if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
      throw new Error(`Entry ${i + 1}: missing or invalid "amount" field`);
    }
  }

  return true;
}