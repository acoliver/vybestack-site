// Allow more than 2 padding chars in the regex since we'll validate this separately
const BASE64_ALPHABET = /^[A-Za-z0-9+/]+={0,}$/;

/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and validates input format.
 * @throws Error if input contains invalid Base64 characters or malformed padding
 */
export function decode(input: string): string {
  // Validate input format
  if (!input.trim()) {
    throw new Error('Input cannot be empty');
  }

  // Remove whitespace
  const cleanInput = input.replace(/\s+/g, '');

  // Validate Base64 format - requires at least one Base64 character before optional padding
  if (!BASE64_ALPHABET.test(cleanInput)) {
    throw new Error('Invalid Base64 format: contains characters outside Base64 alphabet');
  }

  // Check for invalid length: length % 4 === 1 is always invalid
  if (cleanInput.length % 4 === 1) {
    throw new Error('Invalid Base64 format: incorrect length');
  }

  // Validate padding is only at the end and valid
  const paddingIndex = cleanInput.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingSection = cleanInput.substring(paddingIndex);
    const nonPaddingChars = paddingSection.replace(/=/g, '');
    if (nonPaddingChars.length > 0) {
      throw new Error('Invalid Base64 format: padding must be at the end');
    }
    
    // Can only have 0, 1, or 2 padding characters
    const paddingLength = paddingSection.length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 format: too much padding');
    }

    // If there's padding, the length must be a multiple of 4
    if (cleanInput.length % 4 !== 0) {
      throw new Error('Invalid Base64 format: incorrect length');
    }
  }

  try {
    // Use the original input for decoding to handle cases without padding
    return Buffer.from(cleanInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}