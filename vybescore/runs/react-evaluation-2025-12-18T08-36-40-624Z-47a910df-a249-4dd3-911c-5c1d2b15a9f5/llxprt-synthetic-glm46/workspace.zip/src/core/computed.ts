/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ComputedObserver,
  updateObserver,
  notifyObservers,
  EqualFn,
  Options,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  const o: ComputedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: undefined,
  }
  
  // Initial computation
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed is being observed, so register the observer
      if (!o.observers) o.observers = new Set()
      o.observers.add(observer)
      
      // Recompute when being observed
      updateObserver(o)
    } else if (o.value === undefined) {
      // Initial computation if no value yet
      updateObserver(o)
    }
    
    return o.value as T
  }
  
  return getter
}
