import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export function validatePaginationParams(page?: string | null, limit?: string | null): { page: number; limit: number } {
  let pageNum = 1;
  let limitNum = DEFAULT_LIMIT;

  // Validate page parameter
  if (page !== undefined && page !== null) {
    const parsed = Number(page);
    if (isNaN(parsed) || !Number.isInteger(parsed) || parsed <= 0) {
      throw new Error('Invalid page parameter: must be a positive integer');
    }
    pageNum = parsed;
  }

  // Validate limit parameter
  if (limit !== undefined && limit !== null) {
    const parsed = Number(limit);
    if (isNaN(parsed) || !Number.isInteger(parsed) || parsed <= 0 || parsed > MAX_LIMIT) {
      throw new Error(`Invalid limit parameter: must be a positive integer <= ${MAX_LIMIT}`);
    }
    limitNum = parsed;
  }

  return { page: pageNum, limit: limitNum };
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // FIXED: offset should be (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(`
    SELECT id, name, sku, price_cents as priceCents, created_at as createdAt
    FROM inventory
    ORDER BY id
    LIMIT ? OFFSET ?
  `);

  stmt.bind([limit, offset]);

  const items: InventoryItem[] = [];
  while (stmt.step()) {
    const row = stmt.getAsObject() as Record<string, unknown>;
    items.push(mapRow(row));
  }

  stmt.free();

  const hasNext = (offset + limit) < total;

  return {
    items,
    page,
    limit,
    total,
    hasNext
  };
}
