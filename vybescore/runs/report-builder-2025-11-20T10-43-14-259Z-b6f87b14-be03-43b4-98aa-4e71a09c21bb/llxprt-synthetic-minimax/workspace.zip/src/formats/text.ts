import { ReportData, RenderOptions, Formatter } from '../types.js';

export const renderText: Formatter = {
  format(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    lines.push('');
    
    // Add each entry
    data.entries.forEach(entry => {
      const amount = `$${entry.amount.toFixed(2)}`;
      lines.push(`- ${entry.label}: ${amount}`);
    });
    
    // Add total if requested
    if (options.includeTotals) {
      lines.push('');
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`Total: $${total.toFixed(2)}`);
    }
    
    return lines.join('\n');
  }
};