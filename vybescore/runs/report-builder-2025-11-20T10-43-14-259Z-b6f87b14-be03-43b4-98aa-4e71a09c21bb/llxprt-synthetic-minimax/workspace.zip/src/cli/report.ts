import { readFileSync, writeFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, RenderOptions } from '../types.js';

function parseArguments(): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const data = JSON.parse(readFileSync(filePath, 'utf8'));
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    // Validate entries
    data.entries.forEach((entry: unknown, index: number) => {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Entry ${index}: must be an object`);
      }
      
      const typedEntry = entry as { label?: unknown; amount?: unknown };
      
      if (!typedEntry.label || typeof typedEntry.label !== 'string') {
        throw new Error(`Entry ${index}: missing or invalid "label" field`);
      }
      
      if (typeof typedEntry.amount !== 'number' || isNaN(typedEntry.amount)) {
        throw new Error(`Entry ${index}: missing or invalid "amount" field`);
      }
    });
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File "${filePath}" not found`);
      } else if (error.message.includes('JSON')) {
        console.error('Error: Invalid JSON in input file');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to load or parse input file');
    }
    process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${outputPath}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(content);
  }
}

function main(): void {
  const { dataFile, format, outputPath, includeTotals } = parseArguments();
  
  const data = loadReportData(dataFile);
  const options: RenderOptions = { includeTotals };
  
  let formatter;
  switch (format) {
    case 'markdown':
      formatter = renderMarkdown;
      break;
    case 'text':
      formatter = renderText;
      break;
    default:
      console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
      process.exit(1);
  }
  
  const output = formatter.format(data, options);
  writeOutput(output, outputPath);
}

main();