

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet with padding as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate Base64 input - only allow standard Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64: contains non-B64 characters');
  }

  // Check for invalid padding scenarios
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    const padding = input.substring(paddingIndex);
    
    // Padding must be at the end
    const paddingSection = input.slice(paddingIndex + 1).replace(/=/g, '');
    if (paddingSection.length > 0) {
      throw new Error('Invalid Base64: padding must be at the end');
    }
    
    // Only 1 or 2 padding characters allowed
    if (padding.length > 2) {
      throw new Error('Invalid Base64: too much padding');
    }
    
    // If there's padding, the last 4-char block must be properly padded
    if (padding.length > 0 && input.length % 4 !== 0) {
      throw new Error('Invalid Base64: incorrect padding length');
    }
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify we actually decoded something meaningful
    if (input.length > 0 && result.length === 0) {
      throw new Error('Invalid Base64: failed to decode input');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
