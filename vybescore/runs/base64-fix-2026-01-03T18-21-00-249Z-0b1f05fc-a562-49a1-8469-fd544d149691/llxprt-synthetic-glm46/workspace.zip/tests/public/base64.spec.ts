import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

const INVALID_CHARS_ERROR = 'Invalid Base64: contains non-B64 characters';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('handles padding for 1-byte input', () => {
    const result = encode('a');
    expect(result).toBe('YQ==');
  });

  it('handles padding for 2-byte input', () => {
    const result = encode('ab');
    expect(result).toBe('YWI=');
  });

  it('handles no padding for 3-byte input', () => {
    const result = encode('abc');
    expect(result).toBe('YWJj');
  });

  it('decodes without padding', () => {
    const result = decode('YQ');
    expect(result).toBe('a');
  });

  it('encodes non-ASCII text correctly', () => {
    const result = encode('café');
    expect(result).toBe('Y2Fmw6k=');
  });

  it('decodes non-ASCII text correctly', () => {
    const result = decode('Y2Fmw6k=');
    expect(result).toBe('café');
  });

  it('rejects invalid characters', () => {
    expect(() => decode('A B C')).toThrow(INVALID_CHARS_ERROR);
    expect(() => decode('A!B@C')).toThrow(INVALID_CHARS_ERROR);
  });

  it('rejects clearly invalid padding', () => {
    expect(() => decode('YWJj=')).toThrow('Invalid Base64: incorrect padding length');
    expect(() => decode('YQ===')).toThrow(INVALID_CHARS_ERROR);
  });

  it('handles padding in valid cases', () => {
    // YWJ= is actually valid (represents "ab")
    expect(decode('YWJ=')).toBe('ab');
    expect(decode('YWI=')).toBe('ab');
  });
});
