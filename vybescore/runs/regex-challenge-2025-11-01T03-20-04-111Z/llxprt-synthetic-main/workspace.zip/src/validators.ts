export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for plus tags.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check
  const emailRegex = /^.{0,64}@.{0,255}$/;
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for forbidden patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.') ||
      value.includes('@.') || value.includes('.@')) {
    return false;
  }
  
  // Extract and validate local and domain parts
  const atIndex = value.lastIndexOf('@');
  const localPart = value.substring(0, atIndex);
  const domainPart = value.substring(atIndex + 1);
  
  // Local part validation (allows letters, numbers, periods, hyphens, underscores, plus)
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localRegex.test(localPart) || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain validation (no underscores allowed)
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Validate domain format
  const domainRegex = /^[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domainPart)) {
    return false;
  }
  
  // Domain cannot start or end with hyphen or period
  if (domainPart.startsWith('-') || domainPart.endsWith('-') ||
      domainPart.startsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  // Cannot have double dots in domain
  if (domainPart.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check length (10 digits for US number, 11 with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Extract digits
  let countryCode: string;
  let areaCode: string;
  let exchangeCode: string;
  
  if (digitsOnly.length === 10) {
    // No country code
    areaCode = digitsOnly.substring(0, 3);
    exchangeCode = digitsOnly.substring(3, 6);
  } else {
    // With country code
    countryCode = digitsOnly.substring(0, 1);
    if (countryCode !== '1') {
      return false;
    }
    areaCode = digitsOnly.substring(1, 4);
    exchangeCode = digitsOnly.substring(4, 7);
  }
  
  // Area code validation (cannot start with 0 or 1)
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code validation (cannot start with 0 or 1)
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate format with optional separators
  const phoneRegex = /^(?:\+1[-.\s]?)?(\([0-9]{3}\)|[0-9]{3})[-.\s]?[0-9]{3}[-.\s]?[0-9]{4}$/;
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all spaces and hyphens for easier manipulation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Define regex patterns for valid Argentine phone formats
  const patterns = [
    // With country code: +54 9 XXXX XXXXXX (mobile)
    /^\+549[1-9]\d{1,3}\d{6,8}$/,
    // With country code: +54 XXXX XXXXXX (landline)
    /^\+54[1-9]\d{1,3}\d{6,8}$/,
    // Without country code: 0 XXXX XXXXXX (mobile)
    /^09[1-9]\d{1,3}\d{6,8}$/,
    // Without country code: 0 XXXX XXXXXX (landline)
    /^0[1-9]\d{1,3}\d{6,8}$/,
    // With country code with spaces: +54 9 XXXX XXXXXX
    /^\+549[1-9]\d{1,3}\d{6,8}$/
  ];
  
  // Check if the number matches any of the valid patterns
  for (const pattern of patterns) {
    if (pattern.test(cleanNumber)) {
      return true;
    }
  }
  
  // Try a more flexible approach
  let digits = cleanNumber;
  
  // Remove country prefix if present
  if (digits.startsWith('54')) {
    digits = digits.substring(2);
  }
  
  // Remove mobile indicator if present
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Remove trunk prefix if present
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Now digits should contain areaCode + subscriberNumber
  // Area code should be 2-4 digits, subscriber number should be 6-8 digits
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }
  
  // Try to extract area code and subscriber number
  // We'll try area code lengths from 2 to 4 digits
  for (let areaCodeLength = 2; areaCodeLength <= 4 && areaCodeLength <= digits.length - 6; areaCodeLength++) {
    const areaCode = digits.substring(0, areaCodeLength);
    const subscriberNumber = digits.substring(areaCodeLength);
    
    // Area code must not start with 0
    if (areaCode[0] === '0') {
      continue;
    }
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      // Valid configuration found
      return true;
    }
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string' || value.trim() === '') {
    return false;
  }
  
  // Names should contain at least 2 characters
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject obvious invalid names containing certain special symbols
  if (/[@#$%^&*()+=\[\]{}|\\/<>0-9]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // Using \p{L} to match any Unicode letter
  const nameRegex = /^[\p{L}'-]+(?:[\s][\p{L}'-]+)*$/u;
  
  // Check if the name follows the valid pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with multiple consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }
  
  // Reject names with multiple consecutive hyphens or apostrophes
  if (/-{2,}|'{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start or end with hyphen, apostrophe, or space
  if (/^[\s'-]|[\s'-]$/.test(value)) {
    return false;
  }
  
  // Reject names that contain unusual symbol combinations like in 'X Æ A-12'
  if (/[Ææ]$/.test(value)) {
    return false;
  }
  
  // Check for presence of at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx with proper length, prefix, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove spaces and hyphens
  const cardNumber = value.replace(/[\s-]/g, '');
  
  // Check if the card number contains only digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Check card length (13-16 digits)
  if (cardNumber.length < 13 || cardNumber.length > 16) {
    return false;
  }
  
  // Check card prefix and length for each card type
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  if (visaRegex.test(cardNumber)) {
    return runLuhnCheck(cardNumber);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|[4-9]\d\d|72[0-9]|73[01])\d{12})$/;
  if (mastercardRegex.test(cardNumber)) {
    return runLuhnCheck(cardNumber);
  }
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cardNumber)) {
    return runLuhnCheck(cardNumber);
  }
  
  return false;
}

/**
 * Helper function to run the Luhn algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit = digit % 10 + 1;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
