/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Approach: Use regex to find sentence endings and capitalize appropriately
  // First, handle the first letter
  let result = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Find all characters that come after sentence-ending punctuation
  // followed by optional spaces, and capitalize them
  result = result.replace(/([.?!]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Ensure proper spacing after punctuation
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Clean up any double spaces that might have been created
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

/**
 * Extracts all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // Enhanced URL regex pattern that captures various URL formats
  // Including http(s), www, domain names, and IP addresses
  // Negative lookbehind to avoid capturing trailing punctuation
  const urlRegex = /(?<![\w])(?:https?:\/\/|www\.)[^\s/$.?#].[^\s]*?(?=[,.!?;:]?\s|$|[,.!?;:]$)/g;
  
  // Find all matches in the text
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Process each URL to clean trailing punctuation that might have been captured
  const urls = matches.map(url => {
    // Remove surrounding quotes, parentheses, brackets
    url = url.replace(/^["'`(\[{]|["'`\)\]}]$/g, '');
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?)\]}]+$/g, '');
    
    return url;
  }).filter(url => url.length > 0);
  
  return [...new Set(urls)]; // Remove duplicates
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text || '';
  }
  
  // Use regex to replace http:// with https://, but only when it's not already https
  // We need to ensure we're not matching https://
  const regex = /\bhttps?:\/\//gi;
  
  return text.replace(regex, (match) => {
    // If it's already https, leave it unchanged
    if (match.toLowerCase() === 'https://') {
      return 'https://';
    }
    // If it's http, replace with https
    return 'https://';
  });
}

/**
 * Rewrites URLs from http://example.com/... following these rules:
 * 1. Always upgrade the scheme to https://
 * 2. When the path begins with /docs/, rewrite the host to docs.example.com
 * 3. Skip the host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * 4. Preserves nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text || '';
  }
  
  // Match URLs in the text and process them
  return text.replace(/(https?:\/\/)([^\s/$.?#].[^\s]*)/gi, (match, scheme, url) => {
    // Always upgrade to https
    const upgradedScheme = 'https://';
    
    // Split the URL into domain and path
    const firstSlashIndex = url.indexOf('/');
    let domain = firstSlashIndex === -1 ? url : url.substring(0, firstSlashIndex);
    const path = firstSlashIndex === -1 ? '' : url.substring(firstSlashIndex);
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints in the path
      // Patterns to look for: cgi-bin, query strings, legacy extensions
      const hasDynamicHints = /\/cgi-bin\//i.test(path) || 
                            /[?&=]/.test(path) ||
                            /\.(jsp|php|asp|aspx|do|cgi|pl|py)($|\?|&)/i.test(path);
      
      // If no dynamic hints, rewrite the host to docs.example.com
      if (!hasDynamicHints) {
        domain = 'docs.' + domain;
      }
    }
    
    return upgradedScheme + domain + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format dates.
 * Returns 'N/A' if format doesn't match or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Use regex to match mm/dd/yyyy format
  const dateRegex = /(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (accounting for leap years)
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  if (month === 2 && (isLeapYear(parseInt(year, 10)))) {
    maxDays[1] = 29;
  }
  
  // If day is valid for the month
  if (day <= maxDays[month - 1]) {
    return year;
  }
  
  return 'N/A';
}

/**
 * Helper function to check if a year is a leap year
 */
function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}
