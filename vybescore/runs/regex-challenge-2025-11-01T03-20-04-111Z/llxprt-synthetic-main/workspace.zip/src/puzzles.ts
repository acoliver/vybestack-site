/**
 * Finds words beginning with the specified prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to match words starting with the prefix
  // Words are sequences of letters, numbers, or underscores
  const prefixedWordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z0-9_]*\\b`, 'g');
  
  // Find all matches in the text
  const matches = text.match(prefixedWordRegex) || [];
  
  // Filter out exceptions
  const result = matches.filter(word => {
    // Convert both to lowercase for case-insensitive comparison
    const wordLower = word.toLowerCase();
    
    // Check if the word is in the exceptions list
    const isException = exceptions.some(exception => {
      if (!exception) return false;
      return wordLower === exception.toLowerCase();
    });
    
    return !isException;
  });
  
  return [...new Set(result)]; // Remove duplicates
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds to find the token in the right context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a pattern that finds the token after a digit but not at the beginning
  // Capturing the digit and token together, then returning the full match
  const embeddedTokenRegex = new RegExp(`\\d(${escapedToken})`, 'g');
  
  // Find all matches in the text and extract the matched digit+token
  const matches = [];
  let match;
  while ((match = embeddedTokenRegex.exec(text)) !== null) {
    matches.push(match[0]); // Return the full match including the digit
  }
  
  return [...new Set(matches)]; // Remove duplicates
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for absence of whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for presence of at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for presence of at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for presence of at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for presence of at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // This regex matches patterns where a sequence of 2+ characters is repeated immediately
  const repeatedSequenceRegex = /(..+)\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand with ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // First check if the text contains an IPv6 address
  // IPv6 regex that supports full and shorthand notation
  const ipv6Regex = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  // Check for IPv4 addresses to exclude
  const ipv4Regex = /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check for IPv6 addresses in the text
  const ipv6Matches = value.match(ipv6Regex);
  
  if (!ipv6Matches) {
    return false;
  }
  
  // Check if any of the matches could be an IPv4 address
  // (e.g., IPv4-mapped IPv6 addresses)
  for (const match of ipv6Matches) {
    if (!match) continue;
    
    // This would catch IPv6 addresses that contain embedded IPv4 addresses
    if (match.includes('.') && ipv4Regex.test(match)) {
      // Likely a mixed IPv6/IPv4 format, not a pure IPv6
      return false;
    }
  }
  
  return true;
}