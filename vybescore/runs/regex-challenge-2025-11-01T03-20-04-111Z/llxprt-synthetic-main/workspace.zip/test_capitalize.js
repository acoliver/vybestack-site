/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
function capitalizeSentences(text) {
  if (!text || typeof text !== 'string') {
    return '';
  }
  
  // Approach: Use regex to find sentence endings and capitalize appropriately
  // First, handle the first letter
  let result = text.charAt(0).toUpperCase() + text.slice(1);
  
  // Find all characters that come after sentence-ending punctuation
  // followed by optional spaces, and capitalize them
  result = result.replace(/([.?!]\s*)([a-z])/g, function(match, punctuation, letter) {
    return punctuation + letter.toUpperCase();
  });
  
  // Ensure proper spacing after punctuation
  result = result.replace(/([.?!])(?=[A-Za-z])/g, '$1 ');
  
  // Clean up any double spaces that might have been created
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

console.log('Output:', capitalizeSentences('hello world. how are you?'));