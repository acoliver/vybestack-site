/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value
  
  // Create observer that will track dependencies
  const observer: Observer<T> = {
    name: options?.name,
    value: computedValue,
    updateFn: (prevValue) => {
      // Use the update function to compute new value
      // If no previous value, pass undefined to use default parameters
      const newValue = updateFn(prevValue === undefined ? value : prevValue)
      computedValue = newValue
      return newValue
    },
  }
  
  // Return getter that computes fresh value and tracks dependencies
  return (): T => {
    // Re-compute value and track dependencies
    const result = updateObserver(observer)
    if (result !== undefined) {
      computedValue = result
    }
    return computedValue!
  }
}
