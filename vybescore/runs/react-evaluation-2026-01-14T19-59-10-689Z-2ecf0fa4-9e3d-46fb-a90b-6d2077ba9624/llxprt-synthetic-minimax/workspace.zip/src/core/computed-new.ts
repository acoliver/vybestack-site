/**
 * Computed closure implementation for derived values - FIXED VERSION.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value
  
  const o: Observer<T> = {
    name: options?.name,
    value: computedValue,
    updateFn: () => {
      // Re-compute the value by calling the update function
      // This will track dependencies through getActiveObserver()
      const newValue = updateFn(computedValue)
      computedValue = newValue
      return newValue
    },
  }
  
  // Initial computation to set up dependencies
  updateObserver(o)
  
  return (): T => {
    // Re-compute every time the getter is called to ensure dependencies are tracked
    // and the value is always up-to-date
    const newValue = updateFn(computedValue)
    computedValue = newValue
    return newValue
  }
}