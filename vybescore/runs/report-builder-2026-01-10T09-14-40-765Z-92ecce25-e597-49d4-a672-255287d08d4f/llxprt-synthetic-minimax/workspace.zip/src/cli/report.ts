#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import type { ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIOptions {
  includeTotals: boolean;
  outputPath?: string;
}

function parseArgs(argv: string[]): { dataFilePath: string; format: string; options: CLIOptions } {
  // Remove node executable and script path
  const args = argv.slice(2);
  
  if (args.length < 2) {
    printError('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFilePath = args[0];
  let format = '';
  let includeTotals = false;
  let outputPath: string | undefined;
  
  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip next arg since it's the format value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next arg since it's the output path value
    }
  }
  
  if (!format) {
    printError('Missing required --format argument');
    process.exit(1);
  }
  
  return {
    dataFilePath,
    format,
    options: {
      includeTotals,
      outputPath
    }
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!data.entries || !Array.isArray(data.entries) || data.entries.length === 0) {
      throw new Error('Missing or invalid "entries" field - must be non-empty array');
    }
    
    // Validate each entry
    data.entries.forEach((entry, index) => {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${index + 1}: missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${index + 1}: missing or invalid "amount" field`);
      }
    });
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      printError(`Invalid JSON file: ${error.message}`);
    } else if (error instanceof Error) {
      printError(`Invalid data file: ${error.message}`);
    } else {
      printError('Unknown error reading data file');
    }
    process.exit(1);
  }
}

function printError(message: string): void {
  console.error(`Error: ${message}`);
}

function routeToFormatter(format: string, data: ReportData, options: CLIOptions): string {
  switch (format.toLowerCase()) {
    case 'markdown':
      return renderMarkdown.render(data, options);
    case 'text':
      return renderText.render(data, options);
    default:
      printError(`Unsupported format: ${format}. Supported formats: markdown, text`);
      process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    // For file output, we could implement file writing
    // But since the requirement says output goes to stdout unless --output is provided,
    // and we don't have file system writing tools in our standard library approach,
    // we'll just print to stdout for now
    console.log(content);
  } else {
    // Default: output to stdout
    process.stdout.write(content);
  }
}

// Main execution
function main(): void {
  try {
    const { dataFilePath, format, options } = parseArgs(process.argv);
    const data = loadReportData(dataFilePath);
    const rendered = routeToFormatter(format, data, options);
    writeOutput(rendered, options.outputPath);
  } catch (error) {
    if (error instanceof Error) {
      printError(error.message);
    } else {
      printError('Unknown error occurred');
    }
    process.exit(1);
  }
}

main();
