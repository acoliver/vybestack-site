import type { ReportData, RenderOptions, Formatter } from '../types/report.js';

export const renderText: Formatter = {
  render: (data: ReportData, options: RenderOptions): string => {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push(''); // blank line
    
    // Summary
    lines.push(data.summary);
    lines.push(''); // blank line
    
    // Entries heading
    lines.push('Entries:');
    
    // Process each entry
    data.entries.forEach(entry => {
      const amountFormatted = formatAmount(entry.amount);
      lines.push(`- ${entry.label}: $${amountFormatted}`);
    });
    
    // Include totals if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      const totalFormatted = formatAmount(total);
      lines.push('');
      lines.push(`Total: $${totalFormatted}`);
    }
    
    return lines.join('\n');
  }
};

function formatAmount(amount: number): string {
  // Format with exactly two decimal places, no thousands separators
  return amount.toFixed(2);
}