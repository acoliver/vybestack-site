/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerObserver, unregisterObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependents: new Set(),
    dependencies: new Set(),
  } as Observer<T>
  
  // Register this observer
  const observerId = registerObserver(observer as Observer<unknown>)
  
  // Make this observer active for dependency tracking, then execute
  // We immediately execute to establish dependencies and trigger initial side effects
  updateObserver(observer)
  
  let disposed = false
  
  // Return unsubscribe function
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from registry
    unregisterObserver(observerId)
    
    // Clear the observer and its dependencies
    observer.value = undefined
    observer.updateFn = () => value as T
    
    // Clean up dependency relationships
    if (observer.dependencies) {
      observer.dependencies.forEach(dep => {
        if (dep.dependents) {
          dep.dependents.delete(observer)
        }
      })
      observer.dependencies.clear()
    }
    
    if (observer.dependents) {
      observer.dependents.clear()
    }
  }
}
