/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine equality function
  let equalFn: EqualFn<T>
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  } else {
    // Default: strict comparison for primitives, reference equality for objects
    equalFn = (a: T, b: T) => a === b
  }

  // Create a placeholder observer to handle change notifications
  // This is an observer wrapper around the subject value
  const subjectObserver: Observer<T> = {
    value: value,
    updateFn: () => s.value,
    dependents: new Set(),
    dependencies: new Set(),
  } as Observer<T>

  // Track dependent observers that need to be notified when this input changes
  const dependentObservers = new Set<Observer<T>>()

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Register the current observer as dependent on this input
      dependentObservers.add(activeObs as Observer<T>)
      
      // Establish a two-way dependency - the active observer depends on this input
      if (!activeObs.dependencies) activeObs.dependencies = new Set()
      activeObs.dependencies.add(subjectObserver)
      
      // This input tracks the active observer as a dependent
      if (!subjectObserver.dependents) subjectObserver.dependents = new Set()
      subjectObserver.dependents.add(activeObs as Observer<T>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value has changed
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      subjectObserver.value = nextValue
      
      // Notify all dependent observers by updating them
      dependentObservers.forEach(observer => {
        updateObserver(observer)
      })
    }
    return s.value
  }

  return [read, write]
}
