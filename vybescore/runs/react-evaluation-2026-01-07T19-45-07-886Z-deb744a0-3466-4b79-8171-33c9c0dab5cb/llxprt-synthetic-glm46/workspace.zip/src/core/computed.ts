/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  registerObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((a: T, b: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set(),
  }
  
  // Register this observer
  registerObserver(o as Observer<unknown>)
  
  // Track dependencies and compute initial value
  const compute = () => {
    try {
      updateObserver(o)
    } finally {
      // Restore the previous active observer
      // This is handled implicitly by updateObserver
    }
  }
  
  // Compute initial value
  compute()
  
  return (): T => {
    // If this getter is called within an observer context, 
    // this computed value becomes a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // The calling observer becomes dependent on this computed value
      if (!activeObserver.dependencies) activeObserver.dependencies = new Set()
      activeObserver.dependencies.add(o)
      
      // This computed observer tracks which observers depend on it
      if (!o.dependents) o.dependents = new Set()
      o.dependents.add(activeObserver as Observer<T>)
    }
    
    return o.value!
  }
}
