/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR<T = unknown> = {
  name?: string
  dependents?: Set<Observer<T>>
  dependencies?: Set<Observer<T>>
}

export type ObserverV<T = unknown> = {
  value?: T
  updateFn: (value?: T) => T
  dependencies?: Set<Observer<T>>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Global registry to track all observers for proper dependency management
const observerRegistry = new Map<string, Observer<unknown>>()
let nextObserverId = 0

// Track observers being updated to prevent circular notifications
const updatingObservers = new Set<Observer<unknown>>()

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent recursive updates to avoid infinite loops
  if (updatingObservers.has(observer as Observer<unknown>)) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  updatingObservers.add(observer as Observer<unknown>)
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    updatingObservers.delete(observer as Observer<unknown>)
  }
  
  // Always notify dependents to ensure computed chain updates correctly
  // The individual observers will check if their own value changed
  if (observer.dependents) {
    observer.dependents.forEach(dependent => {
      updateObserver(dependent)
    })
  }
}

// Register an observer with a unique ID
function registerObserver(observer: Observer<unknown>): string {
  const id = `observer-${++nextObserverId}`
  observerRegistry.set(id, observer)
  return id
}

// Remove an observer from the registry and clean up its dependencies
function unregisterObserver(id: string): void {
  const observer = observerRegistry.get(id)
  if (observer) {
    // Remove this observer from all its dependencies' dependent sets
    if (observer.dependencies) {
      observer.dependencies.forEach(dep => {
        if (dep.dependents) {
          dep.dependents.delete(observer)
        }
      })
      observer.dependencies.clear()
    }
    
    // Remove all dependents (they might still reference this observer)
    if (observer.dependents) {
      // Clean up双向关系
      observer.dependents.forEach(dependent => {
        if (dependent.dependencies) {
          dependent.dependencies.delete(observer)
        }
      })
      observer.dependents.clear()
    }
    
    observerRegistry.delete(id)
  }
}

export { registerObserver, unregisterObserver }
