import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'url';
import { Express } from 'express';

// Use the same mechanism as server.ts to determine __dirname
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let server: Server;
let app: Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the app and server from the compiled server
  const serverModule = await import(path.join(__dirname, '../../dist/server.js'));
  app = serverModule.app;
  server = serverModule.server;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('form[action="/submit"][method="POST"]')).toHaveLength(1);
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'Anystate',
      postalCode: '12345',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555 123 4567'
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.header.location).toBe('/thank-you');

    // Check that the data was saved to the database
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      expect(fileBuffer.length).toBeGreaterThan(0);
    } else {
      throw new Error('Database file was not created');
    }
  });
});
