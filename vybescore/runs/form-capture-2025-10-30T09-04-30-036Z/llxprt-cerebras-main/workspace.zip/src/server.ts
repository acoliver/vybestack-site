import express, { Express, Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { Server } from 'http';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create the Express app
const app: Express = express();
const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Export app and server for testing
export { app };
export type { Server };

// Middleware for parsing form data
app.use(express.urlencoded({ extended: true }));

// Serve static files from the public directory
app.use(express.static(path.join(__dirname, '../public')));

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s()-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings with spaces and dashes (UK, Argentine formats, etc.)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Database initialization
let db: Database;
let server: Server;

const dbPath = path.join(__dirname, '../data/submissions.sqlite');
const schemaPath = path.join(__dirname, '../db/schema.sql');

async function initializeDatabase() {
  const SQL = await initSqlJs();
  
  // Load existing database or create a new one
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.run(schema);
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form');
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvince: req.body.stateProvince?.trim() || '',
    postalCode: req.body.postalCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phone: req.body.phone?.trim() || ''
  };

  const errors: Record<string, string> = {};

  // Validation
  if (!formData.firstName) errors.firstName = 'First name is required';
  if (!formData.lastName) errors.lastName = 'Last name is required';
  if (!formData.streetAddress) errors.streetAddress = 'Street address is required';
  if (!formData.city) errors.city = 'City is required';
  if (!formData.stateProvince) errors.stateProvince = 'State/Province is required';
  if (!formData.postalCode) errors.postalCode = 'Postal code is required';
  else if (!validatePostalCode(formData.postalCode)) errors.postalCode = 'Invalid postal code format';
  if (!formData.country) errors.country = 'Country is required';
  if (!formData.email) errors.email = 'Email is required';
  else if (!validateEmail(formData.email)) errors.email = 'Invalid email format';
  if (!formData.phone) errors.phone = 'Phone number is required';
  else if (!validatePhone(formData.phone)) errors.phone = 'Invalid phone number format';

  if (Object.keys(errors).length > 0) {
    // Return form with errors and preserved data
    return res.status(400).render('form', { errors, formData });
  }

  // Insert form data into the database
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();

  // Write database to disk
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);

  // Redirect to thank-you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the first name from the database (last submitted entry)
  const result = db.exec("SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1");
  const firstName = result.length > 0 ? result[0].values[0][0] : 'Friend';
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
async function closeServer() {
  console.log('Closing server...');
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(dbPath, buffer);
    db.close();
  }
  if (server) {
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  }
}

// Start server and initialize database
async function startServer(): Promise<Server> {
  await initializeDatabase();
  const serverInstance = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  server = serverInstance;
  return serverInstance;
}

process.on('SIGTERM', closeServer);
process.on('SIGINT', closeServer);

export { server };
startServer();