import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';
import { fileURLToPath } from 'url';
import { dirname } from 'path';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormSubmission extends FormData {
  id?: number;
  createdAt?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormValidator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhone(phone: string): boolean {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.length >= 7;
  }

static validatePostalCode(postalCode: string): boolean {
    const postalCodeRegex = /^[\d\sA-Za-z-]+$/;
    return postalCodeRegex.test(postalCode) && postalCode.trim().length > 0;
  }

  static validateRequired(value: string): boolean {
    return value.trim().length > 0;
  }

  static validateFormData(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || !this.validateRequired(data[field])) {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    }

    if (data.email && !this.validateEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    if (data.phone && !this.validatePhone(data.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }

    if (data.postalCode && !this.validatePostalCode(data.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }

    return errors;
  }

  private static getFieldDisplayName(field: keyof FormData): string {
    const displayNames: Record<keyof FormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State/Province/Region',
      postalCode: 'Postal/Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return displayNames[field] || field;
  }
}

class DatabaseManager {
  private db: Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      let dbBuffer: Uint8Array | null = null;
      
      if (fs.existsSync(this.dbPath)) {
        const dbFile = fs.readFileSync(this.dbPath);
        dbBuffer = new Uint8Array(dbFile);
      } else {
        const dataDir = path.dirname(this.dbPath);
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }
        dbBuffer = null;
      }

      this.db = new SQL.Database(dbBuffer);
      
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      this.db.run(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  insertSubmission(submission: FormSubmission): number {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        submission.firstName,
        submission.lastName,
        submission.streetAddress,
        submission.city,
        submission.stateProvince,
        submission.postalCode,
        submission.country,
        submission.email,
        submission.phone
      ]);
      
      const result = this.db.exec('SELECT last_insert_rowid() as id');
      const insertedId = result[0].values[0][0] as number;
      
      this.saveToDisk();
      return insertedId;
    } finally {
      stmt.free();
    }
  }

  private saveToDisk(): void {
    if (!this.db) return;
    
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
      console.log('Database closed');
    }
  }
}

class FormServer {
  private app: express.Application;
  private dbManager: DatabaseManager;
  private server: { close: (callback?: () => void) => void } | null = null;

  constructor() {
    this.app = express();
    this.dbManager = new DatabaseManager();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private setupRoutes(): void {
    this.app.get('/', this.handleFormGet.bind(this));
    this.app.post('/submit', this.handleFormSubmit.bind(this));
    this.app.get('/thank-you', this.handleThankYou.bind(this));
  }

  private handleFormGet(req: Request, res: Response): void {
    res.render('form', {
      errors: [],
      values: {}
    });
  }

  private handleFormSubmit(req: Request, res: Response): void {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validationErrors = FormValidator.validateFormData(formData);

    if (validationErrors.length > 0) {
      const errorMessages = validationErrors.map(error => error.message);
      res.status(400).render('form', {
        errors: errorMessages,
        values: formData
      });
      return;
    }

    try {
      const submissionId = this.dbManager.insertSubmission(formData);
      console.log(`Form submission saved with ID: ${submissionId}`);
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Error saving submission:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  }

  private handleThankYou(req: Request, res: Response): void {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you', { firstName });
  }

  async start(port?: number): Promise<void> {
    try {
      await this.dbManager.initialize();
      
      const listenPort = port || process.env.PORT || 3535;
      this.server = this.app.listen(listenPort, () => {
        console.log(`Server running on port ${listenPort}`);
      });

      process.on('SIGTERM', this.gracefulShutdown.bind(this));
      process.on('SIGINT', this.gracefulShutdown.bind(this));
      
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  close(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          console.log('HTTP server closed');
          this.dbManager.close();
          resolve();
        });
      } else {
        this.dbManager.close();
        resolve();
      }
    });
  }

  private gracefulShutdown(): void {
    console.log('Received shutdown signal, closing gracefully...');
    
    this.close().then(() => {
      process.exit(0);
    });
  }
}

export { FormServer };

export function createServer(): FormServer {
  return new FormServer();
}

async function main(): Promise<void> {
  const server = new FormServer();
  await server.start();
}

// Only run the main function when this file is run directly, not when imported
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error('Application failed to start:', error);
    process.exit(1);
  });
}
