declare module 'sql.js' {
  interface Database {
    exec(sql: string): Array<{
      columns: string[];
      values: unknown[][];
    }>;
    run(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }

  interface SqlJs {
    Database: new (data?: Uint8Array | null) => Database;
  }

  function initSqlJs(): Promise<SqlJs>;

  export = initSqlJs;
  export { Database };
}