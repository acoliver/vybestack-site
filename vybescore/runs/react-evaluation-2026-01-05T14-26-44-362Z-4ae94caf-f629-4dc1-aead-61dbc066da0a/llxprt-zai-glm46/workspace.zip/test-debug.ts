import { createInput, createComputed, createCallback } from './src/core/input.ts'
import { createComputed as createComp } from './src/core/computed.ts'
import { createCallback as createCB } from './src/core/callback.ts'

// Test 1: compute cells can depend on other compute cells
console.log('=== Test 1: compute cells can depend on other compute cells ===')
const [input, setInput] = createInput(1)
const timesTwo = createComp(() => input() * 2)
const timesThirty = createComp(() => input() * 30)
const sum = createComp(() => timesTwo() + timesThirty())

console.log('Initial input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 32')

setInput(3)
console.log('After setInput(3):')
console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 96')
