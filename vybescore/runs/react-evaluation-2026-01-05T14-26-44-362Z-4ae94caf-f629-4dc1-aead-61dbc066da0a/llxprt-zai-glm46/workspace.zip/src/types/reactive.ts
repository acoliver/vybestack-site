/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<() => unknown>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  oldValue?: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  console.log('[updateObserver] called for observer:', observer.name || 'unnamed')
  const previous = activeObserver
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    console.log('[updateObserver] updateFn returned:', newValue)
    observer.value = newValue
    console.log('[updateObserver] observer.value after update:', observer.value)
  } finally {
    activeObserver = previous
  }
  // After updating (and restoring activeObserver), notify all observers that depend on this one
  // This is done outside the try/finally so we don't track these notifications as dependencies
  console.log('[updateObserver] about to notify dependents for:', observer.name || 'unnamed')
  
  // First notify any observers registered directly via getter dependencies
  const getter = (observer as unknown as { getter?: () => unknown }).getter
  if (getter) {
    const dependents = getDependents(getter)
    if (dependents && dependents.size > 0) {
      console.log('[updateObserver] notifying', dependents.size, 'dependents registered via getter')
      // Create a copy to avoid issues with modification during iteration
      const dependentsCopy = Array.from(dependents)
      for (const dep of dependentsCopy) {
        const depObserver = dep as Observer<unknown>
        if (depObserver !== observer) {
          console.log('[updateObserver] notifying dependent:', depObserver.name || 'unnamed')
          updateObserver(depObserver as Observer<T>)
        }
      }
    }
  }
  
  // Then notify via the dependency tracking (legacy, may not be needed)
  notifyDependents(observer as Observer<unknown>)
}

export function notifyObservers<T>(subject: Subject<T>): void {
  console.log('[notifyObservers] called, subject.observers.size:', subject.observers?.size || 0, 'subject:', subject.name || 'unnamed')
  if (subject.observers) {
    // Create a copy of the observers array to avoid issues with modification during iteration
    const observers = Array.from(subject.observers)
    for (const obsR of observers) {
      console.log('[notifyObservers] processing observer:', obsR.name || 'unnamed')
      // obsR is the ObserverR part of an Observer<T>
      // We need to get the full Observer<T> and update it
      const obs = obsR as Observer<T>
      updateObserver(obs)
    }
  }
}

export function notifyDependents(observer: Observer<unknown>): void {
  console.log('[notifyDependents] called for observer:', observer.name || 'unnamed', 'deps:', observer.dependencies?.size || 0)
  if (observer.dependencies) {
    for (const dep of observer.dependencies) {
      // Re-trigger the dependent observer
      // Need to find the observer associated with this getter
      // and call updateObserver on it
      const depObserver = getObserverForGetter(dep)
      console.log('[notifyDependents] depObserver found:', depObserver ? 'YES' : 'NO')
      if (depObserver) {
        // Check if this is actually the same observer to avoid infinite loops
        if (depObserver !== observer) {
          console.log('[notifyDependents] updating depObserver:', depObserver.name || 'unnamed')
          updateObserver(depObserver as Observer<unknown>)
        } else {
          console.log('[notifyDependents] skipping same observer')
        }
      }
    }
  }
}

// Map to track getter functions to their observers
const getterToObserverMap = new WeakMap<() => unknown, Observer<unknown>>()

// Map to track reverse dependencies: which observers depend on a given getter
const getterToDependentsMap = new WeakMap<() => unknown, Set<ObserverR>>()

export function registerObserver(getter: () => unknown, observer: Observer<unknown>): void {
  getterToObserverMap.set(getter, observer)
}

export function getObserverForGetter(getter: () => unknown): Observer<unknown> | undefined {
  return getterToObserverMap.get(getter)
}

export function addDependent(getter: () => unknown, dependent: ObserverR): void {
  let dependents = getterToDependentsMap.get(getter)
  if (!dependents) {
    dependents = new Set()
    getterToDependentsMap.set(getter, dependents)
  }
  dependents.add(dependent)
}

export function getDependents(getter: () => unknown): Set<ObserverR> | undefined {
  return getterToDependentsMap.get(getter)
}
