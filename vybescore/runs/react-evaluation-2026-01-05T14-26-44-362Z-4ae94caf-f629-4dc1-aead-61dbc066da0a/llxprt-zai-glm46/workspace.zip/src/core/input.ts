/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  registerObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Observer
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Link the observer to this subject for future notifications
      s.observers!.add(observer)
      console.log('[createInput/read]', options?.name || 'unnamed', 'adding observer:', observer.name || 'unnamed')
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(read)
    }
    return s.value
  }

  // Create a simple observer to represent the input
  // This allows us to use the same registration mechanism
  const inputObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => s.value,
    dependencies: new Set()
  }
  
  // Register the read getter with the input observer
  registerObserver(read, inputObserver as unknown as Observer<unknown>)

  const write: SetterFn<T> = (nextValue) => {
    const equalFn: EqualFn<T> = typeof _equal === 'function'
      ? _equal
      : _equal === true
        ? (a, b) => a === b
        : () => false

    if (equalFn(s.value, nextValue)) {
      return s.value
    }

    s.value = nextValue
    notifyObservers(s)
    return s.value
  }

  return [read, write]
}
