/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  getActiveObserver,
  registerObserver,
  addDependent
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set()
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of the active observer
      // This ensures the observer gets updated when this computed changes
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(read)
      console.log('[createComputed/read]', options?.name || 'unnamed', 'added to dependencies of', observer.name || 'unnamed')
      
      // Register the reverse: the active observer (observer) depends on this computed (o)
      // So when this computed changes, it should notify the active observer
      addDependent(read, observer)
    }
    return o.value!
  }

  // Store the read function on the observer for dependency tracking
  ;(o as Observer<T> & { getter: GetterFn<T> }).getter = read

  // Register the getter to observer mapping
  registerObserver(read as () => unknown, o as unknown as Observer<unknown>)

  // Initial computation
  updateObserver(o)

  return read
}
