import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'

console.log('=== Debug: Check which observer is being updated ===')

const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed with a name')
let computeCount = 0
const timesTwo = createComputed(
  () => {
    computeCount++
    console.log(`  [timesTwo updateFn #${computeCount}] Computing, input() =`, input())
    return input() * 2
  },
  undefined,
  undefined,
  { name: 'timesTwo' }
)

console.log('\nStep 2: Initial value')
console.log('  timesTwo():', timesTwo())

console.log('\nStep 3: Update input to 3')
setInput(3)

console.log('\nStep 4: Check timesTwo after update')
console.log('  timesTwo():', timesTwo())
console.log('  computeCount:', computeCount, '(should be 2)')
console.log('  Expected value: 6')
