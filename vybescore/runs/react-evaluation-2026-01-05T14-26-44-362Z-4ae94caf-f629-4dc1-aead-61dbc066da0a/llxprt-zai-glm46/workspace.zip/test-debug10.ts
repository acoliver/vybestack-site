import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'
import { getObserverForGetter } from './src/types/reactive.ts'

console.log('=== Debug: Check registration immediately ===')

const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input() =', input())
  return input() * 2
})

console.log('\nStep 2: Check if getter is registered')
const observer = getObserverForGetter(timesTwo as any)
console.log('  Observer found:', observer ? 'YES' : 'NO')
if (observer) {
  console.log('  Observer name:', observer.name || 'none')
  console.log('  Observer value:', observer.value)
  console.log('  Observer has dependencies:', observer.dependencies ? 'YES' : 'NO')
  if (observer.dependencies) {
    console.log('  Number of dependencies:', observer.dependencies.size)
  }
}

console.log('\nStep 3: Call setInput(3)')
setInput(3)

console.log('\nStep 4: Check timesTwo() after update')
console.log('  timesTwo():', timesTwo())
console.log('  Expected: 6')
