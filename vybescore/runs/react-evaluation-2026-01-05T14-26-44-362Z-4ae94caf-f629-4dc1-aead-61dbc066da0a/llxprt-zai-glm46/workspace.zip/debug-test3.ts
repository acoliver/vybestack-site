import { createInput, createComputed } from './src/index.js'

// Test to check if both timesTwo and timesThirty get notified
console.log('Test: Check which computed values get notified')
const [input, setInput] = createInput(1)

let timesTwoCallCount = 0
const timesTwo = createComputed(() => {
  timesTwoCallCount++
  console.log(`  timesTwo called (count: ${timesTwoCallCount}), input = ${input()}`)
  return input() * 2
})

let timesThirtyCallCount = 0
const timesThirty = createComputed(() => {
  timesThirtyCallCount++
  console.log(`  timesThirty called (count: ${timesThirtyCallCount}), input = ${input()}`)
  return input() * 30
})

let sumCallCount = 0
const sum = createComputed(() => {
  sumCallCount++
  const t2 = timesTwo()
  const t30 = timesThirty()
  console.log(`  sum called (count: ${sumCallCount}), timesTwo = ${t2}, timesThirty = ${t30}`)
  return t2 + t30
})

console.log('\n=== Initial Setup ===')
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())

console.log('\n=== After setInput(3) ===')
setInput(3)
console.log('After setInput completes:')
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())

console.log('\n=== Call Counts ===')
console.log('timesTwo called:', timesTwoCallCount, 'times')
console.log('timesThirty called:', timesThirtyCallCount, 'times')
console.log('sum called:', sumCallCount, 'times')
