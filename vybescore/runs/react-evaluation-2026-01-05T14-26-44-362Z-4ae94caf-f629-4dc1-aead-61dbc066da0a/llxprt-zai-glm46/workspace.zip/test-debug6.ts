import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'
import { getActiveObserver } from './src/types/reactive.ts'

console.log('=== Debug: Trace observer activation ===')

// Monkey-patch to trace
let activeCount = 0
const originalGetActiveObserver = getActiveObserver

// Let's add console.log to trace what's happening
const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  const active = getActiveObserver()
  console.log('  Computing timesTwo, input() =', input(), ', activeObserver:', active?.name || 'none')
  return input() * 2
})

console.log('\nStep 2: Access timesTwo()')
const result1 = timesTwo()
console.log('  Result:', result1)

console.log('\nStep 3: Update input to 3')
setInput(3)

console.log('\nStep 4: Access timesTwo() again')
const result2 = timesTwo()
console.log('  Result:', result2, ', Expected: 6')
