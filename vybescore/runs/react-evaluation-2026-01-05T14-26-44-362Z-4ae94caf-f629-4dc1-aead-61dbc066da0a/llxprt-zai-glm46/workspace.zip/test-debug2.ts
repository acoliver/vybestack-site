import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'

console.log('=== Debug: Testing computed value update ===')
const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input() =', input())
  return input() * 2
})

console.log('Step 2: Initial timesTwo value:', timesTwo())
console.log('Expected: 2')

console.log('\nStep 3: Update input to 3')
setInput(3)

console.log('Step 4: Check timesTwo after update:', timesTwo())
console.log('Expected: 6')
