import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'

console.log('=== Debug: Add logging to notifyObservers ===')
const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input() =', input())
  return input() * 2
})

console.log('Step 2: Access timesTwice')
console.log('  timesTwo():', timesTwo())

// Manually check what's registered
console.log('\nStep 3: Check registration (manual inspection)')
// We can't easily inspect the WeakMap, but we can trace the flow

console.log('\nStep 4: Update input to 3 and check if notifyObservers is called')
setInput(3)

console.log('\nStep 5: Check timesTwo after update')
console.log('  timesTwo():', timesTwo())
console.log('Expected: 6')
