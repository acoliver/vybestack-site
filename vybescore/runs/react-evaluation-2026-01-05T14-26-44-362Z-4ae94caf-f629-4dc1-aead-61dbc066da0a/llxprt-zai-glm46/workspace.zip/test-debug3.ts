import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'

console.log('=== Debug: Testing multiple computed values ===')
const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input() =', input())
  return input() * 2
})

console.log('Step 2: Create timesThirty computed')
const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input() =', input())
  return input() * 30
})

console.log('\nStep 3: Create sum computed (depends on timesTwo and timesThirty)')
const sum = createComputed(() => {
  console.log('  Computing sum, timesTwo() =', timesTwo(), ', timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('\nStep 4: Initial values')
console.log('  timesTwo():', timesTwo())
console.log('  timesThirty():', timesThirty())
console.log('  sum():', sum())
console.log('  Expected sum: 32')

console.log('\nStep 5: Update input to 3')
setInput(3)

console.log('\nStep 6: Check values after update')
console.log('  timesTwo():', timesTwo())
console.log('  timesThirty():', timesThirty())
console.log('  sum():', sum())
console.log('  Expected sum: 96')
