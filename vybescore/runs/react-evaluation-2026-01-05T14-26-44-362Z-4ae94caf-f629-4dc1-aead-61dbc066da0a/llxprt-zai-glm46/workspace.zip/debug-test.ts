import { createInput, createComputed, createCallback } from './src/index.js'

// Test 1: Basic computed update
console.log('Test 1: Basic computed update')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
console.log('Initial timesTwo:', timesTwo()) // Should be 2
setInput(3)
console.log('After setInput(3), timesTwo:', timesTwo()) // Should be 6

// Test 2: Nested computed
console.log('\nTest 2: Nested computed')
const [input2, setInput2] = createInput(1)
const timesTwo2 = createComputed(() => input2() * 2)
const timesThirty = createComputed(() => input2() * 30)
const sum = createComputed(() => timesTwo2() + timesThirty())
console.log('Initial sum:', sum()) // Should be 32
setInput2(3)
console.log('After setInput2(3), sum:', sum()) // Should be 96

// Test 3: Callback
console.log('\nTest 3: Callback')
const [input3, setInput3] = createInput(1)
const output = createComputed(() => input3() + 1)
let value = 0
createCallback(() => (value = output()))
console.log('Initial value:', value) // Should be 2
setInput3(3)
console.log('After setInput3(3), value:', value) // Should be 4
