import { createInput, createComputed } from './src/index.js'

// Test dependency tracking
console.log('Test: Dependency tracking')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  return input() * 30
})
const sum = createComputed(() => {
  console.log('  Computing sum, timesTwo =', timesTwo(), ', timesThirty =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Initial computation:')
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())

console.log('\nAfter setInput(3):')
setInput(3)
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
