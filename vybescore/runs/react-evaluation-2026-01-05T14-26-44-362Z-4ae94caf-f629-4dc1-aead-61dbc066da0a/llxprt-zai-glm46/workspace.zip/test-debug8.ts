import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'
import { getActiveObserver } from './src/types/reactive.ts'

console.log('=== Debug: Check if observers are being added ===')

const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [updateFn] activeObserver:', active ? 'SET' : 'none')
  const val = input()
  console.log('  [updateFn] input() =', val)
  return val * 2
})

console.log('\nStep 2: First access to timesTwo()')
const v1 = timesTwo()
console.log('  Result:', v1)

console.log('\nStep 3: Before setInput, lets call timesTwo() again to see if activeObserver is set')
const v2 = timesTwo()
console.log('  Result:', v2)

console.log('\nStep 4: Now call setInput(3)')
setInput(3)

console.log('\nStep 5: Call timesTwo() after setInput')
const v3 = timesTwo()
console.log('  Result:', v3, ', Expected: 6')
