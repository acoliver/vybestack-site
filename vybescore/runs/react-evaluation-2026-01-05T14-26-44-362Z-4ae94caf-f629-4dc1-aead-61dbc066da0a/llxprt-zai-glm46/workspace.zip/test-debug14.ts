import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'
import { getObserverForGetter } from './src/types/reactive.ts'

console.log('=== Debug: Check updateObserver behavior ===')

const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
let computeCount = 0
const timesTwo = createComputed(() => {
  computeCount++
  console.log(`  [updateFn #${computeCount}] Computing timesTwo, input() =`, input())
  return input() * 2
})

console.log('\nStep 2: Check timesTwo observer')
const timesTwoObserver = getObserverForGetter(timesTwo as any)
console.log('  timesTwoObserver found:', timesTwoObserver ? 'YES' : 'NO')
if (timesTwoObserver) {
  console.log('  timesTwoObserver.value:', timesTwoObserver.value)
}

console.log('\nStep 3: Check input observer')
const inputObserver = getObserverForGetter(input as any)
console.log('  inputObserver found:', inputObserver ? 'YES' : 'NO')
if (inputObserver) {
  console.log('  inputObserver.value:', inputObserver.value)
}

console.log('\nStep 4: Call setInput(3)')
setInput(3)

console.log('\nStep 5: Check timesTwo observer after setInput')
if (timesTwoObserver) {
  console.log('  timesTwoObserver.value:', timesTwoObserver.value)
}

console.log('\nStep 6: Check timesTwo() result')
console.log('  timesTwo():', timesTwo())
console.log('  computeCount:', computeCount)
console.log('  Expected: 6')
