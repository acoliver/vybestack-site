import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'

console.log('=== Debug: Check observer registration ===')
const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input() =', input())
  return input() * 2
})

console.log('Step 2: Access timesTwo to trigger registration')
console.log('  timesTwo():', timesTwo())

console.log('\nStep 3: Update input to 3')
setInput(3)

console.log('Step 4: Check timesTwo after update')
console.log('  timesTwo():', timesTwo())
console.log('Expected: 6')
