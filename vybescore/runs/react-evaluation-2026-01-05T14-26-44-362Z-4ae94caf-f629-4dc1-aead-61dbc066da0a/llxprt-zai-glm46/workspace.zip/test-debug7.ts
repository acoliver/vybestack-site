import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'
import { getActiveObserver } from './src/types/reactive.ts'

// Let's add logging to the reactive system
console.log('=== Debug: Full trace with logging ===')

const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
const timesTwo = createComputed(() => {
  const active = getActiveObserver()
  console.log('  [Inside updateFn] activeObserver:', active?.name || 'none')
  const val = input()
  console.log('  [Inside updateFn] input() =', val, ', returning', val * 2)
  return val * 2
})

console.log('\nStep 2: Access timesTwo() first time')
console.log('  timesTwo():', timesTwo())

console.log('\nStep 3: Update input to 3')
console.log('  Calling setInput(3)...')
setInput(3)
console.log('  setInput returned')

console.log('\nStep 4: Access timesTwo() second time')
console.log('  timesTwo():', timesTwo())
console.log('  Expected: 6')
