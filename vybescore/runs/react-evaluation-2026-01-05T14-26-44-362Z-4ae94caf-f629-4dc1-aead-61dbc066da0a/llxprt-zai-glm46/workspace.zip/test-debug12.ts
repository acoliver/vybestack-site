import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'
import { getObserverForGetter } from './src/types/reactive.ts'

console.log('=== Debug: Check if input getter is registered ===')

const [input, setInput] = createInput(1)

console.log('Step 1: Check if input getter is registered')
const inputObserver = getObserverForGetter(input as any)
console.log('  Input observer found:', inputObserver ? 'YES' : 'NO')

console.log('\nStep 2: Create timesTwo computed')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input() =', input())
  return input() * 2
})

console.log('\nStep 3: Check registered observers')
const timesTwoObserver = getObserverForGetter(timesTwo as any)
console.log('  timesTwo observer found:', timesTwoObserver ? 'YES' : 'NO')
if (timesTwoObserver && timesTwoObserver.dependencies) {
  console.log('  timesTwo dependencies:', Array.from(timesTwoObserver.dependencies))
  
  // Check if the input getter is in the dependencies
  const hasInput = timesTwoObserver.dependencies.has(input as any)
  console.log('  Has input getter in dependencies:', hasInput)
}

console.log('\nStep 4: Call setInput(3)')
setInput(3)

console.log('\nStep 5: Check timesTwo() after update')
console.log('  timesTwo():', timesTwo())
console.log('  Expected: 6')
