import { createInput } from './src/core/input.ts'
import { createComputed } from './src/core/computed.ts'
import { getActiveObserver } from './src/types/reactive.ts'

console.log('=== Debug: Manual notification check ===')

const [input, setInput] = createInput(1)

console.log('Step 1: Create timesTwo computed')
let computeCount = 0
const timesTwo = createComputed(() => {
  computeCount++
  const active = getActiveObserver()
  console.log(`  [updateFn #${computeCount}] activeObserver:`, active ? 'SET' : 'none')
  const val = input()
  console.log(`  [updateFn #${computeCount}] input() =`, val)
  return val * 2
})

console.log('\nStep 2: First access to timesTwo()')
console.log('  timesTwo():', timesTwo())
console.log('  computeCount:', computeCount)

console.log('\nStep 3: Call setInput(3)')
setInput(3)
console.log('  computeCount after setInput:', computeCount, '(should still be 1 if not called)')

console.log('\nStep 4: Call timesTwo() after setInput')
console.log('  timesTwo():', timesTwo())
console.log('  computeCount:', computeCount, '(should be 2 if updateObserver was called)')
console.log('  Expected: 6')
