import { createInput, createComputed } from './src/index.js'

const [input, setInput] = createInput(1, undefined, { name: 'input' })
const timesTwo = createComputed(() => {
  console.log('timesTwo recomputing, input():', input())
  return input() * 2
}, undefined, undefined, { name: 'timesTwo' })

const timesThirty = createComputed(() => {
  console.log('timesThirty recomputing, input():', input())
  return input() * 30
}, undefined, undefined, { name: 'timesThirty' })

const sum = createComputed(() => {
  console.log('sum recomputing, timesTwo():', timesTwo(), ', timesThirty():', timesThirty())
  return timesTwo() + timesThirty()
}, undefined, undefined, { name: 'sum' })

console.log('Initial sum():', sum())
console.log('--- Setting input to 3 ---')
setInput(3)
console.log('After setInput(3), sum():', sum())
