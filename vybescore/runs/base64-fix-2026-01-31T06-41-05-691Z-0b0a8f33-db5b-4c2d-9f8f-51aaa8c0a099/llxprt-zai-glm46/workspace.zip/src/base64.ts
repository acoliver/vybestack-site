/**
 * Regular expression to validate Base64 strings.
 * Matches the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with optional padding.
 */
const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input string.
 * Throws an error if the input is clearly invalid.
 */
function validateBase64Input(input: string): void {
  // Check if the input only contains valid Base64 characters
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for invalid padding (padding must be at the end and 0-2 characters)
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    // Padding must appear only at the end
    const beforePadding = input.slice(0, -paddingLength);
    if (beforePadding.includes('=')) {
      throw new Error('Invalid Base64 input: padding characters in the middle');
    }
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  validateBase64Input(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
