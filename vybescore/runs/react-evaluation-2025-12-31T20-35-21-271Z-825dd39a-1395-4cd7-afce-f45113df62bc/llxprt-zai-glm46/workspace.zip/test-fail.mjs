// Reproduce the failing test
import { createInput, createComputed, createCallback } from './src/index.ts'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial sum:', sum())
console.log('timesTwo:', timesTwo(), 'timesThirty:', timesThirty())
console.log('sum._deps:', Array.from(sum._computedObserver._deps || []).map(o => o.value))

console.log('\nsetInput(3)')
setInput(3)
console.log('After update:')
console.log('timesTwo:', timesTwo(), 'timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 96 (3*2 + 3*30 = 6 + 90 = 96)')
