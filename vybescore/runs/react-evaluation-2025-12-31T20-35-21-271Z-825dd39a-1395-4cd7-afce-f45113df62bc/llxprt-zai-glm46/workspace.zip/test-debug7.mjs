import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

const doubled = createComputed(() => {
  const result = input() * 2
  console.log('doubled computing, result =', result)
  return result
})

const sum = createComputed(() => {
  const d = doubled()
  console.log('sum computing, doubled() =', d, ', returning', d + 10)
  return d + 10
})

console.log('Initial: sum() =', sum())

console.log('\n=== Input notification flow ===')
console.log('Before setInput:')
console.log('  input subject observers:', input._subject ? Array.from(input._subject.observers).map(o => o.value) : 'N/A')
console.log('  doubled._deps:', Array.from(doubled._computedObserver._deps || []).map(o => o.value))
console.log('  sum._deps:', Array.from(sum._computedObserver._deps || []).map(o => o.value))

setInput(3)

console.log('\nAfter setInput:')
console.log('  doubled observer value:', doubled._computedObserver.value)
console.log('  sum observer value:', sum._computedObserver.value)
console.log('  sum() =', sum())
