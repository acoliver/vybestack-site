import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Test: compute cells can depend on other compute cells ===')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 32')

console.log('\nSetting input to 3...')
setInput(3)

console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 96')
