// Add logging to updateObserver
import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

const doubled = createComputed(() => {
  console.log('  [doubled] computing...')
  return input() * 2
})

const sum = createComputed(() => {
  console.log('  [sum] computing...')
  const d = doubled()
  console.log('  [sum] got d =', d)
  return d + 10
})

console.log('Initial: sum() =', sum())

console.log('\n=== setInput(3) ===')
setInput(3)
console.log('After setInput:')
console.log('  doubled observer value:', doubled._computedObserver.value)
console.log('  sum observer value:', sum._computedObserver.value)
console.log('  sum() =', sum())
