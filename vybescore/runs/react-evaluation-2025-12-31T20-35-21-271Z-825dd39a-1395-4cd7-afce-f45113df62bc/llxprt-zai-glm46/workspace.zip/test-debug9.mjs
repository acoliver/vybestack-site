// Test if dependency tracking is re-establishing correctly
import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

const doubled = createComputed(() => {
  const result = input() * 2
  console.log('doubled: computing, result =', result)
  return result
})

const sum = createComputed(() => {
  const d = doubled()
  console.log('sum: computing, doubled() =', d)
  return d + 10
})

console.log('Initial sum() =', sum())
console.log('Before update, sum._deps:', Array.from(sum._computedObserver._deps || []).map(o => ({ value: o.value, same: o === doubled._computedObserver })))

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\nAfter setInput:')
console.log('doubled value:', doubled._computedObserver.value)
console.log('sum value:', sum._computedObserver.value)
console.log('After update, sum._deps:', Array.from(sum._computedObserver._deps || []).map(o => ({ value: o.value, same: o === doubled._computedObserver })))

console.log('\n=== Calling sum() again ===')
console.log('sum() =', sum())
console.log('After calling sum(), sum._deps:', Array.from(sum._computedObserver._deps || []).map(o => ({ value: o.value, same: o === doubled._computedObserver })))
