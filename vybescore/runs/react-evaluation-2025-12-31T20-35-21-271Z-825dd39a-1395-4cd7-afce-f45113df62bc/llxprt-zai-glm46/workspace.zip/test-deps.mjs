import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial state:')
console.log('  timesTwo value:', timesTwo._computedObserver.value)
console.log('  timesThirty value:', timesThirty._computedObserver.value)
console.log('  sum value:', sum._computedObserver.value)
console.log('  sum._deps:', Array.from(sum._computedObserver._deps || []).map(o => o.value))

console.log('\nAfter setInput(3):')
setInput(3)

console.log('  timesTwo value:', timesTwo._computedObserver.value)
console.log('  timesThirty value:', timesThirty._computedObserver.value)
console.log('  sum value:', sum._computedObserver.value)
console.log('  sum._deps:', Array.from(sum._computedObserver._deps || []).map(o => o.value))

console.log('\nThe issue: sum._deps contains the old values (2, 30), not the observer objects')
console.log('We need to check if the dependencies are still the same observer objects')
console.log('  sum._deps[0] === timesTwo._computedObserver:', Array.from(sum._computedObserver._deps || [])[0] === timesTwo._computedObserver)
console.log('  sum._deps[1] === timesThirty._computedObserver:', Array.from(sum._computedObserver._deps || [])[1] === timesThirty._computedObserver)
