/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  _disposed?: boolean  // Track disposal state
  _deps?: Set<ObserverR>  // Internal dependencies for computed observers (who this computed depends on)
  _dependentObservers?: Set<ObserverR>  // Observers that depend on this computed (reverse mapping)
  _updating?: boolean  // Prevent duplicate updates
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let batchDepth = 0

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Skip if observer is disposed or already updating
  if (observer._disposed || observer._updating) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  observer._updating = true
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    observer._updating = false
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Notify observers in order
  const toNotify = Array.from(subject.observers)
  for (const observer of toNotify) {
    if (!observer._disposed && !observer._updating) {
      updateObserver(observer as Observer<T>)
    }
  }
  
  // After updating all direct observers, propagate to dependent computeds
  if (batchDepth === 0) {
    for (const observer of toNotify) {
      if (!observer._disposed) {
        notifyDependentObservers(observer)
      }
    }
  }
}

export function notifyDependentObservers(observer: ObserverR): void {
  const dependentObservers = observer._dependentObservers
  if (dependentObservers && dependentObservers.size > 0) {
    // Create a copy to avoid issues if set is modified during iteration
    const toNotify = Array.from(dependentObservers)
    for (const dep of toNotify) {
      if (!dep._disposed && !dep._updating) {
        // Update dependent computed
        updateObserver(dep as Observer<unknown>)
        
        // Recursively notify its dependents
        notifyDependentObservers(dep)
      }
    }
  }
}

export function notifyComputedDependencies(observer: ObserverR): void {
  // This function is no longer used, kept for compatibility
  notifyDependentObservers(observer)
}

export function batchUpdate<T>(fn: () => T): T {
  batchDepth++
  try {
    return fn()
  } finally {
    batchDepth--
    if (batchDepth === 0) {
      // After batch completes, propagate to all dependent observers
      // This is handled by notifyObservers when batchDepth === 0
    }
  }
}
