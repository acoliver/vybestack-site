/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    _dependentObservers: new Set<ObserverR>(),  // Track observers that depend on this computed
  }
  
  // Track dependencies for this computed
  const dependencies: Set<ObserverR> = new Set()
  ;(o as Observer<T> & { _deps: Set<ObserverR> })._deps = dependencies
  
  // Return getter that:
  // 1. Registers this computed as an observer when accessed by another computed
  // 2. Returns the cached value
  const getter = (): T => {
    // When this computed is accessed by another computed during its updateFn,
    // the activeObserver will be that other computed's observer.
    const active = getActiveObserver()
    if (active && active !== o) {
      // The active observer (another computed) depends on this computed
      // Add this computed's observer to the active observer's dependencies
      const activeDeps = (active as Observer<unknown> & { _deps: Set<ObserverR> })._deps
      if (activeDeps) {
        activeDeps.add(o)
      }
      // Also add the active observer to this computed's dependent observers
      const dependentObservers = (o as Observer<T> & { _dependentObservers: Set<ObserverR> })._dependentObservers
      if (dependentObservers) {
        dependentObservers.add(active)
      }
    }
    return o.value!
  }
  
  // Attach observer to getter for dependency tracking
  ;(getter as GetterFn<T> & { _computedObserver: Observer<T> })._computedObserver = o
  
  // Initialize by running updateFn to track dependencies
  updateObserver(o)
  
  return getter
}
