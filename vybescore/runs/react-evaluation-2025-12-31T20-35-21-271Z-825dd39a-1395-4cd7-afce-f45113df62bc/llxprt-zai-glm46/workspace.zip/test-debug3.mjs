import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Test: compute cells can depend on other compute cells ===')

// Create the reactive chain
const [input, setInput] = createInput(1)

console.log('Created input')

const timesTwo = createComputed(() => {
  console.log('  > timesTwo updateFn called, input() =', input())
  return input() * 2
})

console.log('Created timesTwo')

const timesThirty = createComputed(() => {
  console.log('  > timesThirty updateFn called, input() =', input())
  return input() * 30
})

console.log('Created timesThirty')

const sum = createComputed(() => {
  console.log('  > sum updateFn called, timesTwo() =', timesTwo(), ', timesThirty() =', timesThirty())
  return timesTwo() + timesThirty()
})

console.log('Created sum')

// Access sum._computedObserver._deps to see dependencies
const sumObs = (sum as any)._computedObserver
console.log('sum observer _deps:', sumObs._deps)

console.log('sum() =', sum())

console.log('\n=== Setting input to 3 ===')
setInput(3)
console.log('After setInput, sum() =', sum())
