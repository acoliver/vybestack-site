import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

console.log('=== Creating doubled ===')
const doubled = createComputed(() => {
  console.log('  doubled: computing...')
  return input() * 2
})
console.log('doubled created, initial value:', doubled())
console.log('doubled._computedObserver.value:', doubled._computedObserver.value)
console.log()

console.log('=== Creating sum ===')
const sum = createComputed(() => {
  console.log('  sum: computing...')
  const d = doubled()
  console.log('  sum: doubled() =', d)
  return d + 10
})
console.log('sum created, initial value:', sum())
console.log('sum._computedObserver.value:', sum._computedObserver.value)
console.log('sum._computedObserver._deps:', Array.from(sum._computedObserver._deps || []).map(o => o.value))
console.log()

console.log('=== setInput(3) ===')
setInput(3)
console.log('After setInput:')
console.log('  doubled._computedObserver.value:', doubled._computedObserver.value)
console.log('  sum._computedObserver.value:', sum._computedObserver.value)
console.log('  sum() =', sum())
