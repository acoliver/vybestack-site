/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  getActiveObserver,
  registerDependency,
  notifyDependents,
  Observer
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T>
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === true) {
    equalFn = (a, b) => a === b
  } else {
    equalFn = () => false
  }

  // Initialize with guaranteed value
  let currentValue = value
  const inputObserver: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (currentValue) => currentValue || value,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(inputObserver, observer)
    }
    return currentValue
  }

  const write: SetterFn<T> = (nextValue: T): T => {
    if (!equalFn(currentValue, nextValue)) {
      currentValue = nextValue
      inputObserver.value = currentValue
      notifyDependents(inputObserver)
    }
    return currentValue
  }

  return [read, write]
}