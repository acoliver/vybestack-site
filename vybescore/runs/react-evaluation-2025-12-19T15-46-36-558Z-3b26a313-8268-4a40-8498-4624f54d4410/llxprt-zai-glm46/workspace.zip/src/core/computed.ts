/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn,
  registerDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T>
  
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === true) {
    equalFn = (a, b) => a === b
  } else {
    equalFn = () => false
  }

  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue) => {
      // Recompute the value - this will re-establish dependencies
      const newValue = updateFn(currentValue)
      
      if (computedObserver.value !== undefined && equalFn(computedObserver.value, newValue)) {
        return computedObserver.value
      }
      
      computedObserver.value = newValue
      
      // Notify dependents when value changes
      notifyDependents(computedObserver)
      
      return newValue
    },
  }
  
  const read = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      registerDependency(computedObserver, observer)
    }
    if (computedObserver.value === undefined) {
      // Compute value if not already computed
      updateObserver(computedObserver)
    }
    return computedObserver.value!
  }
  
  // Initial computation
  updateObserver(computedObserver)
  
  return read
}