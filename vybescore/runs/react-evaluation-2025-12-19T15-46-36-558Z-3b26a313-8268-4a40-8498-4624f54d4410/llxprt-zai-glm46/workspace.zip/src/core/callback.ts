/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, unregisterObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const callbackObserver: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      if (!disposed) {
        // When callback runs, it can create dependencies
        return updateFn(currentValue)
      }
      return currentValue!
    },
  }
  
  // Initial effect run to establish dependencies
  updateObserver(callbackObserver)
  
  return () => {
    disposed = true
    unregisterObserver(callbackObserver)
  }
}