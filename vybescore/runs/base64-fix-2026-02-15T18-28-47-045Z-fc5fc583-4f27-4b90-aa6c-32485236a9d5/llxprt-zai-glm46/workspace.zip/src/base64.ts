/**
 * Validate that a string contains only valid Base64 characters.
 * Standard Base64 alphabet: A-Z, a-z, 0-9, +, /, and optional padding (=)
 */
function isValidBase64(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws an error for invalid Base64 strings.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the input contains only valid Base64 characters
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding produced any data (valid base64 should produce at least one byte)
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: decoding produced no output');
    }

    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
