/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  updateObserver,
  setActiveObserver,
  EqualFn,
  Options,
  Subject
} from '../types/reactive.js'

interface ComputedGetter<T> extends GetterFn<T> {
  observer: Observer<T>
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const subjects: Set<Subject<any>> = new Set()
  const dependents: Set<Observer<any>> = new Set()

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev?: T) => {
      // Recompute by calling the user's updateFn
      const result = updateFn(prev)
      return result
    },
    subject: undefined,
    observers: dependents,
  }

  const getter = (): T => {
    // Always track dependencies when getter is called
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed observer with all tracked subjects
      for (const subject of subjects) {
        subject.observers.add(o)
      }
      
      // When this computed is accessed by another observer,
      // register that observer with this computed's dependents
      dependents.add(observer)
    }
    return o.value!
  }

  ;(getter as ComputedGetter<T>).observer = o

  // Track dependencies during initial computation
  const previousObserver = getActiveObserver()
  
  // Use the actual observer as the active one during initial computation
  // This way, when input() is called, it will register the subject with this observer
  setActiveObserver(o)
  try {
    o.value = updateFn(o.value)
  } finally {
    setActiveObserver(previousObserver)
  }

  // o.subject should now be set by the input() calls
  // Capture all subjects we're now registered with
  if (o.subject) {
    subjects.add(o.subject)
  }

  // Override updateFn to also notify dependents
  const originalUpdateFn = o.updateFn
  o.updateFn = (prev?: T) => {
    // First recompute the value
    const result = originalUpdateFn(prev)
    
    // Update the value in the observer
    o.value = result
    
    // Notify all dependents
    for (const dep of Array.from(dependents)) {
      updateObserver(dep)
    }
    
    return result
  }

  return getter
}
