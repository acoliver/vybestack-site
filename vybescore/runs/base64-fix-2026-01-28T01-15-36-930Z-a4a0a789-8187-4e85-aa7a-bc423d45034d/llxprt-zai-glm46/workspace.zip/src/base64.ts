const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate if a string is valid Base64.
 * Throws an error if the input contains invalid characters or malformed padding.
 */
function validateBase64(input: string): void {
  // Check for valid Base64 characters
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64: contains illegal characters');
  }

  // Check padding is correctly placed at the end
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingCount = paddingMatch[0].length;
    if (paddingCount > 2) {
      throw new Error('Invalid Base64: too much padding');
    }
    // If there's padding, verify all = characters are at the end
    const firstEqualsIndex = input.indexOf('=');
    // Padding should start at position (input.length - paddingCount) and continue to end
    if (firstEqualsIndex !== input.length - paddingCount) {
      throw new Error('Invalid Base64: padding not at end');
    }
  }

  // Base64 string length must be a multiple of 4 (after accounting for padding)
  const withoutPadding = input.replace(/=+$/, '');
  if (withoutPadding.length % 4 === 1) {
    throw new Error('Invalid Base64: incorrect length');
  }
}

/**
 * Encode plain text to Base64.
 * Uses standard Base64 encoding with padding for compatibility.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and validates the input.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Remove any whitespace that might have been accidentally included
  const normalized = input.trim();

  // Validate the Base64 input
  validateBase64(normalized);

  try {
    const buffer = Buffer.from(normalized, 'base64');
    
    // Check if decoding actually worked (Buffer.from doesn't always throw on invalid input)
    // Re-encode and compare to detect obviously invalid input
    const reEncoded = buffer.toString('base64').replace(/=+$/, '');
    const normalizedNoPadding = normalized.replace(/=+$/, '');
    
    // If the input is not valid base64, the re-encoded version won't match
    if (normalizedNoPadding && reEncoded === '' && buffer.length === 0) {
      throw new Error('Invalid Base64: failed to decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw new Error(`Failed to decode Base64 input: ${error.message}`);
    }
    throw new Error('Failed to decode Base64 input');
  }
}
