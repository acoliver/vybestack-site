import express from 'express';
import path from 'path';
import dbManager from './database.js';
import { validateForm, FormData } from './validation.js';

export class Server {
  private app: express.Application;
  private server: ReturnType<typeof this.app.listen> | null = null;
  private port: number;
  private isInitialized: boolean = false;

  constructor() {
    this.app = express();
    this.port = parseInt(process.env.PORT || '3535');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Parse JSON and URL-encoded bodies
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));

    // Serve static files
    this.app.use('/public', express.static(path.join(process.cwd(), 'public')));

    // Set EJS as the view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'src', 'templates'));
  }

  private setupRoutes(): void {
    // GET / - Show the form
    this.app.get('/', (req, res) => {
      res.render('form', {
        values: {},
        errors: {}
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', async (req, res) => {
      try {
        const formData: FormData = {
          first_name: req.body.first_name || '',
          last_name: req.body.last_name || '',
          street_address: req.body.street_address || '',
          city: req.body.city || '',
          state_province: req.body.state_province || '',
          postal_code: req.body.postal_code || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        // Validate the form data
        const validationResult = validateForm(formData);

        if (!validationResult.isValid) {
          // Re-render the form with errors and previous values
          return res.status(400).render('form', {
            values: formData,
            errors: validationResult.errors
          });
        }

        // Save to database
        await dbManager.insertSubmission(formData);

        // Redirect to thank-you page with first name
        res.redirect(302, `/thank-you?first_name=${encodeURIComponent(formData.first_name)}`);
      } catch (error) {
        console.error('Error processing form submission:', error);
        res.status(500).render('form', {
          values: req.body,
          errors: { general: 'An error occurred while processing your submission. Please try again.' }
        });
      }
    });

    // GET /thank-you - Show thank you page
    this.app.get('/thank-you', (req, res) => {
      res.render('thank-you', {
        first_name: req.body.first_name || req.query.first_name || 'there'
      });
    });

    // 404 handler
    this.app.use((req, res) => {
      res.status(404).send('Page not found');
    });
  }

  public async initialize(): Promise<void> {
    try {
      // Initialize database
      await dbManager.initialize();
      this.isInitialized = true;
    } catch (error) {
      console.error('Failed to initialize server:', error);
      throw error;
    }
  }

  public async start(): Promise<void> {
    try {
      // Initialize database if not already done
      if (!this.isInitialized) {
        await this.initialize();
      }

      // Start the server
      this.server = this.app.listen(this.port, () => {
        console.log(`Server is running on port ${this.port}`);
      });

      // Handle graceful shutdown
      this.setupGracefulShutdown();
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }

  private setupGracefulShutdown(): void {
    const gracefulShutdown = async (signal: string) => {
      console.log(`Received ${signal}. Starting graceful shutdown...`);
      
      if (this.server) {
        this.server.close();
      }
      
      try {
        await dbManager.close();
        console.log('Database closed successfully');
        console.log('Graceful shutdown completed');
        process.exit(0);
      } catch (error) {
        console.error('Error during graceful shutdown:', error);
        process.exit(1);
      }
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  }

  public getApp(): express.Application {
    return this.app;
  }

  public async stop(): Promise<void> {
    if (this.server) {
      this.server.close();
    }
    await dbManager.close();
  }
}

// Create and start the server (only if this file is run directly)
if (import.meta.url === `file://${process.argv[1]}`) {
  const server = new Server();
  server.start().catch(console.error);
}