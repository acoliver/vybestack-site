export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

const phoneRegex = /^\+?[\d\s\-()]+$/;

export function validateEmail(email: string): boolean {
  if (!email || email.trim().length === 0) return false;
  return emailRegex.test(email.trim());
}

export function validatePhone(phone: string): boolean {
  if (!phone || phone.trim().length === 0) return false;
  const cleaned = phone.trim();
  // Must contain only digits, spaces, parentheses, dashes, and leading +
  if (!phoneRegex.test(cleaned)) return false;
  // Must have at least some digits
  const digitCount = (cleaned.match(/\d/g) || []).length;
  return digitCount >= 7; // Reasonable minimum for a phone number
}

export function validatePostalCode(postalCode: string): boolean {
  if (!postalCode || postalCode.trim().length === 0) return false;
  const cleaned = postalCode.trim();
  // Allow alphanumeric characters, spaces, and hyphens
  // Support formats like "SW1A 1AA", "C1000", "B1675"
  return /^[A-Za-z0-9\s-]+$/.test(cleaned) && cleaned.length >= 3;
}

export function validateRequired(value: string): boolean {
  return !!(value && value.trim().length > 0);
}

export function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Validate required fields
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!validateRequired(data[field])) {
      errors[field] = 'This field is required';
    }
  });

  // Validate email
  if (data.email && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Validate phone
  if (data.phone && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Validate postal code
  if (data.postal_code && !validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}