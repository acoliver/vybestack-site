import initSqlJs from 'sql.js';
import fs from 'fs';
import path from 'path';
import type { Database as SqlJsDatabase, SqlJsStatic } from 'sql.js';

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private static instance: DatabaseManager;
  private db: SqlJsDatabase | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  private constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  public static getInstance(): DatabaseManager {
    if (!DatabaseManager.instance) {
      DatabaseManager.instance = new DatabaseManager();
    }
    return DatabaseManager.instance;
  }

  public async initialize(): Promise<void> {
    if (this.sqlJs && this.db) return;

    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => {
        return path.resolve(process.cwd(), 'node_modules/sql.js/dist/', file);
      }
    }) as SqlJsStatic;

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const filebuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(filebuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
      await this.saveDatabase();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    
    this.db.exec(schema);
  }

  public async insertSubmission(data: SubmissionData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  public async saveDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(this.dbPath, buffer);
  }

  public async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default DatabaseManager.getInstance();