import { describe, expect, it, beforeAll, afterAll, beforeEach } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import { load as loadCheerio } from 'cheerio';
import { Server } from '../../src/server';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  let server: import('express').Express;

  beforeAll(async () => {
    // Create a test server instance
    const testServer = new Server();
    await testServer.initialize(); // Initialize the database
    server = testServer.getApp();
    
    // Clean up database before tests
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  afterAll(async () => {
    // Clean up database after tests
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  beforeEach(() => {
    // Ensure clean state before each test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });

  it('renders the form with all required fields', async () => {
    const response = await request(server)
      .get('/')
      .expect(200);

    const $ = loadCheerio(response.text);
    
    // Check for all form fields
    expect($('#first_name').length).toBe(1);
    expect($('#last_name').length).toBe(1);
    expect($('#street_address').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#state_province').length).toBe(1);
    expect($('#postal_code').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);

    // Check labels are associated with inputs
    expect($('label[for="first_name"]').length).toBe(1);
    expect($('label[for="last_name"]').length).toBe(1);
    expect($('label[for="street_address"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('label[for="state_province"]').length).toBe(1);
    expect($('label[for="postal_code"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);
  });

  it('validates required fields', async () => {
    const response = await request(server)
      .post('/submit')
      .send({})
      .expect(400);

    const $ = loadCheerio(response.text);
    
    // Check that error messages are displayed
    expect($('.error-list').length).toBe(1);
    expect($('.error-text').length).toBeGreaterThan(0);
  });

  it('validates email format', async () => {
    const invalidData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'USA',
      email: 'invalid-email',
      phone: '+1 555 123 4567'
    };

    const response = await request(server)
      .post('/submit')
      .send(invalidData)
      .expect(400);

    const $ = loadCheerio(response.text);
    expect($('.error-text').text()).toContain('email');
  });

  it('validates phone number format', async () => {
    const invalidData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'USA',
      email: 'john@example.com',
      phone: 'invalid-phone'
    };

    const response = await request(server)
      .post('/submit')
      .send(invalidData)
      .expect(400);

    const $ = loadCheerio(response.text);
    expect($('.error-text').text()).toContain('phone');
  });

  it('persists submission and redirects to thank-you page', async () => {
    const validData = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main St',
      city: 'New York',
      state_province: 'NY',
      postal_code: '10001',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555 123 4567'
    };

    // Submit the form
    const response = await request(server)
      .post('/submit')
      .send(validData)
      .expect(302);

    // Check redirect to thank-you page
    expect(response.headers.location).toContain('/thank-you');
    
    // Follow the redirect
    const thankYouResponse = await request(server)
      .get(response.headers.location)
      .expect(200);

    const $ = loadCheerio(thankYouResponse.text);
    expect($('h1').text()).toContain('Thank you, John!');
  });

  it('stores data in database file', async () => {
    const validData = {
      first_name: 'Jane',
      last_name: 'Smith',
      street_address: '456 Oak Ave',
      city: 'London',
      state_province: 'Greater London',
      postal_code: 'SW1A 1AA',
      country: 'UK',
      email: 'jane@example.co.uk',
      phone: '+44 20 7946 0958'
    };

    // Submit the form
    await request(server)
      .post('/submit')
      .send(validData)
      .expect(302);

    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('displays thank-you page with personal greeting', async () => {
    const response = await request(server)
      .get('/thank-you?first_name=Alice')
      .expect(200);

    const $ = loadCheerio(response.text);
    expect($('h1').text()).toContain('Thank you, Alice!');
    expect($('.submit-btn[href="/"]').length).toBe(1);
  });

  it('handles international postal codes and phone numbers', async () => {
    const internationalData = {
      first_name: 'Carlos',
      last_name: 'González',
      street_address: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      state_province: 'CABA',
      postal_code: 'C1000',
      country: 'Argentina',
      email: 'carlos@example.com.ar',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(server)
      .post('/submit')
      .send(internationalData)
      .expect(302);

    // Should redirect successfully
    expect(response.headers.location).toContain('/thank-you');
  });

  it('serves the stylesheet from /public/styles.css', async () => {
    const response = await request(server)
      .get('/public/styles.css')
      .expect(200);

    expect(response.headers['content-type']).toContain('text/css');
    expect(response.text).toContain(':root');
  });
});