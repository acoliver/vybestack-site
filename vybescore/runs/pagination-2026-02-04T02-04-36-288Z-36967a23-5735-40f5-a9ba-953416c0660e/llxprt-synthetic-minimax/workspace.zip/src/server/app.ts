import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    const errors: string[] = [];

    if (pageParam !== undefined) {
      const page = Number(pageParam);
      if (isNaN(page) || !isFinite(page)) {
        errors.push('page must be a valid number');
      } else if (page <= 0) {
        errors.push('page must be greater than 0');
      } else if (page > 10000) {
        errors.push('page value is excessive');
      }
    }

    if (limitParam !== undefined) {
      const limit = Number(limitParam);
      if (isNaN(limit) || !isFinite(limit)) {
        errors.push('limit must be a valid number');
      } else if (limit <= 0) {
        errors.push('limit must be greater than 0');
      } else if (limit > 1000) {
        errors.push('limit value is excessive');
      }
    }

    if (errors.length > 0) {
      res.status(400).json({ error: 'Invalid parameters', details: errors });
      return;
    }

    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
