/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Wrap updateFn to check disposed state before executing
  const originalUpdateFn = updateFn
  const wrappedUpdateFn = (val?: T) => {
    if (disposed) {
      return value as T
    }
    const result = originalUpdateFn(val)
    return result
  }
  observer.updateFn = wrappedUpdateFn
  
  // Register observer to track dependencies - this will populate observer.subjects
  updateObserver(observer)
  
  // Get the subjects that were tracked during updateObserver
  // Note: observer.subjects is populated by input.read() when it calls getActiveObserver()
  const subjects = observer.subjects || new Set()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all tracked subjects
    for (const subject of subjects) {
      const s = subject as { observers: Set<unknown> }
      s.observers.delete(observer)
    }
    subjects.clear()
    
    // Clear the observer to stop further updates
    observer.value = undefined
  }
}
