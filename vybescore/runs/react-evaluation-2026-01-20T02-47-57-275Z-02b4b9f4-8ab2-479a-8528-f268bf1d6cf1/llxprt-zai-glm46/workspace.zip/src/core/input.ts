/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Track this subject for the observer's cleanup
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      observer.subjects.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const prevValue = s.value
    s.value = nextValue
    
    // Check if value actually changed using equalFn if provided
    const changed = s.equalFn ? !s.equalFn(prevValue, nextValue) : prevValue !== nextValue
    
    if (changed) {
      // Clone the observers set to avoid issues if observers modify the set during iteration
      const observersToNotify = [...s.observers]
      for (const observer of observersToNotify) {
        updateObserver(observer as Observer<unknown>)
      }
    }
    
    return s.value
  }

  return [read, write]
}
