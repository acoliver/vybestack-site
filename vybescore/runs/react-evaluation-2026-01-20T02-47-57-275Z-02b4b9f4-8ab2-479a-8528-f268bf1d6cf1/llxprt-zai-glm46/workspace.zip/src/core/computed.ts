/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Store observers that depend on this computed
  const dependentObservers: Set<ObserverR> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (val?: T) => {
      // Run the original update function
      const newValue = updateFn(val)
      o.value = newValue
      
      // Forward updates to all observers that depend on this computed
      for (const observer of dependentObservers) {
        updateObserver(observer as Observer<unknown>)
      }
      
      return newValue
    },
  }
  
  const getter: GetterFn<T> = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Another observer is accessing this computed
      // Register this observer to be notified when this computed updates
      dependentObservers.add(observer)
      
      // Track this dependency for cleanup
      if (!observer.subjects) {
        observer.subjects = new Set()
      }
      // We need a way to track this computed for cleanup
      // For now, we'll use a proxy object
      observer.subjects.add({
        observers: dependentObservers,
      } as unknown as { observers: Set<ObserverR> })
    }
    return o.value!
  }
  
  // Initial computation - this will register dependencies
  updateObserver(o)
  
  return getter
}
