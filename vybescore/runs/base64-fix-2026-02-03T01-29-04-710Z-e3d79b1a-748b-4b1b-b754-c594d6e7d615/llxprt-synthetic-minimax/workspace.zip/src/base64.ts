/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 with proper error handling.
 */
export function decode(input: string): string {
  // Validate input: must contain only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Validate padding: if present, must be at most 2 characters
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch && paddingMatch[0].length > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }

  // Handle unpadded Base64 by adding appropriate padding
  let paddedInput = input;
  const coreLength = input.replace(/=/g, '').length;
  
  if (coreLength === 0) {
    throw new Error('Invalid Base64 input: empty');
  }

  // Add padding if the input is unpadded but has valid length for Base64
  const remainder = coreLength % 4;
  if (remainder !== 0) {
    // Add the necessary padding characters
    const paddingNeeded = 4 - remainder;
    paddedInput = input + '='.repeat(paddingNeeded);
  }

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
