/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  observers?: Set<ObserverR> // Track observers for notification
  equalFn?: EqualFn<T> // Optional equality function for computed values
  isCallback?: boolean // Flag to distinguish callbacks from computed values
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers?: Set<ObserverR> // Track observers for notification
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<ObserverR> // Track observers for notification
}

export type Subject<T> = SubjectR & SubjectV<T> & {
  observers: Set<ObserverR> // Ensure observers is always present
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const oldValue = observer.value
    const newValue = observer.updateFn(oldValue)
    observer.value = newValue
    
    // For computed values, if the value changed and this observer has dependent observers, notify them
    const hasChanged = observer.equalFn ? 
      (oldValue !== undefined && newValue !== undefined && !observer.equalFn(oldValue, newValue)) : 
      oldValue !== newValue
      
    if (observer.observers && hasChanged && newValue !== undefined) {
      const currentObservers = Array.from(observer.observers)
      for (const dependentObserver of currentObservers) {
        if ('updateFn' in dependentObserver && dependentObserver.updateFn) {
          // For computed values, always notify dependent observers
          // For callbacks, check if they should run based on the dependency change
          if (!observer.isCallback || (dependentObserver as Observer<unknown>).isCallback) {
            updateObserver(dependentObserver as Observer<unknown>)
          }
        }
      }
    }
  } finally {
    activeObserver = previous
  }
}

export function addObserverToSubject<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
  // Track this subscription for potential cleanup
  trackSubscription(observer, subject)
}

export function removeObserverFromSubject<T>(subject: Subject<T>, observer: ObserverR): void {
  if (subject.observers?.has(observer)) {
    subject.observers.delete(observer)
  }
}

// Global registry to track which observers are subscribed to which subjects
const subscriptionRegistry = new WeakMap<ObserverR, Set<Subject<unknown>>>()

export function trackSubscription<T>(observer: ObserverR, subject: Subject<T>): void {
  if (!subscriptionRegistry.has(observer)) {
    subscriptionRegistry.set(observer, new Set())
  }
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  subscriptionRegistry.get(observer)!.add(subject as Subject<unknown>)
}

export function untrackAllSubscriptions(observer: ObserverR): void {
  const subjects = subscriptionRegistry.get(observer)
  if (subjects) {
    for (const subject of subjects) {
      if (subject.observers?.has(observer)) {
        subject.observers.delete(observer)
      }
    }
    subscriptionRegistry.delete(observer)
  }
}
