/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  addObserverToSubject,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : 
             equal === false ? () => false : 
             equal === true ? (a: T, b: T) => a === b : 
             undefined,
    observers: new Set(), // Initialize observers set
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      addObserverToSubject(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue: T) => {
    const hasChanged = s.equalFn ? !s.equalFn(s.value, nextValue) : s.value !== nextValue
    
    if (hasChanged) {
      s.value = nextValue
      
      // Create a copy of observers to avoid issues with observers being added/removed during iteration
      const currentObservers = Array.from(s.observers)
      for (const observer of currentObservers) {
        if (('updateFn' in observer) && observer.updateFn) {
          updateObserver(observer as Observer<unknown>)
        }
      }
    }
    return s.value
  }

  return [read, write]
}