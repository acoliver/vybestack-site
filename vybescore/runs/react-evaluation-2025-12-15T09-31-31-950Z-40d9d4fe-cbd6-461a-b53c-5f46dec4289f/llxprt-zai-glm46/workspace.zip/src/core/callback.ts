/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, untrackAllSubscriptions } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let skipFirstExecution = true
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      if (disposed) {
        return value as T // Return initial value if disposed
      }
      
      // Skip side effect execution during first run (dependency tracking)
      if (skipFirstExecution) {
        skipFirstExecution = false
        return currentValue ?? value as T
      }
      
      // Execute the side effect for reactive changes
      updateFn(currentValue)
      // Return the same value to prevent triggering updates
      return currentValue ?? value as T
    },
    observers: new Set(),
    isCallback: true
  }
  
  // Establish dependencies by setting this observer as active and running the user function
  // This will track which subjects the callback depends on
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    // This call establishes the reactive dependencies
    // Side effect execution is prevented by the skipFirstExecution flag
    updateFn(value)
  } finally {
    setActiveObserver(previousObserver)
  }
  
  // Reset flag so reactive changes will execute side effects
  skipFirstExecution = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it subscribed to
    untrackAllSubscriptions(observer)
  }
}