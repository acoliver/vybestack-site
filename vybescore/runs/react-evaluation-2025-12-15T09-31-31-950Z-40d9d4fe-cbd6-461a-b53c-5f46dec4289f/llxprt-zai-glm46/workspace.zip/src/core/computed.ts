/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  addObserverToSubject,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a synthetic subject to track observers for this computed value
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value!,
    equalFn: typeof equal === 'function' ? equal : 
             equal === false ? () => false : 
             equal === true ? (a: T, b: T) => a === b : 
             undefined,
    observers: new Set(),
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: subject.observers, // Share observers with the synthetic subject
    equalFn: subject.equalFn,
    isCallback: false,
  }
  
  // Only compute initial value if value is provided, otherwise wait for first access
  if (value !== undefined) {
    updateObserver(o)
  }
  
  return (): T => {
    // Register this computed value as a dependency when accessed
    const observer = getActiveObserver()
    if (observer) {
      addObserverToSubject(subject, observer)
    }
    
    // Re-evaluate the computed value each time it's accessed
    // to ensure dependencies are properly tracked
    updateObserver(o)
    return o.value!
  }
}