import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function EmptyInventoryState(): JSX.Element {
  return (
    <div>
      <h1>Inventory</h1>
      <p>No inventory items found.</p>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  // Handle loading state
  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  // Handle error state
  if (status === 'error') {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
        <button onClick={() => setCurrentPage(1)}>Try again</button>
      </section>
    );
  }

  // Handle empty state
  if (!data || data.total === 0) {
    return <EmptyInventoryState />;
  }

  // Handle case where current page has no items (could happen after deletion)
  if (data.items.length === 0 && currentPage > 1) {
    return <EmptyInventoryState />;
  }

  const hasPrevious = currentPage > 1;
  const hasNext = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      
      {/* Pagination controls */}
      <nav aria-label="Inventory pagination">
        <button
          onClick={() => setCurrentPage(currentPage - 1)}
          disabled={!hasPrevious}
          aria-label="Previous page"
        >
          Previous
        </button>
        <span aria-live="polite">
          Page {data.page} of {Math.ceil(data.total / data.limit)} ({data.total} items total)
        </span>
        <button
          onClick={() => setCurrentPage(currentPage + 1)}
          disabled={!hasNext}
          aria-label="Next page"
        >
          Next
        </button>
      </nav>

      {/* Display error in a non-blocking way if we have data */}
      {error && (
        <p role="alert" style={{ color: 'orange' }}>
          {error}
        </p>
      )}
    </section>
  );
}
