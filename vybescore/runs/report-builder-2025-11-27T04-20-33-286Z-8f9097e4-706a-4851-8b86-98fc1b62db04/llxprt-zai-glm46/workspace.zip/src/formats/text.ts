import type { ReportData, RenderOptions } from '../types.js';

export function renderText(data: ReportData, options?: RenderOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options || {};

  const lines: string[] = [];
  
  lines.push(title);
  lines.push('');
  lines.push(summary);
  lines.push('');
  lines.push('Entries:');
  
  for (const entry of entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }
  
  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}