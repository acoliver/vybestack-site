#!/usr/bin/env node

import fs from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliOptions {
  format: string;
  output?: string;
  includeTotals?: boolean;
}

function parseArguments(): { dataFile: string; options: CliOptions } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  const options: CliOptions = { format: '' };
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        options.format = args[++i];
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        options.output = args[++i];
        break;
      case '--includeTotals':
        options.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${args[i]}`);
        process.exit(1);
    }
  }
  
  if (!options.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return { dataFile, options };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: Expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: Missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: Missing or invalid "entries" field (expected array)');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: Entry at index ${index} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: Entry at index ${index} missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: Entry at index ${index} missing or invalid "amount" field (expected number)`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

function loadJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw new Error(`Error reading file ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
  }
}

function main(): void {
  try {
    const { dataFile, options } = parseArguments();
    
    const rawData = loadJsonFile(dataFile);
    const reportData = validateReportData(rawData);
    
    const renderOptions: RenderOptions = { includeTotals: options.includeTotals };
    
    let output: string;
    switch (options.format.toLowerCase()) {
      case 'markdown':
        output = renderMarkdown(reportData, renderOptions);
        break;
      case 'text':
        output = renderText(reportData, renderOptions);
        break;
      default:
        console.error(`Error: Unsupported format "${options.format}". Supported formats: markdown, text`);
        process.exit(1);
    }
    
    if (options.output) {
      fs.writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
