import { describe, it, expect } from 'vitest';
import { validateEmail, validatePhone, validatePostalCode, validateRequired, validateForm } from '../../src/validation.js';
import { FormData } from '../../src/types.js';

describe('Validation Module', () => {
  describe('validateEmail', () => {
    it('should validate correct email addresses', () => {
      expect(validateEmail('test@example.com')).toBe(true);
      expect(validateEmail('user.name@domain.co.uk')).toBe(true);
      expect(validateEmail('test+tag@example.org')).toBe(true);
    });

    it('should reject invalid email addresses', () => {
      expect(validateEmail('invalid-email')).toBe(false);
      expect(validateEmail('test@')).toBe(false);
      expect(validateEmail('@domain.com')).toBe(false);
      expect(validateEmail('test..double.dot@example.com')).toBe(false);
      expect(validateEmail('')).toBe(false);
    });

    it('should trim whitespace from email addresses', () => {
      expect(validateEmail('  test@example.com  ')).toBe(true);
    });
  });

  describe('validatePhone', () => {
    it('should validate correct phone numbers', () => {
      expect(validatePhone('+44 20 7946 0958')).toBe(true);
      expect(validatePhone('+54 9 11 1234-5678')).toBe(true);
      expect(validatePhone('(555) 123-4567')).toBe(true);
      expect(validatePhone('555-123-4567')).toBe(true);
      expect(validatePhone('555 123 4567')).toBe(true);
    });

    it('should reject invalid phone numbers', () => {
      expect(validatePhone('')).toBe(false);
      expect(validatePhone('abc')).toBe(false);
      expect(validatePhone('+')).toBe(false);
      expect(validatePhone('   ')).toBe(false);
    });

    it('should trim whitespace from phone numbers', () => {
      expect(validatePhone('  +44 20 7946 0958  ')).toBe(true);
    });
  });

  describe('validatePostalCode', () => {
    it('should validate correct postal codes', () => {
      expect(validatePostalCode('SW1A 1AA')).toBe(true);
      expect(validatePostalCode('12345')).toBe(true);
      expect(validatePostalCode('C1000')).toBe(true);
      expect(validatePostalCode('B1675')).toBe(true);
      expect(validatePostalCode('12345-6789')).toBe(true);
    });

    it('should reject invalid postal codes', () => {
      expect(validatePostalCode('')).toBe(false);
      expect(validatePostalCode('AB')).toBe(false); // Too short
      expect(validatePostalCode('A'.repeat(11))).toBe(false); // Too long
      expect(validatePostalCode('123!456')).toBe(false); // Invalid characters
    });

    it('should trim whitespace from postal codes', () => {
      expect(validatePostalCode('  SW1A 1AA  ')).toBe(true);
    });
  });

  describe('validateRequired', () => {
    it('should validate required fields', () => {
      expect(validateRequired('valid text')).toBe(true);
      expect(validateRequired('a')).toBe(true);
      expect(validateRequired('  trimmed  ')).toBe(true);
    });

    it('should reject empty or whitespace-only fields', () => {
      expect(validateRequired('')).toBe(false);
      expect(validateRequired('   ')).toBe(false);
      expect(validateRequired('\n\t')).toBe(false);
    });
  });

  describe('validateForm', () => {
    const validFormData: FormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvinceRegion: 'State',
      postalZipCode: '12345',
      country: 'USA',
      email: 'john.doe@example.com',
      phoneNumber: '+1 555-123-4567'
    };

    it('should validate a complete, valid form', () => {
      const result = validateForm(validFormData);
      expect(result.isValid).toBe(true);
      expect(Object.keys(result.errors)).toHaveLength(0);
    });

    it('should return errors for missing required fields', () => {
      const incompleteData: FormData = {
        ...validFormData,
        firstName: '',
        email: 'invalid-email'
      };

      const result = validateForm(incompleteData);
      expect(result.isValid).toBe(false);
      expect(result.errors.firstName).toBe('First name is required');
      expect(result.errors.email).toBe('Please enter a valid email address');
    });

    it('should validate international phone numbers', () => {
      const formWithInternationalPhone: FormData = {
        ...validFormData,
        phoneNumber: '+44 20 7946 0958'
      };

      const result = validateForm(formWithInternationalPhone);
      expect(result.isValid).toBe(true);
    });

    it('should validate international postal codes', () => {
      const formWithUKPostcode: FormData = {
        ...validFormData,
        postalZipCode: 'SW1A 1AA'
      };

      const result = validateForm(formWithUKPostcode);
      expect(result.isValid).toBe(true);

      const formWithArgentinaPostcode: FormData = {
        ...validFormData,
        postalZipCode: 'C1000'
      };

      const result2 = validateForm(formWithArgentinaPostcode);
      expect(result2.isValid).toBe(true);
    });

    it('should handle whitespace in fields', () => {
      const formWithWhitespace: FormData = {
        ...validFormData,
        firstName: '  John  ',
        lastName: '  ',
        email: '  john@example.com  '
      };

      const result = validateForm(formWithWhitespace);
      expect(result.isValid).toBe(false); // lastName is just whitespace
      expect(result.errors.lastName).toBe('Last name is required');
    });
  });
});