import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import express from 'express';
import request from 'supertest';
import { join } from 'path';
import fs from 'fs';
import DatabaseManager from '../../src/database.js';

describe('Server Integration Tests', () => {
  let app: express.Application;
  let dbManager: DatabaseManager;
  const testDbPath = join(process.cwd(), 'data', 'test-submissions.sqlite');
  const testSchemaPath = join(process.cwd(), 'db', 'schema.sql');

  beforeEach(async () => {
    // Clean up any existing test database
    if (fs.existsSync(testDbPath)) {
      fs.unlinkSync(testDbPath);
    }

    // Initialize test database
    dbManager = new DatabaseManager(testDbPath, testSchemaPath);
    await dbManager.initialize();

    // Create express app with test configuration
    const app = express();
    
    // Middleware
    app.use(express.urlencoded({ extended: true }));
    app.use(express.json());
    app.use(express.static(join(process.cwd(), 'public')));

    // Set EJS as view engine
    app.set('view engine', 'ejs');
    app.set('views', join(process.cwd(), 'views'));

    // Mock routes for testing
    app.get('/', (req: express.Request, res: express.Response) => {
      res.render('index', {
        formData: {},
        errors: {}
      });
    });

    app.post('/submit', async (req: express.Request, res: express.Response) => {
      try {
        const formData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvinceRegion: req.body.stateProvinceRegion || '',
          postalZipCode: req.body.postalZipCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phoneNumber: req.body.phoneNumber || ''
        };

        const { validateForm } = await import('../../src/validation.js');
        const validationResult = validateForm(formData);

        if (!validationResult.isValid) {
          return res.status(400).render('index', {
            formData,
            errors: validationResult.errors
          });
        }

        await dbManager.insertSubmission(formData);
        res.redirect(302, '/thank-you');
      } catch (error) {
        res.status(500).render('index', {
          formData: req.body,
          errors: { general: 'An error occurred while processing your submission. Please try again.' }
        });
      }
    });

    app.get('/thank-you', (req: express.Request, res: express.Response) => {
      res.render('thank-you');
    });
  });

  afterEach(async () => {
    await dbManager.close();
    
    // Clean up test database
    if (fs.existsSync(testDbPath)) {
      fs.unlinkSync(testDbPath);
    }
  });

  describe('GET /', () => {
    it('should return 200 status', async () => {
      const response = await request(app).get('/');
      expect(response.status).toBe(200);
    });

    it('should render the form template', async () => {
      const response = await request(app).get('/');
      expect(response.text).toContain('International Contact Form');
      expect(response.text).toContain('First Name');
      expect(response.text).toContain('Submit Information');
    });
  });

  describe('POST /submit', () => {
    const validFormData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvinceRegion: 'State',
      postalZipCode: '12345',
      country: 'USA',
      email: 'john.doe@example.com',
      phoneNumber: '+1 555-123-4567'
    };

    it('should redirect to thank-you page on valid submission', async () => {
      const response = await request(app)
        .post('/submit')
        .send(validFormData);
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should return 400 status on invalid form data', async () => {
      const invalidData = {
        ...validFormData,
        email: 'invalid-email',
        firstName: ''
      };

      const response = await request(app)
        .post('/submit')
        .send(invalidData);
      
      expect(response.status).toBe(400);
      expect(response.text).toContain('Please enter a valid email address');
      expect(response.text).toContain('First name is required');
    });

    it('should preserve form data on validation errors', async () => {
      const invalidData = {
        ...validFormData,
        firstName: '',
        email: 'test@example.com'
      };

      const response = await request(app)
        .post('/submit')
        .send(invalidData);
      
      expect(response.text).toContain('value=""');
      expect(response.text).toContain('value="test@example.com"');
    });

    it('should handle international phone numbers', async () => {
      const formWithInternationalPhone = {
        ...validFormData,
        phoneNumber: '+44 20 7946 0958'
      };

      const response = await request(app)
        .post('/submit')
        .send(formWithInternationalPhone);
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should handle international postal codes', async () => {
      const formWithUKPostcode = {
        ...validFormData,
        postalZipCode: 'SW1A 1AA'
      };

      const response = await request(app)
        .post('/submit')
        .send(formWithUKPostcode);
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });
  });

  describe('GET /thank-you', () => {
    it('should return 200 status', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.status).toBe(200);
    });

    it('should render the thank-you template', async () => {
      const response = await request(app).get('/thank-you');
      expect(response.text).toContain('Thank You So Much!');
      expect(response.text).toContain('personal information');
      expect(response.text).toContain('Fill Out Another Form');
    });
  });

  describe('Database Integration', () => {
    it('should save form submission to database', async () => {
      const formData = {
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Another City',
        stateProvinceRegion: 'Province',
        postalZipCode: 'M5V 3L9',
        country: 'Canada',
        email: 'jane.smith@example.com',
        phoneNumber: '+1 416-555-7890'
      };

      await request(app).post('/submit').send(formData);

      // Verify the data was saved
      const submissions = await dbManager.getAllSubmissions();
      expect(submissions).toHaveLength(1);
      
      const savedSubmission = submissions[0];
      expect(savedSubmission.first_name).toBe('Jane');
      expect(savedSubmission.last_name).toBe('Smith');
      expect(savedSubmission.email).toBe('jane.smith@example.com');
      expect(savedSubmission.country).toBe('Canada');
    });
  });
});