import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface Submission {
  id: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_zip_code: string;
  country: string;
  email: string;
  phone_number: string;
  created_at: string;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: unknown = null;

  async initialize(): Promise<void> {
    try {
      const SQL = await (initSqlJs as unknown as (options: { locateFile: (file: string) => string }) => Promise<{
        Database: new (buffer?: Uint8Array) => Database;
      }>)({
        locateFile: (file: string) => {
          return require.resolve(`sql.js/dist/${file}`);
        }
      });
      this.sqlJs = SQL;

      const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
      const dbDir = path.dirname(dbPath);
      
      // Ensure data directory exists
      if (!fs.existsSync(dbDir)) {
        fs.mkdirSync(dbDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(dbPath)) {
        const dbBuffer = fs.readFileSync(dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
        await this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf-8');
      this.db.exec(schema);
    } else {
      // Fallback schema if file doesn't exist
      this.db.exec(`
        CREATE TABLE IF NOT EXISTS submissions (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          first_name TEXT NOT NULL,
          last_name TEXT NOT NULL,
          street_address TEXT NOT NULL,
          city TEXT NOT NULL,
          state_province_region TEXT NOT NULL,
          postal_zip_code TEXT NOT NULL,
          country TEXT NOT NULL,
          email TEXT NOT NULL,
          phone_number TEXT NOT NULL,
          created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
      `);
    }
  }

  async insertSubmission(data: FormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvinceRegion,
      data.postalZipCode,
      data.country,
      data.email,
      data.phoneNumber
    ]);

    stmt.free();

    // Get the last insert ID
    const result = this.db.exec("SELECT last_insert_rowid() as id;");
    return result[0].values[0][0] as number;
  }

  async getSubmissions(): Promise<Submission[]> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const result = this.db.exec("SELECT * FROM submissions ORDER BY created_at DESC;");
    
    if (result.length === 0) {
      return [];
    }

    const columns = result[0].columns;
    const values = result[0].values;

    return values.map(row => {
      const submission: Submission = {} as Submission;
      columns.forEach((col, index) => {
        const key = col as keyof Submission;
        (submission as unknown as Record<string, unknown>)[key] = row[index];
      });
      return submission;
    });
  }

  async saveToFile(): Promise<void> {
    if (!this.db || !this.sqlJs) {
      throw new Error('Database not initialized');
    }

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const dbBuffer = this.db.export();
    fs.writeFileSync(dbPath, dbBuffer);
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();