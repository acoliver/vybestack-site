import { FormData } from './database';

export interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvinceRegion?: string;
  postalZipCode?: string;
  country?: string;
  email?: string;
  phoneNumber?: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationErrors;
}

export class Validator {
  static validateForm(data: FormData): ValidationResult {
    const errors: ValidationErrors = {};

    // Required field validation
    if (!data.firstName.trim()) {
      errors.firstName = 'First name is required';
    }

    if (!data.lastName.trim()) {
      errors.lastName = 'Last name is required';
    }

    if (!data.streetAddress.trim()) {
      errors.streetAddress = 'Street address is required';
    }

    if (!data.city.trim()) {
      errors.city = 'City is required';
    }

    if (!data.stateProvinceRegion.trim()) {
      errors.stateProvinceRegion = 'State/Province/Region is required';
    }

    if (!data.postalZipCode.trim()) {
      errors.postalZipCode = 'Postal/Zip code is required';
    }

    if (!data.country.trim()) {
      errors.country = 'Country is required';
    }

    if (!data.email.trim()) {
      errors.email = 'Email is required';
    } else if (!this.isValidEmail(data.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!data.phoneNumber.trim()) {
      errors.phoneNumber = 'Phone number is required';
    } else if (!this.isValidPhone(data.phoneNumber)) {
      errors.phoneNumber = 'Please enter a valid phone number';
    }

    // Postal code validation (allow alphanumeric)
    if (data.postalZipCode.trim() && !this.isValidPostalCode(data.postalZipCode)) {
      errors.postalZipCode = 'Please enter a valid postal/zip code';
    }

    return {
      isValid: Object.keys(errors).length === 0,
      errors
    };
  }

  private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private static isValidPhone(phone: string): boolean {
    // Allow digits, spaces, parentheses, dashes, and leading +
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
  }

private static isValidPostalCode(postalCode: string): boolean {
    // Allow alphanumeric strings, spaces, and hyphens
    // Should handle formats like "SW1A 1AA", "C1000", "B1675"
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.replace(/\s/g, '').length >= 3;
  }

  static sanitizeInput(input: string): string {
    return input.trim().replace(/[<>]/g, '');
  }
}