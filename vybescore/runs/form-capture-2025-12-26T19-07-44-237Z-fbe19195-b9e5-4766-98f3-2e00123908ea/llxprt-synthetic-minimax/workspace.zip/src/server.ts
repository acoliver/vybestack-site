import express from 'express';
import * as path from 'path';
import { dbManager, FormData } from './database';
import { Validator } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// View engine setup
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));

// Route handlers
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('index', {
    errors: {},
    formData: {},
    title: 'Contact Us'
  });
});

app.post('/submit', async (req: express.Request, res: express.Response) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalZipCode: req.body.postalZipCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phoneNumber || ''
    };

    const validation = Validator.validateForm(formData);

    if (!validation.isValid) {
      return res.status(400).render('index', {
        errors: validation.errors,
        formData,
        title: 'Contact Us - Please Fix Errors'
      });
    }

    // Insert into database
    await dbManager.insertSubmission(formData);
    await dbManager.saveToFile();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('index', {
      errors: { general: 'An error occurred while processing your request. Please try again.' },
      formData: req.body,
      title: 'Contact Us - Error'
    });
  }
});

app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  dbManager.close();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully');
  dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;
