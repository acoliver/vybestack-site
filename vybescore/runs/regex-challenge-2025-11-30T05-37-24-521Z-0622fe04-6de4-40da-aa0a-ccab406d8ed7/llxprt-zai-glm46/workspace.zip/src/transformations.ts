/**
 * Capitalize the first character of each sentence.
 * After .?!, insert exactly one space between sentences even if the input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Common English abbreviations to avoid splitting on
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Mt', 'vs', 'etc', 'e.g', 'i.e', 'U.S', 'U.K'];
  
  // First, replace multiple spaces with a single space, but preserve newlines
  const processed = text.replace(/[ \t]+/g, ' ');
  
  // Split into sentences using sentence-ending punctuation, handling abbreviations
  const sentences: string[] = [];
  let currentSentence = '';
  let i = 0;
  
  while (i < processed.length) {
    const char = processed[i];
    currentSentence += char;
    
    // Check if we have a sentence-ending punctuation
    if (char === '.' || char === '?' || char === '!') {
      // Look ahead to see if this might be an abbreviation
      const beforePunct = currentSentence.slice(0, -1).trim();
      const words = beforePunct.split(/\s+/);
      const lastWord = words[words.length - 1] || '';
      
      // Check if the last word matches any abbreviation
      const isAbbreviation = abbreviations.some(abbr => 
        lastWord.toLowerCase() === abbr.toLowerCase()
      );
      
      // If it's not an abbreviation, this is likely the end of a sentence
      if (!isAbbreviation || i === processed.length - 1 || /\s/.test(processed[i + 1] || '')) {
        sentences.push(currentSentence.trim());
        currentSentence = '';
        
        // Skip any extra spaces after punctuation
        while (i + 1 < processed.length && /\s/.test(processed[i + 1])) {
          i++;
        }
      }
    }
    
    i++;
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence.trim());
  }
  
  // Capitalize first letter of each sentence and join with single spaces
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return '';
    return sentence[0].toUpperCase() + sentence.slice(1);
  });
  
  return capitalizedSentences.join(' ');
}

/**
 * Extract all URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches http/https protocols, domains, and paths
  // Negative lookbehind to ensure we don't capture trailing punctuation
  const urlRegex = /https?:\/\/(?:www\.)?[^\s/$.?#].[^\s]*?(?=[.,;:!?)]?(?:\s|$))/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation if present
  return matches.map(url => url.replace(/[.,;:!?)]+$/, ''));
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch https://
  // Use negative lookbehind to avoid matching https://
  return text.replace(/(?<!https:)http:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs according to specific rules.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when the path contains dynamic hints like cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs that need rewriting
  const urlPattern = /(https?:\/\/)([^/]+)(\/[^\s]*)/g;
  
return text.replace(urlPattern, (match: string, protocol: string, host: string, path: string) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if path starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check if we should skip host rewrite (dynamic hints or legacy extensions)
      const skipPatterns = [
        /\/cgi-bin\//,
        /[?&]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/
      ];
      
      const shouldSkipHost = skipPatterns.some(pattern => pattern.test(path));
      
      if (!shouldSkipHost) {
        // Rewrite host to docs.example.com by prepending 'docs.' to the existing host
        const newHost = `docs.${host}`;
        return newProtocol + newHost + path;
      }
    }
    
    // Just upgrade the protocol
    return newProtocol + host + path;
  });
}

/**
 * Extract the four-digit year from mm/dd/yyyy format.
 * If the string doesn't match that format or month/day are invalid, return 'N/A'.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // More specific day validation based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year (February)
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  
  if (month === 2 && isLeapYear) {
    if (day > 29) return 'N/A';
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}