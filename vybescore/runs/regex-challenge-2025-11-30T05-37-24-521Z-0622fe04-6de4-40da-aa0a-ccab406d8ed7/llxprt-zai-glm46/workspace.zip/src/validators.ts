export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with common rules.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that accepts typical addresses but rejects problematic patterns
  // Local part: letters, digits, plus, hyphens, apostrophes (no consecutive dots, no leading/trailing dots)
  // Domain: letters, digits, hyphens (no underscores, no consecutive dots, no leading/trailing dots)
  // TLD: 2-63 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject patterns that should be invalid
  const invalidPatterns = [
    /\.\./,           // consecutive dots anywhere
    /^\./,            // leading dot in local part
    /\.$/,            // trailing dot in local part
    /@.*\.\./,        // consecutive dots in domain
    /@.*\.$/,         // trailing dot in domain
    /_.*@/,           // underscore in local part
    /@.*_/            // underscore in domain
  ];
  
  // Check if any invalid pattern exists
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return emailRegex.test(value) && value.length > 0 && value.length <= 254;
}

/**
 * Validate US phone numbers with optional +1 prefix.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally 11 with country code)
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // Handle country code
  let phoneNumber = digits;
  if (digits.length === 11) {
    // Must start with 1 for US country code
    if (!digits.startsWith('1')) {
      return false;
    }
    phoneNumber = digits.slice(1); // Remove country code
  }
  
  // Check area code (cannot start with 0 or 1)
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the complete number format
  const phoneRegex = /^(?:\+1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - When country code omitted, must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Main regex pattern for Argentine phone numbers
  const argentinePhoneRegex = /^(\+54)?(9)?(0?)([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, , trunkPrefix, areaCode, subscriberNumber] = match;
  
  // If no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate names with unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and strange names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, special symbols (except allowed punctuation), and emoji-like combinations
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF\u0400-\u04FF\u0370-\u03FF\u0590-\u05FF\u0600-\u06FF\u0750-\u077F\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF\u0400-\u04FF'’\-\s]+$/;
  
  // Additional checks for invalid patterns
  const invalidPatterns = [
    /\d/,                    // digits
    /[^\w\s'’\-\u00C0-\u024F\u1E00-\u1EFF\u0400-\u04FF\u0370-\u03FF\u0590-\u05FF\u0600-\u06FF\u0750-\u077F\u4E00-\u9FFF\u3040-\u309F\u30A0-\u30FF]/, // special symbols
    /\s{2,}/,               // multiple consecutive spaces
    /^[\s'-]+|[\s'-]+$/, // starts or ends with only punctuation/spaces
  ];
  
  // Check if any invalid pattern exists
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  // Name should not be empty or just whitespace
  if (!value.trim()) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Luhn checksum validation helper function.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx.
 * Accepts correct prefixes and lengths, runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits and reasonable length
  if (!/^\d+$/.test(cleanNumber) || cleanNumber.length < 13 || cleanNumber.length > 19) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9][1-9]|3[0-9]{2}|4[0-9]{2}|5[0-9]{2}|6[0-9]{2}|7[01]\d|720)\d{12}))$/;
  
  // American Express: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the accepted card types
  const isValidFormat = visaRegex.test(cleanNumber) || 
                       mastercardRegex.test(cleanNumber) || 
                       amexRegex.test(cleanNumber);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanNumber);
}