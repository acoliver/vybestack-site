import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function validatePaginationParams(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } | { error: string } {
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : 5;

  // Check for non-numeric values (NaN)
  if (pageParam !== undefined && isNaN(page)) {
    return { error: 'Invalid page parameter: must be a number' };
  }
  if (limitParam !== undefined && isNaN(limit)) {
    return { error: 'Invalid limit parameter: must be a number' };
  }

  // Check for negative or zero values
  if (page < 1) {
    return { error: 'Invalid page parameter: must be greater than 0' };
  }
  if (limit < 1) {
    return { error: 'Invalid limit parameter: must be greater than 0' };
  }

  // Check for excessive values
  if (limit > MAX_LIMIT) {
    return { error: `Invalid limit parameter: must not exceed ${MAX_LIMIT}` };
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePaginationParams(pageParam, limitParam);

    if ('error' in validation) {
      res.status(400).json({ error: validation.error });
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
