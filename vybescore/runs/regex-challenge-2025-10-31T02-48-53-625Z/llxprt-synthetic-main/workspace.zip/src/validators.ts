export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for common patterns.
 * Accepts formats like name+tag@example.co.uk, rejects double dots,
 * trailing dots, domains with underscores, and other invalid formats.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part: letters, digits, and allowed special chars
  // Domain part: letters, digits, hyphens, dots in proper format
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick reject for obvious invalid patterns
  if (!value || value.includes('..') || value.startsWith('.') || value.endsWith('.') || value.includes('@.') || value.endsWith('.@')) {
    return false;
  }
  
  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Apply the regex
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers in common formats:
 * (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  const hasCountryCode = value.startsWith('+1');
  const phoneDigits = hasCountryCode ? digitsOnly.substring(1) : digitsOnly;
  
  // Must have exactly 10 digits after removing country code
  if (phoneDigits.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format using regex to ensure proper separators
  const phoneRegex = /^(\+1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[-.]?)?\d{3}[-.]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const clean = value.replace(/[\s-]/g, '');
  
  // Base pattern for validation
  // +54 [9] [area code] [number]
  // 0[area code] [number]
  const arPhoneRegex = /^(\+54)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = clean.match(arPhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, , areaCode, subscriberNumber] = match;
  
  // Check total digit count is between 10 and 14
  if (clean.length < 10 || clean.length > 14) {
    return false;
  }
  
  // If country code is omitted, must begin with trunk prefix 0
  if (!countryCode && !clean.startsWith('0')) {
    return false;
  }
  
  // Area code must be 2-4 digits, starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and Elon Musk-style names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Name validation regex allowing unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'’-]+(?:[\s][\p{L}\p{M}'’-]+)*$/u;
  
  // Check if name contains only allowed characters
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with too many special characters that suggest it's not a real name
  const specialCharCount = (value.match(/[’'-]/g) || []).length;
  const totalLength = value.replace(/\s/g, '').length;
  
  // If more than 30% of the characters (excluding spaces) are special characters, reject
  if (totalLength > 0 && specialCharCount / totalLength > 0.3) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx).
 * Checks proper prefixes and length, plus Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard (16 digits, starts with 51-55 or 2221-2720)
  const mcRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // Check AmEx (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Validate format
  if (!visaRegex.test(cleanValue) && !mcRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Luhn algorithm
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let doubleDigit = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}
