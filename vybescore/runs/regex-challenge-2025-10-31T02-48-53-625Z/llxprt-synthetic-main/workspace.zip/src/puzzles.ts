/**
 * Finds words starting with the given prefix but excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to match words starting with the prefix
  const wordBoundary = '\\b';
  const prefixPattern = `${wordBoundary}${escapedPrefix}[a-zA-Z]*${wordBoundary}`;
  
  const regex = new RegExp(prefixPattern, 'g');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions and remove duplicates
  const result = [];
  const seen = new Set();
  
  for (const word of matches) {
    // Convert to lowercase for comparison with exceptions (case-insensitive)
    const wordLower = word.toLowerCase();
    
    // Skip if it's an exception or already seen
    if (seen.has(wordLower)) continue;
    
    let isException = false;
    for (const exception of exceptions) {
      if (wordLower === exception.toLowerCase()) {
        isException = true;
        break;
      }
    }
    
    if (!isException) {
      result.push(word);
      seen.add(wordLower);
    }
  }
  
  return result;
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all matches with context to capture the digit
  const contextRegex = new RegExp(`(\\d)${escapedToken}`, 'g');
  const matches = [...text.matchAll(contextRegex)];
  
  // Return the full matched patterns (digit + token)
  return matches.map(match => match[0]);
}

/**
 * Validates password strength according to the requirements:
 * - At least 10 characters
 * - One uppercase
 * - One lowercase
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex captures any 2-3 character pattern that repeats immediately
  if (/([a-zA-Z0-9\W]{2,3})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv4 address pattern to exclude (to avoid false positives)
  const ipv4Pattern = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  
  // IPv6 address patterns
  // Full IPv6 with all 8 groups
  const fullIpv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with :: (shorthand)
  // This captures addresses with ::
  const shorthandPattern = /(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with 0 to 6 groups, ending with IPv4
  const ipv6WithIpv4Pattern = /(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/;
  
  // Check if text matches IPv4 pattern, which we want to exclude
  if (ipv4Pattern.test(value)) {
    // If it's just a pure IPv4 address and not part of a larger IPv6 with embedded IPv4
    if (!ipv6WithIpv4Pattern.test(value)) {
      return false;
    }
  }
  
  // Check for any valid IPv6 pattern
  return fullIpv6Pattern.test(value) || 
         shorthandPattern.test(value) || 
         ipv6WithIpv4Pattern.test(value);
}