/**
 * Capitalizes the first character of each sentence.
 * Insert exactly one space between sentences and collapse extra spaces.
 * Tries to preserve common abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Normalize multiple spaces to single spaces but keep sentence ending
  const normalized = text.replace(/\s+/g, ' ');
  
  // Split on sentence boundaries and capitalize
  return normalized.replace(/(^[a-z])|([.?!]\s*([a-z]))/g, (match, firstLetter, punctuation, nextLetter) => {
    if (firstLetter) {
      return firstLetter.toUpperCase();
    } else {
      return punctuation.replace(nextLetter, nextLetter.toUpperCase());
    }
  });
}

/**
 * Finds URLs in the text and returns them as an array.
 * Removes trailing punctuation from extracted URLs.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern, captures HTTP/HTTPS/FTP
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/\/=]*)/g;
  
  if (!text) return [];
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean trailing punctuation
  return matches.map(url => {
    // Remove common trailing punctuation
    return url.replace(/[.,;:!?)\]\}]+$/g, '');
  });
}

/**
 * Replaces all http:// URLs with https:// while leaving existing https URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace all http:// URLs with https:// using regex
  // Use negative lookbehind to avoid replacing already secure URLs
  const httpsRegex = /\bhttps?:\/\//gi;
  
  return text.replace(httpsRegex, () => {
    // Return https:// for both http:// and https:// to ensure security
    return 'https://';
  });
}

/**
 * Rewrites http://example.com/... URLs to https://.
 * When path starts with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http://example.com URLs with their paths
  const urlRegex = /(http:\/\/example\.com)(\/[^?\s]*)/gi;
  
  return text.replace(urlRegex, (match, _protocolHost, path) => {
    // Always upgrade to https
    
    // Skip host rewrite if path contains dynamic hints or legacy extensions
    const dynamicHints = '/cgi-bin';
    const queryString = /[?&=]/;
    const legacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)/;
    
    if (path.includes(dynamicHints) || queryString.test(path) || legacyExtensions.test(path)) {
      // Just upgrade the scheme, keep original host
      return 'https://example.com' + path;
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite host to docs.example.com
      return 'https://docs.example.com' + path;
    }
    
    // Default: just upgrade the scheme
    return 'https://example.com' + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Validate actual date (e.g., no February 30th)
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  const maxDays = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (dayNum > maxDays[monthNum - 1]) {
    return 'N/A';
  }
  
  // Leap year check for February
  if (monthNum === 2 && dayNum === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return year;
}
