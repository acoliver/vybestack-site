import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
      </section>
    );
  }

  const handlePrevious = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = () => {
    if (data.hasNext) {
      setCurrentPage(currentPage + 1);
    }
  };

  const hasNoData = data.items.length === 0;

  return (
    <section>
      <h1>Inventory</h1>
      
      {hasNoData ? (
        <p>No inventory items found.</p>
      ) : (
        <>
          <InventoryList items={data.items} />
          
          <div style={{ marginTop: '1rem', display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
            <button
              onClick={handlePrevious}
              disabled={currentPage <= 1}
              aria-label="Previous page"
              style={{
                padding: '0.5rem 1rem',
                cursor: currentPage <= 1 ? 'not-allowed' : 'pointer',
                opacity: currentPage <= 1 ? 0.5 : 1
              }}
            >
              Previous
            </button>
            
            <span style={{ margin: '0 1rem' }}>
              Page {data.page} of {Math.ceil(data.total / data.limit)}
            </span>
            
            <button
              onClick={handleNext}
              disabled={!data.hasNext}
              aria-label="Next page"
              style={{
                padding: '0.5rem 1rem',
                cursor: !data.hasNext ? 'not-allowed' : 'pointer',
                opacity: !data.hasNext ? 0.5 : 1
              }}
            >
              Next
            </button>
          </div>
          
          <div style={{ marginTop: '0.5rem', fontSize: '0.875rem', color: '#666' }}>
            Showing {data.items.length} of {data.total} items
          </div>
        </>
      )}
    </section>
  );
}
