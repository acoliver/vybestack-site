import express, { type Express, Request, Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

interface ValidationError {
  message: string;
  value?: string;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validation function
    const validateQueryParams = (): { page?: number; limit?: number } | { error: ValidationError } => {
      const errors: ValidationError[] = [];
      
      // Validate page parameter
      if (pageParam !== undefined) {
        if (isNaN(Number(pageParam))) {
          errors.push({ message: 'page must be a number', value: pageParam });
        } else {
          const pageNum = Number(pageParam);
          if (pageNum <= 0) {
            errors.push({ message: 'page must be greater than 0', value: pageParam });
          } else if (pageNum > 1000) {
            errors.push({ message: 'page must be less than or equal to 1000', value: pageParam });
          }
        }
      }
      
      // Validate limit parameter
      if (limitParam !== undefined) {
        if (isNaN(Number(limitParam))) {
          errors.push({ message: 'limit must be a number', value: limitParam });
        } else {
          const limitNum = Number(limitParam);
          if (limitNum <= 0) {
            errors.push({ message: 'limit must be greater than 0', value: limitParam });
          } else if (limitNum > 100) {
            errors.push({ message: 'limit must be less than or equal to 100', value: limitParam });
          }
        }
      }
      
      if (errors.length > 0) {
        return { error: errors[0] };
      }
      
      const page = pageParam ? Number(pageParam) : undefined;
      const limit = limitParam ? Number(limitParam) : undefined;
      
      return { page, limit };
    };

    const validation = validateQueryParams();
    
    if ('error' in validation) {
      return res.status(400).json({
        error: validation.error.message,
        ...(validation.error.value && { value: validation.error.value })
      });
    }

    try {
      const payload = listInventory(db, { page: validation.page, limit: validation.limit });
      res.json(payload);
    } catch (error) {
      console.error('Error fetching inventory:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
