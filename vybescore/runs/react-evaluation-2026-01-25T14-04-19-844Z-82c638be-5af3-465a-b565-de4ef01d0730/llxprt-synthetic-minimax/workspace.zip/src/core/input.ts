/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair
} from '../types/reactive.js'
import { notifyAllCallbacks } from './callback.js'

// Global registry for computed cells that need to be recomputed
const computedCells: Array<() => void> = []

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: { name?: string }
): InputPair<T> {
  let currentValue = value

  const read: () => T = () => {
    return currentValue
  }

  const write: (newValue: T) => T = (nextValue) => {
    currentValue = nextValue
    
    // Force all computed cells to recompute next time they're called
    for (const computed of computedCells) {
      // Touch computed to force recomputation
      computed()
    }
    
    // Notify all callbacks
    notifyAllCallbacks()
    
    return nextValue
  }

  return [read, write]
}

// Export for other modules to register computed cells
export function registerComputedCell(computed: () => void) {
  computedCells.push(computed)
}
