/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn
} from '../types/reactive.js'

// Global registry for computed cells and callbacks
const computedCells: Array<() => void> = []

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  _options?: { name?: string }
): GetterFn<T> {
  let currentValue = value
  
  const getter: GetterFn<T> = () => {
    // Always recompute the value when getter is called
    const newValue = updateFn(currentValue)
    currentValue = newValue
    return currentValue!
  }
  
  // Register this computed cell for notifications
  computedCells.push(getter)
  
  return getter
}

// Export functions for other modules
export function getAllComputedCells() {
  return computedCells.slice()
}

export function markAllComputedDirty() {
  // Force all computed getters to recompute next time they're called
  // Since we're using simple closure approach, this is automatic
}
