/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn
} from '../types/reactive.js'

// Global registry for callbacks
const globalCallbacks: Array<() => void> = []

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: (value?: T) => T, _value?: T): UnsubscribeFn {
  // Execute the callback immediately to establish baseline
  try {
    updateFn(_value)
  } catch (error) {
    // Ignore execution errors
  }
  
  // Register this callback globally
  const registeredCallback = () => {
    try {
      updateFn(_value)
    } catch (error) {
      // Ignore callback execution errors
    }
  }
  
  globalCallbacks.push(registeredCallback)
  
  // Return unsubscribe function
  return () => {
    // Remove this callback from the global registry
    const index = globalCallbacks.indexOf(registeredCallback)
    if (index > -1) {
      globalCallbacks.splice(index, 1)
    }
  }
}

// Export function for input system to notify all callbacks
export function notifyAllCallbacks() {
  // Create a copy of callbacks to avoid issues if callbacks modify the array
  const callbacksToNotify = globalCallbacks.slice()
  for (const callback of callbacksToNotify) {
    try {
      callback()
    } catch (error) {
      // Ignore callback errors
    }
  }
}

// Export for other modules to access callback registry
export function getRegisteredCallbacks() {
  return globalCallbacks.slice()
}
