/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Simple reactive implementation
export interface ReactiveCell<T> {
  value: T
  getter: GetterFn<T>
  setter?: SetterFn<T>
}

// Global tracking for dependency system
let activeGetter: GetterFn<unknown> | undefined = undefined
let activeComputed: ComputedNode<unknown> | undefined = undefined

export function getActiveGetter(): GetterFn<unknown> | undefined {
  return activeGetter
}

export function setActiveGetter(getter: GetterFn<unknown> | undefined) {
  activeGetter = getter
}

export function getActiveComputed(): ComputedNode<unknown> | undefined {
  return activeComputed
}

export function setActiveComputed(computed: ComputedNode<unknown> | undefined) {
  activeComputed = computed
}

// Base dependency tracking
export interface DependencyNode<T> {
  value: T
  updateFn: UpdateFn<T>
  // Callbacks to notify when this node changes
  callbacks: Set<() => void>
  // Computed dependents that track this node
  dependents: Set<DependencyNode<unknown>>
  getValue(): T
  setValue(newValue: T): void
  recompute(): T
  addCallback(callback: () => void): void
  removeCallback(callback: () => void): void
  notifyCallbacks(): void
  addDependent(computed: DependencyNode<unknown>): void
  removeDependent(computed: DependencyNode<unknown>): void
  notifyDependents(): void
}

// Input node that can notify dependents
export interface InputNode<T> extends DependencyNode<T> {
  dirty: boolean
  setValue(newValue: T): void
  markDirty(): void
}

// Computed node that tracks dependencies
export interface ComputedNode<T> extends DependencyNode<T> {
  dependencies: Set<InputNode<unknown>>
  dirty: boolean
  recompute(): T
  addDependency(input: InputNode<unknown>): void
  removeDependency(input: InputNode<unknown>): void
  markDirty(): void
}

// Simple global registry
export const reactiveRegistry = {
  inputs: new Map<InputNode<unknown>, unknown>(),
  computeds: new Map<ComputedNode<unknown>, unknown>(),
  callbacks: new Map<DependencyNode<unknown>, UnsubscribeFn>()
}
