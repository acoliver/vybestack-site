/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First normalize spacing around sentence delimiters
  let result = text;
  
  // Collapse multiple spaces to a single space
  result = result.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence terminators (., ?, !)
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Trim any leading/trailing whitespace
  result = result.trim();
  
  // Capitalize the first character of each sentence
  // This regex finds the first letter after either start of text or a sentence terminator
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex that matches http/https URLs with domain and optional path/query
  // This will match the full URL including domain and TLD
  const urlRegex = /(https?:\/\/[^\s<>"']+?(?:\.[a-zA-Z]{2,})+\/?[^\s<>"']*)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up any trailing punctuation that might have been included
  return matches.map(url => url.replace(/[.,!?;:\)]+$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https:// while leaving https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First replace all http with https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then process URLs that have /docs/ in their path
  // Only rewrite the host if the path doesn't contain dynamic elements
  result = result.replace(/https:\/\/example\.com(\/docs\/[^?\s&]*)(?!(.*(?:(?:cgi-bin|\.(?:jsp|php|asp|aspx|do|cgi|pl|py))|\?.*$)))/gi, 'https://docs.example.com$1');
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format and validate month/day ranges
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  return match[3]; // Return the year (fourth capture group)
}
