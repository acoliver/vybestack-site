/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix) return [];
  
  // Create a Set of exceptions for faster lookup (not used in current implementation)
  
  // Find all words that start with the prefix
  // \b matches word boundary, \w+ matches word characters
  const prefixedWordsRegex = new RegExp(`\\b(${prefix}\\w+)`, 'gi');
  const matches = text.match(prefixedWordsRegex) || [];
  
  // Convert to lowercase if we want a case-insensitive comparison
  const matchesLowercase: string[] = matches.map(word => word.toLowerCase());
  const exceptionsLowercase: string[] = [];
for (const ex of exceptions) {
  exceptionsLowercase.push(ex.toLowerCase());
}
  
  // Filter out exceptions, preserving original case
  const filteredWords: string[] = matches.filter((word, index) => {
    return !exceptionsLowercase.includes(matchesLowercase[index]);
  });
  
  // Return deduplicated results
  const uniqueWords: string[] = [];
  const seen = new Map<string, boolean>();
  
  for (const word of filteredWords) {
    if (!seen.get(word)) {
      seen.set(word, true);
      uniqueWords.push(word);
    }
  }
  
  return uniqueWords;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token) return [];
  
  // Create a regex that finds the token when it appears after a digit but not at the start
  // (?<!^) ensures it's not at the beginning of the string
  // (?<=\d) ensures it comes after a digit
  // To avoid lookbehind which might not be supported in all environments, we'll use a different approach
  const pattern = new RegExp(`(\\d+)(${token})`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Extract just the digit+token part from matches
  return matches.map(match => {
    const tokenMatch = match.match(new RegExp(`(\\d+)(${token})`, 'i'));
    return tokenMatch ? tokenMatch[1] + tokenMatch[2] : '';
  }).filter(Boolean);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/\d/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Check for no whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  // This regex looks for any sequence of characters repeated immediately
  const repeatedSequenceRegex = /(.{2,})\1/;
  if (repeatedSequenceRegex.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex that excludes IPv4 addresses and supports shorthand :: notation
  // This pattern matches IPv6 addresses but excludes IPv4 patterns
  const ipv6Regex = /((^|[^0-9])([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}($|[^0-9]))|((^|[^0-9])([0-9a-fA-F]{1,4}:){1,7}:($|[^0-9]))|((^|[^0-9])([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}($|[^0-9]))|((^|[^0-9])([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}($|[^0-9]))|((^|[^0-9])([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}($|[^0-9]))|((^|[^0-9])([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}($|[^0-9]))|((^|[^0-9])([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}($|[^0-9]))|(^|[^0-9])([0-9a-fA-F]{1,4}:){1}(:[0-9a-fA-F]{1,4}){1,6}($|[^0-9])|(^|[^0-9]):((:[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  // Simple IPv4 regex to exclude IPv4 patterns
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  
  // Filter out IPv4 addresses first
  if (ipv4Regex.test(value)) {
    // Check if there's still something that could be IPv6
    const nonIpv4Text = value.replace(ipv4Regex, '');
    return ipv6Regex.test(nonIpv4Text);
  }
  
  return ipv6Regex.test(value);
}
