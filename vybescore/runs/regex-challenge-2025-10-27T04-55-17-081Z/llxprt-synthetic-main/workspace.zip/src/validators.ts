export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Local part can contain letters, digits, +, ., -, _, % but no consecutive dots
  // Domain must be valid with no underscores, can't start/end with hyphen
  // TLD must be at least 2 characters
  const emailRegex = /^[a-zA-Z0-9](\.?[a-zA-Z0-9+_%-])*[a-zA-Z0-9]@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  if (!value || typeof value !== 'string') return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces, hyphens, parentheses to get the raw digits
  const cleanedValue = value.replace(/[\s\-\(\)]/g, '');
  
  // Support optional +1 country code
  const withCountryCodeRegex = /^\+?1?([2-9]\d{2}[2-9]\d{2}\d{4})$/;
  // Without country code (10 digits)
  const withoutCountryCodeRegex = /^([2-9]\d{2}[2-9]\d{2}\d{4})$/;
  
  return withCountryCodeRegex.test(cleanedValue) || withoutCountryCodeRegex.test(cleanedValue);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens to normalize
  const cleanedValue = value.replace(/[\s\-]/g, '');
  
  // Argentine phone regex with optional country code (+54), optional trunk prefix (0), 
  // optional mobile indicator (9), area code (2-4 digits), subscriber number (6-8 digits)
  // When country code is omitted, number must start with trunk prefix 0
  const argentinePhoneRegex = /^(\+54)?(0?9?([1-9]\d{1,3})(\d{6,8}))$|^0(9?[1-9]\d{1,3})(\d{6,8})$/;
  
  return argentinePhoneRegex.test(cleanedValue);
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, emojis, and most symbols
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0180-\u024F\s\'\-]+$/;
  
  return nameRegex.test(value) && !/\d/.test(value);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let alternate = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanedValue = value.replace(/[\s\-]/g, '');
  
  // Check if it only contains digits
  if (!/^\d+$/.test(cleanedValue)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]|[3-6]\d|7[0-1])\d{14}$/;
  
  // Amex: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if card format matches any supported card type
  const isValidFormat = visaRegex.test(cleanedValue) || 
                        mastercardRegex.test(cleanedValue) || 
                        amexRegex.test(cleanedValue);
  
  if (!isValidFormat) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanedValue);
}
