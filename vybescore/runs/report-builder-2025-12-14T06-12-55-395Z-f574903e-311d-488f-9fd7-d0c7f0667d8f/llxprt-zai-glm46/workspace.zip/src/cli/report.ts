#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { markdownRenderer } from '../formats/markdown.js';
import { textRenderer } from '../formats/text.js';

interface CliOptions {
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): { dataPath: string; options: CliOptions } {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[2];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[++i];
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputPath = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument ${args[i]}`);
        process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, options: { format, outputPath, includeTotals } };
}

function loadReportData(dataPath: string): ReportData {
  try {
    const content = readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Invalid entry: missing or invalid "label" field');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Invalid entry: missing or invalid "amount" field');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${dataPath}: ${error.message}`);
    } else {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: CliOptions): string {
  const { format, includeTotals } = options;
  
  switch (format) {
    case 'markdown':
      return markdownRenderer.render(data, { includeTotals });
    case 'text':
      return textRenderer.render(data, { includeTotals });
    default:
      console.error(`Error: Unsupported format "${format}". Supported formats: markdown, text`);
      process.exit(1);
  }
}

function main(): void {
  const { dataPath, options } = parseArguments(process.argv);
  const data = loadReportData(dataPath);
  const output = renderReport(data, options);
  
  if (options.outputPath) {
    try {
      writeFileSync(options.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Unable to write to ${options.outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();