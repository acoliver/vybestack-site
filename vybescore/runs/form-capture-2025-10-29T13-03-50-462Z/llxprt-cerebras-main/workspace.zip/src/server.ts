import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import ejs from 'ejs';
import initSqlJs, { Database } from 'sql.js';

// Get __dirname equivalent in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize SQLite database
let db: Database;
let server: any;

const initializeDatabase = async () => {
  const SQL = await initSqlJs({
    locateFile: (file) => `https://cdnjs.cloudflare.com/ajax/libs/sql.js/1.10.0/${file}`
  });
  
  const dbPath = path.resolve('data', 'submissions.sqlite');
  let dbData: Uint8Array | undefined;
  
  try {
    dbData = new Uint8Array(fs.readFileSync(dbPath).buffer);
  } catch (err) {
    // File doesn't exist, which is fine - we'll create a new database
  }
  
  db = new SQL.Database(dbData);
  
  // Create table if not exists
  db.run(`
    CREATE TABLE IF NOT EXISTS submissions (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      first_name TEXT NOT NULL,
      last_name TEXT NOT NULL,
      street_address TEXT NOT NULL,
      city TEXT NOT NULL,
      state_province TEXT NOT NULL,
      postal_code TEXT NOT NULL,
      country TEXT NOT NULL,
      email TEXT NOT NULL,
      phone TEXT NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now'))
    );
  `);
};

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^\+?[\d\s\-\(\)]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  // Basic validation for alphanumeric codes with possible spaces and dashes
  const postalCodeRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
};

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  } = req.body;
  
  const errors: string[] = [];
  
  // Required field validation
  if (!firstName) errors.push('First name is required');
  if (!lastName) errors.push('Last name is required');
  if (!streetAddress) errors.push('Street address is required');
  if (!city) errors.push('City is required');
  if (!stateProvince) errors.push('State/Province is required');
  if (!postalCode) errors.push('Postal code is required');
  if (!country) errors.push('Country is required');
  if (!email) errors.push('Email is required');
  if (!phone) errors.push('Phone number is required');
  
  // Additional validation
  if (email && !validateEmail(email)) {
    errors.push('Please enter a valid email address');
  }
  
  if (phone && !validatePhone(phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  if (postalCode && !validatePostalCode(postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors,
      values: req.body
    });
  }
  
  // Insert into database
  db.run(
    `INSERT INTO submissions 
     (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    ]
  );
  
  // Save database to file
  const dbPath = path.resolve('data', 'submissions.sqlite');
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(firstName));
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully');
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  // Save database before exit
  const dbPath = path.resolve('data', 'submissions.sqlite');
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
  
  process.exit(0);
});

// Start server after DB initialization
const startServer = async () => {
  await initializeDatabase();
  server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
};

// Need to import fs for file operations
import fs from 'node:fs';
startServer();

export default app;
export { server };