/**
 * Validate Base64 input string format.
 * Throws an error for clearly invalid Base64 input.
 */
function validateBase64Input(input: string): void {
  // Check for invalid characters
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64: contains illegal characters');
  }

  // Check for incorrect padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingPart = input.substring(paddingIndex);
    if (!/^[=]+$/.test(paddingPart)) {
      throw new Error('Invalid Base64: padding characters not at the end');
    }
    
    // Maximum 2 padding characters
    if (paddingPart.length > 2) {
      throw new Error('Invalid Base64: too many padding characters');
    }
    
    // String length must be valid when considering padding
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64: incorrect string length with padding');
    }
  } else {
    // Without padding, length must be valid for unpadded Base64
    // Unpadded Base64 can have lengths that are not divisible by 4
    // Only check that length is not 1 modulo 4 (which would be invalid)
    if (input.length % 4 === 1) {
      throw new Error('Invalid Base64: incorrect string length');
    }
  }
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input format and rejects invalid Base64 strings.
 */
export function decode(input: string): string {
  // Validate input format first
  validateBase64Input(input);

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}