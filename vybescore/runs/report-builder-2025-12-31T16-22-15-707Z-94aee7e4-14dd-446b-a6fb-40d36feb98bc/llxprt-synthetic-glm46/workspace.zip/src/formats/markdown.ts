import type { Report, RenderOptions, RendererFunction } from "../types.js";

export const renderMarkdown: RendererFunction = (
  report: Report,
  options: RenderOptions,
): string => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${report.title}`);
  lines.push("");

  // Summary
  lines.push(report.summary);
  lines.push("");

  // Entries heading
  lines.push("## Entries");

  // Entries list
  for (const entry of report.entries) {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  }

  // Include totals if requested
  if (options.includeTotals) {
    const total = report.entries.reduce(
      (sum, entry) => sum + entry.amount,
      0,
    );
    const totalAmount = total.toFixed(2);
    lines.push(`**Total:** $${totalAmount}`);
  }

  return lines.join("\n");
};