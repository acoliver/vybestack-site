#!/usr/bin/env node

import { readFileSync, writeFileSync } from "node:fs";
import { exit } from "node:process";
import type { Report, Format, RenderOptions } from "../types.js";
import { renderMarkdown } from "../formats/markdown.js";
import { renderText } from "../formats/text.js";

interface ParsedArgs {
  filePath: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): ParsedArgs {
  // Remove node script path
  const cleanArgs = args.slice(2);

  if (cleanArgs.length < 3) {
    console.error(
      "Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]",
    );
    exit(1);
  }

  const filePath = cleanArgs[0];

  const formatIndex = cleanArgs.findIndex((arg) => arg === "--format");
  if (formatIndex === -1 || formatIndex + 1 >= cleanArgs.length) {
    console.error("Missing --format argument");
    exit(1);
  }

  const rawFormat = cleanArgs[formatIndex + 1];
  if (rawFormat !== "markdown" && rawFormat !== "text") {
    console.error(`Unsupported format: ${rawFormat}`);
    exit(1);
  }
  const format = rawFormat as Format;

  const outputIndex = cleanArgs.findIndex((arg) => arg === "--output");
  const outputPath = outputIndex !== -1 && outputIndex + 1 < cleanArgs.length
    ? cleanArgs[outputIndex + 1]
    : undefined;

  const includeTotals = cleanArgs.includes("--includeTotals");

  return { filePath, format, outputPath, includeTotals };
}

function validateReport(data: unknown): Report {
  if (!data || typeof data !== "object") {
    throw new Error("Invalid JSON: expected object");
  }

  const record = data as Record<string, unknown>;

  if (
    typeof record.title !== "string" || !record.title.trim()
  ) {
    throw new Error("Missing or invalid 'title' field (expected non-empty string)");
  }

  if (
    typeof record.summary !== "string" || !record.summary.trim()
  ) {
    throw new Error("Missing or invalid 'summary' field (expected non-empty string)");
  }

  if (!Array.isArray(record.entries)) {
    throw new Error("Missing or invalid 'entries' field (expected array)");
  }

  if (record.entries.length === 0) {
    throw new Error("'entries' array cannot be empty");
  }

  for (const entry of record.entries) {
    if (!entry || typeof entry !== "object") {
      throw new Error("Each entry must be an object");
    }

    const entryRecord = entry as Record<string, unknown>;

    if (
      typeof entryRecord.label !== "string" || !entryRecord.label.trim()
    ) {
      throw new Error(
        "Missing or invalid 'label' field in entry (expected non-empty string)",
      );
    }

    if (typeof entryRecord.amount !== "number" || isNaN(entryRecord.amount)) {
      throw new Error(
        "Missing or invalid 'amount' field in entry (expected number)",
      );
    }
  }

  return data as Report;
}

function main() {
  try {
    // Parse command line arguments
    const { filePath, format, outputPath, includeTotals } = parseArguments(
      process.argv,
    );

    // Read and parse JSON file
    let fileContent: string;
    try {
      fileContent = readFileSync(filePath, "utf-8");
    } catch (error) {
      console.error(`Error reading file: ${filePath}`);
      console.error(String(error));
      exit(1);
    }

    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error parsing JSON file: ${filePath}`);
      console.error(`Invalid JSON: ${String(error)}`);
      exit(1);
    }

    // Validate report structure
    const report = validateReport(data);

    // Configure render options
    const options: RenderOptions = {
      includeTotals,
    };

    // Render report based on format
    const renderers = {
      markdown: renderMarkdown,
      text: renderText,
    };
    const renderer = renderers[format];
    const output = renderer(report, options);

    // Write output
    if (outputPath) {
      try {
        writeFileSync(outputPath, output, "utf-8");
        console.log(`Report written to: ${outputPath}`);
      } catch (error) {
        console.error(`Error writing to file: ${outputPath}`);
        console.error(String(error));
        exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    exit(1);
  }
}

main();
