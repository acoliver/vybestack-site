/**
 * Encode plain text to Base64 using standard Base64 alphabet (A-Z, a-z, 0-9, +, /).
 * Output includes padding (=) when required to maintain proper Base64 format.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both padded and unpadded Base64 input.
 * Rejects clearly invalid Base64 input by throwing an error.
 */
export function decode(input: string): string {
  // Remove any whitespace
  const sanitized = input.replace(/\s/g, '');
  
  // Check if input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(sanitized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Add padding if missing (Base64 should be divisible by 4)
  let paddedInput = sanitized;
  const missingPadding = (4 - (sanitized.length % 4)) % 4;
  if (missingPadding > 0) {
    paddedInput += '='.repeat(missingPadding);
  }
  
  try {
    const decoded = Buffer.from(paddedInput, 'base64').toString('utf8');
    
    // Verify that we can re-encode the decoded text to get the original input
    // This helps catch edge cases where Base64 might decode but to wrong text
    const reEncoded = Buffer.from(decoded, 'utf8').toString('base64');
    if (reEncoded !== paddedInput) {
      throw new Error('Decoded text does not match expected Base64');
    }
    
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input: ' + (error instanceof Error ? error.message : 'unknown error'));
  }
}
