"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var index_js_1 = require("./src/index.js");
console.log('=== EDGE CASE TESTING ===\n');
// Test 1: Email validation edge cases
console.log('Email validation tests:');
console.log('name+tag@example.co.uk:', (0, index_js_1.isValidEmail)('name+tag@example.co.uk'));
console.log('user@domain..com:', (0, index_js_1.isValidEmail)('user@domain..com'));
console.log('user@domain_.com:', (0, index_js_1.isValidEmail)('user@domain_.com'));
console.log('user@domain.com.:', (0, index_js_1.isValidEmail)('user@domain.com.'));
console.log('user@@domain.com:', (0, index_js_1.isValidEmail)('user@@domain.com'));
console.log('\n--- US Phone validation tests:');
console.log('(212) 555-7890:', (0, index_js_1.isValidUSPhone)('(212) 555-7890'));
console.log('212-555-7890:', (0, index_js_1.isValidUSPhone)('212-555-7890'));
console.log('2125557890:', (0, index_js_1.isValidUSPhone)('2125557890'));
console.log('+1 212-555-7890:', (0, index_js_1.isValidUSPhone)('+1 212-555-7890'));
console.log('012-555-7890:', (0, index_js_1.isValidUSPhone)('012-555-7890')); // invalid area code
console.log('123:', (0, index_js_1.isValidUSPhone)('123')); // too short
console.log('\n--- Argentine Phone validation tests:');
console.log('+54 9 11 1234 5678:', (0, index_js_1.isValidArgentinePhone)('+54 9 11 1234 5678'));
console.log('011 1234 5678:', (0, index_js_1.isValidArgentinePhone)('011 1234 5678'));
console.log('+54 341 123 4567:', (0, index_js_1.isValidArgentinePhone)('+54 341 123 4567'));
console.log('0341 4234567:', (0, index_js_1.isValidArgentinePhone)('0341 4234567'));
console.log('\n--- Name validation tests:');
console.log('Jane Doe:', (0, index_js_1.isValidName)('Jane Doe'));
console.log('Jean-Pierre O\'Brien:', (0, index_js_1.isValidName)('Jean-Pierre O\'Brien'));
console.log('X Æ A-12:', (0, index_js_1.isValidName)('X Æ A-12'));
console.log('John123:', (0, index_js_1.isValidName)('John123'));
console.log('John@Doe:', (0, index_js_1.isValidName)('John@Doe'));
console.log('\n--- Credit Card validation tests:');
console.log('4111111111111111:', (0, index_js_1.isValidCreditCard)('4111111111111111')); // Visa test number
console.log('5555555555554444:', (0, index_js_1.isValidCreditCard)('5555555555554444')); // Mastercard test number
console.log('378282246310005:', (0, index_js_1.isValidCreditCard)('378282246310005')); // Amex test number
console.log('\n=== TRANSFORMATION TESTS ===\n');
console.log('Capitalize sentences:');
console.log((0, index_js_1.capitalizeSentences)('hello world. how are you? i am fine.'));
console.log('Capitalize with extra spaces:');
console.log((0, index_js_1.capitalizeSentences)('hello world.  how are you?'));
console.log('\nExtract URLs:');
var urlText = 'Visit http://example.com today. Also check https://google.com and ftp://files.com';
console.log('URLs found:', (0, index_js_1.extractUrls)(urlText));
console.log('\nEnforce HTTPS:');
var mixedText = 'http://example.com and https://secure.com';
console.log('HTTPS enforced:', (0, index_js_1.enforceHttps)(mixedText));
console.log('\nRewrite docs URLs:');
var docsText = 'See http://example.com/docs/guide and http://example.com/cgi-bin/test.jsp';
console.log('Docs URLs rewritten:', (0, index_js_1.rewriteDocsUrls)(docsText));
console.log('\nExtract year:');
console.log('01/31/2024:', (0, index_js_1.extractYear)('01/31/2024'));
console.log('invalid/date/format:', (0, index_js_1.extractYear)('invalid/date/format'));
console.log('13/45/2024:', (0, index_js_1.extractYear)('13/45/2024')); // invalid month/day
console.log('\n=== PUZZLE TESTS ===\n');
console.log('Find prefixed words:');
var prefixText = 'preview prevent prefix preview';
console.log('Words with "pre" excluding "prevent":', (0, index_js_1.findPrefixedWords)(prefixText, 'pre', ['prevent']));
console.log('\nFind embedded tokens:');
var tokenText = 'xfoo 1foo foo 2foo';
console.log('Embedded "foo":', (0, index_js_1.findEmbeddedToken)(tokenText, 'foo'));
console.log('\nPassword strength:');
console.log('Abcdef!234:', (0, index_js_1.isStrongPassword)('Abcdef!234'));
console.log('weak:', (0, index_js_1.isStrongPassword)('weak'));
console.log('NoSymbols123:', (0, index_js_1.isStrongPassword)('NoSymbols123'));
console.log('Abcdef!234Abcdef!234:', (0, index_js_1.isStrongPassword)('Abcdef!234Abcdef!234')); // has immediate repeats
console.log('\nIPv6 detection:');
console.log('2001:db8::1:', (0, index_js_1.containsIPv6)('2001:db8::1'));
console.log('192.168.1.1:', (0, index_js_1.containsIPv6)('192.168.1.1'));
console.log('::ffff:192.168.1.1:', (0, index_js_1.containsIPv6)('::ffff:192.168.1.1'));
console.log('\n=== COMPLETE ===');
