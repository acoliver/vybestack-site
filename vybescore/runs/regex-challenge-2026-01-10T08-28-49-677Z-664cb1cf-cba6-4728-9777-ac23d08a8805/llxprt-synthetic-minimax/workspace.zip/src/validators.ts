export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Enhanced email validation with regex that supports +tags and more complex domains
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for obvious invalid formats that regex might miss
  if (value.includes('..') || value.endsWith('.') || 
      (value.match(/@/g) || []).length !== 1 ||
      value.includes('_.@') || value.includes('._')) {
    return false;
  }
  
  // Apply the comprehensive regex test
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.replace(/[^\d+]/g, '');
  
  // If there are multiple + signs or it's not at the beginning, invalid
  if (cleanValue.includes('+') && !cleanValue.startsWith('+')) {
    return false;
  }
  
  // Check for multiple leading + signs
  if ((cleanValue.match(/\+/g) || []).length > 1) {
    return false;
  }
  
  // Remove + for processing
  const digitsOnly = cleanValue.replace(/\+/g, '');
  
  // Must have exactly 10 digits for US numbers (excluding +1)
  // Allow 11 digits only if it starts with 1
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    // Valid with country code
  } else if (digitsOnly.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits)
  const areaCode = digitsOnly.substring(digitsOnly.length === 11 ? 1 : 0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Must match specific US format patterns
  const phonePatterns = [
    /^\+?1?\d{10}$/,                    // 1234567890 or +11234567890
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-.\s]*\d{4}$/, // +1 (212) 555-7890 or (212) 555-7890
    /^\+?1?\s*\d{3}[-.\s]*\d{3}[-.\s]*\d{4}$/, // +1 212-555-7890 or 212-555-7890
    /^\+?1?\s*\d{3}\s*\d{3}\s*\d{4}$/          // +1 212 555 7890 or 212 555 7890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleanValue = value.trim();
  
  // Check for obvious invalid formats first
  if (!/\d/.test(cleanValue)) {
    return false; // No digits at all
  }
  
  // Extract all digit groups
  const digitGroups = cleanValue.match(/\d+/g) || [];
  if (digitGroups.length === 0) {
    return false;
  }
  
  // Combine digits and check total length
  const allDigits = digitGroups.join('');
  if (allDigits.length < 10 || allDigits.length > 13) {
    return false;
  }
  
  // Parse based on different patterns
  let areaCodeDigits = '';
  let subscriberDigits = '';
  
  // Check for different formats
  if (cleanValue.startsWith('+54')) {
    // Format with country code
    if (digitGroups.length >= 4) {
      // Try: +54 9 11 1234 5678 or +54 341 123 4567
      if (digitGroups[1] === '9') {
        // Mobile format: +54 9 XX XXX XXXX
        areaCodeDigits = digitGroups[2];
        subscriberDigits = digitGroups[3] + digitGroups[4];
      } else {
        // Landline format: +54 XX XXX XXXX
        areaCodeDigits = digitGroups[1];
        subscriberDigits = digitGroups[2] + digitGroups[3];
      }
    } else if (digitGroups.length === 3) {
      // Try: +54 XX XXXXXXXX (compact)
      areaCodeDigits = digitGroups[1];
      subscriberDigits = digitGroups[2];
    }
  } else if (cleanValue.startsWith('0')) {
    // Format without country code (trunk prefix required)
    if (digitGroups.length >= 3) {
      // General trunk prefix format: 0XX XXX XXXX
      // Strip trunk prefix '0' from area code
      const firstGroupWithTrunk = digitGroups[0];
      if (firstGroupWithTrunk && firstGroupWithTrunk.length >= 3) {
        areaCodeDigits = firstGroupWithTrunk.slice(1); // Remove leading '0'
        subscriberDigits = digitGroups[1] + digitGroups[2];
      }
    } else if (digitGroups.length === 2) {
      // Compact trunk prefix format: 0XXXXXXXXX
      const firstGroupWithTrunk = digitGroups[0];
      if (firstGroupWithTrunk && firstGroupWithTrunk.length >= 3) {
        areaCodeDigits = firstGroupWithTrunk.slice(1); // Remove leading '0'
        subscriberDigits = digitGroups[1];
      }
    }
  } else {
    // No country code or trunk prefix - invalid
    return false;
  }
  
  // Validate area code (2-4 digits, first digit 1-9)
  if (areaCodeDigits.length < 2 || areaCodeDigits.length > 4 || 
      !/^[1-9]/.test(areaCodeDigits)) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits total)
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  
  // Check for obviously invalid characters like numbers or weird symbols
  if (/[\d\s@#$%^&*()+=[\]{}|;:,.<>?]/.test(value)) {
    // Allow spaces, apostrophes, hyphens - so check more carefully
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject if contains unusual symbols that shouldn't be in names
  if (/[@#$%^&*()+=[\]{}|:;,.<>?]/.test(value)) {
    return false;
  }
  
  // Reject specific pattern that looks like the alien name mentioned
  if (/^[xX]\s*[Ææ]\s*[aA]-\d+$/.test(value)) {
    return false;
  }
  
  // Must contain at least some letters
  const hasLetters = /[a-zA-Z\u00C0-\u024F]/.test(value);
  if (!hasLetters) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens, accents
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\s'-]+$/;
  
  // Must be at least 2 characters and not just punctuation
  if (value.length < 2) {
    return false;
  }
  
  // Check for multiple consecutive spaces or punctuation-only patterns
  if (/^\s*['-]+\s*$/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Luhn algorithm helper function for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\s/g, '').split('').map(Number);
  
  // Double every second digit from right to left
  for (let i = digits.length - 2; i >= 0; i -= 2) {
    digits[i] *= 2;
    if (digits[i] > 9) {
      digits[i] -= 9;
    }
  }
  
  // Sum all digits and check if divisible by 10
  const sum = digits.reduce((acc, digit) => acc + digit, 0);
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Clean the input - remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits for most credit cards
  if (!/^\d{13,19}$/.test(cleanValue)) {
    return false;
  }
  
  // Check for obvious card type prefixes and validate with Luhn
  // Visa: starts with 4, 13, 16, or 19 digits
  if (/^4/.test(cleanValue) && /^\d{13}(\d{3})?$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  if ((/^5[1-5]/.test(cleanValue) || /^2[2-7][2-9]/.test(cleanValue)) && /^\d{16}$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // American Express: starts with 34 or 37, 15 digits
  if (/^(34|37)/.test(cleanValue) && /^\d{15}$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Discover: starts with 6011, 65, 644-649, or 622126-622925, 16-19 digits
  if ((/^6011/.test(cleanValue) || /^65/.test(cleanValue) || /^64[4-9]/.test(cleanValue) || /^622[12][6-9]/.test(cleanValue)) && /^\d{16,19}$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // JCB: starts with 3528-3589, 16-19 digits
  if (/^35[2-8][8-9]/.test(cleanValue) && /^\d{16,19}$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // If no specific card type matched but it's all digits in valid range, still validate with Luhn
  if (/^\d{13,19}$/.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}
