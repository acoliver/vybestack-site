"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.isValidEmail = isValidEmail;
exports.isValidUSPhone = isValidUSPhone;
exports.isValidArgentinePhone = isValidArgentinePhone;
exports.isValidName = isValidName;
exports.isValidCreditCard = isValidCreditCard;
/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
function isValidEmail(value) {
    // Basic email validation with regex
    var emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
    // Check for double dots, trailing dots, domains with underscores
    if (value.includes('..') || value.endsWith('.') || value.includes('_.') || value.includes('._')) {
        return false;
    }
    // Check for obvious issues like double @ symbols
    if ((value.match(/@/g) || []).length !== 1) {
        return false;
    }
    return emailRegex.test(value);
}
/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
function isValidUSPhone(value, _options) {
    // Remove all non-digit characters except leading +
    var cleanValue = value.replace(/[^\d+]/g, '');
    // If there are multiple + signs or it's not at the beginning, invalid
    if (cleanValue.includes('+') && !cleanValue.startsWith('+')) {
        return false;
    }
    // Check for multiple leading + signs
    if ((cleanValue.match(/\+/g) || []).length > 1) {
        return false;
    }
    // Remove + for processing
    var digitsOnly = cleanValue.replace(/\+/g, '');
    // Must have exactly 10 digits for US numbers (excluding +1)
    // Allow 11 digits only if it starts with 1
    if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
        // Valid with country code
    }
    else if (digitsOnly.length !== 10) {
        return false;
    }
    // Check area code (first 3 digits)
    var areaCode = digitsOnly.substring(digitsOnly.length === 11 ? 1 : 0, 3);
    // Area codes cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') {
        return false;
    }
    // Must start with specific US format patterns
    var phonePatterns = [
        /^\d{10}$/, // 1234567890
        /^\+?1?\d{10}$/, // +11234567890 or 11234567890
        /^\+?1?\s*\(\d{3}\)\s*\d{3}\s*\d{4}$/, // +1 (212) 555-7890 or (212) 555-7890
        /^\+?1?\s*\d{3}[-.\s]*\d{3}[-.\s]*\d{4}$/ // +1 212-555-7890 or 212-555-7890
    ];
    return phonePatterns.some(function (pattern) { return pattern.test(value); });
}
/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
function isValidArgentinePhone(value) {
    // Pattern for Argentine phone numbers with flexible formatting
    var patterns = [
        // With country code +54, optional 0 trunk prefix, optional 9 mobile indicator
        /^\+54\s*0?\s*9?\s*[1-9]\d{2,3}(?:\s*\d){6,8}$/,
        // Without country code but with trunk prefix 0, optional mobile indicator
        /^0\s*9?\s*[1-9]\d{2,3}(?:\s*\d){6,8}$/
    ];
    return patterns.some(function (pattern) { return pattern.test(value); });
}
/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
function isValidName(value) {
    // Allow unicode letters, accents, apostrophes, hyphens, spaces
    // Reject digits, symbols, and names like "X Æ A-12"
    // Check for obviously invalid characters like numbers or weird symbols
    if (/[\d\s@#$%^&*()+=[\]{}|;:,.<>?]/.test(value)) {
        // Allow spaces, apostrophes, hyphens - so check more carefully
    }
    // Reject if contains digits
    if (/\d/.test(value)) {
        return false;
    }
    // Reject if contains unusual symbols that shouldn't be in names
    if (/[@#$%^&*()+=[\]{}|:;,.<>?]/.test(value)) {
        return false;
    }
    // Reject specific pattern that looks like the alien name mentioned
    if (/^[xX]\s*[Ææ]\s*[aA]-\d+$/.test(value)) {
        return false;
    }
    // Must contain at least some letters
    var hasLetters = /[a-zA-Z\u00C0-\u024F]/.test(value);
    if (!hasLetters) {
        return false;
    }
    // Allow unicode letters, spaces, apostrophes, hyphens, accents
    var nameRegex = /^[a-zA-Z\u00C0-\u024F\s'-]+$/;
    // Must be at least 2 characters and not just punctuation
    if (value.length < 2) {
        return false;
    }
    // Check for multiple consecutive spaces or punctuation-only patterns
    if (/^\s*['-]+\s*$/.test(value)) {
        return false;
    }
    return nameRegex.test(value);
}
/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
/**
 * Luhn algorithm helper function for credit card validation
 */
function runLuhnCheck(cardNumber) {
    var digits = cardNumber.replace(/\s/g, '').split('').map(Number);
    // Double every second digit from right to left
    for (var i = digits.length - 2; i >= 0; i -= 2) {
        digits[i] *= 2;
        if (digits[i] > 9) {
            digits[i] -= 9;
        }
    }
    // Sum all digits and check if divisible by 10
    var sum = digits.reduce(function (acc, digit) { return acc + digit; }, 0);
    return sum % 10 === 0;
}
function isValidCreditCard(value) {
    // Clean the input - remove spaces and dashes
    var cleanValue = value.replace(/[\s-]/g, '');
    // Must be 13-19 digits for most credit cards
    if (!/^\d{13,19}$/.test(cleanValue)) {
        return false;
    }
    // Check for obvious card type prefixes and validate with Luhn
    // Visa: starts with 4, 13, 16, or 19 digits
    if (/^4/.test(cleanValue) && /^\d{13}(\d{3})?$/.test(cleanValue)) {
        return runLuhnCheck(cleanValue);
    }
    // Mastercard: starts with 51-55 or 2221-2720, 16 digits
    if ((/^5[1-5]/.test(cleanValue) || /^2[2-7][2-9]/.test(cleanValue)) && /^\d{16}$/.test(cleanValue)) {
        return runLuhnCheck(cleanValue);
    }
    // American Express: starts with 34 or 37, 15 digits
    if (/^(34|37)/.test(cleanValue) && /^\d{15}$/.test(cleanValue)) {
        return runLuhnCheck(cleanValue);
    }
    // Discover: starts with 6011, 65, 644-649, or 622126-622925, 16-19 digits
    if ((/^6011/.test(cleanValue) || /^65/.test(cleanValue) || /^64[4-9]/.test(cleanValue) || /^622[12][6-9]/.test(cleanValue)) && /^\d{16,19}$/.test(cleanValue)) {
        return runLuhnCheck(cleanValue);
    }
    // JCB: starts with 3528-3589, 16-19 digits
    if (/^35[2-8][8-9]/.test(cleanValue) && /^\d{16,19}$/.test(cleanValue)) {
        return runLuhnCheck(cleanValue);
    }
    // If no specific card type matched but it's all digits in valid range, still validate with Luhn
    if (/^\d{13,19}$/.test(cleanValue)) {
        return runLuhnCheck(cleanValue);
    }
    return false;
}
