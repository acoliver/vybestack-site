"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.findPrefixedWords = findPrefixedWords;
exports.findEmbeddedToken = findEmbeddedToken;
exports.isStrongPassword = isStrongPassword;
exports.containsIPv6 = containsIPv6;
/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
function findPrefixedWords(text, prefix, exceptions) {
    // Escape special regex characters in prefix
    var escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // Pattern to match words starting with prefix (case insensitive)
    var wordPattern = new RegExp("\\b".concat(escapedPrefix, "[a-zA-Z]*\\b"), 'gi');
    // Find all matches
    var matches = text.match(wordPattern) || [];
    // Filter out exceptions (case insensitive)
    var lowercaseExceptions = exceptions.map(function (e) { return e.toLowerCase(); });
    var filteredMatches = matches.filter(function (word) {
        return !lowercaseExceptions.includes(word.toLowerCase());
    });
    return filteredMatches;
}
/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
function findEmbeddedToken(text, token) {
    // Escape special regex characters in token
    var escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
    // Pattern to match token preceded by a digit (using lookbehind to ensure digit before)
    // This matches digit followed by token, ensuring it's not at string start
    var tokenPattern = new RegExp("(?<!^)\\d".concat(escapedToken), 'gi');
    // Find all matches
    var matches = text.match(tokenPattern) || [];
    return matches;
}
/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
function isStrongPassword(value) {
    // Check length: at least 10 characters
    if (value.length < 10) {
        return false;
    }
    // Check for whitespace
    if (/\s/.test(value)) {
        return false;
    }
    // Check for required character types
    var hasUppercase = /[A-Z]/.test(value);
    var hasLowercase = /[a-z]/.test(value);
    var hasDigit = /\d/.test(value);
    var hasSymbol = /[!@#$%^&*()[\]{}|;:'",.<>/?`~-]/.test(value);
    if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
        return false;
    }
    // Check for immediate repeated sequences (e.g., abab should fail)
    // Pattern to find repeating patterns like abab, xyxy, etc.
    var hasImmediateRepeats = /(\w{2})\1/.test(value);
    if (hasImmediateRepeats) {
        return false;
    }
    // More thorough check for any repeating sequences
    for (var i = 0; i < value.length - 3; i++) {
        var pattern = value.substring(i, i + 2);
        if (value.substring(i + 2, i + 4) === pattern) {
            return false;
        }
    }
    return true;
}
/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
function containsIPv6(value) {
    // IPv6 pattern that includes shorthand notation (::)
    // This matches various IPv6 formats while excluding IPv4 patterns
    var ipv6Patterns = [
        // Full 8 groups with possible leading zeros omitted
        /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/,
        // Shorthand with :: compression (at least 2 groups, up to 7 before/after)
        /\b(?:[a-fA-F0-9]{1,4}:){0,6}::(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{1,4}\b/,
        // Shorthand starting with :: (like ::1)
        /\b::[a-fA-F0-9]{1,4}\b/,
        // Shorthand ending with :: (like fe80::)
        /\b[a-fA-F0-9]{1,4}::\b/,
        // IPv4-mapped IPv6 (::ffff:192.168.1.1)
        /\b::(?:ffff:)?(?:25[0-5]|2[0-4]\d|[01]?\d\d?)(?:\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)){3}\b/,
        // Shorthand in middle with various group counts
        /\b(?:[a-fA-F0-9]{1,4}:){1,6}:(?:[a-fA-F0-9]{1,4}:){1,6}[a-fA-F0-9]{1,4}\b/
    ];
    // Check if any IPv6 pattern matches
    for (var _i = 0, ipv6Patterns_1 = ipv6Patterns; _i < ipv6Patterns_1.length; _i++) {
        var pattern = ipv6Patterns_1[_i];
        if (pattern.test(value)) {
            // Double-check: ensure it's not just an IPv4 address
            var ipv4Pattern = /\b(?:25[0-5]|2[0-4]\d|[01]?\d\d?)(?:\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)){3}\b/;
            if (!ipv4Pattern.test(value)) {
                return true;
            }
        }
    }
    return false;
}
