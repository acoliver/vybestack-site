/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix (case insensitive)
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case insensitive)
  const lowercaseExceptions = exceptions.map(e => e.toLowerCase());
  const filteredMatches = matches.filter(word => {
    return !lowercaseExceptions.includes(word.toLowerCase());
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token preceded by a digit (using lookbehind to ensure digit before)
  // This matches digit followed by token, ensuring it's not at string start
  const tokenPattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'gi');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()[\]{}|;:'",.<>/?`~-]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeating sequences of any length
  // Look for patterns like "abab", "xyxy", "abcabc", "123123", etc.
  for (let i = 0; i < value.length - 3; i++) {
    for (let len = 1; len <= 4 && i + len * 2 <= value.length; len++) {
      const pattern = value.substring(i, i + len);
      if (len >= 2 && pattern === value.substring(i + len, i + len * 2)) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that includes shorthand notation (::)
  // This matches various IPv6 formats while excluding pure IPv4 patterns
  const ipv6Patterns = [
    // Full 8 groups with possible leading zeros omitted
    /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/,
    // Shorthand with :: compression (at least 2 groups, up to 7 before/after)
    /\b(?:[a-fA-F0-9]{1,4}:){0,6}::(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{1,4}\b/,
    // Shorthand starting with :: (like ::1)
    /\b::[a-fA-F0-9]{1,4}\b/,
    // Shorthand ending with :: (like fe80::)
    /\b[a-fA-F0-9]{1,4}::\b/,
    // Shorthand in middle with various group counts
    /\b(?:[a-fA-F0-9]{1,4}:){1,6}:(?:[a-fA-F0-9]{1,4}:){1,6}[a-fA-F0-9]{1,4}\b/
  ];
  
  // IPv4-mapped IPv6 pattern (should return true for IPv6 detection)
  const ipv4MappedPattern = /::(?:ffff:)?(?:25[0-5]|2[0-4]\d|[01]?\d\d?)(?:\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)){3}/;
  
  // Check for IPv4-mapped IPv6 addresses first
  if (ipv4MappedPattern.test(value)) {
    return true;
  }
  
  // Check if any standard IPv6 pattern matches
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Double-check: ensure it's not just a pure IPv4 address
      const pureIpv4Pattern = /^(?:25[0-5]|2[0-4]\d|[01]?\d\d?)(?:\.(?:25[0-5]|2[0-4]\d|[01]?\d\d?)){3}$/;
      if (!pureIpv4Pattern.test(value.trim())) {
        return true;
      }
    }
  }
  
  return false;
}
