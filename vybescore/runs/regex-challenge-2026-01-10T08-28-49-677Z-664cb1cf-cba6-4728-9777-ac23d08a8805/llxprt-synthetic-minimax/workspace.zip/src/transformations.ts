/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // This captures sentences starting at beginning or after punctuation
  return text.replace(/(?:^|[.!?]\s+)([a-z])/g, (match, letter) => {
    return match.replace(letter, letter.toUpperCase());
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Enhanced URL pattern to capture common formats
  const urlPattern = /\b(?:https?|ftp):\/\/[^\s<>"{}|^`[]+|\bwww\.[^\s<>"{}|^`[]+|\b[a-zA-Z0-9-]+\.(?:[a-zA-Z]{2,})(?:\/[^\s<>"{}|^`[]*)?/gi;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that shouldn't be part of URL
    return url.replace(/[.,;:!?]+$/, '').replace(/[)\]]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving https:// untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/... URLs
  const docsUrlPattern = /http:\/\/example\.com\/([^\s<>"{}|\\^`[\]]*)/gi;
  
  return text.replace(docsUrlPattern, (match, path) => {
    // Always upgrade scheme to https
    let newUrl = 'https://example.com/' + path;
    
    // Check if path begins with docs/ (not /docs/ because we're already matching after example.com/)
    if (path.startsWith('docs/')) {
      // Check for dynamic hints or legacy extensions in the path
      const hasDynamicHints = /(cgi-bin|\?|&|=|(\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py))/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        newUrl = 'https://docs.example.com/' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation: month 1-12, day 1-31 (simple check)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Check for impossible dates (e.g., February 30)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Leap year validation for February
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    // Not a leap year if not divisible by 4, or divisible by 100 but not 400
    if ((yearNum % 4 !== 0) || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  return year;
}
