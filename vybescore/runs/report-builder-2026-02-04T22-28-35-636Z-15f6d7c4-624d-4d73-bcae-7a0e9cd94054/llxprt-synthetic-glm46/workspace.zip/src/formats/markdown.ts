import type { ReportData, ReportOptions } from '../types.js';

export function renderMarkdown(
  data: ReportData,
  options: Omit<ReportOptions, 'format'>
): string {
  const { title, summary, entries } = data;
  const { includeTotals = false } = options;

  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);

  const lines: string[] = [];

  // Title
  lines.push(`# ${title}`);
  lines.push('');

  // Summary
  lines.push(summary);
  lines.push('');

  // Entries heading
  lines.push('## Entries');
  lines.push('');

  // Entries list
  for (const entry of entries) {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  }

  // Optional total
  if (includeTotals) {
    lines.push('');
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }

  return lines.join('\n');
}