#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import process from 'node:process';
import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): ReportOptions & { inputFilePath: string } {
  const args = process.argv.slice(2);
  const result = {
    format: 'markdown' as 'markdown' | 'text',
    inputFilePath: '',
    includeTotals: false,
  };

  if (args.length === 0) {
    usage();
    process.exit(1);
  }

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    switch (arg) {
      case '--format': {
        if (i + 1 >= args.length) {
          console.error('--format requires a value');
          process.exit(1);
        }
        const formatValue = args[++i];
        if (formatValue !== 'markdown' && formatValue !== 'text') {
          console.error('Unsupported format:', formatValue);
          process.exit(1);
        }
        result.format = formatValue;
        break;
      }

      case '--output':
        if (i + 1 >= args.length) {
          console.error('--output requires a path');
          process.exit(1);
        }
        // Skip the output path argument as we don't need it for this CLI
        i++;
        break;

      case '--includeTotals':
        result.includeTotals = true;
        break;

      default:
        if (arg.startsWith('-')) {
          console.error('Unknown option:', arg);
          usage();
          process.exit(1);
        }
        if (result.inputFilePath) {
          console.error('Multiple input files provided');
          process.exit(1);
        }
        result.inputFilePath = arg;
        break;
    }
  }

  if (!result.inputFilePath) {
    console.error('Input file is required');
    usage();
    process.exit(1);
  }

  return result;
}

function usage(): void {
  console.log(`
Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]

Formats:
  markdown - Render as Markdown
  text     - Render as plain text

Options:
  --output <path>     Write output to file instead of stdout
  --includeTotals     Include totals in the report
`);
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid report data: entries must be objects');
    }

    const entryObj = entry as Record<string, unknown>;
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error('Invalid report data: entry missing "label" field');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid report data: entry has invalid "amount" field');
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const { inputFilePath, format, includeTotals } = parseArguments();

    // Read and parse JSON file
    let content;
    try {
      content = readFileSync(inputFilePath, 'utf-8');
    } catch (error) {
      console.error(`Error reading file ${inputFilePath}:`, error);
      process.exit(1);
    }

    let data;
    try {
      data = JSON.parse(content);
    } catch (error) {
      console.error(`Error parsing JSON in ${inputFilePath}:`, error);
      process.exit(1);
    }

    // Validate data structure
    const validatedData = validateReportData(data);

    // Get renderer
    const renderers: Record<string, ReportRenderer> = {
      markdown: renderMarkdown,
      text: renderText,
    };

    const renderer = renderers[format];
    if (!renderer) {
      console.error('Unsupported format:', format);
      process.exit(1);
    }

    // Render report
    const output = renderer(validatedData, { includeTotals });
    console.log(output);
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
