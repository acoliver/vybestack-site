/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Word boundary + prefix + word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(word => !exceptionsLower.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of the token that come after a digit
  const results: string[] = [];
  
  for (let i = 0; i < text.length; i++) {
    // Check if token starts at this position
    if (text.slice(i).startsWith(token)) {
      // Check if it's not at the start and the previous character is a digit
      if (i > 0 && /\d/.test(text[i - 1])) {
        // Include the digit with the token
        results.push(text[i - 1] + token);
      }
      // Skip ahead by token length to avoid overlapping matches
      i += token.length - 1;
    }
  }
  
  return results;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc, 1212)
  // Look for any pattern of 2-4 characters that repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const pattern = value.slice(i, i + len);
      const next = value.slice(i + len, i + 2 * len);
      if (pattern === next) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check for standard IPv6 (8 groups of hex)
  const standardIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;

  // Check for :: shorthand - simplified to match most common cases
  // Matches patterns like: fe80::1, ::1, 2001:db8::, etc.
  const shorthandIPv6 = /(?:[0-9a-fA-F]{0,4}:)*::(?:[0-9a-fA-F]{0,4}:?)*/;

  // Check for IPv6 with embedded IPv4
  const embeddedIPv4 = /\b(?:[0-9a-fA-F]{0,4}:){2,7}:(?:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})\b/;

  // First check if it matches any IPv6 pattern
  const hasStandardIPv6 = standardIPv6.test(value);
  const hasShorthandIPv6 = shorthandIPv6.test(value);
  const hasEmbeddedIPv4 = embeddedIPv4.test(value);

  return hasStandardIPv6 || hasShorthandIPv6 || hasEmbeddedIPv4;
}
