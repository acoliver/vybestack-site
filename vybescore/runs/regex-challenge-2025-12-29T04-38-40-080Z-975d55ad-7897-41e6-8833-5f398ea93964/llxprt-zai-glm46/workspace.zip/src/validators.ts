export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for patterns that are hard to catch in a single regex
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local or domain part
  if (value.endsWith('.') || value.includes('@.')) {
    return false;
  }
  
  // Reject underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Reject consecutive dots in local part
  const local = value.split('@')[0];
  if (local && (local.startsWith('.') || local.endsWith('.') || local.includes('..'))) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for +1 prefix
  const hasPlusOne = cleaned.startsWith('+1');
  const digits = hasPlusOne ? cleaned.slice(2) : cleaned.replace(/\+/g, '');
  
  // Must have exactly 10 digits (or 7 for local without area code in some cases)
  if (digits.length < 7) {
    return false;
  }
  
  if (digits.length === 10) {
    // Check area code - first digit cannot be 0 or 1
    const areaCode = digits.slice(0, 3);
    if (areaCode[0] === '0' || areaCode[0] === '1') {
      return false;
    }
    
    // Check exchange code - first digit cannot be 0 or 1
    const exchange = digits.slice(3, 6);
    if (exchange[0] === '0' || exchange[0] === '1') {
      return false;
    }
    
    return true;
  }
  
  // For 7 digit numbers (local)
  if (digits.length === 7) {
    return true;
  }
  
  // Check for extensions if allowed
  if (options?.allowExtensions) {
    const extMatch = cleaned.match(/(\d{10,})ext?(\d+)$/);
    if (extMatch) {
      const mainDigits = extMatch[1];
      const areaCode = mainDigits.slice(0, 3);
      if (areaCode[0] !== '0' && areaCode[0] !== '1') {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like:
 * +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if country code is present
  const hasCountryCode = cleaned.startsWith('+54');

  // When no country code, must start with trunk prefix 0
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }

  // When country code is present, should NOT have trunk prefix 0 immediately after
  if (hasCountryCode && cleaned.length > 3 && cleaned[3] === '0') {
    return false;
  }

  // Extract the relevant part after country code or trunk prefix
  let remaining: string;
  if (hasCountryCode) {
    remaining = cleaned.slice(3); // Remove +54
  } else {
    remaining = cleaned.slice(1); // Remove leading 0
  }

  // After country code (or after removing trunk prefix), we can have optional mobile indicator 9
  // followed by area code (2-4 digits starting 1-9) and subscriber (6-8 digits)
  const phonePattern = /^(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = remaining.match(phonePattern);

  if (!match) {
    return false;
  }

  const [, areaCode, subscriber] = match;

  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Name should contain only unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least one letter
  // Should not contain only special characters
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Should not have numbers
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject certain symbols that aren't apostrophes or hyphens
  // (already handled by regex but double-check)
  const invalidSymbols = /[!"#$%&()*+,./:;<=>?@[\\\]^_`{|}~]/;
  if (invalidSymbols.test(value)) {
    return false;
  }
  
  // Check for consecutive special characters that look weird
  if (/'{2,}/.test(value) || /-{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm helper.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let double = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (double) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    double = !double;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length and prefix for each card type
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;

  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{2}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12}$/;

  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const validFormat = visaRegex.test(cleaned) ||
                     mastercardRegex.test(cleaned) ||
                     amexRegex.test(cleaned);

  if (!validFormat) {
    return false;
  }

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
