/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences, collapses extra spaces.
 * Tries to preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single space
  let normalized = text.replace(/[ \t]+/g, ' ');
  
  // Remove spaces at the start and end
  normalized = normalized.trim();

  // Add space after sentence terminators when followed by a letter
  // But not after abbreviations
  // This is complex, so we'll use a more conservative approach
  normalized = normalized.replace(/([.!?])([a-z])/g, '$1 $2');
  
  // Split into sentences and capitalize
  // Sentence boundary: . ! ? followed by space and letter, or end of string
  const sentenceRegex = /(^|[.!?]\s+)([a-z])/g;
  
  normalized = normalized.replace(sentenceRegex, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize the very first character
  if (normalized.length > 0) {
    normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  }
  
  // Clean up: remove multiple spaces again (might have been introduced)
  normalized = normalized.replace(/ +/g, ' ');
  
  return normalized;
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, ftp, and www URLs
  // Exclude trailing punctuation
  const urlRegex = /(https?:\/\/|ftp:\/\/|www\.)[^\s<>"'(){}|[\]\\^`]+[^\s<>"'(){}|[\]\\^`.,!?;:]/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing dots, commas, etc. that might have been included
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, schemeHost, path) => {
    // Always upgrade to https
    let newHost = 'https://example.com';
    
    // Check if path contains dynamic hints
    const dynamicHints = [
      '/cgi-bin', '?', '&', '=',
      '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'
    ];
    
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // Only rewrite host if path starts with /docs/ and no dynamic hints
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      newHost = 'https://docs.example.com';
    }
    
    return newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Feb allows 29 for leap years
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Special check for February on non-leap years
  if (month === 2 && day === 29) {
    // Check if it's a leap year
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  // Year should be reasonable (e.g., between 1000 and 9999)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  return yearStr;
}
