/**
 * Finds words in the text that start with the given prefix but excludes the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find words starting with the prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[A-Za-z]+)\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Create a Set of exceptions for efficient lookup
  const exceptionsSet = new Set(exceptions);
  
  // Filter out any exceptions from the matches
  return matches.filter(word => !exceptionsSet.has(word));
}

/**
 * Finds occurrences of a token that appear after a digit but not at the start of the string.
 * Uses lookaheads and lookbehinds to identify valid instances.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find the digit+token combination:
  // - Has a digit before it (captured)
  // - Is not at the start of the string
  const tokenPattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  while ((match = tokenPattern.exec(text)) !== null) {
    // Add the full match (digit + token) to our results array
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates passwords against strong security requirements.
 * Must be at least 10 characters with one uppercase, one lowercase, one digit, one symbol, no whitespace,
 * and no immediate repeated sequences (e.g., "abab" fails).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }
  
  // Check for whitespace characters
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences of 2 or more characters (e.g., "abab", "xyzxyz")
  // This catches sequences like "abab" where a pattern of 2 characters is repeated
  const repeatedSequencePattern = /(.{2,})\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation.
 * Ensures IPv4 addresses are not detected as IPv6.
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }
  
  // First check for IPv4 addresses and make sure this isn't one
  // Prevent false positives from IPv4 addresses
  const ipv4Pattern = /^(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Pattern to match IPv6 addresses:
  // 1. 8 groups of 1-4 hex digits separated by colons
  // 2. With optional :: shorthand notation for consecutive zeros
  // 3. Can have IPv4-mapped IPv6 addresses (but we need to exclude pure IPv4)
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  // Extract potential IPv6 addresses from the text
  const potentialIPv6Matches = value.match(/(::[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::|::|([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4})/g);
  
  if (!potentialIPv6Matches) {
    return false;
  }
  
  // Check each potential match
  for (const match of potentialIPv6Matches) {
    // If it looks like a pure IPv4 address, skip it
    if (ipv4Pattern.test(match)) {
      continue;
    }
    
    // Check if it's a valid IPv6 address
    if (ipv6Pattern.test(match)) {
      return true;
    }
  }
  
  return false;
}
