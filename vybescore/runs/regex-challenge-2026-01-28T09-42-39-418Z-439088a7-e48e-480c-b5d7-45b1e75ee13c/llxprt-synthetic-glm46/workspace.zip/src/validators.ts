export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex that:
  // - Allows letters, digits, periods, hyphens, plus signs in local part
  // - Rejects consecutive dots
  // - Rejects dots at start or end of local part
  // - Allows subdomains
  // - Rejects underscores in domain
  // - Requires valid domain ending
  const emailRegex = /^(?!.*\.{2})[a-zA-Z0-9][a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]*[a-zA-Z0-9]@(?:(?!.*\.{2})[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}$/;
  
  // Additional check to prevent underscores in domain
  if (value.includes('_') && value.split('@').length > 1 && value.split('@')[1].includes('_')) {
    return false;
  }
  
  // Check for trailing dot in local part or domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check for leading dot in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers with various formats and optional country code.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for extensions if allowed
  if (options?.allowExtensions) {
    const extensionPattern = /[#x]\d+$/;
    const withoutExtension = value.replace(extensionPattern, '');
    const digitsWithoutExtension = withoutExtension.replace(/\D/g, '');
    
    // If extension is present, validate the main part
    if (extensionPattern.test(value) && digitsOnly.length > 10) {
      // Main number should have exactly 11 digits (including country code) or 10 digits
      const mainDigitsWithoutExt = digitsWithoutExtension.match(/^\+?1?(\d{10})$/);
      if (mainDigitsWithoutExt) {
        return validateUSPhoneNumber(mainDigitsWithoutExt[1]);
      }
      return false;
    }
  }
  
  // Check for optional +1 country code
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    const tenDigitNumber = digitsOnly.slice(1);
    return validateUSPhoneNumber(tenDigitNumber);
  } else if (digitsOnly.length === 10) {
    return validateUSPhoneNumber(digitsOnly);
  } else if (digitsOnly.length === 0) {
    return false;
  }
  
  // If we reach here, the format is not valid
  return false;
}

/**
 * Helper function to validate the 10-digit US phone number format
 * Disallows area codes starting with 0 or 1
 */
function validateUSPhoneNumber(digits: string): boolean {
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code is the first 3 digits
  const areaCode = digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers in various formats.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must be 6-8 digits after area code
 * - When country code omitted, number must begin with trunk prefix 0
 * - Allow spaces/hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const normalized = value.replace(/[-\s]/g, '');
  
  // Regex pattern for Argentine phone numbers:
  // ^(?:\+54)?(?:(\d{0})9?|\d) - Optional +54 country code and optional 0 trunk prefix with optional 9
  // (\d{2,4}) - Area code (2-4 digits, leading digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const argentianPhoneRegex = /^(?:\+54)?(?:(0)|)(?:9)?(\d{2,4})(\d{6,8})$/;
  
  const match = normalized.match(argentianPhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, trunkPrefix, areaCode, subscriberNumber] = match;
  
  // Check area code rules: 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Check subscriber number length: 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // Additional rule: when country code is omitted, must have trunk prefix 0
  if (!normalized.startsWith('+54') && trunkPrefix !== '0') {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and styles like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Check if value is empty or only whitespace
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Name validation regex:
  // ^[A-Za-z\u00C0-\u024F] - Start with unicode letter (includes accented letters)
  // (?:[A-Za-z\u00C0-\u024F\s'-']*)$ - Followed by unicode letters, spaces, apostrophes, or hyphens
  const nameRegex = /^[A-Za-z\u00C0-\u024F](?:[A-Za-z\u00C0-\u024F\s'-']*)$/;
  
  // Check for disallowed characters (digits, symbols)
  const disallowedChars = /\d|[@#%&*+=<>$^!{}[\]()|\\/]/;
  if (disallowedChars.test(value)) {
    return false;
  }
  
  // Check for consecutive symbols (like '' or -- with other symbols between)
  if (/['-]{2,}|['-]\s+['-]|['-]$/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx prefixes and lengths.
 * Performs Luhn checksum validation for authenticity.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes from the card number
  const normalized = value.replace(/[\s-]/g, '');
  
  // Check if the normalized value contains only digits
  if (!/^\d+$/.test(normalized)) {
    return false;
  }
  
  // Check Visa: starts with 4, length 13 or 16
  if (normalized.startsWith('4') && (normalized.length === 13 || normalized.length === 16)) {
    return runLuhnCheck(normalized);
  }
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPrefixCheck = /^5[1-5]\d{0,}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{0,}|7(?:[01]\d{0,}|20\d{0,}))\d{0,}$/;
  if (mastercardPrefixCheck.test(normalized) && normalized.length === 16) {
    return runLuhnCheck(normalized);
  }
  
  // Check American Express: starts with 34 or 37, length 15
  if ((normalized.startsWith('34') || normalized.startsWith('37')) && normalized.length === 15) {
    return runLuhnCheck(normalized);
  }
  
  // No valid format matched
  return false;
}

/**
 * Performs Luhn checksum validation on credit card numbers.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  const length = value.length;
  const isEvenLength = length % 2 === 0;
  
  for (let i = 0; i < length; i++) {
    const digit = parseInt(value.charAt(i), 10);
    
    // If the current position is even for even-length cards, or odd for odd-length cards,
    // then double the digit.
    if ((isEvenLength && i % 2 === 0) || (!isEvenLength && i % 2 !== 0)) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
  }
  
  // The card is valid if the sum is a multiple of 10
  return sum % 10 === 0;
}
