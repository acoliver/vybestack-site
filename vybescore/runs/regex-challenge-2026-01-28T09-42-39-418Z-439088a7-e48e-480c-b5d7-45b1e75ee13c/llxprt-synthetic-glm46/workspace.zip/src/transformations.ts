/**
 * Capitalizes the first character of each sentence in the text.
 * Ensures proper spacing between sentences (exactly one space after sentence punctuation).
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim() === '') {
    return text;
  }
  
  // First, normalize the spacing to ensure consistent sentence boundaries
  // Replace multiple whitespace with single space
  const normalizedText = text.replace(/[ \t]+/g, ' ');
  
  // Ensure there's exactly one space after sentence punctuation 
  // when the next character is a letter or opening quote
  let processedText = normalizedText.replace(/([.?!])(?=\w)/g, '$1 ');
  
  // Replace spaces before sentence punctuation with no space
  processedText = processedText.replace(/ ([.?!])/g, '$1');
  
  // Capitalize the first letter of each sentence
  // This regex finds sentence boundaries (start of string or after .!?) 
  // followed by optional spaces and a letter
  processedText = processedText.replace(/(?:^|[.?!]\s+)([a-z])/g, (match, letter) => {
    return match.slice(0, -1) + letter.toUpperCase();
  });
  
  // Capitalize the very first character of the text
  if (processedText.length > 0) {
    processedText = processedText[0].toUpperCase() + processedText.slice(1);
  }
  
  return processedText;
}

/**
 * Extracts URLs found in the text.
 * Removes trailing punctuation like commas, periods, and parentheses.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // URL pattern that matches:
  // - http://, https:// protocols
  // - www. without protocol
  // - domain names with various TLDs
  // - paths, query strings, and fragments
  // - IPv4 addresses as alternatives
  const urlRegex = /(?:https?:\/\/|www\.)([^<> \t\r\n]+|https?:\/\/(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?:\/[^\s]*)?)/g;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up trailing punctuation for each match
  return matches.map(url => {
    // Remove trailing punctuation characters that are likely not part of the URL
    return url.replace(/[.,;:!?)}\]]+$/g, '');
  });
}

/**
 * Replaces all http:// URLs with https:// while preserving existing secure URLs.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Pattern to match http:// URLs but not https://
  const httpUrlRegex = /\bhttp:\/\//g;
  
  // Replace all http:// with https://
  return text.replace(httpUrlRegex, 'https://');
}

/**
 * Rewrites URLs for the example.com domain according to the following rules:
 * - Always upgrade http:// to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths containing cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // First, upgrade all http:// to https://
  const upgradedToHttps = enforceHttps(text);
  
  // Pattern to match URLs with the example.com domain
  const urlRegex = /(https:\/\/(?:www\.)?example\.com)(\/[^ \t\r\n]*)?/g;
  
  return upgradedToHttps.replace(urlRegex, (match, domain, path) => {
    if (!path) {
      return match; // Just a domain without path
    }
    
    // Check if we should skip the rewrite due to dynamic content
    const hasDynamicContent = /\/cgi-bin\/|(\?|&|=)/.test(path) || 
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/i.test(path);
    
    // If docs path but with dynamic content, only upgrade the scheme (which is already done)
    if (path.startsWith('/docs/') && hasDynamicContent) {
      return match;
    }
    
    // If docs path without dynamic content, rewrite the host
    if (path.startsWith('/docs/') && !hasDynamicContent) {
      return 'https://docs.example.com' + path;
    }
    
    // Otherwise, keep as is (scheme already upgraded)
    return match;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy date strings.
 * Returns 'N/A' if the format doesn't match or if month/day is invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Pattern to match mm/dd/yyyy format and capture month, day, year
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.trim().match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Convert to integers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day based on month and leap year
  const daysInMonth = [
    31, // January
    (yearNum % 4 === 0 && (yearNum % 100 !== 0 || yearNum % 400 === 0)) ? 29 : 28, // February (with leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (dayNum < 1 || dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  // Valid date, return the year
  return year;
}
