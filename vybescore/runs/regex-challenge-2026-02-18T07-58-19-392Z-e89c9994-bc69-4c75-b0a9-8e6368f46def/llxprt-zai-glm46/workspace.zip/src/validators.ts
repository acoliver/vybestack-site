export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like user@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Main email pattern: local@domain.tld
  // Local part: alphanumeric, dots, hyphens, plus, underscores (but not consecutive dots or leading/trailing)
  // Domain: alphanumeric and hyphens only (no underscores), proper TLD
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@(?!-)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?<!-)$/;
  
  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for underscore in domain
  const [local, domain] = value.split('@');
  if (domain.includes('_')) {
    return false;
  }
  
  // Check local part doesn't start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Check domain part doesn't start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters to get core number
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits for US numbers)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let coreNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    coreNumber = digitsOnly.slice(1);
  } else if (digitsOnly.length > 11) {
    // Too long even with country code
    return false;
  }
  
  // Must be exactly 10 digits for the core number
  if (coreNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = coreNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Central office code (next 3 digits) cannot start with 0 or 1
  const centralOffice = coreNumber.substring(3, 6);
  if (centralOffice[0] === '0' || centralOffice[0] === '1') {
    return false;
  }
  
  // Optional: allow extensions if specified in options
  if (options?.allowExtensions) {
    const extMatch = value.match(/ext\.?\s*(\d+)/i);
    if (extMatch && extMatch[1]) {
      // Extension is valid, don't affect core validation
    }
  }
  
  // Check that the format matches one of the accepted patterns
  // These patterns allow: (###) ###-####, ###-###-####, ##########, +1 variants
  const pattern = /^\+?1?\s*\(?\d{3}\)?[-\s]?\d{3}[-\s]?\d{4}$/;
  return pattern.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - Without country code, must begin with trunk prefix 0
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep track of structure
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it has country code
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  
  // Different patterns for with/without country code
  let basePattern: RegExp;
  
  if (hasCountryCode) {
    // With country code: +54 [9] [0] area_code subscriber
    // Trunk prefix (0) is optional when country code is present
    basePattern = /^\+?54(?:9)?0?[1-9]\d{1,3}\d{6,8}$/;
  } else {
    // Without country code: Must have trunk prefix 0
    basePattern = /^0[1-9]\d{1,3}\d{6,8}$/;
  }
  
  if (!basePattern.test(cleaned)) {
    return false;
  }
  
  // Extract the number without +54
  let mainNumber = cleaned;
  if (mainNumber.startsWith('+')) {
    mainNumber = mainNumber.slice(1);
  }
  if (mainNumber.startsWith('54')) {
    mainNumber = mainNumber.slice(2);
  }
  
  // Check for mobile indicator (9) after country code
  if (mainNumber.startsWith('9')) {
    mainNumber = mainNumber.slice(1);
  }
  
  // Check for trunk prefix (0)
  const hasTrunkPrefix = mainNumber.startsWith('0');
  if (hasTrunkPrefix) {
    mainNumber = mainNumber.slice(1);
  }
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Extract area code (2-4 digits starting with 1-9)
  const areaCodeMatch = mainNumber.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Remaining digits are subscriber number (6-8 digits)
  const subscriberNumber = mainNumber.slice(areaCode.length);
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and invalid combinations like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Allow:
  // - Unicode letters (\p{L}) including accented characters
  // - Apostrophes for names like O'Connor
  // - Hyphens for hyphenated names
  // - Spaces for multiple names
  // Must contain at least one letter and not be empty
  const namePattern = /^[\p{L}][\p{L}'\s-]*[\p{L}]$/u;
  
  if (!namePattern.test(value.trim())) {
    return false;
  }
  
  // Additional check: reject if contains digits or other symbols
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject common symbol characters that shouldn't be in names
  const forbiddenSymbols = /[!@#$%^&*()_+=[\]{};:"\\|<>,./°£¥€©®™]/;
  if (forbiddenSymbols.test(value)) {
    return false;
  }
  
  // Must have at least 2 characters and contain at least one letter
  if (value.trim().length < 2 || !/[\p{L}]/u.test(value)) {
    return false;
  }
  
  // Check for consecutive apostrophes or hyphens (not valid in names)
  if (/''|--/.test(value)) {
    return false;
  }
  
  // Name should not start or end with apostrophe, hyphen, or space
  const trimmed = value.trim();
  if (/^['\s-]/.test(trimmed) || /['\s-]$/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function: Run Luhn checksum on a card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length: typically 13-19 digits
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Define card patterns (prefix, length)
  // Visa: starts with 4, length 13, 16, or 19
  const visaPattern = /^4\d{12}(\d{3}(\d{3})?)?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardPattern = /^(?:5[1-5]\d{2}|2[2-7][0-9]{2})\d{12}$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if matches any card type
  const isValidFormat = visaPattern.test(cleaned) || 
                        mastercardPattern.test(cleaned) || 
                        amexPattern.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
