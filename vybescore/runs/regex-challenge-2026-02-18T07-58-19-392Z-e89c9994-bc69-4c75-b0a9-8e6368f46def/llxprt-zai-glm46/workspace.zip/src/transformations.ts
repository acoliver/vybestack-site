/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after . ? !
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces sensibly
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces to one
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Ensure exactly one space after sentence-ending punctuation
  // Look for punctuation followed by optional space then letter
  normalized = normalized.replace(/([.!?])\s*([a-z])/g, '$1 $2');
  
  // Common abbreviations that shouldn't trigger capitalization
  // These are checked by looking back to see if we're after a known abbreviation
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Sen', 'Rep', 'Gov', 'Lt', 'Col', 'Sgt', 'Capt', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'eg', 'ie', 'vs', 'approx', 'dept'];
  
  // Capitalize first letter of the text
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence-ending punctuation
  // But NOT after abbreviations
  let result = '';
  let i = 0;
  
  while (i < normalized.length) {
    result += normalized[i];
    
    // Check if we just hit sentence-ending punctuation
    if (normalized[i] === '.' || normalized[i] === '!' || normalized[i] === '?') {
      // Look ahead to see if we have an abbreviation pattern
      // Check the word before the punctuation
      let j = result.length - 2;
      while (j >= 0 && /\w/.test(result[j])) {
        j--;
      }
      const wordBefore = result.slice(j + 1, result.length - 1);
      
      // If it's not a common abbreviation, capitalize the next letter
      if (!abbreviations.includes(wordBefore) && i + 1 < normalized.length) {
        // Skip any whitespace
        let k = i + 1;
        while (k < normalized.length && /\s/.test(normalized[k])) {
          k++;
        }
        
        // Capitalize the next letter
        if (k < normalized.length) {
          result += normalized.slice(i + 1, k) + normalized[k].toUpperCase();
          i = k;
        }
      }
    }
    
    i++;
  }
  
  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL pattern
  // Matches http://, https://, and www. URLs
  // Does NOT include trailing punctuation
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>]+[^\s<>".,!?:;(){}[\]]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Further clean up: remove trailing punctuation that might have been caught
  const cleaned = matches.map(url => {
    // Remove trailing punctuation characters
    return url.replace(/[.,!?:;(){}[\]]+$/, '');
  });
  
  return cleaned;
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https:// (to avoid double replacement)
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite docs URLs.
 * For URLs from http://example.com/...:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should skip host rewrite
    // Skip for: cgi-bin, query strings, legacy extensions
    const skipHostRewrite = /\/cgi-bin\b|[?&=]|(\/)(jsp|php|asp|aspx|do|cgi|pl|py)(\/|\?|$)/i.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    if (isDocsPath && !skipHostRewrite) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade the scheme, keep original host
      return newScheme + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
