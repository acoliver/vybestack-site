/**
 * Find words starting with the given prefix, excluding specified exceptions.
 * Uses word boundaries to ensure we match whole words only.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  // \b ensures word boundaries
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filtered = matches.filter(word => 
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );
  
  // Return unique words
  return [...new Set(filtered)];
}

/**
 * Find occurrences of a token only when it appears after a digit.
 * Does not match at the start of the string.
 * Returns the full match including the digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token
  // This captures the digit+token combination
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?`~]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc)
  // This pattern captures a 2-4 character sequence and checks if it repeats
  const repeatedSequencePattern = /(.{2,4})\1{1,}/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand :: notation).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern with support for :: shorthand
  // This is a simplified but comprehensive pattern
  // Matches:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed: 2001:db8::1
  // - Mixed IPv4 (last 32 bits): ::ffff:192.168.1.1
  // Does NOT match pure IPv4 addresses
  
  // First, check if it's a pure IPv4 address (to exclude)
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Simpler approach: Look for colons and hex patterns typical of IPv6
  // Must have at least one colon
  if (!value.includes(':')) {
    return false;
  }
  
  // Check for IPv6-like structure
  // Multiple groups of hex separated by colons, possibly with ::
  const hasMultipleColons = value.split(':').length >= 3;
  const hasCompression = value.includes('::');
  const hasHexGroups = /^[0-9a-fA-F:]+$/.test(value);
  
  if (hasMultipleColons || hasCompression) {
    if (hasHexGroups) {
      // Additional check: must have enough hex groups to be IPv6
      const groups = value.split(':').filter(g => g.length > 0);
      if (groups.length >= 2 || hasCompression) {
        // Make sure it's not just a single colon or malformed
        if (value.match(/^[0-9a-fA-F:]+$/) && (groups.length >= 3 || hasCompression)) {
          return true;
        }
      }
    }
  }
  
  // More precise IPv6 pattern
  // Simplified: looks for valid IPv6 structures
  const ipv6SimplePattern = /([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|::1?|::/;
  
  return ipv6SimplePattern.test(value);
}
