import { describe, expect, it, beforeAll, afterAll } from "vitest";
import request from "supertest";
import * as cheerio from "cheerio";
import fs from "node:fs";
import path from "node:path";
import type { Express } from "express";

let server: ReturnType<Express["listen"]>;
let app: Express;
const dbPath = path.resolve("data", "submissions.sqlite");

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and start the server from dist directory (CommonJS require)
  const serverModule = await import("../../dist/server.js");
  app = serverModule.default;
  server = app.listen(0); // Use port 0 to find any available port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  // Clean up database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe("friendly form (public smoke)", () => {
  it("renders the form with all fields", async () => {
    const response = await request(app).get("/");
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($("title").text()).toBe("Friendly Contact Form");
    
    // Check for all form fields
    const expectedFields = [
      "firstName", "lastName", "streetAddress", "city", 
      "stateProvinceRegion", "postalZipCode", "country", "email", "phoneNumber"
    ];
    
    expectedFields.forEach((field: string) => {
      expect($(`input[name="${field}"]`).length).toBe(1);
      expect($(`label[for="${field}"]`).length).toBe(1);
    });
  });

  it("persists submission and redirects", async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const validSubmission = {
      firstName: "John",
      lastName: "Doe",
      streetAddress: "123 Main St",
      city: "Anytown",
      stateProvinceRegion: "State",
      postalZipCode: "12345",
      country: "USA",
      email: "john@example.com",
      phoneNumber: "+1-555-123-4567"
    };
    
    const response = await request(app)
      .post("/submit")
      .send(validSubmission)
      .expect(302);
    
    expect(response.headers.location).toBe("/thank-you");
    
    // Verify database was created and contains the submission
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it("shows validation errors on invalid submission", async () => {
    const invalidSubmission = {
      firstName: "",
      lastName: "Doe",
      streetAddress: "123 Main St",
      city: "Anytown",
      stateProvinceRegion: "State",
      postalZipCode: "12345",
      country: "USA",
      email: "invalid-email", // Invalid email
      phoneNumber: "123" // Too short
    };
    
    const response = await request(app)
      .post("/submit")
      .send(invalidSubmission);
    
    expect(response.status).toBe(400);
    expect(response.text).toContain("firstName");
    expect(response.text).toContain("email");
    expect(response.text).toContain("phoneNumber");
  });

  it("renders thank you page", async () => {
    const response = await request(app).get("/thank-you");
    expect(response.status).toBe(200);
    expect(response.text).toContain("Thank you!");
    expect(response.text).toContain("stranger on the internet");
  });
});