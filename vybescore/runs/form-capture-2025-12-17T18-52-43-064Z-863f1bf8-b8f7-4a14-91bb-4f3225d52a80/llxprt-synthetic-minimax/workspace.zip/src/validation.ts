export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhoneNumber(phone: string): boolean {
  // Accept international formats with digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s()_-]+$/;
  if (!phoneRegex.test(phone)) {
    return false;
  }
  
  // Must have at least 7 digits total
  const digitCount = phone.replace(/[^\d]/g, "").length;
  return digitCount >= 7;
}

export function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings, minimum 3 characters
  const postalRegex = /^[a-zA-Z0-9\s_-]{3,15}$/;
  return postalRegex.test(postalCode.trim());
}

export function validateFormData(data: FormData): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    "firstName", "lastName", "streetAddress", "city", 
    "stateProvinceRegion", "postalZipCode", "country", "email", "phoneNumber"
  ];

  requiredFields.forEach(field => {
    const value = data[field]?.trim();
    if (!value) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, " $1").toLowerCase()} is required`
      });
    }
  });

  // Email validation
  if (data.email && data.email.trim()) {
    if (!validateEmail(data.email)) {
      errors.push({
        field: "email",
        message: "Please enter a valid email address"
      });
    }
  }

  // Phone number validation
  if (data.phoneNumber && data.phoneNumber.trim()) {
    if (!validatePhoneNumber(data.phoneNumber)) {
      errors.push({
        field: "phoneNumber",
        message: "Please enter a valid phone number"
      });
    }
  }

  // Postal code validation
  if (data.postalZipCode && data.postalZipCode.trim()) {
    if (!validatePostalCode(data.postalZipCode)) {
      errors.push({
        field: "postalZipCode",
        message: "Please enter a valid postal/zip code"
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}
