import express, { Request, Response, NextFunction } from "express";
import * as path from "path";
import DatabaseService, { FormSubmission } from "./database";
import { validateFormData, FormData, ValidationResult } from "./validation";

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Initialize database service
const dbService = new DatabaseService();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, "../public")));

// Set EJS as view engine
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "../views"));

// Interface for request body
interface FormRequestBody {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

// Interface for template context
interface TemplateContext {
  formData?: FormData;
  errors?: Array<{ field: string; message: string }>;
  hasErrors?: boolean;
}

// GET / - Render the contact form
app.get("/", (req: Request, res: Response) => {
  const context: TemplateContext = {
    hasErrors: false
  };
  res.render("form", context);
});

// POST /submit - Handle form submission
app.post("/submit", async (req: Request<unknown, unknown, FormRequestBody>, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || "",
      lastName: req.body.lastName || "",
      streetAddress: req.body.streetAddress || "",
      city: req.body.city || "",
      stateProvinceRegion: req.body.stateProvinceRegion || "",
      postalZipCode: req.body.postalZipCode || "",
      country: req.body.country || "",
      email: req.body.email || "",
      phoneNumber: req.body.phoneNumber || ""
    };

    const validationResult: ValidationResult = validateFormData(formData);

    if (!validationResult.isValid) {
      const context: TemplateContext = {
        formData,
        errors: validationResult.errors,
        hasErrors: true
      };
      res.status(400).render("form", context);
      return;
    }

    // Insert into database
    const submission: FormSubmission = {
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      streetAddress: formData.streetAddress.trim(),
      city: formData.city.trim(),
      stateProvinceRegion: formData.stateProvinceRegion.trim(),
      postalZipCode: formData.postalZipCode.trim(),
      country: formData.country.trim(),
      email: formData.email.trim(),
      phoneNumber: formData.phoneNumber.trim()
    };

    await dbService.insertSubmission(submission);

    // Redirect to thank you page
    res.redirect(302, "/thank-you");
  } catch (error) {
    next(error);
  }
});

// GET /thank-you - Thank you page
app.get("/thank-you", (req: Request, res: Response) => {
  res.render("thank-you");
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Error occurred:', err);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown
process.on("SIGTERM", async () => {
  console.log("SIGTERM received, shutting down gracefully");
  await dbService.close();
  process.exit(0);
});

process.on("SIGINT", async () => {
  console.log("SIGINT received, shutting down gracefully");
  await dbService.close();
  process.exit(0);
});

// Start server
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

export default app;