import initSqlJs, { Database } from "sql.js";
import * as fs from "fs";
import * as path from "path";

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface SubmissionWithId extends FormSubmission {
  id: number;
  createdAt: string;
}

class DatabaseService {
  private db!: Database;
  private dbFilePath: string;
  private schemaPath: string;
  private initialized: boolean = false;

  constructor(dbFilePath = "./data/submissions.sqlite", schemaPath = "./db/schema.sql") {
    this.dbFilePath = dbFilePath;
    this.schemaPath = schemaPath;
  }

  private async initialize(): Promise<void> {
    if (this.initialized) {
      return;
    }

    const SQL = await initSqlJs({
      locateFile: () => {
        return path.join(process.cwd(), "node_modules/sql.js/dist/sql-wasm.wasm");
      }
    });
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbFilePath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    if (fs.existsSync(this.dbFilePath)) {
      // Load existing database
      const buffer = fs.readFileSync(this.dbFilePath);
      this.db = new SQL.Database(buffer);
    } else {
      // Create new database
      this.db = new SQL.Database();
      this.runSchema();
      this.saveDatabase();
    }

    this.initialized = true;
  }

  private runSchema(): void {
    const schema = fs.readFileSync(this.schemaPath, "utf8");
    const statements = schema.split(";").filter(stmt => stmt.trim());
    
    statements.forEach(statement => {
      if (statement.trim()) {
        this.db.run(statement.trim());
      }
    });
  }

  private saveDatabase(): void {
    const buffer = this.db.export();
    fs.writeFileSync(this.dbFilePath, Buffer.from(buffer));
  }

  public async insertSubmission(submission: FormSubmission): Promise<number> {
    await this.initialize();

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalZipCode,
      submission.country,
      submission.email,
      submission.phoneNumber
    ]);

    stmt.free();
    this.saveDatabase();

    // Get the last insert ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  }

  public async getAllSubmissions(): Promise<SubmissionWithId[]> {
    await this.initialize();

    const stmt = this.db.prepare(`
      SELECT id, first_name, last_name, street_address, city, 
             state_province_region, postal_zip_code, country, 
             email, phone_number, created_at
      FROM submissions
      ORDER BY created_at DESC
    `);

    const submissions: SubmissionWithId[] = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject() as Record<string, unknown>;
      submissions.push({
        id: row.id as number,
        firstName: row.first_name as string,
        lastName: row.last_name as string,
        streetAddress: row.street_address as string,
        city: row.city as string,
        stateProvinceRegion: row.state_province_region as string,
        postalZipCode: row.postal_zip_code as string,
        country: row.country as string,
        email: row.email as string,
        phoneNumber: row.phone_number as string,
        createdAt: row.created_at as string
      });
    }
    
    stmt.free();
    return submissions;
  }

  public async close(): Promise<void> {
    if (this.initialized && this.db) {
      this.saveDatabase();
      this.db.close();
      this.initialized = false;
    }
  }
}

export default DatabaseService;