import express, { Request, Response } from 'express';
import { promises as fs } from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

// Get current directory for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Type declarations for sql.js to avoid import issues
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Import sql.js types
import * as SQL from 'sql.js';

class Database {
  private db: SQL.Database | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.resolve('data', 'submissions.sqlite');
  }

  async init(): Promise<void> {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    await fs.mkdir(dataDir, { recursive: true });

    // Import sql.js dynamically
    const { default: initSqlJs } = await import('sql.js');
    // Initialize sql.js without custom locateFile to use default paths
    const SQL = await initSqlJs();

    // Load existing database or create new one
    let dbBuffer: Uint8Array | null = null;
    try {
      const dbFile = await fs.readFile(this.dbPath);
      dbBuffer = new Uint8Array(dbFile);
    } catch (error) {
      // Database doesn't exist yet, that's okay
    }

    this.db = new SQL.Database(dbBuffer || undefined);

    // Create schema if needed
    try {
      const schema = await fs.readFile(path.resolve(__dirname, '../../db/schema.sql'), 'utf8');
      if (this.db && schema) {
        // Execute the schema as a single statement
        this.db.run(schema);
      }
    } catch (error) {
      console.error('Error reading schema file:', error);
    }
  }

  async saveSubmission(formData: FormData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    
    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    await this.exportDatabase();
  }

  async exportDatabase(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');
    const data = this.db.export();
    await fs.writeFile(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

class FormValidator {
  static validate(formData: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!formData[field] || formData[field].trim() === '') {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    }

    // Email validation
    if (formData.email && !this.isValidEmail(formData.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    // Phone validation
    if (formData.phone && !this.isValidPhone(formData.phone)) {
      errors.push({
        field: 'phone',
        message: 'Please enter a valid phone number'
      });
    }

    // Postal code validation (alphanumeric allowed)
    if (formData.postalCode && !this.isValidPostalCode(formData.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Postal code can only contain letters and numbers'
      });
    }

    return errors;
  }

  private static getFieldDisplayName(field: keyof FormData): string {
    const names: Record<keyof FormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return names[field];
  }

private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email.trim());
  }

private static isValidPhone(phone: string): boolean {
    const phoneRegex = /^\+?[0-9\s\-\(\)]+$/;
    return phoneRegex.test(phone.trim());
  }

  private static isValidPostalCode(postalCode: string): boolean {
    const postalRegex = /^[a-zA-Z0-9\s\-]+$/;
    return postalRegex.test(postalCode.trim());
  }

}

class FormServer {
  private app: express.Application;
  private database: Database;

  constructor() {
    this.app = express();
    this.database = new Database();
    this.setupMiddleware();
    this.setupRoutes();
    this.setupGracefulShutdown();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static('public'));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private setupRoutes(): void {
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    this.app.post('/submit', async (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      const errors = FormValidator.validate(formData);

      if (errors.length > 0) {
        res.status(400).render('form', {
          errors: errors.map(e => e.message),
          values: formData
        });
        return;
      }

      // Save to database
      await this.database.saveSubmission(formData);

      // Redirect to thank you page
      res.redirect('/thank-you');
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      res.render('thank-you', {
        firstName: 'Friend' // Default since we're not storing session data
      });
    });
  }

  private setupGracefulShutdown(): void {
    const shutdown = () => {
      console.log('Shutting down gracefully...');
      this.database.close();
      process.exit(0);
    };

    process.on('SIGTERM', shutdown);
    process.on('SIGINT', shutdown);
  }

  async start(): Promise<void> {
    await this.database.init();
    const port = process.env.PORT || 3535;
    this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }
}

// Start the server
async function main() {
  const server = new FormServer();
  await server.start();
}

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  process.exit(1);
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  process.exit(1);
});

// Start the application
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export for testing
export { Database, FormValidator, FormServer };