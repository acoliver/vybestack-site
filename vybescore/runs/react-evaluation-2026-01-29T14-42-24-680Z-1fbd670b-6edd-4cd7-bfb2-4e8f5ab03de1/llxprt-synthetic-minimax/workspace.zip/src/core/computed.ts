/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Store the computed value evaluation
  const evaluate = () => {
    // Call the update function which will read other reactive values
    // and track them as dependencies
    const result = updateFn(value)
    return result
  }
  
  // Getter function that computes and returns the value
  const getter: GetterFn<T> = () => {
    // Call update function to get current value
    o.value = evaluate() 
    return o.value!
  }
  
  // Initial computation
  updateObserver(o)
  
  return getter
}
