/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64 data.
 */
export function decode(input: string): string {
  // Check for basic validity - Base64 should only contain these characters
  
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }
  
  const trimmed = input.trim();
  
  // Check for non-Base64 characters
  if (!/^[A-Za-z0-9+/=]+$/.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check for invalid padding patterns
  const paddingMatches = trimmed.match(/=/g) || [];
  const paddingCount = paddingMatches.length;
  
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
  
  // If there's padding, it can only be at the end
  if (paddingCount > 0 && !/=+$/.test(trimmed)) {
    throw new Error('Invalid Base64 input: padding must be at the end');
  }
  
  try {
    return Buffer.from(trimmed, 'base64').toString('utf8');
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
