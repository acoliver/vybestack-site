#!/usr/bin/env node

import fs from 'fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): { dataPath: string; options: CliOptions } {
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[2];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    if (args[i] === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      if (args[i] !== 'markdown' && args[i] !== 'text') {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      format = args[i] as 'markdown' | 'text';
    } else if (args[i] === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[i];
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataPath,
    options: {
      format,
      outputPath,
      includeTotals,
    },
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid "amount" field (expected number)`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

function loadReportData(path: string): ReportData {
  try {
    const content = fs.readFileSync(path, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${path}: ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error && error.message.startsWith('Invalid JSON:')) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: ${path}`);
      process.exit(1);
    }
    console.error(`Error: Failed to read file ${path}: ${error}`);
    process.exit(1);
  }
}

function main() {
  const { dataPath, options } = parseArguments(process.argv);
  const data = loadReportData(dataPath);

  const renderOptions: RenderOptions = {
    includeTotals: options.includeTotals,
  };

  const output =
    options.format === 'markdown'
      ? renderMarkdown.render(data, renderOptions)
      : renderText.render(data, renderOptions);

  if (options.outputPath) {
    try {
      fs.writeFileSync(options.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to ${options.outputPath}: ${error}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
