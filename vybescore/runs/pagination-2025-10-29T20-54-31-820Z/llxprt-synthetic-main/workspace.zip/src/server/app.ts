import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(pageParam?: string, limitParam?: string) {
  let page = 1;
  let limit = 5;

  if (pageParam) {
    const parsed = Number(pageParam);
    if (isNaN(parsed) || parsed < 1 || !Number.isInteger(parsed)) {
      throw new Error('Page must be a positive integer');
    }
    page = parsed;
  }

  if (limitParam) {
    const parsed = Number(limitParam);
    if (isNaN(parsed) || parsed < 1 || parsed > 100 || !Number.isInteger(parsed)) {
      throw new Error('Limit must be a positive integer not exceeding 100');
    }
    limit = parsed;
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const { page, limit } = validatePaginationParams(
        req.query.page as string | undefined,
        req.query.limit as string | undefined
      );

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid request';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
