import { useCallback, useEffect, useState } from 'react';
import type { InventoryPage, InventoryState } from '../shared/types';

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number) {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  const load = useCallback(async () => {
    let cancelled = false;
    
    setState((prev) => ({ ...prev, status: 'loading', error: null }));
    try {
      // Include page and limit in the query string
      const url = `/inventory?page=${page}&limit=${limit}`;
      const response = await fetch(url);
      
      if (!response.ok) {
        if (response.status === 400) {
          const errorData = await response.json();
          throw new Error(errorData.error);
        }
        throw new Error(`Request failed with status ${response.status}`);
      }
      const payload = (await response.json()) as InventoryPage;
      if (!cancelled) {
        setState({ status: 'ready', data: payload, error: null });
      }
    } catch (error) {
      if (!cancelled) {
        const message = error instanceof Error ? error.message : 'Unknown error';
        setState({ status: 'error', data: null, error: message });
      }
    }

    return () => {
      cancelled = true;
    };
  }, [page, limit]);

  useEffect(() => {
    load();
  }, [load]);

  return { ...state, refetch: load };
}
