export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with regex.
 * Accepts typical addresses like user@example.com, user.name@tag.example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows letters, digits, dots, hyphens, underscores, percent, plus in local part
  // - Rejects consecutive dots, leading/trailing dots in local part
  // - Requires valid domain with letters, digits, hyphens
  // - Rejects underscores in domain
  // - Allows multiple subdomains and TLDs (at least 2 chars)
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for patterns that are hard to express in a single regex
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local part or domain
  const [local, domain] = value.split('@');
  if (local.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with regex.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all whitespace and common separators except +1 prefix
  const cleaned = value.replace(/[\s()\-._]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    // Handle case where 1 is country code without +
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits for US numbers
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Handle extensions if allowed
  if (options?.allowExtensions) {
    const extensionMatch = value.match(/ext\.?\s*\d+/i);
    if (extensionMatch) {
      // Valid extension format
      return true;
    }
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers with regex.
 * Supports landlines and mobiles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0
 * - Allows single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // - Optional +54 country code
  // - Optional 0 trunk prefix (required if no country code)
  // - Optional 9 mobile indicator
  // - Area code: 2-4 digits starting with 1-9
  // - Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?[9]?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract components for validation
  let remaining = cleaned;
  let hasCountryCode = false;
  
  if (remaining.startsWith('+54')) {
    hasCountryCode = true;
    remaining = remaining.slice(3);
  }
  
  // Check trunk prefix rules
  if (remaining.startsWith('0')) {
    remaining = remaining.slice(1);
  } else if (!hasCountryCode) {
    // If no country code, trunk prefix is required
    return false;
  }
  
  // Check optional mobile indicator
  if (remaining.startsWith('9')) {
    remaining = remaining.slice(1);
  }
  
  // Extract area code (2-4 digits starting with 1-9)
  if (remaining.length < 8) {
    return false; // Too short for area + subscriber
  }
  
  // Area code is 2-4 digits
  let areaCodeLength = 2;
  if (remaining.length >= 10) {
    areaCodeLength = 4;
  } else if (remaining.length >= 9) {
    areaCodeLength = 3;
  }
  
  const areaCode = remaining.slice(0, areaCodeLength);
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number is the rest
  const subscriber = remaining.slice(areaCodeLength);
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  if (!/^\d+$/.test(subscriber)) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names with regex.
 * Permits: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Name regex:
  // - Must start with a letter (unicode supported)
  // - Allows letters, accents, apostrophes, hyphens, spaces
  // - Rejects digits, special symbols, and purely numeric combinations
  // - At least 2 characters
  // - Cannot be just special characters
  const nameRegex = /^[\p{L}][\p{L}'\-\s]*[\p{L}]$/u;
  
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Check for minimum length (at least 2 characters)
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject names that contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with multiple consecutive special characters
  if (/'-|'-|''|--/.test(value)) {
    return false;
  }
  
  // Reject names with unusual symbols (beyond apostrophe and hyphen)
  const symbolPattern = /[^\p{L}'\s-]/u;
  if (symbolPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function: Run Luhn algorithm checksum on credit card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers with regex and Luhn checksum.
 * Accepts: Visa (13-16 digits, starts with 4), Mastercard (16 digits, starts with 51-55 or 2221-2720), 
 *          AmEx (15 digits, starts with 34 or 37)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12,15}$/;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  const validFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
