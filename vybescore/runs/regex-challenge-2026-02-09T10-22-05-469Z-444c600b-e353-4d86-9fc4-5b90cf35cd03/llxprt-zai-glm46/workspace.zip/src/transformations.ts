/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after sentence-ending punctuation (.?!)
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around punctuation
  let result = text;
  
  // Add space after sentence endings if missing (but not for abbreviations)
  // Look for punctuation followed by a letter (not preceded by common abbreviations)
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Collapse multiple spaces into one
  result = result.replace(/[ \t]+/g, ' ');
  
  // Capitalize first letter of text
  result = result.replace(/^[a-z]/, (match) => match.toUpperCase());
  
  // Capitalize after sentence endings
  // Use negative lookbehind to avoid common abbreviations
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'eg', 'ie', 'vs', 'Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  
  // Capitalize after .!? but not after abbreviations
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    // Check if this is an abbreviation
    const beforePunct = result.substring(0, result.indexOf(match) + prefix.length - 1);
    const lastWordMatch = beforePunct.match(/(\w+)\.$/);
    
    if (lastWordMatch) {
      const lastWord = lastWordMatch[1];
      if (abbreviations.includes(lastWord)) {
        return prefix + letter; // Don't capitalize
      }
    }
    return prefix + letter.toUpperCase();
  });
  
  return result;
}

/**
 * Extract URLs from text.
 * Returns all URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http:// or https:// followed by domain and path
  // Excludes trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::\d+)?(?:\/(?:[-\w.~!$&'()*+,;=:@%]|(?<!.)\.(?!\.))*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation (. , ; : ! ?)
    return url.replace(/[.,;:!?\s]+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/[/]/gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    let newHost = host;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for exclusion patterns
      const hasCgiBin = path.includes('/cgi-bin/');
      const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
      const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i.test(path);
      
      // Only rewrite host if no exclusion patterns
      if (!hasCgiBin && !hasQueryString && !hasLegacyExtension) {
        newHost = host.replace(/^example\.com/i, 'docs.example.com');
      }
    }
    
    return newScheme + newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  // Return the year
  return yearStr;
}
