#!/usr/bin/env node

import fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  let format: 'markdown' | 'text' = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      const formatArg = args[i];
      if (formatArg !== 'markdown' && formatArg !== 'text') {
        console.error('Error: Unsupported format. Supported formats: markdown, text');
        process.exit(1);
      }
      format = formatArg;
    } else if (arg === '--output') {
      i++;
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (!data || typeof data !== 'object') {
    return false;
  }

  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    return false;
  }
  
  if (typeof reportData.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(reportData.entries)) {
    return false;
  }
  
  for (const entry of reportData.entries) {
    if (!entry || typeof entry !== 'object') {
      return false;
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (typeof entryRecord.label !== 'string') {
      return false;
    }
    
    if (typeof entryRecord.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

function main() {
  try {
    const args = parseArgs(process.argv);
    
    // Read and parse the JSON file
    let rawData: unknown;
    try {
      const fileContent = fs.readFileSync(args.dataFile, 'utf8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${args.dataFile}`);
      } else {
        console.error(`Error: Could not read file ${args.dataFile}`);
      }
      process.exit(1);
    }
    
    // Validate the data structure
    if (!validateReportData(rawData)) {
      console.error(`Error: Invalid report data structure in file ${args.dataFile}`);
      console.error('Expected format: { title: string, summary: string, entries: { label: string, amount: number }[] }');
      process.exit(1);
    }
    
    const reportData = rawData as ReportData;
    const options: RenderOptions = { includeTotals: args.includeTotals };
    
    // Render the report
    let output: string;
    if (args.format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else {
      output = renderText(reportData, options);
    }
    
    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf8');
      console.log(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error('Unexpected error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();