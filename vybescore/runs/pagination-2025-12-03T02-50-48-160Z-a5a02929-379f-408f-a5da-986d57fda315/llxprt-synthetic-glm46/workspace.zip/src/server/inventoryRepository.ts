import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // Use provided values or defaults
  const page = options.page ?? 1;
  const limit = options.limit ?? DEFAULT_LIMIT;

  // Fixed offset calculation: (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare('SELECT * FROM inventory ORDER BY id LIMIT ? OFFSET ?');
  stmt.bind([limit, offset]);
  const items: InventoryItem[] = [];

  while (stmt.step()) {
    const row = stmt.getAsObject();
    items.push(mapRow(row));
  }
  stmt.free();

  // Calculate if there's a next page
  const hasNext = offset + items.length < total;

  return {
    items,
    page,
    limit,
    total,
    hasNext
  };
}