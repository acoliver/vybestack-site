import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';

console.log('Testing pagination functionality...');

async function testPagination() {
  try {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Start the server
    const server = app.listen(3336, () => {
      console.log('Test server running on port 3336');
    });
    
    // Wait for server to start
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    try {
      // Test default values
      const response1 = await fetch('http://localhost:3336/inventory');
      const data1 = await response1.json();
      console.log('Default (page=1, limit=5):');
      console.log(`Items: ${data1.items.length}`);
      console.log(`Page: ${data1.page}, Limit: ${data1.limit}, Total: ${data1.total}, HasNext: ${data1.hasNext}`);
      console.log(`First item ID: ${data1.items[0]?.id}`);
      console.log(`Last item ID: ${data1.items[data1.items.length-1]?.id}`);
      
      // Test page 2
      const response2 = await fetch('http://localhost:3336/inventory?page=2');
      const data2 = await response2.json();
      console.log('\nPage 2:');
      console.log(`Items: ${data2.items.length}`);
      console.log(`Page: ${data2.page}, Limit: ${data2.limit}, Total: ${data2.total}, HasNext: ${data2.hasNext}`);
      
      // Check pagination works correctly - first item in page 2 should have ID 6 if pagination is working
      if (data2.items[0] && data2.items[0].id === 6) {
        console.log('[OK] Pagination working correctly - page 2 starts with item ID 6');
      } else {
        console.log(`[ERROR] Pagination issue - expected item ID 6 at start of page 2, got ${data2.items[0]?.id || 'undefined'}`);
      }
      
      // Test custom limit
      const response3 = await fetch('http://localhost:3336/inventory?page=1&limit=3');
      const data3 = await response3.json();
      console.log('\nCustom limit 3:');
      console.log(`Items: ${data3.items.length}`);
      console.log(`Page: ${data3.page}, Limit: ${data3.limit}, Total: ${data3.total}, HasNext: ${data3.hasNext}`);
      
      // Test invalid page (should return 400)
      const response4 = await fetch('http://localhost:3336/inventory?page=0');
      console.log('\nInvalid page (0):');
      console.log(`Status: ${response4.status}`);
      const error1 = await response4.json();
      console.log(`Error: ${error1.error}`);
      
      // Test invalid limit (should return 400)
      const response5 = await fetch('http://localhost:3336/inventory?page=1&limit=-1');
      console.log('\nInvalid limit (-1):');
      console.log(`Status: ${response5.status}`);
      const error2 = await response5.json();
      console.log(`Error: ${error2.error}`);
      
      console.log('\n[OK] All pagination tests completed!');
    } finally {
      server.close();
    }
  } catch (error) {
    console.error('[ERROR] Test failed:', error);
  }
}

testPagination();