import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';
import fetch from 'node-fetch';

console.log('Testing pagination functionality...');

async function testPagination() {
  try {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Start the server
    const server = app.listen(3334, () => {
      console.log('Test server running on port 3334');
    });
    
    // Test default values
    const defaultResponse = await fetch('http://localhost:3334/inventory');
    const defaultData = await defaultResponse.json();
    console.log('Default (page=1, limit=5):');
    console.log(`Items: ${defaultData.items.length}`);
    console.log(`Page: ${defaultData.page}, Limit: ${defaultData.limit}, Total: ${defaultData.total}, HasNext: ${defaultData.hasNext}`);
    
    // Test page 2
    const page2Response = await fetch('http://localhost:3334/inventory?page=2');
    const page2Data = await page2Response.json();
    console.log('\nPage 2:');
    console.log(`Items: ${page2Data.items.length}`);
    console.log(`Page: ${page2Data.page}, Limit: ${page2Data.limit}, Total: ${page2Data.total}, HasNext: ${page2Data.hasNext}`);
    
    // Test custom limit
    const limitResponse = await fetch('http://localhost:3334/inventory?page=1&limit=3');
    const limitData = await limitResponse.json();
    console.log('\nCustom limit 3:');
    console.log(`Items: ${limitData.items.length}`);
    console.log(`Page: ${limitData.page}, Limit: ${limitData.limit}, Total: ${limitData.total}, HasNext: ${limitData.hasNext}`);
    
    // Test invalid page
    const invalidPageResponse = await fetch('http://localhost:3334/inventory?page=0');
    console.log('\nInvalid page (0):');
    console.log(`Status: ${invalidPageResponse.status}`);
    const invalidPageData = await invalidPageResponse.json();
    console.log(`Error: ${invalidPageData.error}`);
    
    // Test invalid limit
    const invalidLimitResponse = await fetch('http://localhost:3334/inventory?page=1&limit=-1');
    console.log('\nInvalid limit (-1):');
    console.log(`Status: ${invalidLimitResponse.status}`);
    const invalidLimitData = await invalidLimitResponse.json();
    console.log(`Error: ${invalidLimitData.error}`);
    
    server.close();
    console.log('\nTest completed successfully!');
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testPagination();