import { createApp } from './src/server/app.js';
import { createDatabase } from './src/server/db.js';

console.log('Testing pagination functionality...');

async function testPagination() {
  try {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Start the server
    const server = app.listen(3335, () => {
      console.log('Test server running on port 3335');
    });
    
    // Wait for server to start
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Test default values
    const response1 = await fetch('http://localhost:3335/inventory');
    const data1 = await response1.json();
    console.log('Default (page=1, limit=5):');
    console.log(`Items: ${data1.items.length}`);
    console.log(`Page: ${data1.page}, Limit: ${data1.limit}, Total: ${data1.total}, HasNext: ${data1.hasNext}`);
    console.log(`First item: ${data1.items[0]?.name}`);
    console.log(`Last item: ${data1.items[data1.items.length-1]?.name}`);
    
    // Test page 2
    const response2 = await fetch('http://localhost:3335/inventory?page=2');
    const data2 = await response2.json();
    console.log('\nPage 2:');
    console.log(`Items: ${data2.items.length}`);
    console.log(`Page: ${data2.page}, Limit: ${data2.limit}, Total: ${data2.total}, HasNext: ${data2.hasNext}`);
    console.log(`First item: ${data2.items[0]?.name}`);
    console.log(`Last item: ${data2.items[data2.items.length-1]?.name}`);
    
    // Test custom limit
    const response3 = await fetch('http://localhost:3335/inventory?page=1&limit=3');
    const data3 = await response3.json();
    console.log('\nCustom limit 3:');
    console.log(`Items: ${data3.items.length}`);
    console.log(`Page: ${data3.page}, Limit: ${data3.limit}, Total: ${data3.total}, HasNext: ${data3.hasNext}`);
    console.log(`First item: ${data3.items[0]?.name}`);
    console.log(`Last item: ${data3.items[data3.items.length-1]?.name}`);
    
    // Test invalid page (should return 400)
    const response4 = await fetch('http://localhost:3335/inventory?page=0');
    console.log('\nInvalid page (0):');
    console.log(`Status: ${response4.status}`);
    const error1 = await response4.json();
    console.log(`Error: ${error1.error}`);
    
    // Test invalid limit (should return 400)
    const response5 = await fetch('http://localhost:3335/inventory?page=1&limit=-1');
    console.log('\nInvalid limit (-1):');
    console.log(`Status: ${response5.status}`);
    const error2 = await response5.json();
    console.log(`Error: ${error2.error}`);
    
    // Test non-numeric values
    const response6 = await fetch('http://localhost:3335/inventory?page=abc&limit=xyz');
    console.log('\nNon-numeric values:');
    console.log(`Status: ${response6.status}`);
    const error3 = await response6.json();
    console.log(`Error: ${error3.error}`);
    
    server.close();
    console.log('\nTest completed successfully!');
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testPagination();