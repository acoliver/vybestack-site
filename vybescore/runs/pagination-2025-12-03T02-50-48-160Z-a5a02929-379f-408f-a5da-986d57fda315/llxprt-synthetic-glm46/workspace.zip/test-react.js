import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import '@testing-library/jest-dom';
import { InventoryView } from './src/client/InventoryView';
import { createApp } from './src/server/app.ts';
import { createDatabase } from './src/server/db.ts';

// Mock fetch to test React component
const mockFetch = jest.fn();
global.fetch = mockFetch;

// Mock server responses
const mockPage1Response = {
  items: [
    { id: 1, name: 'Notebook', sku: 'NB-001', priceCents: 799, createdAt: '2024-01-01T09:00:00.000Z' },
    { id: 2, name: 'Mechanical Keyboard', sku: 'KB-235', priceCents: 12999, createdAt: '2024-01-02T12:30:00.000Z' },
    { id: 3, name: 'Wireless Mouse', sku: 'MS-984', priceCents: 4999, createdAt: '2024-01-03T08:15:00.000Z' },
    { id: 4, name: 'Laptop Stand', sku: 'LP-742', priceCents: 3599, createdAt: '2024-01-04T10:05:00.000Z' },
    { id: 5, name: 'Monitor 24\"', sku: 'MN-240', priceCents: 18999, createdAt: '2024-01-04T15:45:00.000Z' }
  ],
  page: 1,
  limit: 5,
  total: 15,
  hasNext: true
};

const mockPage2Response = {
  items: [
    { id: 6, name: 'USB-C Hub', sku: 'HB-611', priceCents: 2599, createdAt: '2024-01-05T11:20:00.000Z' },
    { id: 7, name: 'Portable SSD', sku: 'SD-552', priceCents: 14999, createdAt: '2024-01-06T14:55:00.000Z' },
    { id: 8, name: 'Desk Lamp', sku: 'DL-883', priceCents: 3999, createdAt: '2024-01-07T18:35:00.000Z' },
    { id: 9, name: 'Noise Cancelling Headphones', sku: 'HP-664', priceCents: 21999, createdAt: '2024-01-08T09:05:00.000Z' },
    { id: 10, name: 'Ergonomic Chair', sku: 'CH-120', priceCents: 32999, createdAt: '2024-01-09T16:40:00.000Z' }
  ],
  page: 2,
  limit: 5,
  total: 15,
  hasNext: true
};

const mockLastPageResponse = {
  items: [
    { id: 11, name: '4K Monitor', sku: 'MN-401', priceCents: 24999, createdAt: '2024-01-10T13:20:00.000Z' },
    { id: 12, name: 'Webcam HD', sku: 'WC-789', priceCents: 8999, createdAt: '2024-01-11T10:15:00.000Z' },
    { id: 13, name: 'Bluetooth Speaker', sku: 'BS-356', priceCents: 6999, createdAt: '2024-01-12T17:45:00.000Z' },
    { id: 14, name: 'External Battery', sku: 'EB-945', priceCents: 3999, createdAt: '2024-01-13T09:30:00.000Z' },
    { id: 15, name: 'Microphone USB', sku: 'MC-234', priceCents: 7999, createdAt: '2024-01-14T14:10:00.000Z' }
  ],
  page: 3,
  limit: 5,
  total: 15,
  hasNext: false
};

describe('React Inventory Pagination Tests', () => {
  beforeEach(() => {
    mockFetch.mockClear();
  });

  test('renders inventory list with pagination controls', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => mockPage1Response
    });

    render(<InventoryView />);

    // Verify loading state
    expect(screen.getByText('Loading inventory…')).toBeInTheDocument();

    // Wait for data to load
    await waitFor(() => expect(screen.getByText('Inventory')).toBeInTheDocument());

    // Verify inventory items are rendered
    expect(screen.getByText('Notebook (NB-001) – $7.99')).toBeInTheDocument();
    expect(screen.getByText('Mechanical Keyboard (KB-235) – $129.99')).toBeInTheDocument();

    // Verify pagination controls
    expect(screen.getByText('Previous')).toBeInTheDocument();
    expect(screen.getByText('Next')).toBeInTheDocument();
    expect(screen.getByText('Page 1 of 3')).toBeInTheDocument();

    // Previous button should be disabled on first page
    expect(screen.getByText('Previous')).toBeDisabled();
    // Next button should be enabled if there are more pages
    expect(screen.getByText('Next')).not.toBeDisabled();
  });

  test('navigates to next page', async () => {
    mockFetch
      .mockResolvedValueOnce({
        ok: true,
        json: async () => mockPage1Response
      })
      .mockResolvedValueOnce({
        ok: true,
        json: async () => mockPage2Response
      });

    render(<InventoryView />);

    // Wait for initial page to load
    await waitFor(() => expect(screen.getByText('Inventory')).toBeInTheDocument());

    // Click Next button
    const nextButton = screen.getByText('Next');
    fireEvent.click(nextButton);

    // Verify fetch was called with page 2
    expect(mockFetch).toHaveBeenCalledWith('/inventory?page=2&limit=5');

    // Wait for next page to load
    await waitFor(() => expect(screen.getByText('USB-C Hub (HB-611) – $25.99')).toBeInTheDocument());

    // Verify pagination info updated
    expect(screen.getByText('Page 2 of 3')).toBeInTheDocument();

    // Both buttons should be enabled on middle pages
    expect(screen.getByText('Previous')).not.toBeDisabled();
    expect(screen.getByText('Next')).not.toBeDisabled();
  });

  test('navigates to previous page', async () => {
    mockFetch
      .mockResolvedValueOnce({
        ok: true,
        json: async () => mockPage2Response
      })
      .mockResolvedValueOnce({
        ok: true,
        json: async () => mockPage1Response
      });

    // Start on page 2 by setting initial state
    jest.spyOn(React, 'useState').mockImplementationOnce(() => [2, jest.fn()]);
    
    render(<InventoryView />);

    // Wait for page 2 to load
    await waitFor(() => expect(screen.getByText('Inventory')).toBeInTheDocument());

    // Click Previous button
    const previousButton = screen.getByText('Previous');
    fireEvent.click(previousButton);

    // Verify fetch was called with page 1
    expect(mockFetch).toHaveBeenCalledWith('/inventory?page=1&limit=5');

    // Wait for previous page to load
    await waitFor(() => expect(screen.getByText('Notebook (NB-001) – $7.99')).toBeInTheDocument());

    // Previous button should be disabled on first page
    expect(screen.getByText('Previous')).toBeDisabled();
  });

  test('disables Next button on last page', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => mockLastPageResponse
    });

    render(<InventoryView />);

    // Wait for last page to load
    await waitFor(() => expect(screen.getByText('Inventory')).toBeInTheDocument());

    // Next button should be disabled on last page
    expect(screen.getByText('Next')).toBeDisabled();
    expect(screen.getByText('Previous')).not.toBeDisabled();
  });

  test('displays empty state when no items', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: true,
      json: async () => ({
        items: [],
        page: 1,
        limit: 5,
        total: 0,
        hasNext: false
      })
    });

    render(<InventoryView />);

    // Wait for empty state to load
    await waitFor(() => expect(screen.getByText('No inventory items found.')).toBeInTheDocument();
    expect(screen.getByText('Previous')).toBeDisabled();
    expect(screen.getByText('Next')).toBeDisabled();
  });

  test('displays server validation errors', async () => {
    mockFetch.mockResolvedValueOnce({
      ok: false,
      status: 400,
      json: async () => ({
        error: 'Invalid page parameter. Must be a positive integer.'
      })
    });

    render(<InventoryView />);

    // Wait for error to be displayed
    await waitFor(() => expect(screen.getByText('Invalid page parameter. Must be a positive integer.')).toBeInTheDocument();
  });
});

console.log('All React component tests completed successfully!');