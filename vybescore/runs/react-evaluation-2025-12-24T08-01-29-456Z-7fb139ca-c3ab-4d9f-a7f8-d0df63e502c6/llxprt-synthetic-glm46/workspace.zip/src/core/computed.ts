/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let isComputing = false
  let hasInitialized = false
  const equalFn = typeof equal === 'function' ? equal : undefined
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const compute = (): T => {
    // If we already have a valid value and not tracking dependencies, return it
    if (isComputing) {
      return observer.value as T
    }
    
    isComputing = true
    
    // Initialize the value only on first call in non-tracking context
    if (!hasInitialized) {
      // Call without dependency tracking for initial value
      hasInitialized = true
      observer.value = observer.updateFn(observer.value)
      isComputing = false
      return observer.value as T
    }
    
    updateObserver(observer)
    
    const prevValue = observer.value
    const newValue = observer.updateFn(prevValue)
    
    if (equal === true) {
      if (prevValue === newValue) {
        isComputing = false
        return prevValue as T
      }
    } else if (equalFn) {
      if (equalFn(prevValue!, newValue)) {
        isComputing = false
        return prevValue as T
      }
    }
    
    observer.value = newValue
    isComputing = false
    
    return observer.value as T
  }
  
  return compute
}
