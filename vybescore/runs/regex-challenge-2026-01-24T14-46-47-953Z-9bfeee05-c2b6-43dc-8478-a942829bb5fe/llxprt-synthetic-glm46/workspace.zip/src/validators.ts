export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to RFC 5322 simplified rules.
 * Accepts typical addresses like name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation using regex
  // Local part: letters, digits, and special characters except dot at start/end or consecutive
  // Domain part: letters, digits, hyphens (no underscores), with dots as separators
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // First check if it matches basic email pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Convert to lowercase for domain validation (emails are case-insensitive in domain)
  const lowercaseValue = value.toLowerCase();
  
  // Reject dots at start/end of local part (but allow valid special chars)
  const [localPart, domain] = lowercaseValue.split('@');
  
  // Local part must not start or end with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // No consecutive dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Domain part must not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must not start or end with dot or hyphen
  const domainLabels = domain.split('.');
  for (const label of domainLabels) {
    if (label.startsWith('-') || label.endsWith('-') || label.startsWith('.') || label.endsWith('.')) {
      return false;
    }
    // Domain labels must not be empty
    if (label.length === 0) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting (212) 555-7890, 212-555-7890, 2125557890 formats.
 * Optional +1 prefix is allowed.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Strip all non-digit characters first for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number)
  // Or 11 digits if it starts with 1 (country code)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Normalize by removing leading 1 if present (US country code)
  let normalizedDigits = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    normalizedDigits = digitsOnly.slice(1);
  } else if (digitsOnly.length > 10) {
    // More than 11 digits or not starting with 1 is invalid
    return false;
  }
  
  // Must have exactly 10 digits after normalization
  if (normalizedDigits.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = normalizedDigits.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check format using regex to ensure valid separators and structure
  // Accept: (212) 555-7890, 212-555-7890, 2125557890, +1 212-555-7890, etc.
  const phoneRegex = /^\+?1?\s*\(?\d{3}\)?[\s-]?\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Supports formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Case 1: With country code +54
  // Pattern: +54 [9] areaCode subscriberNumber
  const withCountryCode = cleanValue.match(/^\+54([9]?)([1-9]\d{1,3})(\d{6,8})$/);
  if (withCountryCode) {
    const [, , areaCode, subscriberNumber] = withCountryCode;
    
    // Validate area code length (2-4 digits)
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    // Validate subscriber number length (6-8 digits)
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  // Case 2: Without country code (must have trunk prefix 0)
  // Pattern: 0 areaCode subscriberNumber
  const withoutCountryCode = cleanValue.match(/^0([1-9]\d{1,3})(\d{6,8})$/);
  if (withoutCountryCode) {
    const [, areaCode, subscriberNumber] = withoutCountryCode;
    
    // Validate area code length (2-4 digits)
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    
    // Validate subscriber number length (6-8 digits)
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    
    return true;
  }
  
  // If neither pattern matched, it's invalid
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Trim whitespace from both ends
  const trimmedValue = value.trim();
  
  // Must have at least one character
  if (trimmedValue.length === 0) {
    return false;
  }
  
  // Name validation regex:
  // - Allow unicode letters (including accented characters)
  // - Allow apostrophes and hyphens
  // - Allow spaces between words
  // - Reject digits and most symbols
  const nameRegex = /^['\p{L}\p{M}]+([ \-'](['\p{L}\p{M}]+))*$/u;
  
  return nameRegex.test(trimmedValue) && !/\d/.test(trimmedValue);
}

/**
 * Validates credit card numbers for major networks (Visa/Mastercard/AmEx).
 * Checks prefix patterns and lengths, then applies Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    const digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      let doubledDigit = digit * 2;
      // If result is two digits, add them together
      if (doubledDigit > 9) {
        doubledDigit = doubledDigit.toString().split('').reduce((acc, curr) => acc + parseInt(curr, 10), 0);
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
    
    // Alternate which digits are doubled
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must contain only digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check Visa (starts with 4, length 13 or 16)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  if (visaRegex.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Check Mastercard (starts with 51-55 or 2221-2720, length 16)
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12})$/;
  if (mastercardRegex.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  // Check American Express (starts with 34 or 37, length 15)
  const amexRegex = /^3[47]\d{13}$/;
  if (amexRegex.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}
