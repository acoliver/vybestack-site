/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences even if input omitted spacing.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Normalize multiple spaces to single space
  let normalized = text.replace(/\s+/g, ' ');
  
  // Ensure there's a space after sentence endings (. ? !)
  normalized = normalized.replace(/([.?!])(?=[^\s])/g, '$1 ');
  
  // Split text into sentences
  const sentences = normalized.split(/([.!?]\s*)/);
  
  // Process sentences but keep delimiters
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    if (sentence.trim().length > 0) {
      // Capitalize the first character of the sentence
      sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
  }
  
  // Join sentences back together
  const result = sentences.join('');
  
  // Clean up any double spaces that might have been created
  return result.replace(/\s{2,}/g, ' ').trim();
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns an array of URL strings found in the input.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches various protocol schemes and domains
  const urlRegex = /https?:\/\/(?:[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6})\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up any trailing punctuation that might have been caught
  return matches.map(url => {
    // Remove trailing punctuation that might remain
    return url.replace(/[.,;:!?)}\]]+$/g, '');
  });
}

/**
 * Forces all http URLs to use https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using regex with global flag
  // Use word boundary to avoid replacing things like "vhttp://"
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs for http://example.com/... format:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, or legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http://example.com URLs to https://
  const upgradedHttp = text.replace(/http:\/\/example\.com\//g, 'https://example.com/');
  
  // Now handle docs.example.com rewrite
  // Pattern matches https://example.com/docs/... or http://example.com/docs/...
  // But excludes URLs with dynamic hints or legacy extensions
  return upgradedHttp.replace(
    /https:\/\/example\.com(\/docs\/[^\s?.]*)(?![?&#.]*(?:jsp|php|asp|aspx|do|cgi|pl|py))/g,
    'https://docs.example.com$1'
  );
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day based on month (including leap year rules for February)
  const maxDays = {
    1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  // Check for leap year for February
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  
  if (month === 2) {
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  } else if (day > maxDays[month as keyof typeof maxDays]) {
    return 'N/A';
  }
  
  return year;
}
