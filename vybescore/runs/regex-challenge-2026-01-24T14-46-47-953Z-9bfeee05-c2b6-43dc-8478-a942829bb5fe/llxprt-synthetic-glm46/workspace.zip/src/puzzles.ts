/**
 * Finds words beginning with the specified prefix, excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a set of exceptions for efficient lookup
  const exceptionSet = new Set(exceptions);
  
  // Split text into words and filter
  const words = text.split(/\s+/);
  
  // Filter words that start with prefix, are not in exceptions, and are valid words
  // Word boundary \b ensures we match whole words only
  const prefixedWords: string[] = [];
  
  for (const word of words) {
    // Clean word of common punctuation
    const cleanWord = word.replace(/[^\w]/g, '');
    
    if (cleanWord.startsWith(prefix) && 
        !exceptionSet.has(cleanWord) && 
        cleanWord.length > prefix.length) {
      prefixedWords.push(cleanWord);
    }
  }
  
  return prefixedWords;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Returns the complete occurrence including the digit prefix.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex that captures the digit and token together
  const regex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches, return the full match (digit + token)
  const result: string[] = [];
  let match;
  while ((match = regex.exec(text)) !== null) {
    result.push(match[1]);
  }
  
  return result;
}

/**
 * Validates password strength according to specified policy.
 * Requirements: at least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, and no immediate repeated sequences (e.g., abab).
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (/\d/.test(value) === false) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Must not contain whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for repeated patterns (immediate repetition)
  // Look for patterns of 2 characters that repeat right after themselves (like ab, ab)
  if (/(.{2})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern that matches various formats:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed notation: 2001:db8:85a3::8a2e:370:7334
  // - Loopback: ::1
  // - unspecified: ::
  // Note: IPv4 addresses embedded in IPv6 should also match this pattern (like ::ffff:192.0.2.128)
  
  // IPv6 regex that captures all valid IPv6 formats
  const ipv6Regex = /(::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4})|([0-9a-fA-F]{1,4}:([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4})|::1|::/;
  
  // Test for IPv6 in the value
  return ipv6Regex.test(value);
}
