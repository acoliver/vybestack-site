/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  EqualFn,
  Options,
  Subject
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  // Store dependent observers for this computed value
  const computedObserver: ObserverR = { observers: new Set() }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observer: computedObserver,
  }

  let hasBeenInitialized = false

  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver && computedObserver.observers) {
      // Track this computed value as dependency
      computedObserver.observers.add(currentObserver)
      o.observer = currentObserver
    }
    
    // Only compute on first access or when tracking dependencies
    if (!hasBeenInitialized || currentObserver) {
      updateObserver(o)
      hasBeenInitialized = true
    }
    
    return o.value!
  }

  return read
}