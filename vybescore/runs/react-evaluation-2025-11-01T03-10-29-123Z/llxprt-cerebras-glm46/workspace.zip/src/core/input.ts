/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFunction: EqualFn<T> | undefined
  
  if (typeof _equal === 'function') {
    equalFunction = _equal
  } else if (_equal === false) {
    equalFunction = undefined
  } else {
    equalFunction = (lhs: T, rhs: T) => lhs === rhs
  }

  // Create a shared observer object that can store multiple dependent observers
  const inputObserver: ObserverR = { observers: new Set() }

  const s: Subject<T> = {
    name: options?.name,
    observer: inputObserver,
    value,
    equalFn: equalFunction,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && inputObserver.observers) {
      // Track this input as dependency by adding observer to input's observers list
      inputObserver.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (equalFunction && equalFunction(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all dependent observers when value changes
    if (inputObserver.observers) {
      for (const observer of inputObserver.observers) {
        updateObserver(observer as Observer<unknown>)
      }
    }
    
    return s.value
  }

  return [read, write]
}