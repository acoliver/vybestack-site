import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import { Express } from 'express';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';
import type { Database } from 'sql.js';

describe('inventory API pagination validation', () => {
  let db: Database;
  let app: Express;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  describe('Parameter validation', () => {
    it('returns 400 for non-numeric page', async () => {
      const response = await request(app).get('/inventory?page=abc');
      expect(response.status).toBe(400);
      expect(response.body.error).toBeTruthy();
    });

    it('returns 400 for non-numeric limit', async () => {
      const response = await request(app).get('/inventory?limit=xyz');
      expect(response.status).toBe(400);
      expect(response.body.error).toBeTruthy();
    });

    it('returns 400 for negative page', async () => {
      const response = await request(app).get('/inventory?page=-1');
      expect(response.status).toBe(400);
      expect(response.body.error).toBeTruthy();
    });

    it('returns 400 for zero page', async () => {
      const response = await request(app).get('/inventory?page=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toBeTruthy();
    });

    it('returns 400 for negative limit', async () => {
      const response = await request(app).get('/inventory?limit=-5');
      expect(response.status).toBe(400);
      expect(response.body.error).toBeTruthy();
    });

    it('returns 400 for zero limit', async () => {
      const response = await request(app).get('/inventory?limit=0');
      expect(response.status).toBe(400);
      expect(response.body.error).toBeTruthy();
    });

    it('returns 400 for limit exceeding maximum', async () => {
      const response = await request(app).get('/inventory?limit=101');
      expect(response.status).toBe(400);
      expect(response.body.error).toBeTruthy();
    });
  });

  describe('Default values', () => {
    it('uses default page (1) when not specified', async () => {
      const response = await request(app).get('/inventory');
      expect(response.status).toBe(200);
      expect(response.body.page).toBe(1);
    });

    it('uses default limit (5) when not specified', async () => {
      const response = await request(app).get('/inventory');
      expect(response.status).toBe(200);
      expect(response.body.limit).toBe(5);
    });
  });

  describe('Pagination metadata', () => {
    it('returns correct pagination metadata', async () => {
      const response = await request(app).get('/inventory?page=2&limit=3');
      expect(response.status).toBe(200);
      expect(response.body).toHaveProperty('items');
      expect(response.body).toHaveProperty('page', 2);
      expect(response.body).toHaveProperty('limit', 3);
      expect(response.body).toHaveProperty('total');
      expect(response.body).toHaveProperty('hasNext');
    });

    it('has correct total count', async () => {
      const response = await request(app).get('/inventory');
      expect(response.status).toBe(200);
      expect(response.body.total).toBe(15); // Based on seed data
    });
  });

  describe('Pagination behavior', () => {
    it('returns correct items for first page with limit 5', async () => {
      const response = await request(app).get('/inventory?page=1&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(5);
      expect(response.body.items[0].id).toBe(1);
      expect(response.body.items[4].id).toBe(5);
    });

    it('returns correct items for second page with limit 5', async () => {
      const response = await request(app).get('/inventory?page=2&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(5);
      expect(response.body.items[0].id).toBe(6);
      expect(response.body.items[4].id).toBe(10);
    });

    it('returns items in correct order', async () => {
      const response = await request(app).get('/inventory?limit=10');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(10);
      
      // Check that items are ordered by id
      for (let i = 1; i < response.body.items.length; i++) {
        expect(response.body.items[i].id).toBeGreaterThan(response.body.items[i-1].id);
      }
    });

    it('correctly sets hasNext flag', async () => {
      const page1 = await request(app).get('/inventory?page=1&limit=8');
      expect(page1.body.hasNext).toBe(true); // 8 items on page 1, 7 remaining
      
      const page2 = await request(app).get('/inventory?page=2&limit=8');
      expect(page2.body.hasNext).toBe(false); // Only 7 items remaining, so no page 3
      
      const page3 = await request(app).get('/inventory?page=3&limit=5');
      // With limit 5, page 3 contains items 11-15, which is the last item, so there is no next page
      expect(page3.body.hasNext).toBe(false);
      
      const page4 = await request(app).get('/inventory?page=3&limit=8');
      expect(page4.body.hasNext).toBe(false); // No items remaining after page 3
    });

    it('returns less items on last page', async () => {
      const response = await request(app).get('/inventory?page=3&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(5);
      
      const lastPage = await request(app).get('/inventory?page=4&limit=5');
      expect(lastPage.status).toBe(200);
      expect(lastPage.body.items?.length || 0).toBeLessThanOrEqual(5);
    });
  });

  describe('Edge cases', () => {
    it('handles limit exactly matching remaining items', async () => {
      const response = await request(app).get('/inventory?page=1&limit=15');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(15);
      expect(response.body.hasNext).toBe(false);
    });

    it('handles limit larger than total', async () => {
      const response = await request(app).get('/inventory?page=1&limit=20');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(15);
      expect(response.body.hasNext).toBe(false);
    });

    it('handles page beyond available data', async () => {
      const response = await request(app).get('/inventory?page=10&limit=5');
      expect(response.status).toBe(200);
      expect(response.body.items.length).toBe(0);
      expect(response.body.hasNext).toBe(false);
    });
  });
});