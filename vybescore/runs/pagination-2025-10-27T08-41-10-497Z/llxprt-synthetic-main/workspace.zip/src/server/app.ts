import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;
    
    // Default values
    const DEFAULT_PAGE = 1;
    const DEFAULT_LIMIT = 5;
    const MAX_LIMIT = 100;

    // Validate page parameter
    let page: number;
    if (!pageParam) {
      page = DEFAULT_PAGE;
    } else {
      const parsedPage = Number(pageParam);
      if (isNaN(parsedPage) || !Number.isInteger(parsedPage) || parsedPage < 1) {
        return res.status(400).json({ error: 'page must be a positive integer' });
      }
      page = parsedPage;
    }

    // Validate limit parameter
    let limit: number;
    if (!limitParam) {
      limit = DEFAULT_LIMIT;
    } else {
      const parsedLimit = Number(limitParam);
      if (isNaN(parsedLimit) || !Number.isInteger(parsedLimit) || parsedLimit < 1 || parsedLimit > MAX_LIMIT) {
        return res.status(400).json({ error: `limit must be a positive integer between 1 and ${MAX_LIMIT}` });
      }
      limit = parsedLimit;
    }

    // Get paginated inventory
    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
