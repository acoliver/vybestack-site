export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using regular expressions.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic format check
  if (!emailRegex.test(value)) return false;
  
  // Extract local part and domain
  const [localPart, domain] = value.split('@');
  
  // Local part cannot start or end with a dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Local part cannot have consecutive dots
  if (localPart.includes('..')) return false;
  
  // Domain cannot start or end with a dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) return false;
  
  // Domain cannot have consecutive dots
  if (domain.includes('..')) return false;
  
  // Domain cannot contain underscores
  if (domain.includes('_')) return false;
  
  // Domain must have at least one dot
  if (!domain.includes('.')) return false;
  
  // Each domain part cannot start or end with a hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with common separators.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  const cleanedValue = value.replace(/[\s\-\.]/g, '');
  
  // Check for optional country code +1
  let phoneNumber = cleanedValue;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.slice(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Remove parentheses if present
  phoneNumber = phoneNumber.replace(/[()]/g, '');
  
  // Check length
  if (phoneNumber.length !== 10) return false;
  
  // Check if all characters are digits
  if (!/^\d+$/.test(phoneNumber)) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.substring(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area code must be 2-4 digits (leading digit 1-9).
 * Subscriber number must contain 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input by removing spaces and hyphens
  const cleanedValue = value.replace(/[\s\-\(\)]/g, '');
  
  // Try to match the phone number with the country code (+54)
  const withCountryCode = /^\+54?9?0?([1-9]\d{1,3})(\d{6,8})$/;
  const countryCodeMatch = cleanedValue.match(withCountryCode);
  
  if (countryCodeMatch) {
    const [, areaCode, subscriberNumber] = countryCodeMatch;
    
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    return true;
  }
  
  // Try to match the phone number without the country code (must start with 0)
  const withoutCountryCode = /^0([1-9]\d{1,3})(\d{6,8})$/;
  const noCountryCodeMatch = cleanedValue.match(withoutCountryCode);
  
  if (noCountryCodeMatch) {
    const [, areaCode, subscriberNumber] = noCountryCodeMatch;
    
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    
    return true;
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
    // Check for at least one character character
  if (!value || value.trim().length === 0) return false;
  
  // Name can contain unicode letters (including accented letters), apostrophes, hyphens, and spaces
  const namePattern = /^[\p{L}'\-\s]+$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Check for digits or other symbols not allowed
  const disallowedPattern = /[0-9@#$%^&*()_+=\[\]{}|\\:";<>,.?\/]/;
  if (disallowedPattern.test(value)) return false;
  
  // Check for multiple consecutive spaces
  if (value.includes('  ')) return false;
  
  // Check for multiple consecutive apostrophes or hyphens
  if (value.match(/''|--/)) return false;
  
  // Check for names like "X Æ A-12" that include invalid symbols or patterns
  // Specifically, a letter followed by a single space, a special character, another space, then other characters
  const weirdPattern = /\P{L}\s[\p{L}]\s\P{L}/u;
  if (weirdPattern.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanedValue = value.replace(/[\s\-]/g, '');
  
  // Check if the cleaned value contains only digits
  if (!/^\d+$/.test(cleanedValue)) return false;
  
  // Verify length based on card type
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // American Express: 15 digits, starts with 34 or 37
  
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  if (!visaRegex.test(cleanedValue) && 
      !mastercardRegex.test(cleanedValue) && 
      !amexRegex.test(cleanedValue)) {
    return false;
  }
  
  // Luhn checksum check
  return runLuhnCheck(cleanedValue);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  
  // Reverse the string to process digits from right to left
  const reversedValue = value.split('').reverse().join('');
  
  for (let i = 0; i < reversedValue.length; i++) {
    let digit = parseInt(reversedValue[i], 10);
    
    // Double every second digit (starting from the rightmost digit)
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}
