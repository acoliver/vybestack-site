/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape the prefix to handle special regex characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with the prefix
  // \b ensures we match whole words only
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return [...new Set(matches)].filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token to handle special regex characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match the digit followed by the token to include the digit in the result
  const tokenRegex = new RegExp(`(\\d${escapedToken})`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  return [...new Set(matches)]; // Remove duplicates
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (non-whitespace, non-alphanumeric)
  if (!/[^\w\s]/.test(value)) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (at least 3 characters repeated)
  // This catches cases like "abcabc", "abab", "123123", etc.
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex pattern that includes various IPv6 formats
  // This matches IPv6 addresses including shorthand :: notation
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:(?:[0-9a-fA-F]{1,4}:){1,6}?)?::(?:[0-9a-fA-F]{1,4}:){0,7}/g;
  
  // IPv4 regex to identify and exclude IPv4 addresses
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Find potential IPv6 addresses
  const potentialIPv6 = value.match(ipv6Regex) || [];
  
  for (const match of potentialIPv6) {
    // Skip IPv4-like patterns that might be part of IPv6 with embedded IPv4
    if (ipv4Regex.test(match) && !match.includes(":")) {
      continue;
    }
    
    // If we found a colon-based IPv6 pattern, return true
    if (match.includes(":")) {
      return true;
    }
  }
  
  // Additional check for IPv6 addresses with embedded IPv4
  const ipv6WithIPv4Regex = /(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}/g;
  if (ipv6WithIPv4Regex.test(value)) {
    return true;
  }
  
  return false;
}