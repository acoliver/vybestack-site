/**
 * Capitalize the first character of each sentence (after .?!), 
 * insert exactly one space between sentences even if the input omitted it,
 * and collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  let result = text;
  
  // Collapse multiple spaces into a single space (except newlines)
  result = result.replace(/[ \t]+/g, ' ');
  
  // Ensure there's exactly one space after sentence-ending punctuation
  result = result.replace(/([.!?])(?=[\w])/g, '$1 ');
  
  // Now capitalize sentences
  // Split on sentence boundaries (.!? followed by space)
  const sentences = result.split(/([.!?])(\s|$)/);
  
  for (let i = 0; i < sentences.length; i++) {
    // Every third element (starting from 0) is a sentence
    if (i % 3 === 0 && sentences[i].length > 0) {
      // Capitalize first letter if it's alphabetic
      sentences[i] = sentences[i].replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
    }
  }
  
  // Rejoin the sentences
  result = sentences.join('');
  
  return result.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // URL regex pattern to match http/https URLs with optional www
  // This pattern captures the URL without trailing punctuation
  const urlRegex = /https?:\/\/(?:www\.)?[^-\s<>"]+|www\.[^-\s<>"]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)}\]]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https:// but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrade the scheme to https://.
 * When the path begins with /docs/, rewrite the host to docs.example.com.
 * Skip the host rewrite when the path contains dynamic hints.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // First, simply upgrade all http URLs to https
  text = text.replace(/http:\/\//g, 'https://');
  
  // Now process URLs with /docs/ path to rewrite the host
  // Match all URLs that have docs path
  const docsUrlRegex = /(https:\/\/)(www\.)?([a-zA-Z0-9-]+)\.([a-zA-Z]{2,})(\/docs\/[\w\/.-]*)(\?[^#\s]*)?(#[^#\s]*)?/g;
  
  return text.replace(docsUrlRegex, (match, protocol, www, domain, tld, path, query, fragment) => {
    // Check for dynamic hints in the full URL (not just the path)
    const fullUrl = `${protocol}${www || ''}${domain}.${tld}${path}${query || ''}${fragment || ''}`;
    const hasDynamicHints = /cgi-bin|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$|\?|&|=/.test(fullUrl);
    
    // If no dynamic hints and the URL starts with /docs/, rewrite the host
    if (!hasDynamicHints) {
      return `${protocol}docs.${domain}.${tld}${path}${query || ''}${fragment || ''}`;
    }
    
    // Otherwise, return the original URL with HTTPS
    return fullUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Match mm/dd/yyyy format
  const dateRegex = /^([01]\d)\/([0-3]\d)\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Index 0 unused
  
  // Check for leap year
  const isLeapYear = (year: number) => {
    return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  };
  
  // Adjust February days for leap years
  if (month === 2 && isLeapYear(parseInt(year, 10))) {
    daysInMonth[2] = 29;
  }
  
  if (day < 1 || day > daysInMonth[month]) return 'N/A';
  
  return year;
}
