/**
 * Finds words in the text that start with the specified prefix.
 * Excludes any words that are in the exceptions list.
 * @param text The input text to search
 * @param prefix The prefix to match words against
 * @param exceptions Words to exclude from the results
 * @returns Array of matching words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }

  // Create regex to find words starting with the prefix
  // \b ensures we match whole words
  const regex = new RegExp(`\\b(${prefix}\\w+)`, 'g');
  
  // Find all matches
  const matches = text.match(regex) || [];
  
  // Filter out any words that are in the exceptions list
  // Also deduplicate the results by using a Set
  const uniqueWords = new Set<string>();
  
  for (const match of matches) {
    // Check if the full word is NOT in the exceptions
    if (!exceptions.includes(match)) {
      uniqueWords.add(match);
    }
  }
  
  return Array.from(uniqueWords);
}

/**
 * Finds occurrences of a token that appear after a digit but not at the beginning of the string.
 * Uses lookbehind/lookahead assertions in the regex.
 * @param text The input text to search
 * @param token The token to find
 * @returns Array of matching tokens with their full context
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape any special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a regex with a simpler approach - find digit+token patterns directly
  const regex = new RegExp(`(\\d${escapedToken})`, 'g');
  const matches = text.match(regex) || [];
  
  // Deduplicate the results
  return [...new Set(matches)];
}

/**
 * Validates if a password meets the strong password criteria.
 * Requirements: at least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, and no immediate repeated sequences (e.g., abab).
 * @param value The password to validate
 * @returns True if the password is strong, false otherwise
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences of 2-4 characters
  // This catches patterns like "abab" or "123123"
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);
      if (segment === nextSegment) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detects if the input contains an IPv6 address.
 * Includes support for shorthand notation (::) while excluding IPv4 addresses.
 * @param value The input text to check for IPv6 addresses
 * @returns True if an IPv6 address is found, false otherwise
 */
export function containsIPv6(value: string): boolean {
  if (!value) {
    return false;
  }

  // IPv6 regex pattern
  // This covers:
  // 1. Full notation: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx (8 groups)
  // 2. Leading zeros can be omitted
  // 3. Double colon shorthand for consecutive zeros
  // 4. IPv4-mapped IPv6 addresses: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:IPv4
  const ipv6Regex = /(?:^|(?<=[\s<>]))(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}(?:[0-9a-fA-F]{1,4}:){0,7}(?:::)?(?:[0-9a-fA-F]{1,4})?(?=$|(?=[\s<>]))/;

  // Test if the string contains an IPv6 address
  const hasIpv6 = ipv6Regex.test(value);

  // If we found an IPv6-like address, also check that it's not just an IPv4 address
  if (hasIpv6) {
    // IPv4 regex to check for pure IPv4 addresses
    const ipv4Regex = /(?:^|(?<=[\s<>]))(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)(?=$|(?=[\s<>]))/;
    
    // If the input also contains IPv4, we need to check if the IPv6 pattern match is actually an IPv4
    const ipv4Match = value.match(ipv4Regex);
    const ipv6Match = value.match(ipv6Regex);
    
    if (ipv4Match && ipv6Match) {
      // Check if the IPv6 match is actually the IPv4 we already found
      // This is a simple check to ensure we're not confusing IPv4 with IPv6
      return ipv6Match[0].includes(':');
    }
    
    return true;
  }

  return false;
}