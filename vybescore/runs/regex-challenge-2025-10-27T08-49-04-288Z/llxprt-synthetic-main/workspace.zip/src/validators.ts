export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with support for common formats.
 * Accepts emails like name+tag@example.co.uk while rejecting invalid patterns.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  if (!value || !value.includes('@')) {
    return false;
  }

  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }

  const [localPart, domain] = parts;

  // Local part validation
  // Allow letters, digits, dots, hyphens, plus, underscores (but not at start/end or consecutive)
  // Reject leading/trailing/trailing dots, consecutive dots
  const localRegex = /^[a-zA-Z0-9](?!.*\.\.)[a-zA-Z0-9._+-]*[a-zA-Z0-9]$/;
  if (!localRegex.test(localPart)) {
    return false;
  }

  // Domain validation
  // Domain labels: letters, digits, hyphens (not at start/end)
  // No underscores in domain
  // TLD: at least 2 letters
  const domainRegex = /^[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value) {
    return false;
  }

  // Check for optional +1 country code
  const withoutCountryCode = value.replace(/^\+1[\s-]?/, '').trim();

  // Remove all non-digit characters to get the actual number
  const digitsOnly = withoutCountryCode.replace(/\D/g, '');

  // US phone numbers should have 10 digits after country code
  if (digitsOnly.length !== 10) {
    return false;
  }

  // Area code cannot start with 0 or 1
  const areaCode = digitsOnly.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Validate the overall format
  const phoneRegex = /^(\+1[\s-])?(\(\d{3}\)[\s-]?|\d{3}[-\s]?)\d{3}[-\s]?\d{4}$/;
  if (!phoneRegex.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) {
    return false;
  }

  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Regex groups: [countryCode] [trunkPrefix] [mobileIndicator] [areaCode] [subscriberNumber]
  const phoneRegex = /^(\+54)?(9)?[0]?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(phoneRegex);
  if (!match) {
    return false;
  }

  const countryCode = match[1]; // +54 or undefined
  // const mobileIndicator = match[2]; // 9 or undefined (extracted but not needed for validation)
  const trunkPrefix = cleaned.indexOf('0') === 0 || (countryCode && cleaned.substring(3, 4) === '0') ? true : false;
  const areaCode = match[3]; // 2-4 digits, leading digit 1-9
  const subscriberNumber = match[4]; // 6-8 digits

  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  // If country code is present, mobile indicator can be included
  // If country code is omitted, must start with trunk prefix 0
  if (!countryCode && !trunkPrefix) {
    return false;
  }

  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual patterns like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, most symbols, and consecutive non-letter characters
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\s'-]+$/;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Additional validation: reject names with unusual symbols patterns
  // Check for multiple non-letter characters in a row (except allowed combinations)
  const suspiciousPattern = /(.)\1{2,}/;
  if (suspiciousPattern.test(value)) {
    return false;
  }

  // Reject names with multiple consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }

  // Reject names with multiple consecutive hyphens or apostrophes
  if (/[-']{2,}/.test(value)) {
    return false;
  }

  // Ensure at least one letter is present
  const hasLetter = /[a-zA-Z\u00C0-\u017F]/.test(value);
  if (!hasLetter) {
    return false;
  }

  return true;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks prefixes, lengths, and performs a Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) {
    return false;
  }

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Validate prefix and length for different card types
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercardRegex = /^5[1-5][0-9]{14}$/;
  const amexRegex = /^3[47][0-9]{13}$/;

  // Check if it matches any valid card format
  const isValidFormat = visaRegex.test(cleaned) || 
                       mastercardRegex.test(cleaned) || 
                       amexRegex.test(cleaned);

  if (!isValidFormat) {
    return false;
  }

  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform the Luhn algorithm checksum.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = true; // Start from the rightmost digit (position 0 is even)

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    // Double every second digit from right
    if (!isEven) {  // Fixed: was isEven, should be !isEven (we start counting from right)
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}
