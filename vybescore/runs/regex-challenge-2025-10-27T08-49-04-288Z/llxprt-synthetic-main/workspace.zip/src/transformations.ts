/**
 * Capitalizes the first character of each sentence in the text.
 * Handles sentence boundaries after ., ?, !, adds single spaces between sentences,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }

  // First, ensure there's a single space after sentence terminators
  // Multiple spaces: convert to single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure there's a space after sentence terminators if missing
  // But be careful with abbreviations like "e.g." or "i.e."
  result = result.replace(/([.?!])(?=[a-zA-Z])/g, '$1 ');
  
  // Split into sentences by ., ?, ! followed by any number of spaces
  // Use a lookbehind to ensure we don't split abbreviations
  const sentenceParts = result.split(/(?<=[.?!])\s+/);
  
  // Capitalize each sentence
  for (let i = 0; i < sentenceParts.length; i++) {
    if (sentenceParts[i].length > 0) {
      const firstChar = sentenceParts[i][0];
      // Only capitalize at the beginning of the string or after sentence terminators
      if (i === 0 || sentenceParts[i-1].match(/[.?!]$/)) {
        sentenceParts[i] = firstChar.toUpperCase() + sentenceParts[i].substring(1);
      }
    }
  }
  
  // Join sentences back with a single space
  return sentenceParts.join(' ');
}

/**
 * Extracts all URLs from the given text.
 * Returns an array of URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }

  // URL pattern that matches http, https, ftp, etc.
  // This regex captures URLs while excluding trailing punctuation
  const urlRegex =
    /(https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+?(?=[,.!?;:\]\)\}]*\s|$|[,.!?;:\]\)\}]*\<)/gi;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation from each URL
  return matches.map(url => url.replace(/[,.!?;:\]\)\}]+$/g, '')).filter(url => url.length > 0);
}

/**
 * Converts all HTTP URLs to HTTPS while leaving already secure URLs untouched.
 * @param text The input text containing URLs
 * @returns Text with all HTTP URLs upgraded to HTTPS
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }

  // Replace http:// with https://, but not https:
  return text.replace(/http:\/\/(?!https:)/g, 'https://');
}

/**
 * Rewrites URLs from example.com to use HTTPS and moves docs paths to docs.example.com.
 * Always upgrades http:// to https://.
 * When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions).
 * @param text The input text containing URLs
 * @returns Text with URLs rewritten according to the rules
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }

  // First upgrade all http://example.com URLs to https://example.com
  let result = text.replace(/http:\/\/example\.com\//g, 'https://example.com/');

  // Pattern to match https://example.com URLs
  const urlPattern = /(https:\/\/example\.com\/)([^\s]+)/g;

  // Replace URLs with docs paths
  result = result.replace(urlPattern, (match, prefix, path) => {
    // Check if the path should be rewritten to docs.example.com
    // Skip if it contains dynamic hints or legacy extensions
    const shouldSkip = 
      /\/cgi-bin\//.test(path) || 
      /[?&=]/.test(path) || 
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/i.test(path);

    // If path starts with /docs/ and should not be skipped, rewrite the host
    if (!shouldSkip && /^docs\//i.test(path)) {
      return `https://docs.example.com/${path}`;
    }

    // Otherwise just return the original with HTTPS upgrade
    return `${prefix}${path}`;
  });

  return result;
}

/**
 * Extracts the year from an mm/dd/yyyy formatted date string.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 * @param value The input date string
 * @returns The four-digit year or 'N/A' if invalid
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }

  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Additional validation for day based on month
  // Check for February (non-leap year)
  if (month === 2 && day > 28) {
    return 'N/A';
  }

  // Check for months with 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }

  // If all checks passed, return the year
  return year;
}
