import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns paginated inventory rows with default parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns correct pagination for page 2', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns correct pagination for last page', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(false);
  });

  it('returns 400 for invalid page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid page parameter. Must be a positive integer.');
  });

  it('returns 400 for invalid limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory?limit=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid limit parameter. Must be a positive integer.');
  });

  it('returns 400 for zero page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid page parameter. Must be a positive integer.');
  });

  it('returns 400 for non-integer page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory?page=1.5');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Invalid page parameter. Must be a positive integer.');
  });
});
