import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView() {
  const [page, setPage] = useState(1);
  const { status, data, error } = useInventory(page, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <div>
        <button 
          onClick={() => setPage(prev => Math.max(1, prev - 1))}
          disabled={page <= 1}
        >
          Previous
        </button>
        <span>Page {data.page}</span>
        <button 
          onClick={() => setPage(prev => prev + 1)}
          disabled={!data.hasNext}
        >
          Next
        </button>
      </div>
    </section>
  );
}
