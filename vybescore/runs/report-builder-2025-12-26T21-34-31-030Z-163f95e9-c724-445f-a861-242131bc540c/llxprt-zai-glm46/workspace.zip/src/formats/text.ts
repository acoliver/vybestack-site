import type { ReportData, RenderOptions } from '../types.js';
import { formatCurrency, computeTotal } from '../utils.js';

/**
 * Renders report data as plain text format
 */
export function renderText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatCurrency(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = computeTotal(data.entries);
    lines.push('');
    lines.push(`Total: ${formatCurrency(total)}`);
  }

  return lines.join('\n');
}
