import type { ReportData } from './types.js';

/**
 * Validates report data structure
 */
export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry at index ${i} is not an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid report data: entry at index ${i} missing or invalid "label" field (expected string)`
      );
    }
    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid report data: entry at index ${i} missing or invalid "amount" field (expected number)`
      );
    }
  }

  return data as ReportData;
}

/**
 * Parses and validates JSON report data from a string
 */
export function parseReportData(jsonString: string): ReportData {
  let data: unknown;
  try {
    data = JSON.parse(jsonString);
  } catch (err) {
    if (err instanceof Error && err.name === 'SyntaxError') {
      throw new Error(`Malformed JSON: ${err.message}`);
    }
    throw err;
  }

  return validateReportData(data);
}

/**
 * Formats a number as a currency string with two decimal places
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Computes the total of all entry amounts
 */
export function computeTotal(entries: readonly { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}
