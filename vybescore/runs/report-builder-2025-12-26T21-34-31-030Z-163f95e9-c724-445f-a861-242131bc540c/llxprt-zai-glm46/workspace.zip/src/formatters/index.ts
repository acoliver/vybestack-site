import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

export type Format = 'markdown' | 'text';

export type Renderer = (data: ReportData, options: RenderOptions) => string;

/**
 * Registry of available formatters
 */
export const formatters: Record<Format, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Get a renderer by format name
 */
export function getFormatter(format: string): Renderer {
  const formatter = formatters[format as Format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}

/**
 * List of supported formats
 */
export function getSupportedFormats(): Format[] {
  return Object.keys(formatters) as Format[];
}
