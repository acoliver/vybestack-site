#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { parseReportData } from '../utils.js';
import { getFormatter } from '../formatters/index.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments using Node's standard library
 */
function parseArgs(args: string[]): CliArgs {
  if (args.length < 1) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required (supported: markdown, text)');
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Main entry point for the CLI
 */
function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and parse input file
    const inputPath = path.resolve(args.inputFile);
    let jsonString: string;
    try {
      jsonString = fs.readFileSync(inputPath, 'utf-8');
    } catch (err) {
      if ((err as NodeJS.ErrnoException).code === 'ENOENT') {
        throw new Error(`File not found: ${args.inputFile}`);
      }
      throw err;
    }

    const data = parseReportData(jsonString);

    // Get formatter and render
    const formatter = getFormatter(args.format);
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = formatter(data, options);

    // Write to output
    if (args.outputPath) {
      const outputPath = path.resolve(args.outputPath);
      fs.writeFileSync(outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (err) {
    if (err instanceof Error) {
      console.error(`Error: ${err.message}`);
      process.exit(1);
    } else {
      console.error('Unexpected error');
      process.exit(1);
    }
  }
}

main();
