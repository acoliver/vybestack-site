#!/usr/bin/env node

/**
 * Report CLI - Renders reports from JSON input.
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import { formatters, supportedFormats } from '../formatters.js';
import type { RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parses CLI arguments.
 */
function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    dataFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    switch (arg) {
      case '--format':
        i++;
        if (i >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        result.format = args[i];
        break;

      case '--output':
        i++;
        if (i >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        result.outputPath = args[i];
        break;

      case '--includeTotals':
        result.includeTotals = true;
        break;

      default:
        if (arg.startsWith('--')) {
          console.error(`Error: Unknown option "${arg}"`);
          process.exit(1);
        }
        if (result.dataFile) {
          console.error(`Error: Unexpected argument "${arg}"`);
          process.exit(1);
        }
        result.dataFile = arg;
        break;
    }
  }

  if (!result.dataFile) {
    console.error('Error: Missing data file argument');
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    process.exit(1);
  }

  if (!result.format) {
    console.error('Error: --format is required');
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    process.exit(1);
  }

  return result;
}

/**
 * Reads and parses the JSON data file.
 */
function readDataFile(filePath: string): unknown {
  const resolvedPath = path.resolve(filePath);

  if (!fs.existsSync(resolvedPath)) {
    console.error(`Error: File not found: "${filePath}"`);
    process.exit(1);
  }

  const content = fs.readFileSync(resolvedPath, 'utf-8');

  try {
    return JSON.parse(content);
  } catch (error) {
    console.error(
      `Error: Failed to parse JSON in "${filePath}": ${(error as Error).message}`
    );
    process.exit(1);
  }
}

/**
 * Main CLI entry point.
 */
function main(): void {
  const args = parseArgs(process.argv.slice(2));

  // Validate format
  if (!supportedFormats.includes(args.format)) {
    console.error(`Error: Unsupported format "${args.format}"`);
    console.error(
      `Supported formats: ${supportedFormats.join(', ')}`
    );
    process.exit(1);
  }

  // Read and validate data
  const rawData = readDataFile(args.dataFile);

  if (!validateReportData(rawData)) {
    console.error(
      'Error: Invalid data format. Expected an object with title (string), summary (string), and entries (array of {label: string, amount: number})'
    );
    process.exit(1);
  }

  const data = rawData;

  // Render report
  const formatter = formatters[args.format];
  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  const output = formatter(data, options);

  // Write output
  if (args.outputPath) {
    fs.writeFileSync(args.outputPath, output, 'utf-8');
  } else {
    console.log(output);
  }
}

main();
