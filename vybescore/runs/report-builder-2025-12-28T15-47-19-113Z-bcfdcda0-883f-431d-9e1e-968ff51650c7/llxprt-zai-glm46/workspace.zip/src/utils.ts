/**
 * Utility functions for report formatting.
 */

import type { ReportData, ReportEntry } from './types.js';

/**
 * Validates the report data structure.
 */
export function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    return false;
  }

  if (typeof obj.summary !== 'string') {
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    return false;
  }

  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      return false;
    }
  }

  return true;
}

/**
 * Calculates the total amount from all entries.
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Formats an amount as a currency string with two decimal places.
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}
