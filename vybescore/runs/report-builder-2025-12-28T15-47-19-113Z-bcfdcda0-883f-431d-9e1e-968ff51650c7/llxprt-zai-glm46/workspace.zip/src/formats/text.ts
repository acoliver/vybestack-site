/**
 * Text formatter for reports.
 */

import type { Formatter, ReportData, RenderOptions } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

export const renderText: Formatter['render'] = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);

  // Summary
  lines.push(data.summary);

  // Entries section
  lines.push('Entries:');

  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
