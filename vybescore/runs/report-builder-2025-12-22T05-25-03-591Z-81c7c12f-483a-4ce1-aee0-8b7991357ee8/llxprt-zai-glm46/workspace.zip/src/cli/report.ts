#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { parseArgs } from 'node:util';
import type { ReportData, RenderOptions } from '../types.js';
import { getFormatter } from '../formatters/index.js';

interface CliArgs {
  format: string;
  output?: string;
  includeTotals?: boolean;
}

function parseCliArgs(): { inputFile: string; options: CliArgs } {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const remainingArgs = args.slice(1);
  
  try {
    const { values } = parseArgs({
      args: remainingArgs,
      options: {
        format: {
          type: 'string',
          required: true,
        },
        output: {
          type: 'string',
        },
        includeTotals: {
          type: 'boolean',
          default: false,
        },
      },
      allowPositionals: false,
    });
    
    return {
      inputFile,
      options: values as CliArgs,
    };
  } catch (error) {
    console.error('Error parsing arguments:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const { inputFile, options } = parseCliArgs();
    
    // Read and parse the input file
    let fileContent: string;
    try {
      fileContent = readFileSync(inputFile, 'utf8');
    } catch (error) {
      console.error(`Error reading file "${inputFile}":`, error instanceof Error ? error.message : String(error));
      process.exit(1);
    }
    
    let reportData: unknown;
    try {
      reportData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error parsing JSON in file "${inputFile}":`, error instanceof Error ? error.message : String(error));
      process.exit(1);
    }
    
    // Validate the report data
    const validatedData = validateReportData(reportData);
    
    // Get the formatter and render the report
    const formatter = getFormatter(options.format);
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals,
    };
    
    const output = formatter(validatedData, renderOptions);
    
    // Write output
    if (options.output) {
      try {
        writeFileSync(options.output, output, 'utf8');
      } catch (error) {
        console.error(`Error writing to file "${options.output}":`, error instanceof Error ? error.message : String(error));
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
