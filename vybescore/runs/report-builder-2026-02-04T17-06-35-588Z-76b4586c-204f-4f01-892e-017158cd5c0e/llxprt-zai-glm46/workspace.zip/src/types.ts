/**
 * Report data model interface
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Rendering options
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Format function signature
 */
export type ReportFormatter = (data: ReportData, options: RenderOptions) => string;
