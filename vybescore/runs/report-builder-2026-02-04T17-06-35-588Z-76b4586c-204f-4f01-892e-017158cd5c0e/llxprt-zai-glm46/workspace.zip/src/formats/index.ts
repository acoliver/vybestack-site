import type { ReportFormatter } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Registry of available report formatters
 */
export const formatters: Record<string, ReportFormatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Get supported format names
 */
export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}

/**
 * Check if a format is supported
 */
export function isFormatSupported(format: string): boolean {
  return format in formatters;
}

/**
 * Get a formatter by name, throws if format is not supported
 */
export function getFormatter(format: string): ReportFormatter {
  if (!isFormatSupported(format)) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatters[format];
}
