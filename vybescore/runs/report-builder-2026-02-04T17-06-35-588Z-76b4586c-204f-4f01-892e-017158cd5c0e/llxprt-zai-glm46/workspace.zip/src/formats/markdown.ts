import type { ReportFormatter } from '../types.js';

/**
 * Format amount with exactly two decimal places, no thousands separator
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate total from all entries
 */
function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report as Markdown
 */
export const renderMarkdown: ReportFormatter = (data, options) => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  data.entries.forEach((entry) => {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  });

  // Optional total
  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
};
