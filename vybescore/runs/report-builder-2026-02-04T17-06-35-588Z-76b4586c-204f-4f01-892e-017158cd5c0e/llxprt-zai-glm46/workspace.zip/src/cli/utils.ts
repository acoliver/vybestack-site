import * as fs from 'node:fs';
import type { ReportData } from '../types.js';

/**
 * CLI arguments interface
 */
export interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parse CLI arguments from process.argv
 * Expected format: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */
export function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2); // Skip node executable and script path

  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const inputFile = args[0];
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  // Parse options
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Read and parse JSON file with validation
 */
export function readAndValidateJson(filePath: string): ReportData {
  let content: string;
  
  try {
    content = fs.readFileSync(filePath, 'utf-8');
  } catch (error) {
    const err = error as NodeJS.ErrnoException;
    if (err.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }

  // Validate the structure
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Partial<Record<string, unknown>>;

  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  // Validate each entry
  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${i}: must be an object`);
    }

    const entryObj = entry as Partial<Record<string, unknown>>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
    }
  }

  return reportData as unknown as ReportData;
}
