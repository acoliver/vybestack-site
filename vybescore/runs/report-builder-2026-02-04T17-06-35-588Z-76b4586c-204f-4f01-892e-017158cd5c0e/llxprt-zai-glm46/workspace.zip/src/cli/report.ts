#!/usr/bin/env node

import * as fs from 'node:fs';
import { parseArgs, readAndValidateJson } from './utils.js';
import { getFormatter } from '../formats/index.js';

/**
 * Main CLI entry point
 */
function main(): void {
  try {
    // Parse command line arguments
    const args = parseArgs(process.argv);

    // Read and validate JSON data
    const data = readAndValidateJson(args.inputFile);

    // Get the appropriate formatter
    const formatter = getFormatter(args.format);

    // Render the report
    const output = formatter(data, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

main();
