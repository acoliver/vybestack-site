function isValidEmail(value) {
  // Check for double dots anywhere in the email
  if (value.includes('..')) return false;

  // Check for trailing dot
  if (value.endsWith('.')) return false;

  // Check for leading dot
  if (value.startsWith('.')) return false;

  // Check for underscore in domain parts (after the last @)
  const atIndex = value.lastIndexOf('@');
  if (atIndex > 0 && atIndex < value.length - 1) {
    const domain = value.substring(atIndex + 1);
    if (domain.includes('_')) return false;
  }

  // Split by @ to validate parts
  const parts = value.split('@');
  if (parts.length < 2) return false;

  // Local part (everything before the last @)
  const localPart = parts.slice(0, -1).join('@');
  // Domain part (everything after the last @)
  const domainPart = parts[parts.length - 1];

  console.log('Email:', value);
  console.log('Parts:', parts);
  console.log('Local part:', localPart);
  console.log('Domain part:', domainPart);

  // Validate local part: alphanumeric + some special chars
  const localRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*$/;
  if (!localRegex.test(localPart)) {
    console.log('Local part validation failed');
    return false;
  }

  // Validate domain part: alphanumeric labels separated by dots, TLD 2+ chars
  const domainRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  if (!domainRegex.test(domainPart)) {
    console.log('Domain part validation failed');
    return false;
  }

  console.log('Valid!');
  return true;
}

console.log('=== Testing name@tag@example.co.uk ===');
isValidEmail('name@tag@example.co.uk');
console.log('\n=== Testing user@example.com ===');
isValidEmail('user@example.com');
