import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== Email Validation ===');
console.log('name@tag@example.co.uk:', isValidEmail('name@tag@example.co.uk')); // true (tagged email)
console.log('user@example.com:', isValidEmail('user@example.com')); // true
console.log('user..name@example.com:', isValidEmail('user..name@example.com')); // false (double dot)
console.log('user@example_.com:', isValidEmail('user@example_.com')); // false (underscore in domain)
console.log('.user@example.com:', isValidEmail('.user@example.com')); // false (leading dot)
console.log('user.@example.com:', isValidEmail('user.@example.com')); // false (trailing dot)
console.log('user@name@example.com:', isValidEmail('user@name@example.com')); // false (two @ signs without tag)
console.log('user+tag@example.com:', isValidEmail('user+tag@example.com')); // true (plus in local part)

console.log('\n=== US Phone Validation ===');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890')); // true
console.log('212-555-7890:', isValidUSPhone('212-555-7890')); // true
console.log('2125557890:', isValidUSPhone('2125557890')); // true
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890')); // true
console.log('+12125557890:', isValidUSPhone('+12125557890')); // true
console.log('012-555-7890:', isValidUSPhone('012-555-7890')); // false (area code starts with 0)
console.log('112-555-7890:', isValidUSPhone('112-555-7890')); // false (area code starts with 1)
console.log('21255:', isValidUSPhone('21255')); // false (too short)

console.log('\n=== Argentine Phone Validation ===');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678')); // true (mobile)
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678')); // true
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567')); // true
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567')); // true
console.log('341 1234567:', isValidArgentinePhone('341 1234567')); // false (no trunk prefix w/o country code)
console.log('+54 011 1234567:', isValidArgentinePhone('+54 011 1234567')); // true

console.log('\n=== Name Validation ===');
console.log('Jane Doe:', isValidName('Jane Doe')); // true
console.log('José María González:', isValidName('José María González')); // true
console.log("O'Connor:", isValidName("O'Connor")); // true
console.log('Jean-Claude:', isValidName('Jean-Claude')); // true
console.log('X Æ A-12:', isValidName('X Æ A-12')); // false
console.log('John123:', isValidName('John123')); // false
console.log('John@Doe:', isValidName('John@Doe')); // false

console.log('\n=== Credit Card Validation ===');
console.log('4111111111111111:', isValidCreditCard('4111111111111111')); // true (Visa 16)
console.log('4111111111111:', isValidCreditCard('4111111111111')); // true (Visa 13)
console.log('4111111111111111111:', isValidCreditCard('4111111111111111111')); // false (Visa 19 - too long)
console.log('5500000000000004:', isValidCreditCard('5500000000000004')); // true (Mastercard)
console.log('340000000000009:', isValidCreditCard('340000000000009')); // true (AmEx)
console.log('4111111111111112:', isValidCreditCard('4111111111111112')); // false (fails Luhn)

console.log('\n=== Transformations ===');
console.log('capitalizeSentences:', capitalizeSentences('hello.world.how are you?i am fine.'));
console.log('extractUrls:', extractUrls('Visit https://example.com/path?query=value and www.test.com.'));
console.log('enforceHttps:', enforceHttps('Go to http://example.com or https://secure.com'));
console.log('rewriteDocsUrls:', rewriteDocsUrls('See http://example.com/docs/api and http://example.com/cgi-bin/script.php'));
console.log('extractYear valid:', extractYear('12/25/2024'));
console.log('extractYear invalid month:', extractYear('13/45/2024'));
console.log('extractYear invalid format:', extractYear('2024-12-25'));

console.log('\n=== Puzzles ===');
console.log('findPrefixedWords:', findPrefixedWords('The uninterested and unhappy user underwent undoing', 'un', ['undo']));
console.log('findEmbeddedToken:', findEmbeddedToken('9123x8123y', '123'));
console.log('isStrongPassword (good):', isStrongPassword('Password!123'));
console.log('isStrongPassword (repeated abab):', isStrongPassword('Password!abab123'));
console.log('isStrongPassword (repeated 123):', isStrongPassword('Password!123123'));
console.log('containsIPv6 (full):', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log('containsIPv6 (shorthand):', containsIPv6('2001:db8::1'));
console.log('containsIPv6 (IPv4):', containsIPv6('192.168.1.1'));
console.log('containsIPv6 (mixed):', containsIPv6('::ffff:192.168.1.1'));

console.log('\n=== All edge case tests completed ===');
