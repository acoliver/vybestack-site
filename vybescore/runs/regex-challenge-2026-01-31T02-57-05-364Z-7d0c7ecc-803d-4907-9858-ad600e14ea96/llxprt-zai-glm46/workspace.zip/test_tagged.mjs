import { isValidEmail } from './dist/src/validators.js';

console.log('name@tag@example.co.uk:', isValidEmail('name@tag@example.co.uk'));
console.log('user@example.com:', isValidEmail('user@example.com'));
console.log('user@name@example.com:', isValidEmail('user@name@example.com'));
