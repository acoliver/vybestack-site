// Test various email formats
const testEmails = [
  'name@tag@example.co.uk',
  'user@example.com',
  'user+tag@example.com',
  'name.tag@example.com',
  'name_tag@example.com',
];

testEmails.forEach(email => {
  console.log(`${email}:`);
  console.log('  Has @:', email.includes('@'));
  console.log('  @ count:', (email.match(/@/g) || []).length);
  console.log('  Last @ index:', email.lastIndexOf('@'));
  console.log('  Parts:', email.split('@'));
  console.log('');
});
