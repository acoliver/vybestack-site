import { isValidCreditCard } from './dist/src/validators.js';

console.log('4222222222222 (valid 13-digit Visa):', isValidCreditCard('4222222222222'));
console.log('4111111111111111 (valid 16-digit Visa):', isValidCreditCard('4111111111111111'));
