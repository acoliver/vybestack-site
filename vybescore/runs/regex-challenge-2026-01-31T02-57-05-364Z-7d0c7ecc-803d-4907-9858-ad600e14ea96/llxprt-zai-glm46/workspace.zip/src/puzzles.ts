/**
 * Find words starting with the prefix, excluding banned words.
 * Uses word boundaries and exception list filtering.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with the prefix
  // Word boundary ensures we match whole words
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map((e) => e.toLowerCase()));

  return matches.filter((word) => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start.
 * Uses lookbehind to ensure the token is preceded by a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match a digit followed by the token
  // Use a capturing group to capture the digit + token
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab, 1212)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;

  // Check for at least one digit
  if (!/\d/.test(value)) return false;

  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;

  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This pattern captures any 2-4 character sequence and checks if it repeats immediately
  const repeatedSequencePattern = /(.{2,4})\1/;
  if (repeatedSequencePattern.test(value)) return false;

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns:
  // - Full form: 8 groups of 1-4 hex digits separated by colons
  // - Shorthand: :: can replace one or more consecutive groups of zeros
  // - Mixed: IPv4 embedded in the last 32 bits (e.g., ::ffff:192.168.1.1)
  // - Must not match IPv4-only addresses

  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // IPv6 patterns:
  // 1. Full IPv6: 8 groups of 1-4 hex digits
  const fullIPv6 = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;

  // 2. IPv6 with :: shorthand (can appear at start, middle, or end)
  const shorthandIPv6 = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/;

  // 3. IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const mixedIPv6 = /^(?:[0-9a-fA-F]{1,4}:)*:(?:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})$/;

  // Check if value contains any IPv6 pattern
  // We need to search within the string, not just match the whole string
  // Also check for common IPv6 patterns that might be embedded
  const containsIPv6 = /[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4})+/;

  return (
    fullIPv6.test(value.trim()) ||
    shorthandIPv6.test(value.trim()) ||
    mixedIPv6.test(value.trim()) ||
    (containsIPv6.test(value) && !ipv4Pattern.test(value.trim()))
  );
}
