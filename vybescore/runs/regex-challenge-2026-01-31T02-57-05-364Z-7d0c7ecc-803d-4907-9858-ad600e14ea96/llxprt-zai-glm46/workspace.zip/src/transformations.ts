/**
 * Capitalize the first character of each sentence.
 * - Capitalizes first character after .?!
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces sensibly
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces into one
  let normalized = text.replace(/\s+/g, ' ').trim();

  // Add space after sentence endings if missing (before capital letter)
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');

  // Split into sentences, capitalize first letter, and rejoin
  const sentences: string[] = [];
  let currentSentence = '';

  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    currentSentence += char;

    // Check if we've reached the end of a sentence
    if (char === '.' || char === '?' || char === '!') {
      sentences.push(currentSentence);
      currentSentence = '';
    }
  }

  // Add any remaining text
  if (currentSentence) {
    sentences.push(currentSentence);
  }

  // Capitalize first letter of each sentence
  const result = sentences
    .map((sentence) => {
      if (sentence.length === 0) return '';
      const trimmed = sentence.trimLeft();
      return sentence.substring(0, sentence.length - trimmed.length) +
             trimmed.charAt(0).toUpperCase() +
             trimmed.slice(1);
    })
    .join('');

  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  // Matches http://, https://, and www. URLs
  // Includes domain, optional port, path, query, fragment
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>]+(?:\/[^\s<>]*)?(?:\?[^\s<>]*)?(?:#[^\s<>]*)?/gi;

  const matches = text.match(urlRegex) || [];

  // Strip trailing punctuation from each URL
  return matches.map((url) => {
    return url.replace(/[.,;:!?()]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Captures: scheme, host, and rest of URL
  // eslint-disable-next-line no-useless-escape
  const urlRegex = /(https?:\/\/)([^\/\s]+)(\/[^\s]*)?/gi;

  return text.replace(urlRegex, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';

    // Check if we should rewrite the host
    // Only rewrite if:
    // 1. Host is example.com (or any subdomain pattern)
    // 2. Path starts with /docs/
    // 3. No dynamic hints in the URL

    const shouldRewriteHost = shouldRewriteDocsHost(match);

    if (shouldRewriteHost && path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      // Extract the base domain (everything before the first .)
      // For example.com -> docs.example.com
      // For api.example.com -> docs.api.example.com
      const newHost = 'docs.' + host;
      return newScheme + newHost + path;
    } else {
      // Just upgrade scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Helper to determine if a docs URL should have its host rewritten.
 */
function shouldRewriteDocsHost(url: string): boolean {
  // Skip if URL contains dynamic hints
  const skipPatterns = [
    'cgi-bin',
    '?',
    '&',
    '=',
    '.jsp',
    '.php',
    '.asp',
    '.aspx',
    '.do',
    '.cgi',
    '.pl',
    '.py',
  ];

  for (const pattern of skipPatterns) {
    if (url.includes(pattern)) {
      return false;
    }
  }

  return true;
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;

  const match = value.match(dateRegex);
  if (!match) return 'N/A';

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (01-12)
  if (month < 1 || month > 12) return 'N/A';

  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31,
    2: 29, // Allow leap years
    3: 31,
    4: 30,
    5: 31,
    6: 30,
    7: 31,
    8: 31,
    9: 30,
    10: 31,
    11: 30,
    12: 31,
  };

  const maxDays = daysInMonth[month];
  if (day < 1 || day > maxDays) return 'N/A';

  return year;
}
