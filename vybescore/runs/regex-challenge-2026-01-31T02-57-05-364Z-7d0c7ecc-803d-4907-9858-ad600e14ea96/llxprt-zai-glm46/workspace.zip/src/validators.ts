export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts: name@tag@example.co.uk (plus similar forms)
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Check for double dots anywhere in the email
  if (value.includes('..')) return false;

  // Check for trailing dot
  if (value.endsWith('.')) return false;

  // Check for leading dot
  if (value.startsWith('.')) return false;

  // Check for underscore in domain parts (after the last @)
  const atIndex = value.lastIndexOf('@');
  if (atIndex > 0 && atIndex < value.length - 1) {
    const domain = value.substring(atIndex + 1);
    if (domain.includes('_')) return false;
  }

  // Split by @ to validate parts
  const parts = value.split('@');
  if (parts.length < 2) return false;

  // Local part (everything before the last @)
  const localPart = parts.slice(0, -1).join('@');
  // Domain part (everything after the last @)
  const domainPart = parts[parts.length - 1];

  // Validate local part: alphanumeric + some special chars (including @ for tagged emails)
  // For tagged emails, each segment between @ signs must be valid
  const localSegments = localPart.split('@');
  const localSegmentRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*$/;
  for (const segment of localSegments) {
    if (!localSegmentRegex.test(segment)) return false;
  }

  // Validate domain part: alphanumeric labels separated by dots, TLD 2+ chars
  const domainRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  if (!domainRegex.test(domainPart)) return false;

  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');

  // Check minimum length (10 digits for US number)
  if (digitsOnly.length < 10) return false;

  // Remove optional +1 country code if present
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  } else if (phoneNumber.length === 11 && !phoneNumber.startsWith('1')) {
    return false; // Has 11 digits but doesn't start with 1
  } else if (phoneNumber.length > 11) {
    return false; // Too long
  }

  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;

  // Check area code - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Check if the format is valid (parentheses, dashes, or plain digits)
  // Accept formats: (XXX) XXX-XXXX, XXX-XXX-XXXX, XXXXXXXXX
  // Also allow +1 prefix with various formats
  const formattedRegex = /^(\+1\s*)?(\(\d{3}\)\s*\d{3}[-.]?\d{4}|\d{3}[-.]?\d{3}[-.]?\d{4}|\d{10})$/;
  if (!formattedRegex.test(value.replace(/ /g, ''))) {
    // Try with spaces preserved for +1 format
    const formattedWithSpaces = /^(\+1\s*)?(\(\d{3}\)\s*\d{3}[-.]?\d{4}|\d{3}[-.]?\d{3}[-.]?\d{4}|\d{10})$/;
    if (!formattedWithSpaces.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - If country code omitted, must begin with trunk prefix 0
 * - Allows single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators for validation
  const normalized = value.replace(/[-\s]/g, '');

  // Match the components
  // Optional +54, optional 0 (trunk), optional 9 (mobile), area code (2-4 digits), subscriber (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;

  // If no country code, must start with 0 (trunk prefix)
  if (!normalized.startsWith('+54') && !normalized.startsWith('0')) {
    return false;
  }

  const match = normalized.match(argentinePhoneRegex);
  if (!match) return false;

  const [, areaCode, subscriber] = match;

  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;

  // Area code leading digit must be 1-9 (already enforced by regex)
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;

  return true;
}

/**
 * Validate personal names.
 * Permits: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and "X Æ A-12" style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols (except apostrophe, hyphen, space)
  // At least one character required
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  // Check for digits
  if (/\d/.test(value)) return false;

  // Check for other symbols (not apostrophe, hyphen, space, or letters)
  const hasOtherSymbols = /[^\p{L}\p{M}'\-\s]/u.test(value);
  if (hasOtherSymbols) return false;

  // Name must have at least one letter
  if (!/\p{L}/u.test(value)) return false;

  return nameRegex.test(value);
}

/**
 * Validate credit card numbers.
 * Accepts: Visa (13-16 digits, starts with 4), Mastercard (16 digits, starts with 51-55 or 2221-2720), AmEx (15 digits, starts with 34 or 37)
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Check if it's all digits
  if (!/^\d+$/.test(cleaned)) return false;

  // Check length
  if (cleaned.length < 13 || cleaned.length > 16) return false;

  // Validate based on card type
  // Visa: 13-16 digits, starts with 4
  const isVisa = cleaned.startsWith('4') && cleaned.length >= 13 && cleaned.length <= 16;
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const isMastercard = cleaned.length === 16 && /^(?:5[1-5]\d{2}|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)/.test(cleaned);
  // AmEx: 15 digits, starts with 34 or 37
  const isAmex = cleaned.length === 15 && /^3[47]/.test(cleaned);

  if (!isVisa && !isMastercard && !isAmex) return false;

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}
