import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== FINAL COMPREHENSIVE TEST ===\n');

let passCount = 0;
let failCount = 0;

function test(description, actual, expected) {
  const result = actual === expected ? '✓' : '✗';
  if (actual === expected) {
    passCount++;
  } else {
    failCount++;
    console.log(`${result} ${description}`);
    console.log(`  Expected: ${expected}, Got: ${actual}`);
  }
}

console.log('--- Email Validation ---');
test('Tagged email should be valid', isValidEmail('name@tag@example.co.uk'), true);
test('Simple email should be valid', isValidEmail('user@example.com'), true);
test('Double dot should be invalid', isValidEmail('user..name@example.com'), false);
test('Underscore in domain should be invalid', isValidEmail('user@example_.com'), false);
test('Leading dot should be invalid', isValidEmail('.user@example.com'), false);
test('Trailing dot should be invalid', isValidEmail('user.@example.com'), false);

console.log('\n--- US Phone Validation ---');
test('Parentheses format should be valid', isValidUSPhone('(212) 555-7890'), true);
test('Dashes format should be valid', isValidUSPhone('212-555-7890'), true);
test('Plain digits should be valid', isValidUSPhone('2125557890'), true);
test('+1 with space should be valid', isValidUSPhone('+1 212-555-7890'), true);
test('Area code starting with 0 should be invalid', isValidUSPhone('012-555-7890'), false);
test('Area code starting with 1 should be invalid', isValidUSPhone('112-555-7890'), false);
test('Too short should be invalid', isValidUSPhone('21255'), false);

console.log('\n--- Argentine Phone Validation ---');
test('Mobile with country code should be valid', isValidArgentinePhone('+54 9 11 1234 5678'), true);
test('Buenos Aires landline should be valid', isValidArgentinePhone('011 1234 5678'), true);
test('Rosario landline with country code should be valid', isValidArgentinePhone('+54 341 123 4567'), true);
test('Rosario with trunk prefix should be valid', isValidArgentinePhone('0341 4234567'), true);
test('No trunk prefix without country code should be invalid', isValidArgentinePhone('341 1234567'), false);

console.log('\n--- Name Validation ---');
test('Simple name should be valid', isValidName('Jane Doe'), true);
test('Name with accents should be valid', isValidName('José María González'), true);
test('Name with apostrophe should be valid', isValidName("O'Connor"), true);
test('Name with hyphen should be valid', isValidName('Jean-Claude'), true);
test('Name with digits should be invalid', isValidName('X Æ A-12'), false);
test('Name with symbol should be invalid', isValidName('John@Doe'), false);

console.log('\n--- Credit Card Validation ---');
test('Valid Visa 16-digit should be valid', isValidCreditCard('4111111111111111'), true);
test('Valid Visa 13-digit should be valid', isValidCreditCard('4222222222222'), true);
test('Valid Mastercard should be valid', isValidCreditCard('5500000000000004'), true);
test('Valid AmEx should be valid', isValidCreditCard('340000000000009'), true);
test('Invalid Luhn should be invalid', isValidCreditCard('4111111111111112'), false);

console.log('\n--- Transformations ---');
const capitalized = capitalizeSentences('hello.world.how are you?i am fine.');
console.log(`✓ capitalizeSentences: "${capitalized}"`);

const urls = extractUrls('Visit https://example.com/path?query=value and www.test.com.');
console.log(`✓ extractUrls:`, urls);

const https = enforceHttps('Go to http://example.com');
test('enforceHttps should upgrade to https', https, 'Go to https://example.com');

const rewritten = rewriteDocsUrls('See http://example.com/docs/api');
test('rewriteDocsUrls should rewrite docs host', rewritten, 'See https://docs.example.com/docs/api');

test('extractYear valid date', extractYear('12/25/2024'), '2024');
test('extractYear invalid month', extractYear('13/45/2024'), 'N/A');
test('extractYear invalid format', extractYear('2024-12-25'), 'N/A');

console.log('\n--- Puzzles ---');
const prefixed = findPrefixedWords('The uninterested and unhappy user underwent undoing', 'un', ['undo']);
console.log(`✓ findPrefixedWords:`, prefixed);

const embedded = findEmbeddedToken('9123x8123y', '123');
console.log(`✓ findEmbeddedToken:`, embedded);

test('Strong password should be valid', isStrongPassword('Password!123'), true);
test('Password with repeated sequence should be invalid', isStrongPassword('Password!abab123'), false);

test('IPv6 full form should be detected', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'), true);
test('IPv6 shorthand should be detected', containsIPv6('2001:db8::1'), true);
test('IPv4 should not be detected as IPv6', containsIPv6('192.168.1.1'), false);

console.log(`\n=== SUMMARY ===`);
console.log(`Passed: ${passCount}`);
console.log(`Failed: ${failCount}`);
console.log(failCount === 0 ? '\n✓ All tests passed!' : `\n✗ ${failCount} tests failed`);
