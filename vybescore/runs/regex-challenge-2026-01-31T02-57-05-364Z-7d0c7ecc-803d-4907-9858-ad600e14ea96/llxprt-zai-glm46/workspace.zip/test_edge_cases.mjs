// Edge case testing
import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './dist/src/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './dist/src/puzzles.js';

console.log('=== Email Edge Cases ===');
console.log('name@tag@example.co.uk:', isValidEmail('name@tag@example.co.uk')); // Should accept
console.log('user..name@example.com:', isValidEmail('user..name@example.com')); // Should reject (double dot)
console.log('user@name@example.com:', isValidEmail('user@name@example.com')); // Should accept
console.log('user@example_.com:', isValidEmail('user@example_.com')); // Should reject (underscore in domain)
console.log('.user@example.com:', isValidEmail('.user@example.com')); // Should reject (leading dot)
console.log('user.@example.com:', isValidEmail('user.@example.com')); // Should reject (trailing dot)

console.log('\n=== US Phone Edge Cases ===');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890')); // Should accept
console.log('212-555-7890:', isValidUSPhone('212-555-7890')); // Should accept
console.log('2125557890:', isValidUSPhone('2125557890')); // Should accept
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890')); // Should accept
console.log('012-555-7890:', isValidUSPhone('012-555-7890')); // Should reject (area code starts with 0)
console.log('112-555-7890:', isValidUSPhone('112-555-7890')); // Should reject (area code starts with 1)
console.log('21255:', isValidUSPhone('21255')); // Should reject (too short)

console.log('\n=== Argentine Phone Edge Cases ===');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678')); // Should accept (mobile)
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678')); // Should accept (Buenos Aires)
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567')); // Should accept (Rosario landline)
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567')); // Should accept
console.log('341 1234567:', isValidArgentinePhone('341 1234567')); // Should reject (no trunk prefix without country code)
console.log('+54 011 1234567:', isValidArgentinePhone('+54 011 1234567')); // Should accept

console.log('\n=== Name Edge Cases ===');
console.log('Jane Doe:', isValidName('Jane Doe')); // Should accept
console.log('José María González:', isValidName('José María González')); // Should accept (accents)
console.log("O'Connor:", isValidName("O'Connor")); // Should accept (apostrophe)
console.log('Jean-Claude:', isValidName('Jean-Claude')); // Should accept (hyphen)
console.log('X Æ A-12:', isValidName('X Æ A-12')); // Should reject (contains digits/symbols)
console.log('John123:', isValidName('John123')); // Should reject (digits)
console.log('John@Doe:', isValidName('John@Doe')); // Should reject (symbol)

console.log('\n=== Credit Card Edge Cases ===');
console.log('4111111111111111:', isValidCreditCard('4111111111111111')); // Should accept (Visa)
console.log('5500000000000004:', isValidCreditCard('5500000000000004')); // Should accept (Mastercard)
console.log('340000000000009:', isValidCreditCard('340000000000009')); // Should accept (AmEx)
console.log('4111111111111:', isValidCreditCard('4111111111111')); // Should accept (Visa 13 digits)
console.log('4111111111111112:', isValidCreditCard('4111111111111112')); // Should reject (fails Luhn)

console.log('\n=== Transformations Edge Cases ===');
console.log('capitalizeSentences:', capitalizeSentences('hello.world.how are you?i am fine.'));
console.log('extractUrls:', extractUrls('Visit https://example.com/path?query=value and www.test.com.'));
console.log('enforceHttps:', enforceHttps('Go to http://example.com or https://secure.com'));
console.log('rewriteDocsUrls:', rewriteDocsUrls('See http://example.com/docs/api and http://example.com/cgi-bin/script.php'));
console.log('extractYear valid:', extractYear('12/25/2024'));
console.log('extractYear invalid:', extractYear('13/45/2024'));
console.log('extractYear invalid format:', extractYear('2024-12-25'));

console.log('\n=== Puzzles Edge Cases ===');
console.log('findPrefixedWords:', findPrefixedWords('The uninterested and unhappy user underwent undoing', 'un', ['undo']));
console.log('findEmbeddedToken:', findEmbeddedToken('abc123def456ghi', '123'));
console.log('isStrongPassword (weak):', isStrongPassword('password123')); // Too short, no uppercase/symbol
console.log('isStrongPassword (weak):', isStrongPassword('Password123')); // No symbol
console.log('isStrongPassword (good):', isStrongPassword('Password!123')); // Good
console.log('isStrongPassword (repeated):', isStrongPassword('Password!abab123')); // Repeated sequence
console.log('containsIPv6 (IPv6):', containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334'));
console.log('containsIPv6 (shorthand):', containsIPv6('2001:db8::1'));
console.log('containsIPv6 (IPv4):', containsIPv6('192.168.1.1'));
