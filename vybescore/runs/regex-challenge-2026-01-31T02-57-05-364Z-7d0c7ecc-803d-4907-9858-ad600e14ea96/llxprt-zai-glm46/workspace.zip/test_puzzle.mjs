import { findEmbeddedToken, isStrongPassword } from './dist/src/puzzles.js';

console.log('=== findEmbeddedToken tests ===');
console.log('Text: "test123token", token: "123":', findEmbeddedToken('test123token', '123'));
console.log('Text: "123token", token: "123":', findEmbeddedToken('123token', '123')); // Should NOT match (at start)
console.log('Text: "a123b123c", token: "123":', findEmbeddedToken('a123b123c', '123')); // Should NOT match (not after digit)
console.log('Text: "9123x8123y", token: "123":', findEmbeddedToken('9123x8123y', '123')); // Should match twice

console.log('\n=== isStrongPassword tests ===');
console.log('Password!123:', isStrongPassword('Password!123')); // Should be true
console.log('Password!abab123:', isStrongPassword('Password!abab123')); // Should be false (abab repeated)
console.log('Password!123123:', isStrongPassword('Password!123123')); // Should be false (123 repeated)
