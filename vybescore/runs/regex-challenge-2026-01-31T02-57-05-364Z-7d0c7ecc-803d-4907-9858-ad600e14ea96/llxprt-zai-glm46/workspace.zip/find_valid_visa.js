function runLuhnCheck(cardNumber) {
  let sum = 0;
  let shouldDouble = false;

  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

// Find a valid 13-digit Visa
for (let i = 0; i < 10; i++) {
  const card = '422222222222' + i;
  if (runLuhnCheck(card)) {
    console.log('Valid 13-digit Visa:', card);
    break;
  }
}
