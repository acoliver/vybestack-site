import initSqlJs from 'sql.js';
import path from 'path';
import { readFileSync, existsSync } from 'fs';


export interface DatabaseInstance {
  prepare: (query: string) => {
    run: (params: unknown[]) => void;
    free: () => void;
  };
  exec: (query: string) => void;
  export: () => Uint8Array;
  close: () => void;
}

export default async function initDatabase(): Promise<DatabaseInstance> {
  // Use relative path to node_modules
  const sqlJsPath = path.join(process.cwd(), 'node_modules/sql.js/dist/');
  
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(sqlJsPath, file)
  });

  const dbFilePath = path.join(process.cwd(), 'data/submissions.sqlite');
  let db: DatabaseInstance;

  if (existsSync(dbFilePath)) {
    // Load existing database
    const fileBuffer = readFileSync(dbFilePath);
    db = new SQL.Database(fileBuffer) as DatabaseInstance;
  } else {
    // Create new database
    db = new SQL.Database() as DatabaseInstance;
    
    // Create submissions table
    const schema = readFileSync(path.join(process.cwd(), 'db/schema.sql'), 'utf-8');
    db.exec(schema);
  }

  return db;
}