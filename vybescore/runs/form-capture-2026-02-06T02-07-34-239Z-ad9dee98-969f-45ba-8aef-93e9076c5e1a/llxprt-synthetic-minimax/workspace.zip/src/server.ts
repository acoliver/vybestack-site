// TODO: Implement Express server, SQLite integration, routes, and graceful shutdown.
import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initDatabase from './database.js';
import type { DatabaseInstance } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^@?[\d\s\-()]{7,}$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (UK "SW1A 1AA", US "90210", Argentina "C1000", etc.)
  const postalRegex = /^[A-Za-z0-9\s-]{3,12}$/;
  return postalRegex.test(postalCode);
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

// Initialize database
let db: DatabaseInstance | undefined;

async function startServer() {
  try {
    db = await initDatabase();

    // Routes
    app.get('/', (req, res) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    app.post('/submit', async (req, res) => {
      const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;
      
      const errors: string[] = [];
      const values: Record<string, string> = {
        firstName: firstName || '',
        lastName: lastName || '',
        streetAddress: streetAddress || '',
        city: city || '',
        stateProvince: stateProvince || '',
        postalCode: postalCode || '',
        country: country || '',
        email: email || '',
        phone: phone || ''
      };

      // Validate all fields
      if (!validateRequired(firstName)) errors.push('First name is required');
      if (!validateRequired(lastName)) errors.push('Last name is required');
      if (!validateRequired(streetAddress)) errors.push('Street address is required');
      if (!validateRequired(city)) errors.push('City is required');
      if (!validateRequired(stateProvince)) errors.push('State / Province / Region is required');
      if (!validateRequired(postalCode)) errors.push('Postal / Zip code is required');
      if (!validateRequired(country)) errors.push('Country is required');
      if (!validateRequired(email)) errors.push('Email is required');
      if (!validateRequired(phone)) errors.push('Phone number is required');

      // Email validation
      if (email && !validateEmail(email)) {
        errors.push('Please enter a valid email address');
      }

      // Phone validation
      if (phone && !validatePhone(phone)) {
        errors.push('Please enter a valid phone number');
      }

      // Postal code validation
      if (postalCode && !validatePostalCode(postalCode)) {
        errors.push('Please enter a valid postal code');
      }

      // If validation fails, re-render form with errors
      if (errors.length > 0) {
        res.status(400).render('form', {
          errors,
          values
        });
        return;
      }

      // Insert into database
      try {
        if (!db) {
          throw new Error('Database not initialized');
        }

        const stmt = db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province,
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          firstName.trim(),
          lastName.trim(), 
          streetAddress.trim(),
          city.trim(),
          stateProvince.trim(),
          postalCode.trim(),
          country.trim(),
          email.trim(),
          phone.trim()
        ]);

        // Close statement
        stmt.free();

        // Export database to file
        const data = db.export();
        const fs = await import('fs/promises');
        await fs.writeFile(path.join(process.cwd(), 'data/submissions.sqlite'), Buffer.from(data));

        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (dbError) {
        console.error('Database error:', dbError);
        res.status(500).send('Database error occurred');
      }
    });

    app.get('/thank-you', (req, res) => {
      res.render('thank-you', {
        firstName: 'User' // We'll use a generic name since we're redirecting
      });
    });

    // Graceful shutdown
    process.on('SIGTERM', async () => {
      console.log('Shutting down gracefully...');
      if (db) {
        db.close();
      }
      process.exit(0);
    });

    process.on('SIGINT', async () => {
      console.log('Shutting down gracefully...');
      if (db) {
        db.close();
      }
      process.exit(0);
    });

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
