#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';
import { ReportData, ReportEntry } from '../types/report.js';

// Formatter registry
const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
} as const;

type Format = keyof typeof formatters;

interface CliOptions {
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): { dataFile: string; options: CliOptions } {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  let format: Format | undefined;
  let output: string | undefined;
  let includeTotals = false;
  
  // Parse flags
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[++i] as Format;
    } else if (arg === '--output' && i + 1 < args.length) {
      output = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format flag is required');
    process.exit(1);
  }
  
  if (!formatters[format]) {
    console.error(`Error: Unsupported format '${format}'. Supported formats: ${Object.keys(formatters).join(', ')}`);
    process.exit(1);
  }
  
  return {
    dataFile,
    options: {
      format,
      output,
      includeTotals,
    },
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const report = data as Partial<ReportData>;
  
  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: missing required field "title"');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: missing required field "summary"');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: missing required field "entries"');
  }
  
  const entries = report.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${index} must be an object`);
    }
    
    const partialEntry = entry as Partial<ReportEntry>;
    
    if (typeof partialEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing required field "label"`);
    }
    
    if (typeof partialEntry.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} missing required field "amount"`);
    }
    
    return partialEntry as ReportEntry;
  });
  
  return {
    title: report.title,
    summary: report.summary,
    entries,
  };
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv);
    
    // Validate data file argument
    if (!dataFile || dataFile.startsWith('--')) {
      console.error('Error: data file path is required as first argument');
      process.exit(1);
    }
    
    // Read and parse JSON
    const fileContent = readFileSync(dataFile, 'utf-8');
    const jsonData = JSON.parse(fileContent);
    
    // Validate data
    const reportData = validateReportData(jsonData);
    
    // Render report
    const formatter = formatters[options.format];
    const output = formatter.render(reportData, { includeTotals: options.includeTotals });
    
    // Output to file or stdout
    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Unknown error occurred');
    }
    process.exit(1);
  }
}

main();
