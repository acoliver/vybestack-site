import { Formatter, ReportData, RenderOptions } from '../types/report.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const textFormatter: Formatter = {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push(''); // blank line
    
    // Summary
    lines.push(data.summary);
    lines.push(''); // blank line
    
    // Entries heading
    lines.push('Entries:');
    
    // Entries
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      lines.push(''); // blank line before total
      const total = calculateTotal(data.entries);
      lines.push(`Total: ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  }
};