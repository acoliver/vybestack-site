import type { Formatter, FormatType } from '../types.js';
import { markdownFormatter } from './markdown.js';
import { textFormatter } from './text.js';

export const formatters: Record<FormatType, Formatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

export { markdownFormatter, textFormatter };
export type { Formatter };