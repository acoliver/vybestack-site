import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server.js';

let server: { app: import('express').Express; server: import('http').Server };
let app: import('express').Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = await startServer();
  app = server.app;
}, 30000);

afterAll(() => {
  if (server && server.server && server.server.close) {
    server.server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(app).get('/');
    
    expect(res.status).toBe(200);
    expect(res.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(res.text);
    
    // Check for form fields
    const fields = [
      '#firstName', '#lastName', '#streetAddress', '#city', 
      '#stateProvince', '#postalCode', '#country', '#email', '#phone'
    ];
    
    fields.forEach(selector => {
      expect($(selector).length).toBe(1);
    });
    
    // Check for form submit button
    expect($('button[type="submit"]').length).toBe(1);
    
    // Check for no errors initially
    expect($('.error-list').length).toBe(0);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form
    const res = await request(app).post('/submit').send(formData);
    
    // Should redirect to thank-you page
    expect(res.status).toBe(302);
    expect(res.headers.location).toBe('/thank-you');
    
    // Check database file exists
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Follow redirect to thank-you page
    const thankYouRes = await request(app).get('/thank-you');
    expect(thankYouRes.status).toBe(200);
    
    const $ = cheerio.load(thankYouRes.text);
    expect($('.thankyou-card').length).toBe(1);
    expect($('h1').text()).toContain('Thank you');
  });
  
  it('shows validation errors for invalid data', async () => {
    const invalidData = {
      firstName: '', // Required
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'invalid-email', // Invalid email
      phone: '+1 555-123-4567'
    };
    
    const res = await request(app).post('/submit').send(invalidData);
    
    // Should re-render form with errors
    expect(res.status).toBe(400);
    
    const $ = cheerio.load(res.text);
    
    // Should have error messages
    expect($('.error-list').length).toBe(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
    
    // Form should have previously entered values
    expect($('input[name="lastName"]').val()).toBe('Doe');
    expect($('input[name="city"]').val()).toBe('New York');
  });
});
