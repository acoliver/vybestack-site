import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type FormData = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

// Database instance - will be properly typed after initialization
interface Database {
  run(sql: string, ...params: unknown[]): void;
  export(): Uint8Array;
  close(): void;
}

let db: Database | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');
const schemaPath = path.resolve('db', 'schema.sql');

async function initDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load existing database or create new one
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    } else {
      dbData = new Uint8Array(0);
    }
    
    const SQL = await initSqlJs();
    db = new SQL.Database(dbData);
    
    // Initialize schema if new database
    if (!fs.existsSync(dbPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
      saveDatabase();
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  try {
    if (!db) return;
    
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

function validateForm(data: Partial<FormData>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields validation
  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  }
  
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  }
  
  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }
  
  // Email validation
  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone validation (international format with optional + at beginning)
  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else {
    // Remove spaces and check if it contains only allowed characters
    const cleanedPhone = data.phone.replace(/\s/g, '');
    if (!/^\+?[0-9\-()]+$/.test(cleanedPhone)) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
    }
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Start server
async function startServer(): Promise<{ app: express.Express, server: import('http').Server }> {
  await initDatabase();
  
  const app = express();
  const port = process.env.PORT || 3535;
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Static files
  app.use('/public', express.static(path.resolve('public')));
  
  // Routes
  app.get('/', (req, res) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  });
  
  app.post('/submit', (req, res) => {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', { 
        errors: validation.errors, 
        values: formData 
      });
    }
    
    // Save to database
    try {
      if (db) {
        db.run(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);
        
        saveDatabase();
      }
    } catch (error) {
      console.error('Failed to save submission:', error);
      return res.status(500).render('form', { 
        errors: ['An error occurred while saving your submission. Please try again.'], 
        values: formData 
      });
    }
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  });
  
  app.get('/thank-you', (req, res) => {
    // We could fetch the latest submission to get the first name,
    // but for simplicity, we'll just pass a placeholder
    res.render('thank-you', { firstName: 'friend' });
  });
  
  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.resolve(__dirname, 'templates'));
  
  const server = app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
  });
  
  // Graceful shutdown
  const shutdown = () => {
    console.log('Shutting down server...');
    if (db) {
      db.close();
      console.log('Database closed');
    }
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
  
  return { app, server };
}

// If this file is run directly, start the server
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { startServer, db, validateForm };
