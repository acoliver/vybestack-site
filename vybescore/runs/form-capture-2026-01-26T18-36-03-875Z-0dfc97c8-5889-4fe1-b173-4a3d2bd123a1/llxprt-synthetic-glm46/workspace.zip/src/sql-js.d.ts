declare module 'sql.js' {
  interface Database {
    run(sql: string, ...params: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }
  
  interface InitSqlJsOptions {
    locateFile?: (file: string) => string;
  }
  
  interface InitSqlJsJs {
    Database: {
      new(data?: Uint8Array): Database;
    };
  }
  
  function initSqlJs(options?: InitSqlJsOptions): Promise<InitSqlJsJs>;
  
  export = initSqlJs;
}