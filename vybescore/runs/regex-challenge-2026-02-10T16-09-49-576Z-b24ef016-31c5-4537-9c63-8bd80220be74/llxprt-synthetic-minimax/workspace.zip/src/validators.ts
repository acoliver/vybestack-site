export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with comprehensive checks
  // Unicode letters and numbers, optional special chars in local part
  const emailPattern = /^[\p{L}\p{N}]([\p{L}\p{N}._+-]*[\p{L}\p{N}])?@[\p{L}\p{N}]([\p{L}\p{N}.-]*[\p{L}\p{N}])?\.[\p{L}\p{N}]([\p{L}\p{N}.-]*[\p{L}\p{N}])?$/u;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional validation rules
  if (value.includes('..')) {  // Reject double dots
    return false;
  }
  
  if (value.endsWith('.')) {  // Reject trailing dot
    return false;
  }
  
  if (value.match(/@[\w.-]*_[\w.-]*\./)) {  // Reject domains with underscores
    return false;
  }
  
  // Ensure only one @ symbol
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleaned = value.replace(/\D/g, '');
  
  // Check for valid US phone patterns
  // Pattern 1: +1 followed by 10 digits
  const pattern1 = /^\+?1[2-9]\d{2}[2-9]\d{2}\d{4}$/;
  
  // Pattern 2: 10 digits (direct)
  const pattern2 = /^[2-9]\d{2}[2-9]\d{2}\d{4}$/;
  
  if (pattern1.test(cleaned) || pattern2.test(cleaned)) {
    return true;
  }
  
  // Additional validation with original formatting
  // Allow common US phone formats
  const formattedPattern = /^(?:\+?1[\s.-]?)?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  const match = value.match(formattedPattern);
  
  if (!match) {
    return false;
  }
  
  // Extract and validate components
  const areaCode = match[1];
  const exchangeCode = match[2];
  
  // Area codes cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange codes cannot start with 0 or 1  
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Must be exactly 10 digits when formatted
  if (cleaned.length < 10) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-+ characters for validation
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Remove any + for pattern matching  
  const numericOnly = cleaned.replace(/\+/g, '');
  
  // Extract components for validation
  let match;
  if (cleaned.startsWith('+54')) {
    // Country code 54 - now check if it's mobile format
    if (cleaned.startsWith('+549')) {
      // Mobile format: +549 + area (2-4) + subscriber (6-8)
      match = cleaned.match(/^\+549(\d{2,4})(\d{6,8})$/);
    } else {
      // Landline format: +54 + area (2-4) + subscriber (6-8)
      match = cleaned.match(/^\+54(\d{2,4})(\d{6,8})$/);
    }
  } else {
    // Without country code - must start with trunk prefix 0
    if (!numericOnly.startsWith('0')) {
      return false;
    }
    
    // Check if mobile (after trunk prefix 0, if next digit is 9 it's mobile)
    const afterTrunk = numericOnly.substring(1);
    if (afterTrunk.startsWith('9')) {
      // Mobile without country code: 0 + 9 + area (2-4) + subscriber (6-8)
      match = numericOnly.match(/^09(\d{2,4})(\d{6,8})$/);
    } else {
      // Landline without country code: 0 + area (2-4) + subscriber (6-8)
      match = numericOnly.match(/^0(\d{2,4})(\d{6,8})$/);
    }
  }
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code validation: must be 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Pattern to match valid names:
  // - Unicode letters (any language)
  // - Accents and diacriticals
  // - Spaces (for multi-word names)  
  // - Apostrophes (O'Connor, D'Angelo)
  // - Hyphens (Mary-Jane, Smith-Jones)
  // - Single quotes at boundaries (can't be in middle of name)
  const namePattern = /^[\p{L}]([\p{L}\s'-]*[\p{L}])?$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Must start and end with letters (after trimming)
  const trimmed = value.trim();
  if (!/^[\p{L}]/u.test(trimmed) || !/[\p{L}]$/u.test(trimmed)) {
    return false;
  }
  
  // Check for invalid patterns
  // No consecutive special characters
  if (/[\s'-]{2,}/.test(value)) {
    return false;
  }
  
  // No digits anywhere
  if (/\d/.test(value)) {
    return false;
  }
  
  // No symbols (only allow letters, spaces, apostrophes, hyphens, single quotes)
  if (/[^\p{L}\s'-]/u.test(value)) {
    return false;
  }
  
  // Prevent fantasy names like "X Æ A-12"
  if (/[ÆØÅÄÑÜÖÇ]/.test(value) && value.length <= 5) {
    // Allow common European letters but reject combinations like "Æ" unless it's a legitimate name
    // This is a heuristic check for weird combinations
    return false;
  }
  
  // Reject names that are mostly symbols or special characters
  const lettersCount = (value.match(/[\p{L}]/gu) || []).length;
  const specialCount = (value.match(/[\s'-]/g) || []).length;
  
  if (lettersCount < specialCount) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length === 0) {
    return false;
  }
  
  // Check card type patterns and lengths
  let isValidCard = false;
  const cardLength = digitsOnly.length;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (digitsOnly.startsWith('4')) {
    if (cardLength === 13 || cardLength === 16 || cardLength === 19) {
      isValidCard = true;
    }
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if (digitsOnly.startsWith('51') || digitsOnly.startsWith('52') || 
           digitsOnly.startsWith('53') || digitsOnly.startsWith('54') || 
           digitsOnly.startsWith('55') || 
           (digitsOnly.startsWith('222') && parseInt(digitsOnly.substring(0, 4)) >= 2221 && parseInt(digitsOnly.substring(0, 4)) <= 2720)) {
    if (cardLength === 16) {
      isValidCard = true;
    }
  }
  // AmEx: starts with 34 or 37, length 15
  else if (digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) {
    if (cardLength === 15) {
      isValidCard = true;
    }
  }
  
  // Must match known card patterns
  if (!isValidCard) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

// Luhn checksum algorithm for credit card validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
