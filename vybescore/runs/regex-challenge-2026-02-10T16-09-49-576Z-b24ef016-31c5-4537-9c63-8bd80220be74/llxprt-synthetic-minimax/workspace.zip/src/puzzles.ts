/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || text.trim().length === 0) {
    return [];
  }
  
  if (!prefix) {
    return [];
  }
  
  // Create a regex pattern for words starting with the prefix
  // Word boundaries to match whole words only
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordPattern = new RegExp(`\\b${escapedPrefix}[\\w-]*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const filteredMatches = matches.filter(word => {
    return !exceptionsLower.includes(word.toLowerCase());
  });
  
  // Remove duplicates while preserving order
  const uniqueMatches = [...new Set(filteredMatches)];
  
  return uniqueMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || text.trim().length === 0) {
    return [];
  }
  
  if (!token) {
    return [];
  }
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find token only when preceded by a digit (and not at string start)
  // This captures the digit followed by the token
  const digitTokenPattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'gi');
  
  const matches = text.match(digitTokenPattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // Character type requirements
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // Pattern to find any 4-character sequence that repeats immediately
  // e.g., "abab", "123123", "xyxy"
  const immediateRepeatPattern = /(.{2,})\1/;
  if (immediateRepeatPattern.test(value)) {
    return false;
  }
  
  // Check for repeated characters (like "aaaa", "bbbb")
  const repeatedCharPattern = /(.)\1{2,}/;
  if (repeatedCharPattern.test(value)) {
    return false;
  }
  
  // Check for alternating patterns that shouldn't be allowed
  // Like "abab" which is 2 characters alternating 2 times
  const alternatingPattern = /(..)\1/;
  if (alternatingPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // First, check if the entire string looks like an IPv4 address and reject immediately
  // IPv4 pattern: x.x.x.x where x is 0-255
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value)) {
    return false; // Explicitly reject IPv4 addresses
  }
  
  // Extract potential IPv6 addresses from the text
  // Look for hex digits and colons that might represent IPv6
  const ipv6CandidatePattern = /\b[0-9a-fA-F:]+\b/g;
  const candidates = value.match(ipv6CandidatePattern) || [];
  
  // IPv6 comprehensive patterns to test against candidates
  const fullIPv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // Compressed IPv6 with :: patterns
  const compressedIPv6Patterns = [
    // Start with ::
    /^::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$/,
    
    // End with ::
    /^(?:[0-9a-fA-F]{1,4}:){0,6}::$/,
    
    // Middle ::
    /^(?:[0-9a-fA-F]{1,4}:)+::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}$/,
    
    // Standard compressed patterns
    /^(?:[0-9a-fA-F]{1,4}:){1,7}:$/,
    /^:(?::[0-9a-fA-F]{1,4}){1,7}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,5}:(?::[0-9a-fA-F]{1,4}){1,2}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,4}:(?::[0-9a-fA-F]{1,4}){1,3}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,3}:(?::[0-9a-fA-F]{1,4}){1,4}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,2}:(?::[0-9a-fA-F]{1,4}){1,5}$/,
    /^[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}$/
  ];
  
  // IPv4-mapped IPv6
  const ipv4MappedIPv6Pattern = /^::ffff:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Mixed format (some groups IPv4 style)
  const mixedIPv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){6}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // Test each candidate against IPv6 patterns
  for (const candidate of candidates) {
    // Skip pure IPv4 addresses
    if (ipv4Pattern.test(candidate)) {
      continue;
    }
    
    // Test against full IPv6 pattern
    if (fullIPv6Pattern.test(candidate)) {
      return true;
    }
    
    // Test against compressed IPv6 patterns
    for (const pattern of compressedIPv6Patterns) {
      if (pattern.test(candidate)) {
        return true;
      }
    }
    
    // Test against IPv4-mapped IPv6
    if (ipv4MappedIPv6Pattern.test(candidate)) {
      return true;
    }
    
    // Test against mixed format
    if (mixedIPv6Pattern.test(candidate)) {
      return true;
    }
    
    // General IPv6 validation for compressed addresses
    if (candidate.includes(':') && /^[0-9a-fA-F:]+$/.test(candidate)) {
      const groups = candidate.split(':');
      let isValid = true;
      
      // Count empty groups (from ::)
      let emptyGroupCount = 0;
      for (let i = 0; i < groups.length; i++) {
        if (groups[i] === '') {
          emptyGroupCount++;
        } else if (groups[i].length > 4) {
          // More than 4 hex digits per group
          isValid = false;
          break;
        } else if (!/^[0-9a-fA-F]+$/.test(groups[i])) {
          // Non-hex characters
          isValid = false;
          break;
        }
      }
      
      // Validate structure
      if (emptyGroupCount > 1) {
        // Multiple :: not allowed
        isValid = false;
      } else if (emptyGroupCount === 1 && groups.length > 8) {
        // :: compresses multiple groups
        isValid = true;
      } else if (emptyGroupCount === 0 && groups.length !== 8) {
        // Without compression, must have exactly 8 groups
        isValid = false;
      }
      
      if (isValid && candidate.includes('::')) {
        return true;
      }
    }
  }
  
  return false;
}
