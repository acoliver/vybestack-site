/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // First, capitalize the first character of the text if it's lowercase
  let result = text;
  if (result.length > 0 && /[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.substring(1);
  }
  
  // Pattern to find sentence endings and capitalize following letters
  // This handles both spaced and non-spaced patterns after sentence punctuation
  const sentencePattern = /([.!?])(?:\s*)([a-z])/g;
  
  result = result.replace(sentencePattern, (match, punctuation, lowercase) => {
    return punctuation + ' ' + lowercase.toUpperCase();
  });
  
  // Handle abbreviations by not capitalizing after common abbreviations
  // This is a simplified approach - real implementation would need a comprehensive list
  const abbreviations = ['Mr.', 'Mrs.', 'Ms.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'etc.', 'e.g.', 'i.e.', 'vs.', 'cf.'];
  
  for (const abbrev of abbreviations) {
    // Find abbreviation followed by sentence end
    const abbrevPattern = new RegExp(`(${abbrev.replace('.', '\\.')})\\s+([A-Z])`, 'g');
    result = result.replace(abbrevPattern, (match, abbreviation, nextChar) => {
      // Don't capitalize after abbreviations unless it's a proper sentence ending
      return abbreviation + ' ' + nextChar.toLowerCase();
    });
  }
  
  // Ensure proper spacing between sentences
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || text.trim().length === 0) {
    return [];
  }
  
  // Comprehensive URL pattern matching
  // Matches http/https URLs and www URLs with common formats
  // Allow periods in domains and paths, stop at sentence punctuation or whitespace
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"{}|\\^`[\]]+\b/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs - remove trailing punctuation
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that shouldn't be part of the URL
    let cleanUrl = url.replace(/[.,;!?]+$/, '');
    
    // Handle www URLs by adding http:// if missing scheme
    if (cleanUrl.startsWith('www.')) {
      cleanUrl = 'http://' + cleanUrl;
    }
    
    return cleanUrl;
  });
  
  // Remove duplicates
  return [...new Set(cleanUrls)];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // Replace http:// with https:// while preserving existing https:// URLs
  // Pattern: http:// followed by domain/path
  const httpPattern = /http:\/\/([^\s<>"{}|\\^`[\]]+)/gi;
  
  return text.replace(httpPattern, (match, rest) => {
    return 'https://' + rest;
  });
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || text.trim().length === 0) {
    return text;
  }
  
  // Pattern to match HTTP URLs and capture the full URL
  const httpUrlPattern = /http:\/\/([^\s<>"{}|\\^`[\]]+)/gi;
  
  return text.replace(httpUrlPattern, (match, fullUrl) => {
    // Split the URL into components
    // The captured fullUrl will be "domain/path" so we need to reconstruct
    const urlParts = fullUrl.split('/');
    const domain = urlParts[0]; // First part is the domain
    
    // Check if path starts with /docs/ by looking in the captured URL
    const hasDocsPath = fullUrl.includes('/docs/');
    
    // Check for dynamic hints or legacy extensions that should skip host rewrite
    const hasDynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$))/i.test(fullUrl);
    
    let resultUrl = '';
    
    if (hasDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.domain for /docs/ paths (excluding dynamic hints)
      resultUrl = `https://docs.${domain}${fullUrl.substring(domain.length)}`;
    } else {
      // Just upgrade protocol, keep original domain
      resultUrl = `https://${fullUrl}`;
    }
    
    return resultUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || value.trim().length === 0) {
    return 'N/A';
  }
  
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate year (reasonable range)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  // Additional basic validation for impossible dates
  // Check for impossible month-day combinations
  const thirtyDayMonths = [4, 6, 9, 11];
  if (thirtyDayMonths.includes(month) && day > 30) {
    return 'N/A';
  }
  
  // Check February (28/29 days depending on leap year)
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    const maxDay = isLeapYear ? 29 : 28;
    if (day > maxDay) {
      return 'N/A';
    }
  }
  
  return year.toString();
}
