import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { Server as HttpServer } from 'node:http';
import { startServer } from '../../dist/server.js';

let server: HttpServer | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server
  server = await startServer();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all required fields', async () => {
    const response = await fetch('http://localhost:3535/');
    expect(response.status).toBe(200);
    
    const html = await response.text();
    expect(html).toContain('First Name');
    expect(html).toContain('Last Name');
    expect(html).toContain('Street Address');
    expect(html).toContain('City');
    expect(html).toContain('State/Province/Region');
    expect(html).toContain('Postal/ZIP Code');
    expect(html).toContain('Country');
    expect(html).toContain('Email Address');
    expect(html).toContain('Phone Number');
    expect(html).toContain('Submit My Information');
  });

  it('validates and persists form submission with redirect', async () => {
    const formData = new URLSearchParams({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1-555-1234'
    });

    const response = await fetch('http://localhost:3535/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData,
      redirect: 'manual'
    });

    // Should redirect to thank-you page (302)
    expect(response.status).toBe(302);
    expect(response.headers.get('location')).toBe('/thank-you');
  });

  it('re-renders form with validation errors on invalid data', async () => {
    const formData = new URLSearchParams({
      firstName: 'John',
      lastName: '', // Empty last name - should cause validation error
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'invalid-email', // Invalid email
      phone: '+1-555-1234'
    });

    const response = await fetch('http://localhost:3535/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData
    });

    expect(response.status).toBe(400);
    const html = await response.text();
    expect(html).toContain('Last name is required');
    expect(html).toContain('Please enter a valid email address');
  });

  it('shows thank you page after successful submission', async () => {
    // First submit a valid form to get redirected
    const formData = new URLSearchParams({
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'Somewhere',
      stateProvince: 'Province',
      postalCode: 'A1A 1A1',
      country: 'Canada',
      email: 'jane@example.com',
      phone: '+1-555-5678'
    });

    await fetch('http://localhost:3535/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData
    });

    // Now fetch the thank you page directly
    const response = await fetch('http://localhost:3535/thank-you');
    expect(response.status).toBe(200);
    
    const html = await response.text();
    expect(html).toContain('Thank You So Much');
    expect(html).toContain('What Happens Next');
  });

  it('stores data in SQLite database', async () => {
    // Submit a form to create database entry
    const formData = new URLSearchParams({
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '789 Test St',
      city: 'Testville',
      stateProvince: 'Test Province',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'test@example.com',
      phone: '+44 20 7946 0958'
    });

    await fetch('http://localhost:3535/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData
    });

    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
