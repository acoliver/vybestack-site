/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed value is being tracked by another observer
    }
    // Only re-evaluate if we don't have a current value or if being tracked
    if (o.value === undefined || getActiveObserver()) {
      const newValue = o.updateFn(o.value)
      o.value = newValue
    }
    return o.value!
  }
  
  // Initial evaluation only if no value provided
  if (value === undefined) {
    updateObserver(o)
  }
  return read
}
