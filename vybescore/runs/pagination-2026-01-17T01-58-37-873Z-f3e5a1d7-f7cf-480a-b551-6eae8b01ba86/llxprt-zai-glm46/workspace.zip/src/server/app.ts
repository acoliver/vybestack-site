import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

const MAX_LIMIT = 100;

function validatePageLimit(
  pageParam: string | undefined,
  limitParam: string | undefined
): { page: number; limit: number } | never {
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : 5;

  if (pageParam !== undefined) {
    if (!/^\d+$/.test(pageParam)) {
      throw new Error('page must be a positive integer');
    }
    if (page <= 0) {
      throw new Error('page must be greater than 0');
    }
  }

  if (limitParam !== undefined) {
    if (!/^\d+$/.test(limitParam)) {
      throw new Error('limit must be a positive integer');
    }
    if (limit <= 0) {
      throw new Error('limit must be greater than 0');
    }
    if (limit > MAX_LIMIT) {
      throw new Error(`limit must not exceed ${MAX_LIMIT}`);
    }
  }

  return { page, limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    try {
      const { page, limit } = validatePageLimit(
        req.query.page as string | undefined,
        req.query.limit as string | undefined
      );

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid request';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
