/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  updateObserver,
  subscribe,
  EqualFn,
  Subject
} from '../types/reactive.js'

// Global registry to track all computed values and their dependencies
const computedRegistry = new WeakMap<Observer<any>, Set<() => void>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let computedValue = value
  
  const computedObserver: Observer<T> = {
    name: options?.name,
    value: computedValue,
    updateFn: (_current) => {
      // Call updateFn to get new value
      const newValue = updateFn(computedValue)
      computedValue = newValue
      return newValue
    },
  }
  
  // Set to track dependencies for this computed value
  const dependencies = new Set<() => void>()
  computedRegistry.set(computedObserver, dependencies)
  
  const computedGetter: GetterFn<T> = (): T => {
    // Always track dependencies to ensure they're established
    const currentDependencies = computedRegistry.get(computedObserver) || dependencies
    
    // Monkey patch the global subscribe to track dependencies
    const patchedSubscribe = <U>(subject: Subject<U>, observer: Observer<U>) => {
      const unsubscribe = subscribe(subject, observer)
      currentDependencies.add(unsubscribe)
      return unsubscribe
    }
    
    const globalNamespace = globalThis as Record<string, unknown>
    const originalGlobalSubscribe = globalNamespace.subscribe
    
    try {
      globalNamespace.subscribe = patchedSubscribe
      updateObserver(computedObserver)
      computedValue = computedObserver.value
    } finally {
      if (originalGlobalSubscribe) {
        globalNamespace.subscribe = originalGlobalSubscribe
      } else {
        delete globalNamespace.subscribe
      }
    }
    
    return computedValue
  }

  return computedGetter
}
