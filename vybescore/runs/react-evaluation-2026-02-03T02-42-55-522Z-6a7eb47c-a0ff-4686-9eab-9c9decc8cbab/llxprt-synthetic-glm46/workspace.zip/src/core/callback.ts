/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn,
  updateObserver,
  subscribe,
  Subject
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const subscriptions = new Set<() => void>()
  
  // Create a special observer that will trigger when dependencies change
  const callbackObserver: Observer<T> = {
    value,
    updateFn: (currentValue) => {
      // Execute the update function which should perform side effects
      const result = updateFn(currentValue)
      
      // Return the result to update the observer's value
      return result
    },
  }
  
  // Execute callback to track its dependencies
  const setupCallback = () => {
    // Set up a global intercept for subscribe calls during callback execution
    const globalNamespace = globalThis as Record<string, unknown>
    
    // Store original subscribe function
    const originalSubscribe = globalNamespace.subscribe
    
    try {
      // Monkey patch to track subscriptions
      globalNamespace.subscribe = <U>(subject: Subject<U>, observer: Observer<U>) => {
        if (disposed) {
          return () => {} // no-op if disposed
        }
        
        // Call actual subscribe and track the unsubscribe function
        const unsubscribe = subscribe(subject, observer)
        subscriptions.add(unsubscribe)
        
        return unsubscribe
      }
      
      // Execute callback to establish dependencies
      updateObserver(callbackObserver)
    } finally {
      // Always restore original subscribe
      if (originalSubscribe) {
        globalNamespace.subscribe = originalSubscribe
      } else {
        delete globalNamespace.subscribe
      }
    }
  }
  
  // Initialize the callback tracking
  setupCallback()
  
  // Create unsubscribe function
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clean up all tracked subscriptions
    subscriptions.forEach(unsub => unsub())
    subscriptions.clear()
    
    // Clear the observer
    callbackObserver.value = undefined
    // eslint-disable-next-line @typescript-eslint/no-unused-vars
    callbackObserver.updateFn = (_value?: T) => value!
  }
  
  return unsubscribe
}
