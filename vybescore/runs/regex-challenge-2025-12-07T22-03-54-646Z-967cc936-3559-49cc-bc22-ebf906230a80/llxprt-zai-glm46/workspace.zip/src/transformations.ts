/**
 * Capitalizes the first character of each sentence while preserving spacing rules.
 * Handles sentence boundaries (.?!) and inserts exactly one space between sentences.
 * Collapses extra spaces and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) return text;
  
  // Common abbreviations that shouldn't trigger sentence breaks
  const abbreviations = /\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Mt|Ave|Blvd|Rd|etc|e\.g|i\.e|vs|approx|approx|No|nos|Art|Fig|fig|p|pp|vol|Vols|ed|Ed|rev|Rev|trans|Trans|dept|Dept|univ|Univ|USA|U\.S\.A|UK|U\.K|etc|etc\.)[.!?]?$/i;
  
  // First, collapse multiple spaces into single spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence-ending punctuation if missing
  result = result.replace(/([.!?])(?=[A-Za-zÀ-ÖØ-öø-ÿ])/g, '$1 ');
  
  // Split into sentences while being careful about abbreviations
  const sentences = [];
  let currentSentence = '';
  
  for (let i = 0; i < result.length; i++) {
    currentSentence += result[i];
    
    // Check if we have a sentence-ending punctuation
    if (/[.!?]/.test(result[i])) {
      // Look ahead to see if this might be an abbreviation
      const prevWords = currentSentence.trim().split(/\s+/);
      if (prevWords.length >= 1) {
        const lastWord = prevWords[prevWords.length - 1].toLowerCase();
        if (!abbreviations.test(lastWord)) {
          sentences.push(currentSentence.trim());
          currentSentence = '';
        }
      }
    }
  }
  
  // Add any remaining text
  if (currentSentence.trim()) {
    sentences.push(currentSentence.trim());
  }
  
  // Capitalize each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (!sentence) return sentence;
    
    // Find first letter and capitalize it
    return sentence.replace(/^([a-zà-öø-ÿ])/, (match) => match.toUpperCase());
  });
  
  // Join with single spaces
  return capitalizedSentences.join(' ');
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  const urlRegex = /\b((?:https?:\/\/|www\.)[^\s<>"']+|(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,})(?:\/[^\s<>"']*)?)\b/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    return url.replace(/[.,;:!?'"`)\]}>]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch existing https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * Always upgrades scheme to https://.
 * When path begins with /docs/, rewrites host to docs.example.com.
 * Skips host rewrite for dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with example.com
  const urlPattern = /http:\/\/example\.com(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, path = '') => {
    // Always upgrade to https
    const scheme = 'https://';
    
    // Check if we should skip host rewrite
    const skipPatterns = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/
    ];
    
    const shouldSkipHost = skipPatterns.some(pattern => pattern.test(path));
    
    if (!shouldSkipHost && path.startsWith('/docs/')) {
      // Rewrite host to docs.example.com for docs paths
      return `${scheme}docs.example.com${path}`;
    } else {
      // Just upgrade the scheme
      return `${scheme}example.com${path}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Additional validation for day-month combinations
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years
  const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
  if (isLeapYear) {
    daysInMonth[2] = 29;
  }
  
  // Check if day is valid for the month
  if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year.toString();
}
