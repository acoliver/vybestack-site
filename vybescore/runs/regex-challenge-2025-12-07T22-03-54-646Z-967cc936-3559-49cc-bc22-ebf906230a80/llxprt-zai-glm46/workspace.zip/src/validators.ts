export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using comprehensive regex patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Local part: letters, digits, +, ., -, _ (but no consecutive dots, no leading/trailing dots)
  // Domain part: letters, digits, - (no underscores, no consecutive dots, no leading/trailing dots)
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9]+([a-zA-Z0-9._+-]*[a-zA-Z0-9]+)?@[a-zA-Z0-9]+([a-zA-Z0-9-]*[a-zA-Z0-9]+)?(\.[a-zA-Z0-9]+([a-zA-Z0-9-]*[a-zA-Z0-9]+)?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for consecutive dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Check for underscore in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  // Check for dot at the end
  if (value.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * Accepts: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const cleanValue = value.replace(/\D/g, '');
  
  // Must be at least 10 digits for US numbers
  if (cleanValue.length < 10 || cleanValue.length > 11) {
    return false;
  }
  
  // Extract digits, handling optional +1 country code
  let digits = cleanValue;
  if (cleanValue.length === 11) {
    // If 11 digits, must start with 1 (country code)
    if (cleanValue[0] !== '1') {
      return false;
    }
    digits = cleanValue.slice(1); // Remove country code
  }
  
  // Now digits should be exactly 10
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Check if the original format is valid
  // Support various formats:
  // 212-555-7890, (212) 555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^(\+1[\s-]?)?(\(?([2-9]\d{2})\)?[\s-]?)([2-9]\d{2})[\s-]?(\d{4})(\s*(ext|extension|x|#)\s*\d+)?$/i;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // First normalize the input by removing spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if it starts with +54 (country code)
  const hasCountryCode = cleanValue.startsWith('+54');
  
  let digitsOnly = cleanValue;
  
  if (hasCountryCode) {
    // Remove country code
    digitsOnly = cleanValue.slice(3);
    
    // Check for optional mobile indicator 9
    if (digitsOnly.startsWith('9')) {
      digitsOnly = digitsOnly.slice(1);
    }
    
    // Check for optional trunk prefix 0 (should not be present with country code)
    if (digitsOnly.startsWith('0')) {
      return false; // Invalid: country code + trunk prefix not allowed
    }
  } else {
    // Must start with 0 trunk prefix when no country code
    if (!digitsOnly.startsWith('0')) {
      return false;
    }
    
    // Remove trunk prefix
    digitsOnly = digitsOnly.slice(1);
  }
  
  // At this point, digitsOnly should contain area code + subscriber number
  
  // Minimum length check (area code 2-4 digits + subscriber 6-8 digits = 8-12 digits)
  if (digitsOnly.length < 8 || digitsOnly.length > 12) {
    return false;
  }
  
  // Extract area code (2-4 digits, first digit 1-9)
  // Try to match valid area code lengths
  let areaCode, subscriberNumber;
  
  // Try 2-digit area code
  if (digitsOnly.length >= 8) {
    areaCode = digitsOnly.slice(0, 2);
    subscriberNumber = digitsOnly.slice(2);
    
    if (/^[1-9]\d$/.test(areaCode) && subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      return true;
    }
  }
  
  // Try 3-digit area code
  if (digitsOnly.length >= 9) {
    areaCode = digitsOnly.slice(0, 3);
    subscriberNumber = digitsOnly.slice(3);
    
    if (/^[1-9]\d{2}$/.test(areaCode) && subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      return true;
    }
  }
  
  // Try 4-digit area code
  if (digitsOnly.length >= 10) {
    areaCode = digitsOnly.slice(0, 4);
    subscriberNumber = digitsOnly.slice(4);
    
    if (/^[1-9]\d{3}$/.test(areaCode) && subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits, symbols, and unconventional names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, spaces, apostrophes, and hyphens
  // Reject digits, special symbols, and unusual formatting
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s][\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional checks for obviously invalid patterns
  // Reject names with consecutive punctuation
  if (value.includes("--") || value.includes("''") || value.includes("' -") || value.includes("-'")) {
    return false;
  }
  
  // Reject names starting or ending with punctuation
  if (/^['-]|['-]$/.test(value)) {
    return false;
  }
  
  // Reject names with too many consecutive punctuation marks relative to letters
  const punctCount = (value.match(/['-]/g) || []).length;
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  
  // Ratio check - shouldn't have too many punctuation marks
  if (punctCount > Math.floor(letterCount / 2)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn algorithm helper function for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for major card types (Visa, Mastercard, AmEx).
 * Accepts proper prefixes and lengths, and runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check length - typically 13-19 digits
  if (cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Card type patterns
  const cardPatterns = {
    visa: /^4\d{12}(\d{3})?(\d{3})?$/, // 13, 16, or 19 digits starting with 4
    mastercard: /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/, // 16 digits
    amex: /^3[47]\d{13}$/, // 15 digits starting with 34 or 37
  };
  
  // Check if it matches any card type
  const isValidFormat = Object.values(cardPatterns).some(pattern => pattern.test(cleanValue));
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanValue);
}
