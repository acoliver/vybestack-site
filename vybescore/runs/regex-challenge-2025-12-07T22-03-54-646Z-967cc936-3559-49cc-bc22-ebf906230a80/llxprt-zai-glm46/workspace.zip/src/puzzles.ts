/**
 * Finds words starting with the specified prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  const wordPattern = new RegExp('\\b' + prefix + '[a-zA-Z0-9_-]*', 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  ).filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds as specified.
 * Returns an array of matched token occurrences including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match digit+token sequences
  const embeddedTokenPattern = new RegExp('\\d' + escapedToken, 'g');
  
  const matches = text.match(embeddedTokenPattern) || [];
  
  return matches;
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check character requirements
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':\\"\\|,.<>\/?]/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for repeated patterns (like abab, abcabc)
  // Use a more comprehensive approach for pattern detection
  for (let patternLength = 2; patternLength <= 6; patternLength++) {
    for (let i = 0; i <= value.length - patternLength * 2; i++) {
      const pattern = value.substring(i, i + patternLength);
      const nextPattern = value.substring(i + patternLength, i + patternLength * 2);
      
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 * Returns true if a valid IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex pattern to exclude
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  
  // If it's a pure IPv4 address, return false
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 regex pattern (comprehensive)
  // This pattern matches various IPv6 formats including:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed notation: 2001:db8:85a3::8a2e:370:7334
  // - Loopback: ::1
  // - Unspecified: ::
  // - Mixed notation (IPv4 embedded): 2001:db8::192.0.2.33
  
  // First, try to match a comprehensive IPv6 pattern
  const ipv6Pattern = /(?:^|(?<=\s))(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?:%[0-9a-zA-Z]{1,})?(?:$|(?=\s))/;
  
  // Test for IPv6 patterns
  if (ipv6Pattern.test(value)) {
    return true;
  }
  
  // Additional pattern for :: shorthand
  const shorthandPattern = /::[0-9a-fA-F]*/;
  if (shorthandPattern.test(value)) {
    return true;
  }
  
  return false;
}