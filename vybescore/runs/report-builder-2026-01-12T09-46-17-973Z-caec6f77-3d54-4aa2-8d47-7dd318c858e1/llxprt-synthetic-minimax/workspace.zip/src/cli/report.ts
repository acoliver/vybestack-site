#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { ReportData, CliOptions } from '../types/interfaces.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): { dataPath: string; options: CliOptions } {
  if (argv.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = resolve(argv[2]);
  
  const args = argv.slice(3);
  const options: CliOptions = {
    format: 'markdown', // default
    includeTotals: false
  };

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const formatValue = args[++i];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
      options.format = formatValue as 'markdown' | 'text';
    } else if (arg === '--output') {
      options.output = args[++i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!options.format) {
    throw new Error('--format option is required');
  }

  return { dataPath, options };
}

function parseJsonData(content: string): ReportData {
  try {
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field');
    }
    
    // Validate entries
    for (const [index, entry] of data.entries.entries()) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid JSON: entries[${index}] missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid JSON: entries[${index}] missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Invalid JSON: malformed JSON');
    }
    throw error;
  }
}

function main(): void {
  try {
    const { dataPath, options } = parseArgs(process.argv);
    
    const content = readFileSync(dataPath, 'utf-8');
    const data = parseJsonData(content);
    
    let output: string;
    
    if (options.format === 'markdown') {
      output = renderMarkdown(data, options.includeTotals);
    } else {
      output = renderText(data, options.includeTotals);
    }
    
    if (options.output) {
      writeFileSync(resolve(options.output), output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
