import { ReportData } from '../types/interfaces.js';

export function renderMarkdown(data: ReportData, includeTotals: boolean): string {
  const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `## Entries\n\n`;
  
  for (const entry of data.entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    output += `- **${entry.label}** — ${formattedAmount}\n`;
  }
  
  if (includeTotals) {
    const formattedTotal = `$${total.toFixed(2)}`;
    output += `\n**Total:** ${formattedTotal}`;
  }
  
  return output;
}