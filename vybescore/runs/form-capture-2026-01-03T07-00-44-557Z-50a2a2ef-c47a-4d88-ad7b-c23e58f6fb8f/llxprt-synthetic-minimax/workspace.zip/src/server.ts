import express, { Request, Response } from 'express';
import initSqlJs from 'sql.js';
import path from 'node:path';
import fs from 'node:fs';

// Types
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Database type from sql.js
type SqlJsDatabase = import('sql.js').Database;

// Global database instance
let db: SqlJsDatabase | null = null;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const PORT = parseInt(process.env.PORT || '3535', 10);

// Initialize database
async function initializeDatabase(): Promise<SqlJsDatabase> {
  // Check if database file exists
  const dbExists = fs.existsSync(DB_PATH);
  
  // Initialize SQL.js
  const SQL = await initSqlJs();
  
  // Create new database
  let database: SqlJsDatabase;
  
  // Load schema if database is new
  if (!dbExists) {
    database = new SQL.Database();
    const schemaPath = path.resolve('db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    database.exec(schema);
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Write initial database file
    const data = database.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } else {
    // Load existing database
    const data = fs.readFileSync(DB_PATH);
    database = new SQL.Database(data);
  }
  
  return database;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept international formats with +, digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handle UK "SW1A 1AA", Argentine "C1000", etc.)
  const postalRegex = /^[A-Za-z0-9\s-]{3,12}$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || value.trim() === '') {
      errors.push({ field, message: `${field} is required` });
    }
  });
  
  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }
  
  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }
  
  return errors;
}

// Main application
async function createApp() {
  const app = express();
  
  // Initialize database
  db = await initializeDatabase();
  
  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use('/public', express.static(path.resolve(process.cwd(), 'public')));
  
  // Set EJS as view engine
  app.set('views', path.resolve(process.cwd(), 'src', 'templates'));
  app.set('view engine', 'ejs');
  
  // Routes
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });
  
  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: (req.body.firstName || '').trim(),
      lastName: (req.body.lastName || '').trim(),
      streetAddress: (req.body.streetAddress || '').trim(),
      city: (req.body.city || '').trim(),
      stateProvince: (req.body.stateProvince || '').trim(),
      postalCode: (req.body.postalCode || '').trim(),
      country: (req.body.country || '').trim(),
      email: (req.body.email || '').trim(),
      phone: (req.body.phone || '').trim()
    };
    
    // Validate form data
    const errors = validateFormData(formData);
    
    if (errors.length > 0) {
      // Validation failed - return form with errors
      res.status(400).render('form', {
        errors: errors.map(e => e.message),
        values: formData
      });
      return;
    }
    
    // Validation passed - insert into database
    try {
      if (!db) {
        throw new Error('Database not initialized');
      }
      
      // Insert submission
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);
      
      stmt.free();
      
      // Export database to file
      const data = db.export();
      fs.writeFileSync(DB_PATH, Buffer.from(data));
      
      // Redirect to thank you page
      res.redirect(302, '/thank-you');
      
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        errors: ['An error occurred while processing your submission. Please try again.'],
        values: formData
      });
    }
  });
  
  app.get('/thank-you', (req: Request, res: Response) => {
    // Get first name from last form submission or default
    let firstName = 'friend';
    try {
      if (db) {
        const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
        const result = stmt.step();
        if (result) {
          // sql.js typically returns an array for single row results
          if (Array.isArray(result) && result.length > 0) {
            firstName = result[0] as string;
          } else if (typeof result === 'object' && result !== null) {
            // Handle object format
            const values = Object.values(result);
            if (values.length > 0) {
              firstName = String(values[0]);
            }
          }
        }
        stmt.free();
      }
    } catch (error) {
      console.error('Error retrieving first name:', error);
    }
    
    res.render('thank-you', { firstName });
  });
  
  return app;
}

// Start server
async function startServer() {
  try {
    const app = await createApp();
    
    const server = app.listen(PORT, '0.0.0.0', () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Graceful shutdown
    const gracefulShutdown = () => {
      console.log('Shutting down gracefully...');
      
      if (server) {
        server.close((err) => {
          if (err) {
            console.error('Error closing server:', err);
            process.exit(1);
          }
          
          // Close database
          if (db) {
            try {
              const data = db.export();
              fs.writeFileSync(DB_PATH, Buffer.from(data));
              db.close();
              console.log('Database closed successfully');
            } catch (error) {
              console.error('Error closing database:', error);
            }
          }
          
          console.log('Server shutdown complete');
          process.exit(0);
        });
      }
    };
    
    // Handle shutdown signals
    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
    
    return server;
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export for testing
export { startServer, createApp };

// Start server if this file is run directly
if (process.argv[1] === new URL(import.meta.url).pathname) {
  startServer();
}
