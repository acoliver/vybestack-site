import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import type { Express } from 'express';
import { createApp } from '../../dist/server.js';

let server: ReturnType<Express['listen']> | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database for testing
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Create and start server for testing
  const app = await createApp();
  server = app.listen(0); // Use port 0 to get a random available port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
  });

  it('validates required fields', async () => {
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: '',
        lastName: 'Doe',
        email: 'invalid-email'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('firstName is required');
  });

  it('persists submission and redirects', async () => {
    // Clean database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const response = await request(server)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'USA',
        email: 'john@example.com',
        phone: '+1 555-123-4567'
      });
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
