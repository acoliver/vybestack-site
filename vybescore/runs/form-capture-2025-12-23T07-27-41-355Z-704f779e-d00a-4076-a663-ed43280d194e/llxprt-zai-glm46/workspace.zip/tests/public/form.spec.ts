import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { start } from '../../src/server.js';

type ServerInstance = Awaited<ReturnType<typeof start>>;

let serverInstance: ServerInstance | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  serverInstance = await start();
});

afterAll(() => {
  if (serverInstance) {
    serverInstance.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await fetch('http://localhost:3535/');
    const html = await response.text();
    
    // Check for key form elements
    expect(html).toContain('<form');
    expect(html).toContain('name="firstName"');
    expect(html).toContain('name="lastName"');
    expect(html).toContain('name="streetAddress"');
    expect(html).toContain('name="city"');
    expect(html).toContain('name="stateProvince"');
    expect(html).toContain('name="postalCode"');
    expect(html).toContain('name="country"');
    expect(html).toContain('name="email"');
    expect(html).toContain('name="phone"');
    
    expect(response.status).toBe(200);
  });

  it('persists submission and redirects', async () => {
    // Clear database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Submit form data
    const formData = new URLSearchParams({
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958'
    });

    const response = await fetch('http://localhost:3535/submit', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
      body: formData,
      redirect: 'manual'
    });

    // Check response
    if (response.status === 400) {
      const html = await response.text();
      console.log('Validation failed. Response:', html.substring(0, 500));
    }

    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.get('location')).toContain('/thank-you');

    // Database file should now exist
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows thank you page', async () => {
    const response = await fetch('http://localhost:3535/thank-you?firstName=Test');
    const html = await response.text();
    
    expect(html).toContain('Thank you');
    expect(response.status).toBe(200);
  });
});
