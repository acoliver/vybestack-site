// Type declarations for sql.js
declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): RunResult;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface RunResult {
    columns: string[];
  }

  export interface QueryExecResult extends Array<QueryExecResultModule> {
    columns: string[];
    values: unknown[][];
  }

  export interface QueryExecResultModule {
    [key: string]: unknown;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    get(params?: unknown[]): unknown[] | null;
    all(params?: unknown[]): unknown[][];
    bind(params?: unknown[]): boolean;
    free(): void;
  }

  export interface SqlJsConfig {
    locateFile?: (filename: string) => string;
  }

  export default function initSqlJs(config?: SqlJsConfig): Promise<SqlJsStatic>;

  export const initSqlJs: typeof initSqlJs;
}
