import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

// Validation regex patterns
const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_PATTERN = /^\+?[\d\s\-()]+$/;
const POSTAL_PATTERN = /^[A-Za-z0-9\s-]+$/;

// Validate form data
function validateForm(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  // Required fields
  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  }
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  }
  if (!data.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  if (!data.city?.trim()) {
    errors.push('City is required');
  }
  if (!data.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  if (!data.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  } else if (!POSTAL_PATTERN.test(data.postalCode.trim())) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens');
  }
  if (!data.country?.trim()) {
    errors.push('Country is required');
  }
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!EMAIL_PATTERN.test(data.email.trim())) {
    errors.push('Email must be a valid email address');
  }
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!PHONE_PATTERN.test(data.phone.trim())) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

// Initialize SQLite database
async function initDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  let db: Database;

  // Ensure data directory exists
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    // Load existing database
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    // Create new database and run schema
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase(db);
  }

  return db;
}

// Save database to disk
function saveDatabase(db: Database): void {
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Insert submission into database
function insertSubmission(db: Database, data: FormData): void {
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    data.firstName.trim(),
    data.lastName.trim(),
    data.streetAddress.trim(),
    data.city.trim(),
    data.stateProvince.trim(),
    data.postalCode.trim(),
    data.country.trim(),
    data.email.trim(),
    data.phone.trim()
  ]);
  
  stmt.free();
  saveDatabase(db);
}

// Create Express app
async function createApp(): Promise<{ app: express.Application; db: Database }> {
  const db = await initDatabase();
  const app = express();

  // Configure EJS - templates are in src/templates when running from source
  // or in dist/templates when running compiled code
  const templatesPath = fs.existsSync(path.join(__dirname, 'templates'))
    ? path.join(__dirname, 'templates')
    : path.join(__dirname, '..', 'src', 'templates');
  
  app.set('views', templatesPath);
  app.set('view engine', 'ejs');

  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));

  // Serve static files from /public
  app.use('/public', express.static(path.join(__dirname, '..', 'public')));

  // Serve public favicon if requested
  app.get('/favicon.ico', (req, res) => {
    res.status(404).end();
  });

  // GET / - Render the form
  app.get('/', (req, res) => {
    const errors: string[] = [];
    const values: Partial<FormData> = {};
    res.render('form', { errors, values });
  });

  // POST /submit - Handle form submission
  app.post('/submit', (req, res) => {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);

    if (!validation.valid) {
      // Re-render form with errors
      res.status(400).render('form', {
        errors: validation.errors,
        values: formData
      });
      return;
    }

    // Insert into database
    insertSubmission(db, formData as FormData);

    // Redirect to thank you page with first name
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
  });

  // GET /thank-you - Thank you page
  app.get('/thank-you', (req, res) => {
    const firstName = req.query.firstName || 'Friend';
    res.render('thank-you', { firstName });
  });

  // Health check endpoint (useful for testing)
  app.get('/health', (req, res) => {
    res.status(200).json({ status: 'ok' });
  });

  return { app, db };
}

// Start server
async function start(): Promise<{
  app: express.Application;
  server: ReturnType<express.Application['listen']>;
  db: Database;
  close: () => void;
}> {
  const { app, db } = await createApp();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  const server = app.listen(port, () => {
    // Silently start - logging interferes with test output
  });

  // Graceful shutdown handler
  const close = (): void => {
    server.close(() => {
      db.close();
    });
  };

  // Handle SIGTERM for graceful shutdown
  process.on('SIGTERM', close);
  process.on('SIGINT', close);

  return { app, server, db, close };
}

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  start().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

// Export for testing
export { start, createApp, initDatabase, insertSubmission, validateForm };
export type { FormData, ValidationResult };
