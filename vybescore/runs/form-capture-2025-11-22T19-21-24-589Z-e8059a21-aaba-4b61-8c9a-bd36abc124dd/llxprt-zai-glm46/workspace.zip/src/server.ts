import express, { Express, Request, Response } from 'express';
import path from 'path';
import { promises as fs } from 'fs';
import initSqlJs, { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

const PORT = process.env.PORT || 3535;
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');

class FormCaptureApp {
  private app: Express;
  private db: Database | null = null;
  private server: ReturnType<Express['listen']> | null = null;

  constructor() {
    this.app = express();
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.static(path.join(process.cwd(), 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'src', 'templates'));
  }

  private async initDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Create data directory if it doesn't exist
      await fs.mkdir(path.dirname(DB_PATH), { recursive: true });
      
      // Load existing database or create new one
      try {
        const dbFile = await fs.readFile(DB_PATH);
        this.db = new SQL.Database(dbFile);
      } catch (error: unknown) {
        // Database doesn't exist, create new one
        this.db = new SQL.Database();
        const schema = await fs.readFile(
          path.join(process.cwd(), 'db', 'schema.sql'),
          'utf8'
        );
        this.db.exec(schema);
        await this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (this.db) {
      const data = this.db.export();
      await fs.writeFile(DB_PATH, Buffer.from(data));
    }
  }

  private validateForm(formData: FormData): FormErrors {
    const errors: FormErrors = {};

    if (!formData.firstName?.trim()) {
      errors.firstName = 'First name is required';
    }

    if (!formData.lastName?.trim()) {
      errors.lastName = 'Last name is required';
    }

    if (!formData.streetAddress?.trim()) {
      errors.streetAddress = 'Street address is required';
    }

    if (!formData.city?.trim()) {
      errors.city = 'City is required';
    }

    if (!formData.stateProvince?.trim()) {
      errors.stateProvince = 'State/Province/Region is required';
    }

    if (!formData.postalCode?.trim()) {
      errors.postalCode = 'Postal/Zip code is required';
    } else if (!/^[A-Za-z0-9\s-]+$/.test(formData.postalCode)) {
      errors.postalCode = 'Postal code can only contain letters, numbers, spaces, and hyphens';
    }

    if (!formData.country?.trim()) {
      errors.country = 'Country is required';
    }

    if (!formData.email?.trim()) {
      errors.email = 'Email is required';
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    if (!formData.phone?.trim()) {
      errors.phone = 'Phone number is required';
    } else if (!/^\+?[\d\s\-()]+$/.test(formData.phone)) {
      errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +';
    }

    return errors;
  }

  private setupRoutes(): void {
    this.app.get('/', async (req: Request, res: Response) => {
      try {
        res.render('form', {
          errors: {},
          formData: {},
          title: 'Friendly Contact Form'
        });
      } catch (error) {
        this.handleError(res, error);
      }
    });

    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: FormData = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const errors = this.validateForm(formData);

        if (Object.keys(errors).length > 0) {
          res.status(400).render('form', {
            errors,
            formData,
            title: 'Friendly Contact Form'
          });
          return;
        }

        // Insert into database
        if (this.db) {
          const stmt = this.db.prepare(`
            INSERT INTO submissions (
              first_name, last_name, street_address, city, 
              state_province, postal_code, country, email, phone
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
          
          stmt.run([
            formData.firstName,
            formData.lastName,
            formData.streetAddress,
            formData.city,
            formData.stateProvince,
            formData.postalCode,
            formData.country,
            formData.email,
            formData.phone
          ]);
          
          stmt.free();
          await this.saveDatabase();
        }

        res.redirect('/thank-you');
      } catch (error) {
        this.handleError(res, error);
      }
    });

    this.app.get('/thank-you', (req: Request, res: Response) => {
      try {
        res.render('thank-you', {
          title: 'Thank You!'
        });
      } catch (error) {
        this.handleError(res, error);
      }
    });
  }

  private handleError(res: Response, error: unknown): void {
    console.error('Server error:', error);
    res.status(500).render('form', {
      errors: {},
      formData: {},
      title: 'Friendly Contact Form',
      errorMessage: 'An unexpected error occurred. Please try again later.'
    });
  }

  public async start(): Promise<void> {
    await this.initDatabase();
    
    this.server = this.app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Handle graceful shutdown
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
  }

  public async shutdown(): Promise<void> {
    console.log('Shutting down gracefully...');
    
    if (this.server) {
      this.server.close(() => {
        console.log('Express server closed');
      });
    }

    if (this.db) {
      this.db.close();
      console.log('Database connection closed');
    }

    process.exit(0);
  }
}

// Start the application
const app = new FormCaptureApp();
app.start().catch((error) => {
  console.error('Failed to start application:', error);
  process.exit(1);
});