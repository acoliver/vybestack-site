/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

// Track dependencies between computed values and their signals
const computedDependencies = new Map<Observer<any>, Set<Subject<any>>>()

// Track which observers depend on computed values
const computedObservers = new Map<Subject<any>, Set<Observer<any>>>()

/**
 * Helper function to create an equality function from a boolean or custom function
 */
function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (a, b) => a === b : () => false
  }
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // Create a subject to represent this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue) => {
      // Clear previous dependencies
      const deps = computedDependencies.get(observer)
      if (deps) {
        deps.clear()
      }
      
      // Execute the computation function to get the new value
      const newValue = updateFn(prevValue)
      
      // Update the stored values
      observer.value = newValue
      computedSubject.value = newValue
      
      // Notify observers that depend on this computed value
      const observers = computedObservers.get(computedSubject)
      if (observers) {
        // Create a copy to avoid issues with observers being added/removed during iteration
        const observerCopy = new Set(observers)
        observerCopy.forEach(obs => {
          try {
            updateObserver(obs)
          } catch (error) {
            console.error('Error updating observer:', error)
          }
        })
      }
      
      return newValue
    }
  }
  
  // Track dependencies for this computed observer
  computedDependencies.set(observer, new Set())
  
  // Initialize the computed value
  updateObserver(observer)
  
  const getter = (): T => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Register dependency between active observer and this computed value
      if (!computedObservers.has(computedSubject)) {
        computedObservers.set(computedSubject, new Set())
      }
      computedObservers.get(computedSubject)!.add(activeObs as Observer<any>)
    }
    return computedSubject.value
  }
  
  return getter
}