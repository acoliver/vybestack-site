/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Track dependencies between signals and effects
const signalDependencies = new Map<Subject<any>, Set<Observer<any>>>()

/**
 * Helper function to create an equality function from a boolean or custom function
 */
function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (a, b) => a === b : () => false
  }
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = createEqualFn(equal)
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as a dependency of the signal
      if (!signalDependencies.has(s)) {
        signalDependencies.set(s, new Set())
      }
      signalDependencies.get(s)!.add(observer as Observer<any>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if the value has actually changed
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    
    if (!hasChanged) return s.value
    
    s.value = nextValue
    
    // Trigger all dependent observers
    const observers = signalDependencies.get(s)
    if (observers) {
      // Create a copy to avoid issues with observers being added/removed during iteration
      const observerCopy = new Set(observers)
      observerCopy.forEach(observer => {
        try {
          updateObserver(observer)
        } catch (error) {
          console.error('Error updating observer:', error)
        }
      })
    }
    
    return s.value
  }

  return [read, write]
}
