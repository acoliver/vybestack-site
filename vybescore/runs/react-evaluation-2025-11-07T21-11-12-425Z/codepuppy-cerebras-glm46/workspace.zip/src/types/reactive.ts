/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  disposed?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export type ComputedSubject<T> = Observer<T> & SubjectV<T> & SubjectR

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers(subject: SubjectR): void {
  // Create a copy to avoid issues with observers being removed during iteration
  const observers = Array.from(subject.observers)
  for (const observer of observers) {
    if (!observer.disposed) {
      updateObserver(observer as Observer<unknown>)
    } else {
      // Remove disposed observers
      subject.observers.delete(observer)
    }
  }
}

// Helper to track when a computed value needs to notify its observers
export function createComputedObserver<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  name?: string
): ComputedSubject<T> {
  const computed: ComputedSubject<T> = {
    name,
    observers: new Set(),
    value: value as T,
    updateFn: (prevValue?: T) => {
      const newValue = updateFn(prevValue || value)
      // Update the value and notify observers if it changed
      if (newValue !== prevValue) {
        computed.value = newValue
        notifyObservers(computed)
      }
      return newValue
    },
  }
  return computed
}

export function addObserver(subject: SubjectR, observer: ObserverR): void {
  subject.observers.add(observer)
}

export function removeObserver(subject: SubjectR, observer: ObserverR): void {
  subject.observers.delete(observer)
}
