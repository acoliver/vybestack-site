/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, SubjectR, removeObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      updateFn(prevValue)
      // For callbacks, we don't store the result, just execute the side effect
      return prevValue as T // Return the original value to maintain consistency
    },
  }
  
  // Track which subjects this observer is subscribed to
  const subscribedSubjects = new Set<SubjectR>()
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Remove this observer from all subjects it was subscribed to
    for (const subject of subscribedSubjects) {
      removeObserver(subject, observer)
    }
    
    // No-op function to prevent further updates
    observer.updateFn = () => value as T
  }
}
