/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  EqualFn,
  updateObserver,
  getActiveObserver,
  createComputedObserver,
  addObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a computed observer that can also have observers
  const computed = createComputedObserver(updateFn, value, options?.name)
  
  // Initial computation to establish dependencies
  updateObserver(computed)
  
  // Return getter that tracks dependencies
  return (): T => {
    const observer = getActiveObserver()
    if (observer && !observer.disposed) {
      // This computed is being accessed as a dependency
      // Register the observer as a dependent of this computed
      addObserver(computed, observer)
    }
    
    return computed.value as T
  }
}