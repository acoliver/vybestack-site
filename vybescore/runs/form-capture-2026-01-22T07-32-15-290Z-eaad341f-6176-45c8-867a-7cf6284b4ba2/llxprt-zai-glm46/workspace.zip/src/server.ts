import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

const PORT = process.env.PORT || 3535;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^@?[\d\s\-()+]+$/;
  return phoneRegex.test(phone) && phone.length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim();
    if (!value) {
      errors.push(`${field} is required`);
    }
  }

  if (data.email && !validateEmail(data.email)) {
    errors.push('Please provide a valid email address');
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading @');
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, spaces, and dashes');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  let dbInstance: Database;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    
    const data = dbInstance.export();
    const dbDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(DB_PATH, data);
  }
  
  return dbInstance;
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const dbDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dbDir)) {
      fs.mkdirSync(dbDir, { recursive: true });
    }
    fs.writeFileSync(DB_PATH, data);
    // Force sync to disk
    fs.fsyncSync(fs.openSync(DB_PATH, 'r'));
  }
}

app.get('/', (_req: Request, res: Response): void => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', (req: Request, res: Response): void => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    res.status(400);
    return res.render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);
    
    stmt.free();
    saveDatabase();
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (_req: Request, res: Response): void => {
  res.render('thank-you', {
    firstName: 'Friend',
  });
});

async function startServer(): Promise<void> {
  try {
    db = await initializeDatabase();
    
    app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    const gracefulShutdown = (): void => {
      console.log('Shutting down gracefully...');
      server.close(() => {
        if (db) {
          db.close();
          db = null;
        }
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Auto-start server when module is loaded, except in test environment
// Test detection: vitest sets process.env.VITEST or process.env.NODE_ENV=test
const isTestEnvironment = process.env.VITEST === 'true' || process.env.NODE_ENV === 'test';
if (!isTestEnvironment) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app };
