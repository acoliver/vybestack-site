declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: DatabaseConstructor;
  }

  export interface DatabaseConstructor {
    new (data?: ArrayLike<number> | Buffer | null): Database;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): RunResult;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
    getRowsModified(): number;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    get(params?: unknown[]): unknown;
    all(params?: unknown[]): unknown[];
    free(): void;
    getColumnNames(): string[];
  }

  export interface RunResult {
    changes: number;
    lastInsertRowid: number | bigint;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface SqlJsConfig {
    locateFile?: (filename: string) => string;
  }

  interface InitSqlJsStatic {
    (config?: SqlJsConfig): Promise<SqlJsStatic>;
  }

  const initSqlJs: InitSqlJsStatic;
  export default initSqlJs;
}
