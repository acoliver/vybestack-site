import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type Formatter = (data: ReportData, options?: RenderOptions) => string;

export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};