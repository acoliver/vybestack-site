import type { ReportData, RenderOptions } from '../types.js';

export function renderText(
  data: ReportData,
  options: RenderOptions = { includeTotals: false }
): string {
  const { title, summary, entries } = data;
  
  // Calculate total if needed
  const total = options.includeTotals
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : 0;
  
  // Build the text output
  const lines: string[] = [];
  
  // Title
  lines.push(title);
  lines.push('');
  
  // Summary
  lines.push(summary);
  lines.push('');
  
  // Entries heading
  lines.push('Entries:');
  
  // Entry list
  for (const entry of entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }
  
  // Total if requested
  if (options.includeTotals) {
    lines.push(`Total: $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}