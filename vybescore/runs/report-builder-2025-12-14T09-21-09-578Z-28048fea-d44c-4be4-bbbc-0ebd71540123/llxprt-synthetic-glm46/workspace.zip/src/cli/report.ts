#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  let dataFile = '';
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (!dataFile && !arg.startsWith('--')) {
      dataFile = arg;
      continue;
    }
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip the format value
      continue;
    }
    
    if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the output value
      continue;
    }
    
    if (arg === '--includeTotals') {
      includeTotals = true;
      continue;
    }
  }
  
  if (!dataFile) {
    throw new Error('Please specify a data file');
  }
  
  if (!format) {
    throw new Error('Please specify a format with --format');
  }
  
  if (!['markdown', 'text'].includes(format)) {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: label must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${i}: amount must be a valid number`);
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArgs();
    
    // Read and parse the JSON file
    const dataPath = path.resolve(dataFile);
    if (!fs.existsSync(dataPath)) {
      throw new Error(`File not found: ${dataPath}`);
    }
    
    const fileContent = fs.readFileSync(dataPath, 'utf-8');
    let parsedData: unknown;
    
    try {
      parsedData = JSON.parse(fileContent);
    } catch (error) {
      throw new Error(`Invalid JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    
    // Validate the report data
    const reportData = validateReportData(parsedData);
    
    // Get the formatter
    const formatter = formatters[format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${format}`);
    }
    
    // Generate the report
    const options: RenderOptions = { includeTotals };
    const output = formatter(reportData, options);
    
    // Output to file or stdout
    if (outputPath) {
      fs.writeFileSync(outputPath, output);
      console.error(`Report saved to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

// Run the CLI
main();
