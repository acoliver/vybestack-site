

const INVALID_BASE64_MESSAGE = 'Invalid Base64 input';
const BASE64_CHAR_PATTERN = /^[A-Za-z0-9+/=]*$/;

/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Check for clearly invalid characters first
  if (!BASE64_CHAR_PATTERN.test(input)) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }
  
  // Check that padding is only at the end and there are at most 2 padding chars
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1 && paddingIndex < input.length - 3) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }
  
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch && paddingMatch[0].length > 2) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    // Additional validation: if result is empty but input wasn't just padding, it's likely invalid
    if (result === '' && !/^=+$/.test(input)) {
      throw new Error(INVALID_BASE64_MESSAGE);
    }
    return result;
  } catch (error) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }
}
