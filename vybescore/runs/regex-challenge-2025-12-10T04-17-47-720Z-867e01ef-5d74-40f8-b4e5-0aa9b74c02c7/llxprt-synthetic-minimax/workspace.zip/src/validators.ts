export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dots
  if (value.startsWith('.') || value.endsWith('.')) {
    return false;
  }
  
  // Extract domain part and check for underscores
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const domain = parts[1];
  if (domain.includes('_')) {
    return false;
  }
  
  // Check that domain has at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  // Check TLD is at least 2 characters
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except the leading +
  let cleaned = value.trim();
  
  // Handle extensions if allowed
  if (options?.allowExtensions) {
    const extensionMatch = cleaned.match(/(ext|x|extension)\s*\.?:?\s*(\d+)/i);
    if (extensionMatch) {
      cleaned = cleaned.replace(extensionMatch[0], '');
    }
  }
  
  // Check if starts with optional +1
  const usPhoneRegex = /^(\+?1[\s.-]?)?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  const match = cleaned.match(usPhoneRegex);
  
  if (!match) {
    return false;
  }
  
  // Ensure area code doesn't start with 0 or 1 (handled by regex [2-9] for area code)
  // The regex already ensures area code is 2-9 for first digit
  // and exchange code is 2-9 for first digit
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit and non-space characters except +
  const cleaned = value.trim();
  
  // Pattern for Argentine phone numbers:
  // Optional +54 country code
  // Optional 0 trunk prefix (must be present if no country code)
  // Optional 9 mobile indicator (for mobile numbers)
  // 2-4 digit area code (first digit 1-9)
  // Subscriber number total 6-8 digits (allowing spaces/hyphens between groups)
  const argentinePhoneRegex = /^(\+54\s*)?(0\s*)?9?\s*([1-9]\d{1,3})\s*(\d{3,4}[\s-]?\d{3,4})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const hasCountryCode = match[1] !== undefined;
  const hasTrunkPrefix = match[2] !== undefined;
  
  // If no country code, trunk prefix must be present
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Check for digits - reject if any digits found
  if (/\d/.test(trimmed)) {
    return false;
  }
  
  // Check for unusual symbol combinations
  if (/[^a-zA-ZÀ-ÿ\s'-]/.test(trimmed)) {
    return false;
  }
  
  // Ensure it doesn't start or end with special characters
  if (/^[\s'-]/.test(trimmed) || /[\s'-]$/.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check card type and length
  let validLength = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(cleaned)) {
    validLength = cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19;
  }
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  else if ((/^5[1-5]/.test(cleaned)) || (/^2[2-7][0-9]/.test(cleaned))) {
    validLength = cleaned.length === 16;
  }
  // American Express: starts with 34 or 37, length 15
  else if (/^3[47]/.test(cleaned)) {
    validLength = cleaned.length === 15;
  }
  
  if (!validLength) {
    return false;
  }
  
  // Perform Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i));
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}