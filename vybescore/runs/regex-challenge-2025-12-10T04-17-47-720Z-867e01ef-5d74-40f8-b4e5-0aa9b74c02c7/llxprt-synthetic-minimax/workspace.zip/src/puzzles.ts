/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for the prefix (escape special characters)
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = `\\b${escapedPrefix}[a-zA-Z]*`;
  const regex = new RegExp(pattern, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(match => {
    const lowercaseMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseMatch === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of the token with a digit before it
  const regex = new RegExp(`(\\d)${escapedToken}`, 'gi');
  const matches = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[0]); // Include the digit and token
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check length
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^a-zA-Z0-9\s]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123")
  // This pattern looks for any 2+ character sequence that repeats immediately
  if (/(..+)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Simplified IPv6 regex pattern
  const ipv6Regex = /\b([0-9a-f]{0,4}:){2,7}[0-9a-f]{0,4}\b|::/i;
  
  // IPv4 regex pattern to exclude from matches
  const ipv4Regex = /\b(\d{1,3}\.){3}\d{1,3}\b/;
  
  // First check if it matches IPv4 - if so, return false
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Check if it matches IPv6
  return ipv6Regex.test(value);
}