/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // First, normalize spaces and handle sentence ending punctuation
  let result = text;
  
  // Pattern to find sentence boundaries (., !, ?) followed by spaces
  // We need to be careful about abbreviations and other patterns
  result = result.replace(/([.!?])(\s*)([A-Za-z])/g, (match, punct, spaces, letter) => {
    return punct + spaces + letter.toUpperCase();
  });
  
  // Capitalize the first letter of the text if it starts a sentence
  result = result.replace(/^(\s*)([a-z])/, (match, spaces, letter) => {
    return spaces + letter.toUpperCase();
  });
  
  // Ensure exactly one space after sentence ending punctuation
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Normalize multiple spaces to single spaces
  result = result.replace(/\s+/g, ' ');
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"]+|www\.[^\s<>"]+/gi;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but only when it's not already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs and capture host and path
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)?/g, (match, host, path = '') => {
    let newUrl = 'https://' + host + path;
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints
      const hasDynamicHints = /(\?|=|&|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.host
        const docsHost = 'docs.' + host;
        newUrl = 'https://' + docsHost + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = new Date(parseInt(year, 10), month, 0).getDate();
  if (day < 1 || day > daysInMonth) {
    return 'N/A';
  }
  
  return year;
}