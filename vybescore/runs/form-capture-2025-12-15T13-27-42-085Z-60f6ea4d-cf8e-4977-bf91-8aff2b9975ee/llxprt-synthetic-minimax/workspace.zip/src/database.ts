import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;

  async initialize(): Promise<void> {
    if (this.db) {
      return;
    }

    this.sqlJs = await initSqlJs();

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    try {
      if (fs.existsSync(dbPath)) {
        const filebuffer = fs.readFileSync(dbPath);
        this.db = new this.sqlJs!.Database(filebuffer);
      } else {
        this.db = new this.sqlJs!.Database();
        this.createSchema();
      }
    } catch (error) {
      console.error('Error initializing database:', error);
      throw error;
    }
  }

  private createSchema(): void {
    const schemaPath = path.join(process.cwd(), 'data', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    this.db!.exec(schema);
  }

  async insertSubmission(submission: FormSubmission): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalZipCode,
      submission.country,
      submission.email,
      submission.phoneNumber
    ]);

    stmt.step();
    stmt.free();

    // Get the last insert rowid
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  }

  async save(): Promise<void> {
    if (!this.db) {
      return;
    }

    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    const data = this.db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();