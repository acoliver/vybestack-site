export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city',
    'stateProvinceRegion', 'postalZipCode', 'country', 'email', 'phoneNumber'
  ];

  requiredFields.forEach(field => {
    if (!data[field]?.trim()) {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phoneNumber && !isValidPhone(data.phoneNumber)) {
    errors.phoneNumber = 'Please enter a valid phone number';
  }

  // Postal code validation
  if (data.postalZipCode && !isValidPostalCode(data.postalZipCode)) {
    errors.postalZipCode = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/[\s\-()]+/g, '').length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings (handles international formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}