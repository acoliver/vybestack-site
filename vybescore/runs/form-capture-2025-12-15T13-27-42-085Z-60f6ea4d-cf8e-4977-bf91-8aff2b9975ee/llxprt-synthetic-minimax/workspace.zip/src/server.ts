import express, { Request, Response, NextFunction } from 'express';
import * as path from 'path';
import { dbManager, FormSubmission } from './database';
import { validateForm, FormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static('public'));

// Set up EJS as the view engine
app.set('views', path.join(process.cwd(), 'views'));
app.set('view engine', 'ejs');

// Initialize database on startup
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
    
    const server = app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });

    // Graceful shutdown
    process.on('SIGTERM', async () => {
      console.log('Received SIGTERM, shutting down gracefully');
      await dbManager.save();
      await dbManager.close();
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });

    process.on('SIGINT', async () => {
      console.log('Received SIGINT, shutting down gracefully');
      await dbManager.save();
      await dbManager.close();
      server.close(() => {
        console.log('Server closed');
        process.exit(0);
      });
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// GET / - Render the contact form
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    title: 'Contact Us - Friendly Form (Definitely Not A Scam)',
    errors: {},
    data: {},
    submitted: false
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvinceRegion: req.body.stateProvinceRegion || '',
      postalZipCode: req.body.postalZipCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phoneNumber: req.body.phoneNumber || ''
    };

    // Validate the form data
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      // Return to form with errors
      return res.status(400).render('form', {
        title: 'Contact Us - Please Fix Errors',
        errors: validation.errors,
        data: formData,
        submitted: false
      });
    }

    // Convert to FormSubmission format
    const submission: FormSubmission = {
      firstName: formData.firstName,
      lastName: formData.lastName,
      streetAddress: formData.streetAddress,
      city: formData.city,
      stateProvinceRegion: formData.stateProvinceRegion,
      postalZipCode: formData.postalZipCode,
      country: formData.country,
      email: formData.email,
      phoneNumber: formData.phoneNumber
    };

    // Save to database
    await dbManager.insertSubmission(submission);
    await dbManager.save();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
    
  } catch (error) {
    console.error('Error processing form submission:', error);
    next(error);
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You - Your Data Is Now Ours Forever'
  });
});

// 404 handler
app.use((req: Request, res: Response) => {
  res.status(404).send('Page not found');
});

// Error handler
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Start the server
startServer();