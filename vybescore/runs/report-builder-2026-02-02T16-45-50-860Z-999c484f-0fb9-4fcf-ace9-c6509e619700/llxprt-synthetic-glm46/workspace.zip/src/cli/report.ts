#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { resolve } from 'path';
import { ReportData, FormatOptions } from '../types.js';
import { MarkdownRenderer } from '../formats/markdown.js';
import { TextRenderer } from '../formats/text.js';

interface CliArguments {
  dataFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArguments(): CliArguments {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const result: CliArguments = {
    dataFile: '',
    format: '',
    outputPath: null,
    includeTotals: false
  };
  
  // Parse arguments
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (i === 0 && !arg.startsWith('--')) {
      // First non-flag argument is the data file
      result.dataFile = arg;
    } else if (arg === '--format') {
      i++; // Move to next argument
      if (i >= args.length) {
        throw new Error('Missing format argument after --format');
      }
      result.format = args[i];
    } else if (arg === '--output') {
      i++; // Move to next argument
      if (i >= args.length) {
        throw new Error('Missing output path argument after --output');
      }
      result.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  // Validate required arguments
  if (!result.dataFile) {
    throw new Error('Missing data file argument');
  }
  
  if (!result.format) {
    throw new Error('Missing --format argument');
  }
  
  return result;
}

function validateData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: data must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries array');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid label`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid amount`);
    }
  }
  
  return data as ReportData;
}

function loadDataFile(filePath: string): ReportData {
  try {
    const content = readFileSync(resolve(filePath), 'utf-8');
    const data = JSON.parse(content);
    return validateData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function createRenderer(format: string) {
  switch (format) {
    case 'markdown':
      return new MarkdownRenderer();
    case 'text':
      return new TextRenderer();
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function writeOutput(content: string, outputPath: string | null) {
  if (outputPath) {
    writeFileSync(resolve(outputPath), content);
    console.error(`Report written to ${outputPath}`);
  } else {
    console.log(content);
  }
}

function main() {
  try {
    const args = parseArguments();
    const data = loadDataFile(args.dataFile);
    const renderer = createRenderer(args.format);
    const options: FormatOptions = { includeTotals: args.includeTotals };
    const output = renderer.render(data, options);
    writeOutput(output, args.outputPath);
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

main();
