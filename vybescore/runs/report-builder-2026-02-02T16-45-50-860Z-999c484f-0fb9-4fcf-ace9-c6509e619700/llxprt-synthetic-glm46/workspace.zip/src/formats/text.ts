import { ReportData, FormatOptions, Renderer } from '../types.js';

/**
 * Text format renderer
 */
export class TextRenderer implements Renderer {
  render(data: ReportData, options: FormatOptions): string {
    const { title, summary, entries } = data;
    const { includeTotals } = options;
    
    // Header
    const lines: string[] = [];
    lines.push(title);
    lines.push('');
    
    // Summary
    lines.push(summary);
    lines.push('');
    
    // Entries
    lines.push('Entries:');
    for (const entry of entries) {
      lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
    }
    
    // Total if requested
    if (includeTotals) {
      const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
      lines.push(`Total: $${total.toFixed(2)}`);
    }
    
    // Remove trailing empty line
    if (lines[lines.length - 1] === '') {
      lines.pop();
    }
    
    return lines.join('\n');
  }
}