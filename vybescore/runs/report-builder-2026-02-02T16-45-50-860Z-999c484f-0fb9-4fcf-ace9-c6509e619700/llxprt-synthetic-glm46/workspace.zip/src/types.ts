/**
 * Core data structure for financial reports
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: Entry[];
}

/**
 * Individual financial entry with label and amount
 */
export interface Entry {
  label: string;
  amount: number;
}

/**
 * Common options passed to formatters
 */
export interface FormatOptions {
  includeTotals: boolean;
}

/**
 * Common interface for all format renderers
 */
export interface Renderer {
  render(data: ReportData, options: FormatOptions): string;
}