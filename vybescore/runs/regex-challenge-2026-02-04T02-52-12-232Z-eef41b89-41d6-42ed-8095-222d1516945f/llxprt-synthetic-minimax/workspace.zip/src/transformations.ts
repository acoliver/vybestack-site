/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;

  // First, normalize spacing - replace multiple spaces with single spaces
  let result = text.replace(/\s+/g, ' ');

  // Handle sentence endings followed by space and next sentence
  // Pattern: sentence ending (., ?, !) followed by optional space and a lowercase letter
  result = result.replace(/([.!?])(\s*)([a-z])/g, (match, punctuation, spaces, letter) => {
    return punctuation + spaces + letter.toUpperCase();
  });

  // Capitalize the first character of the text if it's a letter
  if (result.length > 0 && /[a-z]/.test(result[0])) {
    result = result[0].toUpperCase() + result.slice(1);
  }

  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];

  // Comprehensive URL pattern that captures common URL formats
  // Matches http/https URLs with optional www, domains, paths, query params, etc.
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"']+[^\s<>"'.?!,:;)$\]]/gi;

  const matches = text.match(urlPattern);
  if (!matches) return [];

  // Clean up URLs - remove trailing punctuation that shouldn't be part of the URL
  return matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[.,!?;]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;

  // Replace http:// with https:// but don't touch https://
  // Using word boundaries to avoid replacing http in other contexts
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;

  // Pattern to match http://example.com URLs
  // Group 1: full URL starting with http://example.com
  const pattern = /(http:\/\/example\.com[^\s<>"']*[^\s<>"'.?!,:;)$\]])/gi;

  return text.replace(pattern, (match) => {
    // Parse the URL components
    const urlMatch = match.match(/^http:\/\/example\.com(\/.*)?$/);
    if (!urlMatch) return match; // Don't modify if doesn't match expected pattern

    const path = urlMatch[1] || '/';

    // Check if path contains dynamic hints that should skip host rewrite
    const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py', '?', '&', '='];
    const hasDynamicHints = dynamicHints.some(hint => path.toLowerCase().includes(hint));

    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Rewrite for docs path: https://docs.example.com/...
      return match.replace(/^http:\/\/example\.com/, 'https://docs.example.com');
    } else {
      // Just upgrade scheme: https://example.com/...
      return match.replace(/^http:\/\//, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';

  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);

  if (!match) return 'N/A';

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';

  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (isLeapYear) {
      if (day < 1 || day > 29) return 'N/A';
    } else {
      if (day < 1 || day > 28) return 'N/A';
    }
  } else {
    if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  }

  return year;
}
