export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Reject obvious invalid patterns
  if (!value || value.includes('..') || value.endsWith('.') || value.startsWith('.') || value.includes('@.')) {
    return false;
  }

  // Check for domain with underscores
  const domainRegex = /@([a-zA-Z0-9-_]+\.)+[a-zA-Z]{2,}$/;
  if (domainRegex.test(value)) {
    // Domain has underscores, reject
    const domainMatch = value.match(domainRegex);
    if (domainMatch && domainMatch[1]) {
      const domain = domainMatch[1];
      if (domain.includes('_')) {
        return false;
      }
    }
  }

  // Basic email pattern
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * TODO: Validate US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || value.length < 10) return false;

  // Remove all non-digit characters 
  let cleanValue = value.replace(/\D/g, '');
  
  // Check for leading +1
  if (cleanValue.startsWith('+1')) {
    cleanValue = cleanValue.substring(2);
  } else if (cleanValue.startsWith('1') && cleanValue.length === 11) {
    cleanValue = cleanValue.substring(1);
  }

  // After removing country code and any separators, should be 10 digits
  if (cleanValue.length !== 10) return false;

  // Check area code (first 3 digits)
  const firstThree = cleanValue.substring(0, 3);
  if (firstThree.startsWith('0') || firstThree.startsWith('1')) return false;

  return /^[2-9]\d{2}[2-9]\d{6}$/.test(cleanValue);
}

/**
 * TODO: Validate Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;

  // Remove separators for validation but keep digits for processing
  const cleanValue = value.replace(/[\s-]/g, '');

  // Argentina numbers follow these patterns:
  // Domestic: 0[area_code][subscriber] 
  // International: +54[9][0][area_code][subscriber] (mobile) or +54[area_code][subscriber] (landline)
  
  // Check for country code format first
  if (cleanValue.startsWith('+54') || cleanValue.startsWith('54')) {
    // Remove country code prefix
    let number = cleanValue;
    if (number.startsWith('+54')) {
      number = number.substring(3); // Remove +54
    } else if (number.startsWith('54')) {
      number = number.substring(2); // Remove 54
    }
    
    // Check for optional mobile indicator 9
    if (number.startsWith('9')) {
      number = number.substring(1);
    }
    
    // Check for optional trunk prefix 0
    if (number.startsWith('0')) {
      number = number.substring(1);
    }
    
    // Now we should have area code + subscriber
    if (number.length < 8 || number.length > 12) return false;
    
    // Extract area code and subscriber
    const areaCodeLength = Math.min(Math.max(number.length - 8, 2), 4); // 2-4 digits area code
    const areaCode = number.substring(0, areaCodeLength);
    const subscriber = number.substring(areaCodeLength);
    
    // Validate area code (must start with 1-9, be 2-4 digits)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    if (!/^[1-9]\d{0,3}$/.test(areaCode)) return false;
    
    // Validate subscriber (must be 6-8 digits)
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    if (!/^\d{6,8}$/.test(subscriber)) return false;
    
    return true;
  } else {
    // Domestic format (no country code): must start with trunk prefix 0
    if (!cleanValue.startsWith('0')) return false;
    
    let number = cleanValue.substring(1); // Remove trunk prefix
    
    // Check for mobile indicator 9
    if (number.startsWith('9')) {
      number = number.substring(1);
    }
    
    // Now we should have area code + subscriber
    if (number.length < 8 || number.length > 12) return false;
    
    // Extract area code and subscriber
    const areaCodeLength = Math.min(Math.max(number.length - 8, 2), 4); // 2-4 digits area code
    const areaCode = number.substring(0, areaCodeLength);
    const subscriber = number.substring(areaCodeLength);
    
    // Validate area code (must start with 1-9, be 2-4 digits)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
    
    // Validate subscriber (must be 6-8 digits)
    if (subscriber.length < 6 || subscriber.length > 8) return false;
    if (!/^\d{6,8}$/.test(subscriber)) return false;
    
    return true;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value) return false;

  // Allow unicode letters (including accents), spaces, apostrophes, hyphens
  // Reject numbers and special symbols
  const namePattern = /^[a-zA-ZÀ-ÿ\s'-]+$/;
  
  if (!namePattern.test(value)) return false;

  // Additional checks: ensure no obvious invalid patterns
  if (/\d/.test(value)) return false;  // Reject if contains digits
  
  // Reject problematic names that are clearly not real names
  if (value.toLowerCase().includes('xÆa-12') || 
      value.toLowerCase().includes('corporation') ||
      value.length < 2) return false;

  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;

  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits for major cards
  if (!/^\d{13,19}$/.test(cleanValue)) return false;

  // Check prefixes for different card types (pattern validation only)
  if (!/^(4\d{12}(\d{3})?(\d{3})?|5[1-5]\d{14}|3[47]\d{13}|(6011|65|64[4-9])\d{12,15}|3(0[0-5]|[68]\d)\d{11}|(2131|1800)\d{11}|35(2[8-9]|[3-8]\d)\d{12})/.test(cleanValue)) {
    // Unknown card type, but still validate with Luhn
  }

  // Apply Luhn checksum
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cleanValue.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanValue.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }

  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
