/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];

  // Create a pattern for the prefix
  // Use word boundaries to ensure we match whole words
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'gi');

  const matches = text.match(pattern);
  if (!matches) return [];

  // Filter out exceptions (case insensitive)
  const lowerExceptions = exceptions.map(e => e.toLowerCase());
  return matches.filter(match => {
    return !lowerExceptions.includes(match.toLowerCase());
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];

  // Use lookbehind to ensure token appears after a digit
  // Use negative lookbehind to ensure token is not at the beginning
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const pattern = new RegExp(`(?<!^)\\d(${escapedToken})`, 'gi');

  const matches = text.match(pattern);
  if (!matches) return [];

  // Return the full matches including the leading digit
  return matches.filter(match => match); // Remove empty matches
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) return false;

  // Check for no whitespace
  if (/\s/.test(value)) return false;

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;

  // Check for at least one digit
  if (!/\d/.test(value)) return false;

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;

  // Check for immediate repeated sequences (e.g., abab, 1234, etc.)
  // Look for patterns that repeat immediately like abab, 123123, etc.
  const repeatPattern = /(.{2,})\1/;
  if (repeatPattern.test(value)) return false;

  // More specific check for alternating patterns
  // This catches sequences like abab, 1212, tutu, etc.
  for (let i = 0; i < value.length - 3; i++) {
    const pattern = value.substring(i, i + 2);
    const continuation = value.substring(i + 2, i + 4);
    if (pattern === continuation) return false;
  }

  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;

  // Exclude obvious IPv4 addresses first
  // IPv4 pattern: 4 octets (0-255) separated by dots
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    // Still need to check if it's a valid IPv4, but we'll reject all that look like IPv4
    return false;
  }

  // IPv6 address patterns
  // Full IPv6: 8 groups of 4 hex digits separated by colons
  const fullPattern = /\b(?:[a-fA-F0-9]{1,4}:){7}[a-fA-F0-9]{1,4}\b/;
  
  // Shorthand IPv6 with :: compression
  const shorthandPattern = /\b(?:[a-fA-F0-9]*:){1,7}:?\b/;
  
  // Check for common IPv6 patterns
  // Note: This is a simplified IPv6 detection
  // Real IPv6 validation is quite complex
  
  // Pattern for standard IPv6 addresses
  const standardPattern = /\b(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{0,4}\b/;
  
  // Pattern for addresses with port numbers or additional info
  const withBracketsPattern = /\[?[a-fA-F0-9:]+\]?:?\d*/;

  // Multiple pattern matching for comprehensive IPv6 detection
  return fullPattern.test(value) || 
         standardPattern.test(value) ||
         shorthandPattern.test(value) ||
         withBracketsPattern.test(value);
}
