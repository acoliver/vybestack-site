import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const DEFAULT_PAGE = 1;
    const DEFAULT_LIMIT = 5;
    const MAX_PAGE = 10000;
    const MAX_LIMIT = 1000;

    let page: number | undefined = undefined;
    let limit: number | undefined = undefined;

    // Validate page parameter
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (!Number.isInteger(pageNum) || !Number.isFinite(pageNum)) {
        return res.status(400).json({ error: 'Page must be a valid number' });
      }
      if (pageNum <= 0 || pageNum > MAX_PAGE) {
        return res.status(400).json({ error: `Page must be between 1 and ${MAX_PAGE}` });
      }
      page = pageNum;
    } else {
      page = DEFAULT_PAGE;
    }

    // Validate limit parameter
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (!Number.isInteger(limitNum) || !Number.isFinite(limitNum)) {
        return res.status(400).json({ error: 'Limit must be a valid number' });
      }
      if (limitNum <= 0 || limitNum > MAX_LIMIT) {
        return res.status(400).json({ error: `Limit must be between 1 and ${MAX_LIMIT}` });
      }
      limit = limitNum;
    } else {
      limit = DEFAULT_LIMIT;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
