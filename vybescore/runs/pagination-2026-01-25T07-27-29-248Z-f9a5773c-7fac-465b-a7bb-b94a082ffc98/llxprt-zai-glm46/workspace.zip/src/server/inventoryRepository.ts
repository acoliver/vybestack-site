import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

export class PaginationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'PaginationError';
  }
}

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validateAndParsePage(page: unknown): number {
  if (page === undefined || page === null) {
    return 1;
  }
  
  const num = Number(page);
  
  if (isNaN(num)) {
    throw new PaginationError('Invalid page: must be a number');
  }
  
  if (!Number.isInteger(num) || num < 1) {
    throw new PaginationError('Invalid page: must be a positive integer');
  }
  
  return num;
}

function validateAndParseLimit(limit: unknown): number {
  if (limit === undefined || limit === null) {
    return DEFAULT_LIMIT;
  }
  
  const num = Number(limit);
  
  if (isNaN(num)) {
    throw new PaginationError('Invalid limit: must be a number');
  }
  
  if (!Number.isInteger(num) || num < 1) {
    throw new PaginationError('Invalid limit: must be a positive integer');
  }
  
  if (num > MAX_LIMIT) {
    throw new PaginationError(`Invalid limit: must not exceed ${MAX_LIMIT}`);
  }
  
  return num;
}

export function listInventory(
  db: Database,
  options: { page?: unknown; limit?: unknown }
): InventoryPage {
  const page = validateAndParsePage(options.page);
  const limit = validateAndParseLimit(options.limit);

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = offset + limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
