import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, DEFAULT_LIMIT } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs
    function validateParam(param: string | undefined, name: string, defaultValue: number, maxValue?: number): number | null {
      if (param === undefined) {
        return defaultValue;
      }
      
      const num = Number(param);
      if (Number.isNaN(num)) {
        res.status(400).json({ error: `Invalid ${name} parameter: must be a valid number` });
        return null;
      }
      
      if (num <= 0) {
        res.status(400).json({ error: `Invalid ${name} parameter: must be greater than 0` });
        return null;
      }
      
      if (maxValue && num > maxValue) {
        res.status(400).json({ error: `Invalid ${name} parameter: cannot exceed ${maxValue}` });
        return null;
      }
      
      return Math.floor(num);
    }

    const page = validateParam(pageParam, 'page', 1, 10000);
    if (page === null) return;
    
    const limit = validateParam(limitParam, 'limit', DEFAULT_LIMIT, 100);
    if (limit === null) return;

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
