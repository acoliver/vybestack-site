/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      // Execute the side effect
      const newValue = updateFn(prevValue)
      if (newValue !== undefined) {
        observer.value = newValue
      }
      return newValue
    },
  }
  
  // Set this callback as active observer to track dependencies
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    // Execute initial effect to track dependencies
    const initialValue = updateFn(value)
    if (initialValue !== undefined) {
      observer.value = initialValue
    }
  } finally {
    setActiveObserver(previousObserver)
  }
  
  // Return unsubscribe function
  const unsubscribe: UnsubscribeFn = () => {
    observer._isDisposed = true
  }
  
  return unsubscribe
}