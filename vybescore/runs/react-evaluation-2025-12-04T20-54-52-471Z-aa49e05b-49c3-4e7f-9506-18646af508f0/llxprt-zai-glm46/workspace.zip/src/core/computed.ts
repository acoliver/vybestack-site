/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  Subject,
  getActiveObserver,
  setActiveObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === true) {
    equalFn = (a: T, b: T) => a === b
  }

  // Create a subject to make the computed observable
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }

  // Track dirty state for optimization
  let isDirty = true

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => {
      isDirty = true
      notifyObservers(subject)
      return undefined
    },
  }
  
  const getter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Add the active observer as dependent on this computed
      subject.observers.add(activeObs)
    }
    
    // Recompute only if dirty
    if (isDirty) {
      const previousObserver = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        const newValue = updateFn(subject.value)
        if (newValue !== undefined && !equalFn?.(newValue, subject.value)) {
          observer.value = newValue
          subject.value = newValue
        }
        isDirty = false
      } finally {
        setActiveObserver(previousObserver)
      }
    }
    
    return subject.value
  }

  // Initial computation
  const previousObserver = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    const initialValue = updateFn(value)
    if (initialValue !== undefined) {
      observer.value = initialValue
      subject.value = initialValue
    }
    isDirty = false
  } finally {
    setActiveObserver(previousObserver)
  }
  
  return getter
}