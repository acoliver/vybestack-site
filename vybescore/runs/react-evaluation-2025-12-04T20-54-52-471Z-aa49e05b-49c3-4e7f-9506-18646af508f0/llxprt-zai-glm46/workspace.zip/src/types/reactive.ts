/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T | undefined

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  _isDisposed?: boolean
}

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  const previous = activeObserver
  activeObserver = observer
  if (observer && !previous) {
    // Only run effect scheduling logic when we transition from no observer to an observer
  } else if (!observer && previous) {
    // Only run cleanup when we transition from observer to no observer
  }
}

export function isDisposedObserver<T>(observer: Observer<T>): boolean {
  return !!observer._isDisposed
}

// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function updateObserver<T>(observer: Observer<T>): void {
  if (!isDisposedObserver(observer)) {
    observer.updateFn(observer.value)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  subject.observers.forEach(observer => {
    const fullObserver = observer as Observer<T>
    if (fullObserver.updateFn !== undefined && !isDisposedObserver(fullObserver)) {
      fullObserver.updateFn(fullObserver.value)
    }
  })
}