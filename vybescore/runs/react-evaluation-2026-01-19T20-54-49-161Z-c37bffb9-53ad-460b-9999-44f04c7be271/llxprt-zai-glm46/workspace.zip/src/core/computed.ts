/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  registerDependency,
  notifyDependents
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject to wrap this computed value
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn: undefined,
  }
  
  // Create the observer with a custom updateFn that notifies dependents
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      const result = updateFn(prevValue)
      s.value = result
      // After updating, notify all dependents of this computed value
      notifyDependents(s)
      return result
    },
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      registerDependency(s)
    }
    return s.value
  }
  
  // Initial computation
  updateObserver(o)
  
  return read
}
