/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject } from '../types/reactive.js'

// Track all active callbacks for cleanup
const activeCallbacks = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create a subject to represent this callback
  const s: Subject<T> = {
    name: 'callback',
    observer: undefined,
    value: value as T,
    equalFn: undefined,
  }
  
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Wrap the updateFn to track dependencies during execution
  const originalUpdateFn = updateFn
  observer.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    s.value = result
    return result
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  activeCallbacks.add(observer as Observer<unknown>)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    activeCallbacks.delete(observer as Observer<unknown>)
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
