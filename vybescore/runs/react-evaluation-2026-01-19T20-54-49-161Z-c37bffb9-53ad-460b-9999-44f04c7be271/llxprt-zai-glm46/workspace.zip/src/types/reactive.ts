/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  dependents?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Track all observers to enable notifications
// Maps subject to set of observers that depend on it
const dependencyGraph = new Map<SubjectR, Set<ObserverR>>()

export function registerDependency(subject: SubjectR): void {
  const observer = activeObserver
  if (!observer) return
  
  if (!dependencyGraph.has(subject)) {
    dependencyGraph.set(subject, new Set())
  }
  dependencyGraph.get(subject)!.add(observer)
}

export function notifyDependents(subject: SubjectR): void {
  // Get all observers that depend on this subject
  const dependents = dependencyGraph.get(subject)
  if (dependents) {
    for (const observer of dependents) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}
