export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface ValidationError {
  field: keyof FormData;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data?: FormData;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^\+?[\d\s\-()]+$/;
const POSTAL_REGEX = /^[A-Za-z0-9\s-]+$/;

export function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: ValidationError[] = [];
  
  // Check required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalZipCode', 'country', 'email', 'phoneNumber'
  ];

  for (const field of requiredFields) {
    if (!data[field] || (typeof data[field] === 'string' && data[field].trim() === '')) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }

  // Email validation
  if (data.email && !EMAIL_REGEX.test(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phoneNumber) {
    const phone = data.phoneNumber.replace(/\s/g, ''); // Remove spaces for length check
    if (!PHONE_REGEX.test(data.phoneNumber) || phone.length < 7) {
      errors.push({
        field: 'phoneNumber',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation
  if (data.postalZipCode && !POSTAL_REGEX.test(data.postalZipCode)) {
    errors.push({
      field: 'postalZipCode',
      message: 'Please enter a valid postal/zip code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: errors.length === 0 ? data as FormData : undefined
  };
}

export function sanitizeInput(input: string): string {
  return input.trim().replace(/\s+/g, ' ');
}