import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';
import { FormData } from './validation.js';

class DatabaseManager {
  private static instance: DatabaseManager;
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  private constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  public static getInstance(): DatabaseManager {
    if (!DatabaseManager.instance) {
      DatabaseManager.instance = new DatabaseManager();
    }
    return DatabaseManager.instance;
  }

  public async initialize(): Promise<void> {
    if (this.db) {
      return;
    }

    // Initialize SQL.js
    this.sqlJs = await initSqlJs({
      locateFile: (file: string) => {
        // Look for sql.wasm in the same directory as this file
        return path.join(process.cwd(), file);
      }
    });

    // Load existing database or create new one
    const dbExists = fs.existsSync(this.dbPath);
    if (dbExists) {
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbBuffer);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    
    this.db.exec(schema);
    
    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
  }

  public async saveSubmission(data: FormData): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const sql = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_zip_code, country, 
        email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    this.db.run(sql, [
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvinceRegion,
      data.postalZipCode,
      data.country,
      data.email,
      data.phoneNumber
    ]);

    // Save to disk
    await this.persist();
  }

  private async persist(): Promise<void> {
    if (!this.db) return;

    const dbBuffer = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(dbBuffer));
  }

  public async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  public getDatabase(): Database | null {
    return this.db;
  }
}

export default DatabaseManager;