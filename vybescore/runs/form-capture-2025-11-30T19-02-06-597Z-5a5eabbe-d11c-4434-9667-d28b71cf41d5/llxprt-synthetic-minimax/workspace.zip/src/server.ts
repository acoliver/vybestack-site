import express, { Request, Response } from 'express';
import * as path from 'path';
import DatabaseManager from './database.js';
import { validateFormData, FormData } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Configure Express
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Set up view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Serve static files
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Initialize database
const dbManager = DatabaseManager.getInstance();

async function initializeDatabase(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// GET / - Render the contact form
app.get('/', (req: Request, res: Response) => {
  res.status(200).render('form', {
    errors: [],
    formData: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: Partial<FormData> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvinceRegion: req.body.stateProvinceRegion,
      postalZipCode: req.body.postalZipCode,
      country: req.body.country,
      email: req.body.email,
      phoneNumber: req.body.phoneNumber
    };

    const validationResult = validateFormData(formData);

    if (!validationResult.isValid) {
      // Re-render form with errors and previously entered values
      return res.status(400).render('form', {
        errors: validationResult.errors,
        formData
      });
    }

    // Save to database
    if (validationResult.data) {
      await dbManager.saveSubmission(validationResult.data);
      console.log('Form submission saved successfully');
    }

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      errors: [{ field: 'general', message: 'An error occurred while processing your submission. Please try again.' }],
      formData: req.body
    });
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.status(200).render('thank-you');
});

// Graceful shutdown handling
async function gracefulShutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    await dbManager.close();
    console.log('Database connection closed');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to view the application`);
    });

    // Handle server errors
    server.on('error', (error: NodeJS.ErrnoException) => {
      if (error.code === 'EADDRINUSE') {
        console.error(`Port ${PORT} is already in use`);
      } else {
        console.error('Server error:', error);
      }
      process.exit(1);
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export app for testing
export default app;

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}