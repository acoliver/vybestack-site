/**
 * Finds words beginning with the given prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Create word boundary regex for words with the given prefix
  const prefixPattern = new RegExp('\\b' + prefix + '[a-zA-Z]*\\b', 'g');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase()));
}

/**
 * Finds occurrences of the token when it appears after a digit and not at the start of the string.
 * Uses lookaheads/lookbehinds to match only the token occurrences meeting these criteria.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to find digits followed by the token and not at start of string
  const tokenPattern = new RegExp('(\\d)' + escapedToken, 'g');
  
  // Find all matches while checking position
  const result = [];
  let match;
  while ((match = tokenPattern.exec(text)) !== null) {
    if (match.index > 0) {
      // Return the full match including the digit
      result.push(match[0]);
    }
  }
  
  return result;
}

/**
 * Validates password strength according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (like abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length requirement
  if (value.length < 10) return false;
  
  // Check for required character classes
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"|,.<>\/?]/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences of 2 or more characters
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // First check if it looks like an IPv4 address
  const ipv4Pattern = /^\d{1,3}(?:\.\d{1,3}){3}$/;
  if (ipv4Pattern.test(value)) return false;
  
  // Look for IPv6 patterns within the text (not just matching the entire string)
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){1,6}|::[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}::|(?:[0-9a-fA-F]{1,4}:){1,5}::[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){0,1}:|:(?::[0-9a-fA-F]{1,4}){1,7}|:(?::[0-9a-fA-F]{1,4}){0,1}:|(?:[0-9a-fA-F]{1,4}:){6}(\d{1,3}\.){3}\d{1,3}|(?:[0-9a-fA-F]{1,4}:){0,5}:(\d{1,3}\.){3}\d{1,3}|::(?:\d{1,3}\.){3}\d{1,3}/;
  
  return ipv6Regex.test(value);
}
