export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Email validation using regular expressions.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for specific constraints
  if (!emailRegex.test(value)) return false;
  
  // No double dots
  if (value.includes('..')) return false;
  
  // No trailing dot in local or domain part
  if (value.endsWith('.')) return false;
  
  // Domain part should not contain underscores
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) return false;
  
  return true;
}

/**
 * US phone number validation.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all characters except digits, plus, parentheses, hyphens, and spaces
  const cleaned = value.replace(/[^\d()+\- ]/g, '');
  
  // Check for optional +1 prefix
  const hasPlusOne = cleaned.startsWith('+1');
  const coreNumber = hasPlusOne ? cleaned.substring(2) : cleaned;
  
  // Accept formats: (212) 555-7890, 212-555-7890, 2125557890
  const phoneRegex = /^\(?(\d{3})\)?[-\s]?(\d{3})[-\s]?(\d{4})$/;
  const match = coreNumber.match(phoneRegex);
  
  if (!match) return false;
  
  // Extract area code and validate it (cannot start with 0 or 1)
  const areaCode = match[1];
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  return true;
}

/**
 * Argentine phone number validation.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54, optional trunk prefix 0, optional mobile indicator 9.
 * Area code must be 2-4 digits (leading digit 1-9), subscriber number 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation, but keep them for parsing
  const digitsOnly = value.replace(/[^\d+]/g, '');
  
  // Check for optional country code +54
  const hasCountryCode = digitsOnly.startsWith('+54');
  const afterCountryCode = hasCountryCode ? digitsOnly.substring(3) : digitsOnly;
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !afterCountryCode.startsWith('0')) return false;
  
  // Extract trunk prefix, mobile indicator, area code, and subscriber number
  const hasTrunkPrefix = afterCountryCode.startsWith('0');
  const afterTrunkPrefix = hasTrunkPrefix ? afterCountryCode.substring(1) : afterCountryCode;
  
  const isMobile = afterTrunkPrefix.startsWith('9');
  const afterMobileIndicator = isMobile ? afterTrunkPrefix.substring(1) : afterTrunkPrefix;
  
  // Area code should be 2-4 digits (leading digit 1-9)
  let areaCodeLength = 2;
  while (areaCodeLength <= 4 && areaCodeLength < afterMobileIndicator.length) {
    areaCodeLength++;
  }
  
  for (let len = 2; len <= 4; len++) {
    if (len > afterMobileIndicator.length) break;
    
    const areaCode = afterMobileIndicator.substring(0, len);
    const subscriberNumber = afterMobileIndicator.substring(len);
    
    // Area code must start with 1-9
    if (areaCode[0] === '0' || areaCode[0] < '1') continue;
    
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
      // Validate the entire format with original separators
      const fullRegex = hasCountryCode 
        ? /^\+54\s?9?\s?\d{2,4}[\s-]?\d{3,4}[\s-]?\d{4}$/
        : /^0\d{2,4}[\s-]?\d{3,4}[\s-]?\d{4}$/;
      
      return fullRegex.test(value);
    }
  }
  
  return false;
}

/**
 * Personal name validation.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Must contain at least one letter
  const hasLetter = /[a-zA-Z\u00C0-\u024F\u0400-\u04FF]/.test(value);
  if (!hasLetter) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const validNameRegex = /^[a-zA-Z\u00C0-\u024F\u0400-\u04FF\s'-]+$/;
  
  // Reject digits and most symbols
  const hasInvalidChars = /[0-9@#%&*()+=\[\]{};:"|,.<>\/?`~$^]/.test(value);
  
  return validNameRegex.test(value) && !hasInvalidChars;
}

/**
 * Credit card validation for Visa/Mastercard/AmEx.
 * Checks valid prefixes and lengths, then runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Check if it's all digits
  if (!/^\d+$/.test(digitsOnly)) return false;
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  let validLength = false;
  
  if ((digitsOnly.startsWith('4') && (digitsOnly.length === 13 || digitsOnly.length === 16))) {
    validLength = true; // Visa
  } else if (
    (digitsOnly.match(/^(5[1-5]\d{0,14})$/) ||
     digitsOnly.match(/^(2(2[2-9]|[3-6]\d|[7][01]|720)\d{0,12})$/)) &&
    digitsOnly.length === 16
  ) {
    validLength = true; // Mastercard
  } else if (
    (digitsOnly.startsWith('34') || digitsOnly.startsWith('37')) &&
    digitsOnly.length === 15
  ) {
    validLength = true; // AmEx
  }
  
  if (!validLength) return false;
  
  // Luhn algorithm checksum
  let sum = 0;
  let isEven = false;
  
  for (let i = digitsOnly.length - 1; i >= 0; i--) {
    const digit = parseInt(digitsOnly.charAt(i), 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled = (doubled % 10) + 1;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
