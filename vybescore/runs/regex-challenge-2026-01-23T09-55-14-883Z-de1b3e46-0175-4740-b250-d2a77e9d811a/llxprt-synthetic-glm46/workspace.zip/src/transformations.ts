/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces sensibly while leaving abbreviations intact.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Split text into sentences using punctuation as delimiters
  const sentences = text.split(/([.?!])/);
  const result = [];
  
  // Track whether we should capitalize the next segment
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (i % 2 === 0) {
      // This is a text segment (not punctuation)
      if (segment.trim().length > 0) {
        if (capitalizeNext) {
          // Find the first alphabetical character to capitalize
          let processed = segment;
          for (let j = 0; j < processed.length; j++) {
            if (/[a-zA-Z]/.test(processed[j])) {
              processed = processed.substring(0, j) + processed[j].toUpperCase() + processed.substring(j + 1);
              break;
            }
          }
          result.push(processed);
          capitalizeNext = false;
        } else {
          result.push(segment);
        }
      } else {
        result.push(segment);
      }
    } else {
      // This is punctuation
      result.push(segment);
      // After punctuation, capitalize the next segment
      capitalizeNext = true;
    }
  }
  
  // Join the segments together
  let joined = result.join('');
  
  // Clean up spacing around punctuation
  joined = joined.replace(/\s+([.?!])/g, '$1'); // Remove space before punctuation
  joined = joined.replace(/([.?!])([a-zA-Z])/g, '$1 $2'); // Add space after punctuation
  
  // Clean up any excessive spaces at the beginning or end
  joined = joined.replace(/^\s+|\s+$/g, '');
  
  return joined;
}

/**
 * Extracts URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern (http/https/ftp)
  const urlRegex = /(?:https?:\/\/|ftp:\/\/)(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like .,;!?) but keep path punctuation like / and #
  return matches.map(url => url.replace(/[.,;!?)\s]+$/g, ''));
}

/**
 * Replaces http:// URLs with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites URLs from http://example.com/... according to specific rules:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  return text.replace(/http:\/\/example\.com(\/[^\s]*)/g, (match, path) => {
    // Always upgrade to https
    let newUrl = 'https://example.com' + path;
    
    // Check if we should rewrite the host for docs paths
    if (path.startsWith('/docs/')) {
      // Skip host rewrite if path contains dynamic hints
      const hasDynamicHints = /\/(?:cgi-bin|[?&#])|\/(?:jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Extract month, day, year from mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string to preserve leading zeros if any
  
  // Validate month
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year for February
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && (parseInt(year, 10) % 100 !== 0 || parseInt(year, 10) % 400 === 0));
  if (month === 2 && isLeapYear) {
    if (day < 1 || day > 29) return 'N/A';
  } else {
    if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  }
  
  return year;
}
