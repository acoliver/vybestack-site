/**
 * Check if string has immediate repeated sequences (like abab, xyxy)
 */
function hasRepeatedSequences(value: string): boolean {
  // Check for any 2+ character sequence that repeats immediately
  const pattern = /(..+)\1/;
  return pattern.test(value);
}

/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary pattern with prefix
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, ensuring the token starts immediately after the digit
  const pattern = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must not contain whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric, non-space)
  if (!/[^a-zA-Z0-9\s]/.test(value)) {
    return false;
  }
  
  // Must not have immediate repeated sequences (like abab, xyxy)
  if (hasRepeatedSequences(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns - check for any valid IPv6 address
  const ipv6Patterns = [
    // IPv6 with :: compression (most common case)
    /[0-9a-fA-F]*::[0-9a-fA-F]*/,
    
    // IPv6 starting with ::
    /::[0-9a-fA-F]*/,
    
    // IPv6 ending with ::
    /[0-9a-fA-F]*::/,
    
    // IPv6 with multiple colons (at least 3 colons to distinguish from IPv4)
    /[0-9a-fA-F]*:[0-9a-fA-F]*:[0-9a-fA-F]*/,
  ];
  
  // First check if there's any IPv6 pattern
  const hasIPv6 = ipv6Patterns.some(pattern => pattern.test(value));
  
  // If there's no IPv6, it's definitely not IPv6
  if (!hasIPv6) {
    return false;
  }
  
  // If we found IPv6 patterns, make sure it's not just IPv4 being mistaken
  // (IPv4 would have dots, not just colons)
  const hasDots = value.includes('.');
  const hasColons = value.includes(':');
  
  // If it has both dots and colons, it might be mixed content
  // But if it only has colons and matches IPv6 patterns, it's likely IPv6
  if (hasColons && !hasDots) {
    return true;
  }
  
  // If it has both dots and colons, check if the IPv6 patterns are genuine
  // by ensuring they don't overlap with IPv4 patterns
  return hasIPv6;
}
  