/**
 * Validate month/day combination
 */
function isValidMonthDay(month: number, day: number): boolean {
  if (month < 1 || month > 12) return false;
  if (day < 1 || day > 31) return false;
  
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const days = daysInMonth[month - 1];
  return day <= days;
}

/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and spacing
  let result = text;
  
  // Normalize multiple spaces to single spaces
  result = result.replace(/\s+/g, ' ');
  
  // Handle spacing after sentence endings
  result = result.replace(/([.!?])([^\s])/g, '$1 $2');
  
  // Capitalize the first letter of each sentence
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize the very first character of the string
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Ensure exactly one space after sentence endings
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  // Handle abbreviations by not capitalizing if previous context suggests it's an abbreviation
  // This is a simplified approach - in a real implementation you'd need a dictionary
  const abbreviationPatterns = [
    /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|vs|etc|e\.g|i\.e)\.\s*[A-Z]/g, // Common abbreviations
  ];
  
  // Don't capitalize after these patterns
  for (const pattern of abbreviationPatterns) {
    result = result.replace(pattern, (match) => {
      return match.toLowerCase();
    });
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlPattern = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+[^\s<>"'.,!?)]?/gi;
  const matches = text.match(urlPattern) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation that isn't part of the URL
    return url.replace(/[),.!?]+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/\bhttp:\/\/([^/\s]+)(\/[^\s]*)?/gi, (match, host, path = '') => {
    // Check if path exists and starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions in the path
      const dynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
      if (!dynamicHints.test(path)) {
        // Move to docs subdomain
        const newHost = `docs.${host}`;
        return `https://${newHost}${path}`;
      }
    }
    
    // Just upgrade to https
    return `https://${host}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month and day
  if (!isValidMonthDay(month, day)) {
    return 'N/A';
  }
  
  // Validate year (reasonable range)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return year.toString();
}