export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Run Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').reverse().map(Number);
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern that handles most cases including + character
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  // Additional checks for specific invalid patterns
  const invalidPatterns = [
    /\.\./, // Double dots
    /\.$/, // Trailing dot
    /@\./, // @ followed by dot
    /@.*\.\.$/, // Multiple trailing dots
    /@.*__.*@/, // Double underscores
    /@.*\._/, // Underscore before dot
    /@\._/, // Underscore right after @
  ];
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1
  let hasCountryCode = false;
  let digits = cleaned;
  
  if (cleaned.startsWith('+1')) {
    hasCountryCode = true;
    digits = cleaned.substring(2);
  } else if (cleaned.startsWith('+')) {
    return false; // Only +1 is allowed as country code
  }
  
  // Must be exactly 10 digits if no country code, or 11 digits if with country code
  if ((!hasCountryCode && digits.length !== 10) || (hasCountryCode && digits.length !== 11)) {
    return false;
  }
  
  // If has country code, first digit should be 1
  if (hasCountryCode && digits[0] !== '1') {
    return false;
  }
  
  // Remove country code for area code validation
  const localNumber = hasCountryCode ? digits.substring(1) : digits;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = localNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check if it matches common US phone patterns
  const phonePatterns = [
    /^\d{10}$/, // 1234567890
    /^(\d{3})(\d{3})(\d{4})$/, // 1234567890
    /^(\d{3})[- ](\d{3})[- ](\d{4})$/, // 123-456-7890 or 123 456 7890
    /^\((\d{3})\)[- ]?(\d{3})[- ]?(\d{4})$/, // (123) 456-7890
  ];
  
  for (const pattern of phonePatterns) {
    if (pattern.test(cleaned)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Extract digits only for analysis
  const digits = value.replace(/\D/g, '');
  
  // Basic length check - must have between 10-15 digits total
  if (digits.length < 10 || digits.length > 15) {
    return false;
  }
  
  let pos = 0;
  
  // Check for country code +54
  if (digits.startsWith('54')) {
    pos = 2;
    
    // Optional mobile indicator
    if (pos < digits.length && digits[pos] === '9') {
      pos++;
    }
    
    // Extract area code (2-4 digits, first digit 1-9)
    if (pos < digits.length) {
      const areaStart = pos;
      let areaLen = 0;
      while (pos < digits.length && pos - areaStart < 4 && digits[pos] >= '1' && digits[pos] <= '9') {
        pos++;
        areaLen++;
      }
      
      if (areaLen >= 2 && areaLen <= 4) {
        // Rest is subscriber number
        const subscriberLen = digits.length - pos;
        if (subscriberLen >= 6 && subscriberLen <= 8) {
          return true;
        }
      }
    }
  } else {
    // No country code - must start with 0
    if (digits.startsWith('0')) {
      pos = 1;
      
      // Optional mobile indicator
      if (pos < digits.length && digits[pos] === '9') {
        pos++;
      }
      
      // Extract area code (2-4 digits, first digit 1-9)
if (pos < digits.length) {
      const areaStart = pos;
      let areaLen = 0;
      while (pos < digits.length && pos - areaStart < 4 && digits[pos] >= '1' && digits[pos] <= '9') {
        pos++;
        areaLen++;
      }
        
        if (areaLen >= 2 && areaLen <= 4) {
          // Rest is subscriber number
          const subscriberLen = digits.length - pos;
          if (subscriberLen >= 6 && subscriberLen <= 8) {
            return true;
          }
        }
      }
    }
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty or just whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Unicode letters, accents, apostrophes, hyphens, and spaces allowed
  // No digits, no special symbols except ' - '
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Should not start or end with space
  if (value.trim() !== value) {
    return false;
  }
  
  // Should not have multiple consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }
  
  // Should not have multiple consecutive hyphens or apostrophes
  if (/[-']{2,}/.test(value)) {
    return false;
  }
  
  // Should not start or end with hyphen or apostrophe
  if (/^[-']|[-']$/.test(value)) {
    return false;
  }
  
  // Must have at least 2 characters (after trimming)
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit cards using Luhn checksum and proper prefixes/lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it's a valid length for credit cards (13-19 digits)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Check for valid credit card prefixes and lengths
  const validCards = [
    { prefix: '4', lengths: [13, 16, 19] }, // Visa
    { prefix: '5', lengths: [16] }, // Mastercard (starts with 5)
    { prefix: '37', lengths: [15] }, // American Express
    { prefix: '6', lengths: [16] }, // Discover (starts with 6)
  ];
  
  let isValidPrefix = false;
  let isValidLength = false;
  
  for (const card of validCards) {
    for (const length of card.lengths) {
      if (digitsOnly.length === length) {
        isValidLength = true;
        if (digitsOnly.startsWith(card.prefix)) {
          // For Mastercard, also check that it doesn't start with 5 followed by digits that would be invalid
          if (card.prefix === '5') {
            const secondDigit = digitsOnly.charAt(1);
            // Mastercard starts with 51-55
            if (secondDigit >= '1' && secondDigit <= '5') {
              isValidPrefix = true;
            }
          } else {
            isValidPrefix = true;
          }
        }
      }
    }
  }
  
  if (!isValidPrefix || !isValidLength) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}