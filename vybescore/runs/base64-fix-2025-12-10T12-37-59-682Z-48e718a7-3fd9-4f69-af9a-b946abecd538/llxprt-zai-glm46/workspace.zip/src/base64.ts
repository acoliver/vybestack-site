/**
 * Regular expression to validate Base64 strings.
 * Allows for optional padding at the end.
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input format and padding.
 */
function validateBase64Input(input: string): void {
  const paddingLength = (input.match(/=/g) || []).length;
  
  // Padding should only appear at the end and be 0, 1, or 2 characters
  if (paddingLength > 2 || (paddingLength > 0 && !input.endsWith('='.repeat(paddingLength)))) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64 strings.
 */
export function decode(input: string): string {
  // Trim whitespace but keep the string as-is for validation
  const trimmed = input.trim();
  
  // Validate Base64 format
  if (!BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check for correct padding
  validateBase64Input(trimmed);
  
  // For unpadded input, pad it to make length a multiple of 4
  let normalized = trimmed;
  const paddingLength = (trimmed.match(/=/g) || []).length;
  const lengthWithoutPadding = trimmed.length - paddingLength;
  
  if (paddingLength === 0 && lengthWithoutPadding % 4 !== 0) {
    const padLength = 4 - (lengthWithoutPadding % 4);
    normalized += '='.repeat(padLength);
  }
  
  try {
    const result = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Validate that the result is valid UTF-8
    if (normalized !== Buffer.from(result, 'utf8').toString('base64').replace(/=+$/, '')) {
      // Check if original had padding that was removed
      const paddedCheck = Buffer.from(result, 'utf8').toString('base64');
      if (normalized !== paddedCheck) {
        throw new Error('Invalid Base64 input: corrupted data');
      }
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input: corrupted data');
  }
}
