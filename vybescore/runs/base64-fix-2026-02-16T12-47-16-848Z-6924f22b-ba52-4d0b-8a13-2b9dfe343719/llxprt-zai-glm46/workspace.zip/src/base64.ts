/**
 * Encode plain text to Base64 using the canonical Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input format.
 */
function validateBase64Input(input: string): void {
  // Check for invalid characters (anything not in A-Z, a-z, 0-9, +, /, =, or whitespace)
  if (/[^A-Za-z0-9+/=\s]/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check that padding, if present, is only at the end and consists of 1-2 '=' chars
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      throw new Error('Invalid Base64 input: too much padding');
    }
    // Check there's no padding before the end
    if (/=.*?[^=]/.test(input)) {
      throw new Error('Invalid Base64 input: padding in the middle');
    }
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  validateBase64Input(trimmed);

  try {
    // Remove any whitespace and use standard base64 decoding
    const cleaned = trimmed.replace(/\s/g, '');
    
    const result = Buffer.from(cleaned, 'base64').toString('utf8');
    
    // Verify the decoding produced valid UTF-8
    // If the input was invalid base64, Buffer.from may produce garbage or empty
    // We check by trying to re-encode and compare (normalize padding)
    const reEncoded = Buffer.from(result, 'utf8').toString('base64');
    const normalized = cleaned.padEnd(Math.ceil(cleaned.length / 4) * 4, '=');
    
    // Check if the re-encoded matches (accounting for padding)
    const reEncodedNormalized = reEncoded.padEnd(Math.ceil(reEncoded.length / 4) * 4, '=');
    if (reEncodedNormalized !== normalized && cleaned !== reEncoded) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
