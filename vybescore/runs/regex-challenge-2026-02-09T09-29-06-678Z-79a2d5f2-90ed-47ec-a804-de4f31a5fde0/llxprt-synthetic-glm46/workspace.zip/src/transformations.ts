/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // First, split text into sentences using sentence-ending punctuation
  const sentences = text.split(/([.!?]+)/);
  
  // Process each sentence-start fragment
  let result = '';
  let capitalize = true; // First character of text should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const fragment = sentences[i];
    
    if (i % 2 === 0) {
      // This is a sentence content fragment
      if (capitalize && fragment) {
        // Find the first letter character
        const firstLetterIndex = fragment.search(/[a-zA-Z]/);
        if (firstLetterIndex !== -1) {
          // Capitalize the first letter
          const before = fragment.substring(0, firstLetterIndex);
          const firstLetter = fragment[firstLetterIndex].toUpperCase();
          const after = fragment.substring(firstLetterIndex + 1);
          result += before + firstLetter + after;
        } else {
          result += fragment;
        }
        capitalize = false; // Don't capitalize next fragment unless it's after punctuation
      } else {
        result += fragment;
      }
    } else {
      // This is punctuation
      result += fragment;
      capitalize = true; // Next content fragment should be capitalized
    }
  }
  
  // Clean up spacing between sentences
  // Find patterns like "punctuation followed by space" and ensure exactly one space
  // This handles cases where there might be multiple spaces or missing spaces
  result = result.replace(/([.!?])(\s*)/g, '$1 ');
  
  // Clean up extra spaces at the beginning and end
  result = result.trim();
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // URL regex pattern that matches most common URL formats
  // Matches http://, https://, and protocol-less URLs
  // Excludes trailing punctuation like .,!? and other symbols
  const urlRegex = /(https?:\/\/|www\.)[^\s<>"'`]+/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up each URL to remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation common in text
    return url.replace(/[.,!?;:'")\]}]+$/, '');
  });
  
  return cleanedUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace all http:// with https://, but only match complete URLs
  // Using negative lookahead to avoid matching https:// URLs
  const httpToHttpsRegex = /\bhttp:\/\//gi;
  
  return text.replace(httpToHttpsRegex, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // Match all http://example.com URLs
  const urlRegex = /http:\/\/example\.com(\/[^\s<>"'`]+)/g;
  
  return text.replace(urlRegex, (match, path) => {
    // Always upgrade to HTTPS
    let newUrl = 'https://';
    
    // Check if path contains dynamic hints that should prevent host rewrite
    const dynamicHints = [
      '/cgi-bin/', '?', '&', '=', '.jsp', '.php', '.asp', 
      '.aspx', '.do', '.cgi', '.pl', '.py'
    ];
    
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    
    // If the path begins with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      newUrl += 'docs.';
    }
    
    newUrl += 'example.com' + path;
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for valid month/day combinations
  // April, June, September, November have 30 days
  if ((monthNum === 4 || monthNum === 6 || monthNum === 9 || monthNum === 11) && dayNum > 30) {
    return 'N/A';
  }
  
  // February has 28 days (or 29 in leap years)
  if (monthNum === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    
    if (dayNum > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  }
  
  // All other months have 31 days
  return year;
}
