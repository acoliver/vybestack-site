/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) {
    return [];
  }
  
  // Create a regex pattern to match words starting with the prefix
  // \b matches word boundaries
  // \w+ matches one or more word characters
  const wordPattern = new RegExp(`\\b(${prefix}\\w+)`, 'gi');
  
  // Find all matches
  const matches = [...text.matchAll(wordPattern)];
  
  // Extract the matched words
  let words = matches.map(match => match[1].toLowerCase());
  
  // Remove duplicates
  words = [...new Set(words)];
  
  // Filter out exceptions
  const lowerCaseExceptions = exceptions.map(ex => ex.toLowerCase());
  const filteredWords = words.filter(word => !lowerCaseExceptions.includes(word));
  
  return filteredWords;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) {
    return [];
  }
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create a regex pattern to match the token with preceding digit
  // Use lookahead to match digit + token but ensure the token is preceded by a digit
  // and not at the start of the string
  const tokenPattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  // Find all matches in the text
  const matches = [...text.matchAll(tokenPattern)];
  
  // Return an array of the matched tokens with the preceding digit
  return matches.map(match => match[0]);
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (anything that's not alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab")
  // This regex looks for any 2-character sequence that repeats immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv6 address patterns
  // Full form: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // Shorthand: can have :: for consecutive zeros
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))/;
  
  // IPv4 address pattern (to exclude)
  const ipv4Pattern = /\b((25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If there's an IPv4 address in the string, it's not what we're looking for
  if (ipv4Pattern.test(value)) {
    // Check if there's also an IPv6 address (rare case)
    const hasIPv6 = ipv6Pattern.test(value);
    
    // If it has both (unlikely), return true if it's not just an IPv4-mapped IPv6
    if (hasIPv6) {
      // Look for IPv4-mapped IPv6 addresses like ::ffff:192.168.1.1
      const iPv4MappedPattern = /::ffff:(\d+\.\d+\.\d+\.\d+)/;
      if (iPv4MappedPattern.test(value)) {
        // Don't consider IPv4-mapped addresses as pure IPv6
        return false;
      }
    }
    
    return hasIPv6;
  }
  
  // Check for IPv6 address
  return ipv6Pattern.test(value);
}
