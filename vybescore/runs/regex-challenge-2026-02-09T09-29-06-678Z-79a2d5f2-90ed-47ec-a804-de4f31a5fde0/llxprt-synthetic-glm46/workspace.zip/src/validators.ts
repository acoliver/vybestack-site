export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part
  if (localPart.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local part
  if (localPart.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject double dots in domain
  if (domain.includes('..')) {
    return false;
  }
  
  // Reject domain parts that start or end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Test a single regex that captures all valid formats
  // Accepts: 212-555-7890, 2125557890, (212) 555-7890, 1 212 555 7890, +1 212 555 7890
  const phoneRegex = /^(\+1[\s-]?|1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  // Extract digits to validate area code constraints
  const digits = value.replace(/\D/g, '');
  
  // Check if we have exactly 10 digits (standard US number) or 11 digits (with country code)
  if (digits.length === 10) {
    // Standard US number without country code
    const areaCode = digits.substring(0, 3);
    
    // Area code can't start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    return true;
  } else if (digits.length === 11 && digits.startsWith('1')) {
    // US number with country code
    const areaCode = digits.substring(1, 4);
    
    // Area code can't start with 0 or 1
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    return true;
  } else {
    // Invalid length
    return false;
  }
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Don't check format first, just validate directly after cleaning
  
  // Remove all separators for validation
  const cleanValue = value.replace(/[\s\-()]/g, '');
  
  // Check for country code prefix
  const hasCountryCode = cleanValue.startsWith('+54');
  
  // Strip country code if present
  const afterCountryCode = hasCountryCode ? cleanValue.substring(3) : cleanValue;
  
  // Check for trunk prefix (0) when no country code is present
  const hasTrunkPrefix = !hasCountryCode && afterCountryCode.startsWith('0');
  
  // Strip trunk prefix if present
  const afterTrunkPrefix = hasTrunkPrefix ? afterCountryCode.substring(1) : afterCountryCode;
  
  // Check for mobile prefix (9)
  const hasMobilePrefix = afterTrunkPrefix.startsWith('9');
  
  // Strip mobile prefix if present
  const afterMobilePrefix = hasMobilePrefix ? afterTrunkPrefix.substring(1) : afterTrunkPrefix;
  
  // Remaining digits should contain area code + subscriber number
  // Area code is 2-4 digits, subscriber number is 6-8 digits
  if (afterMobilePrefix.length < 8 || afterMobilePrefix.length > 12) {
    return false;
  }
  
  // Extract area code (2-4 digits, first digit must not be 0)
  // Area code could be 2, 3, or 4 digits
  // Try 2-digit area code first
  const areaCode = afterMobilePrefix.substring(0, 2);
  const subscriberNumber = afterMobilePrefix.substring(2);
  
  if (areaCode.startsWith('0') || areaCode.length < 2) {
    return false;
  }
  
  // Area code is valid, check subscriber number length
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Validate that all remaining characters are digits
  if (!/^\d+$/.test(afterMobilePrefix)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace from start and end
  const trimmedValue = value.trim();
  
  // Empty names are invalid
  if (!trimmedValue) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(trimmedValue)) {
    return false;
  }
  
  // Check for symbols like X Æ A-12 style names
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  return nameRegex.test(trimmedValue);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check for empty string
  if (!cleaned) {
    return false;
  }
  
  // Check length for major card types
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  let isValidLength = false;
  let hasValidPrefix = false;
  
  // Visa check
  if (cleaned.length === 13 || cleaned.length === 16) {
    if (cleaned.startsWith('4')) {
      isValidLength = true;
      hasValidPrefix = true;
    }
  }
  
  // Mastercard check
  if (cleaned.length === 16) {
    const firstTwo = parseInt(cleaned.substring(0, 2));
    const firstFour = parseInt(cleaned.substring(0, 4));
    
    if ((firstTwo >= 51 && firstTwo <= 55) || (firstFour >= 2221 && firstFour <= 2720)) {
      isValidLength = true;
      hasValidPrefix = true;
    }
  }
  
  // AmEx check
  if (cleaned.length === 15) {
    const firstTwo = parseInt(cleaned.substring(0, 2));
    
    if (firstTwo === 34 || firstTwo === 37) {
      isValidLength = true;
      hasValidPrefix = true;
    }
  }
  
  if (!isValidLength || !hasValidPrefix) {
    return false;
  }
  
  // Luhn algorithm check
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run the Luhn checksum algorithm.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      const doubled = digit * 2;
      sum += doubled > 9 ? doubled - 9 : doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
