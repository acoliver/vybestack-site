/**
 * Encode plain text to Base64 using standard RFC 4648 encoding.
 * Produces output with canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) and required padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding and recovers the original Unicode string.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Normalize URL-safe Base64 characters to standard Base64
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
