import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import FormCaptureApp from '../../src/server.js';

let server: FormCaptureApp;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const app = new FormCaptureApp();
  await app.start();
  server = app;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server.getServerInstance()).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('firstName');
    expect(response.text).toContain('lastName');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
