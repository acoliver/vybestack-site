import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type FormData = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

type ValidationError = string;

interface AppError extends Error {
  statusCode?: number;
}

class FormCaptureApp {
  private app: express.Application;
  private db: Database | null = null;
  private dbPath: string;
  private server: undefined | import('http').Server;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
    this.setupErrorHandling();
  }

  private setupMiddleware(): void {
    this.app.use(express.json());
    this.app.use(express.urlencoded({ extended: true }));
    
    // Serve static files from public
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    
    // Set EJS as view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
      });

      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const fileBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(fileBuffer);
      } else {
        this.db = new SQL.Database();
        const schema = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
        this.db.run(schema);
        this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (this.db) {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    }
  }

  private validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  private validatePhone(phone: string): boolean {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    return phoneRegex.test(phone) && phone.trim().length > 0;
  }

  private validatePostalCode(postalCode: string): boolean {
    const postalRegex = /^[\w\s-]+$/;
    return postalRegex.test(postalCode) && postalCode.trim().length > 0;
  }

  private validateForm(data: Partial<FormData>): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required fields
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field]!.trim().length === 0) {
        const label = field.replace(/([A-Z])/g, ' $1').trim();
        errors.push(`${label.charAt(0).toUpperCase() + label.slice(1)} is required`);
      }
    }

    // Email validation
    if (data.email && !this.validateEmail(data.email)) {
      errors.push('Please enter a valid email address');
    }

    // Phone validation
    if (data.phone && !this.validatePhone(data.phone)) {
      errors.push('Please enter a valid phone number');
    }

    // Postal code validation
    if (data.postalCode && !this.validatePostalCode(data.postalCode)) {
      errors.push('Please enter a valid postal code');
    }

    return errors;
  }

  private setupRoutes(): void {
    // Home page - display form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', { 
        errors: [], 
        values: {} 
      });
    });

    // Form submission
    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: Partial<FormData> = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        streetAddress: req.body.streetAddress,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone
      };

      const errors = this.validateForm(formData);

      if (errors.length > 0) {
        return res.status(400).render('form', {
          errors,
          values: formData
        });
      }

      try {
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        // Insert into database
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          formData.firstName!,
          formData.lastName!,
          formData.streetAddress!,
          formData.city!,
          formData.stateProvince!,
          formData.postalCode!,
          formData.country!,
          formData.email!,
          formData.phone!
        ]);
        
        stmt.free();
        this.saveDatabase();

        // Redirect to thank you page
        res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
      } catch (error) {
        console.error('Database error:', error);
        errors.push('An error occurred while saving your submission. Please try again.');
        res.status(500).render('form', {
          errors,
          values: formData
        });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  private setupErrorHandling(): void {
    // 404 handler
    this.app.use((req: Request, res: Response) => {
      res.status(404).send('Page not found');
    });

    // General error handler
    this.app.use((err: AppError, req: Request, res: Response) => {
      console.error('Unhandled error:', err);
      res.status(err.statusCode || 500).send('Internal server error');
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
    
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }

  public async stop(): Promise<void> {
    console.log('Shutting down server...');
    
    if (this.server) {
      return new Promise<void>((resolve) => {
        this.server!.close(() => {
          console.log('HTTP server closed');
          resolve();
        });
      });
    }
  }

  public getServerInstance(): import('http').Server | undefined {
    return this.server;
  }

  public async cleanup(): Promise<void> {
    await this.stop();
    if (this.db) {
      this.db.close();
      this.db = null;
      console.log('Database connection closed');
    }
  }
}

// Graceful shutdown handler
async function handleShutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}, shutting down gracefully...`);
  if (app) {
    await app.cleanup();
  }
  process.exit(0);
}

// Initialize and start the app
const app = new FormCaptureApp();

// Handle shutdown signals
process.on('SIGTERM', () => handleShutdown('SIGTERM'));
process.on('SIGINT', () => handleShutdown('SIGINT'));

// Handle uncaught exceptions
process.on('uncaughtException', (error) => {
  console.error('Uncaught Exception:', error);
  handleShutdown('uncaughtException');
});

process.on('unhandledRejection', (reason, promise) => {
  console.error('Unhandled Rejection at:', promise, 'reason:', reason);
  handleShutdown('unhandledRejection');
});

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  app.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default FormCaptureApp;
