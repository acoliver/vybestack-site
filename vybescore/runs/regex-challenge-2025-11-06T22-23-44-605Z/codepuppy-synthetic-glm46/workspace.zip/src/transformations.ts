/**
 * Capitalize the first character of each sentence after .?!, insert exactly one space between sentences
 * Collapse extra spaces while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Add space after sentence endings if missing
  normalized = normalized.replace(/([.?!])([A-Za-z])/g, '$1 $2');
  
  // Split into sentences using a simpler approach
  // Find all sentence boundaries (., ?, !) and process the text between them
  const parts: string[] = [];
  let start = 0;
  
  // Use a regex to find sentence endings
  const sentenceEndRegex = /[.?!]/g;
  let match;
  
  while ((match = sentenceEndRegex.exec(normalized)) !== null) {
    const end = match.index;
    const sentence = normalized.substring(start, end + 1).trim();
    if (sentence) {
      parts.push(sentence);
    }
    start = end + 1;
  }
  
  // Add the remaining text after the last sentence ending
  if (start < normalized.length) {
    const remaining = normalized.substring(start).trim();
    if (remaining) {
      parts.push(remaining);
    }
  }
  
  // Process each sentence
  const processedSentences = parts.map((part) => {
    if (!part) return '';
    
    // Capitalize the first letter
    let processed = part;
    if (processed.length > 0) {
      processed = processed[0].toUpperCase() + processed.slice(1);
    }
    
    return processed;
  });
  
  // Join sentences with single space
  const result = processedSentences.filter(s => s.length > 0).join(' ');
  
  return result.trim();
}

/**
 * Find URLs in the text and return an array of matched URL strings without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL pattern that captures various URL formats
  // This pattern matches http(s), ftp, and protocol-relative URLs
  // It excludes trailing punctuation like .,!?) etc.
  const urlPattern = /\b(?:(?:https?|ftp):\/\/|www\.)[^\s<>"']+\b/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Strip trailing punctuation that's unlikely to be part of URL
    return url.replace(/[.,!?;:"'\)\]\}>]+$/g, '');
  }).filter(url => url.length > 0);
  
  // Remove duplicates while preserving order
  const uniqueUrls: string[] = [];
  const seen = new Set<string>();
  
  for (const url of cleanedUrls) {
    const normalized = url.toLowerCase();
    if (!seen.has(normalized)) {
      seen.add(normalized);
      uniqueUrls.push(url);
    }
  }
  
  return uniqueUrls;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https://, but not https:// (it should stay)
  // Use word boundary to avoid matching parts of other strings
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/...
 * Replaces host with docs.example.com when path begins with /docs/, but skips dynamic hints
 * Always upgrades scheme to https://
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, upgrade all http to https
  let result = enforceHttps(text);
  
  // Pattern to match URLs from example.com
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;
  
  result = result.replace(urlPattern, (match, protocol, domain, path = '') => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // If there's no path, just upgrade to https
    if (!path) {
      return secureProtocol + domain;
    }
    
    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = [
      /cgi-bin/i,
      /[?&=]/, // Query string indicators
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)($|\?|#)/i // Legacy extensions
    ];
    
    const hasDynamicHints = dynamicHints.some(hint => hint.test(path));
    
    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      return secureProtocol + 'docs.' + domain + path;
    }
    
    // Otherwise, just upgrade the protocol
    return secureProtocol + domain + path;
  });
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Trim whitespace
  const trimmed = value.trim();
  
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = trimmed.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day against month (including leap years for February)
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 28, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  // Check for leap year if February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  const maxDays = month === 2 && isLeapYear(year) ? 29 : daysInMonth[month];
  
  if (day > maxDays) {
    return 'N/A';
  }
  
  return year;
}