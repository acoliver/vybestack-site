export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Robust email validation supporting typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email validation regex pattern
  // Local part: letters, digits, +, ., -, _, but no consecutive dots or starting/ending dots
  // Domain part: letters, digits, -, ., no underscores, proper TLD format
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for invalid patterns
  if (value.includes('..') || value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('@.') || value.includes('.@')) return false;
  if (value.includes('_') && value.split('@')[1]?.includes('_')) return false;
  if (value.startsWith('-') || value.endsWith('-')) return false;
  
  // Basic structure check
  const atIndex = value.lastIndexOf('@');
  if (atIndex <= 0 || atIndex === value.length - 1) return false;
  
  const localPart = value.substring(0, atIndex);
  const domainPart = value.substring(atIndex + 1);
  
  // Local part checks
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  // Domain part checks
  if (domainPart.startsWith('.') || domainPart.endsWith('.')) return false;
  if (domainPart.includes('..')) return false;
  if (domainPart.includes('_')) return false;
  
  const domainParts = domainPart.split('.');
  if (domainParts.length < 2) return false;
  
  // Check TLD is at least 2 characters
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  return emailPattern.test(value);
}

/**
 * US phone number validation supporting (212) 555-7890, 212-555-7890, 2125557890, optional +1
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check for extensions if allowed
  if (options?.allowExtensions) {
    const extensionMatch = value.match(/(ext[.\s]?|x[.\s]?|#)(\d+)$/i);
    if (extensionMatch) {
      const baseNumber = value.substring(0, value.indexOf(extensionMatch[0]));
      return isValidUSPhone(baseNumber, { ...options, allowExtensions: false });
    }
  }
  
  // Handle optional +1 country code
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits for US phone number
  if (phoneNumber.length !== 10) return false;
  
  // Extract area code, exchange, and subscriber number
  const areaCode = phoneNumber.substring(0, 3);
  const exchange = phoneNumber.substring(3, 6);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange cannot start with 0 or 1
  if (exchange[0] === '0' || exchange[0] === '1') return false;
  
  // Validate format patterns
  const patterns = [
    /^\+?1?[\s.-]?\(?[2-9]\d{2}\)?[\s.-]?[2-9]\d{2}[\s.-]?\d{4}$/, // (212) 555-7890, 212-555-7890, etc.
    /^\+?1?[2-9]\d{9}$/, // 2125557890
  ];
  
  return patterns.some(pattern => pattern.test(value.replace(/\s+/g, ' ').trim()));
}

/**
 * Argentine phone number validation covering mobile/landline formats
 * Supports +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation, keep track of original for format checking
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it starts with +54 (country code)
  const hasCountryCode = cleaned.startsWith('+54');
  let phoneNumber = cleaned;
  
  if (hasCountryCode) {
    phoneNumber = cleaned.substring(3); // Remove +54
    
    // After country code, can have optional 0 (trunk) and optional 9 (mobile)
    if (phoneNumber.startsWith('0')) {
      phoneNumber = phoneNumber.substring(1); // Remove trunk prefix
    }
    
    if (phoneNumber.startsWith('9')) {
      phoneNumber = phoneNumber.substring(1); // Remove mobile indicator
    }
  } else {
    // Without country code, must start with 0 (trunk prefix)
    if (!phoneNumber.startsWith('0')) return false;
    phoneNumber = phoneNumber.substring(1); // Remove trunk prefix
    
    // Optional mobile indicator 9 after trunk
    if (phoneNumber.startsWith('9')) {
      phoneNumber = phoneNumber.substring(1); // Remove mobile indicator
    }
  }
  
  // Now phoneNumber should be: area code + subscriber number
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  
  if (phoneNumber.length < 8 || phoneNumber.length > 12) return false;
  
  // Find area code (2-4 digits)
  let areaCode: string = '';
  let subscriberNumber: string = '';
  
  // Try area code lengths from 2 to 4
  for (let areaCodeLength = 2; areaCodeLength <= 4; areaCodeLength++) {
    const potentialAreaCode = phoneNumber.substring(0, areaCodeLength);
    const potentialSubscriber = phoneNumber.substring(areaCodeLength);
    
    if (/^[2-9]\d{0,3}$/.test(potentialAreaCode) && 
        potentialSubscriber.length >= 6 && 
        potentialSubscriber.length <= 8) {
      areaCode = potentialAreaCode;
      subscriberNumber = potentialSubscriber;
      break;
    }
  }
  
  if (!areaCode || !subscriberNumber) return false;
  
  // Validate area code doesn't start with 0, has 2-4 digits
  if (!/^[2-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Validate subscriber number has 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  // Additional validation: check the original format
  const argentinePhonePattern = /^\+?54[\s-]?9?[\s-]?0?\d{2,4}[\s-]?\d{6,8}$/;
  if (!argentinePhonePattern.test(cleaned)) {
    // Try pattern without country code
    const localPattern = /^0[\s-]?9?[\s-]?\d{2,4}[\s-]?\d{6,8}$/;
    if (!localPattern.test(cleaned)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic length checks
  if (value.trim().length < 1 || value.length > 100) return false;
  
  // Check for numbers (reject X Æ A-12 style names)
  if (/\d/.test(value)) return false;
  
  // Check for forbidden characters (multiple consecutive special chars, etc.)
  if (/[<>{}\[\]\|~`@#$%^&*()_=+]/.test(value)) return false;
  
  // Don't allow multiple consecutive apostrophes or hyphens
  if (/'{2,}|-{2,}/.test(value)) return false;
  
  // Don't allow apostrophe at start/end or hyphen at start/end
  if (value.startsWith("'") || value.endsWith("'") || value.startsWith('-') || value.endsWith('-')) return false;
  
  // Allow: unicode letters, accents, apostrophes, hyphens, spaces
  const namePattern = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Additional validation for name structure
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  // Validate spacing (no excessive spaces)
  if (/\s{3,}/.test(value)) return false;
  
  // Don't allow space-apostrophe or apostrophe-space combinations
  if (/\s'|'\s/.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum)
 * Accepts Visa/Mastercard/AmEx
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check length based on card type
  const visaPattern = /^4\d{12}(\d{3})?$/; // 13 or 16 digits starting with 4
  const mastercardPattern = /^5[1-5]\d{14}$/; // 16 digits starting with 51-55
  const mastercardPatternNew = /^2(2[2-9]\d|3[0-5]\d|4[0-9]\d|5[01]\d|6[0-5]\d)\d{12}$/; // New Mastercard ranges
  const amexPattern = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  let isValidLength = false;
  if (visaPattern.test(cleaned) || mastercardPattern.test(cleaned) || 
      mastercardPatternNew.test(cleaned) || amexPattern.test(cleaned)) {
    isValidLength = true;
  }
  
  if (!isValidLength) return false;
  
  // Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
