/**
 * Find words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }
  
  // Create a Set for O(1) lookup of exceptions
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  // Use a simple approach: split text into words and check each
  const words = text.match(/\b[a-zA-Z0-9_]+\b/g) || [];
  
  const filteredWords: string[] = [];
  const seen = new Set<string>();
  
  for (const word of words) {
    // Check if word starts with prefix
    if (word.toLowerCase().startsWith(prefix.toLowerCase())) {
      const lowerWord = word.toLowerCase();
      if (!exceptionSet.has(lowerWord) && !seen.has(lowerWord)) {
        seen.add(lowerWord);
        filteredWords.push(word);
      }
    }
  }
  
  return filteredWords;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }
  
  // Use a simple approach: find occurrences manually
  const results: string[] = [];
  const seen = new Set<string>();
  
  let index = 0;
  const textLength = text.length;
  const tokenLength = token.length;
  
  while (index < textLength) {
    const tokenIndex = text.indexOf(token, index);
    
    if (tokenIndex === -1) break;
    
    // Check if token is not at start and preceded by a digit
    if (tokenIndex > 0 && /\d/.test(text[tokenIndex - 1])) {
      // Look back to find the start of the digit+token sequence
      let digitStart = tokenIndex - 1;
      while (digitStart >= 0 && /\d/.test(text[digitStart])) {
        digitStart--;
      }
      digitStart++;
      
      const match = text.substring(digitStart, tokenIndex + tokenLength);
      
      if (!seen.has(match)) {
        seen.add(match);
        results.push(match);
      }
    }
    
    index = tokenIndex + 1;
  }
  
  return results;
}

/**
 * Validate passwords: at least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (like abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Minimum length 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let patternLength = 2; patternLength <= 4; patternLength++) {
    for (let i = 0; i <= value.length - patternLength * 2; i++) {
      const pattern = value.substr(i, patternLength);
      const nextPattern = value.substr(i + patternLength, patternLength);
      if (pattern === nextPattern) {
        return false;
      }
    }
  }
  
  // Additional check for repeated sequences with one character in between (like ab1ab)
  if (/(.{2,})\d+\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // First, remove IPv4 addresses to avoid false positives
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  const textWithoutIPv4 = value.replace(ipv4Pattern, '');
  
  // IPv6 address patterns
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (compressed)
  const compressedIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){0,7}::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with leading/trailing ::
  const leadingTrailingCompressedPattern = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::\b/;
  
  // IPv6 with only :: (the unspecified address)
  const unspecifiedPattern = /\b::\b/;
  
  // IPv6 with embedded IPv4 (like ::ffff:192.168.1.1)
  const embeddedIPv4Pattern = /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // Check if any IPv6 patterns exist in the text without IPv4 addresses
  if (fullIPv6Pattern.test(textWithoutIPv4) ||
      compressedIPv6Pattern.test(textWithoutIPv4) ||
      leadingTrailingCompressedPattern.test(textWithoutIPv4) ||
      unspecifiedPattern.test(textWithoutIPv4) ||
      embeddedIPv4Pattern.test(textWithoutIPv4)) {
    // Additional validation: make sure we're not matching hexadecimal numbers that look like IPv6
    // IPv6 addresses should have at least one colon
    if (/:/.test(textWithoutIPv4)) {
      // More comprehensive check - remove words that have colons but aren't IPv6
      const potentialMatches = textWithoutIPv4.match(/\b[^\s]*:[^\s]*\b/g) || [];
      
      for (const match of potentialMatches) {
        if (isIPv6Address(match)) {
          return true;
        }
      }
    }
  }
  
  return false;
}

/**
 * Helper function to validate if a string is a proper IPv6 address
 */
function isIPv6Address(str: string): boolean {
  // Remove any surrounding punctuation
  const cleaned = str.replace(/^[.,!?;:"'\(\[\{]+|[.,!?;:"'\)\]\}]+$/g, '');
  
  // IPv6 patterns to check
  const patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits
    /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/,
    // Compressed with ::
    /^(?:[0-9a-fA-F]{1,4}:){1,7}:$/,
    /^::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}$/,
    /^[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})$/,
    /^:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)$/
  ];
  
  return patterns.some(pattern => pattern.test(cleaned));
}