export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

// Helper function for Luhn checksum check
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\s/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses according to typical requirements:
 * - Accept typical addresses with + tags and multiple domain levels
 * - Reject double dots, trailing dots, domains with underscores
 * - Use strict validation for local and domain parts
 */
export function isValidEmail(value: string): boolean {
  // Email regex that rejects double dots, trailing dots, and underscore in domains
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for disallowed patterns
  if (value.includes('..') || 
      value.startsWith('.') || 
      value.endsWith('.') ||
      value.includes('@.') ||
      value.endsWith('.@') ||
      value.includes('_@')) {
    return false;
  }
  
  return emailPattern.test(value);
}

/**
 * Validates US phone numbers with these rules:
 * - Accept formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 country code prefix
 * - Area codes cannot start with 0 or 1
 * - Rejects impossible formats
 */
export function isValidUSPhone(value: string): boolean {
  // Remove common separators for basic validation
  const cleanValue = value.replace(/[\s\-\(\)]/g, '');
  
  // Check for optional +1 country code
  const hasCountryCode = cleanValue.startsWith('+1');
  const digits = hasCountryCode ? cleanValue.substring(2) : cleanValue;
  
  // Must be 10 digits long (US phone numbers)
  if (digits.length !== 10) {
    return false;
  }
  
  // All characters must be digits
  if (!/^\d+$/.test(digits)) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Check for valid format with optional country code
  const completePattern = /^(\+1[ -]?)?(\(\d{3}\)[ -]?|\d{3}[ -]?)\d{3}[ -]?\d{4}$/;
  return completePattern.test(value);
}

/**
 * Validates Argentine phone numbers with these rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits in total
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators for validation but keep track of format
  const cleanValue = value.replace(/[\s\-\(\)]/g, '');
  
  // Main regex pattern for Argentine phone validation
  const pattern = /^(\+54)?(0?)(9?)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanValue.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, mobileIndicator, areaCode, subscriberNumber] = match;
  
  // If no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits (already enforced by regex)
  // Subscriber number must be 6-8 digits (already enforced by regex)
  
  // Check total length when formatted properly
  const totalDigits = cleanValue.replace(/\+/g, '').length;
  
  // Valid total digit counts:
  // - Minimum: Area code (2) + Subscriber (6) = 8 digits
  // - Maximum: Country code (2) + Area code (4) + Subscriber (8) = 14 digits
  if (totalDigits < 8 || totalDigits > 14) {
    return false;
  }
  
  return true;
}

/**
 * Validates names with these rules:
 * - Permit unicode letters, accents, apostrophes, hyphens, spaces
 * - Reject digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Check for invalid characters first (digits and special symbols)
  if (/[0-9]|[@#$%^&*()_+=\[\]{}|\\:;<>,.?/]/.test(value)) {
    return false;
  }
  
  // RegEx to match names with unicode letters, accented characters, apostrophes, hyphens, and spaces
  const namePattern = /^[\p{L}\s'-]+$/u;
  
  // Reject overly stylized names with excessive special characters (allowing more for complex names)
  const specialCharCount = (value.match(/[-']/g) || []).length;
  if (specialCharCount > 4) { // Increased limit to accommodate complex names
    return false;
  }
  
  // Minimum length of 2 characters
  if (value.trim().length < 2) {
    return false;
  }
  
  // Must match the pattern
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers with these rules:
 * - Accept Visa (4), Mastercard (5), AmEx (3) prefixes and appropriate lengths
 * - Run a Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove whitespace
  const cleanValue = value.replace(/\s/g, '');
  
  // Basic format validation
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: 13 or 16 digits starting with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/;
  
  // AmEx: 15 digits starting with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanValue);
}