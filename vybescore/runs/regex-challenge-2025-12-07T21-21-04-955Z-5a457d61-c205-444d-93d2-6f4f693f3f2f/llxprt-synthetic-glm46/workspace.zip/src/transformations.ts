/**
 * Capitalizes the first character of each sentence:
 * - Inserts exactly one space between sentences even if input omitted it
 * - Collapses extra spaces while preserving punctuation
 * - Handles sentence boundaries after .?!
 * - Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around punctuation
  // Add a space after punctuation if missing
  let normalized = text.replace(/([.!?])(?=[^\s\w])/g, '$1 ');
  
  // Also add space after punctuation before uppercase letter (not part of another word)
  normalized = normalized.replace(/([.!?])(?=[A-Z])/g, '$1 ');
  
  // Add space after punctuation directly before an uppercase letter
  normalized = normalized.replace(/([.!?])(?=[A-Z])/g, '$1 ');
  
  // Collapse multiple spaces to single spaces
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Capitalize the first character and each character after sentence punctuation
  const sentences = normalized.split(/([.!?]\s*)/);
  const result = [];
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    // If this is a sentence start (not punctuation), capitalize it
    if (i === 0 || (i > 0 && sentences[i-1].match(/[.!?]\s*/))) {
      result.push(segment.charAt(0).toUpperCase() + segment.slice(1));
    } else {
      result.push(segment);
    }
  }
  
  return result.join('');
}

/**
 * Extracts all URLs found in the text:
 * - Returns URLs as an array
 * - Strips trailing punctuation
 * - Supports http, https, ftp, and protocols without explicit scheme
 */
export function extractUrls(text: string): string[] {
  const urlPattern = /(https?:\/\/|ftp:\/\/|www\.)[^\s<>"{}|\\^`\[\]]+/gi;
  const matches = text.match(urlPattern) || [];
  
  // Strip trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:)]+$/g, ''));
}

/**
 * Enforces HTTPS scheme on all URLs:
 * - Replaces http:// with https://
 * - Leaves existing HTTPS URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not if it's already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs with these rules:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic content (cgi-bin, query strings, etc.)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  const urlPattern = /https?:\/\/example\.com(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match) => {
    // Always upgrade to HTTPS first
    let rewritten = match.replace('http://', 'https://');
    
    // Extract the path part after the domain
    const pathMatch = rewritten.match(/https:\/\/example\.com(\/[^\s?]*)/);
    
    if (pathMatch) {
      const path = pathMatch[1];
      
      // Check for dynamic content that should not trigger host rewrite
      const hasDynamicHints = /[?&=]|(cgi-bin)|\.(jsp|php|asp|aspx|do|cgi|pl|py)($|[?#])/i;
      
      // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
      if (path.startsWith('/docs/') && !hasDynamicHints.test(rewritten)) {
        rewritten = rewritten.replace('https://example.com/', 'https://docs.example.com/');
      }
    }
    
    return rewritten;
  });
}

/**
 * Extracts the year from dates in mm/dd/yyyy format:
 * - Returns the four-digit year if valid format
 * - Returns 'N/A' if format is invalid or month/day are out of range
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month (basic check, not considering leap years)
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}