/**
 * Finds words starting with a specific prefix but excludes specified exceptions:
 * - Uses word boundaries to match whole words
 * - Excludes any words found in the exceptions array
 * - Returns array of matching words (case-sensitive)
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary pattern for the prefix
  const wordPattern = new RegExp(`\\b${prefix}\\w+`, 'g');
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string:
 * - Uses lookahead to ensure the token is preceded by a digit
 * - Excludes the start of the string
 * - Returns array of matching tokens including the digit
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match digit + token, ensuring not at start of string
  const pattern = new RegExp(`(\\d${escapedToken})`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    // Check if the match is not at the beginning of the string
    if (match.index > 0) {
      matches.push(match[1]);
    }
  }
  
  return matches;
}

/**
 * Validates password strength with these requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab fails)
 */
export function isStrongPassword(value: string): boolean {
  // Length check
  if (value.length < 10) {
    return false;
  }
  
  // Character class checks
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\w\s]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol || hasWhitespace) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212, etc.)
  // This pattern looks for any 2-character sequence that immediately repeats
  for (let i = 0; i < value.length - 3; i++) {
    if (value[i] === value[i+2] && value[i+1] === value[i+3]) {
      return false;
    }
  }
  
  // Also check for repeated character sequences (aaaa, 1111, etc.)
  const repeatCharPattern = /(.)\1{3,}/.test(value);
  if (repeatCharPattern) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses while excluding IPv4 addresses:
 * - Matches full IPv6 addresses with 8 groups of 1-4 hex digits
 * - Handles shorthand notation with ::
 * - Uses specific patterns to exclude IPv4 addresses
 * - Returns true if IPv6 is detected, false otherwise
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regular expression that handles various formats
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  // Check for IPv6 addresses
  const hasIPv6 = ipv6Pattern.test(value);
  
  // If IPv6 found, make sure it's not actually IPv4
  if (hasIPv6) {
    // Check if it looks more like an IPv4 address
    const ipv4InIPv6 = value.match(/:\d+\.\d+\.\d+\.\d+/);
    const pureIPv4 = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(value);
    
    // If it's pure IPv4 or IPv4 embedded in IPv6 notation, don't treat as IPv6
    if (pureIPv4 || ipv4InIPv6) {
      return false;
    }
    
    return true;
  }
  
  return false;
}