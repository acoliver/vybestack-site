import type { ReportData, ReportOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: ReportOptions): string {
  // Calculate total if requested
  let total = '0.00';
  if (options.includeTotals) {
    const totalAmount = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    total = totalAmount.toFixed(2);
  }

  // Build output lines
  const lines: string[] = [];

  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }

  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** $${total}`);
  }

  return lines.join('\n');
}