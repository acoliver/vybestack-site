#!/usr/bin/env node

import fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportOptions } from '../types.js';

function printHelp() {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Supported formats:');
  console.error('  markdown - Render as markdown format');
  console.error('  text     - Render as plain text format');
  console.error('');
  console.error('Options:');
  console.error('  --output <path>      Write output to file instead of stdout');
  console.error('  --includeTotals      Include totals in the report');
}

function parseArgs(args: string[]): {
  inputPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 3) {
    console.error('Error: Missing required arguments');
    printHelp();
    process.exit(1);
  }

  const inputPath = args[0];
  const formatArgIndex = args.indexOf('--format');
  
  if (formatArgIndex === -1 || formatArgIndex + 1 >= args.length) {
    console.error('Error: --format is required and needs a value');
    printHelp();
    process.exit(1);
  }

  const format = args[formatArgIndex + 1];
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    inputPath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${i}: expected object`);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field`);
    }
  }

  return data as ReportData;
}

function main() {
  try {
    const args = process.argv.slice(2);
    const { inputPath, format, outputPath, includeTotals } = parseArgs(args);

    // Load and validate input JSON
    let data: unknown;
    try {
      const jsonContent = fs.readFileSync(inputPath, 'utf8');
      data = JSON.parse(jsonContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error parsing JSON file ${inputPath}: ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error reading file ${inputPath}: ${error.message}`);
      } else {
        console.error(`Unknown error reading file ${inputPath}`);
      }
      process.exit(1);
      return;
    }

    // Validate report data structure
    const reportData: ReportData = validateReportData(data);

    // Render report based on format
    const options: ReportOptions = { includeTotals };
    let output: string;

    switch (format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        console.error(`Error: Unsupported format "${format}"`);
        process.exit(1);
        return;
    }

    // Write output
    if (outputPath) {
      try {
        fs.writeFileSync(outputPath, output, 'utf8');
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error writing to file ${outputPath}: ${error.message}`);
        } else {
          console.error(`Unknown error writing to file ${outputPath}`);
        }
        process.exit(1);
        return;
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

main();
