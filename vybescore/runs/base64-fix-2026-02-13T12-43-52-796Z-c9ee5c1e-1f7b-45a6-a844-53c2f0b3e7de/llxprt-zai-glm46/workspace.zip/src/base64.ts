/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with padding (=) as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 format and throw an error if invalid.
 */
function validateBase64(input: string): void {
  if (input.length === 0) {
    throw new Error('Failed to decode Base64 input: empty input');
  }

  // Validate Base64 format: only allow A-Z, a-z, 0-9, +, /, and = (padding)
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Pattern.test(input)) {
    throw new Error('Failed to decode Base64 input: invalid characters');
  }

  // Validate padding placement and length
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must be at the end
    const paddingSection = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      throw new Error('Failed to decode Base64 input: invalid padding');
    }
    // Padding can only be 1 or 2 characters (never 3)
    if (paddingSection.length > 2) {
      throw new Error('Failed to decode Base64 input: invalid padding');
    }
    // Total length with padding must be multiple of 4
    if (input.length % 4 !== 0) {
      throw new Error('Failed to decode Base64 input: invalid length');
    }
  }
  // Without padding, length does not need to be a multiple of 4
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  validateBase64(trimmed);

  const buffer = Buffer.from(trimmed, 'base64');
  
  // Check if decoding actually worked (invalid base64 may produce empty buffer)
  if (buffer.length === 0 && trimmed.length > 0) {
    const hasNonWhitespace = /[^\s]/.test(trimmed);
    if (hasNonWhitespace) {
      throw new Error('Failed to decode Base64 input: invalid data');
    }
  }
  
  return buffer.toString('utf8');
}
