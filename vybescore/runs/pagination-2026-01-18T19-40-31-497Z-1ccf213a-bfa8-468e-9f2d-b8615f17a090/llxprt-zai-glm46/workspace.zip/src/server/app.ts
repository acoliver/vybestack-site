import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    let page: number | undefined;
    if (pageParam !== undefined) {
      const pageNum = Number(pageParam);
      if (isNaN(pageNum) || !Number.isInteger(pageNum) || pageNum < 1) {
        return res.status(400).json({ error: 'Invalid page parameter. Must be a positive integer.' });
      }
      if (pageNum > 1000000) {
        return res.status(400).json({ error: 'Page parameter exceeds maximum allowed value.' });
      }
      page = pageNum;
    }

    // Validate limit parameter
    let limit: number | undefined;
    if (limitParam !== undefined) {
      const limitNum = Number(limitParam);
      if (isNaN(limitNum) || !Number.isInteger(limitNum) || limitNum < 1) {
        return res.status(400).json({ error: 'Invalid limit parameter. Must be a positive integer.' });
      }
      if (limitNum > 1000) {
        return res.status(400).json({ error: 'Limit parameter exceeds maximum allowed value.' });
      }
      limit = limitNum;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
