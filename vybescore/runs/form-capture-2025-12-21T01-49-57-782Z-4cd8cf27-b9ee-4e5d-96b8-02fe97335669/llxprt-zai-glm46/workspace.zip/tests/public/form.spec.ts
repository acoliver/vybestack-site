import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { shutdown } from '../../src/server.js';

// Server will be started when module is imported
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

afterAll(async () => {
  if (shutdown) {
    await shutdown();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
