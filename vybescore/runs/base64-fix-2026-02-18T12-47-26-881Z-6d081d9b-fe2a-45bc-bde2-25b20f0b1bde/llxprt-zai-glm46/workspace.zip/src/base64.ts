const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Validate that a string is valid Base64.
 * Checks for valid characters and proper structure.
 */
function isValidBase64(input: string): boolean {
  if (!BASE64_REGEX.test(input)) {
    return false;
  }

  // Check padding is only at the end and correct length
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2) {
      return false;
    }
    // Total length (with padding) must be multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws an error for invalid Base64.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding was successful (Buffer.from is lenient)
    // Re-encode and compare to ensure validity
    const reEncoded = buffer.toString('base64');
    const normalizedInput = trimmed.replace(/=+$/, '');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReEncoded) {
      throw new Error(INVALID_BASE64_ERROR);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
