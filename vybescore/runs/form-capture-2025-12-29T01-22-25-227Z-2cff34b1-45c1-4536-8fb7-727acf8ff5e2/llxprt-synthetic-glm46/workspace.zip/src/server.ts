import express, { type Request, Response } from "express";
import path from "path";
import fs from "fs";
import { Database } from "sql.js";
import { fileURLToPath } from "url";

// Get __dirname equivalent for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Type definitions
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

const app = express();
const port = process.env.PORT || 3535;

// Configure middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory
app.use("/public", express.static(path.join(__dirname, "../public")));

// Initialize SQLite database
let db: Database;
const dbPath = path.join(__dirname, "../data/submissions.sqlite");

async function initializeDatabase() {
  try {
    // Load Database
    const SQL = await import("sql.js");
    const sqlJs = await SQL.default();
    
    // Load or create database file
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }
    
    db = new sqlJs.Database(dbData);
    
    // Create schema if needed
    const schemaPath = path.join(__dirname, "../db/schema.sql");
    const schema = fs.readFileSync(schemaPath, "utf8");
    db.exec(schema);
    
    console.log("Database initialized successfully");
  } catch (error) {
    console.error("Failed to initialize database:", error);
    throw error;
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 5;
}

function validatePostalCode(postalCode: string): boolean {
  const postalCodeRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalCodeRegex.test(postalCode);
}

function validateForm(data: FormData): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields validation
  if (!data.firstName.trim()) errors.push("First name is required");
  if (!data.lastName.trim()) errors.push("Last name is required");
  if (!data.streetAddress.trim()) errors.push("Street address is required");
  if (!data.city.trim()) errors.push("City is required");
  if (!data.stateProvince.trim()) errors.push("State/Province/Region is required");
  if (!data.postalCode.trim()) errors.push("Postal code is required");
  if (!data.country.trim()) errors.push("Country is required");
  
  // Email validation
  if (!validateEmail(data.email)) {
    errors.push("Please enter a valid email address");
  }
  
  // Phone validation
  if (!validatePhone(data.phone)) {
    errors.push("Please enter a valid phone number");
  }
  
  // Postal code validation
  if (!validatePostalCode(data.postalCode)) {
    errors.push("Please enter a valid postal code");
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Define routes
app.get("/", (req, res) => {
  res.render("form", { 
    errors: [], 
    values: {} 
  });
});

app.post("/submit", (req, res) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName || "",
      lastName: req.body.lastName || "",
      streetAddress: req.body.streetAddress || "",
      city: req.body.city || "",
      stateProvince: req.body.stateProvince || "",
      postalCode: req.body.postalCode || "",
      country: req.body.country || "",
      email: req.body.email || "",
      phone: req.body.phone || ""
    };
    
    // Validate form data
    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render("form", {
        errors: validation.errors,
        values: formData
      });
    }
    
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    stmt.free();
    
    // Save database to file
    fs.writeFileSync(dbPath, new Uint8Array(db.export()));
    
    // Redirect to thank you page
    res.redirect(302, `/thank-you`);
  } catch (error) {
    console.error("Error submitting form:", error);
    const errorMessage = "An error occurred while submitting your form. Please try again.";
    res.status(500).render("form", {
      errors: [errorMessage],
      values: req.body
    });
  }
});

app.get("/thank-you", (req, res) => {
  try {
    // Get the most recent submission to extract first name
    const result = db.exec(`
      SELECT first_name FROM submissions 
      ORDER BY created_at DESC 
      LIMIT 1
    `);
    
    let firstName = "Friend";
    if (result.length > 0 && result[0].values.length > 0 && result[0].values[0].length > 0) {
      firstName = String(result[0].values[0][0]);
    }
    
    res.render("thank-you", { 
      firstName: firstName
    });
  } catch (error) {
    console.error("Error retrieving data for thank you page:", error);
    res.render("thank-you", { 
      firstName: "Friend"
    });
  }
});

// Set up EJS as view engine
app.set("views", path.join(__dirname, "templates"));
app.set("view engine", "ejs");

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err.stack);
  res.status(500).render("form", {
    errors: ["An unexpected error occurred"],
    values: {}
  });
});

// Graceful shutdown function
function gracefulShutdown() {
  console.log("Shutting down gracefully...");
  if (db) {
    db.close();
  }
  process.exit(0);
}

// Initialize server
async function startServer() {
  try {
    await initializeDatabase();
    
    app.listen(port, () => {
      console.log(`Server is running on port ${port}`);
    });
    
    // Handle signals
    process.on("SIGTERM", gracefulShutdown);
    process.on("SIGINT", gracefulShutdown);
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();
