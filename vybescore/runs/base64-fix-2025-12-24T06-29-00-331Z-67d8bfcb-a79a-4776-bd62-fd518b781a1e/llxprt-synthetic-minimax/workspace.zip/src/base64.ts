/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Handles input with or without padding and validates the Base64 format.
 */
export function decode(input: string): string {
  // Remove any whitespace
  const cleanInput = input.replace(/\s/g, '');
  
  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(cleanInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check that the input length is valid for Base64 (allowing missing padding)
  const paddedLength = Math.ceil(cleanInput.length / 4) * 4;
  if (paddedLength - cleanInput.length > 2) {
    throw new Error('Invalid Base64 input: too much missing padding');
  }

  try {
    return Buffer.from(cleanInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
