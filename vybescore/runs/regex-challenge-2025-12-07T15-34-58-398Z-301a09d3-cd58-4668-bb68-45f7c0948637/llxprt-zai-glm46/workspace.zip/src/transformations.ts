/**
 * Capitalizes the first character of each sentence while preserving spacing rules.
 * Capitalizes the first character after ., !, or ?, inserts exactly one space between sentences,
 * and collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // Common abbreviations that shouldn't trigger sentence capitalization
  const abbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|Dept|U\.S|U\.S\.A|U\.K|etc|e\.g|i\.e|vs|approx|no|vol|fig|p|pp|ch|sec|min|hr|ft|lb|oz|gal|qt|pt|in|cm|mm|km|m|kg|g|lb|oz|mb|kb|gb|tb|phd|ba|bs|ms|ma|b\.sc|m\.sc)\.?$/i;
  
  // Step 1: Normalize spacing - collapse multiple spaces to single space
  let result = text.replace(/\s+/g, ' ');
  
  // Step 2: Ensure proper spacing after sentence endings
  result = result.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Step 3: Split into sentences, process each, and rejoin
  const sentences = result.split(/([.!?])/);
  let capitalizeNext = true;
  const processedSentences: string[] = [];
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i] || '';
    const punctuation = sentences[i + 1] || '';
    
    if (sentence.trim()) {
      // Check if this is an abbreviation
      const trimmedSentence = sentence.trim();
      if (capitalizeNext && !abbreviations.test(trimmedSentence)) {
        // Capitalize the first letter
        const capitalizedSentence = sentence.replace(/^(\s*)([a-z])/, (match, spaces, letter) => {
          return spaces + letter.toUpperCase();
        });
        processedSentences.push(capitalizedSentence);
      } else {
        processedSentences.push(sentence);
      }
      
      // Determine if next sentence should be capitalized
      capitalizeNext = !!(punctuation && /[.!?]/.test(punctuation));
    } else if (sentence) {
      processedSentences.push(sentence);
    }
    
    if (punctuation) {
      processedSentences.push(punctuation);
    }
  }
  
  result = processedSentences.join('');
  
  // Step 4: Clean up final spacing
  result = result.replace(/\s+([.!?])/g, '$1'); // Remove spaces before punctuation
  result = result.replace(/\s+/g, ' '); // Collapse any remaining multiple spaces
  result = result.trim(); // Remove leading/trailing spaces
  
  return result;
}

/**
 * Finds URLs in the text and returns them as an array without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }
  
  // URL regex that matches:
  // - http:// or https://
  // - www.
  // - domain name with subdomains
  // - top-level domain
  // - optional path, query, and fragment
  const urlRegex = /(https?:\/\/[^\s<>"']+|www\.[^\s<>"']+)/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up matches by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters that are not part of the URL
    return url.replace(/[.,;:!?)\]}>]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // Replace http:// with https://, but don't touch https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://..., moving docs paths to https://docs.example.com/
 * Always upgrades the scheme to https://, and when the path begins with /docs/, rewrites the host to docs.example.com.
 * Skips host rewrite when path contains dynamic hints like cgi-bin, query strings, or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return text;
  }
  
  // First, upgrade all http:// to https://
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Pattern to match URLs that need host rewriting for docs
  // This captures: https://example.com/docs/... but excludes dynamic paths
  const docsUrlRegex = /(https:\/\/)([^/\s]+)(\/docs\/[^\s]*?)(?=[\s.,;:!?)]|$)/g;
  
  // Check if the URL contains dynamic hints that should prevent host rewriting
  const shouldSkipHostRewrite = (url: string): boolean => {
    const skipPatterns = [
      /\/cgi-bin\//i,
      /[?&]/,           // query strings
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/i  // legacy extensions
    ];
    
    return skipPatterns.some(pattern => pattern.test(url));
  };
  
  result = result.replace(docsUrlRegex, (match, protocol, host, path) => {
    // Check if we should skip host rewrite due to dynamic content
    if (shouldSkipHostRewrite(match)) {
      return match; // Only upgrade scheme (already done)
    }
    
    // For docs paths, rewrite host to docs.{originalHost}
    return protocol + 'docs.' + host + path;
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Additional validation for day based on month
  const maxDay = getMaxDayInMonth(month);
  if (day > maxDay) {
    return 'N/A';
  }
  
  return yearStr;
}

/**
 * Helper function to get the maximum number of days in a month.
 */
function getMaxDayInMonth(month: number): number {
  switch (month) {
    case 2: // February - assuming non-leap year
      return 28;
    case 4: // April
    case 6: // June
    case 9: // September
    case 11: // November
      return 30;
    default: // All other months
      return 31;
  }
}