export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with common patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that covers most valid cases
  // Local part: letters, digits, +, -, ., apostrophes, but no consecutive dots or starting/ending with dot
  // Domain part: letters, digits, hyphens, dots but no underscores, no starting/ending dots, no consecutive dots
  // TLD: 2-63 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // More restrictive patterns
  const localPartRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  const domainPartRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Test basic format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  const [localPart, domainPart] = value.split('@');
  
  // Local part should not start or end with dot, and no consecutive dots
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }
  
  // Domain part should not have underscores, no consecutive dots, or start/end with dots
  if (domainPart.includes('_') || domainPart.startsWith('.') || domainPart.endsWith('.') || domainPart.includes('..')) {
    return false;
  }
  
  // Final validation with more specific regex
  if (!localPartRegex.test(localPart) || !domainPartRegex.test(domainPart)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1 prefix.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (should have at least 10 digits for US number)
  if (digits.length < 10) {
    return false;
  }
  
  // Remove optional +1 country code if present
  let phoneNumber = digits;
  if (digits.length === 11 && digits.startsWith('1')) {
    phoneNumber = digits.slice(1);
  } else if (digits.length > 11) {
    return false; // Too many digits
  }
  
  // For numbers that were 11 digits but didn't start with 1
  if (digits.length === 11 && !digits.startsWith('1')) {
    return false;
  }
  
  // Should now have exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code and validate it doesn't start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate overall format using regex for supported patterns
  const usPhoneRegex = /^(?:\+1[\s.-]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2}))[,\s.-]*([2-9]\d{2})[,\s.-]*(\d{4})(?:\s*x\d+)?$/;
  return usPhoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // For numbers with country code
  const withCountryCodeRegex = /^\+54?(?:9)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // For numbers without country code, must start with 0
  const noCountryCodeRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  let match;
  
  if (cleaned.startsWith('+54')) {
    match = cleaned.match(withCountryCodeRegex);
  } else {
    match = cleaned.match(noCountryCodeRegex);
  }
  
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriberNumber] = match;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Accepts unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and 'X Æ A-12' style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove leading/trailing spaces and check if empty after trimming
  const trimmed = value.trim();
  if (!trimmed) {
    return false;
  }
  
  // Name regex: allows unicode letters, accents, apostrophes, hyphens, and spaces
  const nameRegex = /^[a-zA-ZÀ-ÖØ-öø-ÿĀ-ſ\s'-]+$/u;
  
  if (!nameRegex.test(trimmed)) {
    return false;
  }
  
  // Check for digits and symbols
  const invalidPatterns = /\d|[ÆÕ]|[\\/*+<>{}()[\]|^%$#@!&~]/;
  if (invalidPatterns.test(trimmed)) {
    return false;
  }
  
  // Ensure at least one letter character is present
  const hasLetter = /[\p{L}]/u.test(trimmed);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names that are just symbols or punctuation
const hasValidContent = /[\p{L}]/u.test(trimmed);
  if (!hasValidContent) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths, and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check basic length constraints
  if (cardNumber.length < 13 || cardNumber.length > 19) {
    return false;
  }
  
  // Credit card patterns:
  // Visa: 4, length 13 or 16
  // Mastercard: 51-55, 2221-2720, length 16
  // AmEx: 34, 37, length 15
  
  const visaRegex = /^4(\d{12}|\d{15})$/;
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[01]\d|720)\d{12}))$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any of the card patterns
  if (visaRegex.test(cardNumber) || mastercardRegex.test(cardNumber) || amexRegex.test(cardNumber)) {
    // Run Luhn checksum
    return runLuhnCheck(cardNumber);
  }
  
  return false;
}