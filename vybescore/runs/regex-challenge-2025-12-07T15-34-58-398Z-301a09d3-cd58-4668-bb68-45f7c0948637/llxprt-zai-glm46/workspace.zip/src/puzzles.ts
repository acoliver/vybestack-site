/**
 * Finds words starting with the given prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }
  
  // Escape the prefix for regex and create a word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  // \b ensures we match whole words, \w+ matches the rest of the word
  const wordRegex = new RegExp('\\b' + escapedPrefix + '\\w*', 'gi');
  
  const matches = text.match(wordRegex);
  
  if (!matches) {
    return [];
  }
  
  // Create a Set of exceptions for efficient lookup (case-insensitive)
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  // Filter out exceptions and return unique words
  const filteredWords = matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptionSet.has(word));
  
  // Return unique words (preserve original case from first occurrence)
  const uniqueWords = Array.from(new Set(filteredWords));
  
  return uniqueWords;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match token that:
  // - is preceded by a digit
  // - is not at the beginning of the string
  const tokenRegex = new RegExp('(\\d)' + escapedToken, 'g');
  
  const matches: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[1] + match[0].slice(1));
  }
  
  return matches;
}

/**
 * Validates passwords according to strong password policy.
 * Requirements: at least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, 1212, xyzxyz)
  // Look for patterns of 2-4 characters that repeat immediately
  const repeatedPattern = /(..+?)\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Additional check for simple alternating patterns like abab
  const alternatingPattern = /(.)(.)\1\2/;
  if (alternatingPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 * Returns true if the string contains a valid IPv6 address.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // IPv6 patterns:
  // 1. Full notation: 8 groups of 4 hex digits separated by colons
  // 2. Compressed notation with :: (zero compression)
  // 3. Mixed notation with IPv4 embedded
  // 4. Shortened groups (leading zeros can be omitted)
  
  // First, exclude pure IPv4 addresses
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Regex.test(value.trim())) {
    return false;
  }
  
  // IPv6 regex pattern that matches:
  // - Standard IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed IPv6: 2001:db8::1
  // - Shortened groups: 2001:db8:85a3:0:0:8a2e:370:7334
  // - Mixed with IPv4: 2001:db8::192.168.1.1
  // - Link-local: fe80::1
  const ipv6Regex = /(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)|(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?))(?![0-9a-fA-F:])/;
  
  return ipv6Regex.test(value);
}