import initSqlJs, { Database as SqlJsDatabase, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

const DB_FILE_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');
const WASM_PATH = path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm');

export interface Submission {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
}

export class Database {
  private static instance: Database;
  private db: SqlJsDatabase | null = null;
  private SqlJsConstructor: SqlJsStatic | null = null;

  private constructor() {}

  static async getInstance(): Promise<Database> {
    if (!Database.instance) {
      Database.instance = new Database();
      await Database.instance.initialize();
    }
    return Database.instance;
  }

  private async initialize(): Promise<void> {
    this.SqlJsConstructor = await initSqlJs.default({
      locateFile: (file: string) => {
        if (file === 'sql-wasm.wasm') {
          return WASM_PATH;
        }
        return require.resolve(`sql.js/dist/${file}`);
      }
    });

    await this.loadDatabase();
  }

  private async loadDatabase(): Promise<void> {
    try {
      if (fs.existsSync(DB_FILE_PATH)) {
        const fileBuffer = fs.readFileSync(DB_FILE_PATH);
        this.db = new this.SqlJsConstructor!.Database(fileBuffer);
      } else {
        this.db = new this.SqlJsConstructor!.Database();
        await this.createSchema();
        await this.saveDatabase();
      }
    } catch (error) {
      console.error('Failed to load database:', error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
    if (this.db) {
      this.db.exec(schema);
    }
  }

  async saveDatabase(): Promise<void> {
    if (this.db) {
      const data = this.db.export();
      const buffer = Buffer.from(data);
      fs.writeFileSync(DB_FILE_PATH, buffer);
    }
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();

    // Get the last inserted row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  }

  async getAllSubmissions(): Promise<Submission[]> {
    if (!this.db) {
      return [];
    }
    
    const stmt = this.db.prepare("SELECT * FROM submissions ORDER BY created_at DESC");
    const results: Submission[] = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject() as unknown as Submission;
      results.push(row);
    }
    
    stmt.free();
    return results;
  }

  async close(): Promise<void> {
    if (this.db) {
      await this.saveDatabase();
      this.db.close();
    }
  }
}

export default Database;