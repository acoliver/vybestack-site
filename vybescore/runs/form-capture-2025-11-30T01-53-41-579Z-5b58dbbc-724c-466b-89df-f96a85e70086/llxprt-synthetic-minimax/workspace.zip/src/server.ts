import express, { Request, Response } from 'express';
import path from 'path';
import Database from './database.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Validation interface
interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data?: FormData;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]{7,20}$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s\- .]{3,10}$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: Record<string, string>): ValidationResult {
  const errors: ValidationError[] = [];
  const formData: FormData = {
    first_name: (data['first_name'] || '').trim(),
    last_name: (data['last_name'] || '').trim(),
    street_address: (data['street_address'] || '').trim(),
    city: (data['city'] || '').trim(),
    state_province: (data['state_province'] || '').trim(),
    postal_code: (data['postal_code'] || '').trim(),
    country: (data['country'] || '').trim(),
    email: (data['email'] || '').trim(),
    phone: (data['phone'] || '').trim(),
  };

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city', 
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!formData[field]) {
      errors.push({
        field: field,
        message: `${field.replace('_', ' ')} is required`
      });
    }
  }

  // Email validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation
  if (formData.postal_code && !validatePostalCode(formData.postal_code)) {
    errors.push({
      field: 'postal_code',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: formData
  };
}

// Routes

// GET / - Show form
app.get('/', async (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    data: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response) => {
  const validation = validateFormData(req.body);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      data: validation.data
    });
  }

  try {
    const db = await Database.getInstance();
    await db.insertSubmission(validation.data!);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', {
      errors: [{ field: 'general', message: 'Internal server error. Please try again.' }],
      data: validation.data
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: unknown, req: Request, res: Response, next: express.NextFunction) => {
  console.error(err);
  res.status(500).send('Something broke!');
});

// Server lifecycle management
let server: ReturnType<typeof app.listen> | null = null;

async function startServer() {
  try {
    // Initialize database
    await Database.getInstance();
    
    server = app.listen(PORT, () => {
      console.log(` Server running on port ${PORT}`);
      console.log(` Form available at http://localhost:${PORT}/`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

async function shutdown() {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close();
  }
  
  try {
    const db = await Database.getInstance();
    await db.close();
    console.log('Database closed successfully');
  } catch (error) {
    console.error('Error closing database:', error);
  }
  
  process.exit(0);
}

// Handle shutdown signals
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default app;