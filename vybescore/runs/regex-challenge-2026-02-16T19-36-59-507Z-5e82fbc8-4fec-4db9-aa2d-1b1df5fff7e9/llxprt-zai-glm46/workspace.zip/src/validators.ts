export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts: name@tag@example.co.uk
 * Rejects: double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Reject obvious invalid patterns first
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.startsWith('@') || value.endsWith('@')) return false;
  
  // Count @ symbols - must have at least one
  const atCount = (value.match(/@/g) || []).length;
  if (atCount < 1) return false;
  
  // Split by @ and validate each part
  const parts = value.split('@');
  
  // Last part must be a valid domain (no underscores)
  const domain = parts[parts.length - 1];
  if (domain.includes('_')) return false;
  
  // Validate domain format (must have at least one dot and valid TLD)
  const domainRegex = /^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}$/;
  if (!domainRegex.test(domain)) return false;
  
  // Local part can contain tags (multiple @ symbols allowed)
  // But each non-domain part must be valid
  for (let i = 0; i < parts.length - 1; i++) {
    const part = parts[i];
    if (part.length === 0) return false;
    if (part.startsWith('.') || part.endsWith('.')) return false;
    // Local parts can contain alphanumeric and common special chars
    const localPartRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*$/;
    if (!localPartRegex.test(part)) return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects: impossible area codes (leading 0/1), too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('1')) {
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (digits.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  if (digits[0] === '0' || digits[0] === '1') return false;
  
  // Exchange code cannot start with 0 or 1
  if (digits[3] === '0' || digits[3] === '1') return false;
  
  // Handle optional extension
  if (options?.allowExtensions) {
    const extMatch = value.match(/ext\.?\s*(\d+)?/i);
    if (extMatch && !extMatch[1]) return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles: landlines and mobiles with optional country code, trunk prefix, mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, keep digits
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Regex for Argentine phone numbers:
  // Optional +54 or 54 (country code)
  // Optional 0 (trunk prefix)
  // Optional 9 (mobile indicator)
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentinaPhoneRegex = /^(?:\+?54)?(?:0)?(?:9)?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinaPhoneRegex.test(cleaned)) return false;
  
  // If no country code, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  if (!hasCountryCode) {
    if (!cleaned.startsWith('0')) return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects: digits, symbols, and invalid combinations like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, apostrophes, hyphens, spaces, and common accented characters
  // Must have at least 2 characters
  if (value.trim().length < 2) return false;
  
  // Check for invalid characters (digits and most symbols)
  const validNameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!validNameRegex.test(value)) return false;
  
  // Reject names with only apostrophes, hyphens, or spaces
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Reject patterns like "X Æ A-12" (contains digits)
  if (/\d/.test(value)) return false;
  
  // Reject multiple consecutive special chars
  if (/''|--/.test(value)) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').reverse();
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = parseInt(digits[i], 10);
    
    // Double every second digit (starting from right, position 1)
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts: Visa (starts with 4, 13-16 digits), Mastercard (starts with 51-55, 16 digits),
 *          AmEx (starts with 34 or 37, 15 digits).
 * Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check Visa: starts with 4, length 13-16
  const visaRegex = /^4\d{12,15}$/;
  
  // Check Mastercard: starts with 51-55, length 16
  const mastercardRegex = /^5[1-5]\d{14}$/;
  
  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  const validFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
