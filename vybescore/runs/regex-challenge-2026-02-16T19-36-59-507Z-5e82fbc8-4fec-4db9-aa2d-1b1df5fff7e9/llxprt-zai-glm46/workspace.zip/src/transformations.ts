/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence boundaries
  // Replace multiple spaces with single space
  let normalized = text.replace(/[ \t]+/g, ' ');
  
  // Ensure exactly one space after sentence endings (. ! ?)
  // But not after abbreviations (common patterns: Mr., Mrs., Dr., etc., e.g., i.e.)
  const abbreviationPattern = /\b(Mr|Mrs|Ms|Dr|Prof|Sr|Jr|vs|etc|eg|i\.e|e\.g|no)\.$/;
  
  // Add space after sentence endings if missing (unless preceded by abbreviation)
  normalized = normalized.replace(/([.!?])(?=[a-zA-Z])(?!\s)/g, '$1 ');
  
  // Collapse multiple spaces to single space
  normalized = normalized.replace(/ +/g, ' ');
  
  // Capitalize first character of text
  if (normalized.length > 0) {
    normalized = normalized[0].toUpperCase() + normalized.slice(1);
  }
  
  // Capitalize after sentence boundaries (but not after abbreviations)
  const sentences = normalized.split(/([.!?]\s+)/);
  for (let i = 0; i < sentences.length; i++) {
    if (i % 2 === 0 && sentences[i].length > 0) {
      // This is sentence content (odd indices are delimiters)
      if (i > 0 && sentences[i - 1]) {
        // Check if previous sentence ended with abbreviation
        const prevSentence = i >= 2 ? sentences[i - 2] : '';
        if (!abbreviationPattern.test(prevSentence.trim())) {
          // Capitalize first letter
          sentences[i] = sentences[i][0].toUpperCase() + sentences[i].slice(1);
        }
      }
    }
  }
  
  return sentences.join('');
}

/**
 * Find URLs in text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex
  // Matches http://, https://, www.
  // Captures the URL without trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[a-zA-Z0-9\-._~:/?#[\]@!$&'()*+,;=%]+[a-zA-Z0-9\-_~:/?#[\]@!$&'()*+,;=%]/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation marks
    return url.replace(/[.,;:!?]+$/, '');
  }).filter(url => url.length > 0);
}

/**
 * Convert all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  const urlPattern = /(http:\/\/example\.com\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (url: string) => {
    // Parse the URL
    const upgradedUrl = url.replace(/^http:\/\//, 'https://');
    
    // Extract the path part
    const pathMatch = upgradedUrl.match(/^https:\/\/example\.com(\/.*)$/i);
    if (!pathMatch) return upgradedUrl;
    
    const path = pathMatch[1];
    
    // Check for dynamic hints that should prevent host rewrite
    const hasQueryString = /[?&=]/.test(path);
    const hasCgiBin = /\/cgi-bin\//i.test(path);
    const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i.test(path);
    
    if (hasQueryString || hasCgiBin || hasLegacyExtension) {
      // Only upgrade scheme, don't rewrite host
      return upgradedUrl;
    }
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite host to docs.example.com
      return upgradedUrl.replace(/^https:\/\/example\.com\//i, 'https://docs.example.com/');
    }
    
    return upgradedUrl;
  });
}

/**
 * Extract year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!dateMatch) return 'N/A';
  
  const month = parseInt(dateMatch[1], 10);
  const day = parseInt(dateMatch[2], 10);
  const year = dateMatch[3];
  
  // Validate month (01-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) return 'N/A';
  
  return year;
}
