/**
 * Find words starting with prefix, excluding specified exceptions.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern to find words starting with prefix
  // Word boundary before, word characters after
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z0-9_]+`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches
    .map(word => word)
    .filter(word => !exceptionsLower.has(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Find occurrences of token only when it appears after a digit and not at string start.
 * Uses lookahead/lookbehind for matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, not at the start of the string
  // Use a capturing group to get the full match (digit + token)
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // Must have at least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Must have at least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Must have at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must have at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, 123123)
  // Look for patterns of 2+ characters that repeat immediately
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensures IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that handles:
  // - Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed form with :: (shorthand)
  // - Mixed IPv4/IPv6 (e.g., ::ffff:192.168.1.1)
  
  // First, explicitly exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) return false;
  
  // Simpler IPv6 pattern that works for most cases
  // Matches hex groups with colons, allowing ::
  const simpleIPv6 = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]+|::(ffff(:0{1,4})?:)?((25[0-5]|(2[0-4]|1?[0-9])?[0-9])\.){3}(25[0-5]|(2[0-4]|1?[0-9])?[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1?[0-9])?[0-9])\.){3}(25[0-5]|(2[0-4]|1?[0-9])?[0-9]))/;
  
  return simpleIPv6.test(value);
}
