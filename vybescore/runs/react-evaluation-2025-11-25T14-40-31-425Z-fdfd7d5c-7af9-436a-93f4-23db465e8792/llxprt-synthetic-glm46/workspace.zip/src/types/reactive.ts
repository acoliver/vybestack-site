/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<SubjectBase>
  computedObservers?: Set<Observer<unknown>>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export type SubjectBase = Subject<any>

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  
  // Clear previous dependencies before tracking new ones
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  const previousDependencies = new Set(observer.dependencies)
  observer.dependencies.clear()
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Clean up old dependencies
  for (const dependency of previousDependencies) {
    if (dependency.observers) {
      dependency.observers.delete(observer)
    }
  }
  
  // Register new dependencies
  for (const dependency of observer.dependencies) {
    if (!dependency.observers) {
      dependency.observers = new Set()
    }
    dependency.observers.add(observer)
  }
  
  // Notify computed observers after updating
  if (observer.computedObservers) {
    // Copy to avoid issues with observers being added/removed during iteration
    const computedObservers = Array.from(observer.computedObservers)
    for (const computedObserver of computedObservers) {
      updateObserver(computedObserver)
    }
  }
}