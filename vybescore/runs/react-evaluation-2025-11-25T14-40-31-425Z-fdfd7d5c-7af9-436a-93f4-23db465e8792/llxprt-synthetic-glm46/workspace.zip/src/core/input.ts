/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  SubjectBase
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean equality flag to a proper function
  const equalFn: EqualFn<T> | undefined = 
    _equal === false 
      ? () => false
      : typeof _equal === 'function' 
        ? _equal 
        : _equal === true 
          ? Object.is 
          : undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // This observer depends on this subject
      s.observers!.add(observer)
      
      // Track this subject as a dependency for the observer
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(s as SubjectBase)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed (if equality function provided)
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers that depend on this subject
    if (s.observers) {
      // Copy to avoid issues with observers being added/removed during iteration
      const observers = Array.from(s.observers)
      for (const observer of observers) {
        updateObserver(observer)
      }
    }
    
    return s.value
  }

  return [read, write]
}