/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  Subject,
  EqualFn,
  SubjectBase
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equality flag to a proper function
  const equalFn: EqualFn<T> | undefined = 
    _equal === false 
      ? () => false
      : typeof _equal === 'function' 
        ? _equal 
        : _equal === true 
          ? Object.is 
          : undefined

  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set(),
    computedObservers: new Set(),
  }
  
  // Create a mock Subject to represent this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    equalFn,
  } as Subject<T>
  
  // Initialize the computed value
  computedSubject.value = updateFn(value)
  
  const computedGetter: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    
    // If there's an active observer, they depend on this computed value
    if (currentObserver) {
      // Track this computed subject as a dependency
      if (!currentObserver.dependencies) {
        currentObserver.dependencies = new Set()
      }
      currentObserver.dependencies.add(computedSubject as SubjectBase)
      
      // Register the current observer as an observer of this computed observer
      if (!computedObserver.computedObservers) {
        computedObserver.computedObservers = new Set()
      }
      computedObserver.computedObservers.add(currentObserver)
    }
    
    return computedSubject.value
  }
  
  // Custom update function for our computed observer that also updates the subject
  const customUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    const result = updateFn(prevValue)
    computedSubject.value = result
    return result
  }
  
  // Replace the observer's update function with our custom one
  computedObserver.updateFn = customUpdateFn
  
  // Initialize the computed value by running the updateFn
  // This will track dependencies
  updateObserver(computedObserver)
  
  return computedGetter
}