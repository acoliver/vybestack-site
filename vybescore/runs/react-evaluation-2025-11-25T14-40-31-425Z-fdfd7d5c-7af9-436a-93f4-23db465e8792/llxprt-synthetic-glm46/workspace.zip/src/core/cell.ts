/**
 * Cell implementation for reactive values with input and output sides.
 */

import { createInput } from './input.js'
import { createOutput } from './output.js'

/**
 * Creates a cell with input and output sides for reactive values.
 */
export function createCell<T>(value: T) {
  const [input, setInput] = createInput(value)
  
  return {
    input,
    setInput,
    output: createOutput(() => input())
  }
}