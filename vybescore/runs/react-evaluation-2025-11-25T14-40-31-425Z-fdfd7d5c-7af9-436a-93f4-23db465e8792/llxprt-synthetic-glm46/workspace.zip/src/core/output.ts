/**
 * Output closure implementation for reactive primitives that depend on other values.
 */

import { UpdateFn, Observer, updateObserver } from '../types/reactive.js'

/**
 * Creates an output closure that tracks dependencies and runs the provided function.
 */
export function createOutput<T>(updateFn: UpdateFn<T>, value?: T) {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set(),
  }
  
  // Register observer to track dependencies by running the updateFn
  updateObserver(observer)
  
  return {
    get value() {
      return observer.value
    },
    cancel: () => {
      // Clean up all dependencies
      if (observer.dependencies) {
        for (const dependency of observer.dependencies) {
          if (dependency.observers) {
            dependency.observers.delete(observer)
          }
        }
        observer.dependencies.clear()
      }
      
      // Clear the observer to stop further updates
      observer.value = undefined
      // Set a no-op function to prevent further updates
      observer.updateFn = () => value as T
    }
  }
}