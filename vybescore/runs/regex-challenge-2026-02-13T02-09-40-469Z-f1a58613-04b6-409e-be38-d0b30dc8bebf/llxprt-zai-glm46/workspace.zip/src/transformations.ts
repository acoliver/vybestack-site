/**
 * Capitalize the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces.
 * Preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces - collapse multiple spaces to one
  let normalized = text.replace(/\s+/g, ' ');
  
  // Then ensure proper spacing after sentence endings
  // Look for sentence endings (. ! ?) followed by a lowercase letter without space
  normalized = normalized.replace(/([.!?])([a-z])/g, '$1 $2');
  
  // Capitalize first character of the text
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence endings
  // Use a callback to handle each match
  normalized = normalized.replace(/([.!?]\s+)([a-z])/g, (_match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Also handle case where sentence ending is directly followed by letter (should have space)
  normalized = normalized.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  return normalized.trim();
}

/**
 * Extract all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, and www
  // Allow for various characters in URL
  const urlPattern = /https?:\/\/[^\s<>"{}|\\^`[\]]+|www\.[^\s<>"{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    return url.replace(/[.,;:!?)\]'"]+$/, '');
  });
}

/**
 * Convert all http:// URLs to https://.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite URLs for the example.com domain.
 * - Always upgrade scheme to https
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /http:\/\/example\.com([^\s]*)/gi;
  
  return text.replace(urlPattern, (_match, path) => {
    // Always upgrade to https
    const newPath = path;
    
    // Check if this should be rewritten to docs subdomain
    // Conditions: path starts with /docs/ AND no dynamic hints
    const shouldRewriteHost = newPath.startsWith('/docs/') &&
      !/\/cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(newPath);
    
    if (shouldRewriteHost) {
      return `https://docs.example.com${newPath}`;
    } else {
      return `https://example.com${newPath}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: {[key: number]: number} = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
