export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like user@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain.tld
  // Local part: letters, digits, dots, hyphens, underscores, plus signs
  // Domain: letters, digits, hyphens, dots (no underscores)
  // TLD: at least 2 letters
  // No consecutive dots, no leading/trailing dots in local or domain parts
  
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9.+%_-]*@[a-zA-Z0-9][a-zA-Z0-9.-]*\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for underscore in domain
  const [local, domain] = value.split('@');
  if (domain.includes('_')) {
    return false;
  }
  
  // Check local part doesn't start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Check that domain parts don't start or end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except + at the start
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && cleaned.length === 11) {
    digits = digits.slice(1);
  }
  
  // Must have exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = digits.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats.
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must have trunk prefix 0
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and other separators
  const cleaned = value.replace(/[\s-]/g, '');
  
  // More comprehensive pattern
  const fullRegex = /^(?:\+?54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!fullRegex.test(cleaned)) {
    return false;
  }
  
  const match = cleaned.match(/^(?:\+?54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriber = match[2];
  
  // Area code must be 2-4 digits, leading digit 1-9 (already enforced by regex)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  if (!hasCountryCode) {
    // Must have trunk prefix
    if (!cleaned.startsWith('0')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols (except apostrophe, hyphen, space)
  // Pattern: letters (including unicode) with optional apostrophes, hyphens, and spaces
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names that are just special characters
  const lettersOnly = value.replace(/[\p{L}\p{M}]/gu, '');
  if (lettersOnly.length === value.length) {
    return false;
  }
  
  // Reject names with certain symbols (Æ is a letter, but check for problematic combinations)
  // The main concern is names like "X Æ A-12" which contain digits
  // We already check for digits, so this should be covered
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length and prefix
  const length = cleaned.length;
  
  // Visa: 13, 16 or 19 digits, starts with 4
  const isVisa = (length === 13 || length === 16 || length === 19) && cleaned.startsWith('4');
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const isMastercard = length === 16 && (
    (cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') ||
     cleaned.startsWith('54') || cleaned.startsWith('55')) ||
    (cleaned.startsWith('22') || cleaned.startsWith('23') || cleaned.startsWith('24') ||
     cleaned.startsWith('25') || cleaned.startsWith('26') || cleaned.startsWith('27'))
  );
  
  // AmEx: 15 digits, starts with 34 or 37
  const isAmEx = length === 15 && (cleaned.startsWith('34') || cleaned.startsWith('37'));
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
