/**
 * Find words starting with the given prefix, excluding the specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * Returns the full match including the digit and token.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, not at start of string
  // Use negative lookbehind for start of string to ensure we're not at the beginning
  const pattern = new RegExp(`(?<!^)\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // Look for patterns like abab, abcabc, 123123, etc.
  for (let i = 0; i < value.length - 3; i++) {
    for (let len = 1; len <= (value.length - i) / 2; len++) {
      const substring = value.slice(i, i + len);
      const nextPos = i + len;
      const nextSubstring = value.slice(nextPos, nextPos + len);
      
      if (substring === nextSubstring && len >= 2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses in text.
 * Handles shorthand notation with ::
 * Ensures IPv4 addresses don't trigger positive results.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Can use :: to replace consecutive zeros
  // - Can end with IPv4 (IPv6-mapped IPv4)
  // Exclude pure IPv4 addresses
  
  // First, exclude pure IPv4 addresses
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 patterns
  // Full format: 8 groups of 1-4 hex digits
  const fullIPv6 = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Shorthand with :: (at least one group before and after ::)
  const shorthandIPv6 = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // IPv6 with IPv4 at the end
  const ipv6MappedIPv4 = /(?:[0-9a-fA-F]{1,4}:)*:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;
  
  // Test all patterns
  if (fullIPv6.test(value) || shorthandIPv6.test(value) || ipv6MappedIPv4.test(value)) {
    // Additional check to ensure we're not matching something that looks like IPv6 but isn't
    // For example, a simple colon shouldn't match
    return true;
  }
  
  return false;
}
