/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64.
 */
export function decode(input: string): string {
  // Validate Base64 input - only allow valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Add padding if missing (Base64 strings should be divisible by 4)
  const padding = input.length % 4;
  let normalized = input;
  if (padding === 2) {
    normalized = input + '==';
  } else if (padding === 3) {
    normalized = input + '=';
  } else if (padding !== 0) {
    throw new Error('Invalid Base64 input: invalid length');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch {
    throw new Error('Failed to decode Base64 input');
  }
}
