import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, RenderOptions, Format } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  file: string;
  format: Format;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    file: '',
    format: 'markdown',
    includeTotals: false,
  };

  let i = 2; // Skip node and script name
  if (i >= argv.length) {
    throw new Error('Missing required argument: <data.json>');
  }
  
  args.file = argv[i++];

  while (i < argv.length) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        throw new Error('--format requires a value');
      }
      const format = argv[i + 1] as Format;
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      args.format = format;
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        throw new Error('--output requires a value');
      }
      args.output = argv[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
      i++;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return args;
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}] missing or invalid "amount" field`);
    }
  }

  return true;
}

function loadAndValidateData(filePath: string): ReportData {
  let content: string;
  
  try {
    content = readFileSync(filePath, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to read file: ${filePath}`);
  }

  let data: unknown;
  
  try {
    data = JSON.parse(content);
  } catch (error) {
    throw new Error('Invalid JSON: malformed syntax');
  }

  validateReportData(data);
  
  return data as ReportData;
}

function renderReport(data: ReportData, format: Format, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    const data = loadAndValidateData(args.file);
    const options: RenderOptions = { includeTotals: args.includeTotals };
    
    const output = renderReport(data, args.format, options);
    
    if (args.output) {
      writeFileSync(args.output, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();