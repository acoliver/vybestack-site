import { validators, transformations, puzzles } from './dist/src/index.js';

const { 
  isValidEmail, 
  isValidUSPhone, 
  isValidArgentinePhone, 
  isValidName, 
  isValidCreditCard
} = validators;

const {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} = transformations;

const {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} = puzzles;

console.log('=== VALIDATORS ===');

// Email tests
console.log('Email tests:');
console.log('  user@example.com:', isValidEmail('user@example.com'));
console.log('  user@tag@example.com:', isValidEmail('user+tag@example.com')); 
console.log('  user@@example..com:', isValidEmail('user@@example..com'));
console.log('  user@domain_with_underscore.com:', isValidEmail('user@domain_with_underscore.com'));
console.log('  user@domain.com:', isValidEmail('user@domain.com.'));

console.log('Phone tests:');
console.log('  (212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('  212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('  2125557890:', isValidUSPhone('2125557890'));
console.log('  +1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('  012-555-7890 (invalid):', isValidUSPhone('012-555-7890'));

console.log('Argentine phone tests:');
console.log('  +54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('  011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('  +54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('  0341 4234567:', isValidArgentinePhone('0341 4234567'));

console.log('Name tests:');
console.log('  Jane Doe:', isValidName('Jane Doe'));
console.log('  José María García:', isValidName('José María García'));
console.log('  O\'Connor:', isValidName('O\'Connor'));
console.log('  X Æ A-12 (invalid):', isValidName('X Æ A-12'));
console.log('  Jane123 (invalid):', isValidName('Jane123'));

console.log('Credit card tests:');
console.log('  Visa 4111111111111111:', isValidCreditCard('4111111111111111'));
console.log('  MasterCard 5555555555554444:', isValidCreditCard('5555555555554444'));
console.log('  AmEx 378282246310005:', isValidCreditCard('378282246310005'));

console.log('\n=== TRANSFORMATIONS ===');

console.log('Capitalize sentences:');
const sentenceText = 'hello world. this is a test! another line';
console.log('  Input:', sentenceText);
console.log('  Output:', transformations.capitalizeSentences(sentenceText));

console.log('\nExtract URLs:');
const urlText = 'Visit http://example.com and https://test.org for more info.';
console.log('  Input:', urlText);
console.log('  Output:', transformations.extractUrls(urlText));

console.log('\nEnforce HTTPS:');
const httpText = 'Visit http://example.com and keep https://test.org secure.';
console.log('  Input:', httpText);
console.log('  Output:', transformations.enforceHttps(httpText));

console.log('\nRewrite docs URLs:');
const docsText = 'Check http://example.com/docs/v1 and http://api.service.com/old.jsp';
console.log('  Input:', docsText);
console.log('  Output:', transformations.rewriteDocsUrls(docsText));

console.log('\nExtract year:');
console.log('  12/25/2023:', transformations.extractYear('12/25/2023'));
console.log('  13/25/2023 (invalid):', transformations.extractYear('13/25/2023'));
console.log('  not a date:', transformations.extractYear('not a date'));

console.log('\n=== PUZZLES ===');

console.log('Find prefixed words:');
const prefixedText = 'unhappy prefix unprefix regular unknown excluded';
console.log('  Input:', prefixedText);
console.log('  Output (prefix=un, no exclude):', puzzles.findPrefixedWords(prefixedText, 'un', []));
console.log('  Output (prefix=un, exclude=unhappy):', puzzles.findPrefixedWords(prefixedText, 'un', ['unhappy']));

console.log('\nFind embedded token:');
const embeddedText = 'token after4digit 5token abc9token xyz';
console.log('  Input:', embeddedText);
console.log('  Output (token=token):', puzzles.findEmbeddedToken(embeddedText, 'token'));

console.log('\nStrong password:');
console.log('  StrongPass123!:', puzzles.isStrongPassword('StrongPass123!'));
console.log('  weak1!:', puzzles.isStrongPassword('weak1!'));
console.log('  NoSpecial123:', puzzles.isStrongPassword('NoSpecial123'));
console.log('  NoNumbers!:', puzzles.isStrongPassword('NoNumbers!'));
console.log('  abab (invalid pattern):', puzzles.isStrongPassword('abab'));

console.log('\nIPv6 detection:');
console.log('  IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334:', puzzles.containsIPv6('IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334:'));
console.log('  IPv4 (should be false):', puzzles.containsIPv6('192.168.1.1'));
console.log('  Short form: fe80::1:', puzzles.containsIPv6('fe80::1'));