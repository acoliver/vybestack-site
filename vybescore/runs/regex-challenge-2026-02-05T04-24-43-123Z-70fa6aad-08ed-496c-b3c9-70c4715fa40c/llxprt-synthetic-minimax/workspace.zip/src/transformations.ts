export function extractUrls(text: string): string[] {
  // Simple approach: match http/https followed by domain parts until whitespace
  const urlRegex = /https?:\/\/\S+/g;
  const matches = text.match(urlRegex);
  return matches || [];
}

export function enforceHttps(text: string): string {
  // Simple replacement: replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

export function capitalizeSentences(text: string): string {
  // First, normalize spaces - remove multiple spaces but preserve sentence boundaries
  let result = text.replace(/\s+/g, ' ');
  
  // Capitalize first character of text
  if (result.length > 0) {
    result = result.charAt(0).toUpperCase() + result.slice(1);
  }
  
  // Find sentence boundaries and capitalize after punctuation
  result = result.replace(/([.!?])\s*([a-z])/g, (match, p1, p2) => {
    return p1 + ' ' + p2.toUpperCase();
  });
  
  return result;
}

export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/\s]+)([^\s]*)/g, (match, domain, path) => {
    // Always upgrade scheme to https://
    let result = 'https://';
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should prevent host rewrite
      const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
      const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
      
      if (hasDynamicHint) {
        // Don't rewrite host for dynamic URLs, just upgrade scheme
        result += domain + path;
      } else {
        // Rewrite host to docs.domain.com but preserve path starting with /docs/
        result += 'docs.' + domain + path;
      }
    } else {
      // For non-docs URLs, just upgrade scheme but preserve domain and path
      result += domain + path;
    }
    
    return result;
  });
}

export function extractYear(value: string): string {
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}