export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  if (value.includes("..")) {
    return false;
  }
  
  if (value.endsWith(".")) {
    return false;
  }
  
  const domain = value.split("@")[1];
  if (domain && domain.includes("_")) {
    return false;
  }
  
  return true;
}

export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[^\d+]/g, "");
  
  if (cleaned.length < 10) {
    return false;
  }
  
  const digits = cleaned.replace(/\D/g, "");
  let startIndex = 0;
  if (digits.startsWith("1")) {
    startIndex = 1;
  }
  
  const areaCode = digits.substring(startIndex, startIndex + 3);
  if (areaCode.length !== 3) {
    return false;
  }
  
  const areaFirstDigit = areaCode[0];
  if (areaFirstDigit === "0" || areaFirstDigit === "1") {
    return false;
  }
  
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  return true;
}

export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, "");
  const digitsOnly = cleaned.replace(/\D/g, "");
  
  if (digitsOnly.length === 0) {
    return false;
  }
  
  let startIndex = 0;
  
  if (digitsOnly.startsWith("54")) {
    startIndex = 2;
    
    if (digitsOnly.charAt(startIndex) === "9") {
      startIndex++;
    }
  } else if (digitsOnly.startsWith("0")) {
    startIndex = 1;
    
    if (digitsOnly.charAt(startIndex) === "9") {
      startIndex++;
    }
  }
  
  if (startIndex >= digitsOnly.length) {
    return false;
  }
  
  const areaCodeLength = Math.min(4, digitsOnly.length - startIndex);
  const areaCode = digitsOnly.substring(startIndex, startIndex + areaCodeLength);
  
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  if (areaCode.charAt(0) === "0") {
    return false;
  }
  
  startIndex += areaCode.length;
  
  const subscriberDigits = digitsOnly.substring(startIndex);
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  return true;
}

export function isValidName(value: string): boolean {
  if (!value.trim()) {
    return false;
  }
  
  if (/\d|[XÆA-]/.test(value)) {
    return false;
  }
  
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  if (!nameRegex.test(value)) {
    return false;
  }
  
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  return true;
}

export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, "");
  
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  let isValidType = false;
  
  if (cleaned.startsWith("4")) {
    isValidType = [13, 16, 19].includes(cleaned.length);
  }
  else if (/^5[1-5]/.test(cleaned)) {
    isValidType = cleaned.length === 16;
  }
  else if (/^3[47]/.test(cleaned)) {
    isValidType = cleaned.length === 15;
  }
  
  if (!isValidType) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}

function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}