export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const words = text.split(/\s+/);
  const result = [];
  
  for (const word of words) {
    const cleanWord = word.replace(/^[\W_]+|[\W_]+$/g, '');
    
    if (cleanWord.startsWith(prefix) && !exceptions.includes(cleanWord)) {
      result.push(cleanWord);
    }
  }
  
  return result;
}

export function findEmbeddedToken(text: string, token: string): string[] {
  const result = [];
  // Use regex to find token that appears after a digit (not at start)
  const regex = new RegExp(`(?<=\\d)${token}(?!\\$)`, 'g');
  const matches = text.match(regex);
  
  if (matches) {
    // Need to find the actual words containing these tokens after digits
    const words = text.split(/\s+/);
    for (const word of words) {
      if (/\d/.test(word) && word.includes(token)) {
        result.push(word);
      }
    }
  }
  
  return result;
}

export function isStrongPassword(value: string): boolean {
  if (value.length < 10) return false;
  if (/\s/.test(value)) return false;
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/[0-9]/.test(value)) return false;
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  if (/(..+)\1/.test(value)) return false;
  
  return true;
}

export function containsIPv6(value: string): boolean {
  // Check for IPv4 addresses first - if found, return false
  if (/\d+\.\d+\.\d+\.\d+/.test(value)) {
    return false;
  }
  
  // IPv6 patterns to match various IPv6 formats
  const ipv6Patterns = [
    // Standard IPv6 with colons
    /\b[a-f0-9]{0,4}:[a-f0-9]{0,4}:[a-f0-9]{0,4}:[a-f0-9]{0,4}:[a-f0-9]{0,4}:[a-f0-9]{0,4}\b/i,
    // IPv6 with :: shorthand
    /\b[a-f0-9]{0,4}:?[a-f0-9]{0,4}:?::[a-f0-9]{0,4}:?[a-f0-9]{0,4}\b/i,
    // IPv6 loopback
    /\b::1\b/i,
    // IPv6 any address
    /\b::\b/i,
    // IPv6 patterns with mixed notation
    /\b[a-f0-9]{0,4}:[a-f0-9]{0,4}:[a-f0-9]{0,4}::[a-f0-9]{0,4}\b/i,
    // IPv6 link-local
    /\bfe80:[a-f0-9]{0,4}:?[a-f0-9]{0,4}:?[a-f0-9]{0,4}\b/i
  ];
  
  return ipv6Patterns.some(pattern => pattern.test(value));
}