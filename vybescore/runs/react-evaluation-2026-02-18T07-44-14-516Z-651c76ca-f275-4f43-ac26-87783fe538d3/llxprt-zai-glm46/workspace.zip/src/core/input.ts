/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Extend Observer to support chaining
interface ExtendedObserver<T> extends Observer<T> {
  nextObserver?: ExtendedObserver<unknown>
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      const obs = observer as ExtendedObserver<unknown>
      // Check if observer is already in the chain
      let existing = s.observer as ExtendedObserver<unknown> | undefined
      let alreadyLinked = false
      while (existing) {
        if (existing === obs) {
          alreadyLinked = true
          break
        }
        existing = existing.nextObserver
      }
      
      // Only link if not already in the chain
      if (!alreadyLinked) {
        const existingHead = s.observer as ExtendedObserver<unknown> | undefined
        if (existingHead && existingHead !== obs) {
          obs.nextObserver = existingHead
        }
        s.observer = observer
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Trigger all chained observers
    const active = getActiveObserver()
    let current = s.observer as ExtendedObserver<unknown> | undefined
    while (current) {
      // Skip if this observer is already active (prevents infinite loops)
      if (current !== active) {
        const next = current.nextObserver
        updateObserver(current as Observer<unknown>)
        current = next
      } else {
        current = current.nextObserver
      }
    }
    return s.value
  }

  return [read, write]
}
