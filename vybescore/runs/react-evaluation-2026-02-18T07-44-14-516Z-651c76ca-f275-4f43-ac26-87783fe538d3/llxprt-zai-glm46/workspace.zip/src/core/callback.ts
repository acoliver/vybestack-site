/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

// Extend Observer to support chaining and disposal
interface ExtendedObserver<T> extends Observer<T> {
  nextObserver?: ExtendedObserver<unknown>
  disposed?: boolean
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: ExtendedObserver<T> = {
    value,
    updateFn,
    disposed: false,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    observer.nextObserver = undefined
  }
}
