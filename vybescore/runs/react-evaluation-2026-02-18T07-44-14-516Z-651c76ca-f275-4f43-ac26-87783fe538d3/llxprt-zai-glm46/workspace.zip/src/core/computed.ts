/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

// Extend Observer to support chaining
interface ExtendedObserver<T> extends Observer<T> {
  nextObserver?: ExtendedObserver<unknown>
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: ExtendedObserver<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  updateObserver(o)
  
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      const obs = observer as ExtendedObserver<unknown>
      // Check if observer is already in the chain
      let existing = o.nextObserver as ExtendedObserver<unknown> | undefined
      let alreadyLinked = false
      while (existing) {
        if (existing === obs) {
          alreadyLinked = true
          break
        }
        existing = existing.nextObserver
      }
      
      // Only link if not already in the chain
      if (!alreadyLinked) {
        const existingHead = o.nextObserver as ExtendedObserver<unknown> | undefined
        if (existingHead && existingHead !== obs) {
          obs.nextObserver = existingHead
        }
        o.nextObserver = obs
      }
    }
    return o.value!
  }
  
  return getter
}
