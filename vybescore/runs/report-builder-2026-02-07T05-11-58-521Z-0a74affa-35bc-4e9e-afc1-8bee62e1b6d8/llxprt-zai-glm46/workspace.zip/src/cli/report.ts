#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { getFormatter } from '../formats/index.js';
import { parseJsonFile } from '../utils.js';
import type { RenderOptions } from '../types.js';

/**
 * CLI arguments interface
 */
interface CliArgs {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

/**
 * Parse command line arguments
 */
function parseArgs(args: string[]): CliArgs {
  const parsed: CliArgs = {
    inputFile: '',
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let argIndex = 0;

  // First positional argument is the input file
  if (argIndex < args.length && !args[argIndex].startsWith('--')) {
    parsed.inputFile = args[argIndex];
    argIndex++;
  }

  // Parse optional flags
  while (argIndex < args.length) {
    const arg = args[argIndex];

    if (arg === '--format') {
      argIndex++;
      if (argIndex >= args.length) {
        throw new Error('--format requires a value');
      }
      parsed.format = args[argIndex];
    } else if (arg === '--output') {
      argIndex++;
      if (argIndex >= args.length) {
        throw new Error('--output requires a value');
      }
      parsed.outputPath = args[argIndex];
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }

    argIndex++;
  }

  return parsed;
}

/**
 * Main CLI function
 */
function main(): void {
  // Get arguments (skip first two: node executable and script path)
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  let parsedArgs: CliArgs;

  try {
    parsedArgs = parseArgs(args);
  } catch (error) {
    console.error(`Error parsing arguments: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
    return; // TypeScript type guard
  }

  // Validate required arguments
  if (!parsedArgs.inputFile) {
    console.error('Error: Input file path is required');
    process.exit(1);
    return;
  }

  if (!parsedArgs.format) {
    console.error('Error: --format option is required');
    console.error('Supported formats: markdown, text');
    process.exit(1);
    return;
  }

  // Read and parse input file
  let reportData: ReturnType<typeof parseJsonFile>;

  try {
    const filePath = resolve(parsedArgs.inputFile);
    const content = readFileSync(filePath, 'utf-8');
    reportData = parseJsonFile(content, filePath);
  } catch (error) {
    console.error(`Error reading file: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
    return;
  }

  // Get formatter and render report
  try {
    const formatter = getFormatter(parsedArgs.format);
    const options: RenderOptions = {
      includeTotals: parsedArgs.includeTotals,
    };
    const output = formatter(reportData, options);

    // Write output
    if (parsedArgs.outputPath) {
      const outputPath = resolve(parsedArgs.outputPath);
      writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

// Run CLI
main();
