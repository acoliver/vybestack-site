import type { ReportData, ReportEntry } from './types.js';

/**
 * Calculate total amount from report entries
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Format amount as currency with two decimal places
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Validate report data structure
 */
export function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    return false;
  }

  if (typeof report.summary !== 'string') {
    return false;
  }

  if (!Array.isArray(report.entries)) {
    return false;
  }

  for (const entry of report.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }

    const entryRecord = entry as Record<string, unknown>;

    if (typeof entryRecord.label !== 'string') {
      return false;
    }

    if (typeof entryRecord.amount !== 'number') {
      return false;
    }
  }

  return true;
}

/**
 * Parse and validate JSON file
 */
export function parseJsonFile(content: string, filePath: string): ReportData {
  let data: unknown;

  try {
    data = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }

  if (!validateReportData(data)) {
    throw new Error(
      `Invalid report data in ${filePath}. Expected structure: { title: string, summary: string, entries: [{ label: string, amount: number }] }`
    );
  }

  return data;
}
