import type { Formatter } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

/**
 * Render report as plain text
 */
export const renderText: Formatter = (data, options) => {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  lines.push('');

  // Entry list
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    lines.push('');
    lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
  }

  return lines.join('\n');
};
