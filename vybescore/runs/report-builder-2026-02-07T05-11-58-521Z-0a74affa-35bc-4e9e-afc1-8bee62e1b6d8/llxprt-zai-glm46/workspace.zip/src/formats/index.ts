import type { Formatter } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Map of supported format names to formatter functions
 */
export const FORMATTERS: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Check if a format is supported
 */
export function isFormatSupported(format: string): boolean {
  return format in FORMATTERS;
}

/**
 * Get formatter for a given format name
 */
export function getFormatter(format: string): Formatter {
  if (!isFormatSupported(format)) {
    const supportedFormats = Object.keys(FORMATTERS).join(', ');
    throw new Error(
      `Unsupported format: ${format}. Supported formats: ${supportedFormats}`
    );
  }

  return FORMATTERS[format];
}
