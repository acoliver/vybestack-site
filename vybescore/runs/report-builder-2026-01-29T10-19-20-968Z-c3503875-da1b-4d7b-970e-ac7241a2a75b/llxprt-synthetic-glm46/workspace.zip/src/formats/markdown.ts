import { ReportData, RenderOptions, Renderer } from '../types.js';
import { formatAmount } from '../utils.js';

export const renderMarkdown: Renderer = (data: ReportData, options: RenderOptions) => {
  const lines = [
    `# ${data.title}`,
    '',
    data.summary,
    '',
    '## Entries',
  ];

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};