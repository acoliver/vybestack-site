#!/usr/bin/env node

import { readFile, writeFile } from 'fs/promises';
import { ReportData, Format, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: Format;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: string = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      format = formatValue as Format;
      i++;
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++;
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else if (args[i].startsWith('--format=')) {
      const formatValue = args[i].substring(9);
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      format = formatValue as Format;
    }
  }

  if (!format) {
    console.error('Format is required. Use --format <format>');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  return {
    dataFile,
    format: format as Format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(obj: unknown): ReportData {
  if (!obj || typeof obj !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const dataObj = obj as Record<string, unknown>;
  
  if (typeof dataObj.title !== 'string' || !dataObj.title.trim()) {
    throw new Error('Invalid JSON: title is required and must be a non-empty string');
  }
  
  if (typeof dataObj.summary !== 'string' || !dataObj.summary.trim()) {
    throw new Error('Invalid JSON: summary is required and must be a non-empty string');
  }
  
  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid JSON: entries must be an array');
  }
  
  for (let i = 0; i < dataObj.entries.length; i++) {
    const entry = dataObj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} must be an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      throw new Error(`Invalid JSON: entry ${i}.label is required and must be a non-empty string`);
    }
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry ${i}.amount is required and must be a number`);
    }
  }
  
  return {
    title: dataObj.title,
    summary: dataObj.summary,
    entries: dataObj.entries as Array<{label: string; amount: number}>,
  };
}

function getRenderer(format: Format) {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

async function main() {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArgs();
    
    let dataJson;
    try {
      const fileContent = await readFile(dataFile, 'utf8');
      dataJson = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error parsing JSON file: ${error.message}`);
      } else if (error instanceof Error) {
        console.error(`Error reading file ${dataFile}: ${error.message}`);
      } else {
        console.error(`Error reading file ${dataFile}`);
      }
      process.exit(1);
    }
    
    let data: ReportData;
    try {
      data = validateReportData(dataJson);
    } catch (error) {
      if (error instanceof Error) {
        console.error(error.message);
      } else {
        console.error('Unknown validation error');
      }
      process.exit(1);
    }
    
    const renderOptions: RenderOptions = { includeTotals };
    const renderer = getRenderer(format);
    const output = renderer(data, renderOptions);
    
    if (outputPath) {
      try {
        await writeFile(outputPath, output, 'utf8');
        console.log(`Report saved to ${outputPath}`);
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error writing to output file: ${error.message}`);
        } else {
          console.error(`Error writing to output file`);
        }
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Unexpected error: ${error.message}`);
    } else {
      console.error('Unexpected error occurred');
    }
    process.exit(1);
  }
}

main().catch((error) => {
  if (error instanceof Error) {
    console.error(`Unhandled error: ${error.message}`);
  } else {
    console.error('Unhandled error occurred');
  }
  process.exit(1);
});
