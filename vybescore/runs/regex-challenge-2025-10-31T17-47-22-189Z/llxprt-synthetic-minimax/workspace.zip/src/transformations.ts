/**
 * Capitalize the first character of each sentence, preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  // Split text into sentences based on punctuation
  // Use lookahead to keep the punctuation
  const sentences = text.split(/(?<=[.!?])\s*/);
  
  const capitalized = sentences.map((sentence, index) => {
    if (sentence.length === 0) return sentence;
    
    // Capitalize first letter
    return sentence.charAt(0).toUpperCase() + sentence.slice(1);
  });
  
  // Join with single space
  return capitalized.join(' ');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s)]+/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com URLs
  const urlRegex = /https?:\/\/([^\/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, host, path) => {
    // If it starts with https, leave it as is
    if (match.startsWith('https://')) {
      // But still check if we need to rewrite docs URLs
      if (path && path.startsWith('/docs/')) {
        // Check for dynamic hints or legacy extensions
        const hasDynamicHints = /(\?|=|&|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
        
        if (!hasDynamicHints) {
          // Rewrite host to docs.hostname
          const newHost = `docs.${host}`;
          return `https://${newHost}${path}`;
        }
      }
      return match;
    }
    
    // For http:// URLs
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /(\?|=|&|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.hostname and upgrade scheme
        const newHost = `docs.${host}`;
        return `https://${newHost}${path}`;
      }
    }
    
    // Just upgrade scheme
    return match.replace('http://', 'https://');
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate year is 4 digits
  if (year.length !== 4) {
    return 'N/A';
  }
  
  return year;
}
