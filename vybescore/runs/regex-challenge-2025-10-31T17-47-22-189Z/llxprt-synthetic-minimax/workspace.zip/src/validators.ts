export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using regex patterns.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common formats.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.trim();
  const digitsOnly = cleaned.replace(/[^\d]/g, '');
  
  // Must be 10 or 11 digits (with optional +1)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) {
    return false;
  }
  
  // Extract the 10-digit number (remove leading 1 if present)
  const number = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Check area code (first 3 digits): cannot start with 0 or 1
  const areaCode = parseInt(number.slice(0, 3));
  if (areaCode < 200 || areaCode > 999) {
    return false;
  }
  
  // Check exchange code (next 3 digits): cannot start with 0 or 1
  const exchangeCode = parseInt(number.slice(3, 6));
  if (exchangeCode < 200 || exchangeCode > 999) {
    return false;
  }
  
  // Check line number (last 4 digits)
  const lineNumber = parseInt(number.slice(6, 10));
  if (lineNumber < 0 || lineNumber > 9999) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Optional country code +54, optional mobile indicator 9, optional trunk prefix 0, area code 2-4 digits (1-9), subscriber number 6-8 digits
  // Allow spaces and hyphens as separators
  const phoneRegex = /^\+?\s*54\s*9?\s*0?\s*([2-9]\d{1,3})\s*-?\s*(\d{6,8})$/;
  const match = value.trim().match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits (first digit 1-9 already ensured by [2-9])
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  // Allows unicode letters, accents, apostrophes, hyphens, and spaces
  // Rejects digits and other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must not be empty or just whitespace/punctuation
  if (!nameRegex.test(value) || value.trim().length === 0) {
    return false;
  }
  
  // Must contain at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to validate credit card using Luhn algorithm.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers using length/prefix checks and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  const length = cardNumber.length;
  
  // Check card type and prefix
  let isValidType = false;
  
  // Visa: starts with 4, length 13, 16, or 19
  if ((cardNumber.startsWith('4')) && (length === 13 || length === 16 || length === 19)) {
    isValidType = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  else if ((/^5[1-5]/.test(cardNumber) || /^2(2[2-9]\d|3[0-8]\d|4[0-9]{2}|5[0-5]\d)/.test(cardNumber)) && length === 16) {
    isValidType = true;
  }
  // American Express: starts with 34 or 37, length 15
  else if ((cardNumber.startsWith('34') || cardNumber.startsWith('37')) && length === 15) {
    isValidType = true;
  }
  
  if (!isValidType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}
