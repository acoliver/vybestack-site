import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Debugging Reactive System ===')

// Test 1: compute cells fire callbacks
console.log('\nTest 1: compute cells fire callbacks')
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)
let value = 0
createCallback(() => {
  console.log(`  Callback called: output() = ${output()}`)
  value = output()
})

console.log(`  Initial: input=${input()}, output=${output()}, value=${value}`)
setInput(3)
console.log(`  After setInput(3): input=${input()}, output=${output()}, value=${value}`)
console.log(`  Expected value=4, actual=${value}`)

// Test 2: callbacks can be added and removed
console.log('\nTest 2: callbacks can be added and removed')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => {
  console.log(`  Callback1 called: output2() = ${output2()}`)
  values1.push(output2())
})
const values2 = []
createCallback(() => {
  console.log(`  Callback2 called: output2() = ${output2()}`)
  values2.push(output2())
})

console.log(`  Initial: input2=${input2()}, output2=${output2()}`)
console.log(`  values1=${JSON.stringify(values1)}, values2=${JSON.stringify(values2)}`)

setInput2(31)
console.log(`  After setInput2(31): input2=${input2()}, output2=${output2()}`)
console.log(`  values1=${JSON.stringify(values1)}, values2=${JSON.stringify(values2)}`)

unsubscribe1()
console.log('  After unsubscribe1()')
setInput2(41)
console.log(`  After setInput2(41): input2=${input2()}, output2=${output2()}`)
console.log(`  values1=${JSON.stringify(values1)}, values2=${JSON.stringify(values2)}`)
console.log(`  Expected: values1=[32], values2=[32,42]`)