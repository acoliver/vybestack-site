import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, observerObservers } from '../types/reactive.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // Track dependencies by running the function once with the observer as active
  const trackDependencies = () => {
    const previousObserver = getActiveObserver()
    setActiveObserver(observer as unknown as Observer<unknown>)
    try {
      updateFn(value)
    } finally {
      setActiveObserver(previousObserver)
      
      // Establish dependency chain - when dependencies notify this observer,
      // this observer should also notify its own dependents
      if (previousObserver) {
        let observers = observerObservers.get(observer as unknown as Observer<unknown>)
        if (!observers) {
          observers = new Set()
          observerObservers.set(observer as unknown as Observer<unknown>, observers)
        }
        observers.add(previousObserver)
      }
    }
  }
  
  // Initialize the callback and track dependencies
  trackDependencies()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = value
    // Replace updateFn with a no-op to prevent further updates
    observer.updateFn = (v) => v as T
    
    // Clean up dependency relationships
    observerObservers.delete(observer as unknown as Observer<unknown>)
  }
}
