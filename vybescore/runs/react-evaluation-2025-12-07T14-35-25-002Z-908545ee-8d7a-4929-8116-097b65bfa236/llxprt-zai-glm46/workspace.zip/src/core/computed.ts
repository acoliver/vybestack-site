import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  setActiveObserver,
  getActiveObserver,
  observerObservers
} from '../types/reactive.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = () => {
    const previousObserver = getActiveObserver()
    setActiveObserver(o as unknown as Observer<unknown>)
    try {
      // Only compute if we have no initial value, otherwise use the provided initial value
      let newValue = o.value
      if (o.value === undefined) {
        newValue = updateFn(o.value)
        o.value = newValue
      }
      return o.value as T
    } finally {
      setActiveObserver(previousObserver)
      
      // If we're being observed by another observer, establish the dependency chain
      if (previousObserver) {
        let observers = observerObservers.get(o as unknown as Observer<unknown>)
        if (!observers) {
          observers = new Set()
          observerObservers.set(o as unknown as Observer<unknown>, observers)
        }
        observers.add(previousObserver)
      }
    }
  }
  
  // Initialize the computed value
  getter()
  return getter
}