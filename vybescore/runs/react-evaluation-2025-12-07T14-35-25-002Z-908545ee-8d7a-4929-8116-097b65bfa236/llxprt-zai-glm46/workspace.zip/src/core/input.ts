import {
  InputPair,
  Subject,
  getActiveObserver,
  addObserverToSubject,
  notifySubjectObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function defaultEqual<T>(a: T, b: T): boolean {
  return a === b
}

export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof _equal === 'function' ? _equal : _equal === false ? undefined : defaultEqual
  
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserverToSubject(s, observer)
      // Establish that when this subject changes, the observer should be updated
      // This is already handled by addObserverToSubject
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!s.equalFn?.(s.value, nextValue)) {
      s.value = nextValue
      notifySubjectObservers(s)
    }
    return s.value
  }

  return [read, write]
}