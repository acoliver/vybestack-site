/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): void {
  activeObserver = observer as unknown as Observer<unknown> | undefined
}

// Each subject tracks its own observers
const subjectObservers = new WeakMap<Subject<unknown>, Set<Observer<unknown>>>()
// Each observer can also be a subject to other observers
export const observerObservers = new WeakMap<Observer<unknown>, Set<Observer<unknown>>>()

export function addObserverToSubject<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  let observers = subjectObservers.get(subject as unknown as Subject<unknown>)
  if (!observers) {
    observers = new Set()
    subjectObservers.set(subject as unknown as Subject<unknown>, observers)
  }
  observers.add(observer)
}

export function addObserverToObserver(observer: Observer<unknown>, dependent: Observer<unknown>): void {
  let observers = observerObservers.get(observer)
  if (!observers) {
    observers = new Set()
    observerObservers.set(observer, observers)
  }
  observers.add(dependent)
}

export function removeObserverFromSubject<T>(subject: Subject<T>, observer: Observer<unknown>): void {
  const observers = subjectObservers.get(subject as unknown as Subject<unknown>)
  if (observers) {
    observers.delete(observer)
  }
}

export function notifySubjectObservers<T>(subject: Subject<T>): void {
  const observers = subjectObservers.get(subject as unknown as Subject<unknown>)
  if (observers && observers.size > 0) {
    const observersArray = Array.from(observers)
    observersArray.forEach(observer => {
      try {
        // Update the observer by running its update function
        const oldValue = observer.value
        const newValue = observer.updateFn(oldValue)
        if (oldValue !== newValue) {
          observer.value = newValue
        }
        
        // After updating an observer, also notify any observers that depend on this observer
        const dependentObservers = observerObservers.get(observer)
        if (dependentObservers && dependentObservers.size > 0) {
          const dependentsArray = Array.from(dependentObservers)
          dependentsArray.forEach(dependent => {
            try {
              updateObserver(dependent as unknown as Observer<unknown>)
            } catch (error) {
              // Silently ignore errors in dependent observers
            }
          })
        }
      } catch (error) {
        // Silently ignore errors in observers to prevent crashes
      }
    })
  }
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  try {
    activeObserver = observer as unknown as Observer<unknown>
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}