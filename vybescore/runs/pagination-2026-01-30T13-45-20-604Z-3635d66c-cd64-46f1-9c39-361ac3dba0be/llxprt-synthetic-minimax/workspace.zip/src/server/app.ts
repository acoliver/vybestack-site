import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate query parameters with proper defaults
    const validationErrors: string[] = [];

    let page: number = 1; // default
    if (pageParam !== undefined && pageParam !== null && pageParam !== '') {
      const pageNum = Number(pageParam);
      if (Number.isNaN(pageNum) || !Number.isInteger(pageNum)) {
        validationErrors.push('page must be a valid integer');
      } else if (pageNum <= 0) {
        validationErrors.push('page must be positive');
      } else if (pageNum > 1000) {
        validationErrors.push('page is excessive (maximum 1000)');
      } else {
        page = pageNum;
      }
    }

    let limit: number = 5; // default
    if (limitParam !== undefined && limitParam !== null && limitParam !== '') {
      const limitNum = Number(limitParam);
      if (Number.isNaN(limitNum) || !Number.isInteger(limitNum)) {
        validationErrors.push('limit must be a valid integer');
      } else if (limitNum <= 0) {
        validationErrors.push('limit must be positive');
      } else if (limitNum > 100) {
        validationErrors.push('limit is excessive (maximum 100)');
      } else {
        limit = limitNum;
      }
    }

    if (validationErrors.length > 0) {
      res.status(400).json({ error: validationErrors.join(', ') });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
