/**
 * Encode plain text to Base64 using standard RFC 4648 Base64 alphabet.
 * Returns properly padded output using A-Z, a-z, 0-9, +, / characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding and throws error for invalid input.
 */
export function decode(input: string): string {
  // Normalize input: accept URL-safe characters and add missing padding
  let normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  // Add missing padding
  const paddingNeeded = (4 - (normalized.length % 4)) % 4;
  if (paddingNeeded > 0 && paddingNeeded < 4) {
    normalized += '='.repeat(paddingNeeded);
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
