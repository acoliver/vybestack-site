import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Awaited<ReturnType<typeof createDatabase>>;
  let app: Awaited<ReturnType<typeof createApp>>;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination metadata', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({
      page: 1,
      limit: 5,
      total: 15,
      hasNext: true
    });
  });

  it('respects custom page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({
      page: 2,
      limit: 3,
      total: 15,
      hasNext: true
    });
    expect(response.body.items.length).toBe(3);
  });

  it('returns correct items for different pages', async () => {
    const page1Response = await request(app).get('/inventory?page=1&limit=3');
    const page2Response = await request(app).get('/inventory?page=2&limit=3');
    
    expect(page1Response.status).toBe(200);
    expect(page2Response.status).toBe(200);
    
    // Should have different items on different pages
    const page1Ids = page1Response.body.items.map((item: { id: number }) => item.id);
    const page2Ids = page2Response.body.items.map((item: { id: number }) => item.id);
    
    expect(page1Ids).toEqual([1, 2, 3]);
    expect(page2Ids).toEqual([4, 5, 6]);
  });

  it('handles pagination boundaries correctly', async () => {
    // Last page with exactly 5 items
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body).toMatchObject({
      page: 3,
      limit: 5,
      total: 15,
      hasNext: false
    });
    expect(response.body.items.length).toBe(5);
  });

  it('validates non-numeric page parameter', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates non-numeric limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('validates negative page parameter', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be greater than 0');
  });

  it('validates zero limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be greater than 0');
  });

  it('validates excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('maximum value is 100');
  });

  it('validates excessive page parameter', async () => {
    const response = await request(app).get('/inventory?page=1001');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('maximum value is 1000');
  });

  it('returns empty results for page beyond total', async () => {
    const response = await request(app).get('/inventory?page=10&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.hasNext).toBe(false);
  });
});
