import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  // Fixed offset calculation: (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = offset + limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}

export function validatePaginationParams(pageParam: string | undefined, limitParam: string | undefined): { page: number; limit: number } | { error: string } {
  // Default values
  if (!pageParam && !limitParam) {
    return { page: 1, limit: DEFAULT_LIMIT };
  }

  // Parse page parameter
  let page = 1;
  if (pageParam !== undefined) {
    if (isNaN(Number(pageParam))) {
      return { error: 'Invalid page parameter: must be a number' };
    }
    page = Number(pageParam);
    if (page <= 0) {
      return { error: 'Invalid page parameter: must be greater than 0' };
    }
    if (!Number.isInteger(page)) {
      return { error: 'Invalid page parameter: must be an integer' };
    }
    if (page > 1000) {
      return { error: 'Invalid page parameter: maximum value is 1000' };
    }
  }

  // Parse limit parameter
  let limit = DEFAULT_LIMIT;
  if (limitParam !== undefined) {
    if (isNaN(Number(limitParam))) {
      return { error: 'Invalid limit parameter: must be a number' };
    }
    limit = Number(limitParam);
    if (limit <= 0) {
      return { error: 'Invalid limit parameter: must be greater than 0' };
    }
    if (!Number.isInteger(limit)) {
      return { error: 'Invalid limit parameter: must be an integer' };
    }
    if (limit > 100) {
      return { error: 'Invalid limit parameter: maximum value is 100' };
    }
  }

  return { page, limit };
}
