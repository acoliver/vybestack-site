/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs, including the full domain
  // Using word boundaries and ensuring we capture the complete URL
  const urlRegex = /\bhttps?:\/\/[\w.-]+\.[\w.-]+[^\s,.;:!?)\]"]*/gi;
  const matches = text.match(urlRegex);
  
  // Post-process matches to remove trailing punctuation
  if (matches) {
    return matches.map(url => url.replace(/[.,;:!?)]+$/, ''));
  }
  
  return [];
}