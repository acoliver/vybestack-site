/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 full format
  const fullIPv6 = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 compressed format with ::
  // This regex checks for valid compressed IPv6 addresses
  const compressedIPv6 = /^(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}$|^::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$|^([0-9a-fA-F]{1,4}:){1,6}::$|^([0-9a-fA-F]{1,4}:){1,5}::[0-9a-fA-F]{1,4}$|^([0-9a-fA-F]{1,4}:){1,4}::([0-9a-fA-F]{1,4}:){0,1}[0-9a-fA-F]{1,4}$|^([0-9a-fA-F]{1,4}:){1,3}::([0-9a-fA-F]{1,4}:){0,2}[0-9a-fA-F]{1,4}$|^([0-9a-fA-F]{1,4}:){1,2}::([0-9a-fA-F]{1,4}:){0,3}[0-9a-fA-F]{1,4}$|^[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:){0,4}[0-9a-fA-F]{1,4}$|^::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}$|^::([0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}$|^::$|^::1$/;
  
  // Mixed IPv6 with IPv4
  const mixedIPv6 = /^([0-9a-fA-F]{1,4}:){6}(\d{1,3}\.){3}\d{1,3}$/;
  
  // IPv4 regex to explicitly exclude
  const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
  
  // If it matches IPv4, return false
  if (ipv4Regex.test(value)) return false;
  
  // Check if it matches any IPv6 pattern
  return fullIPv6.test(value) || compressedIPv6.test(value) || mixedIPv6.test(value);
}