/**
 * Validates Argentine phone numbers covering mobile/landline formats
 */
export function isValidArgentinePhone(value: string): boolean {
  // Normalize the phone number by removing spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Regex for various Argentine phone number formats:
  // - +54 followed by optional 9, area code (2-4 digits), and subscriber number (6-8 digits)
  // - 0 followed by area code (2-4 digits), and subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54(9)?([1-9]\d{1,3})\d{6,8}|0([1-9]\d{1,3})\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleanValue)) return false;
  
  // Check if it starts with +54 or 0
  const hasCountryCode = cleanValue.startsWith('+54');
  const hasTrunkPrefix = cleanValue.startsWith('0');
  
  // It must start with either +54 or 0, but not both
  if (!(hasCountryCode || hasTrunkPrefix) || (hasCountryCode && hasTrunkPrefix)) return false;
  
  let startIndex = 0;
  
  // Move past country code if present
  if (hasCountryCode) {
    startIndex += 3; // Skip '+54'
  }
  
  // Move past trunk prefix if present (this only happens when there's no country code)
  if (hasTrunkPrefix && !hasCountryCode) {
    startIndex += 1; // Skip '0'
  }
  
  // Check for mobile indicator '9'
  let hasMobileIndicator = false;
  if (cleanValue.charAt(startIndex) === '9' && hasCountryCode) {
    hasMobileIndicator = true;
    startIndex += 1;
  }
  
  // Extract area code (2-4 digits, first digit 1-9)
  let areaCodeEndIndex = startIndex + 2;
  while (areaCodeEndIndex < startIndex + 4 && 
         areaCodeEndIndex < cleanValue.length && 
         /\d/.test(cleanValue.charAt(areaCodeEndIndex))) {
    areaCodeEndIndex++;
  }
  
  const areaCode = cleanValue.substring(startIndex, areaCodeEndIndex);
  
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode.charAt(0) === '0') return false;
  
  // Extract subscriber number (6-8 digits)
  const subscriberNumber = cleanValue.substring(areaCodeEndIndex);
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}