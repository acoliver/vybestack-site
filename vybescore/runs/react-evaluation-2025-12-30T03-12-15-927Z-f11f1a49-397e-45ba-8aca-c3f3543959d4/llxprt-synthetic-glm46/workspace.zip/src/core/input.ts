/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerObserver,
  addDependency
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = Object.is as EqualFn<T>
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Register the subject in the global registry for tracking
  registerObserver(s as Observer<T>)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Establish dependency relationship
      addDependency(observer as Observer<unknown>, s as Observer<T>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      // Directly update the input observer, which will trigger cascading updates
      updateObserver(s as Observer<T>)
    }
    return s.value
  }

  return [read, write]
}
