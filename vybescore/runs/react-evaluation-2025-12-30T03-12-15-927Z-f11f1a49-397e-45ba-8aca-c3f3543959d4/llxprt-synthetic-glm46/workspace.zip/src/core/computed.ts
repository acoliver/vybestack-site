/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  registerObserver,
  addDependency,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value: undefined, // Always start with undefined so it gets computed
    updateFn,
  }

  // Register the observer in the global registry
  registerObserver(o)
  
  
  
  // Computed getter function that tracks dependencies
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      o.observer = observer
      // Establish dependency relationship
      addDependency(observer as Observer<unknown>, o)
    }
    // Always recompute when accessed
    const previous = getActiveObserver()
    setActiveObserver(o)
    try {
      const newValue = o.updateFn(o.value)
      if (newValue !== undefined) {
        o.value = newValue
      }
    } finally {
      setActiveObserver(previous)
    }
    return o.value!
  }

  // Always call updateObserver to compute the initial value
  updateObserver(o)
  
  return getter
}
