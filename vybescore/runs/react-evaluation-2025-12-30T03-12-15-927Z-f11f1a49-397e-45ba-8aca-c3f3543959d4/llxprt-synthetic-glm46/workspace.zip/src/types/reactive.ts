/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observer?: ObserverR | undefined
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export type Observer<T> = ObserverR & ObserverV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Check if observer has updateFn (Inputs don't have updateFn, but computed values and callbacks do)
  if (!observer.updateFn) {
    // If this is an input, just trigger dependent observers
    triggerDependentUpdates(observer as Observer<unknown>)
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    if (newValue !== undefined) {
      observer.value = newValue
    }
  } finally {
    activeObserver = previous
  }
  
  // Trigger dependent observers
  triggerDependentUpdates(observer as Observer<unknown>)
}

function triggerDependentUpdates(changedObserver: Observer<unknown>): void {
  // Find all observers that depend on this one
  const toUpdate: Observer<unknown>[] = []
  observerRegistry.forEach(depObserver => {
    const deps = observerDependencies.get(depObserver as Observer<unknown>)
    if (deps && deps.has(changedObserver as Observer<unknown> | ObserverR)) {
      toUpdate.push(depObserver as Observer<unknown>)
    }
  })
  
  // Update all dependent observers
  toUpdate.forEach(dependentObserver => {
    try {
      updateObserver(dependentObserver)
    } catch (error) {
      // Ignore errors in dependent observers to prevent cascade failures
    }
  })
}

// Global registry for tracking all observers for proper cleanup and reactive updates
const observerRegistry = new Set<Observer<unknown>>()

// Track dependencies between observers
const observerDependencies = new Map<Observer<unknown>, Set<Observer<unknown> | ObserverR>>()

export function registerObserver<T>(observer: Observer<T>): void {
  observerRegistry.add(observer as Observer<unknown>)
}

export function unregisterObserver<T>(observer: Observer<T>): void {
  observerRegistry.delete(observer as Observer<unknown>)
  // Clean up dependency tracking
  observerDependencies.delete(observer as Observer<unknown>)
  // Remove this observer from other observers' dependencies
  observerDependencies.forEach(deps => deps.delete(observer as Observer<unknown>))
}

export function addDependency<T, U>(dependent: Observer<T>, dependency: Observer<U> | ObserverR): void {
  if (!observerDependencies.has(dependent as Observer<unknown>)) {
    observerDependencies.set(dependent as Observer<unknown>, new Set())
  }
  observerDependencies.get(dependent as Observer<unknown>)!.add(dependency as Observer<unknown> | ObserverR)
}
