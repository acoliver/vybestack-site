/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  // Using word boundaries to ensure we match complete words
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const filteredMatches = matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      lowerMatch === exception.toLowerCase()
    );
  });
  
  return [...new Set(filteredMatches)]; // Remove duplicates
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find patterns where token appears after a digit (using lookbehind)
  // The lookbehind ensures we're not at the start of the string
  // Use this pattern for validation
  new RegExp(`(?<!^)(?<=\\d)${escapedToken}`, 'g');
  
  // Find the full context (digit + token) and return as array
  const contextPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const contexts = text.match(contextPattern) || [];
  
  return contexts;
}

/**
 * Check if password is strong enough.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace.
 * No immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[a-z]/.test(value)) return false; // lowercase
  if (!/[A-Z]/.test(value)) return false; // uppercase
  if (!/\d/.test(value)) return false;    // digit
  if (!/[^a-zA-Z0-9\s]/.test(value)) return false; // symbol
  
  // Check for immediate repeated sequences
  // Look for patterns like abab, 1212, etc.
  for (let i = 0; i < value.length - 3; i++) {
    const seq1 = value.substring(i, i + 2);
    const seq2 = value.substring(i + 2, i + 4);
    if (seq1 === seq2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns
  // Standard IPv6: 8 groups of hex digits separated by colons
  // Shorthand: :: for consecutive zeros
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/;
  
  // Check for IPv6 patterns anywhere in the string
  const hasIPv6 = ipv6Pattern.test(value);
  
  // If no IPv6 pattern found, return false
  if (!hasIPv6) {
    return false;
  }
  
  // Check for IPv4 patterns that might confuse us
  const ipv4Pattern = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/;
  const hasIPv4 = ipv4Pattern.test(value);
  
  // If it's pure IPv4, don't count it as IPv6
  if (hasIPv4 && !hasIPv6) {
    return false;
  }
  
  return hasIPv6;
}