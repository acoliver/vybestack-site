/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle null or empty input
  if (!text) {
    return text;
  }
  
  // Pattern to match sentence endings followed by optional whitespace and non-space character
  // Captures: punctuation + whitespace + next character
  const sentencePattern = /([.!?])([\s]*)([^\s])/g;
  
  return text.replace(sentencePattern, (match, punctuation, spaces, nextChar) => {
    // Capitalize the next character after sentence ending
    return punctuation + spaces + nextChar.toUpperCase();
  }).replace(/^([a-z])/i, (match, firstChar) => {
    // Capitalize the very first character if it's a letter
    return firstChar.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches most common URL formats
  const urlPattern = /\bhttps?:\/\/[^\s<>"']+/gi;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from URLs
  const cleanUrls = matches.map(url => {
    // Remove trailing punctuation that might be attached
    return url.replace(/[.,!?;:]*(?:\s|$)/, '');
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving the rest of the URL
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match HTTP URLs with example.com domain - include the leading slash in capture
  const docsUrlPattern = /http:\/\/example\.com(\/[^\s<>"']*)/gi;
  
  return text.replace(docsUrlPattern, (match, path) => {
    // Check for dynamic hints that should not trigger host rewrite
    const hasDynamicHints = /(\?|=|&|\.(jsp|php|asp|aspx|do|cgi|pl|py)$|cgi-bin)/i.test(path);
    
    if (!hasDynamicHints && path.startsWith('/docs/')) {
      // Replace host with docs.example.com and upgrade to https
      return 'https://docs.example.com' + path;
    } else {
      // Just upgrade to https, keep original host
      return 'https://example.com' + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  
  // Validate month and day ranges
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Return the year part
  return match[3];
}
