export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Run Luhn algorithm checksum validation for credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  // Remove any non-digit characters
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Allow typical email formats, reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for common issues
  if (value.includes('..')) {
    return false; // Double dots
  }
  
  if (value.endsWith('.')) {
    return false; // Trailing dot
  }
  
  // Check for underscore in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false; // Underscore in domain
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.trim();
  
  // Allow extensions if option is set
  const extensionPattern = options?.allowExtensions ? '(?:\\s*(?:ext|x|extension)\\s*\\d{1,5})?' : '';
  
  // Pattern for US phone numbers
  const phonePattern = new RegExp(
    `^\\+?1?\\s*([2-9][0-8][0-9])([2-9][0-9]{2})([0-9]{4})${extensionPattern}$`,
    'i'
  );
  
  // Pattern with common separators
  const separatedPattern = new RegExp(
    `^\\+?1?\\s*\\(?([2-9][0-8][0-9])\\)?[\\s\\-\\.]?([2-9][0-9]{2})[\\s\\-\\.]?([0-9]{4})${extensionPattern}$`,
    'i'
  );
  
  // Check separated format first
  const separatedMatch = cleaned.match(separatedPattern);
  if (separatedMatch) {
    return true;
  }
  
  // Check compact format
  const compactMatch = cleaned.match(phonePattern);
  return compactMatch !== null;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, parentheses, and dots but preserve the + sign
  const cleaned = value.replace(/[\s().-]/g, '');
  
  // Argentine phone validation rules:
  // 1. Optional country code +54
  // 2. Optional mobile indicator 9
  // 3. Trunk prefix 0 is mandatory when no country code, optional otherwise
  // 4. Area code: 2-4 digits, first digit 1-9
  // 5. Subscriber number: 6-8 digits total
  
  // First check: starts with +54 (country code format)
  if (cleaned.startsWith('+54')) {
    const withoutCountryCode = cleaned.slice(3);
    
    // Case 1: +54 [9] 0 area subscriber
    // Pattern: ^9?0[1-9]\d{1,3}\d{6,8}$
    const case1Pattern = /^9?0[1-9]\d{1,3}\d{6,8}$/;
    if (case1Pattern.test(withoutCountryCode)) {
      const subscriberLength = withoutCountryCode.replace(/^9?0[1-9]\d{1,3}/, '').length;
      return subscriberLength >= 6 && subscriberLength <= 8;
    }
    
    // Case 2: +54 9 area subscriber (9 comes after country code)
    // Pattern: ^9[1-9]\d{1,3}\d{6,8}$
    const case2Pattern = /^9[1-9]\d{1,3}\d{6,8}$/;
    if (case2Pattern.test(withoutCountryCode)) {
      const subscriberLength = withoutCountryCode.replace(/^9[1-9]\d{1,3}/, '').length;
      return subscriberLength >= 6 && subscriberLength <= 8;
    }
    
    // Case 3: +54 area subscriber (just area code after country code)
    // Pattern: ^[1-9]\d{1,3}\d{6,8}$
    const case3Pattern = /^[1-9]\d{1,3}\d{6,8}$/;
    if (case3Pattern.test(withoutCountryCode)) {
      const subscriberLength = withoutCountryCode.replace(/^[1-9]\d{1,3}/, '').length;
      return subscriberLength >= 6 && subscriberLength <= 8;
    }
  } 
  // Second check: starts with 0 (domestic format, trunk is mandatory)
  else if (cleaned.startsWith('0')) {
    // Pattern: ^0[1-9]\d{1,3}\d{6,8}$
    const domesticPattern = /^0[1-9]\d{1,3}\d{6,8}$/;
    if (domesticPattern.test(cleaned)) {
      const subscriberLength = cleaned.replace(/^0[1-9]\d{1,3}/, '').length;
      return subscriberLength >= 6 && subscriberLength <= 8;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject empty strings or just whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Allow unicode letters (including accents), apostrophes, hyphens, and spaces
  // Reject digits, symbols, and special characters like X Æ A-12
  const nameRegex = /^[\p{L}\p{M}]+(?:[\s'-][\p{L}\p{M}]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check to reject obvious non-names
  // No digits allowed anywhere
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject very short or very long names
  if (value.length < 2 || value.length > 100) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check if it's a reasonable length for a credit card
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for common credit card prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  let validPrefix = false;
  
  // Visa
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    validPrefix = true;
  }
  // MasterCard 51-55
  else if (cleaned.startsWith('5') && cleaned.length === 16) {
    const secondDigit = parseInt(cleaned[1], 10);
    if (secondDigit >= 1 && secondDigit <= 5) {
      validPrefix = true;
    }
  }
  // MasterCard 2221-2720
  else if (cleaned.startsWith('222') && cleaned.length === 16) {
    const prefix = parseInt(cleaned.substring(0, 4), 10);
    if (prefix >= 2221 && prefix <= 2720) {
      validPrefix = true;
    }
  }
  // American Express
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    validPrefix = true;
  }
  
  if (!validPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}