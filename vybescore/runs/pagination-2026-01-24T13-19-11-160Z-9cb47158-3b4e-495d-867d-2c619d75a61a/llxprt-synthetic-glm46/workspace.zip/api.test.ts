import { describe, it, expect } from 'vitest';
import request from 'supertest';
import { createApp } from './src/server/app';
import type { Express } from 'express';

describe('API endpoints', () => {
  const STATUS_BAD_REQUEST = 400;
  const STATUS_OK = 200;
  const defaultItemsPerPage = 5;

  async function getApp(): Promise<Express> {
    const app = await createApp();
    return app;
  }

  describe('GET /inventory', () => {
    it('should return default pagination for no query params', async () => {
      const app = await getApp();
      const res = await request(app).get('/inventory');
      expect(res.status).toBe(STATUS_OK);
      expect(res.body.page).toBe(1);
      expect(res.body.limit).toBe(defaultItemsPerPage);
      expect(res.body.items).toHaveLength(defaultItemsPerPage);
      expect(res.body.total).toBe(15); // From seed.sql
      expect(res.body.hasNext).toBe(true);
    });

    it('should return the correct pagination for specific page', async () => {
      const app = await getApp();
      const res = await request(app).get('/inventory?page=2');
      expect(res.status).toBe(STATUS_OK);
      expect(res.body.page).toBe(2);
      expect(res.body.limit).toBe(defaultItemsPerPage);
      expect(res.body.items).toHaveLength(defaultItemsPerPage);
      expect(res.body.total).toBe(15);
      expect(res.body.hasNext).toBe(true);
    });

    it('should return the correct pagination with custom limit', async () => {
      const app = await getApp();
      const res = await request(app).get('/inventory?limit=10');
      expect(res.status).toBe(STATUS_OK);
      expect(res.body.page).toBe(1);
      expect(res.body.limit).toBe(10);
      expect(res.body.items).toHaveLength(10);
      expect(res.body.total).toBe(15);
      expect(res.body.hasNext).toBe(true);
    });

    it('should return remaining items on last page', async () => {
      const app = await getApp();
      const res = await request(app).get('/inventory?page=3&limit=5');
      expect(res.status).toBe(STATUS_OK);
      expect(res.body.page).toBe(3);
      expect(res.body.limit).toBe(5);
      expect(res.body.items).toHaveLength(5); // Last 5 items out of 15
      expect(res.body.total).toBe(15);
      expect(res.body.hasNext).toBe(false);
    });

    it('should return correct items for custom page and limit', async () => {
      const app = await getApp();
      const res = await request(app).get('/inventory?page=2&limit=3');
      expect(res.status).toBe(STATUS_OK);
      expect(res.body.page).toBe(2);
      expect(res.body.limit).toBe(3);
      expect(res.body.items).toHaveLength(3);
      expect(res.body.items[0].id).toBe(4); // Should start with item ID 4 (items 4, 5, 6)
      expect(res.body.total).toBe(15);
      expect(res.body.hasNext).toBe(true);
    });

    it('should reject non-integer page values', async () => {
      const app = await getApp();
      let res = await request(app).get('/inventory?page=abc');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid page parameter');

      res = await request(app).get('/inventory?page=2.5');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid page parameter');

      res = await request(app).get('/inventory?page=0');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid page parameter');

      res = await request(app).get('/inventory?page=-1');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid page parameter');
    });

    it('should reject invalid limit values', async () => {
      const app = await getApp();
      let res = await request(app).get('/inventory?limit=abc');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid limit parameter');

      res = await request(app).get('/inventory?limit=2.5');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid limit parameter');

      res = await request(app).get('/inventory?limit=0');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid limit parameter');

      res = await request(app).get('/inventory?limit=-1');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid limit parameter');

      res = await request(app).get('/inventory?limit=101');
      expect(res.status).toBe(STATUS_BAD_REQUEST);
      expect(res.body.error).toContain('Invalid limit parameter');
    });

    it('should handle page beyond available data', async () => {
      const app = await getApp();
      const res = await request(app).get('/inventory?page=100');
      expect(res.status).toBe(STATUS_OK);
      expect(res.body.page).toBe(100);
      expect(res.body.limit).toBe(defaultItemsPerPage);
      expect(res.body.items).toHaveLength(0); // No items
      expect(res.body.total).toBe(15);
      expect(res.body.hasNext).toBe(false);
    });
  });
});