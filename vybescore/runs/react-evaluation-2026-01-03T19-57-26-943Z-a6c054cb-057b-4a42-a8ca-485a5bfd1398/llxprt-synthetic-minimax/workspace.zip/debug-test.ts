import { createInput, createComputed, createCallback } from './src/index.js'

// Debug test 1: Basic dependency tracking
console.log('=== Debug Test 1: Basic Input/Computed ===')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, input =', input())
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('  Computing timesThirty, input =', input())
  return input() * 30
})

console.log('Initial values:')
console.log('  timesTwo =', timesTwo())
console.log('  timesThirty =', timesThirty())

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('After input change:')
console.log('  timesTwo =', timesTwo())
console.log('  timesThirty =', timesThirty())

// Debug test 2: Circular dependencies
console.log('\n=== Debug Test 2: Circular Dependencies ===')
const [input2, setInput2] = createInput(1)
const timesTwo2 = createComputed(() => {
  console.log('  Computing timesTwo2, input =', input2())
  return input2() * 2
})
const timesThirty2 = createComputed(() => {
  console.log('  Computing timesThirty2, input =', input2())
  return input2() * 30
})
const sum2 = createComputed(() => {
  console.log('  Computing sum2, timesTwo2 =', timesTwo2(), 'timesThirty2 =', timesThirty2())
  return timesTwo2() + timesThirty2()
})

console.log('Initial circular values:')
console.log('  sum2 =', sum2())

console.log('\n=== Setting input2 to 3 ===')
setInput2(3)

console.log('After input2 change:')
console.log('  sum2 =', sum2())

// Debug test 3: Callback behavior
console.log('\n=== Debug Test 3: Callback Behavior ===')
const [input3, setInput3] = createInput(1)
const output3 = createComputed(() => {
  console.log('  Computing output3, input =', input3())
  return input3() + 1
})
let value = 0
console.log('Creating callback...')
createCallback(() => {
  console.log('  Callback firing, output =', output3())
  value = output3()
  console.log('  value set to', value)
})

console.log('Initial value:', value)
console.log('\n=== Setting input3 to 3 ===')
setInput3(3)
console.log('Final value:', value)
console.log('Expected value: 4')