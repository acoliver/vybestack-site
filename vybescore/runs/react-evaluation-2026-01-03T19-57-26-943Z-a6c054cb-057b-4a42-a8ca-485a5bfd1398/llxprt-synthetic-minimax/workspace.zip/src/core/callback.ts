/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create persistent observer that gets re-triggered on dependency changes
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T) => {
      if (!disposed && typeof updateFn === 'function') {
        updateFn(currentValue)
      }
      return currentValue as T
    },
  }
  
  // Register observer to establish reactive dependencies
  updateObserver(observer)
  
  // Return unsubscribe function that disposes the callback
  return () => {
    disposed = true
  }
}
