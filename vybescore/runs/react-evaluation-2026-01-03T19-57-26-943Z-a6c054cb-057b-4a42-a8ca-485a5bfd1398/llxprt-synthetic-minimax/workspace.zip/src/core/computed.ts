/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create getter that properly tracks dependencies
  const getter: GetterFn<T> = () => {
    // Always force recomputation to ensure dependencies are captured
    updateObserver(observer)
    return observer.value!
  }
  
  // Don't compute initial value - wait for first access
  // This prevents double computation on creation
  
  return getter
}
