/**
 * Computed closure implementation for derived values.

This implementation re-computes values on access and handles proper observer pattern.
*/

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  getActiveObserver,
  setActiveObserver,
  notifyObservers,
  subscribeObserver,
  Subject,
  EqualFn,
  clearObserverDependencies,
  getObserverDependencies
} from '../types/reactive.js'

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (typeof equal === 'function') {
    return equal
  }
  if (equal === true) {
    return Object.is as EqualFn<T>
  }
  return undefined
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject to manage this computed value's observers
  const subject: Subject<T> = {
    name: options?.name,
    value: value as T,
    equalFn: createEqualFn(equal),
    observers: new Set(),
    __isComputed: true
  }

  // Create an observer for this computed value
  const computedObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn: () => {
      // Clear previous dependencies before recomputing
      clearObserverDependencies(computedObserver)
      
      const previousObserver = getActiveObserver()
      setActiveObserver(computedObserver)
      
      try {
        const newValue = updateFn(computedObserver.value)
        
        const equalFn = subject.equalFn
        
        if (subject.value === undefined || !equalFn || !equalFn(subject.value, newValue)) {
          subject.value = newValue
          computedObserver.value = newValue
          
          notifyObservers(subject)
        }
      } finally {
        setActiveObserver(previousObserver)
      }
      
      return computedObserver.value
    },
    subscribed: true
  }

  const getter: GetterFn<T> = (): T => {
    const currentObserver = getActiveObserver()
    
    if (currentObserver && currentObserver !== computedObserver) {
      // Subscribe current observer to this computed value
      subscribeObserver(subject, currentObserver as Observer<unknown>)
      
      // Subscribe the current observer to all dependencies of this computed value
      const dependencies = getObserverDependencies(computedObserver)
      
      for (const dep of dependencies) {
        subscribeObserver(dep, currentObserver as Observer<unknown>)
      }
    }
    
    // Recompute by calling the update function
    computedObserver.updateFn()
    
    return subject.value
  }

  return getter
}
