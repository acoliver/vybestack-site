/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create an observer for this callback
  const callbackObserver: Observer<T> = {
    value,
    updateFn: () => {
      const previousObserver = getActiveObserver()
      setActiveObserver(callbackObserver)
      
      try {
        callbackObserver.value = updateFn(callbackObserver.value)
      } finally {
        setActiveObserver(previousObserver)
      }
      
      return callbackObserver.value
    },
    subscribed: true
  }

  // Execute the initial callback to track its dependencies
  callbackObserver.updateFn()

  return () => {
    if (!callbackObserver.subscribed) return

    callbackObserver.subscribed = false
  }
}
