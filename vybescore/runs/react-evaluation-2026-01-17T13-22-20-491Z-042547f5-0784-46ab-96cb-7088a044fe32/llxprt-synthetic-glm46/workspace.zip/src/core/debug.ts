// Simple debugging utilities

let debugMode = true

export function setDebugEnabled(enabled: boolean): void {
  debugMode = enabled
}

export function debugLog(message: string, data?: unknown): void {
  if (debugMode) {
    console.log(`[REACTIVE] ${message}`, data)
  }
}