/**
 * Reactive programming system implementation based on a simplified observer pattern.
 */

// Export partial types for public API (ObserverR and ObserverV are implementation details)
export type ObserverR = {
  name?: string
  subscribed?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
}

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Core reactive primitives - observers observe subjects
export interface Observer<T = unknown> {
  name?: string
  subscribed?: boolean
  value?: T
  updateFn: UpdateFn<T>
}

export interface Subject<T = unknown> {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers?: Set<Observer<unknown>>
  __isComputed?: boolean
}

let activeObserver: Observer<unknown> | undefined

// Global state management
let notifying = false

export function getActiveObserver<T>(): Observer<T> | undefined {
  return activeObserver as Observer<T> | undefined
}

export function setActiveObserver<T>(observer: Observer<T> | undefined): void {
  activeObserver = observer as Observer<unknown> | undefined
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
  } catch (error) {
    console.error('Error in observer update:', error)
    throw error
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (!subject.observers || notifying) return
  
  notifying = true
  try {
    const observers = Array.from(subject.observers)
    for (const observer of observers) {
      if (observer.subscribed === false) continue
      updateObserver(observer as Observer<unknown>)
    }
  } finally {
    notifying = false
  }
}

export function subscribeObserver<T>(subject: Subject<T>, observer: Observer<T>): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  
  // If this observer is already on this computed subject, don't add it again
  if (subject.__isComputed && subject.observers.has(observer as Observer<unknown>)) {
    return
  }
  
  subject.observers.add(observer as Observer<unknown>)
  
  if (observer.subscribed !== false) {
    observer.subscribed = true
  }
  
  // Auto-subscribe dependencies when observer executes
  const currentObserver = getActiveObserver()
  if (currentObserver && currentObserver !== observer) {
    // Track dependencies for all observers except input getters
    const deps = getObserverDependencies(currentObserver)
    if (!deps.has(subject as Subject<unknown>)) {
      deps.add(subject as Subject<unknown>)
    }
  }
}

export function unsubscribeObserver<T>(subject: Subject<T>, observer: Observer<T>): void {
  if (!subject.observers) return
  subject.observers.delete(observer as Observer<unknown>)
  observer.subscribed = false
}

// Simple map to track dependencies for each observer
const observerDependencies = new WeakMap<Observer<unknown>, Set<Subject<unknown>>>()

export function getObserverDependencies(observer: Observer<unknown>): Set<Subject<unknown>> {
  let deps = observerDependencies.get(observer)
  if (!deps) {
    deps = new Set()
    observerDependencies.set(observer, deps)
  }
  return deps
}

export function clearObserverDependencies(observer: Observer<unknown>): void {
  const deps = observerDependencies.get(observer)
  if (deps) {
    deps.clear()
  }
}
