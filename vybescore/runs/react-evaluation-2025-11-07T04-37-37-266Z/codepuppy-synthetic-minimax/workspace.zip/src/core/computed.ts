/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initialize the computed value
  updateObserver(o)

  const getter = (): T => {
    // Get the current observer that's tracking dependencies
    const observer = getActiveObserver()
    
    // If we're being observed, store the observer relationship
    // and recompute to track dependencies and notify of changes
    if (observer) {
      (o as { _observer?: Observer<T> })._observer = observer as Observer<T>
      const previousValue = o.value
      updateObserver(o)
      
      // If our value changed, notify our observer
      if (previousValue !== o.value) {
        updateObserver(observer as Observer<T>)
      }
    } else {
      // If not being observed, only recompute if we don't have a value yet
      if (o.value === undefined) {
        updateObserver(o)
      }
    }
    
    return o.value!
  }
  
  // Store the observer reference on the getter function itself
  ;(getter as { _observer?: Observer<T> })._observer = o
  
  return getter
}