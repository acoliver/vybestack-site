/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Normalize the equality function
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (a, b) => a === b
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (a, b) => a === b : () => false
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      // Store a reference back to this subject so the observer can track it
      ;(observer as { _subject?: Subject<T> })._subject = s
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update and notify if value actually changed
    if (!s.equalFn || !s.equalFn(s.value, nextValue)) {
      s.value = nextValue
      if (s.observer) {
        const observer = s.observer as Observer<T>
        updateObserver(observer)
        
        // If this observer has dependent observers, notify them
        const dependentObserver = (observer as { _observer?: Observer<T> })._observer
        if (dependentObserver) {
          updateObserver(dependentObserver)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
