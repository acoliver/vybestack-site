/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserverWithNotification,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Support boolean flag or custom equality function
  const equalFn: EqualFn<T> = typeof equal === 'function' 
    ? equal 
    : equal === false 
      ? () => false 
      : (a, b) => a === b

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers!.add(observer)
      
      // Track this subject for cleanup
      if (!observer._subjects) {
        observer._subjects = new Set()
      }
      observer._subjects.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if value actually changed
    const equalFn = s.equalFn || ((a, b) => a === b)
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      // Use updateObserverWithNotification to propagate updates to observers' observers
      s.observers?.forEach(observer => {
        updateObserverWithNotification(observer as Observer<unknown>)
      })
    }
    return s.value
  }

  return [read, write]
}
