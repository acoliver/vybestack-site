/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    _subjects: new Set(),
    observers: new Set(),
  }

  // Compute initial value
  updateObserver(observer)

  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    if (activeObserver) {
      // When accessed within an observer context, register that observer
      observer.observers!.add(activeObserver)
      
      // Also track this computed as a subject for cleanup
      if (!observer._subjects) {
        observer._subjects = new Set()
      }
      observer._subjects.add(activeObserver)
      
      // If accessed within an observer context, track this dependency
      // by re-evaluating the computed value
      updateObserver(observer)
      return observer.value!
    } else {
      // If accessed outside an observer context, just return current value
      return observer.value!
    }
  }

  return getter
}