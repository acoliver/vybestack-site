/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  // Track subjects this observer is subscribed to for cleanup
  _subjects?: Set<ISubject>
  // Also act as a subject for other observers
  observers?: Set<ObserverR>
} & ISubject

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export interface ISubject {
  name?: string
  observers?: Set<ObserverR>
}

export type SubjectR = ISubject

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function updateObserverWithNotification<T>(observer: Observer<T>): void {
  updateObserver(observer)
  
  // Notify observers that depend on this computed value
  if (observer.observers && observer.observers.size > 0) {
    observer.observers.forEach(obs => {
      updateObserverWithNotification(obs as Observer<unknown>)
    })
  }
  
  // If this observer has subjects tracking it, notify them
  if (observer._subjects) {
    observer._subjects.forEach(subject => {
      if (subject.observers && subject.observers.size > 0) {
        // Convert to proper type for notifyObservers
        const subjectWithType = subject as SubjectR & { value?: unknown; equalFn?: (a: unknown, b: unknown) => boolean }
        notifyObservers(subjectWithType as SubjectR & SubjectV<unknown>)
      }
    })
  }
}

export function notifyObservers<T>(subject: SubjectR & SubjectV<T>): void {
  subject.observers?.forEach(observer => {
    updateObserver(observer as Observer<unknown>)
  })
}
