/**
 * Encode plain text to Base64 using canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check for correct padding
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // If padding exists, it can only be 1 or 2 characters at the end
    const padding = input.substring(paddingIndex);
    if (padding.length > 2 || !/^=+$/.test(padding)) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    
    // Check that padding is only at the end of the string
    if (paddingIndex < input.length - padding.length) {
      throw new Error('Invalid Base64 input: padding not at end');
    }
  }

  // Check for valid length according to Base64 specification
  if (input.length % 4 === 1) {
    throw new Error('Invalid Base64 input: length is not valid');
  }

  // Add padding for the Node.js Buffer.from() call if needed
  let normalizedInput = input;
  if (paddingIndex === -1 && input.length % 4 !== 0) {
    normalizedInput = input + '='.repeat(4 - (input.length % 4));
  }

  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
