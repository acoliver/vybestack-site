const INVALID_INPUT_MSG = 'Invalid Base64 input';

/**
 * Validate Base64 input string.
 * Returns true if the input is valid Base64 (standard alphabet with optional padding).
 */
function isValidBase64(input: string): boolean {
  // Base64 regex: matches standard alphabet (A-Z, a-z, 0-9, +, /) with optional padding
  const base64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  
  // Must match the Base64 alphabet
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Padding must be correct: can only appear at the end
  // If there are padding characters, they must be 1 or 2 '=' chars
  const paddingIndex = input.indexOf('=');
  const hasInvalidPadding =
    paddingIndex !== -1 && (
      // Everything after the first '=' must be '='
      !/^=+$/.test(input.slice(paddingIndex)) ||
      // Can only have 1 or 2 padding chars
      input.slice(paddingIndex).length > 2 ||
      // If there's padding, the total length must be a multiple of 4
      input.length % 4 !== 0
    );
  
  return !hasInvalidPadding;
}

/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with standard alphabet (A-Z, a-z, 0-9, +, /) and optional padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate input before attempting to decode
  if (!isValidBase64(input)) {
    throw new Error(INVALID_INPUT_MSG);
  }

  try {
    const buffer = Buffer.from(input, 'base64');
    
    // Check if decoding actually worked (Buffer.from with 'base64' is forgiving)
    // Verify by re-encoding and comparing
    const reEncoded = buffer.toString('base64');
    
    // Remove padding from both for comparison (since input might lack padding)
    // but we validated structure above
    const normalizedInput = input.replace(/=+$/, '');
    const normalizedReEncoded = reEncoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReEncoded) {
      throw new Error(INVALID_INPUT_MSG);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_INPUT_MSG);
  }
}
