/**
 * Capitalizes the first character of each sentence.
 * After .!? punctuation, ensures exactly one space between sentences.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: collapse multiple spaces to single space
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Split sentences by punctuation followed by space or end of string
  const sentences = normalized.split(/([.!?])\s*/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    let part = sentences[i];
    
    if (part && capitalizeNext) {
      // Capitalize first letter and keep rest as-is
      part = part.charAt(0).toUpperCase() + part.slice(1);
      capitalizeNext = false;
    }
    
    result += part;
    
    // If this part ends sentence punctuation, next part needs capitalization
    if (/[.!?]/.test(part)) {
      capitalizeNext = true;
    }
  }
  
  // Clean up spacing around punctuation
  result = result.replace(/\s+([.!?])/g, '$1'); // Remove space before punctuation
  result = result.replace(/([.!?])(?!\s|$)/g, '$1 '); // Add space after punctuation
  result = result.replace(/\s+/g, ' '); // Collapse multiple spaces
  result = result.trim(); // Remove leading/trailing spaces
  
  return result;
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Enhanced URL regex pattern
  // Matches http://, https://, www., and domain-only URLs
  const urlRegex = /\b((?:https?:\/\/|www\.|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})(?:[^\s<>'"]+[\w\/-]))/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?)\]\}]+$/, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrade http to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /(http:\/\/[^ \s<>"']+)/g;
  
  return text.replace(urlPattern, (match) => {
    // Always upgrade to https first
    const upgradedUrl = match.replace('http://', 'https://');
    
    // Parse the URL components
    const urlMatch = upgradedUrl.match(/^(https:\/\/)([^\/]+)(.*)$/);
    if (!urlMatch) return upgradedUrl;
    
    const [, scheme, host, path] = urlMatch;
    
    // Check if we should skip host rewrite
    const skipPatterns = [
      /cgi-bin/i,
      /[?&=]/,           // Query strings
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/i  // Legacy extensions
    ];
    
    const shouldSkip = skipPatterns.some(pattern => pattern.test(path));
    
    // Check if path starts with /docs/ and we shouldn't skip
    if (path.startsWith('/docs/') && !shouldSkip) {
      // Rewrite host to docs.example.com
      const newHost = host.replace(/^([^\.]+)/, 'docs.$1');
      return scheme + newHost + path;
    }
    
    return upgradedUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate day range for each month (basic validation)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check if day is valid for the month
  if (day > daysInMonth[month - 1]) {
    // Check for leap year (February 29th)
    if (month === 2 && day === 29) {
      const yearNum = parseInt(year, 10);
      const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
      if (!isLeapYear) return 'N/A';
    } else {
      return 'N/A';
    }
  }
  
  return year;
}
