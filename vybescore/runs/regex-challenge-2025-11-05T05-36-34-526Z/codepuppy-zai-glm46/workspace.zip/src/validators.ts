export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex patterns.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^(?!.*\.\.)(?!.*\.$)[a-zA-Z0-9+._-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional check: no underscores in domain
  const domainHasUnderscore = /_/.test(value.split('@')[1] || '');
  
  return emailRegex.test(value) && !domainHasUnderscore;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length
  if (digitsOnly.length < 10) return false;
  
  // Handle optional +1 country code
  const phoneNumber = digitsOnly.startsWith('1') && digitsOnly.length === 11 
    ? digitsOnly.slice(1) 
    : digitsOnly;
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format patterns
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles with various formatting
 * Supports +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if it starts with +54 (country code)
  const hasCountryCode = cleanNumber.startsWith('+54');
  
  // For numbers starting with +54, the pattern is: +54 [9?] [0?] areaCode subscriber
  // For numbers without +54, the pattern is: 0 areaCode subscriber
  let areaCode: string;
  let subscriberNumber: string;
  
  if (hasCountryCode) {
    // Remove +54 prefix
    const withoutCountry = cleanNumber.substring(3);
    // Remove optional mobile indicator 9
    const withoutMobile = withoutCountry.startsWith('9') ? withoutCountry.substring(1) : withoutCountry;
    // Remove optional trunk prefix 0
    const withoutTrunk = withoutMobile.startsWith('0') ? withoutMobile.substring(1) : withoutMobile;
    
    // Area code should be 2-4 digits, subscriber 6-8 digits
    if (withoutTrunk.length < 8 || withoutTrunk.length > 12) return false;
    
    // Try different area code lengths (2-4 digits)
    for (let areaLen = 2; areaLen <= 4; areaLen++) {
      if (withoutTrunk.length > areaLen) {
        areaCode = withoutTrunk.substring(0, areaLen);
        subscriberNumber = withoutTrunk.substring(areaLen);
        
        // Check if area code starts with 2-9 and subscriber is 6-8 digits
        if (/^[2-9]/.test(areaCode) && subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
          return true;
        }
      }
    }
  } else {
    // Must start with 0 if no country code
    if (!cleanNumber.startsWith('0')) return false;
    
    const withoutTrunk = cleanNumber.substring(1);
    
    // Area code should be 2-4 digits, subscriber 6-8 digits
    if (withoutTrunk.length < 8 || withoutTrunk.length > 12) return false;
    
    // Try different area code lengths (2-4 digits)
    for (let areaLen = 2; areaLen <= 4; areaLen++) {
      if (withoutTrunk.length > areaLen) {
        areaCode = withoutTrunk.substring(0, areaLen);
        subscriberNumber = withoutTrunk.substring(areaLen);
        
        // Check if area code starts with 2-9 and subscriber is 6-8 digits
        if (/^[2-9]/.test(areaCode) && subscriberNumber.length >= 6 && subscriberNumber.length <= 8) {
          return true;
        }
      }
    }
  }
  
  return false;
}

/**
 * Validates personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and unconventional names like X Æ A-12
 */
export function isValidName(value: string): boolean {
  // Unicode letters with accents, apostrophes, hyphens, and spaces
  // Excludes digits and most symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Additional check: exclude certain symbol combinations
  const hasInvalidSymbols = /[¬®©™°±µ½¼¾×÷§¶†‡•…‰‹›""''«»¿¡§¶]/.test(value);
  
  // Must have at least one letter (not just symbols/spaces)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  
  return nameRegex.test(value) && !hasInvalidSymbols && hasLetter;
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = digit.toString().split('').map(Number).reduce((a, b) => a + b, 0);
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx with correct prefixes and lengths
 * Performs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  const cardPatterns = [
    { regex: /^4(\d{12}|\d{15})$/, type: 'Visa' }, // 13 or 16 digits starting with 4
    { regex: /^5[1-5]\d{14}$/, type: 'Mastercard' }, // 16 digits starting with 51-55
    { regex: /^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/, type: 'Mastercard' }, // New Mastercard ranges
    { regex: /^3[47]\d{13}$/, type: 'AmEx' } // 15 digits starting with 34 or 37
  ];
  
  // Check if it matches any card pattern
  let isValidFormat = false;
  for (const pattern of cardPatterns) {
    if (pattern.regex.test(cleanNumber)) {
      isValidFormat = true;
      break;
    }
  }
  
  if (!isValidFormat) return false;
  
  // Perform Luhn checksum
  return runLuhnCheck(cleanNumber);
}
