/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Split text into words and filter
  const words = text.split(/\s+/);
  
  // Filter words that contain the prefix and are not exceptions
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  const result = words.filter(word => {
    const lowerWord = word.toLowerCase();
    return lowerWord.includes(prefix.toLowerCase()) && 
           !lowerExceptions.includes(lowerWord) &&
           word.length > 0;
  });
  
  // Remove duplicates while preserving order
  return result.filter((word, index, self) => self.indexOf(word) === index);
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern: digit followed by token
  // Using string concatenation to avoid template string escape issues
  const pattern = new RegExp('\d+' + token, 'g');
  
  return text.match(pattern) || [];
}

/**
 * Validates passwords according to strong password policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, 1212, xyxy)
  // This looks for any 2-character pattern that repeats immediately
  if (/(..)\1/.test(value)) return false;
  
  // Check for longer repeated patterns (e.g., abcabc)
  if (/(...).*\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger positive.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it's clearly an IPv4 address, return false
  if (ipv4Pattern.test(value)) return false;
  
  // IPv6 patterns (various forms)
  const ipv6Patterns = [
    // Full form: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/,
    // Compressed form with :: : 2001:db8::8a2e:370:7334
    /(?:[0-9a-fA-F]{1,4}:){1,7}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/,
    // leading :: 
    /::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/,
    // trailing ::
    /(?:[0-9a-fA-F]{1,4}:){1,7}::/,
    // single ::
    /::/,
    // IPv4-mapped IPv6: ::ffff:192.0.2.128
    /::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/,
    // Short forms with fewer segments
    /(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}/
  ];
  
  // Check each IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Additional check: make sure we're not matching within an IPv4 address
      // Extract the potential IPv6 match and verify it doesn't contain IPv4 pattern
      const match = value.match(pattern);
      if (match && !ipv4Pattern.test(match[0])) {
        return true;
      }
    }
  }
  
  return false;
}