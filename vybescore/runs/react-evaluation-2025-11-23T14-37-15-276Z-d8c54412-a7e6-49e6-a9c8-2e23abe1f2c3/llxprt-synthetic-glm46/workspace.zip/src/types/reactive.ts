/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  [key: string]: unknown
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR>
  [key: string]: unknown
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Track dependencies for proper cleanup
const trackingDeps = new Map<ObserverR, Set<ObserverR>>()

export function trackDependency(observer: ObserverR, dependency: ObserverR): void {
  if (!trackingDeps.has(observer)) {
    trackingDeps.set(observer, new Set())
  }
  trackingDeps.get(observer)!.add(dependency)
}

export function clearDependencies(observer: ObserverR): void {
  const deps = trackingDeps.get(observer)
  if (deps) {
    deps.forEach(dep => {
      if ('observers' in dep && dep.observers) {
        (dep.observers as Set<ObserverR>).delete(observer)
      }
    })
    trackingDeps.delete(observer)
  }
}