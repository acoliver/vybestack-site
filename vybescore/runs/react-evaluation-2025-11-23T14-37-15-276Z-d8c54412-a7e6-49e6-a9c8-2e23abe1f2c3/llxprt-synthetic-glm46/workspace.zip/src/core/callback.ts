/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR, clearDependencies } from '../types/reactive.js'

// Store all active callbacks
const allCallbacks = new Set<unknown>()



/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Add to active callbacks
  allCallbacks.add(observer as unknown)
  
  // Initialize by running the effect once
  updateObserver(observer)
  
  let disposed = false
  
  // Return unsubscribe function
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from active callbacks
    allCallbacks.delete(observer as unknown)
    
    // Clear all tracked dependencies for this observer
    clearDependencies(observer as ObserverR)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}

// Helper to trigger all callbacks
export function triggerCallbacks(): void {
  allCallbacks.forEach(observer => {
    updateObserver(observer as Observer<unknown>)
  })
}