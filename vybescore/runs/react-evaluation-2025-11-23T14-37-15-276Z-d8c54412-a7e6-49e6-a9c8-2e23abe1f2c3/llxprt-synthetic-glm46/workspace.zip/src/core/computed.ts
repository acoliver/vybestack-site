/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

// Store all computed values to manage propagation
const allComputed = new Set<unknown>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Register this computed value
  allComputed.add(o as unknown)
  
  // Initialize the computed value
  updateObserver(o)
  
  // Return getter function that tracks dependencies
  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // This computed value is being accessed as part of another computation
      // Ensure it's up-to-date when accessed
      updateObserver(o)
    }
    return o.value!
  }
  
  return getter
}

// Helper function to propagate updates through computed values
export function propagateUpdates(): void {
  allComputed.forEach(computed => {
    updateObserver(computed as Observer<unknown>)
  })
}