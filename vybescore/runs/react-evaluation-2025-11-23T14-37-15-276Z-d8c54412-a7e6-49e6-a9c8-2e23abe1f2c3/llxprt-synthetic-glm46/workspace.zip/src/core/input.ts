/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  trackDependency,
  ObserverR
} from '../types/reactive.js'
import { propagateUpdates } from './computed.js'
import { triggerCallbacks } from './callback.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean equal to actual equality function if needed
  const equalFn = typeof _equal === 'function' ? _equal : 
                  _equal === true ? (a: T, b: T) => a === b : undefined

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && s.observers) {
s.observers.add(observer as ObserverR)
      // Track the dependency relationship
      trackDependency(observer as ObserverR, s as ObserverR)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all interested observers
    if (s.observers) {
      s.observers.forEach(observer => {
        updateObserver(observer as Observer<unknown>)
      })
    }
    
    // Propagate updates through computed values and callbacks
    propagateUpdates()
    triggerCallbacks()
    
    return s.value
  }

  return [read, write]
}