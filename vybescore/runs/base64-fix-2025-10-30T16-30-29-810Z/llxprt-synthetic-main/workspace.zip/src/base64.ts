/**
 * Encode plain text to Base64 using the standard RFC 4648 Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the standard RFC 4648 Base64 alphabet.
 * Rejects clearly invalid Base64 inputs.
 */
export function decode(input: string): string {
  // Check for invalid Base64 characters (outside the standard Base64 alphabet)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check for invalid padding placement
  if (input.includes('=')) {
    // Find the first padding character
    const paddingIndex = input.indexOf('=');
    // Padding can only appear at the end
    const paddingPart = input.substring(paddingIndex);
    if (!/^=[=]*$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: padding characters not at the end');
    }
    
    // Maximum of two padding characters allowed
    const paddingCount = (input.match(/=/g) || []).length;
    if (paddingCount > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // Check for invalid Base64 length with padding
    const lengthWithoutPadding = input.replace(/=+$/, '').length;
    if (paddingCount === 1 && lengthWithoutPadding % 4 !== 3) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
    if (paddingCount === 2 && lengthWithoutPadding % 4 !== 2) {
      throw new Error('Invalid Base64 input: incorrect padding');
    }
  } else {
    // For unpadded input, length must be divisible by 4
    if (input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    // First, try to decode the input directly
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Re-encode to verify the content matches our expectations
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    
    // For inputs with padding, we need more strict validation
    if (input.includes('=')) {
      // Verify the padding amount and location are correct
      if (reencoded !== input) {
        throw new Error('Invalid Base64 input: corrupted data');
      }
    } else {
      // For unpadded input, verify by re-encoding and removing padding
      const normalizedReencoded = reencoded.replace(/=+$/, '');
      if (normalizedReencoded !== input) {
        throw new Error('Invalid Base64 input: corrupted data');
      }
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
