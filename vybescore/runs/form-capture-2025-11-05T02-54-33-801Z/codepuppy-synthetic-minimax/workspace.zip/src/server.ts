import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import initSqlJs, { Database } from 'sql.js';

interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

class ContactFormServer {
  private app: express.Application;
  private db: Database | null = null;
  private server:(import('http').Server) | null = null;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.join(process.cwd(), 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(process.cwd(), 'src', 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Try to load existing database file
      try {
        const dbFile = await fs.readFile(this.dbPath);
        this.db = new SQL.Database(dbFile);
      } catch (error) {
        // If file doesn't exist, create new database
        this.db = new SQL.Database();
      }

      // Set up schema if needed
      const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
      const schema = await fs.readFile(schemaPath, 'utf-8');
      this.db.run(schema);
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) return;
    
    try {
      const data = this.db.export();
      await fs.writeFile(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private validateFormSubmission(data: FormSubmission): ValidationResult {
    const errors: string[] = [];

    // Required fields validation
    if (!data.firstName?.trim()) errors.push('First name is required');
    if (!data.lastName?.trim()) errors.push('Last name is required');
    if (!data.streetAddress?.trim()) errors.push('Street address is required');
    if (!data.city?.trim()) errors.push('City is required');
    if (!data.stateProvince?.trim()) errors.push('State/Province/Region is required');
    if (!data.postalCode?.trim()) errors.push('Postal/Zip code is required');
    if (!data.country?.trim()) errors.push('Country is required');
    if (!data.email?.trim()) errors.push('Email is required');
    if (!data.phone?.trim()) errors.push('Phone number is required');

    // Email validation (simple regex)
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push('Please enter a valid email address');
    }

    // Phone validation (international format)
    if (data.phone && ! /^[+]?[0-9\s\-()]+$/.test(data.phone)) {
      errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +');
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.push('Postal code can only contain letters, digits, spaces, and dashes');
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private setupRoutes(): void {
    // Home page - form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // Form submission handler
    this.app.post('/submit', async (req: Request, res: Response) => {
      try {
        const formData: FormSubmission = {
          firstName: req.body.firstName || '',
          lastName: req.body.lastName || '',
          streetAddress: req.body.streetAddress || '',
          city: req.body.city || '',
          stateProvince: req.body.stateProvince || '',
          postalCode: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };

        const validation = this.validateFormSubmission(formData);

        if (!validation.isValid) {
          return res.status(400).render('form', {
            errors: validation.errors,
            values: formData
          });
        }

        // Insert into database
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);
        stmt.free();

        // Save database to file
        await this.saveDatabase();

        // Redirect to thank you page
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Error submitting form:', error);
        res.status(500).render('form', {
          errors: ['An error occurred while submitting the form. Please try again.'],
          values: req.body
        });
      }
    });

    // Thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // Get the most recent submission to show first name
      let firstName = 'friend';
      try {
        if (this.db) {
          const stmt = this.db.prepare('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
          const result = stmt.get();
          stmt.free();
          if (result && typeof result === 'object' && 'first_name' in result) {
            firstName = String(result.first_name);
          }
        }
      } catch (error) {
        console.error('Error fetching recent submission:', error);
      }

      res.render('thank-you', { firstName });
    });

    // Error handling middleware
    this.app.use((err: Error, req: Request, res: Response) => {
      console.error('Unhandled error:', err);
      res.status(500).render('form', {
        errors: ['An unexpected error occurred. Please try again.'],
        values: {}
      });
    });
  }

  public async start(): Promise<void> {
    try {
      await this.initializeDatabase();
      
      const port = parseInt(process.env.PORT || '3000', 10);
      this.server = this.app.listen(port, () => {
        console.log(`Server running on port ${port}`);
      });

      // Graceful shutdown handler
      const shutdown = async (signal: string) => {
        console.log(`\nReceived ${signal}. Shutting down gracefully...`);
        
        if (this.server) {
          this.server.close(() => {
            console.log('HTTP server closed');
          });
        }

        if (this.db) {
          await this.saveDatabase();
          this.db.close();
          console.log('Database connection closed');
        }

        process.exit(0);
      };

      process.on('SIGTERM', () => shutdown('SIGTERM'));
      process.on('SIGINT', () => shutdown('SIGINT'));
      
    } catch (error) {
      console.error('Failed to start server:', error);
      process.exit(1);
    }
  }
}

// Start the server
const server = new ContactFormServer();
server.start().catch((error) => {
  console.error('Server startup failed:', error);
  process.exit(1);
});