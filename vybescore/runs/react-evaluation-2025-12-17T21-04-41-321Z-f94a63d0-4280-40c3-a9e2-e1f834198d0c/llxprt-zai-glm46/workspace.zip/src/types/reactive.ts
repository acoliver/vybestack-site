/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  dependents?: Set<ObserverR>
}

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
  dependents?: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T> & {
  dependents: Set<ObserverR>
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer // Set this observer as active so it can track dependencies
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function triggerUpdate(subject: { observer?: ObserverR; dependents?: Set<ObserverR> }): void {
  // Update dependents first (computed values, callbacks)
  if (subject.dependents && subject.dependents.size > 0) {
    // Create a copy to avoid issues with modifications during iteration
    const dependents = Array.from(subject.dependents)
    for (const dependent of dependents) {
      if (dependent && (dependent as Observer<unknown>).updateFn) {
        updateObserver(dependent as Observer<unknown>)
      }
    }
  }
  // Then update the subject's own observer if it has one
  if (subject.observer) {
    updateObserver(subject.observer as Observer<unknown>)
  }
}

export function removeObserver(subject: { dependents?: Set<ObserverR> }, observer: ObserverR): void {
  if (subject.dependents) {
    subject.dependents.delete(observer)
  }
}

// Global tracking for callback dependencies
let globalCallbackTracker: ((subject: SubjectR, observer: ObserverR) => void) | undefined

// Observer tracking for reactive updates
export function addObserver(subject: SubjectR, observer: ObserverR): void {
  if (!subject.dependents) {
    subject.dependents = new Set()
  }
  subject.dependents.add(observer)
  
  // Also notify global callback tracker if set
  if (globalCallbackTracker) {
    globalCallbackTracker(subject, observer)
  }
}

export function setGlobalCallbackTracker(tracker: (subject: SubjectR, observer: ObserverR) => void): void {
  globalCallbackTracker = tracker
}