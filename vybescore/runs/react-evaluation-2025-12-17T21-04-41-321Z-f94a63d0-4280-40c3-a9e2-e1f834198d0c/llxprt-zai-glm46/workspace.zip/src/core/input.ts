/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  triggerUpdate,
  addObserver
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    dependents: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this input as a dependency of the current observer
      addObserver(s, observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (newValue: T) => {
    // Check if value actually changed
    if (equalFn) {
      if (equalFn(s.value, newValue)) {
        return s.value
      }
    } else {
      if (s.value === newValue) {
        return s.value
      }
    }
    
    s.value = newValue
    triggerUpdate(s)
    return s.value
  }

  return [read, write]
}