/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  addObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependents: new Set(),
  }
  
  const getter = (): T => {
    const previousObserver = getActiveObserver()
    
    // If we're being called from within another reactive context,
    // register the current observer as a dependent of this computed value
    if (previousObserver && observer.dependents) {
      addObserver(observer, previousObserver)
    }
    
    setActiveObserver(observer)
    try {
      observer.value = updateFn(observer.value)
      return observer.value!
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  return getter
}