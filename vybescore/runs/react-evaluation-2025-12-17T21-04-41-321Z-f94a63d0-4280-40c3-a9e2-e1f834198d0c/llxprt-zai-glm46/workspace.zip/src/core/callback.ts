/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver, removeObserver, ObserverR, SubjectR, setGlobalCallbackTracker } from '../types/reactive.js'

// Global state to track dependencies for cleanup
const callbackDependencies = new Map<ObserverR, Set<SubjectR>>()

// Set up global tracker for dependencies
setGlobalCallbackTracker((subject: SubjectR, observer: ObserverR) => {
  const dependencies = callbackDependencies.get(observer)
  if (dependencies) {
    dependencies.add(subject)
  }
})

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependents: new Set(),
  }
  
  // Track which subjects this observer depends on for cleanup
  const dependencies = new Set<SubjectR>()
  callbackDependencies.set(observer, dependencies)
  
  // Execute immediately to track dependencies and register with them
  const prev = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    observer.value = updateFn(observer.value)
  } finally {
    setActiveObserver(prev)
  }
  
  const unsubscribe = () => {
    // Remove this observer from all tracked dependencies
    for (const dependency of dependencies) {
      removeObserver(dependency, observer)
    }
    dependencies.clear()
    callbackDependencies.delete(observer)
  }
  
  return unsubscribe
}