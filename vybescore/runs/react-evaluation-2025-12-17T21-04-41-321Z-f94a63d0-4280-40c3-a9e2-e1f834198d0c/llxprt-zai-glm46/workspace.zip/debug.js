import { createInput, createComputed, createCallback } from './src/index.js';

console.log('Testing reactive system...');

const [input, setInput] = createInput(1);
const output = createComputed(() => input() + 1);

console.log('Initial input:', input());
console.log('Initial output:', output());

let value = 0;
const unsubscribe = createCallback(() => {
  console.log('Callback triggered!');
  console.log('output() is:', output());
  value = output();
  console.log('Callback set value to:', value);
});

console.log('After callback setup, value is:', value);

console.log('Setting input to 3...');
setInput(3);

console.log('After setInput(3), input is:', input());
console.log('After setInput(3), output is:', output());
console.log('After setInput(3), value is:', value);

console.log('Expected: value should be 4');