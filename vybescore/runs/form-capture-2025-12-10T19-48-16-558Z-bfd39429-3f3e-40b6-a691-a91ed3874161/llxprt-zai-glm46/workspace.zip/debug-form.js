const express = require('express');
const path = require('path');

const app = express();

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src', 'templates'));

app.get('/test', (req, res) => {
  console.log('Rendering form template...');
  console.log('Views directory:', app.get('views'));
  
  res.render('form', {
    errors: {},
    formData: {},
    title: 'International Contact Form'
  }, (err, html) => {
    if (err) {
      console.error('Template error:', err);
      return res.status(500).send('Template error: ' + err.message);
    }
    console.log('Template rendered successfully');
    console.log('HTML preview:', html.substring(0, 200));
    res.send(html);
  });
});

app.listen(3000, () => {
  console.log('Debug server running on port 3000');
  console.log('Visit http://localhost:3000/test');
});