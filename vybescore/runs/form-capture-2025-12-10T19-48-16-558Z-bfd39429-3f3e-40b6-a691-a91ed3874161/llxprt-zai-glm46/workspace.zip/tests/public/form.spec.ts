import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import app from '../../src/test-server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
    
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Street address');
    expect(response.text).toContain('City');
    expect(response.text).toContain('State / Province / Region');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
    expect(response.text).toContain('name="firstName"');
    expect(response.text).toContain('name="lastName"');
    expect(response.text).toContain('name="streetAddress"');
    expect(response.text).toContain('name="city"');
    expect(response.text).toContain('name="stateProvince"');
    expect(response.text).toContain('name="postalCode"');
    expect(response.text).toContain('name="country"');
    expect(response.text).toContain('name="email"');
    expect(response.text).toContain('name="phone"');
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database file
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Wait a moment for file system operations
    await new Promise(resolve => setTimeout(resolve, 100));
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Test successful form submission
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify the database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Test the thank you page
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);
    
    expect(thankYouResponse.text).toContain('Thank You!');
    expect(thankYouResponse.text).toContain('Congratulations');
    expect(thankYouResponse.text).toContain('personal information');
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({})
      .expect(200);
    
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Street address is required');
  });

  it('validates email format', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'invalid-email',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(200);
    
    expect(response.text).toContain('Please enter a valid email address');
  });

  it('validates phone format', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: 'invalid-phone-with-symbols!'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(200);
    
    expect(response.text).toContain('Please enter a valid phone number');
  });

  it('accepts international phone formats', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });

  it('accepts various postal code formats', async () => {
    const formData = {
      firstName: 'Carlos',
      lastName: 'García',
      streetAddress: '789 Pine St',
      city: 'Buenos Aires',
      stateProvince: 'Capital Federal',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos.garcia@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });
});