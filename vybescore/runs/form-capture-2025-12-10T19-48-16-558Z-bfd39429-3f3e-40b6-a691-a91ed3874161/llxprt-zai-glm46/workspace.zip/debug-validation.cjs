const express = require('express');
const path = require('path');

// Create a mini app to test validation
const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'src/templates'));

// Validation functions
function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone) {
  // More permissive phone validation that accepts international formats
  const phoneRegex = /^[\d\s\-\+\(\)]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode) {
  // Simple validation for postal codes
  const postalCodeRegex = /^[a-zA-Z0-9\s\-]+$/;
  return postalCodeRegex.test(postalCode);
}

// Helper function to get human-readable field names
function getHumanReadableFieldName(field) {
  const fieldNames = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State/province',
    postalCode: 'Postal code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone'
  };
  
  return fieldNames[field] || field.charAt(0).toUpperCase() + field.slice(1);
}

function validateForm(formData) {
  const errors = [];
  const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  // Check required fields
  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors.push({
        field,
        message: `${getHumanReadableFieldName(field)} is required`
      });
    }
  }
  
  // Email validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }
  
  // Phone validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }
  
  // Postal code validation
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }
  
  return errors;
}

app.post('/submit', (req, res) => {
  console.log('Received POST request to /submit');
  console.log('Request body:', req.body);
  
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  console.log('Form data:', formData);
  
  const errors = validateForm(formData);
  console.log('Validation errors:', errors);
  
  if (errors.length > 0) {
    const errorsObj = {};
    errors.forEach(error => {
      errorsObj[error.field] = error.message;
    });
    
    console.log('Errors object:', errorsObj);
    
    res.status(200).render('form', {
      errors: errorsObj,
      formData,
      title: 'International Contact Form'
    });
  } else {
    console.log('Validation passed, redirecting to /thank-you');
    res.redirect('/thank-you');
  }
});

const PORT = 3536;
app.listen(PORT, () => {
  console.log(`Debug server running on http://localhost:${PORT}`);
});