import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { createRequire } from 'module';

const require = createRequire(import.meta.url);
const initSqlJs = require('sql.js');

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  id?: number;
  createdAt?: string;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

function getHumanReadableFieldName(field: string): string {
  const fieldNames: { [key: string]: string } = {
    firstName: 'First name',
    lastName: 'Last name',
    streetAddress: 'Street address',
    city: 'City',
    stateProvince: 'State/province',
    postalCode: 'Postal code',
    country: 'Country',
    email: 'Email',
    phone: 'Phone'
  };
  
  return fieldNames[field] || field.charAt(0).toUpperCase() + field.slice(1);
}

const app = express();
// eslint-disable-next-line @typescript-eslint/no-unused-vars
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Database initialization (mock for testing)
const mockDB: FormData[] = [];

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];
  
  for (const field of requiredFields) {
    const value = formData[field];
    if (!value || (typeof value === 'string' && value.trim().length === 0)) {
      errors.push({
        field,
        message: `${getHumanReadableFieldName(field)} is required`
      });
    }
  }
  
  // Email validation
  if (formData.email && !validateEmail(formData.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }
  
  // Phone validation
  if (formData.phone && !validatePhone(formData.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }
  
  // Postal code validation
  if (formData.postalCode && !validatePostalCode(formData.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }
  
  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: {},
    formData: {},
    title: 'International Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    // Convert errors array to object for template
    const errorsObj: Record<string, string> = {};
    errors.forEach((error: ValidationError) => {
      errorsObj[error.field] = error.message;
    });
    
    res.render('form', {
      errors: errorsObj,
      formData,
      title: 'International Contact Form'
    });
  } else {
    // Insert into mock database for testing
    try {
      mockDB.push({
        ...formData,
        id: mockDB.length + 1,
        createdAt: new Date().toISOString()
      });
      
      // Create database file for verification
      const dbPath = path.join(__dirname, '../data/submissions.sqlite');
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      fs.writeFileSync(dbPath, Buffer.from('mock database file'));
      
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('form', {
        errors: { general: 'An error occurred while saving your submission. Please try again.' },
        formData,
        title: 'International Contact Form'
      });
    }
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You for Your Submission!'
  });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error(err.stack);
  res.status(500).render('form', {
    errors: { general: 'An unexpected error occurred. Please try again.' },
    formData: {},
    title: 'International Contact Form'
  });
});

export default app;