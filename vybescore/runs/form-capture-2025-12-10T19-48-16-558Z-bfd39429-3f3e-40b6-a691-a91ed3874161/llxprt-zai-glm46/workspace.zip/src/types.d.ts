// TypeScript declarations for sql.js
declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    exec(sql: string): unknown;
    prepare(sql: string): unknown;
    export(): Uint8Array;
    close(): void;
  }
}

// Make the module work with both require and import
declare module 'sql.js' {
  function initSqlJs(options?: Record<string, unknown>): Promise<{
    Database: typeof Database;
  }>;
  
  const sqljs: {
    Database: typeof Database;
    initSqlJs: typeof initSqlJs;
  };
  export = sqljs;
}