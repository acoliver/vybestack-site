const express = require('express');
const path = require('path');
const fs = require('fs');
const ejs = require('ejs');
const { initSqlJs } = require('sql.js');

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db;
async function initializeDatabase() {
  try {
    const SQL = await initSqlJs();
    
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const dataDir = path.dirname(dbPath);
    
    // Ensure data directory exists
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Load or create database
    let dbData = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }
    
    db = new SQL.Database(dbData);
    
    // Create table if it doesn't exist
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.exec(schema);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to file
function saveDatabase() {
  try {
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email) {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone) {
  const phoneRegex = /^[+]?\d[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode) {
  const postalRegex = /^[a-zA-Z0-9\s\-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(data) {
  const errors = [];

  // Required field validation
  if (!data.firstName?.trim()) errors.push('First name is required');
  if (!data.lastName?.trim()) errors.push('Last name is required');
  if (!data.streetAddress?.trim()) errors.push('Street address is required');
  if (!data.city?.trim()) errors.push('City is required');
  if (!data.stateProvince?.trim()) errors.push('State/Province/Region is required');
  if (!data.postalCode?.trim()) errors.push('Postal/Zip code is required');
  if (!data.country?.trim()) errors.push('Country is required');
  if (!data.email?.trim()) errors.push('Email is required');
  if (!data.phone?.trim()) errors.push('Phone number is required');

  // Format validation
  if (data.email && !validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (data.phone && !validatePhone(data.phone)) {
    errors.push('Please enter a valid phone number (digits, spaces, parentheses, dashes, and optional leading + are allowed)');
  }

  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push('Please enter a valid postal/zip code (letters, numbers, spaces, and dashes are allowed)');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req, res) => {
  const formData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.render('form', {
      errors: validation.errors,
      values: formData
    });
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  // For this demo, we'll just use a generic name since we're not storing session data
  res.render('thank-you', { firstName: 'friend' });
});

// Graceful shutdown
function gracefulShutdown(signal) {
  console.log(`\nReceived ${signal}. Starting graceful shutdown...`);
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed.');
      if (db) {
        db.close();
        console.log('Database closed.');
      }
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
}

// Start server
let server;
async function startServer() {
  try {
    await initializeDatabase();
    
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();