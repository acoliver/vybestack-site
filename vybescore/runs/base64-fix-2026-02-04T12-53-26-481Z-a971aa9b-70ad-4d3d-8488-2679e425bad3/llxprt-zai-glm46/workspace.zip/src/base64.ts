/**
 * Validate that a string contains only valid Base64 characters.
 * Base64 alphabet: A-Z, a-z, 0-9, +, /, with optional padding (=)
 */
function isValidBase64(input: string): boolean {
  // Base64 with padding: ^[A-Za-z0-9+/]+={0,2}$
  // Base64 without padding: ^[A-Za-z0-9+/]+$
  const base64Pattern = /^[A-Za-z0-9+/]+={0,2}$/;
  
  // Check if it matches the basic pattern
  if (!base64Pattern.test(input)) {
    return false;
  }
  
  // Validate padding rules:
  // - Padding can only appear at the end
  // - Can have 0, 1, or 2 padding characters
  // - If 1 padding char, string length (without padding) must be divisible by 4 with remainder 3
  // - If 2 padding chars, string length (without padding) must be divisible by 4 with remainder 2
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    const unpaddedLength = input.length - paddingLength;
    
    if (paddingLength > 2) {
      return false;
    }
    
    const remainder = unpaddedLength % 4;
    if (paddingLength === 1 && remainder !== 3) {
      return false;
    }
    if (paddingLength === 2 && remainder !== 2) {
      return false;
    }
  }
  
  // Check for non-canonical padding (padding in the middle)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Ensure all padding is at the end
    const paddingOnly = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingOnly)) {
      return false;
    }
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using standard Base64 alphabet.
 * Output includes padding characters (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Rejects invalid Base64 payloads by throwing an error.
 */
export function decode(input: string): string {
  // Trim whitespace
  const trimmed = input.trim();
  
  // Validate the input contains only valid Base64 characters
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Verify the buffer is not empty (which would happen for invalid input)
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
