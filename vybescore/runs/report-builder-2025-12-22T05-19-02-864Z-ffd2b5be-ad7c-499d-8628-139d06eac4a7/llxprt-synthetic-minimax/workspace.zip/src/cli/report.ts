#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): { dataPath: string; options: CliOptions } {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = argv[2];
  const args = argv.slice(3);

  let format: 'markdown' | 'text' | null = null;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const formatValue = args[i + 1];
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Error: Unsupported format '${formatValue}'. Supported formats: markdown, text`);
        process.exit(1);
      }
      format = formatValue as 'markdown' | 'text';
      i++; // Skip the next argument as it's the format value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip the next argument as it's the output path
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataPath,
    options: { format, outputPath, includeTotals }
  };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Report data must be a JSON object');
    return false;
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string') {
    console.error('Error: Report data missing required field "title" (string)');
    return false;
  }

  if (typeof reportData.summary !== 'string') {
    console.error('Error: Report data missing required field "summary" (string)');
    return false;
  }

  if (!Array.isArray(reportData.entries)) {
    console.error('Error: Report data missing required field "entries" (array)');
    return false;
  }

  for (let i = 0; i < reportData.entries.length; i++) {
    const entry = reportData.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${i} must be an object`);
      return false;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Entry at index ${i} missing required field "label" (string)`);
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Entry at index ${i} missing required field "amount" (number)`);
      return false;
    }
  }

  return true;
}

function main(): void {
  try {
    const { dataPath, options } = parseArguments(process.argv);

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(dataPath, 'utf8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File '${dataPath}' not found`);
      } else {
        console.error('Error: Failed to read or parse JSON file');
      }
      process.exit(1);
    }

    // Validate report data
    if (!validateReportData(jsonData)) {
      process.exit(1);
    }

    const reportData: ReportData = jsonData as ReportData;

    // Generate output
    let output: string;
    if (options.format === 'markdown') {
      output = renderMarkdown(reportData, options);
    } else {
      output = renderText(reportData, options);
    }

    // Write output
    if (options.outputPath) {
      try {
        writeFileSync(options.outputPath, output);
      } catch (error) {
        console.error(`Error: Failed to write output file '${options.outputPath}'`);
        process.exit(1);
      }
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error('Error: Unexpected error occurred');
    process.exit(1);
  }
}

main();
