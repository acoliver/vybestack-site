/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/* eslint-disable @typescript-eslint/no-explicit-any */
// Store multiple observers for each subject
const subjectObservers = new WeakMap<any, Set<any>>()
/* eslint-enable @typescript-eslint/no-explicit-any */

function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (a: T, b: T) => a === b : undefined
  }
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: createEqualFn(equal),
  }

  // Initialize observers set for this subject
  subjectObservers.set(s, new Set())

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Add to our multi-observer set
      const observers = subjectObservers.get(s)
      if (observers) {
        /* eslint-disable @typescript-eslint/no-explicit-any */
        observers.add(observer as any)
        /* eslint-enable @typescript-eslint/no-explicit-any */
      }
      // Also maintain the legacy single observer for compatibility
      /* eslint-disable @typescript-eslint/no-explicit-any */
      s.observer = observer as any
      /* eslint-enable @typescript-eslint/no-explicit-any */
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      
      // Notify all observers from our multi-observer set
      const observers = subjectObservers.get(s)
      if (observers) {
        for (const obs of observers) {
          /* eslint-disable @typescript-eslint/no-explicit-any */
          updateObserver(obs as any)
          /* eslint-enable @typescript-eslint/no-explicit-any */
        }
      }
      
      // Also notify legacy single observer for compatibility
      if (s.observer) {
        const observers = subjectObservers.get(s)
        if (!observers || !observers.has(s.observer as Observer<unknown>)) {
          /* eslint-disable @typescript-eslint/no-explicit-any */
          updateObserver(s.observer as any)
          /* eslint-enable @typescript-eslint/no-explicit-any */
        }
      }
    }
    return s.value
  }

  return [read, write]
}
