/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/* eslint-disable @typescript-eslint/no-explicit-any */
// Store observers for computed values
const computedObservers = new WeakMap<any, Set<any>>()
/* eslint-enable @typescript-eslint/no-explicit-any */

function _createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (a: T, b: T) => a === b : undefined
  }
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = _createEqualFn(equal)
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Initialize observers set for this computed value
  computedObservers.set(observer, new Set())

  const getter: GetterFn<T> = () => {
    // Register this computed value as an observer for any dependencies
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add the active observer to our computed's observers list
      const observers = computedObservers.get(observer)
      if (observers) {
        /* eslint-disable @typescript-eslint/no-explicit-any */
        observers.add(activeObserver as any)
        /* eslint-enable @typescript-eslint/no-explicit-any */
      }
      // Also maintain legacy observer for compatibility
      /* eslint-disable @typescript-eslint/no-explicit-any */
      (observer as any).observer = activeObserver
      /* eslint-enable @typescript-eslint/no-explicit-any */
    }
    
    return observer.value!
  }

  // Override the observer's update function to handle equality checks and notify observers
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    const hasChanged = !equalFn || !prevValue || !equalFn(prevValue, newValue)
    
    if (hasChanged) {
      observer.value = newValue
      
      // Notify all observers of this computed value
      const observers = computedObservers.get(observer)
      if (observers) {
        for (const obs of observers) {
          /* eslint-disable @typescript-eslint/no-explicit-any */
          updateObserver(obs as any)
          /* eslint-enable @typescript-eslint/no-explicit-any */
        }
      }
      
      // Also notify legacy observer
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const legacyObserver = (observer as any).observer
      if (legacyObserver) {
        const observers = computedObservers.get(observer)
        if (!observers || !observers.has(legacyObserver)) {
          /* eslint-disable @typescript-eslint/no-explicit-any */
          updateObserver(legacyObserver as any)
          /* eslint-enable @typescript-eslint/no-explicit-any */
        }
      }
    }
    
    return observer.value!
  }

  // Initial computation - this will register dependencies
  updateObserver(observer)

  return getter
}