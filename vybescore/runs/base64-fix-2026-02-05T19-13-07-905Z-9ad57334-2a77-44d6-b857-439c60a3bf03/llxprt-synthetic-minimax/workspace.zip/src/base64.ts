/**
 * Encode plain text to Base64 using standard Base64 encoding.
 * Returns the canonical Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input and handles missing padding.
 */
export function decode(input: string): string {
  // Normalize input: handle URL-safe characters
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');
  
  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Add missing padding if necessary
  let paddedInput = normalized;
  const missingPadding = 4 - (normalized.length % 4);
  if (missingPadding < 4 && !normalized.endsWith('=')) {
    // Only add padding if we have a partial block and no existing padding
    paddedInput = normalized + '='.repeat(missingPadding % 4);
  }

  try {
    const decoded = Buffer.from(paddedInput, 'base64').toString('utf8');
    // Additional validation: check if the result contains only valid UTF-8
    if (decoded && decoded.length > 0) {
      return decoded;
    }
    throw new Error('Decoding resulted in empty or invalid UTF-8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
