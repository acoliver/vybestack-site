#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, CliOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): { dataFile: string; options: CliOptions } {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  const args = argv.slice(3);
  
  let format: 'markdown' | 'text' | undefined;
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const formatValue = args[i + 1];
      if (!formatValue) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      if (formatValue !== 'markdown' && formatValue !== 'text') {
        console.error(`Unsupported format: ${formatValue}`);
        process.exit(1);
      }
      format = formatValue;
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output') {
      const outputValue = args[i + 1];
      if (!outputValue) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      output = outputValue;
      i++; // Skip next argument as it's the output value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, options: { format, output, includeTotals } };
}

function loadReportData(filePath: string): ReportData {
  try {
    const rawData = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(rawData);
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label must be a string`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entries[${i}].amount must be a number`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: Cannot read file '${filePath}'`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error(`Error: Failed to parse JSON from '${filePath}'`);
    }
    process.exit(1);
  }
}

function main(): void {
  const { dataFile, options } = parseArgs(process.argv);
  const reportData = loadReportData(dataFile);
  
  let output: string;
  if (options.format === 'markdown') {
    output = renderMarkdown(reportData, { includeTotals: options.includeTotals });
  } else {
    output = renderText(reportData, { includeTotals: options.includeTotals });
  }
  
  if (options.output) {
    try {
      writeFileSync(options.output, output);
    } catch (error) {
      console.error(`Error: Failed to write to '${options.output}'`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();