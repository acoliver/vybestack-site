import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT || '3535';
const DB_PATH = path.join(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(process.cwd(), 'db', 'schema.sql');

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: Record<string, string>;
}

const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Determine paths based on environment (dev vs compiled)
const isDev = process.env.NODE_ENV !== 'production';
const publicPath = isDev
  ? path.join(__dirname, '..', 'public')
  : path.join(__dirname, 'public');
const viewsPath = isDev
  ? path.join(__dirname, 'views')
  : path.join(__dirname, 'views');

app.use(express.static(publicPath));

app.set('view engine', 'ejs');
app.set('views', viewsPath);

let db: Database | null = null;

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  const phoneRegex = /^[+]?[(]?\d[\d()\s-]*\d$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function isValidPostalCode(code: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(code) && code.trim().length >= 3;
}

function validateSubmission(data: Submission): ValidationResult {
  const errors: Record<string, string> = {};

  if (!data.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }

  if (!data.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }

  if (!data.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }

  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }

  if (!data.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }

  if (!data.postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  } else if (!isValidPostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal code';
  }

  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }

  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}

async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  try {
    const fs = await import('fs');
    let dbData: Uint8Array | null = null;

    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      dbData = new Uint8Array(fileBuffer);
    }

    db = new SQL.Database(dbData ?? undefined);

    if (!fs.existsSync(DB_PATH)) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      const currentDb = db;
      if (currentDb) {
        currentDb.run(schema);
      }
      await saveDatabase();
      console.log('Database initialized with schema');
    }
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}

async function saveDatabase(): Promise<void> {
  if (!db) return;

  try {
    const fs = await import('fs');
    const data = db.export();
    const buffer = Buffer.from(data);
    
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(DB_PATH, buffer);
  } catch (error) {
    console.error('Error saving database:', error);
    throw error;
  }
}

function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: {},
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const submission: Submission = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateSubmission(submission);

  if (!validation.valid) {
    return res.status(400).render('index', {
      errors: validation.errors,
      formData: submission
    });
  }

  try {
    const currentDb = db;
    if (!currentDb) {
      throw new Error('Database not initialized');
    }

    const now = new Date().toISOString();
    currentDb.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone,
        now
      ]
    );

    saveDatabase().catch(err => console.error('Failed to save database:', err));

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error inserting submission:', error);
    res.status(500).render('index', {
      errors: { _form: 'An error occurred while processing your submission' },
      formData: submission
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

async function startServer(): Promise<void> {
  await initDatabase();

  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  const gracefulShutdown = (signal: string) => {
    console.log(`Received ${signal}, shutting down gracefully...`);
    server.close(() => {
      console.log('HTTP server closed');
      closeDatabase();
      console.log('Database closed');
      process.exit(0);
    });

    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      closeDatabase();
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Only start server if this file is run directly (not when imported in tests)
if (import.meta.url === `file://${process.argv[1]}` || import.meta.url === `file://${path.resolve(process.argv[1])}`) {
  startServer().catch(err => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

export { app, initDatabase, saveDatabase, closeDatabase };
