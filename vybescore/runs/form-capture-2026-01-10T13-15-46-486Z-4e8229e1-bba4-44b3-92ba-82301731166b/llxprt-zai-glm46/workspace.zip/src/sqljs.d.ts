declare module 'sql.js' {
  export interface SqlJsStatic {
    Database: typeof Database;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): unknown;
    exec(sql: string): unknown[];
    export(): Uint8Array;
    close(): void;
  }

  export default function initSqlJs(config?: unknown): Promise<SqlJsStatic>;
}
