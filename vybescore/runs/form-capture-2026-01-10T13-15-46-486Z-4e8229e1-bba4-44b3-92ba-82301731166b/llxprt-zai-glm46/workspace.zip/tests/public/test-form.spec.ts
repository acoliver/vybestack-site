import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { app, initDatabase, closeDatabase } from '../../dist/server.js';

describe('Form Endpoints', () => {
  beforeAll(async () => {
    await initDatabase();
  });

  afterAll(() => {
    closeDatabase();
  });

  describe('GET /', () => {
    it('should render the form page', async () => {
      const response = await request(app).get('/');
      
      expect(response.status).toBe(200);
      expect(response.text).toContain('Friendly International Contact Form');
      expect(response.text).toContain('first_name');
      expect(response.text).toContain('last_name');
      expect(response.text).toContain('email');
      expect(response.text).toContain('phone');
    });

    it('should have proper label associations', async () => {
      const response = await request(app).get('/');
      
      expect(response.text).toMatch(/for="first_name"/);
      expect(response.text).toMatch(/id="first_name"/);
      expect(response.text).toMatch(/name="first_name"/);
    });
  });

  describe('POST /submit', () => {
    const validSubmission = {
      first_name: 'John',
      last_name: 'Doe',
      street_address: '123 Main Street',
      city: 'London',
      state_province: 'England',
      postal_code: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };

    it('should accept valid international phone numbers', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          phone: '+54 9 11 1234-5678'
        });
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should accept valid UK postal codes', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          postal_code: 'SW1A 1AA'
        });
      
      expect(response.status).toBe(302);
    });

    it('should accept alphanumeric postal codes', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          postal_code: 'C1000'
        });
      
      expect(response.status).toBe(302);
    });

    it('should redirect to thank-you on successful submission', async () => {
      const response = await request(app)
        .post('/submit')
        .send(validSubmission);
      
      expect(response.status).toBe(302);
      expect(response.headers.location).toBe('/thank-you');
    });

    it('should reject empty required fields', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: '',
          last_name: 'Doe',
          street_address: '123 Main Street',
          city: 'London',
          state_province: 'England',
          postal_code: 'SW1A 1AA',
          country: 'United Kingdom',
          email: 'john@example.com',
          phone: '+44 20 7946 0958'
        });
      
      expect(response.status).toBe(400);
      expect(response.text).toContain('First name is required');
    });

    it('should reject invalid email addresses', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          email: 'not-an-email'
        });
      
      expect(response.status).toBe(400);
      expect(response.text).toContain('valid email');
    });

    it('should reject invalid phone numbers', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          phone: 'abc'
        });
      
      expect(response.status).toBe(400);
      expect(response.text).toContain('valid phone');
    });

    it('should reject invalid postal codes', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          postal_code: '@#$%'
        });
      
      expect(response.status).toBe(400);
      expect(response.text).toContain('valid postal');
    });

    it('should preserve form values on validation error', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          first_name: 'Jane',
          last_name: '',
          street_address: '456 Oak Avenue',
          city: 'Paris',
          state_province: 'Île-de-France',
          postal_code: '75001',
          country: 'France',
          email: 'jane@example.com',
          phone: '+33 1 42 86 83 26'
        });
      
      expect(response.status).toBe(400);
      expect(response.text).toContain('Jane');
      expect(response.text).toContain('456 Oak Avenue');
    });

    it('should accept phone with spaces and dashes', async () => {
      const response = await request(app)
        .post('/submit')
        .send({
          ...validSubmission,
          phone: '+1 (555) 123-4567'
        });
      
      expect(response.status).toBe(302);
    });
  });

  describe('GET /thank-you', () => {
    it('should render the thank-you page', async () => {
      const response = await request(app).get('/thank-you');
      
      expect(response.status).toBe(200);
      expect(response.text).toContain('Thank You');
      expect(response.text.toLowerCase()).toContain('spam');
    });

    it('should have link back to form', async () => {
      const response = await request(app).get('/thank-you');
      
      expect(response.text).toContain('href="/"');
    });
  });
});
