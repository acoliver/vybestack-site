import express, { Request, Response } from 'express';
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

let db: Database | null = null;
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

app.set('view engine', 'ejs');
const viewsPath = process.env.NODE_ENV === 'production' 
  ? path.join(__dirname, 'templates')
  : path.join(__dirname, 'templates');
app.set('views', viewsPath);

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[(]?\d+[)]?[-\s\d]*$/;
  return phoneRegex.test(phone.trim());
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  const trimmed = postalCode.trim();
  return trimmed.length > 0 && postalRegex.test(trimmed);
}

function validateForm(values: FormValues): string[] {
  const errors: string[] = [];

  if (!values.firstName?.trim()) {
    errors.push('First name is required.');
  }
  if (!values.lastName?.trim()) {
    errors.push('Last name is required.');
  }
  if (!values.streetAddress?.trim()) {
    errors.push('Street address is required.');
  }
  if (!values.city?.trim()) {
    errors.push('City is required.');
  }
  if (!values.stateProvince?.trim()) {
    errors.push('State / Province / Region is required.');
  }
  if (!values.postalCode?.trim()) {
    errors.push('Postal / Zip code is required.');
  } else if (!validatePostalCode(values.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens.');
  }
  if (!values.country?.trim()) {
    errors.push('Country is required.');
  }
  if (!values.email?.trim()) {
    errors.push('Email is required.');
  } else if (!validateEmail(values.email)) {
    errors.push('Please enter a valid email address.');
  }
  if (!values.phone?.trim()) {
    errors.push('Phone number is required.');
  } else if (!validatePhone(values.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +.');
  }

  return errors;
}

app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(values);

  if (errors.length > 0) {
    res.status(400).render('form', { errors, values });
    return;
  }

  if (!db) {
    errors.push('Database not initialized. Please try again.');
    res.status(500).render('form', { errors, values });
    return;
  }

  try {
    const now = new Date().toISOString();
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        values.firstName.trim(),
        values.lastName.trim(),
        values.streetAddress.trim(),
        values.city.trim(),
        values.stateProvince.trim(),
        values.postalCode.trim(),
        values.country.trim(),
        values.email.trim(),
        values.phone.trim(),
        now,
      ]
    );

    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);

    res.redirect(302, '/thank-you');
  } catch (error) {
    errors.push('An error occurred while saving your submission. Please try again.');
    res.status(500).render('form', { errors, values });
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', { firstName: 'Friend' });
});

async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, buffer);
  }
}

let server: ReturnType<typeof app.listen>;

export async function start(): Promise<typeof app> {
  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

  return new Promise((resolve) => {
    server = app.listen(port, () => {
      resolve(app);
    });
  });
}

export function stop(): void {
  if (db) {
    db.close();
    db = null;
  }
  if (server) {
    server.close();
  }
}

process.on('SIGTERM', () => {
  stop();
  process.exit(0);
});

if (import.meta.url === `file://${process.argv[1]}`) {
  start().then(() => {
    const port = process.env.PORT || 3535;
    console.log(`Server running on http://localhost:${port}`);
  });
}
