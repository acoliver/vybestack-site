import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import { start, stop } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await start();
});

afterAll(() => {
  stop();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    expect(true).toBe(true);
  });
});
