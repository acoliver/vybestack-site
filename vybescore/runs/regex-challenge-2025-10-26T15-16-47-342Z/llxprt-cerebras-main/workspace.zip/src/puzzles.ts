/**
 * Finds words beginning with the prefix but excluding the listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex that matches words beginning with the prefix
  // \b ensures we match complete words
  const regex = new RegExp(`\\b${prefix}\\w*`, 'gi');
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Finds occurrences where the token appears after a digit and not at the start of the string
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex that uses positive lookbehind to ensure the token appears after a digit
  // and negative lookahead to ensure it's not at the start of the string
  const regex = new RegExp(`(?<=\\d)${token}`, 'gi');
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * Validates passwords according to the policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length and no whitespace
  if (value.length < 10 || /\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  
  if (!(hasUpper && hasLower && hasDigit && hasSymbol)) {
    return false;
  }
  
  // Check for repeated immediate sequences (like abab)
  // This regex looks for any sequence of 2 or more characters that immediately repeats
  const repeatedSequenceRegex = /(.{2,})\1/;
  return !repeatedSequenceRegex.test(value);
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern
  // Covers full IPv6 addresses and compressed (::) versions
  const ipv6Regex = /(?:(?:^|:)(?:[0-9a-f]{1,4})){1,8}(?:::)?(?:[0-9a-f]{1,4})(?:\/\d{1,3})?/gi;
  
  // IPv4 regex pattern for exclusion
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if value contains IPv6 but not IPv4
  return ipv6Regex.test(value) && !ipv4Regex.test(value);
}