export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern matching
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Email regex that ensures:
  // - No double dots or trailing dots in local part
  // - Domain parts don't start or end with hyphens or dots
  // - No underscores in domain part
  // - Valid TLD with at least 2 characters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for double dots or trailing dots in local part
  if (value.includes('..') || value.endsWith('.')) {
    return false;
  }
  
  // Check if there's underscore in domain part
  const domainPart = value.split('@')[1];
  if (domainPart && domainPart.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers with support for different formats
 * Supports (212) 555-7890, 212-555-7890, 2125557890 formats
 * Optional +1 prefix, disallows impossible area codes (leading 0/1)
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except + at the beginning
  const cleaned = value.replace(/(?!^\+)[^\d]/g, '');
  
  // Check if it starts with +1 and remove it
  let phone = cleaned;
  if (cleaned.startsWith('+1')) {
    phone = cleaned.substring(2);
  }
  
  // Area code cannot start with 0 or 1
  if (phone.length !== 10 || phone[0] === '0' || phone[0] === '1') {
    return false;
  }
  
  // Valid 10-digit phone number
  return true;
}

/**
 * Validates Argentine phone numbers
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens and other non-digit characters except + at the beginning
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Define possible patterns
  // Pattern 1: +5491112345678 (mobile with country code)
  // Pattern 2: +543411234567 (landline with country code)
  // Pattern 3: 01112345678 (mobile with trunk prefix) - Buenos Aires
  // Pattern 4: 03414234567 (landline with trunk prefix)
  
  // Check for patterns with country code
  if (cleaned.startsWith('+54')) {
    const withoutCountryCode = cleaned.substring(3);
    
    // Pattern for mobile numbers (with 9)
    if (withoutCountryCode.startsWith('9')) {
      const rest = withoutCountryCode.substring(1);
      // Area code must be 2-4 digits (1-9) + subscriber number (6-8 digits)
      if (rest.length >= 8 && rest.length <= 12) {
        const areaCodeLength = rest.length <= 10 ? 2 : (rest.length === 11 ? 3 : 4);
        const areaCode = rest.substring(0, areaCodeLength);
        const subscriber = rest.substring(areaCodeLength);
        
        // Area code must start with 1-9
        if (areaCode[0] === '0') return false;
        
        // Subscriber number must be 6-8 digits
        return subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber);
      }
    } 
    // Pattern for landline numbers (without 9)
    else if (withoutCountryCode.length >= 7 && withoutCountryCode.length <= 11) {
      const areaCodeLength = withoutCountryCode.length <= 9 ? 2 : (withoutCountryCode.length === 10 ? 3 : 4);
      const areaCode = withoutCountryCode.substring(0, areaCodeLength);
      const subscriber = withoutCountryCode.substring(areaCodeLength);
      
      // Area code must start with 1-9
      if (areaCode[0] === '0') return false;
      
      // Subscriber number must be 6-8 digits
      return subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber);
    }
  }
  
  // Check for patterns with trunk prefix
  if (cleaned.startsWith('0')) {
    const withoutTrunk = cleaned.substring(1);
    
    // Pattern for mobile numbers (with 9)
    if (withoutTrunk.startsWith('9')) {
      const rest = withoutTrunk.substring(1);
      if (rest.length >= 8 && rest.length <= 12) {
        const areaCodeLength = rest.length <= 10 ? 2 : (rest.length === 11 ? 3 : 4);
        const areaCode = rest.substring(0, areaCodeLength);
        const subscriber = rest.substring(areaCodeLength);
        
        // Area code must start with 1-9
        if (areaCode[0] === '0') return false;
        
        // Subscriber number must be 6-8 digits
        return subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber);
      }
    }
    // Pattern for landline numbers (without 9)
    else if (withoutTrunk.length >= 7 && withoutTrunk.length <= 11) {
      const areaCodeLength = withoutTrunk.length <= 9 ? 2 : (withoutTrunk.length === 10 ? 3 : 4);
      const areaCode = withoutTrunk.substring(0, areaCodeLength);
      const subscriber = withoutTrunk.substring(areaCodeLength);
      
      // Area code must start with 1-9
      if (areaCode[0] === '0') return false;
      
      // Subscriber number must be 6-8 digits
      return subscriber.length >= 6 && subscriber.length <= 8 && /^\d+$/.test(subscriber);
    }
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // A valid name can contain Unicode letters, hyphens, apostrophes, and spaces
  // but shouldn't contain digits or special symbols
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Check if the value contains any digits or symbols that aren't hyphens or apostrophes
  return nameRegex.test(value) && !/[\d!@#$%^&*()_=+\[\]{}\\|;:"<>,.\/?`~]/.test(value);
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum)
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any spaces or dashes from the input
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if the string only contains digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 5[1-5], length 16
  // Amex: starts with 34 or 37, length 15
  const visaRegex = /^4\d{12}(\d{3})?(\d{3})?$/;
  const mastercardRegex = /^5[1-5]\d{14}$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the card patterns
  if (!(visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned))) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to run Luhn algorithm checksum on credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}