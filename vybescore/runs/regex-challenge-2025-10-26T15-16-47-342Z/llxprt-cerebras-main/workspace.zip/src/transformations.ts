/**
 * Capitalizes the first character of each sentence, preserving spacing rules
 * Inserts exactly one space between sentences even if input omitted it
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, let's handle sentence endings followed by spaces/newlines and then letters
  // This regex captures sentence-ending punctuation and the following character(s)
  return text.replace(/([.?!])\s*([a-z])/g, (match, p1, p2) => {
    return p1 + ' ' + p2.toUpperCase();
  })
  // Capitalize the first letter of the text
  .replace(/^([a-z])/, (match) => match.toUpperCase())
  // Collapse multiple spaces into single spaces
  .replace(/\s+/g, ' ')
  // Ensure there's exactly one space after sentence-ending punctuation
  .replace(/([.?!])([^\s.?!])/g, '$1 $2');
}

/**
 * Extracts URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL regex that matches http:// or https:// URLs
  // Handles domains, ports, paths, query parameters, and fragments
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w\/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?/gi;
  const matches = text.match(urlRegex);
  return matches ? matches.map(url => url.replace(/[.!?]+$/, '')) : [];
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace all instances of 'http://' with 'https://'
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/
 * when applicable
 */
export function rewriteDocsUrls(text: string): string {
  // Replace http:// with https:// and rewrite host when path begins with /docs/
  // but skip host rewrite when path contains dynamic hints
  return text.replace(/http:\/\/([\w.-]+)(\/[^\s]*)?/gi, (match, host, path = '/') => {
    // Upgrade scheme to https
    let newUrl = `https://${host}${path}`;
    
    // Check if we should rewrite the host
    const skipRewritePatterns = [
      /cgi-bin/i,
      /[?&=]/,  // Query strings
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    const shouldSkipRewrite = skipRewritePatterns.some(pattern => pattern.test(path));
    
    // Rewrite host if path starts with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/') && !shouldSkipRewrite) {
      newUrl = `https://docs.${host}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format where month is 1-12 and day is 1-31
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (match) {
    return match[3]; // Return the year part
  }
  
  return 'N/A';
}