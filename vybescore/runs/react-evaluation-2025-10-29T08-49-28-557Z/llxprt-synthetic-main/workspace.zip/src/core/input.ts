/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR,
  registerDependency,
  notifyDependents
} from '../types/reactive.js'

function _normalizeEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') return equal ? ((a: T, b: T): boolean => a === b) : undefined
  return equal
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Create a unique observer ID for this input
  const inputObserver: ObserverR = { name: options?.name }
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: _normalizeEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      
      // Track the dependency relationship
      registerDependency(observer, inputObserver)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (!shouldUpdate) return s.value
    
    s.value = nextValue
    
    // Notify all observers that depend on this input
    notifyDependents(inputObserver)
    
    return s.value
  }

  return [read, write]
}
