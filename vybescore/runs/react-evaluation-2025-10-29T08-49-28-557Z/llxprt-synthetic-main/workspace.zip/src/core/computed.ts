/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  registerDependency,
  notifyDependents,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a unique ID for this computed value
  const computedId: ObserverR = { name: options?.name }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // Register the active observer as dependent on this computed value
      registerDependency(activeObserver, computedId)
    }
    return o.value!
  }
  
  // Wrap updateFn to notify all dependents
  const originalUpdateFn = o.updateFn
  o.updateFn = (currentValue) => {
    const newValue = originalUpdateFn(currentValue)
    o.value = newValue
    
    // Notify all observers that depend on this computed value
    notifyDependents(computedId)
    
    return newValue
  }
  
  // Initialize the value
  updateObserver(o)
  
  return getter
}