/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getDependencyRegistry } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register dependencies and execute initially
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from dependency registry
    const registry = getDependencyRegistry()
    registry.delete(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}