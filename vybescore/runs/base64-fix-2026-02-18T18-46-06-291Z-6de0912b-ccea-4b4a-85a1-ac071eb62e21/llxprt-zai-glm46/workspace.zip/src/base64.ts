const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Check for valid Base64 characters
  if (!VALID_BASE64_REGEX.test(trimmed)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Add padding if needed (Buffer requires correct padding)
  const padded = padInput(trimmed);

  try {
    const result = Buffer.from(padded, 'base64').toString('utf8');
    
    // Verify the decoding was successful by checking if we get empty buffer
    // for invalid input that somehow passes the regex check
    if (trimmed.length > 0 && Buffer.from(padded, 'base64').length === 0 && !isAllPadding(trimmed)) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Add padding to Base64 input if it's missing.
 * Base64 padding must be 0, 1, or 2 '=' characters to make the length a multiple of 4.
 */
function padInput(input: string): string {
  const paddingLength = (4 - (input.length % 4)) % 4;
  return input + '='.repeat(paddingLength);
}

/**
 * Check if a string consists only of padding characters.
 */
function isAllPadding(input: string): boolean {
  return /^=*$/.test(input);
}
