const STANDARD_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

function isValidBase64(input: string): boolean {
  // Check only contains valid Base64 characters
  if (!STANDARD_BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Check for proper padding: if padding is present, it must be at the end
  // and the total length must be a multiple of 4
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end
    if (input.slice(paddingIndex) !== '='.repeat(input.length - paddingIndex)) {
      return false;
    }
    // With padding, length must be multiple of 4
    return input.length % 4 === 0;
  }
  
  // Without padding, let Buffer try to decode it to see if it's actually valid
  // This handles cases like "ab" which are technically valid but need proper length
  try {
    const decoded = Buffer.from(input, 'base64');
    return decoded.length > 0 || input.length % 4 === 0;
  } catch (error) {
    return false;
  }
}

/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
