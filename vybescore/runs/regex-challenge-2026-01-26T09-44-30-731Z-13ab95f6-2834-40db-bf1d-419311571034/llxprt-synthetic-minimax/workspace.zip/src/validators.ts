export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check basic format first
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots, trailing dots, domains with underscores
  if (value.includes('..') || value.endsWith('.') || value.includes('@_.') || /@[^.]*\.[^.]*_/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Remove + if present
  const phoneDigits = cleaned.replace(/^\+/, '');
  
  // Check for optional +1 prefix
  let checkNumber = phoneDigits;
  if (phoneDigits.startsWith('1') && phoneDigits.length === 11) {
    checkNumber = phoneDigits.substring(1);
  }
  
  // Must be 10 digits without country code
  if (checkNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) cannot start with 0 or 1
  const areaCode = parseInt(checkNumber.substring(0, 3));
  if (areaCode <= 100) {
    return false;
  }
  
  // Check format - must match common US patterns
  const usPhoneRegex = /^\+?1?[\s.-]?\(?[2-9][0-8][0-9]\)?[\s.-]?[2-9][0-9]{2}[\s.-]?[0-9]{4}$/;
  return usPhoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Remove + if present
  const phoneDigits = cleaned.replace(/^\+/, '');
  
  // Pattern for Argentine numbers
  // Country code: +54 (optional)
  // Trunk prefix: 0 (optional, immediate before area code)
  // Mobile indicator: 9 (optional, between country/trunk and area code)
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber number: 6-8 digits total
  
  if (phoneDigits.startsWith('54')) {
    // With country code +54
    if (phoneDigits.length >= 10 && phoneDigits.length <= 13) {
      const numberWithoutCountry = phoneDigits.substring(2);
      
      // Check for optional mobile indicator 9
      let numberToCheck = numberWithoutCountry;
      if (numberToCheck.startsWith('9')) {
        numberToCheck = numberToCheck.substring(1);
      }
      
      // Now we should have area code + subscriber
      if (numberToCheck.length >= 7 && numberToCheck.length <= 10) {
        // Area code: 2-4 digits (first digit 1-9)
        // Need to determine area code length - check for 2-4 digits first
        let areaCode = '';
        let subscriber = '';
        
        // Try 2-digit area code first
        if (numberToCheck.length >= 8) {
          areaCode = numberToCheck.substring(0, 2);
          subscriber = numberToCheck.substring(2);
        }
        // Try 3-digit area code
        else if (numberToCheck.length >= 9) {
          areaCode = numberToCheck.substring(0, 3);
          subscriber = numberToCheck.substring(3);
        }
        // Try 4-digit area code
        else if (numberToCheck.length >= 10) {
          areaCode = numberToCheck.substring(0, 4);
          subscriber = numberToCheck.substring(4);
        }
        
        // Validate area code and subscriber
        if (areaCode.length >= 2 && areaCode.length <= 4 && 
            areaCode.charAt(0) >= '1' && areaCode.charAt(0) <= '9' &&
            subscriber.length >= 6 && subscriber.length <= 8) {
          return true;
        }
      }
    }
  } else if (phoneDigits.startsWith('0')) {
    // Without country code, starts with 0
    const numberWithoutTrunk = phoneDigits.substring(1);
    if (numberWithoutTrunk.length >= 8 && numberWithoutTrunk.length <= 12) {
      // Try different area code lengths
      let areaCode = '';
      let subscriber = '';
      
      // Try 2-digit area code first
      if (numberWithoutTrunk.length >= 8) {
        areaCode = numberWithoutTrunk.substring(0, 2);
        subscriber = numberWithoutTrunk.substring(2);
      }
      // Try 3-digit area code
      else if (numberWithoutTrunk.length >= 9) {
        areaCode = numberWithoutTrunk.substring(0, 3);
        subscriber = numberWithoutTrunk.substring(3);
      }
      // Try 4-digit area code
      else if (numberWithoutTrunk.length >= 10) {
        areaCode = numberWithoutTrunk.substring(0, 4);
        subscriber = numberWithoutTrunk.substring(4);
      }
      
      // Validate area code and subscriber
      if (areaCode.length >= 2 && areaCode.length <= 4 && 
          areaCode.charAt(0) >= '1' && areaCode.charAt(0) <= '9' &&
          subscriber.length >= 6 && subscriber.length <= 8) {
        return true;
      }
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  
  // Check for obviously invalid patterns first
  if (/[0-9]/.test(value)) {
    return false;
  }
  
  if (/[\r\n\t]/.test(value)) {
    return false;
  }
  
  // Pattern for valid names:
  // - Unicode letters, accented characters
  // - Apostrophes and hyphens in middle
  // - Spaces for multiple names
  // - Cannot start or end with special chars except spaces
  const nameRegex = /^[\p{L}](?:[\p{L}' -]*[\p{L}])?$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that look like codes (X Æ A-12 style)
  if (value.includes('Æ') || value.includes('X') || /A-12/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/\s/g, '');
  
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercardRegex = /^(5[1-5][0-9]{14}|2[2-7][0-9]{14})$/;
  const amexRegex = /^3[47][0-9]{13}$/;
  
  let isValidFormat = false;
  
  if (visaRegex.test(cleaned)) {
    isValidFormat = cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19;
  } else if (mastercardRegex.test(cleaned)) {
    isValidFormat = cleaned.length === 16;
  } else if (amexRegex.test(cleaned)) {
    isValidFormat = cleaned.length === 15;
  }
  
  if (!isValidFormat) {
    return false;
  }
  
  return runLuhnCheck(cleaned);
}
