/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const regex = new RegExp(`\\b${prefix}\\w+\\b`, 'gi');
  const matches = text.match(regex) || [];
  
  return matches.filter(word => {
    const cleanWord = word.toLowerCase();
    return !exceptions.some(exc => exc.toLowerCase() === cleanWord);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const regex = new RegExp(`(\\d${token})`, 'g');
  const matches = text.match(regex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain uppercase, lowercase, digit, symbol
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/[0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (like abab)
  for (let i = 0; i < value.length - 3; i++) {
    const sequence = value.substring(i, i + 4);
    if (sequence.charAt(0) === sequence.charAt(2) && sequence.charAt(1) === sequence.charAt(3)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it's an IPv4 address - exclude those
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 detection - including shorthand ::
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,7}\b/;
  
  return ipv6Regex.test(value);
}
