/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  return text
    .split(/([.!?]+[\s]*)/)
    .map((segment, index, array) => {
      // Check if this is a sentence-ending segment
      if (/^[.!?]+[\s]*$/.test(segment)) {
        // Keep punctuation and following space
        return segment;
      }
      
      // If this follows a sentence ending, capitalize the first letter
      if (index > 0 && /^[.!?]+[\s]*$/.test(array[index - 1])) {
        return segment.charAt(0).toUpperCase() + segment.slice(1);
      }
      
      // First segment should also be capitalized if it's the start
      if (index === 0 && segment.length > 0) {
        return segment.charAt(0).toUpperCase() + segment.slice(1);
      }
      
      return segment;
    })
    .join('')
    // Clean up spacing
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /https?:\/\/[^\s]+/g;
  const matches = text.match(urlRegex) || [];
  
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,;:!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/[^\s]*)/g, (match, host, path) => {
    // Skip host rewrite for dynamic hints or legacy extensions
    if (/[?&]/.test(path) || /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path) || /cgi-bin/i.test(path)) {
      return `https://${host}${path}`;
    }
    
    // If path begins with /docs/, rewrite host
    if (path.startsWith('/docs/')) {
      const docsHost = `docs.${host}`;
      return `https://${docsHost}${path}`;
    }
    
    // Default: upgrade scheme but keep host
    return `https://${host}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month and day
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  if (dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}
