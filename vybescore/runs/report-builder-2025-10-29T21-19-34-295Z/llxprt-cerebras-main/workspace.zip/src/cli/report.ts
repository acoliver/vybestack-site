#!/usr/bin/env node

import { readFile } from 'fs';
import { parseArgs } from './args.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData } from '../types/report.js';

// Get file path from command line arguments
const args = parseArgs(process.argv.slice(2));

// Read and parse the JSON file
readFile(args.dataFile, 'utf8', (err, data) => {
  if (err) {
    console.error(`Error reading file: ${err.message}`);
    process.exit(1);
  }

  try {
    const reportData: ReportData = JSON.parse(data);
    
    // Validate required fields
    if (!reportData.title || !reportData.summary || !reportData.entries) {
      throw new Error('Invalid report data: missing required fields');
    }
    
    // Render the report
    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(reportData, { includeTotals: args.includeTotals });
        break;
      case 'text':
        output = renderText(reportData, { includeTotals: args.includeTotals });
        break;
      default:
        throw new Error(`Unsupported format: ${args.format}`);
    }
    
    // Output to file or stdout
    if (args.output) {
      import('fs').then(fs => {
        fs.writeFile(args.output!, output, 'utf8', (err) => {
          if (err) {
            console.error(`Error writing output file: ${err.message}`);
            process.exit(1);
          }
        });
      });
    } else {
      console.log(output);
    }
  } catch (parseError: any) {
    console.error(`Error parsing JSON data: ${parseError.message}`);
    process.exit(1);
  }
});