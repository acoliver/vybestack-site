// CLI argument parsing using only built-in Node.js modules
interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

export function parseArgs(args: string[]): CliArgs {
  const parsed: Partial<CliArgs> = {
    includeTotals: false,
  };
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (!arg.startsWith('--')) {
      if (!parsed.dataFile) {
        parsed.dataFile = arg;
      } else {
        throw new Error(`Unexpected positional argument: ${arg}`);
      }
      continue;
    }
    
    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('Missing value for --format');
        }
        const format = args[++i];
        if (format !== 'markdown' && format !== 'text') {
          throw new Error(`Unsupported format: ${format}`);
        }
        parsed.format = format;
        break;
      
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('Missing value for --output');
        }
        parsed.output = args[++i];
        break;
      
      case '--includeTotals':
        parsed.includeTotals = true;
        break;
        
      default:
        throw new Error(`Unknown argument: ${arg}`);
    }
  }
  
  if (!parsed.dataFile) {
    throw new Error('Missing data file argument');
  }
  
  if (!parsed.format) {
    throw new Error('Missing --format argument');
  }
  
  return parsed as CliArgs;
}