/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Padding is included when required for compliance with the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input with or without padding and recovers the original Unicode string.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Check for invalid characters - Base64 only allows A-Z, a-z, 0-9, +, /, and padding =
  // We'll use a more permissive regex that allows whitespace but rejects invalid characters
  const cleanInput = input.trim().replace(/\s/g, '');
  
  if (!cleanInput) {
    throw new Error('Base64 input cannot be empty');
  }

  // Validate Base64 string structure:
  // 1. Only allows valid Base64 characters
  // 2. Validates padding is only at the end (if present)
  // 3. Validates the number of padding characters (max 2)
  const base64Content = cleanInput.replace(/=+$/, ''); // Remove padding for content validation
  const paddingCount = cleanInput.length - base64Content.length;
  
  // Check for invalid characters in the content (excluding padding)
  if (!/^[A-Za-z0-9+/]+$/.test(base64Content)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }
  
  // Check for invalid padding (too many or not at the end)
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }

  try {
    // Buffer's base64 decoder handles padding correctly
    return Buffer.from(cleanInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}