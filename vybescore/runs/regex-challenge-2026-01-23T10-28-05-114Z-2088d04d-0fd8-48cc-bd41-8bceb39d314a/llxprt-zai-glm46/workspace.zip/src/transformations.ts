/**
 * Capitalize the first character of each sentence.
 * - Capitalizes first letter after sentence-ending punctuation (.!?)
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // First, normalize spacing: replace multiple spaces and tabs with single space
  const normalized = text.replace(/ {2,}|\t+/g, ' ');
  
  // Use a simpler approach: split on sentence boundaries, capitalize each part
  // But preserve abbreviations
  const abbreviationPattern = /\b(Dr|Mr|Ms|Mrs|Prof|Sr|Jr|etc|vs|eg|ie)\.$/;
  
  // Find all sentence boundaries (. ! ?) followed by space and lowercase letter
  // We'll process character by character
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < normalized.length; i++) {
    const char = normalized[i];
    
    if (capitalizeNext && char && /[a-z]/.test(char)) {
      result += char.toUpperCase();
      capitalizeNext = false;
    } else {
      result += char;
      
      // Check if this ends a sentence
      if (char === '.' || char === '!' || char === '?') {
        // Look ahead to see if there's a space and then a lowercase letter
        const nextChar = normalized[i + 1];
        const afterNext = normalized[i + 2];
        
        // Build what we have so far in this sentence to check for abbreviations
        const lastSentenceEnd = Math.max(0, result.lastIndexOf(' ', i - 1));
        const recentText = result.slice(lastSentenceEnd, result.length);
        
        if (nextChar === ' ' && afterNext && /[a-z]/.test(afterNext)) {
          // Check if we just ended with an abbreviation
          const trimmed = recentText.trim();
          if (!abbreviationPattern.test(trimmed)) {
            capitalizeNext = true;
          }
        } else if (!nextChar) {
          // End of string, no need to capitalize
          capitalizeNext = false;
        }
      }
    }
  }
  
  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http://, https://, and www. prefixes
  // Excludes trailing punctuation
  const urlRegex = /(?:https?:\/\/|www\.)[a-zA-Z0-9\-._~:/?#[\]@!$&'()*+,;=%]+[a-zA-Z0-9\-_~:/?#[\]@!$&'()*+,;=%]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation: .,;:!? but not if it's part of the URL
    return url.replace(/[.,;:!?\\]+$/, '');
  });
}

/**
 * Force all http URLs to https.
 * Replaces http:// with https:// while leaving existing https:// URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs.
 * For http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs
  // We need to be careful to only match example.com domains
  const urlRegex = /(http:\/\/example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, protocolAndHost, path) => {
    // Always upgrade to https
    let newHost = 'https://example.com';
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for exceptions that should NOT trigger the host rewrite
      // - cgi-bin in path
      // - query strings (?, &, =)
      // - legacy extensions (.jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
      const hasCgiBin = path.includes('/cgi-bin') || path.includes('cgi-bin');
      const hasQueryString = /[?&=]/.test(path);
      const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i.test(path);
      
      if (!hasCgiBin && !hasQueryString && !hasLegacyExtension) {
        // Safe to rewrite host
        newHost = 'https://docs.example.com';
      }
    }
    
    return newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns the four-digit year if format is valid and month/day are valid.
 * Returns 'N/A' when the format is invalid or month/day are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year if month is February
  if (month === 2 && day === 29) {
    // Leap year: divisible by 4, but not by 100 unless also by 400
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    if (!isLeapYear) return 'N/A';
  } else if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return match[3];
}
