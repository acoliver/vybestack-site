/**
 * Find words starting with a given prefix, excluding specified exceptions.
 * Uses regex to find all words beginning with the prefix, then filters out exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  // \\b ensures we match word boundaries
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const filtered = matches.filter(word => 
    !exceptionsLower.includes(word.toLowerCase())
  );
  
  // Return unique words
  return [...new Set(filtered)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning.
 * Returns the full match including the digit prefix.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token
  // We want to return the digit + token, not just the token
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  return matches;
}

/**
 * Validate strong passwords.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length 10
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for repeated sequences (e.g., abab, 1212)
  // A repeated sequence is a pattern of 2-4 characters that repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const sequence = value.slice(i, i + len);
      const nextSequence = value.slice(i + len, i + len * 2);
      if (sequence === nextSequence) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand notation (::).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it looks like an IPv4 address to exclude it
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // IPv6 pattern (simplified but comprehensive)
  // Must match:
  // - Full notation: 8 groups of 1-4 hex digits separated by colons
  // - Shorthand: :: can replace one or more consecutive groups of zeros
  // - Can include embedded IPv4 in the last 32 bits (::ffff:192.168.1.1)
  
  // Pattern breakdown:
  // - Starts with optional hex groups
  // - Can have :: shorthand
  // - Ends with hex groups (or embedded IPv4)
  
  // Check for colons which are indicative of IPv6 (but not in URLs)
  if (value.includes(':') && !value.includes('http')) {
    // Check if it matches IPv6 patterns
    // Full IPv6: 8 groups of hex
    const fullPattern = /^[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}$/;
    // IPv6 with ::
    const shorthandPattern = /::/;
    // IPv6 with embedded IPv4
    const embeddedPattern = /::ffff:(\d+\.\d+\.\d+\.\d+)/i;
    
    if (fullPattern.test(value) || shorthandPattern.test(value) || embeddedPattern.test(value)) {
      return true;
    }
    
    // More comprehensive check: multiple colons with hex
    if (/^[0-9a-fA-F:]+$/.test(value) && value.split(':').length >= 3) {
      return true;
    }
  }
  
  return false;
}
