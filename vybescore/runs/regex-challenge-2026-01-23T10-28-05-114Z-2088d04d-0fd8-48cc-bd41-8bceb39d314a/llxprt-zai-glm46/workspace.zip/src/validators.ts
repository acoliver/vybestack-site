export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict rules.
 * Accepts: name@tag@example.co.uk style addresses
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Trim whitespace
  const email = value.trim();
  
  // Basic structure check: at least one @ (support quoted strings and tags)
  const atCount = (email.match(/@/g) || []).length;
  if (atCount < 1) return false;
  
  // Find the last @ sign (separates local part from domain)
  const lastAtIndex = email.lastIndexOf('@');
  const localPart = email.slice(0, lastAtIndex);
  const domain = email.slice(lastAtIndex + 1);
  
  // Local part must be 1-64 chars and not empty
  if (!localPart || localPart.length > 64) return false;
  
  // Domain must be 1-255 chars and not empty
  if (!domain || domain.length > 255) return false;
  
  // Reject dots at start/end or consecutive dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  if (localPart.includes('..')) return false;
  
  // Reject dots at start/end or consecutive dots in domain
  if (domain.startsWith('.') || domain.endsWith('.')) return false;
  if (domain.includes('..')) return false;
  
  // Reject underscores in domain
  if (domain.includes('_')) return false;
  
  // Local part: allow letters, digits, @, and . ! # $ % & ' * + - / = ? ^ _ ` { | } ~
  // @ is allowed in quoted strings or tagged addresses (like name@tag@example.com)
  const localPartRegex = /^[a-zA-Z0-9@.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localPartRegex.test(localPart)) return false;
  
  // Domain: allow subdomains and TLD, letters, digits, hyphens (but not starting/ending with hyphen)
  // Domain parts must be separated by dots, each part 1-63 chars
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  const domainPartRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/;
  for (const part of domainParts) {
    if (part.length < 1 || part.length > 63) return false;
    if (!domainPartRegex.test(part)) return false;
  }
  
  // TLD must be at least 2 chars and only letters
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2 || !/^[a-zA-Z]+$/.test(tld)) return false;
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 country code
 * Disallows: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all whitespace and common separators for validation
  const cleaned = value.trim().replace(/[\s\-().]/g, '');
  
  // Check for optional +1 or 1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length > 10) {
    // Only strip leading 1 if it makes the length 10 (i.e., 1 + area code + number)
    digits = digits.slice(1);
  }
  
  // Must be exactly 10 digits (area code + 7-digit number)
  if (!/^\d{10}$/.test(digits)) return false;
  
  const areaCode = digits.slice(0, 3);
  const exchangeCode = digits.slice(3, 6);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (first digit of 7-digit number) cannot be 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - Without country code, must start with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const cleaned = value.trim().replace(/[\s-]/g, '');
  
  // Regex breakdown:
  // ^\+?54? - Optional +54 country code
  // (?:0)? - Optional trunk prefix 0
  // (?:9)? - Optional mobile indicator 9
  // (\d{2,4}) - Area code (2-4 digits)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const withCountryRegex = /^\+?54(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  const withoutCountryRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  let match = cleaned.match(withCountryRegex);
  if (!match) {
    match = cleaned.match(withoutCountryRegex);
  }
  
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code must be 2-4 digits with leading digit 1-9 (already enforced by regex)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber number must be 6-8 digits (already enforced by regex)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names.
 * Allows: Unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: Digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Must not be empty
  const trimmed = value.trim();
  if (!trimmed) return false;
  
  // Must be at least 2 characters
  if (trimmed.length < 2) return false;
  
  // Allow unicode letters (including accents), apostrophes, hyphens, and spaces
  // Reject digits and symbols (except apostrophe and hyphen)
  // \p{L} matches any unicode letter
  // \p{M} matches combining marks (accents)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) return false;
  
  // Reject names that are only special characters
  const lettersOnly = trimmed.replace(/[\p{M}'\-\s]/gu, '');
  if (lettersOnly.length === 0) return false;
  
  return true;
}

/**
 * Validate credit card numbers.
 * Supports: Visa (starts with 4, 13-19 digits), Mastercard (starts with 51-55 or 2221-2720, 16 digits), 
 * AmEx (starts with 34 or 37, 15 digits)
 * Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleaned)) return false;
  
  // Check card prefixes and lengths
  const visaRegex = /^4\d{12,18}$/; // 13-19 digits starting with 4
  const mastercardRegex = /^(?:5[1-5]\d{14}|2[2-7][0-2][0-9]\d{12})$/; // 16 digits, 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
