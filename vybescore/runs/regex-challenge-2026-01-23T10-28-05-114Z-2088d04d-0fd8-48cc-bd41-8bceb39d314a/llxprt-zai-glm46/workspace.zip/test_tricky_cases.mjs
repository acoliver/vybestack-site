// Test tricky and edge case strings
import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== TESTING TRICKY CASES ===\n');

console.log('--- Email edge cases ---');
const emailTests = [
  ['name@tag@example.co.uk', true],
  ['user@example.com', true],
  ['test+tag@example.com', true],
  ['user..name@example.com', false],
  ['user@example..com', false],
  ['user@_example.com', false],
  ['.user@example.com', false],
  ['user.@example.com', false],
  ['user@-example.com', false],
  ['user@example-.com', false],
  ['user@example.com.', false],
  ['user@.example.com', false],
  ['user@example', false],
  ['@example.com', false],
  ['user@', false],
];
emailTests.forEach(([email, expected]) => {
  const result = isValidEmail(email);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${email}: ${result} (expected ${expected})`);
});

console.log('\n--- US Phone edge cases ---');
const phoneTests = [
  ['(212) 555-7890', true],
  ['212-555-7890', true],
  ['2125557890', true],
  ['+1 212-555-7890', true],
  ['+12125557890', true],
  ['1-212-555-7890', true],
  ['012-555-7890', false], // bad area code
  ['112-555-7890', false], // bad area code
  ['212-055-7890', false], // bad exchange
  ['212-155-7890', false], // bad exchange
  ['212555789', false], // too short
  ['(212)-555-7890', true],
  ['212 555 7890', true],
];
phoneTests.forEach(([phone, expected]) => {
  const result = isValidUSPhone(phone);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${phone}: ${result} (expected ${expected})`);
});

console.log('\n--- Argentine Phone edge cases ---');
const arPhoneTests = [
  ['+54 9 11 1234 5678', true],
  ['+54-9-11-1234-5678', true],
  ['011 1234 5678', true],
  ['011-1234-5678', true],
  ['+54 341 123 4567', true],
  ['0341 4234567', true],
  ['0341-423-4567', true],
  ['54 9 11 1234 5678', true], // without +
  ['91112345678', true], // mobile without country/trunk
  ['0111234567', true], // landline without country
];
arPhoneTests.forEach(([phone, expected]) => {
  const result = isValidArgentinePhone(phone);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${phone}: ${result} (expected ${expected})`);
});

console.log('\n--- Name edge cases ---');
const nameTests = [
  ['Jane Doe', true],
  ['José María', true],
  ["O'Connor", true],
  ['Mary-Kate', true],
  ['François Müller', true],
  ['X Æ A-12', false],
  ['John123', false],
  ['John@Doe', false],
  ['', false],
  ['A', false], // too short
  ['a', false], // too short
  ['Ab', true], // minimum
];
nameTests.forEach(([name, expected]) => {
  const result = isValidName(name);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} "${name}": ${result} (expected ${expected})`);
});

console.log('\n--- Credit Card edge cases ---');
const ccTests = [
  ['4111111111111111', true], // Visa
  ['5500000000000004', true], // Mastercard
  ['340000000000009', true], // AmEx
  ['4111111111111112', false], // fails Luhn
  ['4111 1111 1111 1111', true], // with spaces
  ['4111-1111-1111-1111', true], // with hyphens
  ['411111111111111', false], // too short
  ['41111111111111111', false], // bad Luhn
  ['6011111111111117', true], // Discover
];
ccTests.forEach(([cc, expected]) => {
  const result = isValidCreditCard(cc);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${cc}: ${result} (expected ${expected})`);
});

console.log('\n--- Transformation edge cases ---');
console.log('capitalizeSentences:');
console.log('  "hello world. how are you?" -> "' + capitalizeSentences('hello world. how are you?') + '"');
console.log('  "dr. smith is here. mr. jones arrived." -> "' + capitalizeSentences('dr. smith is here. mr. jones arrived.') + '"');

console.log('\nextractUrls:');
const urlTests = [
  'Visit http://example.com today!',
  'See https://test.com/path?q=1, and www.foo.com.',
  'URLs: http://a.com, https://b.co.uk, and www.c.org.'
];
urlTests.forEach(text => {
  const urls = extractUrls(text);
  console.log(`  "${text}" -> ${JSON.stringify(urls)}`);
});

console.log('\nrewriteDocsUrls:');
const rewriteTests = [
  'Visit http://example.com/docs/guide',
  'See http://example.com/docs/api/v1',
  'Check http://example.com/docs?page=1',
  'Go to http://example.com/docs/cgi-bin/script',
  'See http://example.com/about',
  'Use https://example.com/docs/guide',
];
rewriteTests.forEach(text => {
  const result = rewriteDocsUrls(text);
  console.log(`  "${text}"`);
  console.log(`    -> "${result}"`);
});

console.log('\nextractYear:');
const dateTests = [
  ['01/31/2024', '2024'],
  ['12/31/1999', '1999'],
  ['02/29/2024', '2024'], // leap year
  ['02/29/2023', 'N/A'], // not leap year
  ['13/01/2024', 'N/A'], // invalid month
  ['01/32/2024', 'N/A'], // invalid day
  ['00/01/2024', 'N/A'], // invalid month
  ['not a date', 'N/A'],
];
dateTests.forEach(([date, expected]) => {
  const result = extractYear(date);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${date}: ${result} (expected ${expected})`);
});

console.log('\n--- Puzzle edge cases ---');

console.log('findPrefixedWords:');
console.log('  "preview prevent prefix pre", "pre", ["prevent"] -> ' + JSON.stringify(findPrefixedWords('preview prevent prefix pre', 'pre', ['prevent'])));
console.log('  "pre pre pre", "pre", [] -> ' + JSON.stringify(findPrefixedWords('pre pre pre', 'pre', [])));

console.log('\nfindEmbeddedToken:');
console.log('  "xfoo 1foo foo", "foo" -> ' + JSON.stringify(findEmbeddedToken('xfoo 1foo foo', 'foo')));
console.log('  "1test 2test 3test", "test" -> ' + JSON.stringify(findEmbeddedToken('1test 2test 3test', 'test')));

console.log('\nisStrongPassword:');
const pwTests = [
  ['Abcdef!234', true],
  ['Abcdef1234', false], // no symbol
  ['abcdef!234', false], // no uppercase
  ['ABCDEF!234', false], // no lowercase
  ['Abcdefgh!', false], // no digit
  ['Abc!23', false], // too short
  ['Abc def!234', false], // has whitespace
  ['abab123!AB', false], // repeated sequence
  ['1234ABcd!@', true],
];
pwTests.forEach(([pw, expected]) => {
  const result = isStrongPassword(pw);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} "${pw}": ${result} (expected ${expected})`);
});

console.log('\ncontainsIPv6:');
const ipv6Tests = [
  ['2001:0db8:85a3:0000:0000:8a2e:0370:7334', true],
  ['2001:db8::1', true],
  ['::1', true],
  ['fe80::', true],
  ['2001:db8:85a3::8a2e:370:7334', true],
  ['192.168.1.1', false],
  ['255.255.255.255', false],
  ['http://example.com', false],
  ['Address: 2001:db8::1 is local', true],
];
ipv6Tests.forEach(([addr, expected]) => {
  const result = containsIPv6(addr);
  const status = result === expected ? '[OK]' : '';
  console.log(`${status} ${addr}: ${result} (expected ${expected})`);
});

console.log('\n[OK] All tricky case tests completed');
