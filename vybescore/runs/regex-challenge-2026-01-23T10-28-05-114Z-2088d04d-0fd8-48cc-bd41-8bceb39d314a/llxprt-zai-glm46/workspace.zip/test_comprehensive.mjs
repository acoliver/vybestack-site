// Comprehensive testing of all functions
import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

let pass = 0;
let fail = 0;

function test(name, fn) {
  try {
    fn();
    pass++;
    console.log(`✓ ${name}`);
  } catch (e) {
    fail++;
    console.log(`✗ ${name}: ${e.message}`);
  }
}

function assertEqual(actual, expected, msg = '') {
  const a = JSON.stringify(actual);
  const b = JSON.stringify(expected);
  if (a !== b) {
    throw new Error(msg || `Expected ${b}, got ${a}`);
  }
}

function assertTrue(val, msg = '') {
  if (val !== true) {
    throw new Error(msg || `Expected true, got ${val}`);
  }
}

function assertFalse(val, msg = '') {
  if (val !== false) {
    throw new Error(msg || `Expected false, got ${val}`);
  }
}

console.log('=== VALIDATORS ===\n');

test('isValidEmail: simple valid', () => assertTrue(isValidEmail('user@example.com')));
test('isValidEmail: with tag', () => assertTrue(isValidEmail('name@tag@example.co.uk')));
test('isValidEmail: reject double dots local', () => assertFalse(isValidEmail('user..name@example.com')));
test('isValidEmail: reject double dots domain', () => assertFalse(isValidEmail('user@example..com')));
test('isValidEmail: reject underscore in domain', () => assertFalse(isValidEmail('user@_example.com')));
test('isValidEmail: reject trailing dot local', () => assertFalse(isValidEmail('user.@example.com')));
test('isValidEmail: reject leading dot local', () => assertFalse(isValidEmail('.user@example.com')));

test('isValidUSPhone: standard format', () => assertTrue(isValidUSPhone('(212) 555-7890')));
test('isValidUSPhone: hyphens', () => assertTrue(isValidUSPhone('212-555-7890')));
test('isValidUSPhone: plain digits', () => assertTrue(isValidUSPhone('2125557890')));
test('isValidUSPhone: with +1', () => assertTrue(isValidUSPhone('+1 212-555-7890')));
test('isValidUSPhone: reject area code starting with 0', () => assertFalse(isValidUSPhone('012-555-7890')));
test('isValidUSPhone: reject area code starting with 1', () => assertFalse(isValidUSPhone('112-555-7890')));
test('isValidUSPhone: reject exchange starting with 0', () => assertFalse(isValidUSPhone('212-055-7890')));
test('isValidUSPhone: reject too short', () => assertFalse(isValidUSPhone('212555789')));

test('isValidArgentinePhone: mobile with country code', () => assertTrue(isValidArgentinePhone('+54 9 11 1234 5678')));
test('isValidArgentinePhone: landline with trunk prefix', () => assertTrue(isValidArgentinePhone('011 1234 5678')));
test('isValidArgentinePhone: landline with country code', () => assertTrue(isValidArgentinePhone('+54 341 123 4567')));
test('isValidArgentinePhone: landline with trunk and area', () => assertTrue(isValidArgentinePhone('0341 4234567')));

test('isValidName: simple', () => assertTrue(isValidName('Jane Doe')));
test('isValidName: with accents', () => assertTrue(isValidName('José María')));
test('isValidName: apostrophe', () => assertTrue(isValidName("O'Connor")));
test('isValidName: hyphen', () => assertTrue(isValidName('Mary-Kate')));
test('isValidName: reject digits', () => assertFalse(isValidName('John123')));
test('isValidName: reject X Æ A-12', () => assertFalse(isValidName('X Æ A-12')));

test('isValidCreditCard: Visa', () => assertTrue(isValidCreditCard('4111111111111111')));
test('isValidCreditCard: Mastercard', () => assertTrue(isValidCreditCard('5500000000000004')));
test('isValidCreditCard: AmEx', () => assertTrue(isValidCreditCard('340000000000009')));
test('isValidCreditCard: reject bad Luhn', () => assertFalse(isValidCreditCard('4111111111111112')));

console.log('\n=== TRANSFORMATIONS ===\n');

test('capitalizeSentences: simple', () => assertEqual(capitalizeSentences('hello world. how are you?'), 'Hello world. How are you?'));
test('capitalizeSentences: missing space after period', () => assertEqual(capitalizeSentences('hello world.how are you?'), 'Hello world.how are you?'));
test('capitalizeSentences: abbreviations preserved', () => {
  const result = capitalizeSentences('dr. smith is here. mr. jones arrived.');
  assertTrue(result.includes('Dr.') && result.includes('Mr.'), 'Should capitalize Dr. and Mr.');
});

test('extractUrls: basic', () => assertEqual(extractUrls('Visit http://example.com today'), ['http://example.com']));
test('extractUrls: multiple', () => assertEqual(extractUrls('Visit http://example.com, https://test.com.'), ['http://example.com', 'https://test.com']));
test('extractUrls: with www', () => assertEqual(extractUrls('See www.example.com'), ['www.example.com']));

test('enforceHttps: simple', () => assertEqual(enforceHttps('Visit http://example.com'), 'Visit https://example.com'));
test('enforceHttps: already secure', () => assertEqual(enforceHttps('Visit https://example.com'), 'Visit https://example.com'));
test('enforceHttps: mixed', () => assertEqual(enforceHttps('http://a.com and https://b.com'), 'https://a.com and https://b.com'));

test('rewriteDocsUrls: docs path', () => {
  const result = rewriteDocsUrls('See http://example.com/docs/guide');
  assertTrue(result.includes('docs.example.com'), 'Should use docs.example.com host');
});
test('rewriteDocsUrls: upgrade scheme', () => {
  const result = rewriteDocsUrls('Visit http://example.com/docs/guide');
  assertTrue(result.includes('https://'), 'Should upgrade to https');
});
test('rewriteDocsUrls: cgi-bin exception', () => {
  const result = rewriteDocsUrls('See http://example.com/docs/cgi-bin/script');
  assertTrue(result.includes('example.com') && !result.includes('docs.example.com'), 'Should not rewrite host for cgi-bin');
});
test('rewriteDocsUrls: query string exception', () => {
  const result = rewriteDocsUrls('See http://example.com/docs?page=1');
  assertTrue(result.includes('example.com') && !result.includes('docs.example.com'), 'Should not rewrite host for query strings');
});

test('extractYear: valid date', () => assertEqual(extractYear('01/31/2024'), '2024'));
test('extractYear: invalid format', () => assertEqual(extractYear('not a date'), 'N/A'));
test('extractYear: invalid month', () => assertEqual(extractYear('13/01/2024'), 'N/A'));
test('extractYear: invalid day', () => assertEqual(extractYear('01/32/2024'), 'N/A'));

console.log('\n=== PUZZLES ===\n');

test('findPrefixedWords: basic', () => {
  const result = findPrefixedWords('preview prevent prefix pre', 'pre', ['prevent']);
  assertTrue(result.includes('preview') && result.includes('prefix'), 'Should find prefixed words');
  assertTrue(!result.includes('prevent'), 'Should exclude exception');
});
test('findPrefixedWords: returns unique', () => {
  const result = findPrefixedWords('pre pre pre', 'pre', []);
  assertEqual(result, ['pre'], 'Should return unique words');
});

test('findEmbeddedToken: after digit', () => {
  const result = findEmbeddedToken('xfoo 1foo foo', 'foo');
  assertEqual(result, ['1foo'], 'Should find token after digit');
});
test('findEmbeddedToken: multiple', () => {
  const result = findEmbeddedToken('xfoo 1foo 2foo foo', 'foo');
  assertEqual(result, ['1foo', '2foo'], 'Should find all tokens after digits');
});

test('isStrongPassword: strong', () => assertTrue(isStrongPassword('Abcdef!234')));
test('isStrongPassword: too short', () => assertFalse(isStrongPassword('Abc!23')));
test('isStrongPassword: no uppercase', () => assertFalse(isStrongPassword('abcdef!234')));
test('isStrongPassword: no lowercase', () => assertFalse(isStrongPassword('ABCDEF!234')));
test('isStrongPassword: no digit', () => assertFalse(isStrongPassword('Abcdefgh!')));
test('isStrongPassword: no symbol', () => assertFalse(isStrongPassword('Abcdef1234')));
test('isStrongPassword: has whitespace', () => assertFalse(isStrongPassword('Abc def!234')));
test('isStrongPassword: repeated sequence', () => assertFalse(isStrongPassword('abab123!AB')));

test('containsIPv6: full notation', () => assertTrue(containsIPv6('2001:0db8:85a3:0000:0000:8a2e:0370:7334')));
test('containsIPv6: shorthand', () => assertTrue(containsIPv6('2001:db8::1')));
test('containsIPv6: in text', () => assertTrue(containsIPv6('Address: 2001:db8::1')));
test('containsIPv6: not IPv4', () => assertFalse(containsIPv6('192.168.1.1')));
test('containsIPv6: not URL', () => assertFalse(containsIPv6('http://example.com')));

console.log('\n=== SUMMARY ===');
console.log(`Passed: ${pass}`);
console.log(`Failed: ${fail}`);
console.log(fail === 0 ? '\n✓ All tests passed!' : `\n✗ ${fail} test(s) failed`);

process.exit(fail === 0 ? 0 : 1);
