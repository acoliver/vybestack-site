import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './dist/src/validators.js';

console.log('Email tests:');
console.log('user@example.com:', isValidEmail('user@example.com'));
console.log('user@tag@example.co.uk:', isValidEmail('user@tag@example.co.uk'));
console.log('user@@example.com:', isValidEmail('user@@example.com'));
console.log('user@example..com:', isValidEmail('user@example..com'));
console.log('user@_example.com:', isValidEmail('user@_example.com'));
console.log('user.name@example.com:', isValidEmail('user.name@example.com'));
console.log('user@example.com.:', isValidEmail('user@example.com.'));
console.log('');

console.log('US Phone tests:');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('2125557890:', isValidUSPhone('2125557890'));
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('012-555-7890:', isValidUSPhone('012-555-7890'));
console.log('212-555-789:', isValidUSPhone('212-555-789'));
console.log('');

console.log('Argentine Phone tests:');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567'));
console.log('');

console.log('Name tests:');
console.log('Jane Doe:', isValidName('Jane Doe'));
console.log('José María:', isValidName('José María'));
console.log("X Æ A-12:", isValidName('X Æ A-12'));
console.log("O'Brien:", isValidName("O'Brien"));
console.log('Mary-Jane:', isValidName('Mary-Jane'));
console.log('');

console.log('Credit Card tests:');
console.log('4111111111111111:', isValidCreditCard('4111111111111111'));
console.log('5500000000000004:', isValidCreditCard('5500000000000004'));
console.log('340000000000009:', isValidCreditCard('340000000000009'));
console.log('4111111111111112:', isValidCreditCard('4111111111111112'));
