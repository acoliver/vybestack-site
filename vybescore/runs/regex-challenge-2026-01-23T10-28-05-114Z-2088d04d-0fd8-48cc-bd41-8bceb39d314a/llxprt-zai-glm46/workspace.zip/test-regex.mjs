import { 
  isValidEmail, 
  isValidUSPhone, 
  isValidArgentinePhone, 
  isValidName, 
  isValidCreditCard 
} from './dist/src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './dist/src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './dist/src/puzzles.js';

console.log('=== TESTING CREATIVITY IN REGEX ===\n');

console.log('--- Malicious/Tricky Emails ---');
const trickyEmails = [
  'user@example.com',
  'user.name@example.com',
  'user+tag@example.co.uk',
  'user@example..com',
  'user@.example.com',
  'user@example.com.',
  'user@_example.com',
  'user@@example.com',
  '.user@example.com',
  'user..name@example.com',
  'user@exa mple.com',
  'user@example.com.com'
];
trickyEmails.forEach(email => {
  console.log(`${email.padEnd(30)} => ${isValidEmail(email)}`);
});

console.log('\n--- Edge Case US Phones ---');
const edgePhones = [
  '(212) 555-7890',
  '212-555-7890',
  '2125557890',
  '+1 212-555-7890',
  '1-212-555-7890',
  '012-555-7890',  // invalid - area code starts with 0
  '212-055-7890',  // invalid - exchange starts with 0
  '212-555-789',   // invalid - too short
  '555-7890',      // invalid - missing area code
  '212-555-78901'  // invalid - too long
];
edgePhones.forEach(phone => {
  console.log(`${phone.padEnd(20)} => ${isValidUSPhone(phone)}`);
});

console.log('\n--- International Argentine Phones ---');
const argPhones = [
  '+54 9 11 1234 5678',
  '011 1234 5678',
  '+54 341 123 4567',
  '0341 4234567',
  '54-9-11-1234-5678',
  '+54011412345678',
  '011-1234-5678',
  '91112345678',  // invalid - missing country/trunk
  '+54 011 1234 5678'  // double trunk prefix
];
argPhones.forEach(phone => {
  console.log(`${phone.padEnd(25)} => ${isValidArgentinePhone(phone)}`);
});

console.log('\n--- Strange Names ---');
const names = [
  'Jane Doe',
  'José María',
  "O'Brien",
  'Mary-Jane',
  'X Æ A-12',
  'John123',
  'a',
  'Dr. John Smith',
  'Åsa',
  'محمد',
  '李明'
];
names.forEach(name => {
  console.log(`${name.padEnd(20)} => ${isValidName(name)}`);
});

console.log('\n--- Credit Cards (Luhn Check) ---');
const cards = [
  '4111111111111111',  // Valid Visa
  '5500000000000004',  // Valid Mastercard
  '340000000000009',   // Valid AmEx
  '4111111111111112',  // Invalid Luhn
  '4242-4242-4242-4242',  // Valid with dashes
  '378282246310005',   // Valid AmEx
  '6011111111111117'   // Valid Discover (should be rejected)
];
cards.forEach(card => {
  console.log(`${card.padEnd(20)} => ${isValidCreditCard(card)}`);
});

console.log('\n--- Sentence Capitalization ---');
const sentences = [
  'hello. how are you? i am fine.',
  'this is a test.another one.',
  'dr. smith is here. mr. jones arrived.',
  'what?really!yes.',
  'multiple   spaces   here'
];
sentences.forEach(s => {
  console.log(`Input:  "${s}"`);
  console.log(`Output: "${capitalizeSentences(s)}"\n`);
});

console.log('--- URL Extraction ---');
const urlTexts = [
  'Visit http://example.com today!',
  'Check out https://docs.example.com/api/v1',
  'Links: www.example.com, example.com/path',
  'Multiple: http://one.com and http://two.com'
];
urlTexts.forEach(t => {
  console.log(`Text: "${t}"`);
  console.log(`URLs: ${extractUrls(t)}\n`);
});

console.log('--- HTTPS Enforcement ---');
const httpsTests = [
  'http://example.com',
  'https://example.com',
  'Visit http://example.com and https://secure.com'
];
httpsTests.forEach(t => {
  console.log(`Input:  "${t}"`);
  console.log(`Output: "${enforceHttps(t)}"\n`);
});

console.log('--- Docs URL Rewriting ---');
const docsUrls = [
  'See http://example.com/docs/guide',
  'Link: http://example.com/docs/api/v1',
  'Dynamic: http://example.com/docs/page?param=1',
  'CGI: http://example.com/docs/cgi-bin/script',
  'Legacy: http://example.com/docs/file.php',
  'Other: http://example.com/blog/post'
];
docsUrls.forEach(u => {
  console.log(`Input:  "${u}"`);
  console.log(`Output: "${rewriteDocsUrls(u)}"\n`);
});

console.log('--- Year Extraction ---');
const dates = [
  '01/31/2024',
  '12/25/2023',
  '13/01/2024',  // Invalid month
  '02/30/2024',  // Invalid day
  '01-01-2024',  // Wrong separator
  '2024/01/31'   // Wrong format
];
dates.forEach(d => {
  console.log(`${d.padEnd(15)} => ${extractYear(d)}`);
});

console.log('\n--- Prefixed Words ---');
const wordTests = [
  ['preview prevent prefix', 'pre', ['prevent']],
  ['unhappy undo unknown', 'un', []],
  ['testing tester test', 'test', ['testing']]
];
wordTests.forEach(([text, prefix, exceptions]) => {
  console.log(`Text: "${text}", Prefix: "${prefix}", Exceptions: [${exceptions}]`);
  console.log(`Found: ${findPrefixedWords(text, prefix, exceptions)}\n`);
});

console.log('--- Embedded Tokens ---');
const tokenTests = [
  ['xfoo 1foo foo', 'foo'],
  ['abc123def 456ghi', '123'],
  ['token 1token token2', 'token']
];
tokenTests.forEach(([text, token]) => {
  console.log(`Text: "${text}", Token: "${token}"`);
  console.log(`Found: ${findEmbeddedToken(text, token)}\n`);
});

console.log('--- Password Strength ---');
const passwords = [
  'Abcdef!234',      // Strong
  'weak',            // Too short
  'nouppercase1!',   // No uppercase
  'NOLOWERCASE1!',   // No lowercase
  'NoDigit!',        // No digit
  'NoSymbol1',       // No symbol
  'Has Space1!',     // Has space
  'ababAB!123',      // Repeated sequence
  'ValidP@ssw0rd'    // Strong
];
passwords.forEach(pw => {
  console.log(`${pw.padEnd(20)} => ${isStrongPassword(pw)}`);
});

console.log('\n--- IPv6 Detection ---');
const ipv6Tests = [
  '2001:db8::1',
  '::1',
  'fe80::1',
  '192.168.1.1',     // IPv4 - should not match
  '2001:0db8:85a3:0000:0000:8a2e:0370:7334',
  '::ffff:192.168.1.1',
  'http://[2001:db8::1]:8080/path',
  'not an ipv6 address'
];
ipv6Tests.forEach(test => {
  console.log(`${test.padEnd(45)} => ${containsIPv6(test)}`);
});

console.log('\n=== TEST COMPLETE ===');
