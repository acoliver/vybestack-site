/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for words starting with prefix
  const prefixPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => {
    return !exceptions.includes(word);
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to find token occurrences that:
  // 1. Are preceded by a digit (using lookbehind)
  // 2. Are not at the beginning of the string (negative lookbehind for start)
  // 3. Match the exact token
  const pattern = new RegExp(`(?<!^)\\d${token}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Length check: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace check
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // This pattern looks for repeated character sequences
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this looks like an IPv4 address (to exclude them)
  const ipv4Pattern = /\b(?:[0-9]{1,3}\.){3}[0-9]{1,3}\b/g;
  if (ipv4Pattern.test(value)) {
    return false; // IPv4 addresses should not trigger IPv6 detection
  }
  
  // IPv6 address patterns
  // Pattern 1: Full IPv6 with 8 groups of 4 hex digits
  const fullIpv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/g;
  
  // Pattern 2: IPv6 with shorthand notation (::)
  const shorthandPattern = /\b[0-9a-fA-F]*(?::[0-9a-fA-F]*){1,7}\b/g;
  
  // Pattern 3: IPv6 starting with ::
  const doubleColonPattern = /\b::[0-9a-fA-F]*\b/g;
  
  // Pattern 4: IPv6 ending with ::
  const endingDoubleColonPattern = /\b[0-9a-fA-F]*::\b/g;
  
  // Check against all IPv6 patterns
  if (fullIpv6Pattern.test(value) || 
      shorthandPattern.test(value) || 
      doubleColonPattern.test(value) || 
      endingDoubleColonPattern.test(value)) {
    return true;
  }
  
  return false;
}
