export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex pattern that handles most valid cases
  // and rejects obviously invalid forms like double dots, trailing dots, etc.
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  // Must match the basic pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots in domain
  const domain = value.split('@')[1];
  if (domain && domain.endsWith('.')) {
    return false;
  }
  
  // Reject domains with underscores
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Must have at least 10 digits (accounting for +1)
  const digitsOnly = cleaned.replace(/\D/g, '');
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // US phone regex pattern
  // Optional +1 country code
  // Area code (2-9 for first digit, 0-9 for second/third)
  // Local number (3-9 for first digit, 0-9 for remaining)
  const phoneRegex = /^(?:\+?1[\s.-]?)?(?:\([2-9][0-9]{2}\)|[2-9][0-9]{2})[\s.-]?[2-9][0-9]{2}[\s.-]?[0-9]{4}$/;
  
  if (!phoneRegex.test(value)) {
    return false;
  }
  
  // Extract area code for validation
  const areaCodeMatch = value.match(/\(([2-9][0-9]{2})\)|([2-9][0-9]{2})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1] || areaCodeMatch[2];
  
  // Ensure area code doesn't start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators and spaces for easier validation
  const cleaned = value.replace(/[\s.-]/g, '');
  
  // Pattern to match Argentine phone numbers in various formats
  // Check if the cleaned number matches the overall structure
  // Argentine format: Optional +54 or 0, then area code (2-4 digits), then subscriber (6-8 digits)
  const numberPattern = /^(\+54|0)?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(numberPattern);
  
  if (!match) {
    return false;
  }
  
  const [, prefix, areaCode] = match;
  
  // Area code validation: 2-4 digits, no leading zeros
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode.startsWith('0')) {
    return false;
  }
  
  // Ensure we have a valid country/area prefix
  // Must either start with +54, or 0 (for trunk), or have just digits
  if (!prefix && !cleaned.startsWith('54') && !cleaned.startsWith('0')) {
    // If no prefix, the number should start with trunk '0'
    // but this was already checked in the pattern match
  }
  
  // Check total length (country code + area code + subscriber)
  const totalDigits = cleaned.replace(/[^\d]/g, '').length;
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Reject empty or whitespace-only names
  if (!value || !value.trim()) {
    return false;
  }
  
  // Check for digits (immediately disqualifying)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for disallowed symbols (excluding spaces, hyphens, apostrophes)
  // This pattern looks for symbols that aren't allowed in names
  if (/[^a-zA-ZÀ-ÿǽǣ\s\-'’]/u.test(value)) {
    return false;
  }
  
  // Reject obviously invalid patterns like "X Æ A-12"
  // These typically contain disconnected symbols or unusual patterns
  if (/[ÆØÙÀÂÔÛÊÎÏËÝŸÑÃẼÕŨŚŴĈŻĤŜ]/u.test(value)) {
    // Allow some special characters but reject combinations that look like random symbols
    if (value.includes('Æ') && !value.includes(' ') && value.length < 10) {
      return false;
    }
  }
  
  // Must contain at least one letter
  if (!/[a-zA-ZÀ-ÿǽǣ]/u.test(value)) {
    return false;
  }
  
  // Reject names that are too short or too long
  if (value.trim().length < 2 || value.trim().length > 100) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Must be a reasonable length for credit cards (13-19 digits)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for card type patterns and lengths
  // Visa: starts with 4, length 13, 16, 19
  // MasterCard: starts with 51-55, or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  const visaPattern = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const masterCardPattern = /^5[1-5][0-9]{14}$|^2(?:2[2-9]|[3-6][0-9]|7[01])[0-9]{12}$/;
  const amexPattern = /^3[47][0-9]{13}$/;
  
  const isVisa = visaPattern.test(cleaned);
  const isMasterCard = masterCardPattern.test(cleaned);
  const isAmex = amexPattern.test(cleaned);
  
  if (!isVisa && !isMasterCard && !isAmex) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleaned);
}

// Luhn checksum validation helper
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
