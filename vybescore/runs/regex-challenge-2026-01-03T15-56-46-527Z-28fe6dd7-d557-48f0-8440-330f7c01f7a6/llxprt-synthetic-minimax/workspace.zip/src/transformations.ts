/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence endings to get segments
  const segments = text.split(/([.!?]+\s+)/);
  
  // Process each segment
  let result = '';
  let lastWasPunctuation = false;
  
  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i];
    
    // Check if this is a punctuation segment (contains sentence punctuation followed by space)
    if (/[.!?]+\s+/.test(segment)) {
      result += segment;
      lastWasPunctuation = true;
    } else {
      // This is a sentence segment
      // Capitalize it if it's the first segment or comes after punctuation
      if (i === 0 || lastWasPunctuation) {
        const firstLetterMatch = segment.match(/[A-Za-zÀ-ÿ]/);
        if (firstLetterMatch && firstLetterMatch.index !== undefined) {
          const firstLetterIndex = firstLetterMatch.index;
          const beforeFirst = segment.slice(0, firstLetterIndex);
          const firstLetter = segment[firstLetterIndex].toUpperCase();
          const afterFirst = segment.slice(firstLetterIndex + 1);
          result += beforeFirst + firstLetter + afterFirst;
        } else {
          result += segment;
        }
      } else {
        result += segment;
      }
      lastWasPunctuation = false;
    }
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Simple URL pattern without unnecessary escaping
  const urlPattern = /https?:\/\/[^\s<>"'()]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that shouldn't be part of the URL
    return url.replace(/[.,!?;]*$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Simple replacement without complex regex
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Find and replace http:// URLs specifically handling docs paths
  const httpUrlPattern = /http:\/\/([^/\s]+)(.*)/gi;
  
  return text.replace(httpUrlPattern, (match, host, pathAndRest) => {
    // Check if this is specifically a docs URL
    if (pathAndRest.includes('/docs/')) {
      // Check for dynamic hints or legacy extensions in the path
      // Use word boundaries to avoid matching substrings like "do" in "/docs/"
      const dynamicHints = /(^|[^\w])(cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))(?=[^\w]|$)/i;
      
      if (dynamicHints.test(pathAndRest)) {
        // Skip host rewrite, just upgrade scheme to https
        return match.replace(/^http:\/\//i, 'https://');
      } else {
        // Host rewrite for docs paths
        return `https://docs.${host}${pathAndRest}`;
      }
    }
    // For non-docs URLs, just upgrade the scheme
    return match.replace(/^http:\/\//i, 'https://');
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Simple pattern matching for mm/dd/yyyy format
  const datePattern = /^\d{1,2}\/\d{1,2}\/\d{4}$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  // Parse the date
  const parts = value.split('/');
  const month = parseInt(parts[0], 10);
  const day = parseInt(parts[1], 10);
  const year = parts[2];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, with basic month validation)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for Feb (leap year)
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // If we get here, the format is valid
  return year;
}
