/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  callbacks,
  getIsTriggeringCallbacks,
  setIsTriggeringCallbacks
} from '../types/reactive.js'

export function triggerCallbacks() {
  // Prevent re-entrancy - don't trigger callbacks if we're already in the process
  if (getIsTriggeringCallbacks()) return
  
  setIsTriggeringCallbacks(true)
  try {
    // Create a copy of callbacks to avoid issues with callbacks being deleted during iteration
    const callbacksCopy = Array.from(callbacks)
    callbacksCopy.forEach(observer => {
      if (observer.updateFn && callbacks.has(observer)) { // Check if still in callbacks set
        try {
          observer.value = observer.updateFn(observer.value)
        } catch (e) {
          console.error('Error in callback:', e)
        }
      }
    })
  } finally {
    setIsTriggeringCallbacks(false)
  }
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (a, b) => a === b
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers = s.observers || []
      if (!s.observers.includes(observer)) {
        s.observers.push(observer)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      if (s.observers) {
        s.observers.forEach(observer => {
          updateObserver(observer as Observer<T>)
        })
      }
      // Trigger callbacks after notifying observers
      triggerCallbacks()
    }
    return s.value
  }

  return [read, write]
}
