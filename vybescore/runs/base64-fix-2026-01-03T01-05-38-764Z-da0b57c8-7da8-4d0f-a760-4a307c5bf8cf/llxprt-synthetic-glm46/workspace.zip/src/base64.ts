/**
 * Encode plain text to Base64 using canonical alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate if a string contains only valid Base64 characters (A-Z, a-z, 0-9, +, /, =).
 */
function isValidBase64(input: string): boolean {
  return /^[A-Za-z0-9+/=]+$/.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 format: contains characters outside A-Z, a-z, 0-9, +, /, =');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}
