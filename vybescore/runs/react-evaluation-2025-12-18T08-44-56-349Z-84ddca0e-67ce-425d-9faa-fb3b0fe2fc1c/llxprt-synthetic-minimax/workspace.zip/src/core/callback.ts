/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, Subject, getActiveObserver, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const s: Subject<T> = {
    name: undefined,
    observer: undefined,
    value: value!,
    equalFn: undefined,
  }

  const observer: Observer<T> = {
    value: value!,
    updateFn,
  }

  let disposed = false

  // Execute callback immediately to establish dependencies
  const executeCallback = () => {
    if (disposed) return
    
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== s.observer) {
      s.observer = currentObserver
    }
    
    observer.value = updateFn(observer.value)
    s.value = observer.value
  }

  // Initial execution to establish dependency tracking
  updateObserver(observer)
  
  // Setup observer tracking
  if (s.observer) {
    // Create a reactive cycle where our observer tracks changes
    observer.updateFn = () => {
      if (disposed) return s.value
      executeCallback()
      return s.value
    }
  }

  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up references
    s.observer = undefined
    observer.value = undefined as T
    observer.updateFn = () => value as T
  }
}
