/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = typeof _equal === 'function' 
    ? _equal 
    : (_equal === false ? undefined : undefined)

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value!,
    equalFn,
  }

  const o: Observer<T> = {
    name: options?.name,
    value: value!,
    updateFn,
  }

  const recompute = () => {
    // Don't pass any argument to allow default parameters to work
    const newValue = updateFn()
    
    // Check if value actually changed
    if (s.equalFn && o.value !== undefined && s.equalFn(o.value, newValue)) {
      return o.value
    }
    
    const oldValue = o.value
    o.value = newValue
    s.value = newValue
    
    // If value changed and we have observers, notify them
    if (oldValue !== newValue && s.observer) {
      updateObserver(s.observer as Observer<unknown>)
    }
    
    return newValue
  }

  // Initial computation
  updateObserver(o)

  const read: GetterFn<T> = () => {
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== s.observer) {
      s.observer = currentObserver
    }
    
    // Re-compute value when accessed
    recompute()
    
    return s.value
  }

  return read
}
