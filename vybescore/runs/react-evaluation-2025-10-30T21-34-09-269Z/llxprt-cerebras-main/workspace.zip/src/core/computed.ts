/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  SubjectV
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Keep track of dependencies
  const dependencies = new Set<SubjectV<unknown>>()
  
  // Create the observer
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (currentValue?: T) => {
      // Before computing, clear dependencies
      dependencies.clear()
      
      // Temporarily set activeObserver to this computed observer
      // to track dependencies during computation
      const previousActiveObserver = globalThis.__activeObserver
      globalThis.__activeObserver = o
      
      try {
        return updateFn(currentValue)
      } finally {
        // Reset activeObserver
        globalThis.__activeObserver = previousActiveObserver
      }
    }
  }
  
  // Process equal function parameter
  const equalFn = typeof equal === 'function' ? equal : 
                  equal === false ? undefined : 
                  (a: T, b: T) => a === b
  
  // Initial computation
  updateObserver(o)
  
  // Create getter that tracks dependencies
  const getter: GetterFn<T> = () => {
    // If there's an active observer, register this computed as a dependency
    const activeObserver = globalThis.__activeObserver
    if (activeObserver && activeObserver !== o) {
      dependencies.add(o)
    }
    
    return o.value!
  }
  
  // Add equalFn property to observer for consistent interface
  ;(o as any).equalFn = equalFn
  
  return getter
}