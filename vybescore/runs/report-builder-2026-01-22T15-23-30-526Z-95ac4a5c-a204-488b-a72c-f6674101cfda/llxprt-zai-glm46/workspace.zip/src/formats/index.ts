import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type ReportRenderer = (data: ReportData, options: RenderOptions) => string;

export const RENDERERS: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getRenderer(format: string): ReportRenderer {
  const renderer = RENDERERS[format];
  if (!renderer) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return renderer;
}
