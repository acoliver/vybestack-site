#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { getRenderer } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const format: string[] = [];
  const outputPath: string[] = [];
  const includeTotals: string[] = [];

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format' && i + 1 < args.length) {
      format.push(args[++i]);
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath.push(args[++i]);
    } else if (arg === '--includeTotals') {
      includeTotals.push('');
    }
  }

  if (format.length !== 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  return {
    dataFile,
    format: format[0],
    outputPath: outputPath.length > 0 ? outputPath[0] : null,
    includeTotals: includeTotals.length > 0,
  };
}

function loadData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected an object');
    }

    const reportData = data as Partial<ReportData>;

    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
    }
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
    }
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
    }

    for (let i = 0; i < reportData.entries.length; i++) {
      const entry = reportData.entries[i];
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid entry at index ${i}: expected an object`);
      }
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "label" field (expected string)`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "amount" field (expected number)`);
      }
    }

    return reportData as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON file: ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    console.error('Error: Unknown error occurred while loading data');
    process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv.slice(2));
  const data = loadData(args.dataFile);

  const options: RenderOptions = {
    includeTotals: args.includeTotals,
  };

  const output = getRenderer(args.format)(data, options);

  if (args.outputPath) {
    fs.writeFileSync(args.outputPath, output, 'utf-8');
  } else {
    console.log(output);
  }
}

main();
