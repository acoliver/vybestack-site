/**
 * A single entry in a financial report.
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * The structure of the JSON input for reports.
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options that control how the report is rendered.
 */
export interface RenderOptions {
  includeTotals: boolean;
}
