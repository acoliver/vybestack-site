import type { ReportData, RenderOptions } from '../types.js';

/**
 * Render a monetary amount with two decimal places.
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Compute the total of all entry amounts.
 */
function computeTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report data as Markdown.
 */
export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(computeTotal(data.entries))}`);
  }

  return lines.join('\n');
}
