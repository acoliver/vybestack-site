#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Type-safe formatter map.
 */
type Formatter = (data: ReportData, options: RenderOptions) => string;
const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Parse and validate command-line arguments.
 */
function parseArgs(args: string[]): {
  inputPath: string;
  format: string;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  let inputPath: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        fatalError('Missing value for --format');
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        fatalError('Missing value for --output');
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--')) {
      if (inputPath !== undefined) {
        fatalError(`Unexpected argument: ${arg}`);
      }
      inputPath = arg;
    } else {
      fatalError(`Unknown option: ${arg}`);
    }
  }

  if (inputPath === undefined) {
    fatalError('Missing input file path');
  }

  if (format === undefined) {
    fatalError('Missing --format option');
  }

  return { inputPath, format, outputPath, includeTotals };
}

/**
 * Load and parse JSON input with validation.
 */
function loadReportData(inputPath: string): ReportData {
  let content: string;
  try {
    content = fs.readFileSync(inputPath, 'utf-8');
  } catch {
    fatalError(`Cannot read input file: ${inputPath}`);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch {
    fatalError(`Invalid JSON in input file: ${inputPath}`);
  }

  // Validate structure
  if (typeof data !== 'object' || data === null) {
    fatalError('Invalid report data: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    fatalError('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    fatalError('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    fatalError('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      fatalError(`Invalid report data: entry at index ${i} is not an object`);
    }
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      fatalError(`Invalid report data: entry at index ${i} missing or invalid "label" (expected string)`);
    }
    if (typeof entryObj.amount !== 'number') {
      fatalError(`Invalid report data: entry at index ${i} missing or invalid "amount" (expected number)`);
    }
  }

  return data as ReportData;
}

/**
 * Display error and exit.
 */
function fatalError(message: string): never {
  console.error(`Error: ${message}`);
  process.exit(1);
}

/**
 * Main entry point.
 */
function main(): void {
  const args = process.argv.slice(2);
  const { inputPath, format, outputPath, includeTotals } = parseArgs(args);

  const formatter = formatters[format];
  if (!formatter) {
    fatalError(`Unsupported format: ${format}`);
  }

  const data = loadReportData(inputPath);
  const options: RenderOptions = { includeTotals };
  const output = formatter(data, options);

  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch {
      fatalError(`Cannot write output file: ${outputPath}`);
    }
  } else {
    console.log(output);
  }
}

main();
