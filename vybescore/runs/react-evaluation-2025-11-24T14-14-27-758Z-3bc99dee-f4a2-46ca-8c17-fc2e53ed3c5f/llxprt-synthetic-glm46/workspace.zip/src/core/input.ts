/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  propagateUpdate,
  trackDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  // Set up equality function based on _equal parameter
  if (_equal !== undefined) {
    if (typeof _equal === 'boolean') {
      s.equalFn = _equal ? (a: T, b: T) => a === b : undefined
    } else {
      s.equalFn = _equal
    }
  }

  const read: GetterFn<T> = () => {
    // Track this dependency when accessed
    const observer = getActiveObserver()
    if (observer) {
      trackDependency(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (newValue) => {
    // Only update if value is different (using equality function if available)
    if (
      s.equalFn && s.equalFn(s.value, newValue) ||
      !s.equalFn && s.value === newValue
    ) {
      return s.value // Return current value if no change needed
    }

    propagateUpdate(s,newValue)
    return s.value
  }

  return [read, write]
}