/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  propagateUpdate,
  trackDependency,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
// Store a subject for each computed observer to allow dependency tracking
const computedToSubject = new WeakMap<Observer<any>, Subject<any>>()

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create subject for this computed value to allow other things to depend on it
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn: undefined,
  }

  // Set up equality function based on _equal parameter
  if (_equal !== undefined) {
    if (typeof _equal === 'boolean') {
      subject.equalFn = _equal ? (a: T, b: T) => a === b : undefined
    } else {
      subject.equalFn = _equal
    }
  }
  
  // Create observer for this computed value
  const observer: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: () => {
      // Get the computed value
      const newValue = updateFn(observer.value)
      
      // If value changed, update the subject and notify dependents
      propagateUpdate(subject, newValue)
      
      return newValue
    },
    dependencies: new Set()
  }

  // Store mapping to allow other things to track this computed value
  computedToSubject.set(observer, subject)
  
  // Initial compute and dependency tracking
  updateObserver(observer)
  
  const read: GetterFn<T> = () => {
    // Track current access if there's an active observer
    trackDependency(subject)
    
    return subject.value as T
  }

  return read
}