/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<Subject<any>>
}

export type Subject<T> = {
  name?: string
  observers: Set<Observer<any>>
  value: T
  equalFn?: EqualFn<T>
}

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  
  // Clear previous dependencies
  if (observer.dependencies) {
    // Remove observer from all previous dependencies
    for (const dependency of observer.dependencies) {
      dependency.observers.delete(observer)
    }
    observer.dependencies.clear()
  }
  
  // Track new dependencies during computation
  observer.dependencies = new Set()
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
  
  // Add observer to all new dependencies
  if (observer.dependencies) {
    for (const dependency of observer.dependencies) {
      dependency.observers.add(observer)
    }
  }
}

// Helper function to propagate changes to observers
export function propagateUpdate<T>(subject: Subject<T>, newValue: T): void {
  if (subject.equalFn && subject.equalFn(subject.value, newValue)) {
    return // Value hasn't changed according to equality function
  }
  
  subject.value = newValue
  
  // Create a copy of observers to avoid issues if the set is modified during iteration
  const observers = Array.from(subject.observers)
  
  // Update all observers that depend on this subject
  for (const observer of observers) {
    updateObserver(observer)
  }
}

// Helper function to track dependencies during computation
export function trackDependency(subject: Subject<any>): void {
  const observer = getActiveObserver()
  if (observer) {
    observer.dependencies = observer.dependencies || new Set()
    observer.dependencies.add(subject)
    
    // Register this observer with the subject
    subject.observers.add(observer)
  }
}