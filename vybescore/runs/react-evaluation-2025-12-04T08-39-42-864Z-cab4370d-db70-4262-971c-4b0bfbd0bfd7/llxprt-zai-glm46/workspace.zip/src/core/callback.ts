/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, setActiveObserver, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn: (newValue?: T) => {
      // Execute the user's update function
      const result = updateFn(newValue)
      // Update our own value for consistency
      updateObserver(observer, result)
      return result
    },
    _disposed: false
  }
  
  const unsubscribe = () => {
    if (observer._disposed) return
    observer._disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => {
      if (value !== undefined) return value
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      return undefined as any
    }
  }
  
  // Execute the callback with initial value immediately
  const previousActiveObserver = getActiveObserver()
  setActiveObserver(observer)
  try {
    const result = updateFn(value)
    updateObserver(observer, result)
  } finally {
    setActiveObserver(previousActiveObserver)
  }
  
  return unsubscribe
}