/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  defaultEqual,
  setActiveObserver,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = equal === true ? defaultEqual : equal === false ? undefined : equal as EqualFn<T>
  
  let currentValue: T | undefined = value
  
  // Create a subject-like structure for the computed value to store observers
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: currentValue as T,
    equalFn,
  }
  
  // Create an observer for this computed value
  const observer: Observer<T> = {
    name: options?.name,
    value: currentValue,
    updateFn: (newValue?: T) => {
      // Re-compute the value by calling updateFn
      const recomputedValue = updateFn(newValue)
      
      // Check if value has changed
      const hasChanged = !equalFn || !equalFn(currentValue as T, recomputedValue)
      
      if (hasChanged) {
        currentValue = recomputedValue
        observer.value = currentValue
        computedSubject.value = recomputedValue
        
        // Notify all observers of this computed value
        for (const obs of computedSubject.observers) {
          if (!obs._disposed && 'updateFn' in obs) {
            const obsWithFn = obs as Observer<T>
            const obsValue = obsWithFn.updateFn(recomputedValue)
            updateObserver(obsWithFn, obsValue)
          }
        }
      }
      
      return recomputedValue
    },
  }
  
  const computedGetter: GetterFn<T> = () => {
    // Set this computed observer as active so dependencies can register it
    const previousObserver = getActiveObserver()
    setActiveObserver(observer)
    
    try {
      // Compute the current value
      const recomputedValue = updateFn(currentValue)
      
      // Check if value has changed (always notify if this is the first computation)
      const hasChanged = currentValue === undefined || !equalFn || !equalFn(currentValue as T, recomputedValue)
      
      if (hasChanged) {
        currentValue = recomputedValue
        observer.value = currentValue
        computedSubject.value = recomputedValue
        
        // Notify all observers of this computed value
        for (const obs of computedSubject.observers) {
          if (!obs._disposed && 'updateFn' in obs) {
            const obsWithFn = obs as Observer<T>
            const obsValue = obsWithFn.updateFn(recomputedValue)
            updateObserver(obsWithFn, obsValue)
          }
        }
      }
      
      return currentValue as T
    } finally {
      // Restore the previous active observer
      setActiveObserver(previousObserver)
    }
  }
  
  return computedGetter
}