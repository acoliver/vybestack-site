/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  defaultEqual,
  Observer
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = equal === true ? defaultEqual : equal === false ? undefined : equal as EqualFn<T>
  
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      
      // Notify all observers of this input
      for (const observer of s.observers) {
        if (!observer._disposed && 'updateFn' in observer) {
          const obs = observer as Observer<T>
          const updatedValue = obs.updateFn(nextValue)
          updateObserver(obs, updatedValue)
        }
      }
    }
    return nextValue
  }

  return [read, write]
}