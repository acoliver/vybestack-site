import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

export const renderText: ReportRenderer = (data: ReportData, options: ReportOptions): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;
  
  // Calculate total if needed
  let total = 0;
  if (includeTotals) {
    total = entries.reduce((sum, entry) => sum + entry.amount, 0);
  }
  
  // Build the text output
  let output = `${title}\n`;
  output += `${summary}\n`;
  output += `Entries:\n`;
  
  for (const entry of entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (includeTotals) {
    output += `Total: $${total.toFixed(2)}`;
  }
  
  return output;
};