

export interface ParsedArgs {
  filePath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArguments(args: string[]): ParsedArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const filePath = args[2];
  
  // Default values
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse arguments
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i++; // Skip the next argument as it's the value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip the next argument as it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return {
    filePath,
    format,
    outputPath,
    includeTotals
  };
}