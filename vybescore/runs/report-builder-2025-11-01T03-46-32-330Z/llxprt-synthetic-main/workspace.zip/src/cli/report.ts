#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { parseArguments } from './args.js';

// Map format names to renderer functions
const formatters: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: expected an object');
  }
  
  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  const entries = reportData.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: label must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: amount must be a number`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: reportData.title,
    summary: reportData.summary,
    entries,
  };
}

function main() {
  try {
    const { filePath, format, outputPath, includeTotals } = parseArguments(process.argv);
    
    // Check if format is supported
    if (!formatters[format]) {
      console.error(`Error: Unsupported format: ${format}`);
      process.exit(1);
    }
    
    // Read and parse the JSON file
    const fileContent = readFileSync(filePath, 'utf8');
    let rawData: unknown;
    
    try {
      rawData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Failed to parse JSON file: ${filePath}`);
      process.exit(1);
    }
    
    // Validate and type the data
    let reportData: ReportData;
    try {
      reportData = validateReportData(rawData);
    } catch (error) {
      console.error(`Error: ${error instanceof Error ? error.message : 'Invalid data format'}`);
      process.exit(1);
    }
    
    // Set up options
    const options: ReportOptions = { includeTotals };
    
    // Generate the report
    const report = formatters[format](reportData, options);
    
    // Output the report
    if (outputPath) {
      writeFileSync(outputPath, report);
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
