import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initializeDatabase from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

interface DatabaseExport {
  run(sql: string, params?: unknown[]): void;
  exec(sql: string): Array<{
    columns: string[];
    values: unknown[][];
  }>;
  export(): Uint8Array;
  close(): void;
}

let db: DatabaseExport;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  const phoneRegex = /^[+]?[0-9()\s-]+$/;
  return phoneRegex.test(phone);
};

const validatePostalCode = (postalCode: string): boolean => {
  const postalRegex = /^[a-zA-Z0-9\s-]+$/;
  return postalRegex.test(postalCode);
};

interface FormErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  const errors: FormErrors = {};
  const formData: FormData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };

  res.render('form', { errors, formData });
});

app.post('/submit', (req: Request, res: Response) => {
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;

  const errors: FormErrors = {};
  const formData: FormData = {
    firstName,
    lastName,
    streetAddress,
    city,
    stateProvince,
    postalCode,
    country,
    email,
    phone
  };

  // Validate required fields
  if (!firstName?.trim()) errors.firstName = 'First name is required';
  if (!lastName?.trim()) errors.lastName = 'Last name is required';
  if (!streetAddress?.trim()) errors.streetAddress = 'Street address is required';
  if (!city?.trim()) errors.city = 'City is required';
  if (!stateProvince?.trim()) errors.stateProvince = 'State/Province/Region is required';
  if (!postalCode?.trim()) errors.postalCode = 'Postal/Zip code is required';
  if (!country?.trim()) errors.country = 'Country is required';
  if (!email?.trim()) errors.email = 'Email is required';
  if (!phone?.trim()) errors.phone = 'Phone number is required';

  // Validate format
  if (email && !validateEmail(email)) errors.email = 'Please enter a valid email address';
  if (phone && !validatePhone(phone)) errors.phone = 'Please enter a valid phone number';
  if (postalCode && !validatePostalCode(postalCode)) errors.postalCode = 'Please enter a valid postal code';

  // If there are errors, re-render the form
  if (Object.keys(errors).length > 0) {
    return res.render('form', { errors, formData });
  }

  try {
    // Insert into database
    db.run(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `, [
      firstName,
      lastName,
      streetAddress,
      city,
      stateProvince,
      postalCode,
      country,
      email,
      phone
    ]);
    
    // Export and save database
    const data = db.export();
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    fs.writeFileSync(dbPath, Buffer.from(data));
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    errors.email = 'An error occurred while saving your submission. Please try again.';
    res.render('form', { errors, formData });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, shutting down gracefully');
  if (db) {
    try {
      const data = db.export();
      const dbPath = path.join(__dirname, '../data/submissions.sqlite');
      fs.writeFileSync(dbPath, Buffer.from(data));
      db.close();
    } catch (error) {
      console.error('Error during shutdown:', error);
    }
  }
  process.exit(0);
});

// Start server
async function startServer() {
  try {
    db = await initializeDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();