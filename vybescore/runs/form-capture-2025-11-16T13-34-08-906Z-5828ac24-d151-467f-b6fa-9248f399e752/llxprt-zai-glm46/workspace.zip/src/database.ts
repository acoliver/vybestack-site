import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface DatabaseExport {
  run(sql: string, params?: unknown[]): void;
  exec(sql: string): Array<{
    columns: string[];
    values: unknown[][];
  }>;
  export(): Uint8Array;
  close(): void;
}

async function initializeDatabase(): Promise<DatabaseExport> {
  try {
    // Initialize SQL.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '../node_modules/sql.js/dist/', file)
    });
    
    const dbPath = path.join(__dirname, '../data/submissions.sqlite');
    
    let db: Database;
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      // Load existing database
      const data = fs.readFileSync(dbPath);
      db = new SQL.Database(data);
      console.log('Loaded existing database');
    } else {
      // Create new database
      db = new SQL.Database();
      console.log('Created new database');
    }
    
    // Initialize schema
    const schemaPath = path.join(__dirname, '../db/schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);
    
    // Ensure data directory exists
    const dataDir = path.join(__dirname, '../data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    return {
      run: (sql: string, params?: unknown[]) => db.run(sql, params),
      exec: (sql: string) => db.exec(sql),
      export: () => db.export(),
      close: () => db.close()
    };
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export default initializeDatabase;