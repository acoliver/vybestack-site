/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex for words starting with the prefix
  const prefixRegex = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  const uniqueWords = new Set<string>();
  
  matches.forEach(match => {
    const lowerMatch = match.toLowerCase();
    if (!exceptionsSet.has(lowerMatch)) {
      uniqueWords.add(match);
    }
  });
  
  return Array.from(uniqueWords);
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match token after a digit, but not at start of string
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenRegex) || [];
  return matches as string[];
}

/**
 * Validates if a password meets strong security requirements.
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Password must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must contain at least one uppercase letter
  const uppercasePattern = /[A-Z]/;
  if (!uppercasePattern.test(value)) return false;
  
  // Must contain at least one lowercase letter
  const lowercasePattern = /[a-z]/;
  if (!lowercasePattern.test(value)) return false;
  
  // Must contain at least one digit
  const digitPattern = /\d/;
  if (!digitPattern.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  const symbolPattern = /[^\w\s]/;
  if (!symbolPattern.test(value)) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab)
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses in the given text.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // IPv6 regex that matches standard IPv6 format including shorthand with ::
  const ipv6Pattern = /((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))/g;
  
  // First check for IPv6 addresses
  const ipv6Matches = value.match(ipv6Pattern);
  if (ipv6Matches && ipv6Matches.length > 0) {
    return true;
  }
  
  // Check for shorthand notation with ::
  const shorthandPattern = /::/;
  if (shorthandPattern.test(value)) {
    return true;
  }
  
  return false;
}