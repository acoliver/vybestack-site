export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address with comprehensive checks.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic regex for email validation
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick check for overall structure
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  // No double dots
  if (value.includes('..')) return false;
  
  // No trailing dots in local or domain part
  if (value.endsWith('.')) return false;
  
  // No underscore in domain
  const domainMatch = value.match(/@(.+)$/);
  if (domainMatch && domainMatch[1].includes('_')) return false;
  
  // Check domain validity more carefully
  const domainParts = domainMatch ? domainMatch[1].split('.') : [];
  if (domainParts.length < 2) return false;
  
  // Check each domain part for validity
  for (const part of domainParts) {
    if (part.length === 0) return false;
    if (part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * Validates a US phone number.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for basic validation
  const digitsOnly = value.replace(/\D/g, '');
  
  if (digitsOnly.length < 10) return false;
  
  // Handle optional country code
  let phoneNumber = digitsOnly;
  
  if (digitsOnly.startsWith('1') && digitsOnly.length === 11) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length === 10) {
    phoneNumber = digitsOnly;
  } else {
    return false;
  }
  
  // Validate area code (first 3 digits - cannot start with 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check if the remaining 7 digits form a valid exchange (next 3 digits cannot start with 0 or 1)
  const exchange = phoneNumber.substring(3, 6);
  if (exchange[0] === '0' || exchange[0] === '1') return false;
  
  // Full validation with proper formatting
  const usPhoneRegex = /^(?:\+1[ -]?)?(?:\([0-9]{3}\)[ -]?|[0-9]{3}[ -]?)[0-9]{3}[ -]?[0-9]{4}$/;
  
  // Clean the value for formatting check
  if (!usPhoneRegex.test(value.replace(/[^0-9+\-().\s]/g, ''))) {
    // Try without cleaning non-digit characters
    const cleaned = value.replace(/[^0-9+\-().\s]/g, '');
    if (!usPhoneRegex.test(cleaned)) {
      // Final attempt with full digits
      const formattedDigits = `(${phoneNumber.substring(0, 3)}) ${phoneNumber.substring(3, 6)}-${phoneNumber.substring(6)}`;
      if (digitsOnly.length === 10 && usPhoneRegex.test(formattedDigits)) {
        return true;
      }
      return false;
    }
  }
  
  return true;
}

/**
 * Validates an Argentine phone number.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters for validation (except +)
  const cleaned = value.replace(/[^0-9+]/g, '');
  
  // Argentine phone regex
  // Optional country code +54
  // Optional trunk prefix 0
  // Optional mobile indicator 9
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleaned)) return false;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  
  // Additional validations
  // Area code should be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // If country code is omitted, trunk prefix (0) must be present
  if (!value.includes('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates a name with unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols like X Æ A-12
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0590-\u05FF\u0600-\u06FF\s'-]+$/;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names with consecutive non-letter characters (except apostrophes between letters)
  if (/[^\w']{2,}/.test(value)) return false;
  
  // Reject names with numbers
  if (/[0-9]/.test(value)) return false;
  
  // Reject names with unusual symbols (excluding allowed apostrophes, hyphens, and spaces)
  const disallowedSymbols = /[!"#$%&()*+,./:;<=>?@[\\\]^_`{|}~]/;
  if (disallowedSymbols.test(value)) return false;
  
  // At least one letter should be present
  if (!/[a-zA-Z\u00C0-\u017F\u0400-\u04FF\u0590-\u05FF\u0600-\u06FF]/.test(value)) return false;
  
  return true;
}

/**
 * Implements the Luhn algorithm to validate credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates a credit card number.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value) return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid lengths based on card type
  // Visa: 13 or 16 digits, starts with 4
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  // AmEx: 15 digits, starts with 34 or 37
  
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  const visaRegex = /^4\d{12}(\d{3})?$/;
  const mastercardRegex = /^(5[1-5]\d{14})$|^(2[2-7]\d{14})$/;
  const amexRegex = /^3[47]\d{13}$/;
  
  const isValidFormat = visaRegex.test(digitsOnly) || 
                        mastercardRegex.test(digitsOnly) || 
                        amexRegex.test(digitsOnly);
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}