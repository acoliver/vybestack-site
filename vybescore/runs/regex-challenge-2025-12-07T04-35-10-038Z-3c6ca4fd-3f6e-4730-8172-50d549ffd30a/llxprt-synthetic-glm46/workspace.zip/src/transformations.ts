/**
 * Capitalizes the first character of each sentence.
 * After . ? ! punctuation, insert exactly one space between sentences.
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // First, collapse multiple spaces into single spaces
  let result = text.replace(/\s+/g, ' ');
  
  // Replace periods followed by lowercase letter with period, space, and uppercase letter
  result = result.replace(/\. +([a-z])/g, (match, letter) => `. ${letter.toUpperCase()}`);
  
  // Replace question marks followed by lowercase letter with question mark, space, and uppercase letter
  result = result.replace(/\? +([a-z])/g, (match, letter) => `? ${letter.toUpperCase()}`);
  
  // Replace exclamation marks followed by lowercase letter with exclamation mark, space, and uppercase letter
  result = result.replace(/! +([a-z])/g, (match, letter) => `! ${letter.toUpperCase()}`);
  
  // Make sure the first letter of the text is capitalized
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Remove any space before closing punctuation
  result = result.replace(/\s+([.?!])/g, '$1');
  
  return result.trim();
}

/**
 * Extracts all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Comprehensive URL regex that matches most URL patterns
  // Includes http/https, www, domain names with many TLDs
  const urlRegex = /https?:\/\/(?:[-\w.])+(?::[0-9]+)?(?:\/(?:[\w/_.])*(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?)?|(?:www\.)[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&//=]*)/g;
  
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:?)]\}]+$/g, ''));
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return '';
  
  // Replace http:// with https:// but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * 1. Always upgrade the scheme to https://
 * 2. When the path begins with /docs/, rewrite the host to docs.example.com
 * 3. Skip host rewrite when the path contains dynamic hints
 * 4. Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return '';
  
  // Regex to match URLs with scheme upgrade and path handling
  const urlRegex = new RegExp('(http://|https://)([^/\\s]+)(/[^\\s]*)', 'g');
  
  return text.replace(urlRegex, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    let newHost = host;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check if path contains dynamic hints that should prevent host rewrite
      const dynamicHints = [
        'cgi-bin',
        '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'
      ];
      
      const shouldSkipRewrite = dynamicHints.some(hint => path.includes(hint)) || 
                                 path.includes('?') || 
                                 path.includes('&') || 
                                 path.includes('=');
      
      if (!shouldSkipRewrite) {
        // Rewrite the host to docs.example.com
        newHost = 'docs.example.com';
      }
    }
    
    return newScheme + newHost + path;
  });
}

/**
 * Returns the four-digit year for mm/dd/yyyy.
 * If the string doesn't match that format or month/day are invalid, return N/A.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month/day combinations (simple validation)
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  };
  
  // Adjust February for leap years
  if (month === 2 && isLeapYear(year)) {
    if (day > 29) return 'N/A';
  } else if (day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}