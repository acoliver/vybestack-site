import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { initializeDatabase, insertSubmission, closeDatabase } from './database.js';
import { validateForm, hasErrors } from './validator.js';
import type { FormData, FormErrors } from './types.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DEFAULT_PORT = process.env.PORT || '3535';

const app = express();

// Middleware
app.use(express.static(path.resolve(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Set EJS as the templating engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'views'));

// Initialize database on startup
let dbReady = false;

async function waitForDb(): Promise<void> {
  if (!dbReady) {
    await initializeDatabase();
    dbReady = true;
  }
}

// Routes
app.get('/', async (req: Request, res: Response) => {
  await waitForDb();
  
  const formData: FormData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: '',
    phone: ''
  };
  
  res.render('form', { formData, errors: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  await waitForDb();
  
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors: FormErrors = validateForm(formData);
  
  if (hasErrors(errors)) {
    res.status(400).render('form', { formData, errors });
    return;
  }
  
  // Insert into database
  insertSubmission(formData);
  
  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handler
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Server instance (not auto-started)
let server: ReturnType<typeof app.listen> | null = null;

// Only auto-start when running directly
if (import.meta.url === `file://${process.argv[1]}`) {
  server = app.listen(DEFAULT_PORT, () => {
    console.log(`Server listening on port ${DEFAULT_PORT}`);
  });
}

export function startServer(port?: string | number): ReturnType<typeof app.listen> {
  if (server) {
    return server;
  }
  const serverPort = port || DEFAULT_PORT;
  server = app.listen(serverPort, () => {
    console.log(`Server listening on port ${serverPort}`);
  });
  return server;
}

export function stopServer(): Promise<void> {
  return new Promise((resolve) => {
    if (server) {
      server.close(() => {
        closeDatabase();
        server = null;
        resolve();
      });
    } else {
      closeDatabase();
      resolve();
    }
  });
}

// Graceful shutdown
async function shutdown(signal: string): Promise<void> {
  console.log(`Received ${signal}, closing server gracefully...`);
  
  await stopServer();
  process.exit(0);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT', () => shutdown('SIGINT'));

export { app };

