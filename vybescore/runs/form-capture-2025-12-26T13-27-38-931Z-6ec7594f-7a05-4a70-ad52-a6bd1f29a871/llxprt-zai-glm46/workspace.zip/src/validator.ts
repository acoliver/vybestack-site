import type { FormData, FormErrors } from './types.js';

export function validateForm(data: Partial<FormData>): FormErrors {
  const errors: FormErrors = {};

  // Required fields
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  }
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  }

  // Email validation - simple regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (data.email && !emailRegex.test(data.email.trim())) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation - international formats: digits, spaces, parentheses, dashes, leading +
  const phoneRegex = /^\+?[0-9\s()()-]+/;
  if (data.phone && !phoneRegex.test(data.phone.trim())) {
    errors.phone = 'Please enter a valid phone number';
  }
  if (data.phone && data.phone.trim().length < 5) {
    errors.phone = 'Phone number is too short';
  }

  // Postal code validation - alphanumeric, spaces allowed
  const postalRegex = /^[0-9A-Za-z\s-]+$/;
  if (data.postalCode && !postalRegex.test(data.postalCode.trim())) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

export function hasErrors(errors: FormErrors): boolean {
  return Object.keys(errors).length > 0;
}
