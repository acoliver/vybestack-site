import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import type { Submission } from './types.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_DIR = path.resolve(__dirname, '..', 'data');
const DB_PATH = path.join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '..', 'db', 'schema.sql');

let db: Database | null = null;
let SQL: SqlJsStatic | null = null;

export async function initializeDatabase(): Promise<void> {
  if (db) {
    return;
  }

  // Ensure data directory exists
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    // Run schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (!db) {
    return;
  }
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

export function insertSubmission(submission: Submission): number {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvince,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phone
  ]);

  const result = db.exec('SELECT last_insert_rowid() as id');
  const lastId = result[0]?.values[0]?.[0] as number;
  
  saveDatabase();
  
  return lastId;
}

export function getAllSubmissions(): Submission[] {
  if (!db) {
    return [];
  }

  const result = db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
  
  if (result.length === 0) {
    return [];
  }

  const rows = result[0].values;
  return rows.map((row) => ({
    id: row[0] as number,
    firstName: row[1] as string,
    lastName: row[2] as string,
    streetAddress: row[3] as string,
    city: row[4] as string,
    stateProvince: row[5] as string,
    postalCode: row[6] as string,
    country: row[7] as string,
    email: row[8] as string,
    phone: row[9] as string,
    createdAt: row[10] as string
  }));
}

export function closeDatabase(): void {
  if (db) {
    saveDatabase();
    db.close();
    db = null;
  }
}
