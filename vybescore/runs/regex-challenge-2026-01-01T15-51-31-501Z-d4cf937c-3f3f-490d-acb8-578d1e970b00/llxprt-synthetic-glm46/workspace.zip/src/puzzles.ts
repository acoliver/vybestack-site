/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words starting with prefix but exclude exceptions
  const wordRegex = new RegExp(`\\b${prefix}\\w+\\b`, 'gi');
  const matches = text.match(wordRegex) || [];
  
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token occurrences after digits, not at start of string
  const tokenPattern = new RegExp(`\\d${token}`, 'g');
  const matches = [...text.matchAll(tokenPattern)].map(match => match[0]);
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Requirements: At least 10 chars, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repetition
  if (value.length < 10) return false;
  
  // Check for character types
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+=\[\]{};':"\\|,.<>]/.test(value);
  const hasWhitespace = /\s/.test(value);
  
  // Check for immediate repetition (aaaa pattern)
  const hasRepetition = /(.)\1{3}/.test(value);
  
  return hasUpper && hasLower && hasDigit && hasSymbol && !hasWhitespace && !hasRepetition;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv6 format, excluding IPv4 that might be present in the same string
  const ipv6Regex = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::/;
  return ipv6Regex.test(value);
}
