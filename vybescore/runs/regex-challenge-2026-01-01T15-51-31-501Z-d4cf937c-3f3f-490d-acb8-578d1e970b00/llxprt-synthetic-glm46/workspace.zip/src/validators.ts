export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Accept typical addresses such as name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores, and other obviously invalid forms
  const emailRegex = /^[a-zA-Z0-9.%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  // First, do basic format validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  const invalidPatterns = [
    /\.\./,           // Double dots
    /\.$/,            // Trailing dot
    /_\.*/,            // Underscore before dot in domain
    /\._/,            // Dot after underscore in domain
    /@.*_/,           // Underscore in domain
    /@.*\.$/,         // Trailing dot in domain
    /\.@/,            // Dot right before @
    /@.*\..*\./,      // Multiple consecutive dots in domain
  ];
  
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  // Disallow impossible area codes (leading 0/1) and too short inputs
  
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length (at least 10 digits for US number)
  if (cleaned.length < 10 || cleaned.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 (country code)
  if (cleaned.length === 11 && cleaned[0] !== '1') {
    return false;
  }
  
  // Extract the last 10 digits (or all if exactly 10)
  const lastTen = cleaned.length === 10 ? cleaned : cleaned.substring(1);
  
  // Area code can't start with 0 or 1
  if (lastTen[0] === '0' || lastTen[0] === '1') {
    return false;
  }
  
  // More comprehensive regex pattern
  const phoneRegex = /^(\+1[\s-.]?)?(\(\d{3}\)|\d{3})[\s-.]?\d{3}[\s-.]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  /*
   Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
   - Optional country code +54.
   - Optional trunk prefix 0 immediately before the area code.
   - Optional mobile indicator 9 between country/trunk and the area code.
   - Area code must be 2-4 digits (leading digit 1-9).
   - Subscriber number (after the area code) must contain 6-8 digits in total.
   - When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
   - Allow single spaces or hyphens as separators; ignore punctuation when validating.
  */

  // Check for valid separators (original string, not cleaned)
  // Should only contain spaces and hyphens as separators
  const validSeparatorsRegex = /^[0-9+ -]+$/;
  if (!validSeparatorsRegex.test(value)) {
    return false;
  }

  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[ -]/g, '');
  
  // Extract components
  const componentRegex = /^(\+54)?(9)?(0?[1-9]\d{0,3})(\d{6,8})$/;
  const match = cleaned.match(componentRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, , trunkPrefix, subscriber] = match;
  
  // If country code is omitted, trunk prefix must be present
  if (!countryCode && trunkPrefix && !trunkPrefix.startsWith('0')) {
    return false;
  }
  
  // Area code must be 2-4 digits (excluding trunk prefix 0)
  const areaCodeDigits = trunkPrefix.replace('0', '');
  if (areaCodeDigits.length < 2 || trunkPrefix.length > 4) {
    return false;
  }
  
  // Check subscriber number length
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // All checks passed
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check if name contains only allowed characters: unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  return nameRegex.test(value) && !/\d/.test(value) && !/[^\p{L}\p{M}'\s-]/u.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Luhn checksum implementation
  const runLuhnCheck = (cardNumber: string): boolean => {
    const digits = cardNumber.replace(/\D/g, '').split('').map(Number);
    
    let sum = 0;
    let isEven = false;
    
    // Process digits from right to left
    for (let i = digits.length - 1; i >= 0; i--) {
      let digit = digits[i];
      
      if (isEven) {
        digit *= 2;
        if (digit > 9) digit -= 9;
      }
      
      sum += digit;
      isEven = !isEven;
    }
    
    return sum % 10 === 0;
  };
  
  // Remove non-digits
  const cleaned = value.replace(/\D/g, '');
  
  // Check for valid prefixes and lengths
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/; // 13 or 16 digits
  const amexRegex = /^3[47][0-9]{13}$/; // 15 digits
  const mastercardRegex = /^5[1-5][0-9]{14}$/; // 16 digits
  
  const validPrefix = visaRegex.test(cleaned) || amexRegex.test(cleaned) || mastercardRegex.test(cleaned);
  
  return validPrefix && runLuhnCheck(cleaned);
}
