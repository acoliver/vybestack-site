/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Capitalize the first character of each sentence after punctuation
  // Also handle the first word of the text
  return text.replace(/^[a-z]|[.!?]\s*[a-z]/g, (match) => match.toUpperCase());
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Extract URLs without trailing punctuation
  const urlRegex = /(https?:\/\/[^\s,;:!?)]+)/g;
  const matches = text.match(urlRegex) || [];
  return matches.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/example\.com(\/docs\/[^\s?#]*)/g, 'https://docs.example.com$1');
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Extract year from mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Validate month/day combinations
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for leap year if February
  if (monthNum === 2) {
    const isLeap = (parseInt(year, 10) % 400 === 0) || 
                   ((parseInt(year, 10) % 100 !== 0) && (parseInt(year, 10) % 4 === 0));
    
    if (dayNum > (isLeap ? 29 : 28)) {
      return 'N/A';
    }
  } else if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}
