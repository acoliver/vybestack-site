/**
 * Encode plain text to Base64 using RFC 4648 standard encoding.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard decoding.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate the input contains only valid Base64 characters
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Base64 strings must be a multiple of 4 characters (after accounting for padding)
  const withPadding = input.padEnd(Math.ceil(input.length / 4) * 4, '=');
  
  try {
    const decoded = Buffer.from(withPadding, 'base64').toString('utf8');
    // Verify the input was actually valid Base64 by encoding back
    const reencoded = Buffer.from(decoded, 'utf8').toString('base64');
    if (!input.replace(/=*$/, '').startsWith(reencoded.replace(/=*$/, ''))) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid format');
  }
}
