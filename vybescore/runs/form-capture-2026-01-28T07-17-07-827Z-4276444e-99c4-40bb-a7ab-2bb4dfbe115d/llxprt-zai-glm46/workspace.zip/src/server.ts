import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(__dirname, '../db/schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
let db: Database | null = null;

const isCompiled = __dirname.endsWith('dist') || __dirname.includes('/dist/');
const templatesPath = isCompiled
  ? path.resolve(__dirname, '../src/templates')
  : path.resolve(__dirname, 'templates');
const publicPath = isCompiled
  ? path.resolve(__dirname, '../public')
  : path.resolve(__dirname, '../public');

app.set('view engine', 'ejs');
app.set('views', templatesPath);

app.use(express.static(publicPath));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^@?[\d\s\-()]+$/;
  const cleanedPhone = phone.replace(/[^0-9]/g, '');
  return phoneRegex.test(phone) && cleanedPhone.length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  if (!data.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  if (!data.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  if (!data.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  if (!data.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  if (!data.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Invalid postal code format' });
  }
  if (!data.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  if (!data.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  if (!data.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  return errors;
}

function getFormErrorsMap(errors: ValidationError[]): Record<string, string> {
  const map: Record<string, string> = {};
  for (const error of errors) {
    map[error.field] = error.message;
  }
  return map;
}

app.get('/', (_req: Request, res: Response) => {
  res.render('index', {
    errors: {},
    formData: {},
    hasErrors: false,
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    res.status(400);
    return res.render('index', {
      errors: getFormErrorsMap(errors),
      formData,
      hasErrors: true,
    });
  }

  if (!db) {
    res.status(500);
    return res.send('Database not initialized');
  }

  try {
    db.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );

    const data = db.export();
    const dataBuffer = Buffer.from(data);
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, dataBuffer);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Failed to save submission');
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you');
});

export interface ServerHandle {
  close: () => Promise<void>;
  app: express.Application;
}

export async function createServer(): Promise<ServerHandle> {
  const SQL = await initSqlJs();

  if (fs.existsSync(DB_PATH)) {
    const dbBuffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbBuffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    const data = db.export();
    const dataBuffer = Buffer.from(data);
    fs.mkdirSync(path.dirname(DB_PATH), { recursive: true });
    fs.writeFileSync(DB_PATH, dataBuffer);
  }

  const PORT = process.env.PORT || 3535;

  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });

  return {
    close: async () => {
      return new Promise<void>((resolve) => {
        server.close(() => {
          if (db) {
            db.close();
            db = null;
          }
          resolve();
        });
      });
    },
    app,
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  createServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

process.on('SIGTERM', async () => {
  if (db) {
    db.close();
    db = null;
  }
  process.exit(0);
});
