/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws an error for invalid Base64.
 */
export function decode(input: string): string {
  const normalized = input.replace(/\s+/g, '');

  // Validate that the input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(normalized)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Add padding if necessary
  let padded = normalized;
  while (padded.length % 4 !== 0) {
    padded += '=';
  }

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}