import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs: reject non-numeric, negative, zero, or excessive values
    const page = pageParam ? Number(pageParam) : undefined;
    const limit = limitParam ? Number(limitParam) : undefined;

    // Validation logic
    const validationErrors: string[] = [];
    
    if (page !== undefined) {
      if (!Number.isInteger(page) || page < 1) {
        validationErrors.push('page must be a positive integer (>= 1)');
      } else if (page > 10000) {
        validationErrors.push('page value is too large (max: 10000)');
      }
    }
    
    if (limit !== undefined) {
      if (!Number.isInteger(limit) || limit < 1) {
        validationErrors.push('limit must be a positive integer (>= 1)');
      } else if (limit > 100) {
        validationErrors.push('limit value is too large (max: 100)');
      }
    }

    if (validationErrors.length > 0) {
      const errorMessage = validationErrors.length === 1 
        ? validationErrors[0] 
        : `Invalid query parameters: ${validationErrors.join(', ')}`;
      res.status(400).json({ 
        error: errorMessage
      });
      return;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
