import { ContactSubmission } from './db.js';

export interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

export function validateSubmission(data: Partial<ContactSubmission>): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field validation
  if (!data.firstName || data.firstName.trim() === '') {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName || data.lastName.trim() === '') {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city || data.city.trim() === '') {
    errors.city = 'City is required';
  }

  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.postalCode = 'Postal/Zip code is required';
  }

  if (!data.country || data.country.trim() === '') {
    errors.country = 'Country is required';
  }

  if (!data.email || data.email.trim() === '') {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone || data.phone.trim() === '') {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal/zip code';
  }

  return errors;
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Remove all spaces, parentheses, dashes, and plus signs for validation
  const cleaned = phone.replace(/[\s\+\-\(\)]/g, '');
  // Must contain only digits and be at least 7 digits long
  return /^\d{7,}$/.test(cleaned);
}

function isValidPostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings, including spaces
  // Examples: "SW1A 1AA", "C1000", "B1675", "12345"
  const cleaned = postalCode.replace(/\s/g, '');
  return /^[A-Za-z0-9]{3,10}$/.test(cleaned);
}

export function hasErrors(errors: ValidationErrors): boolean {
  return Object.keys(errors).length > 0;
}