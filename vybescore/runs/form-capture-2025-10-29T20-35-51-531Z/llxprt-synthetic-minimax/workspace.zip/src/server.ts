import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { dbManager, ContactSubmission } from './db.js';
import { validateSubmission, ValidationErrors, hasErrors } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Routes

// GET / - Render the contact form
app.get('/', (req, res) => {
  res.render('form', {
    errors: {},
    data: {},
    title: 'Contact Us'
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req, res) => {
  try {
    const submissionData: Partial<ContactSubmission> = {
      firstName: req.body.firstName?.trim(),
      lastName: req.body.lastName?.trim(),
      streetAddress: req.body.streetAddress?.trim(),
      city: req.body.city?.trim(),
      stateProvince: req.body.stateProvince?.trim(),
      postalCode: req.body.postalCode?.trim(),
      country: req.body.country?.trim(),
      email: req.body.email?.trim(),
      phone: req.body.phone?.trim()
    };

    const errors = validateSubmission(submissionData);

    if (hasErrors(errors)) {
      // Validation failed, re-render form with errors and previously entered values
      return res.status(400).render('form', {
        errors,
        data: submissionData,
        title: 'Contact Us'
      });
    }

    // Validation passed, save to database
    await dbManager.insertSubmission(submissionData as ContactSubmission);
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred. Please try again.' },
      data: req.body,
      title: 'Contact Us'
    });
  }
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req, res) => {
  const firstName = (req.query.name as string) || '';
  res.render('thank-you', {
    title: 'Thank You',
    firstName: firstName || 'there'
  });
});

// Health check endpoint
app.get('/health', (req, res) => {
  res.json({ status: 'ok' });
});

// Initialize database and start server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Graceful shutdown
    const gracefulShutdown = async (signal: string) => {
      console.log(`Received ${signal}. Shutting down gracefully...`);
      server.close(async () => {
        console.log('HTTP server closed');
        await dbManager.close();
        console.log('Database connection closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default app;