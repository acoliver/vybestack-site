import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';

interface ContactSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: any = null;
  private dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  private schemaPath = path.join(process.cwd(), 'db', 'schema.sql');

  async initialize(): Promise<void> {
    try {
      // Initialize SQL.js
      this.sqlJs = await initSqlJs({
        locateFile: (file: string) => {
          // Look for the WASM file in the dist folder
          const wasmPath = path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sqlite-wasm.wasm');
          if (fs.existsSync(wasmPath)) {
            return wasmPath;
          }
          // Fallback to the original path
          return path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', 'sqlite-wasm.js');
        }
      });

    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const dbFile = fs.readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbFile);
    } else {
      this.db = new this.sqlJs.Database();
      await this.createSchema();
      await this.saveToDisk();
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = fs.readFileSync(this.schemaPath, 'utf8');
    this.db.exec(schema);
  }

  async saveToDisk(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async insertSubmission(submission: ContactSubmission): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();

    // Get the last inserted row ID
    const result = this.db.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const dbManager = new DatabaseManager();
export type { ContactSubmission };