/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  trackDependency,
  updateObserver,
  updateObserverMaybe,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = () => false
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Handle observer with tracked subjects (for callbacks)
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const observerWithSubjects = observer as any
      if (observerWithSubjects.trackedSubjects) {
        if (observerWithSubjects.trackedSubjects.indexOf(s) === -1) {
          observerWithSubjects.trackedSubjects.push(s)
        }
      } else {
        // Regular observer - handle as usual
        trackDependency(observer, s)
        s.observer = observer
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify the observer if there is one
      if (s.observer) {
        try {
          // Update observer with the new value using safe update function
          updateObserverMaybe(s.observer)
        } catch (e) {
          // Ignore errors during observer updates
        }
      }
    }
    return s.value
  }

  return [read, write]
}