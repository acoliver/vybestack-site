/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, Subject, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const trackedSubjects: Subject<T>[] = []
  
  // Track what's observed during callback execution
  let observedValue: T | undefined = value
  
  type TrackingObserver = Observer<T> & { trackedSubjects: Subject<T>[] }
  
  // Set up tracking observer
  const trackingObserver: TrackingObserver = {
    name: undefined,
    value,
    updateFn: (prevValue?: T) => {
      // Execute the actual update function
      observedValue = updateFn(prevValue)
      return observedValue
    },
    trackedSubjects
  }
  
  // Execute the callback once to establish dependencies
  const execute = () => {
    if (disposed) {
      return
    }
    
    const previousObserver = getActiveObserver()
    setActiveObserver(trackingObserver)
    
    try {
      // Clear previous tracked subjects
      trackedSubjects.length = 0
      
      // Execute the callback
      observedValue = updateFn(observedValue)
    } finally {
      setActiveObserver(previousObserver)
    }
  }
  
  // Initial execution
  execute()
  
  // Return unsubscribe function
  const unsubscribe = () => {
    if (disposed) {
      return
    }
    
    disposed = true
    
    // Clean up observer references
    trackedSubjects.forEach(subject => {
      if (subject.observer === trackingObserver) {
        subject.observer = undefined
      }
    })
    
    // Clear tracked subjects
    trackedSubjects.length = 0
  }
  
  return unsubscribe
}