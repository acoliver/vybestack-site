/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  trackDependency,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = () => false
  } else {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  const getter = (): T => {
    const previousObserver = getActiveObserver()
    
    // Set the computed observer as active to track dependencies
    setActiveObserver(o)
    
    try {
      const previousValue = o.value
      const newValue = updateFn(previousValue)
      
      if (newValue !== undefined && !equalFn(previousValue as T, newValue)) {
        o.value = newValue
      }
      
      return o.value!
    } finally {
      // Restore the previous observer
      setActiveObserver(previousObserver)
    }
  }

  // Initialize with the provided value or compute initial value
  if (value !== undefined) {
    o.value = value
  } else {
    // Compute initial value
    const initialValue = updateFn(undefined)
    if (initialValue !== undefined) {
      o.value = initialValue
    }
  }

  return getter
}