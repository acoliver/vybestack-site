/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

// Extended Observer type for callback tracking
export type ObserverWithTracking<T> = Observer<T> & {
  trackedSubjects?: Subject<T>[]
}

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

// Export activeObserver to allow direct access
export { activeObserver }

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Helper to update observer when it might be ObserverR
export function updateObserverMaybe<T>(observer: ObserverR): void {
  const obs = observer as any
  if (obs.updateFn && typeof obs.updateFn === 'function') {
    // Create a temporary Observer with the necessary fields
    const tempObserver: Observer<T> = {
      name: obs.name,
      value: obs.value,
      updateFn: obs.updateFn
    }
    try {
      updateObserver(tempObserver)
      // Copy updated value back to original observer
      obs.value = tempObserver.value
    } catch (e) {
      // Ignore errors that might occur during observer update
      console.debug('Error updating observer:', e)
    }
  }
}

// Direct update function that bypasses type constraints
export function updateObserverDirect(): (observer: ObserverR) => void {
  const currentObserver = activeObserver
  
  return function(observer: ObserverR): void {
    const obs = observer as any
    if (obs.updateFn && typeof obs.updateFn === 'function') {
      try {
        // Directly update the observer without using the typed function
        const prevObserver = activeObserver
        activeObserver = obs
        try {
          obs.value = obs.updateFn(obs.value)
        } finally {
          activeObserver = prevObserver
        }
      } catch (e) {
        // Ignore errors during observer updates
        console.debug('Observer update error:', e)
      }
    }
  }
}

// Helper function to get a reference to the subject that this observer depends on
export function trackDependency<T>(observer: Observer<T>, subject: Subject<unknown>): void {
  // Store subject reference in a private property of the observer using type assertion
  // This simplifies cleanup by allowing us to easily remove dependency
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-assignment
  (observer as any).__subject = subject
}

// Helper to get the subject a callback depends on
export function getDependencySubject<T>(observer: Observer<T>): Subject<unknown> | undefined {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any, @typescript-eslint/no-unsafe-return
  return (observer as any).__subject
}

// Function to safely update an observer that might be ObserverR
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function safeUpdateObserver(_observer: ObserverR): void {
  // This function can be used if needed in the future to update observers in a type-safe way
  // Currently unused to prevent lint errors
}
