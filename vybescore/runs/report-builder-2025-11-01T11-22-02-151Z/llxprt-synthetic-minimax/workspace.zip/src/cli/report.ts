import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataPath: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script name
  const argsList = argv.slice(2);
  
  let i = 0;
  while (i < argsList.length) {
    const arg = argsList[i];
    
    if (!arg.startsWith('--')) {
      if (!args.dataPath) {
        args.dataPath = arg;
      }
      i++;
      continue;
    }

    switch (arg) {
      case '--format':
        i++;
        if (i >= argsList.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        args.format = argsList[i];
        break;
      case '--output':
        i++;
        if (i >= argsList.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        args.outputPath = argsList[i];
        break;
      case '--includeTotals':
        args.includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown option ${arg}`);
        process.exit(1);
    }
    
    i++;
  }

  // Validate required arguments
  if (!args.dataPath) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!args.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  // Validate format
  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error(`Error: Unsupported format: ${args.format}`);
    process.exit(1);
  }

  return args;
}

function readAndValidateJson(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (typeof data.title !== 'string' || !data.title) {
      throw new Error('Missing or invalid required field: title (must be a non-empty string)');
    }
    
    if (typeof data.summary !== 'string' || !data.summary) {
      throw new Error('Missing or invalid required field: summary (must be a non-empty string)');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid required field: entries (must be an array)');
    }
    
    // Validate each entry
    if (data.entries.length === 0) {
      throw new Error('entries array cannot be empty');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (typeof entry.label !== 'string' || !entry.label) {
        throw new Error(`Invalid entry at index ${i}: label must be a non-empty string`);
      }
      
      if (typeof entry.amount !== 'number' || !isFinite(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: amount must be a valid number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT')) {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error.message.startsWith('Unexpected token')) {
        console.error('Error: Invalid JSON format');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read or parse JSON file');
    }
    process.exit(1);
  }
}

function getFormatter(format: string): (data: ReportData, options: RenderOptions) => string {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(content);
  }
}

// Main execution
(function main() {
  const args = parseArgs(process.argv);
  const data = readAndValidateJson(args.dataPath);
  const options: RenderOptions = {
    includeTotals: args.includeTotals
  };
  
  const formatter = getFormatter(args.format);
  const output = formatter(data, options);
  
  writeOutput(output, args.outputPath);
})();