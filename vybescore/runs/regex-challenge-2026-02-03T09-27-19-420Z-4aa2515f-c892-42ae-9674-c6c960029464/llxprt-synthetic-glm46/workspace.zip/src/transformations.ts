/**
 * Capitalizes the first character of each sentence (after .?!), 
 * ensuring exactly one space between sentences and collapsing extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing: ensure exactly one space after sentence terminators
  const normalized = text
    .replace(/([.!?])(?=\S)/g, '$1 ') // Add space after terminators if missing
    .replace(/\s+/g, ' ')             // Collapse any multiple spaces to single space
    .trim();
  
  // Split into sentences using sentence terminators, then capitalize each
  const sentences = normalized.split(/(?<=[.!?])/);
  
  const capitalizedSentences = sentences.map((sentence) => {
    // Find the first non-space character in the sentence
    const trimmed = sentence.trim();
    
    // Return the sentence as-is if it's empty or doesn't contain letters
    if (!trimmed || !/[a-zA-Z]/.test(trimmed)) {
      return sentence;
    }
    
    // Find the position of the first letter character
    const firstLetterIndex = sentence.search(/[a-zA-Z]/);
    
    if (firstLetterIndex === -1) {
      return sentence; // No letters found
    }
    
    // Extract the letter to capitalize and the rest of the sentence
    const before = sentence.substring(0, firstLetterIndex);
    const letterToCapitalize = sentence[firstLetterIndex];
    const after = sentence.substring(firstLetterIndex + 1);
    
    return before + letterToCapitalize.toUpperCase() + after;
  });
  
  // Join sentences back together
  return capitalizedSentences.join('');
}

/**
 * Finds and extracts all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern using lookbehind to ensure protocol is present
  const urlPattern = /(?<=\b|^)(?:https?:\/\/)?(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s\)\}].,;:"'`<>]*)?/g;
  
  const urls = [];
  let match;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];
    
    // If there's no protocol, check if the matched text starts with www.
    // If so, add http:// to make it a valid URL
    if (!url.match(/^https?:\/\//) && url.startsWith('www.')) {
      url = 'http://' + url;
    }
    // If there's no protocol and doesn't start with www., we need to check if it's valid
    else if (!url.match(/^https?:\/\//) && !url.startsWith('www.')) {
      // Skip if not a valid URL (e.g., word that happens to match pattern)
      continue;
    }
    
    // Remove trailing punctuation if present
    url = url.replace(/[,\);:."!'`\]<>]+$/g, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not when already https://
  // Use a simpler approach since negative lookbehind might not be supported
  // Replace http:// with https:// but only if it's not already https://
  return text.replace(/\bhttp:\/\/([^\/])/g, 'https://$1');
}

/**
 * Rewrites URLs for http://example.com/... to https://..., 
 * moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/ URLs (and variations)
  const urlPattern = /(https?):\/\/((?:[a-zA-Z0-9-]+\.)+example\.com)(\/[^ \t\n\r<>"`']*)/g;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https';
    
    // Check if path begins with /docs/ and doesn't contain exclusions
    const docsPathPattern = /^\/docs\/(.*)$/;
    const exclusions = /(cgi-bin|\?|&|=|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/;
    
    if (docsPathPattern.test(path) && !exclusions.test(path)) {
      // Extract everything after /docs/
      const docsMatch = path.match(docsPathPattern);
      if (docsMatch) {
        return `${newProtocol}://docs.example.com/docs/${docsMatch[1]}`;
      }
    }
    
    // Just upgrade the protocol for all other URLs
    return `${newProtocol}://${domain}${path}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day values are out of range.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format using capturing groups
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  // Extract month, day, and year from captured groups
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Additional validation for day values based on month
  // February has 28 days (ignoring leap years for simplicity)
  if (monthNum === 2 && dayNum > 28) {
    return 'N/A';
  }
  
  // April, June, September, November have 30 days
  if ((monthNum === 4 || monthNum === 6 || monthNum === 9 || monthNum === 11) && dayNum > 30) {
    return 'N/A';
  }
  
  // All other months have 31 days, which would be caught by the main regex
  return year;
}
