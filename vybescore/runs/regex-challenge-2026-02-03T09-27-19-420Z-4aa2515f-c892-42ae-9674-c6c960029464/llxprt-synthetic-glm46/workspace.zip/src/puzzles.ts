/**
 * Finds words in the text that start with the given prefix but are not in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words with the given prefix
  // \b ensures we match whole words, \w+ matches the rest of the word
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Return unique matches that aren't in the exceptions list
  return [...new Set(matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  ))];
}

/**
 * Finds occurrences of the token that appear after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex usage
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find token preceded by a digit but not at the start of string
  // Use a simpler approach: find digit+token occurrences
  const pattern = new RegExp(`(\\d${escapedToken})(?!^)`, 'g');
  
  // Find all matches
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates password strength according to the required policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check length requirement: at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace characters
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\w\s]/.test(value); // Non-word and non-space characters
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // A sequence of characters that immediately repeats
  // E.g., "abab", "123123", "xxyx", "abcabc"
  const repeatedSequencePattern = /(.{2,})\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand with ::) while ensuring IPv4 addresses don't trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 address pattern to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // IPv6 address patterns
  // Full IPv6 with all 8 hextets
  const fullIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand for replacing zeros
  const compressedIPv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){0,6}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with leading or trailing ::
  const edgeCompressedPattern = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}::\b/;
  
  // Check for IPv6 patterns while making sure it doesn't look like IPv4
  const hasIPv6 = fullIPv6Pattern.test(value) || 
                   compressedIPv6Pattern.test(value) || 
                   edgeCompressedPattern.test(value);
  
  // Verify it's actually IPv6 and not confused with IPv4
  return hasIPv6 && !ipv4Pattern.test(value);
}
