export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Check for invalid patterns
  const hasDoubleDots = /\.\./.test(value);
  const hasTrailingDot = /\.$/.test(value);
  const hasUnderscoreInDomain = /_.*@/.test(value) || /@.*_/.test(value);
  
  return emailPattern.test(value) && !hasDoubleDots && !hasTrailingDot && !hasUnderscoreInDomain;
}

/**
 * Validates US phone numbers supporting common formats and optional +1.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and invalid lengths.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Test original format with optional separators and +1 prefix
  const phonePattern = /^(?:\+1[\s-]?)?(\(?\d{3}\)?[\s-]?)(\d{3}[\s-]?)(\d{4})$/;
  return phonePattern.test(value);
}

/**
 * Validates Argentine phone numbers supporting both mobile and landline formats.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Handles optional country code +54, trunk prefix 0, and mobile indicator 9.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens to validate
  const normalized = value.replace(/[ -]/g, '');
  
  // Pattern breakdown:
  // ^(\+54)? - Optional +54 country code at start
  // (0)? - Optional trunk prefix 0 after country code
  // (9)? - Optional mobile indicator 9 after trunk prefix
  // ([2-9]\d{1,3}) - Area code: 2-4 digits starting with 1-9 (not 0)
  // (\d{6,8})$ - Subscriber number: 6-8 digits
  const phonePattern = /^(\+54)?(0)?(9)?([2-9]\d{1,3})(\d{6,8})$/;
  const match = normalized.match(phonePattern);
  
  if (!match) {
    return false;
  }
  
  const hasCountryCode = match[1] === '+54';
  const hasTrunkPrefix = match[2] === '0';
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // If country code is omitted, trunk prefix must be present
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unconventional names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Name pattern: Unicode letters (with accents), apostrophes, hyphens, and spaces
  // Must contain at least one letter and not only symbols/spaces
  const namePattern = /^[\p{L}'’-]+(?:[\s.'’-]+[\p{L}'’-]+)*$/u;
  
  // Basic pattern match
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Ensure the name has at least one letter (not just symbols)
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with unconventional symbols (looking for patterns like "X Æ A-12")
  const hasUnconventionalSymbols = /[^\p{L}'’\s-]/u.test(value);
  if (hasUnconventionalSymbols) {
    return false;
  }
  
  // Reject single-character names that are just symbols
  if (value.length === 1 && !/[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using regex patterns and Luhn checksum.
 * Supports Visa, Mastercard, and American Express formats.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const normalized = value.replace(/[ -]/g, '');
  
  // Return false if not all digits after removing separators
  if (!/^\d+$/.test(normalized)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaPattern = /^4\d{12}(?:\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardPattern = /^5[1-5]\d{14}$|^2(2[2-9]|[3-6]\d|7([01]|20))\d{12}$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexPattern = /^3[47]\d{13}$/;
  
  // Check if number matches any supported card pattern
  const isValidPattern = visaPattern.test(normalized) || 
                        mastercardPattern.test(normalized) || 
                        amexPattern.test(normalized);
  
  if (!isValidPattern) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(normalized);
}

/**
 * Helper function to run the Luhn checksum algorithm on a numeric string.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      let doubled = digit * 2;
      // If the result is a two-digit number, subtract 9 (equivalent to summing the digits)
      if (doubled > 9) {
        doubled -= 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    // Alternate between doubling and not doubling
    shouldDouble = !shouldDouble;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
