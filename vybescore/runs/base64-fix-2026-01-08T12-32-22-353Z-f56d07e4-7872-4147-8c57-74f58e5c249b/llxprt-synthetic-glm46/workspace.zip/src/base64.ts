/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check if the input contains only valid Base64 characters
  if (!isValidBase64Pattern(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Check for invalid padding (must be at the end only and max 2 characters)
  if (!hasValidPadding(input)) {
    throw new Error('Invalid Base64 input: incorrect padding');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Verify the result is valid UTF-8
    if (result.includes('\ufffd')) {
      throw new Error('Invalid Base64 input: contains invalid UTF-8 sequences');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error; // Re-throw our custom error
    }
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Helper function to check if input matches valid Base64 pattern
 */
function isValidBase64Pattern(input: string): boolean {
  return /^[A-Za-z0-9+/]*={0,2}$/.test(input);
}

/**
 * Helper function to check if padding is valid
 */
function hasValidPadding(input: string): boolean {
  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    return false;
  }
  
  // If padding exists, it must be at the very end of the string
  const paddingIndex = input.indexOf('=');
  return paddingIndex === -1 || paddingIndex === input.length - paddingCount;
}
