/**
 * Capitalizes the first character of each sentence in the text.
 * Handles proper spacing after sentence delimiters (.?!) and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split into characters to process each one
  const chars = text.split('');
  let newSentence = true; // Track if next character starts a new sentence
  
  for (let i = 0; i < chars.length; i++) {
    // First character should be capitalized
    if (i === 0 && /[a-z]/.test(chars[i])) {
      chars[i] = chars[i].toUpperCase();
      newSentence = false;
      continue;
    }
    
    // If previous character was a sentence delimiter, capitalize next character
    if (newSentence && /[a-z]/.test(chars[i]) && chars[i] !== ' ') {
      chars[i] = chars[i].toUpperCase();
      newSentence = false;
      continue;
    }
    
    // Check if current character is a sentence delimiter
    if (chars[i] === '.' || chars[i] === '?' || chars[i] === '!') {
      // Ensure there's exactly one space after punctuation
      const nextIdx = i + 1;
      if (nextIdx < chars.length && /[a-zA-Z]/.test(chars[nextIdx])) {
        chars.splice(nextIdx, 0, ' ');
        i++;
      } else if (nextIdx < chars.length && chars[nextIdx] === ' ') {
        // Remove any additional spaces after the first one
        let extraSpaces = 0;
        let j = nextIdx + 1;
        while (j < chars.length && chars[j] === ' ') {
          extraSpaces++;
          j++;
        }
        if (extraSpaces > 0) {
          chars.splice(nextIdx + 1, extraSpaces);
        }
      }
      
      // The next character after possible spaces starts a new sentence
      newSentence = true;
    }
  }
  
  return chars.join('');
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
// Regex pattern to match URLs
  const urlPattern = /(https?:\/\/)?(www\.)?[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(\/[^\\\s]*)?/g;
  
  // Find all potential matches
  const matches = [...text.matchAll(urlPattern)];
  
  // Process each match to remove trailing punctuation and ensure the protocol is included
  const urls = matches.map(match => {
    // Get the full match
    let url = match[0];
    
    // Remove trailing punctuation like .,?!;:) etc.
    url = url.replace(/[.,?!;:)\]]+$/, '');
    
    // If protocol is missing, add https (we don't know if it should be http or https)
    if (!url.startsWith('http://') && !url.startsWith('https://')) {
      url = 'https://' + url;
    }
    
    return url;
  });
  
  return urls;
}

/**
 * Replaces http:// URLs with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Pattern to match http:// URLs but not https://
  const httpPattern = /http:\/\/[^"'\s]+/g;
  
  // Replace each match with its https:// equivalent
  return text.replace(httpPattern, (url) => {
    return url.replace('http://', 'https://');
  });
}

/**
 * Rewrites URLs with special rules for documentation paths.
 * For URLs http://example.com/...:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic URLs (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // Pattern to match http://example.com URLs, capturing the host and path
  const urlPattern = /http:\/\/([a-zA-Z0-9.-]+)(\/[^"'?\s]*)?/g;
  
  return text.replace(urlPattern, (match, host, path = '') => {
    // Always upgrade scheme to https
    let newUrl = `https://${host}${path}`;
    
    // If there's no path or path doesn't start with /docs/, just return the upgraded URL
    if (!path || !path.startsWith('/docs/')) {
      return newUrl;
    }
    
    // Check if URL contains dynamic indicators that should prevent hostname rewriting
    const dynamicPatterns = [
      /\/cgi-bin\//i,              // CGI scripts
      /[?&]/,                      // Query parameters
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[?#/]|$)/i  // Legacy extensions
    ];
    
    const shouldSkipHostRewrite = dynamicPatterns.some(pattern => pattern.test(newUrl));
    
    if (!shouldSkipHostRewrite) {
      // Rewrite the host to include docs. subdomain
      newUrl = `https://docs.${host}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day values are invalid.
 */
export function extractYear(value: string): string {
  if (!value) return 'N/A';
  
  // Pattern to match month/day/year format (mm/dd/yyyy)
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = datePattern.exec(value);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Year is a string to preserve any leading zeros
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31) based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  let maxDays = daysInMonth[month - 1];
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    // Leap year: divisible by 4 but not 100, unless also divisible by 400
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    maxDays = isLeapYear ? 29 : 28;
  }
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return year;
}