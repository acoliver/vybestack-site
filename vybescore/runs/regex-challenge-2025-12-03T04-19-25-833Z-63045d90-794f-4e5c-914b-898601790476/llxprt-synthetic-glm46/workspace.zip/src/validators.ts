export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC patterns.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for consecutive dots
  if (value.includes('..')) {
    return false;
  }
  
  // Check for underscores in domain part
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Check local part doesn't start or end with a dot
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check domain doesn't start or end with a dot or hyphen
  if (domainPart.startsWith('.') || domainPart.endsWith('.') || 
      domainPart.startsWith('-') || domainPart.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers in multiple formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Normalize the phone number by removing common separators
  const cleaned = value.replace(/[\s\-.()]/g, '');
  
  // Check for optional +1 country code
  const withoutCountryCode = cleaned.startsWith('+1') ? cleaned.slice(2) : cleaned;
  
  // For 10-digit format (most common US phone number format)
  if (withoutCountryCode.length === 10) {
    // Check if area code (first 3 digits) starts with 0 or 1 (invalid in US)
    const areaCode = withoutCountryCode.slice(0, 3);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    // Check if all remaining digits are valid
    return /^\d+$/.test(withoutCountryCode);
  }
  
  // For 11-digit format with leading 1 (country code)
  if (withoutCountryCode.length === 11 && withoutCountryCode.startsWith('1')) {
    // Check if area code (digits 2-4) starts with 0 or 1 (invalid in US)
    const areaCode = withoutCountryCode.slice(1, 4);
    if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
      return false;
    }
    
    // Check if all remaining digits are valid
    return /^\d+$/.test(withoutCountryCode);
  }
  
  // If extensions are allowed, we can accept formats with extension markers
  if (options?.allowExtensions && value.includes('ext')) {
    // Extract the main number part before the extension
    const mainNumber = value.toLowerCase().split('ext')[0].trim();
    return isValidUSPhone(mainNumber, {});
  }
  
  return false;
}

/**
 * Validates Argentine phone numbers in multiple formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, 
 * +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens (common separators)
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Basic pattern for Argentine phone numbers
  // Allows formats: +54[9]0XXXXXXXX, 0XXXXXXXX
  const basePattern = /^((\+54\s?9?\s?)|(0))(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(basePattern);
  
  if (!match) return false;
  
  const countryPrefix = match[2]; // "+54 9 " or "+54 " or "0"
  const areaCode = match[4];      // 2-4 digits
  const subscriberNumber = match[5]; // 6-8 digits
  
  // If there's a country code, area code must start with 0
  // If no country code, we already validated it starts with 0 in the pattern
  
  // Validate area code
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // For numbers with country code, area code must start with 0
  if (countryPrefix && countryPrefix.includes('+54') && areaCode.length > 0 && !areaCode.startsWith('0')) {
    // Try a more lenient pattern that doesn't require area code to start with 0
    // Some formats like +54 9 11 1234 5678 don't include the trunk prefix 0 in the area code
    const lenientPattern = /^(\+54\s?9?\s?)(\d{2,4})(\d{6,8})$/;
    if (cleaned.match(lenientPattern)) {
      return true;
    }
  }
  
  // Validate subscriber number
  return subscriberNumber.length >= 6 && subscriberNumber.length <= 8;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unconventional names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim() === '') {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Pattern for valid names: unicode letters, spaces, apostrophes, hyphens
  const namePattern = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!namePattern.test(value)) {
    return false;
  }
  
  // Additional checks for unconventional names containing non-name symbols
  // Looking for unusual symbols that aren't typical in names
  const unusualPattern = /[^\p{L}\p{M}'\-\s]/u;
  if (unusualPattern.test(value)) {
    return false;
  }
  
  // Check for sequences of non-letter characters
  const nonLetterPattern = /(['-]{2,})|(\s{2,})/;
  if (nonLetterPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using format rules and Luhn checksum.
 * Accepts common credit card number formats with or without spaces.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens from the input
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Basic format checks
  if (!/^\d+$/.test(cleaned)) {
    return false; // Contains non-digits
  }
  
  // Check if it matches known card prefixes and lengths
  const cardPatterns = [
    // Visa: 13 or 16 digits, starts with 4
    { regex: /^4(\d{12}|\d{15})$/, type: 'Visa' },
    // Mastercard: 16 digits, starts with 51-55 or 2221-2720
    { regex: /^5[1-5]\d{14}$/, type: 'Mastercard' },
    { regex: /^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|7([01]\d|20))\d{12}$/, type: 'Mastercard' },
    // American Express: 15 digits, starts with 34 or 37
    { regex: /^3[47]\d{13}$/, type: 'AmEx' }
  ];
  
  let isValidFormat = false;
  for (const pattern of cardPatterns) {
    if (pattern.regex.test(cleaned)) {
      isValidFormat = true;
      break;
    }
  }
  
  if (!isValidFormat) {
    return false;
  }
  
  // Perform Luhn algorithm check
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform the Luhn checksum algorithm.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isSecondDigit = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    // Double every second digit from the right
    if (isSecondDigit) {
      digit *= 2;
      // If the result is two digits, sum them
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isSecondDigit = !isSecondDigit;
  }
  
  // Valid if sum is a multiple of 10
  return sum % 10 === 0;
}