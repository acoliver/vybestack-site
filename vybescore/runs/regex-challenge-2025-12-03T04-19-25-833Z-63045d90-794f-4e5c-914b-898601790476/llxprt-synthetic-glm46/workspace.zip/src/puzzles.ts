/**
 * Finds words beginning with the given prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a set for efficient lookup of exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Create a regex pattern to find words starting with the prefix
  // \b matches word boundary, [a-zA-Z]+ ensures we match alphabetic characters only
const wordPattern = new RegExp(`\\b(${prefix}[a-zA-Z]*)\\b`, 'g');
  
  // Find all matches
  const matches = [...text.matchAll(wordPattern)];
  
  // Filter out exceptions and return the matched words
  return matches
    .map(match => match[0])
    .filter(word => !exceptionSet.has(word.toLowerCase()))
    // Remove duplicates
    .filter((word, index, array) => array.indexOf(word) === index);
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Returns an array of matched token occurrences.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];

  // Escape the token to handle special regex characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Create a regex pattern that captures the digit and token to return the full match
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');

  // Find all matches
  const matches = [...text.matchAll(tokenPattern)];

  // Return the matched tokens with the preceding digit
  return matches.map(match => match[0]);
}

/**
 * Validates passwords according to strong password rules:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value) return false;
  
  // Check minimum length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (/\d/.test(value) === false) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab", "123123", "aaaa")
  // This pattern captures any sequence of 2-4 characters and checks if it's immediately repeated
  const repeatedPattern = /(.{1,4})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) while excluding IPv4 addresses.
 * Returns true if the string contains a valid IPv6 address, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value) return false;
  
  // First, check if it's a plain IPv4 address (which would be matched incorrectly)
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern to match standard IPv6 formats
  // 1. Full notation: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. Shorthand notation with :: at any position
  // 3. IPv4-mapped IPv6 addresses
  
  const ipv6Pattern = new RegExp([
    // Full IPv6 notation (8 groups of hex digits)
    '(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4})',
    '|',
    // Zero compression (::) at various positions
    '([0-9a-fA-F]{1,4}:){1,7}:',
    '|',
    '([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}',
    '|',
    '([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}',
    '|',
    '([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}',
    '|',
    '([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}',
    '|',
    '([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}',
    '|',
    '[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})',
    '|',
    ':((:[0-9a-fA-F]{1,4}){1,7}|:)',
    '|',
    // IPv6 with embedded IPv4
    '((([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4})?)',
    '((25[0-5]|2[0-4]\\d|[01]?\\d?\\d)\\.){3}(25[0-5]|2[0-4]\\d|[01]?\\d?\\d)'
  ].join(''));
  
  return ipv6Pattern.test(value);
}