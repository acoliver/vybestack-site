import { defineConfig } from 'vitest/config';

export default defineConfig({
  test: {
    include: ['tests/public/components.spec.tsx'],
    environment: 'jsdom',
    setupFiles: ['./tests/public/setup.ts'],
    globals: true
  }
});