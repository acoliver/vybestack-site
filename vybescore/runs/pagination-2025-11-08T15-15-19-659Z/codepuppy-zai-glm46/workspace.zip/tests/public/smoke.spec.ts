import { describe, expect, it, beforeEach } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeEach(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns default pagination metadata', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('respects page parameter', async () => {
    const response = await request(app).get('/inventory?page=2');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.items).toHaveLength(5);
    // Should get items 6-10 (second page)
    expect(response.body.items[0].id).toBe(6);
  });

  it('respects limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(3);
    expect(response.body.items).toHaveLength(3);
    // Should get items 1-3
    expect(response.body.items[0].id).toBe(1);
  });

  it('respects both page and limit parameters', async () => {
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items).toHaveLength(3);
    // Should get items 4-6 (page 2 with limit 3)
    expect(response.body.items[0].id).toBe(4);
  });

  it('returns correct hasNext flag for last page', async () => {
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.hasNext).toBe(false);
    expect(response.body.items).toHaveLength(5);
  });

  it('validates non-numeric page parameter', async () => {
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page parameter must be a valid number');
  });

  it('validates non-numeric limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit parameter must be a valid number');
  });

  it('validates zero page parameter', async () => {
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page parameter must be greater than 0');
  });

  it('validates zero limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit parameter must be greater than 0');
  });

  it('validates negative page parameter', async () => {
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page parameter must be greater than 0');
  });

  it('validates negative limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit parameter must be greater than 0');
  });

  it('validates excessive page parameter', async () => {
    const response = await request(app).get('/inventory?page=1001');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page parameter cannot exceed 1000');
  });

  it('validates excessive limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit parameter cannot exceed 100');
  });

  it('handles empty page parameter', async () => {
    const response = await request(app).get('/inventory?page=');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page parameter must be a valid number');
  });

  it('handles empty limit parameter', async () => {
    const response = await request(app).get('/inventory?limit=');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit parameter must be a valid number');
  });

  it('returns empty items array for page beyond available data', async () => {
    const response = await request(app).get('/inventory?page=10&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(10);
    expect(response.body.limit).toBe(5);
    expect(response.body.items).toHaveLength(0);
    expect(response.body.hasNext).toBe(false);
  });
});
