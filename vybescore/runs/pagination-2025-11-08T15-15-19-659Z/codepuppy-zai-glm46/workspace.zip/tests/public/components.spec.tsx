import { describe, expect, it, beforeEach, afterEach, vi } from 'vitest';
import { render, fireEvent } from '@testing-library/react';
import { InventoryView } from '../../src/client/InventoryView';

describe('React components (client smoke)', () => {
  // Mock fetch for React component tests
  const mockFetch = vi.fn();
  let originalFetch: typeof global.fetch;

  beforeEach(() => {
    originalFetch = global.fetch;
    global.fetch = mockFetch;
  });

  afterEach(() => {
    global.fetch = originalFetch;
    mockFetch.mockReset();
  });

  it('should render loading state initially', async () => {
    mockFetch.mockImplementation(async () => ({
      ok: true,
      json: async () => ({
        items: [],
        page: 1,
        limit: 5,
        total: 15,
        hasNext: true
      })
    }));

    const { getByText } = render(<InventoryView />);
    expect(getByText('Loading inventory…')).toBeInTheDocument();
  });

  it('should render inventory items when data is loaded', async () => {
    const mockData = {
      items: [
        { id: 1, name: 'Notebook', sku: 'NB-001', priceCents: 799, createdAt: '2024-01-01T09:00:00.000Z' },
        { id: 2, name: 'Mechanical Keyboard', sku: 'KB-235', priceCents: 12999, createdAt: '2024-01-02T12:30:00.000Z' }
      ],
      page: 1,
      limit: 5,
      total: 15,
      hasNext: true
    };

    mockFetch.mockImplementation(async () => ({
      ok: true,
      json: async () => mockData
    }));

    const { findByText, getByText } = render(<InventoryView />);
    await findByText('Notebook');
    expect(getByText('Notebook')).toBeInTheDocument();
    expect(getByText('Mechanical Keyboard')).toBeInTheDocument();
    expect(getByText('Page 1')).toBeInTheDocument();
  });

  it('should render error state when request fails', async () => {
    mockFetch.mockImplementation(async () => ({
      ok: false,
      json: async () => ({ error: 'Page parameter must be greater than 0' }),
      status: 400
    }));

    const { findByText } = render(<InventoryView />);
    const errorMessage = await findByText('Page parameter must be greater than 0');
    expect(errorMessage).toBeInTheDocument();
    expect(errorMessage).toHaveAttribute('role', 'alert');
  });

  it('should handle pagination navigation', async () => {
    const mockDataPage1 = {
      items: [
        { id: 1, name: 'Notebook', sku: 'NB-001', priceCents: 799, createdAt: '2024-01-01T09:00:00.000Z' }
      ],
      page: 1,
      limit: 5,
      total: 15,
      hasNext: true
    };

    const mockDataPage2 = {
      items: [
        { id: 6, name: 'USB-C Hub', sku: 'HB-611', priceCents: 2599, createdAt: '2024-01-05T11:20:00.000Z' }
      ],
      page: 2,
      limit: 5,
      total: 15,
      hasNext: true
    };

    mockFetch
      .mockImplementationOnce(async () => ({
        ok: true,
        json: async () => mockDataPage1
      }))
      .mockImplementationOnce(async () => ({
        ok: true,
        json: async () => mockDataPage2
      }));

    const { findByText, getByText, getByLabelText } = render(<InventoryView />);
    
    await findByText('Page 1');
    
    const nextButton = getByLabelText('Next page');
    expect(nextButton).not.toBeDisabled();
    
    fireEvent.click(nextButton);
    
    await findByText('USB-C Hub');
    expect(getByText('Page 2')).toBeInTheDocument();
    
    // Verify the correct API call was made
    expect(mockFetch).toHaveBeenCalledWith('/inventory?page=2&limit=5');
  });

  it('should disable Previous button on first page', async () => {
    const mockData = {
      items: [
        { id: 1, name: 'Notebook', sku: 'NB-001', priceCents: 799, createdAt: '2024-01-01T09:00:00.000Z' }
      ],
      page: 1,
      limit: 5,
      total: 15,
      hasNext: true
    };

    mockFetch.mockImplementation(async () => ({
      ok: true,
      json: async () => mockData
    }));

    const { findByText, getByLabelText } = render(<InventoryView />);
    
    await findByText('Page 1');
    
    const previousButton = getByLabelText('Previous page');
    expect(previousButton).toBeDisabled();
  });

  it('should disable Next button on last page', async () => {
    // Mock last page data (hasNext: false)
    const mockDataFirstPage = {
      items: [
        { id: 1, name: 'Notebook', sku: 'NB-001', priceCents: 799, createdAt: '2024-01-01T09:00:00.000Z' }
      ],
      page: 1,
      limit: 5,
      total: 5,
      hasNext: false
    };

    mockFetch.mockImplementation(async () => ({
      ok: true,
      json: async () => mockDataFirstPage
    }));

    const { findByText, getByLabelText } = render(<InventoryView />);
    
    await findByText('Page 1');
    
    const nextButton = getByLabelText('Next page');
    expect(nextButton).toBeDisabled();
  });

  it('should render empty state when no items', async () => {
    const mockData = {
      items: [],
      page: 1,
      limit: 5,
      total: 0,
      hasNext: false
    };

    mockFetch.mockImplementation(async () => ({
      ok: true,
      json: async () => mockData
    }));

    const { findByText } = render(<InventoryView />);
    
    const emptyMessage = await findByText('No inventory items found.');
    expect(emptyMessage).toBeInTheDocument();
  });
});