You are assisting with the "Pagination Service Repair" TypeScript project.
Restore correct pagination behaviour across the Express API (SQLite-backed) and the React client. Validate `page`/`limit`, return accurate metadata, and ensure the UI navigates between pages while showing errors for invalid input.
Do not fabricate test results; report any command output that fails.

Problem context:

# Pagination Service Repair

This project contains a small Express API backed by SQLite and a minimal React client rendered through tests. The current implementation is missing critical pagination behavior.

## Requirements

- `GET /inventory` must accept `page` and `limit` query parameters (default `page = 1`, `limit = 5`).
  - Validate inputs: reject non-numeric, negative, zero, or excessive values with HTTP 400.
  - Query must return the correct slice of items without skipping or duplicating rows.
  - Response should include pagination metadata: `page`, `limit`, `total`, `hasNext`.
- React hook/component must request the selected page, update when the user navigates, and surface errors.
  - Provide “Previous” and “Next” controls that disable appropriately when there is no further data.
  - Ensure the UI renders empty states and propagates server validation errors.
- Keep the database bootstrap (`createDatabase`) intact so tests can create a fresh DB each run, but feel free to add helpers.

## Commands

```bash
npm install
npm run typecheck
npm run lint
npm run test:public
```

Expect thorough review runs that exercise the API via Supertest and the React components via Testing Library with in-memory SQLite databases. Plan to coordinate edits across server, shared types, and client files to satisfy all requirements.


Before finishing, run these commands and report any failures honestly:
npm run typecheck, npm run lint, npm run test:public, npm run build

IMPORTANT: You must run lint and the build as a final step and resolve ANY lint or build errors before finishing.
Fix all ESLint errors (unused variables, any types, etc.) and ensure the build completes successfully.

### Remediation Guidance
- It isn't working correctly.
- Your previous attempt exited with code 1. Review the CLI logs to diagnose the issue.
- Please resolve the issues and re-run lint, tests, and build before finishing.
