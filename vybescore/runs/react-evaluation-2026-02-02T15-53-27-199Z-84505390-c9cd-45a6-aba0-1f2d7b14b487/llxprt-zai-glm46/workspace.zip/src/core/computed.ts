/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  EqualFn,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject to track observers of this computed value
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value: value as T,
  }
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev) => {
      const newValue = updateFn(prev)
      subject.value = newValue
      // Notify all observers of this computed value
      subject.observers.forEach(obs => {
        if (obs !== o) { // Don't notify ourselves
          updateObserver(obs as Observer<unknown>)
        }
      })
      return newValue
    },
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register the current observer to be notified when this computed value changes
      subject.observers.add(observer)
      // If this is a callback being tracked, add this subject to its dependencies
      const callbackSubjects = (globalThis as unknown as { __llxprt_current_callback_subjects__?: Set<Subject<unknown>> }).__llxprt_current_callback_subjects__
      if (callbackSubjects) {
        callbackSubjects.add(subject as Subject<unknown>)
      }
    }
    return subject.value
  }
  
  return read
}
