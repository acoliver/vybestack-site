/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject, ObserverR } from '../types/reactive.js'

// Track which subjects each callback observer is subscribed to
const callbackSubjectsMap = new WeakMap<ObserverR, Set<Subject<unknown>>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }

  // Track subjects this callback depends on
  const subjects = new Set<Subject<unknown>>()
  callbackSubjectsMap.set(observer as ObserverR, subjects)

  // Set the global tracking variable so subjects can register themselves
  ;(globalThis as unknown as { __llxprt_current_callback_subjects__?: Set<Subject<unknown>> }).__llxprt_current_callback_subjects__ = subjects

  // Initial execution to establish dependencies
  updateObserver(observer)

  // Clear the global tracking variable
  ;(globalThis as unknown as { __llxprt_current_callback_subjects__?: Set<Subject<unknown>> }).__llxprt_current_callback_subjects__ = undefined

  let disposed = false

  return () => {
    if (disposed) return
    disposed = true

    // Remove this observer from all tracked subjects
    subjects.forEach(subject => {
      subject.observers.delete(observer as ObserverR)
    })
    subjects.clear()
    callbackSubjectsMap.delete(observer as ObserverR)

    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
