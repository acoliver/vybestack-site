import { useEffect, useState } from 'react';
import type { InventoryPage } from '../shared/types';

interface InventoryState {
  status: 'idle' | 'loading' | 'ready' | 'error';
  data: InventoryPage | null;
  error: string | null;
}

const INITIAL_STATE: InventoryState = {
  status: 'idle',
  data: null,
  error: null
};

export function useInventory(page: number, limit: number): InventoryState & { refetch: () => void } {
  const [state, setState] = useState<InventoryState>(INITIAL_STATE);

  const fetchData = async (pageNum: number, limitNum: number): Promise<void> => {
    setState((prev) => ({ ...prev, status: 'loading', error: null }));
    try {
      const queryParams = new URLSearchParams({
        page: pageNum.toString(),
        limit: limitNum.toString()
      });
      const response = await fetch(`/inventory?${queryParams}`);
      
      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        const errorMessage = errorData.error || `Request failed with status ${response.status}`;
        throw new Error(errorMessage);
      }
      
      const payload = (await response.json()) as InventoryPage;
      setState({ status: 'ready', data: payload, error: null });
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error';
      setState((prev) => ({ ...prev, status: 'error', error: message }));
    }
  };

  useEffect(() => {
    if (state.status === 'idle') {
      fetchData(page, limit);
    }
  }, [page, limit, state.status]);

  const refetch = (): void => {
    fetchData(page, limit);
  };

  return { ...state, refetch };
}