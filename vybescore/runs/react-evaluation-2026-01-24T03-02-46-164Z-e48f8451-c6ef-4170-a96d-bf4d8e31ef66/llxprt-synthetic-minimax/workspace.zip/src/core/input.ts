/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  InputNode,
  getActiveNode,
  registerDependency,
  markStale,
  notifyNode,
  Options,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const node: InputNode<T> = {
    name: options?.name,
    value,
    observers: new Set(),
    isStale: false,
    equalFn: undefined,
  }

  const read = () => {
    const activeNode = getActiveNode()
    if (activeNode) {
      registerDependency(node, activeNode)
    }
    return node.value
  }

  const write = (nextValue: T) => {
    node.value = nextValue
    
    // Propagate the change through the reactive graph
    propagateChange(node as unknown as import('../types/reactive.js').InputNode<unknown>)
    
    return node.value
  }

  return [read, write]
}

function propagateChange(inputNode: InputNode<unknown>): void {
  // Mark all dependent nodes as stale
  markStale(inputNode)
  
  // Collect all dependent computed nodes for processing
  const dependentNodes = new Set<import('../types/reactive.js').ReactiveNode>()
  
  // Collect all observers (computed nodes and callbacks) - filter disposed ones
  for (const observer of [...inputNode.observers]) {
    // Only collect non-disposed observers
    if (!isNodeDisposed(observer)) {
      collectDependentNodes(observer, dependentNodes)
    }
  }
  
  // Process all dependent computed nodes
  for (const node of dependentNodes) {
    // Only notify active (non-disposed) observers
    if (!isNodeDisposed(node)) {
      notifyNode(node as import('../types/reactive.js').ComputedNode<unknown>)
    }
  }
}

function isNodeDisposed(node: import('../types/reactive.js').ReactiveNode | null | undefined): boolean {
  if (!node) return false
  return 'disposed' in node && node.disposed === true
}

function collectDependentNodes(node: import('../types/reactive.js').ReactiveNode | null | undefined, collected: Set<import('../types/reactive.js').ReactiveNode>): void {
  if (!node || collected.has(node) || isNodeDisposed(node)) return
  
  collected.add(node)
  
  // Recursively collect all observers
  if ('observers' in node && node.observers) {
    for (const observer of [...node.observers]) {
      if (!isNodeDisposed(observer)) {
        collectDependentNodes(observer, collected)
      }
    }
  }
}

// Helper function to properly establish bidirectional dependencies  
function registerComputedDependency(computedNode: import('../types/reactive.js').ComputedNode<unknown>, activeNode: import('../types/reactive.js').ReactiveNode): void {
  // Register the active node as observer of the computed node
  computedNode.observers.add(activeNode)
  
  // Track dependency from computed to active node for cleanup
  if ('dependencies' in computedNode) {
    computedNode.dependencies.add(activeNode)
  }
}
