/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  ComputedNode,
  getActiveNode,
  setActiveNode,
  registerDependency,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create computed node
  const node: ComputedNode<T> = {
    name: options?.name,
    value: value as T,
    updateFn,
    observers: new Set(),
    dependencies: new Set(),
    isStale: true
  }

  // Function to evaluate the computed value
  const evaluateNode = () => {
    const previousNode = getActiveNode()
    
    try {
      // Set this computed as active during evaluation
      setActiveNode(node)
      
      // Clear dependencies tracking for fresh evaluation
      node.dependencies.clear()
      
      // Evaluate the function to get new value
      const newValue = node.updateFn(node.value)
      node.value = newValue
      node.isStale = false
      
      return newValue
    } finally {
      // Restore previous active node
      setActiveNode(previousNode)
    }
  }

  // Initial evaluation to set up dependencies
  evaluateNode()

  const read: GetterFn<T> = () => {
    const activeNode = getActiveNode()
    if (activeNode && activeNode !== node) {
      // Register this computed as dependency of the active node
      registerDependency(node, activeNode)
      
      // Also register active node as observer of this computed
      node.observers.add(activeNode)
      
      // Track dependency in both directions for proper cleanup
      if ('dependencies' in node) {
        node.dependencies.add(activeNode)
      }
    }
    
    // Re-evaluate if stale
    if (node.isStale) {
      evaluateNode()
    }
    
    return node.value!
  }

  return read
}
