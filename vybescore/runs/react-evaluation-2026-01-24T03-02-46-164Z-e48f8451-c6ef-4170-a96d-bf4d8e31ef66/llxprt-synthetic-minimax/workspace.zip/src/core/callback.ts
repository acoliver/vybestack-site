/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  CallbackNode,
  getActiveNode,
  setActiveNode,
  registerDependency,
  unregisterDependency,
  UpdateFn
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create callback node that tracks dependencies
  const node: CallbackNode = {
    name: 'callback',
    value: value as unknown,
    updateFn: updateFn as (value?: unknown) => unknown,
    observers: new Set(),
    dependencies: new Set(),
    isStale: false,
    disposed: false
  }

  // Function to execute the callback
  const executeCallback = () => {
    // Don't execute if disposed
    if (node.disposed) return
    
    const previousNode = getActiveNode()
    
    try {
      // Set this callback as active during evaluation
      setActiveNode(node)
      
      // Execute the update function - this establishes dependencies
      node.updateFn(node.value)
      
    } finally {
      // Restore previous active node
      setActiveNode(previousNode)
    }
    
    // Mark as not stale after successful execution
    node.isStale = false
  }

  // Execute callback to establish dependencies
  executeCallback()

  // Track the active node after execution for proper cleanup
  const callbackActiveNode = getActiveNode()
  if (callbackActiveNode && callbackActiveNode !== node) {
    registerDependency(callbackActiveNode, node)
    // Also track this dependency in the callback's own dependencies set
    node.dependencies.add(callbackActiveNode)
  }

  const unsubscribe = () => {
    if (node.disposed) return
    node.disposed = true
    
    // Remove this callback from all dependency nodes
    for (const dep of [...node.dependencies]) {
      // Remove from dependency's observer set
      if ('observers' in dep) {
        dep.observers.delete(node)
      }
      unregisterDependency(dep, node)
    }
    
    // Also remove this callback from the active node that created it
    if (callbackActiveNode && 'observers' in callbackActiveNode) {
      callbackActiveNode.observers.delete(node)
      unregisterDependency(callbackActiveNode, node)
    }
    
    // Clear dependencies to stop being notified of changes
    node.dependencies.clear()
    
    // Clear observers to break the notification chain
    node.observers.clear()
    
    // Mark as stale to prevent further execution
    node.isStale = true
  }

  return unsubscribe
}
