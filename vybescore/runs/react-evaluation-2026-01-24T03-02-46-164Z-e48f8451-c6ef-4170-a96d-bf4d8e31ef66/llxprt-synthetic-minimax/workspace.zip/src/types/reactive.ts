/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Legacy types for backward compatibility
export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Modern reactive node types
export type ReactiveNode = {
  name?: string
  observers: Set<ReactiveNode>
  isStale: boolean
}

export type InputNode<T> = ReactiveNode & {
  value: T
  equalFn?: EqualFn<T>
}

export type ComputedNode<T> = ReactiveNode & {
  value: T
  updateFn: UpdateFn<T>
  dependencies: Set<ReactiveNode>
}

export type CallbackNode = ComputedNode<unknown> & {
  disposed: boolean
}

let activeNode: ReactiveNode | undefined

export function getActiveNode(): ReactiveNode | undefined {
  return activeNode
}

export function setActiveNode(node: ReactiveNode | undefined): void {
  activeNode = node
}

export function registerDependency(subject: ReactiveNode, observer: ReactiveNode): void {
  subject.observers.add(observer)
}

export function unregisterDependency(subject: ReactiveNode, observer: ReactiveNode): void {
  subject.observers.delete(observer)
}

export function markStale(node: ReactiveNode): void {
  if (!node.isStale) {
    node.isStale = true
    
    // Recursively mark all observers as stale, skipping disposed ones
    for (const observer of [...node.observers]) {
      // Skip disposed observers
      if ('disposed' in observer && (observer as CallbackNode).disposed) {
        continue
      }
      markStale(observer)
    }
  }
}

export function notifyNode(node: ComputedNode<unknown>): void {
  // Only notify non-disposed nodes
  if ('disposed' in node && (node as CallbackNode).disposed) return
  
  // Trigger re-evaluation for computed nodes
  if (node !== getActiveNode() && 'updateFn' in node) {
    if (node.isStale && 'value' in node) {
      node.isStale = false
      
      // Re-evaluate the computed function
      const newValue = node.updateFn(node.value)
      node.value = newValue
      
      // Notify all observers of this node, filtering disposed ones
      for (const observer of [...node.observers]) {
        // Skip disposed observers
        if ('disposed' in observer && (observer as CallbackNode).disposed) {
          continue
        }
        notifyNode(observer as ComputedNode<unknown>)
      }
    }
  }
}

export function collectDependentNodes(node: ReactiveNode | null | undefined, collected: Set<ReactiveNode>): void {
  if (!node || collected.has(node) || ('disposed' in node && (node as CallbackNode).disposed)) return
  
  collected.add(node)
  
  // Recursively collect all observers, skipping disposed ones
  if ('observers' in node && node.observers) {
    for (const observer of [...node.observers]) {
      // Skip disposed observers during collection
      if ('disposed' in observer && (observer as CallbackNode).disposed) {
        continue
      }
      collectDependentNodes(observer, collected)
    }
  }
}
