/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

// Track which subjects each observer depends on
const observerToSubjects = new WeakMap<ObserverR, Set<Subject<unknown>>>()

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Initialize observer's observers set if needed
      if (!observer.observers) {
        observer.observers = new Set()
      }
      // Track the reverse relationship
      let subjects = observerToSubjects.get(observer)
      if (!subjects) {
        subjects = new Set()
        observerToSubjects.set(observer, subjects)
      }
      subjects.add(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers
    s.observers.forEach(observer => updateObserver(observer as Observer<unknown>))
    return s.value
  }

  return [read, write]
}

// Export the WeakMap for use in callback.ts
export { observerToSubjects }
