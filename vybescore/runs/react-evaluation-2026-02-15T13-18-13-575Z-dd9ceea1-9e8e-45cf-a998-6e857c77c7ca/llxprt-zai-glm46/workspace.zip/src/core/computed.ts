/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR,
  Subject
} from '../types/reactive.js'

// Track which subjects each observer depends on
const observerToSubjects = new WeakMap<ObserverR, Set<Subject<unknown>>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  updateObserver(o)
  
  // Return a getter that tracks dependencies
  return (): T => {
    const observer = getActiveObserver()
    if (observer) {
      o.observers!.add(observer)
      // Track the reverse relationship
      let subjects = observerToSubjects.get(observer)
      if (!subjects) {
        subjects = new Set()
        observerToSubjects.set(observer, subjects)
      }
      subjects.add(o as Subject<unknown>)
    }
    return o.value!
  }
}

// Export the WeakMap for use in callback.ts
export { observerToSubjects }
