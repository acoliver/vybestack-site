import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (pagination)', () => {
  it('returns first page by default', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items[0].id).toBe(1); // First item
  });

  it('returns second page correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.items[0].id).toBe(6); // Second page starts at item 6
    expect(response.body.hasNext).toBe(true);
  });

  it('returns last page without next', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.items.length).toBe(5);
    expect(response.body.items[0].id).toBe(11); // Third page starts at item 11
    expect(response.body.hasNext).toBe(false);
  });

  it('validates page parameter - rejects page 0', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('page');
  });

  it('validates limit parameter - rejects limit over 100', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=150');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('limit');
  });

  it('validates page parameter - rejects non-numeric', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('page');
  });

  it('handles empty page gracefully', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    // Page beyond available data
    const response = await request(app).get('/inventory?page=10&limit=5');
    
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.page).toBe(10);
    expect(response.body.hasNext).toBe(false);
  });

  it('calculates pagination correctly for different limits', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBe(3);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.total).toBe(15);
  });
});