import request from 'supertest';
import { createApp } from '../src/server/app.js';
import { createDatabase } from '../src/server/db.js';

async function testApiPagination() {
  console.log('Testing API pagination...');
  
  try {
    // Create database and app
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test 1: Default pagination (page 1, limit 5)
    console.log('\nTest 1: Default pagination');
    let response = await request(app).get('/inventory');
    console.log('Status:', response.status);
    console.log('Items:', response.body.items?.length || 0);
    console.log('Page:', response.body.page);
    console.log('Limit:', response.body.limit);
    console.log('Total:', response.body.total);
    console.log('Has Next:', response.body.hasNext);
    console.log('First item ID:', response.body.items?.[0]?.id);
    console.log('Last item ID:', response.body.items?.[response.body.items.length - 1]?.id);
    
    // Test 2: Page 2
    console.log('\nTest 2: Page 2');
    response = await request(app).get('/inventory?page=2&limit=5');
    console.log('Status:', response.status);
    console.log('Items:', response.body.items?.length || 0);
    console.log('Page:', response.body.page);
    console.log('First item ID:', response.body.items?.[0]?.id);
    console.log('Last item ID:', response.body.items?.[response.body.items.length - 1]?.id);
    
    // Test 3: Invalid page (should return 400)
    console.log('\nTest 3: Invalid page (0)');
    response = await request(app).get('/inventory?page=0');
    console.log('Status:', response.status);
    console.log('Error:', response.body);
    
    // Test 4: Invalid limit (should return 400)
    console.log('\nTest 4: Invalid limit (150)');
    response = await request(app).get('/inventory?limit=150');
    console.log('Status:', response.status);
    console.log('Error:', response.body);
    
    // Test 5: Non-numeric page (should return 400)
    console.log('\nTest 5: Non-numeric page (abc)');
    response = await request(app).get('/inventory?page=abc');
    console.log('Status:', response.status);
    console.log('Error:', response.body);
    
    // Test 6: Last page
    console.log('\nTest 6: Last page (page 3)');
    response = await request(app).get('/inventory?page=3&limit=5');
    console.log('Status:', response.status);
    console.log('Items:', response.body.items?.length || 0);
    console.log('Has Next:', response.body.hasNext);
    console.log('First item ID:', response.body.items?.[0]?.id);
    
    // Test 7: Different limit
    console.log('\nTest 7: Limit 3');
    response = await request(app).get('/inventory?page=1&limit=3');
    console.log('Status:', response.status);
    console.log('Items:', response.body.items?.length || 0);
    console.log('Limit:', response.body.limit);
    console.log('Has Next:', response.body.hasNext);
    
    console.log('\nAll API tests completed!');
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testApiPagination();