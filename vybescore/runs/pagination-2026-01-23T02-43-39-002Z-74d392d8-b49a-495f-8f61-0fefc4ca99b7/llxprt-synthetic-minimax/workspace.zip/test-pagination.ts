import { createApp } from './src/server/app.js';
import { createDatabase } from './src/server/db.js';
import fetch from 'node-fetch';

async function testPagination(): Promise<void> {
  console.log('Testing pagination implementation...');
  
  try {
    // Create database and app
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Start server on test port
    const port = 3334;
    const server = app.listen(port, () => {
      console.log(`Test server running on http://localhost:${port}`);
    });
    
    // Wait for server to start
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Test 1: Default pagination (page 1, limit 5)
    console.log('\nTest 1: Default pagination');
    let response = await fetch(`http://localhost:${port}/inventory`);
    let data = await response.json();
    console.log('Status:', response.status);
    console.log('Items:', data.items?.length || 0);
    console.log('Page:', data.page);
    console.log('Limit:', data.limit);
    console.log('Total:', data.total);
    console.log('Has Next:', data.hasNext);
    
    // Test 2: Page 2
    console.log('\nTest 2: Page 2');
    response = await fetch(`http://localhost:${port}/inventory?page=2&limit=5`);
    data = await response.json();
    console.log('Status:', response.status);
    console.log('Items:', data.items?.length || 0);
    console.log('Page:', data.page);
    console.log('First item ID:', data.items?.[0]?.id);
    
    // Test 3: Invalid page (should return 400)
    console.log('\nTest 3: Invalid page (0)');
    response = await fetch(`http://localhost:${port}/inventory?page=0`);
    console.log('Status:', response.status);
    if (!response.ok) {
      const error = await response.json();
      console.log('Error:', error);
    }
    
    // Test 4: Invalid limit (should return 400)
    console.log('\nTest 4: Invalid limit (150)');
    response = await fetch(`http://localhost:${port}/inventory?limit=150`);
    console.log('Status:', response.status);
    if (!response.ok) {
      const error = await response.json();
      console.log('Error:', error);
    }
    
    // Test 5: Non-numeric page (should return 400)
    console.log('\nTest 5: Non-numeric page (abc)');
    response = await fetch(`http://localhost:${port}/inventory?page=abc`);
    console.log('Status:', response.status);
    if (!response.ok) {
      const error = await response.json();
      console.log('Error:', error);
    }
    
    // Test 6: Last page
    console.log('\nTest 6: Last page (page 3)');
    response = await fetch(`http://localhost:${port}/inventory?page=3&limit=5`);
    data = await response.json();
    console.log('Status:', response.status);
    console.log('Items:', data.items?.length || 0);
    console.log('Has Next:', data.hasNext);
    
    server.close();
    console.log('\nAll tests completed!');
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testPagination();