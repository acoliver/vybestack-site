import { createDatabase } from './src/server/db.js';
import { listInventory } from './src/server/inventoryRepository.js';

async function testPagination() {
  console.log('Testing pagination implementation...');
  
  try {
    // Create database
    const db = await createDatabase();
    
    console.log('\nTest 1: Default pagination (page 1, limit 5)');
    let result = listInventory(db, { page: 1, limit: 5 });
    console.log('Page:', result.page);
    console.log('Limit:', result.limit);
    console.log('Items:', result.items.length);
    console.log('Total:', result.total);
    console.log('Has Next:', result.hasNext);
    console.log('First item ID:', result.items[0]?.id);
    console.log('Last item ID:', result.items[result.items.length - 1]?.id);
    
    console.log('\nTest 2: Page 2');
    result = listInventory(db, { page: 2, limit: 5 });
    console.log('Page:', result.page);
    console.log('Items:', result.items.length);
    console.log('First item ID:', result.items[0]?.id);
    console.log('Last item ID:', result.items[result.items.length - 1]?.id);
    
    console.log('\nTest 3: Page 3 (last page)');
    result = listInventory(db, { page: 3, limit: 5 });
    console.log('Page:', result.page);
    console.log('Items:', result.items.length);
    console.log('Has Next:', result.hasNext);
    console.log('First item ID:', result.items[0]?.id);
    
    console.log('\nTest 4: Large limit');
    result = listInventory(db, { page: 1, limit: 20 });
    console.log('Limit:', result.limit);
    console.log('Items:', result.items.length);
    console.log('Has Next:', result.hasNext);
    
    console.log('\nTest 5: Edge case - page beyond data');
    result = listInventory(db, { page: 10, limit: 5 });
    console.log('Page:', result.page);
    console.log('Items:', result.items.length);
    console.log('First item:', result.items[0]);
    
    console.log('\nTest 6: Validation - page 0 should default to 1');
    result = listInventory(db, { page: 0, limit: 5 });
    console.log('Page:', result.page);
    console.log('Items:', result.items.length);
    
    console.log('\nTest 7: Validation - limit 0 should default to 5');
    result = listInventory(db, { page: 1, limit: 0 });
    console.log('Limit:', result.limit);
    console.log('Items:', result.items.length);
    
    console.log('\nAll repository tests passed!');
    
  } catch (error) {
    console.error('Test failed:', error);
  }
}

testPagination();