import { describe, it, expect, beforeEach } from 'vitest'
import { createInput, createComputed } from '../../src/index.js'
import { clearDependencies } from '../../src/core/reactive-system.js'

describe('Debug Reactive System', () => {
  beforeEach(() => {
    clearDependencies()
  })

  it('debug basic computed dependency', () => {
    const [input, setInput] = createInput(1)
    const timesTwo = createComputed(() => input() * 2)
    const timesThirty = createComputed(() => input() * 30)
    const sum = createComputed(() => timesTwo() + timesThirty())
    
    console.log('Initial:')
    console.log('  input:', input())
    console.log('  timesTwo:', timesTwo())
    console.log('  timesThirty:', timesThirty())
    console.log('  sum:', sum())
    
    expect(sum()).toBe(32)
    
    setInput(3)
    
    console.log('After setInput(3):')
    console.log('  input:', input())
    console.log('  timesTwo:', timesTwo())
    console.log('  timesThirty:', timesThirty())
    console.log('  sum:', sum())
    
    expect(sum()).toBe(96)
  })
})