import { getActiveObserver, setActiveObserver, updateObserver, ObserverR } from '../types/reactive.js'

// Override the reactive functions globally
;(global as unknown as { getActiveObserver: () => ObserverR | undefined }).getActiveObserver = getActiveObserver
;(global as unknown as { setActiveObserver: (obs: ObserverR | undefined) => void }).setActiveObserver = setActiveObserver
;(global as unknown as { updateObserver: typeof updateObserver }).updateObserver = updateObserver