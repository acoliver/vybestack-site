import { ObserverR } from '../types/reactive.js'

// Global reactive system state
const dependencyGraph = new Map<ObserverR, Set<ObserverR>>()
const callbacks = new Set<ObserverR>()

export function addDependency(from: ObserverR, to: ObserverR): void {
  if (!dependencyGraph.has(from)) {
    dependencyGraph.set(from, new Set())
  }
  dependencyGraph.get(from)!.add(to)
}

export function removeDependency(from: ObserverR, to: ObserverR): void {
  const deps = dependencyGraph.get(from)
  if (deps) {
    deps.delete(to)
    if (deps.size === 0) {
      dependencyGraph.delete(from)
    }
  }
}

export function notifyObservers(observer: ObserverR): void {
  // Get all observers that depend on this one
  const dependents: ObserverR[] = []
  
  for (const [observerKey, deps] of dependencyGraph.entries()) {
    if (deps.has(observer)) {
      dependents.push(observerKey)
    }
  }

  // Notify dependents by triggering their onDependencyChange
  for (const dependent of dependents) {
    if (dependent.onDependencyChange) {
      dependent.onDependencyChange()
    }
  }

  // Also notify callbacks (they are special observers that always run)
  for (const callback of callbacks) {
    if (callback.onDependencyChange) {
      callback.onDependencyChange()
    }
  }
}

export function registerCallback(callback: ObserverR): void {
  callbacks.add(callback)
}

export function unregisterCallback(callback: ObserverR): void {
  callbacks.delete(callback)
}

// Debug function to inspect the current state
export function debugState(): { dependencyGraph: Map<ObserverR, Set<ObserverR>>, callbacks: Set<ObserverR> } {
  return {
    dependencyGraph: new Map(dependencyGraph),
    callbacks: new Set(callbacks)
  }
}

// Clear all dependencies (useful for testing)
export function clearDependencies(): void {
  dependencyGraph.clear()
  callbacks.clear()
}