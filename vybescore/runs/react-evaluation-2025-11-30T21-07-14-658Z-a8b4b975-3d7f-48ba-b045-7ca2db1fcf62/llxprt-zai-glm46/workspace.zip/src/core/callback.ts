import { UnsubscribeFn, UpdateFn, Observer, ObserverR } from '../types/reactive.js'
import { registerCallback, unregisterCallback } from './reactive-system.js'

export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    updateFn,
    value,
    onDependencyChange: () => {
      // Execute the callback when dependencies change
      observer.value = observer.updateFn(observer.value)
    }
  }

  // Register this callback
  registerCallback(observer)

  // Execute the callback immediately to establish dependencies
  const previous = (global as unknown as { getActiveObserver: () => ObserverR | undefined }).getActiveObserver()
  ;(global as unknown as { setActiveObserver: (obs: ObserverR | undefined) => void }).setActiveObserver(observer)
  observer.value = observer.updateFn(observer.value)
  ;(global as unknown as { setActiveObserver: (obs: ObserverR | undefined) => void }).setActiveObserver(previous)

  const unsubscribe = (): void => {
    unregisterCallback(observer)
  }

  return unsubscribe
}