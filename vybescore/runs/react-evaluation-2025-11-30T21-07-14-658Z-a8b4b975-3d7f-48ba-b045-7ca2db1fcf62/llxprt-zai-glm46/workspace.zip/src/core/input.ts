import { EqualFn, InputPair, Options, Subject, ObserverR } from '../types/reactive.js'
import { notifyObservers, addDependency } from './reactive-system.js'

function defaultEqual<T>(a: T, b: T): boolean {
  return a === b
}

export function createInput<T>(value: T, equal?: EqualFn<T>, options?: Options): InputPair<T> {
  const equalFn = equal || defaultEqual
  
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn
  }

  const inputObserver: ObserverR = {
    name: options?.name
  }

  const getter = (): T => {
    const activeObserver = (global as unknown as { getActiveObserver: () => ObserverR | undefined }).getActiveObserver()
    if (activeObserver) {
      // Track that active observer depends on this input
      addDependency(activeObserver, inputObserver)
    }
    return subject.value
  }

  const setter = (newValue: T): T => {
    if (!equalFn(subject.value, newValue)) {
      subject.value = newValue
      
      // Notify all observers that this input changed
      notifyObservers(inputObserver)
    }
    return subject.value
  }

  return [getter, setter]
}