import { GetterFn, Options, Observer, UpdateFn, ObserverR } from '../types/reactive.js'
import { addDependency, notifyObservers } from './reactive-system.js'

export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: (a: T, b: T) => boolean,
  options?: Options
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn
  }

  let isComputing = false
  let isDirty = true

  // Add onDependencyChange to mark this computed as dirty and notify dependents
  observer.onDependencyChange = () => {
    if (!isComputing) {
      isDirty = true
      // Notify all observers that depend on this computed
      notifyObservers(observer)
    }
  }

  const getter = (): T => {
    const activeObserver = (global as unknown as { getActiveObserver: () => ObserverR | undefined }).getActiveObserver()
    if (activeObserver && activeObserver !== observer) {
      // Track that active observer depends on this computed
      addDependency(activeObserver, observer)
    }

    if (isDirty) {
      isComputing = true
      
      try {
        // Set this observer as active while computing to track dependencies
        (global as unknown as { setActiveObserver: (obs: ObserverR | undefined) => void }).setActiveObserver(observer)
        
        // Compute the new value
        observer.value = observer.updateFn(observer.value)
      } finally {
        isComputing = false
        // Restore previous observer
        ;(global as unknown as { setActiveObserver: (obs: ObserverR | undefined) => void }).setActiveObserver(undefined)
      }

      isDirty = false
    }

    return observer.value as T
  }

  return getter
}