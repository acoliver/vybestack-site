/**
 * Utility functions for report processing.
 */

import type { ReportData, ReportEntry } from './types.js';

/**
 * Validates report data structure.
 */
export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid field: title (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid field: summary (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid field: entries (expected array)');
  }

  const entries: ReportEntry[] = [];
  for (const [index, entry] of obj.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: expected object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid entry at index ${index}: missing or invalid label (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid entry at index ${index}: missing or invalid amount (expected number)`
      );
    }

    entries.push({
      label: entryObj.label,
      amount: entryObj.amount,
    });
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

/**
 * Formats an amount as a currency string with two decimal places.
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total of all entry amounts.
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}
