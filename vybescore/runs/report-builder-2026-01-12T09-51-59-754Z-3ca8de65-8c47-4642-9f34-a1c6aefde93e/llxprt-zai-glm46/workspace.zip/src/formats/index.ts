/**
 * Format registry - maps format names to renderer functions.
 */

import type { Renderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const FORMATS: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const SUPPORTED_FORMATS = Object.keys(FORMATS);
