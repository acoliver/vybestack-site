#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import { readFileSync, writeFileSync } from 'node:fs';
import { resolve } from 'node:path';
import { FORMATS } from '../formats/index.js';
import type { RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parses command-line arguments using Node's standard library.
 */
function parseArgs(args: string[]): CliArgs {
  const result: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    switch (arg) {
      case '--format':
        i++;
        if (i >= args.length) {
          throw new Error('--format requires a value');
        }
        result.format = args[i];
        break;

      case '--output':
        i++;
        if (i >= args.length) {
          throw new Error('--output requires a value');
        }
        result.outputPath = args[i];
        break;

      case '--includeTotals':
        result.includeTotals = true;
        break;

      default:
        if (arg.startsWith('--')) {
          throw new Error(`Unknown option: ${arg}`);
        }
        if (result.dataFile) {
          throw new Error(`Unexpected argument: ${arg}`);
        }
        result.dataFile = arg;
        break;
    }

    i++;
  }

  return result;
}

/**
 * Main CLI entry point.
 */
function main(): void {
  const args = process.argv.slice(2);

  try {
    const parsed = parseArgs(args);

    // Validate required arguments
    if (!parsed.dataFile) {
      console.error('Error: missing data file argument');
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }

    if (!parsed.format) {
      console.error('Error: --format is required');
      console.error('Supported formats: markdown, text');
      process.exit(1);
    }

    // Get renderer
    const renderer = FORMATS[parsed.format];
    if (!renderer) {
      console.error(`Error: Unsupported format: ${parsed.format}`);
      console.error('Supported formats: markdown, text');
      process.exit(1);
    }

    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const content = readFileSync(resolve(parsed.dataFile), 'utf-8');
      jsonData = JSON.parse(content);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: malformed JSON in ${parsed.dataFile}`);
        console.error(error.message);
      } else if (error instanceof Error) {
        console.error(`Error: cannot read file ${parsed.dataFile}`);
        console.error(error.message);
      } else {
        console.error(`Error: cannot read file ${parsed.dataFile}`);
      }
      process.exit(1);
    }

    // Validate report data
    const reportData = validateReportData(jsonData);

    // Render report
    const options: RenderOptions = {
      includeTotals: parsed.includeTotals,
    };
    const output = renderer(reportData, options);

    // Write output
    if (parsed.outputPath) {
      try {
        writeFileSync(resolve(parsed.outputPath), output, 'utf-8');
      } catch (error) {
        console.error(`Error: cannot write to ${parsed.outputPath}`);
        if (error instanceof Error) {
          console.error(error.message);
        }
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: an unknown error occurred');
    }
    process.exit(1);
  }
}

main();
