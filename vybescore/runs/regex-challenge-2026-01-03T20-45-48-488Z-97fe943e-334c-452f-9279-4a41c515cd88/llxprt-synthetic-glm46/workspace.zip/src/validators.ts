export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check: local@domain.tld
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
// Quick rejection for common invalid patterns
  const rejectPatterns = [
    /\.{2,}/,         // double dots anywhere
    /\.$/,           // trailing dot
    /^\./,           // leading dot
    /^@/,            // missing local part
    /@$/,            // missing domain
    /_/              // underscore not allowed in domain or local part
  ];

  // Check against reject patterns
  for (const pattern of rejectPatterns) {
    if (pattern.test(value)) return false;
  }

  // Check basic email structure
  if (!emailRegex.test(value)) return false;
  
  // More specific domain checks
  const domain = value.split('@')[1];
  if (!domain || domain.startsWith('.') || domain.endsWith('.'))
    return false;
  
  // Domain should not start or end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-'))
      return false;
  }

  return true;
}

/**
 * Validates US phone numbers with optional +1 prefix
 * Accepts formats: (212) 555-7890, 212-555-7890, 2125557890, +1-212-555-7890
 * Rejects impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Optional +1 prefix
  const hasOptionalPrefix = value.startsWith('+1');
  
  // Check if we have 11 digits with +1 prefix or 10 digits without
  if (hasOptionalPrefix && digits.length !== 11) return false;
  if (!hasOptionalPrefix && digits.length !== 10) return false;
  
  // Extract the area code (last 10 digits)
  const areaCode = hasOptionalPrefix ? digits.substring(1, 4) : digits.substring(0, 3);
  
  // Area codes cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check if the format matches one of the accepted patterns
  const patterns = [
    // (212) 555-7890
    /^\(\d{3}\)\s?\d{3}-\d{4}$/,
    // 212-555-7890
    /^\d{3}-\d{3}-\d{4}$/,
    // 2125557890
    /^\d{10}$/,
    // +1 (212) 555-7890
    /^\+1\s?\(\d{3}\)\s?\d{3}-\d{4}$/,
    // +1-212-555-7890
    /^\+1-\d{3}-\d{3}-\d{4}$/,
    // +1 212 555 7890
    /^\+1\s?\d{3}\s?\d{3}\s?\d{4}$/,
    // +12125557890
    /^\+1\d{10}$/
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats
 * Handles: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces and hyphens) for validation
  const cleanValue = value.replace(/[-\s]/g, '');
  
  // Main regex pattern for Argentine phone numbers
  // Optional +54, optional 0 trunk prefix, optional 9 mobile indicator,
  // area code (2-4 digits, leading 1-9), subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(\+54|54)?(0)?(9)?(\d{2,4})(\d{6,8})$/;
  
const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;

  const [, countryCode, trunkPrefix, , areaCode] = match;

  // Country code validation
  if (countryCode && countryCode !== '+54' && countryCode !== '54') return false;

  // Area code validation: leading digit must be 1-9
  if (!/^[1-9]/.test(areaCode)) return false;

  // If country code is omitted, number must begin with trunk prefix 0
  if (!countryCode && !trunkPrefix) return false;

  // Total validation (for debugging)
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Accept unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and other invalid characters
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s\p{L}\p{M}'-]+)*$/u;
  
  return nameRegex.test(value) && !/\d/.test(value);
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Check known prefixes
  const validPrefixes = [
    '4',           // Visa
    '5[1-5]',      // Mastercard
    '3[47]',       // American Express
    '6(?:011|5[0-9]{2})'  // Discover
  ];
  
  const prefixValid = validPrefixes.some(prefix => 
    new RegExp(`^${prefix}`).test(digits)
  );
  
  if (!prefixValid) return false;
  
  // Luhn checksum
  return runLuhnCheck(digits);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    const digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      let doubled = digit * 2;
      if (doubled > 9) {
        doubled -= 9;
      }
      sum += doubled;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
