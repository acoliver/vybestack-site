/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex chars in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match words that start with the prefix, followed by any letters
  const regex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');

  // Get all matches
  const matches = [...text.matchAll(regex)].map(match => match[0]);

  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex chars in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Simple approach: find patterns of digit + token that aren't at start
  const matches: string[] = [];
  
  // Try to capture digit+token patterns
  const matchPattern = new RegExp(`(\\d${escapedToken})`, 'g');
  let match;
  
  while ((match = matchPattern.exec(text)) !== null) {
    // Check if this match is not at the beginning of the string
    if (match.index > 0) {
      matches.push(match[1]);
    }
  }

  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;

  // No whitespace
  if (/\s/.test(value)) return false;

  // One uppercase, one lowercase, one digit, one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!"#$%&'()*+,\-./:;<=>?@[\\\]^_`{|}~]/.test(value);

  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;

  // No immediate repeated sequences (like abab)
  const repeatedPattern = /(.{2,})\1/;
  if (repeatedPattern.test(value)) return false;

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex to exclude
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;

  // IPv6 regex patterns
  const ipv6Regexes = [
    // Full notation (8 groups of 4 hex digits)
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // With :: compression
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/,
    // Leading/trailing ::
    /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}::\b/,
    // Single ::
    /\b::\b/,
    // Mixed notation (IPv4 embedded)
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}\b/
  ];

  // Check if any IPv6 pattern matches
  const isIPv6 = ipv6Regexes.some(regex => regex.test(value));

  // Make sure it's not an IPv4 address
  if (ipv4Regex.test(value)) return false;

  return isIPv6;
}
