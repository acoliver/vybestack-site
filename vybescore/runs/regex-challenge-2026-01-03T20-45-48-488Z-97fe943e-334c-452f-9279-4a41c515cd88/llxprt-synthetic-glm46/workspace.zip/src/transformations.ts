/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence delimiters (. ? !) keeping the delimiter
  const segments = text.split(/([.?!])/);
  
  let result = segments.map((segment, index) => {
    if (/[.?!]/.test(segment)) {
      // Sentence-ending punctuation found
      return segment;
    } else if (segment.trim()) {
      // Text content (word or phrase)
      // Previous segment is punctuation, so this should be capitalized
      if (index > 0 && /[.?!]/.test(segments[index - 1])) {
        // Trim leading space and capitalize
        const trimmed = segment.trim();
        const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
        return capitalized;
      }
      // If it's the first segment, capitalize it
      if (index === 0) {
        return segment.charAt(0).toUpperCase() + segment.slice(1);
      }
      return segment;
    }
    // Just whitespace, return as-is
    return segment;
  }).join('');
  
  // Ensure exactly one space after punctuation and handle spacing
  result = result.replace(/([.?!])s*([a-zA-Z])/g, '$1 $2');
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching protocol://domain/path/etc
  const urlRegex = /\bhttps?:\/\/[^\s/$.?#].[^\s]*\b/gi;
  const matches = text.match(urlRegex) || [];

  // Remove trailing punctuation but keep the core URL
  return matches.map(match => 
    match.replace(/[^\w\-._~:/?[\]!$&'()*+,;=%]/g, '')
  );
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but leave https:// urls unchanged
  const httpsRegex = /\bhttp:\/\//g;
  return text.replace(httpsRegex, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http:// to https://
  const httpsText = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Then rewrite docs.example.com URLs for /docs/ paths when not dynamic
  const docsRegex = /(https?:\/\/example\.com)(\/docs\/[^?\s]*)(?!\?(?:.*\b)?(?:cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py))/g;
  
  return httpsText.replace(docsRegex, 'https://docs.example.com$2');
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format and validate month/day ranges
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Additional validation: February days check (simplified leap year logic)
  if (month === 2 && day > 29) return 'N/A';
  if (month === 2 && day === 29) {
    // Leap year check: divisible by 4 but not by 100, unless divisible by 400
    const yearNum = parseInt(year, 10);
    if ((yearNum % 4 !== 0) || (yearNum % 100 === 0 && yearNum % 400 !== 0)) {
      return 'N/A';
    }
  }
  
  // Validate days in months with 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  return year;
}
