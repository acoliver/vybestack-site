#!/usr/bin/env node
import { encode } from './src/base64.ts';

console.log("Testing direct space encoding:");
const result = encode(" ");
console.log(`Result: "${result}"`);