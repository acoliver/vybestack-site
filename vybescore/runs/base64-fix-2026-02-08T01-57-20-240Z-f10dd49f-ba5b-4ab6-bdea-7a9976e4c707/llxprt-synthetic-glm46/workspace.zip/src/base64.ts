/**
 * Valid Base64 character pattern
 */
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to standard Base64.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with proper padding.
 */
export function encode(input: string): string {
  // Use standard base64 encoding which includes correct padding
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate that input contains only Base64 characters
  if (!BASE64_REGEX.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }

  try {
    // Use standard base64 decoding
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
