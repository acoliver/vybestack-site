import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('encodes single character with proper padding', () => {
    const result = encode('a');
    expect(result).toBe('YQ==');
  });

  it('decodes without padding', () => {
    const result = decode('YQ');
    expect(result).toBe('a');
  });

  it('encodes non-ASCII UTF-8 characters', () => {
    const result = encode('hello ');
    expect(result).toBe('aGVsbG8g8J+MjQ==');
  });

  it('decodes non-ASCII UTF-8 characters', () => {
    const result = decode('aGVsbG8g8J+MjQ==');
    expect(result).toBe('hello ');
  });

  it('encodes space character', () => {
    const result = encode(' ');
    expect(result).toBe('IA==');
  });

  it('decodes space character', () => {
    const result = decode('IA==');
    expect(result).toBe(' ');
  });

  it('rejects invalid Base64 characters', () => {
    expect(() => decode('invalid@base64!#$')).toThrow('Invalid Base64 input: contains characters outside Base64 alphabet');
  });

  it('allows padding in various lengths', () => {
    expect(decode('aGVsbG8=')).toBe('hello');
  });
});
