/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let isRunning = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prev) => {
      // Prevent re-entrant calls
      if (isRunning) {
        return prev!
      }
      
      try {
        isRunning = true
        const result = updateFn(prev)
        return result
      } finally {
        isRunning = false
      }
    },
    disposed: false,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  const unsubscribe = () => {
    if (observer.disposed) return
    observer.disposed = true
    
    // Clear observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
