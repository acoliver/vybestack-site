/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  ObserverR,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with
 * supplied function which computes current value
 * of closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observers: ObserverR[] = []
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Track whether we're notifying to prevent cycles
  let isNotifying = false

  // Computed value recalculates each time it's accessed
  const getter: GetterFn<T> = () => {
    // Register this computed as a dependency of current observer
    const currentObserver = getActiveObserver()
    if (currentObserver && currentObserver !== o && !isNotifying) {
      if (!observers.includes(currentObserver)) {
        observers.push(currentObserver)
      }
    }

    // Update this computed value (which tracks its own dependencies)
    updateObserver(o)

    return o.value!
  }

  // Wrap updateFn to notify observers when this computed's value changes
  const originalUpdateFn = o.updateFn
  o.updateFn = (prev) => {
    const prevValue = o.value
    const result = originalUpdateFn(prev)

    // Notify observers if value changed and we're not already notifying
    if (!isNotifying && result !== prevValue) {
      const activeObserver = getActiveObserver()
      isNotifying = true
      try {
        for (const observer of [...observers]) {
          // Skip notifying the observer that triggered this update
          if (!observer.disposed && observer !== activeObserver) {
            updateObserver(observer as Observer<T>)
          }
        }
      } finally {
        isNotifying = false
      }
    }

    return result
  }

  return getter
}
