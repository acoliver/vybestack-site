import { readFile } from 'fs/promises';
import { resolve } from 'path';

export interface CliOptions {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArguments(args: string[]): CliOptions {
  if (args.length < 2) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[0];
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('Error: --format requires a value');
      }
      format = args[i + 1];
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('Error: --output requires a value');
      }
      outputPath = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Error: Unknown option: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('Error: --format is required');
  }

  return {
    dataPath: resolve(dataPath),
    format,
    outputPath: outputPath ? resolve(outputPath) : undefined,
    includeTotals
  };
}

export async function readDataFile(path: string): Promise<unknown> {
  try {
    const fileContent = await readFile(path, 'utf-8');
    return JSON.parse(fileContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Error: Invalid JSON in file: ${path}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`Error: File not found: ${path}`);
    }
    throw error;
  }
}