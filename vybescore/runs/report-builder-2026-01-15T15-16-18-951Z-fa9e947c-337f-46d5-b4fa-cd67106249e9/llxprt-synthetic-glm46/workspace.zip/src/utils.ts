import type { ReportData } from './types.js';

export function formatAmount(amount: number): string {
  return amount.toFixed(2);
}

export function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid report data: must be an object');
  }
  
  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }
  
  if (typeof report.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }
  
  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }
  
  for (const entry of report.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: must be an object');
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (typeof entryRecord.label !== 'string') {
      throw new Error('Invalid entry: label must be a string');
    }
    
    if (typeof entryRecord.amount !== 'number') {
      throw new Error('Invalid entry: amount must be a number');
    }
  }
}