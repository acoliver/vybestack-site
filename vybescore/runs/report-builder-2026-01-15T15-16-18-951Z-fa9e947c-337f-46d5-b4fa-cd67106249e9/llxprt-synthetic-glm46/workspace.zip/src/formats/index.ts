import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';
import type { ReportRenderer } from '../types.js';

export const formatters: Record<string, ReportRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};