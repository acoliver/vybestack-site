import type { ReportData, RenderOptions, ReportRenderer } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  let output = `# ${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += '## Entries\n';

  for (const entry of data.entries) {
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** $${total.toFixed(2)}\n`;
  }

  return output;
}

export const markdownRenderer: ReportRenderer = {
  render: renderMarkdown,
};