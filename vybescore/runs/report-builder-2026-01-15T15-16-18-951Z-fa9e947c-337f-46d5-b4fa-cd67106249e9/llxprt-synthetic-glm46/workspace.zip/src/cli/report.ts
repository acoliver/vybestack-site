#!/usr/bin/env node

import { writeFile } from 'fs/promises';
import process from 'process';
import { formatters } from '../formats/index.js';
import { parseArguments, readDataFile } from '../args.js';
import type { ReportData } from '../types.js';

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: Expected an object');
  }

  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  const entries = reportData.entries.map((entry: Record<string, unknown>, index: number) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid data: entry at index ${index} must be an object`);
    }
    
    if (typeof entry.label !== 'string') {
      throw new Error(`Invalid data: entry at index ${index} must have a string label`);
    }
    
    if (typeof entry.amount !== 'number') {
      throw new Error(`Invalid data: entry at index ${index} must have a number amount`);
    }
    
    return {
      label: entry.label,
      amount: entry.amount
    };
  });
  
  return {
    title: reportData.title,
    summary: reportData.summary,
    entries
  };
}

async function main(): Promise<void> {
  try {
    const options = parseArguments(process.argv.slice(2));
    const rawData = await readDataFile(options.dataPath);
    const reportData = validateReportData(rawData);
    
    const formatter = formatters[options.format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${options.format}`);
    }
    
    const output = formatter.render(reportData, {
      includeTotals: options.includeTotals
    });
    
    if (options.outputPath) {
      await writeFile(options.outputPath, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'An unknown error occurred');
    process.exit(1);
  }
}

main();
