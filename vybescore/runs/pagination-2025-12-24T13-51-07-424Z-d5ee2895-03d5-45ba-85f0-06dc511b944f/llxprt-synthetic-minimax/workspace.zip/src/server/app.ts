import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory, validatePage, validateLimit } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate page parameter
    const pageValidation = validatePage(pageParam);
    if (!pageValidation.isValid) {
      return res.status(400).json({ error: pageValidation.error });
    }

    // Validate limit parameter
    const limitValidation = validateLimit(limitParam);
    if (!limitValidation.isValid) {
      return res.status(400).json({ error: limitValidation.error });
    }

    const payload = listInventory(db, { page: pageValidation.value, limit: limitValidation.value });
    res.json(payload);
  });

  return app;
}
