import type { Database } from 'sql.js';
import type { InventoryItem } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePage(pageParam: string | undefined): { isValid: boolean; value: number; error?: string } {
  if (!pageParam) {
    return { isValid: true, value: 1 };
  }
  
  const page = Number(pageParam);
  
  if (!Number.isFinite(page)) {
    return { isValid: false, value: 1, error: 'Page must be a valid number' };
  }
  
  if (page <= 0) {
    return { isValid: false, value: 1, error: 'Page must be positive' };
  }
  
  if (!Number.isInteger(page)) {
    return { isValid: false, value: 1, error: 'Page must be an integer' };
  }
  
  if (page > 1000000) {
    return { isValid: false, value: 1, error: 'Page is too large' };
  }
  
  return { isValid: true, value: page };
}

function validateLimit(limitParam: string | undefined): { isValid: boolean; value: number; error?: string } {
  if (!limitParam) {
    return { isValid: true, value: DEFAULT_LIMIT };
  }
  
  const limit = Number(limitParam);
  
  if (!Number.isFinite(limit)) {
    return { isValid: false, value: DEFAULT_LIMIT, error: 'Limit must be a valid number' };
  }
  
  if (limit <= 0) {
    return { isValid: false, value: DEFAULT_LIMIT, error: 'Limit must be positive' };
  }
  
  if (!Number.isInteger(limit)) {
    return { isValid: false, value: DEFAULT_LIMIT, error: 'Limit must be an integer' };
  }
  
  if (limit > 100) {
    return { isValid: false, value: DEFAULT_LIMIT, error: 'Limit cannot exceed 100' };
  }
  
  return { isValid: true, value: limit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): { items: InventoryItem[]; page: number; limit: number; total: number; hasNext: boolean } {
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const page = options.page && options.page > 0 ? Math.floor(options.page) : 1;
  const limit = options.limit && options.limit > 0 ? Math.floor(options.limit) : DEFAULT_LIMIT;

  // FIX: offset should be (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  // FIX: hasNext should be based on remaining items
  const hasNext = offset + rows.length < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}

export { validatePage, validateLimit };
