import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): { 
  filePath?: string; 
  format?: FormatType; 
  output?: string; 
  includeTotals?: boolean;
  error?: string;
} {
  const result: { 
    filePath?: string; 
    format?: FormatType; 
    output?: string; 
    includeTotals?: boolean;
    error?: string;
  } = {};

  // Skip node and script path
  const args = argv.slice(2);
  
  if (args.length < 2) {
    result.error = 'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]';
    return result;
  }

  result.filePath = args[0];

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          result.error = '--format requires a value';
          return result;
        }
        result.format = args[++i] as FormatType;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          result.error = '--output requires a value';
          return result;
        }
        result.output = args[++i];
        break;
      case '--includeTotals':
        result.includeTotals = true;
        break;
      default:
        result.error = `Unknown argument: ${arg}`;
        return result;
    }
  }

  if (!result.filePath) {
    result.error = 'JSON file path is required';
  }

  if (!result.format) {
    result.error = '--format is required';
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const reportData = data as Record<string, unknown>;

  // Check required fields
  if (!reportData.title || typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (!reportData.summary || typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!reportData.entries || !Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  // Validate entries
  const entries = reportData.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}] missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${index}] missing or invalid "amount" field`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries
  };
}

function main(): void {
  const args = parseArgs(process.argv);
  
  if (args.error) {
    console.error(args.error);
    process.exit(1);
  }

  try {
    // Read and parse JSON file
    const jsonContent = readFileSync(args.filePath!, 'utf-8');
    const data = JSON.parse(jsonContent);
    
    // Validate data structure
    const reportData = validateReportData(data);

    // Check format
    if (args.format !== 'markdown' && args.format !== 'text') {
      console.error(`Unsupported format: ${args.format}`);
      process.exit(1);
    }

    // Render report
    const options: RenderOptions = { includeTotals: args.includeTotals };
    const renderers = {
      markdown: renderMarkdown,
      text: renderText
    };

    const output = renderers[args.format](reportData, options);

    // Write output
    if (args.output) {
      writeFileSync(args.output, output, 'utf-8');
    } else {
      console.log(output);
    }

  } catch (error) {
    if (error instanceof Error) {
      const nodeError = error as NodeJS.ErrnoException;
      if (nodeError.code === 'ENOENT') {
        console.error(`Error: File not found: ${args.filePath}`);
      } else if (error instanceof SyntaxError) {
        console.error('Error: Invalid JSON file');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();