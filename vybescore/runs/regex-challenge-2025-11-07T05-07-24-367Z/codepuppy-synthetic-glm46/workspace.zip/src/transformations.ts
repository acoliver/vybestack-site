/**
 * Capitalize the first character of each sentence.
 * After .?! punctuation, capitalize first letter, ensure single space between sentences,
 * collapse extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize multiple spaces to single spaces, but preserve sentence boundaries
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to match sentence boundaries (looking for . ? ! followed by space and letter)
  // Also handle the beginning of the string
  const capitalizeRegex = /(^|[.!?]\s+)([a-z])/g;
  
  // Capitalize first letter after sentence boundaries or at start
  normalized = normalized.replace(capitalizeRegex, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  // Ensure exactly one space after punctuation if there's more text
  normalized = normalized.replace(/([.!?])\s+/g, '$1 ');
  
  return normalized;
}

/**
 * Extract URLs from text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http/https, www, domains with optional paths, queries, fragments
  // Negative lookbehind and lookahead to avoid capturing surrounding punctuation
  const urlRegex = /(?<!\S)(?:https?:\/\/|www\.)[^\s<>"']+|(?:https?:\/\/|www\.)[^\s<>"']+(?=\s|$|[.!?])|(?:https?:\/\/|www\.)[^\s<>"']+(?=[^\w-])/gi;
  
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Clean up trailing punctuation from each match
  return matches.map(url => {
    // Remove trailing punctuation marks that are not valid URL characters
    return url.replace(/[.,!?;:)]+$/g, '');
  });
}

/**
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  // Use word boundary to avoid partial matches
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs: upgrade to https and move docs paths to docs.example.com
 * Excludes URLs with cgi-bin, query strings, or legacy extensions from host rewrite
 */
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http to https
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Pattern for example.com URLs
  // captures: the full URL, protocol, any subdomains, path start
  const exampleUrlRegex = /(https:\/\/)([^\/]*example\.com)(\/[^\s]*)/gi;
  
  result = result.replace(exampleUrlRegex, (match, protocol, domain, path) => {
    // Check if path contains excluded patterns
    const excludedPatterns = [/\/cgi-bin\//, /[?&=]/, /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/i];
    
    const isExcluded = excludedPatterns.some(pattern => pattern.test(path));
    
    if (!isExcluded && path.startsWith('/docs/')) {
      // Rewrite to docs.example.com for docs paths
      return protocol + 'docs.example.com' + path;
    } else {
      // Keep original domain but ensure https
      return protocol + domain + path;
    }
  });
  
  return result;
}

/**
 * Extract the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate day range for specific months (basic validation)
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Simple leap year check for February
  const isLeapYear = (year: string) => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  };
  
  let maxDay = daysInMonth[month];
  if (month === 2 && isLeapYear(year)) {
    maxDay = 29;
  }
  
  if (day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
