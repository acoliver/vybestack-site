export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern that handles:
  // - Local part: letters, digits, +, -, ., _ (no consecutive dots, no leading/trailing dots)
  // - Domain: letters, digits, -, . (no underscores, no consecutive dots, no leading/trailing dots)
  // - TLD: 2+ letters
  const emailRegex = /^[a-zA-Z0-9]+([._+-][a-zA-Z0-9]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional check for consecutive dots in the entire email
  if (value.includes('..')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits without country code, 11 with)
  if (cleaned.length < 10 || cleaned.length > 11) {
    return false;
  }
  
  // Remove optional +1 prefix if present
  let phoneNumber = cleaned;
  if (phoneNumber.length === 11 && phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.slice(1);
  } else if (phoneNumber.length === 11 && !phoneNumber.startsWith('1')) {
    return false; // Invalid country code
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the original format is acceptable
  const formatRegex = /^(\+1[\s-]?)?(\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  return formatRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, etc.)
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+54? - Optional country code
  // (0)? - Optional trunk prefix
  // 9? - Optional mobile indicator
  // ([1-9]\d{1,3}) - Area code (2-4 digits, first digit 1-9)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const phoneRegex = /^\+54?(0)?9?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = match[1] === '0';
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Pattern allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes, hyphens, spaces
  // - No digits, no special symbols
  const nameRegex = /^[\p{L}\p{M}'\s-]+$/u;
  
  // Disallow names that are too short or contain only spaces/hyphens/apostrophes
  if (value.trim().length < 1) {
    return false;
  }
  
  // Disallow names with consecutive spaces/hyphens/apostrophes (except apostrophes in contractions)
  if (/[\s-]{2,}/.test(value)) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths with Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[1-9]\d{3}|0[1-9]\d{2})\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check prefix and length
  const isValidFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function for Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
