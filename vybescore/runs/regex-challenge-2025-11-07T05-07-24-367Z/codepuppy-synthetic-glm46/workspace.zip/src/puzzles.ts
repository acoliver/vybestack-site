/**
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex and create word boundary pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  // \b ensures word boundary, [a-zA-Z]+ matches the rest of the word
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*`, 'g');
  
  const matches = text.match(wordRegex);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions and return unique matches
  const result = matches.filter(word => !exceptions.includes(word));
  
  // Remove duplicates
  return [...new Set(result)];
}

/**
 * Return occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Simple approach: split by spaces and check each word
  const words = text.split(/\s+/);
  const results: string[] = [];
  
  for (const word of words) {
    // Check if word contains the token after a digit
    const tokenIndex = word.indexOf(token);
    if (tokenIndex > 0) {
      // Check if character before token is a digit
      const charBefore = word[tokenIndex - 1];
      if (/\d/.test(charBefore)) {
        // Get the substring from the digit to the end of token
        const startIndex = tokenIndex - 1;
        const endIndex = tokenIndex + token.length;
        results.push(word.substring(startIndex, endIndex));
      }
    }
  }
  
  return results;
}

/**
 * Validate passwords according to policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  // Look for patterns where a sequence of 2+ characters repeats immediately
  const repeatedPattern = /(.{2,})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // First, ensure it's not an IPv4 address pattern
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  if (ipv4Pattern.test(value)) {
    // If it looks like IPv4, don't consider it IPv6
    return false;
  }
  
  // IPv6 regex pattern that supports:
  // - Full notation: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // - Compression with ::
  // - Mixed notation (rare, but possible)
  // - Leading zeros can be omitted
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b:(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b|\b[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}\b|\b::[0-9a-fA-F]{1,4}\b|\b[0-9a-fA-F]{1,4}::\b|\b::\b/;
  
  return ipv6Pattern.test(value);
}