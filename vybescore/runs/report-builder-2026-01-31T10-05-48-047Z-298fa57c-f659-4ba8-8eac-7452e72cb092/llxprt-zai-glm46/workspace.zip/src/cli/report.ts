#!/usr/bin/env node

import fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters, supportedFormats } from '../formatters.js';

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2);
  const dataPath = args[0];

  if (!dataPath) {
    console.error('Error: Missing data file path');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      format = args[i] ?? '';
    } else if (arg === '--output') {
      i++;
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: Missing --format option');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function loadData(dataPath: string): ReportData {
  try {
    const content = fs.readFileSync(dataPath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    if (!data || typeof data !== 'object') {
      throw new Error('Invalid data: root must be an object');
    }

    const { title, summary, entries } = data as Partial<ReportData>;

    if (typeof title !== 'string' || !title) {
      throw new Error('Invalid data: missing or invalid "title" field');
    }

    if (typeof summary !== 'string' || !summary) {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }

    if (!Array.isArray(entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }

    for (let i = 0; i < entries.length; i++) {
      const entry = entries[i];
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid data: entry at index ${i} is not an object`);
      }
      if (typeof entry.label !== 'string' || !entry.label) {
        throw new Error(`Invalid data: entry at index ${i} missing or invalid "label"`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entry at index ${i} missing or invalid "amount"`);
      }
    }

    return { title, summary, entries };
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON file: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unknown error occurred while loading data');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: RenderOptions): string {
  const formatter = formatters[format];

  if (!formatter) {
    console.error(`Error: Unsupported format "${format}"`);
    console.error(`Supported formats: ${supportedFormats.join(', ')}`);
    process.exit(1);
  }

  return formatter(data, options);
}

function main(): void {
  const { dataPath, format, outputPath, includeTotals } = parseArgs(process.argv);

  const data = loadData(dataPath);
  const output = renderReport(data, format, { includeTotals });

  if (outputPath) {
    fs.writeFileSync(outputPath, output, 'utf-8');
  } else {
    console.log(output);
  }
}

main();
