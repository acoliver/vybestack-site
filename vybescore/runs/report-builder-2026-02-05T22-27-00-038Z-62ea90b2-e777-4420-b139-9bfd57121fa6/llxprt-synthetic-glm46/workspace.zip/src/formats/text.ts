import type { ReportData, RenderOptions, Renderer } from '../types.js';

export const renderText: Renderer = (data: ReportData, options: RenderOptions): string => {
  // Calculate total if needed
  const total = options.includeTotals 
    ? data.entries.reduce((sum, entry) => sum + entry.amount, 0)
    : null;
  
  // Format amount with two decimal places
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };
  
  // Build content
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push('');
  
  // Summary
  lines.push(data.summary);
  lines.push('');
  
  // Entries section
  lines.push('Entries:');
  
  // Entry list
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  // Total if requested
  if (options.includeTotals && total !== null) {
    lines.push(`Total: ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
};