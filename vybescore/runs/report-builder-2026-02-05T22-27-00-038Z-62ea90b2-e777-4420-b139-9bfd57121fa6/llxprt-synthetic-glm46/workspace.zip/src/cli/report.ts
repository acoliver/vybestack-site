#!/usr/bin/env node

import fs from 'node:fs';

import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, FormatType, Renderer } from '../types.js';

// Map format types to their renderer functions
const formatRenderers: Record<FormatType, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  inputFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

// Parse command line arguments
function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: report-cli <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const cliArgs: Partial<CliArgs> = {
    inputFile: args[0],
    includeTotals: false,
  };
  
  for (let i = 1; i < args.length; i += 2) {
    const flag = args[i];
    const value = args[i + 1];
    
    if (flag === '--format') {
      if (!value || !['markdown', 'text'].includes(value)) {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      cliArgs.format = value as FormatType;
    } else if (flag === '--output') {
      if (!value) {
        console.error('Error: --output flag requires a path');
        process.exit(1);
      }
      cliArgs.outputPath = value;
    } else if (flag === '--includeTotals') {
      // This flag doesn't take a value, handle it differently
      cliArgs.includeTotals = true;
      i--; // Adjust index since this flag doesn't have a value
    }
  }
  
  if (!cliArgs.inputFile || !cliArgs.format) {
    console.error('Error: Missing required arguments');
    process.exit(1);
  }
  
  return cliArgs as CliArgs;
}

// Validate and parse report data
function parseReportData(filePath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Validate structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON structure');
    }
    
    const report = data as ReportData;
    
    if (typeof report.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    
    if (typeof report.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    
    if (!Array.isArray(report.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    for (const entry of report.entries) {
      if (typeof entry.label !== 'string' || typeof entry.amount !== 'number') {
        throw new Error('Invalid entry structure');
      }
    }
    
    return report;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in file ${filePath}`);
    } else {
      console.error(`Error: ${(error as Error).message}`);
    }
    process.exit(1);
  }
}

// Main CLI function
function main(): void {
  const cliArgs = parseArgs();
  
  // Parse the input data
  const reportData = parseReportData(cliArgs.inputFile);
  
  // Render the report
  const renderer = formatRenderers[cliArgs.format];
  const output = renderer(reportData, { includeTotals: cliArgs.includeTotals });
  
  // Write output
  if (cliArgs.outputPath) {
    try {
      fs.writeFileSync(cliArgs.outputPath, output, 'utf-8');
      console.log(`Report written to ${cliArgs.outputPath}`);
    } catch (error) {
      console.error(`Error writing to file: ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

// Run the CLI
main();
