/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate that a string contains only valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Validate that the input was properly padded Base64
    // by trying to re-encode and compare (this catches malformed padding)
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Handle the case where input might not have padding but is otherwise valid
    const normalizedInput = input.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedInput !== normalizedReencoded) {
      throw new Error('Invalid Base64 input: malformed or corrupted data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
