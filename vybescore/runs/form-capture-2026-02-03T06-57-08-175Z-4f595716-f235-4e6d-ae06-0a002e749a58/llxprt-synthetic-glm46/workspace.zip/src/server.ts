import express from 'express';
import path from 'path';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { fileURLToPath } from 'url';
// @ts-expect-error - sql.js doesn't have proper TypeScript definitions
import initSqlJs from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const port = process.env.PORT || 3535;
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database setup
import type { DatabaseSQL, SqlValue } from './types.d.ts'; // Import the interface
let db: DatabaseSQL;
const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    let dbBinary = Buffer.alloc(0);
    
    try {
      dbBinary = readFileSync(dbPath);
    } catch (error) {
      console.log('Database file does not exist, creating a new one');
    }
    
    db = new SQL.Database(dbBinary);
    
    // Ensure the submissions table exists
    db.run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      )
    `);
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Validation functions
function saveDatabase(): void {
  try {
    // Ensure directory exists
    const dir = path.dirname(dbPath);
    if (!existsSync(dir)) {
      mkdirSync(dir, { recursive: true });
    }
    
    const data = db.export();
    writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved successfully');
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^@?[\d\s()\-]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  return postalRegex.test(postalCode);
}

function validateForm(formData: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!formData.city || formData.city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }
  
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push('Postal / Zip code contains invalid characters');
  }
  
  if (!formData.country || formData.country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!formData.email || formData.email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Email address is not valid');
  }
  
  if (!formData.phone || formData.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhoneNumber(formData.phone)) {
    errors.push('Phone number contains invalid characters');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Friend' });
});

app.post('/submit', (req, res) => {
  const validation = validateForm(req.body);
  
  if (!validation.isValid) {
    return res.render('form', {
      errors: validation.errors,
      values: req.body
    });
  }
  
  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `) as { run(params: SqlValue[]): void; free(): void };
    
    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    ]);
    
    stmt.free();
    
    saveDatabase();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database insertion error:', error);
    const errors = ['Something went wrong, please try again.'];
    res.render('form', { errors, values: req.body });
  }
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  saveDatabase();
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed.');
      
      if (db) {
        db.close();
        console.log('Database connection closed.');
      }
      
      process.exit(0);
    });
  } else {
    process.exit(0);
  }
  
  setTimeout(() => {
    console.error('Could not close connections in time, forcefully shutting down');
    process.exit(1);
  }, 10000);
}

// Initialize database and start server
await initializeDatabase();

const server = app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
});

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));