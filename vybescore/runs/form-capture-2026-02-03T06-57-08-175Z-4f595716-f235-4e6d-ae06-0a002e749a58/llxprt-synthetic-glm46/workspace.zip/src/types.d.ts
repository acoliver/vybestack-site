declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }
  
  export interface DatabaseStatic {
    new(data?: Buffer | Uint8Array): Database;
  }

  export const Database: DatabaseStatic;
}

export interface DatabaseSQL {
  run(sql: string, params?: SqlValue[]): void;
  prepare(sql: string): unknown;
  export(): Uint8Array;
  close(): void;
}

export type SqlValue = string | number | null | undefined;