/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Insert exactly one space between sentences if missing
  let result = text.replace(/([.!?])(?=\S)/g, '$1 ');
  
  // Split into sentences and capitalize each one
  result = result.replace(/((?:^|[.!?]\s+)([a-z]))/g, (match, full, letter) => {
    return full.replace(letter, letter.toUpperCase());
  });
  
  // Clean up extra spaces
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex pattern - matches http/https, domain, and optional path/query/fragment
  // Excludes trailing punctuation
  const urlRegex = /\bhttps?:\/\/[^\s\)\]\}\<\>",;:]+(?<![.,;:!?)\]\}\>])/g;
  
  const matches = text.match(urlRegex);
  return matches || [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but don't touch existing https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // First upgrade all http to https
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Pattern to match example.com URLs with /docs/ path
  // Exclude URLs with dynamic hints (cgi-bin, query strings, or legacy extensions)
  const docsUrlPattern = /\bhttps:\/\/([^\s\/]+)(\/docs\/[^\s\?\&;]*)(?<![\?\&;])/g;
  
  result = result.replace(docsUrlPattern, (match, domain, path) => {
    // Check if the URL contains dynamic hints or legacy extensions
    const hasDynamicHints = /(cgi-bin|[?&=]|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    
    if (hasDynamicHints.test(match)) {
      // Return unchanged (just stay with https://)
      return match;
    }
    
    // Rewrite to docs.example.com format
    return `https://docs.${domain}${path}`;
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format and validate month/day
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Additional validation for days in month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Simple leap year check for February
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
  const maxDays = month === 2 ? (isLeapYear ? 29 : 28) : daysInMonth[month - 1];
  
  if (day > maxDays) return 'N/A';
  
  return year;
}
