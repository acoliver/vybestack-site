/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create word boundary pattern for the given prefix
  const prefixPattern = new RegExp(`\\b${escapeRegex(prefix)}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(prefixPattern) || [];
  
  // Filter out exceptions and unique results
  return [...new Set(matches.filter(word => !exceptions.includes(word)))];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Find patterns of digit+token, excluding those at the start
  // Use explicit pattern construction with proper escaping
  const escapedToken = escapeRegex(token);
  const pattern = '\d' + escapedToken + '(?=\b|\W|$)';
  const tokenPattern = new RegExp(pattern, 'g');
  
  const allMatches = text.match(tokenPattern) || [];
  
  // Filter out matches at the start of the string
  const matches = allMatches.filter(match => {
    const index = text.indexOf(match);
    return index > 0;
  });
  
  return [...new Set(matches)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase, one lowercase, one digit, one symbol
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/\d/.test(value)) return false;
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, 1212)
  // Look for patterns of 2-4 characters repeated immediately
  const repeatedPattern = /(.{2,4})\1/;
  if (repeatedPattern.test(value)) return false;
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that excludes IPv4 addresses
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: for compressed zeros
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  
  // First check if it matches IPv4 pattern to exclude it
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  return ipv6Pattern.test(value);
}

/**
 * Helper function to escape regex special characters
 */
function escapeRegex(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}