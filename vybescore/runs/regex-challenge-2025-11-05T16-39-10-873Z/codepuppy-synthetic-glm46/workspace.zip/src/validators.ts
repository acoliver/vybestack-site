export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex supporting common formats
  // Reject double dots, trailing dots, underscores in domains
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for invalid patterns
  if (!value || typeof value !== 'string') return false;
  
  // Reject consecutive dots anywhere
  if (value.includes('..')) return false;
  
  // Reject dot at the end of local part or domain
  if (value.endsWith('.')) return false;
  
  // Reject underscores in domain part
  const [, domain] = value.split('@');
  if (domain && domain.includes('_')) return false;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove common separators for validation
  const cleanNumber = value.replace(/[\s\-\(\)]/g, '');
  
  // Handle optional +1 prefix
  const numberWithoutCountry = cleanNumber.startsWith('+1') ? cleanNumber.substring(2) : cleanNumber;
  
  // Should be 10 digits after removing country code
  if (!/^\d{10}$/.test(numberWithoutCountry)) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = numberWithoutCountry.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Support common formats with regex validation
  const phonePatterns = [
    /^\+1[\s\-]?\(?\d{3}\)?[\s\-]?\d{3}[\s\-]?\d{4}$/, // +1 (212) 555-7890, +1-212-555-7890
    /^\(\d{3}\)[\s\-]?\d{3}[\s\-]?\d{4}$/, // (212) 555-7890
    /^\d{3}[\s\-]?\d{3}[\s\-]?\d{4}$/, // 212-555-7890, 212 555 7890
    /^\d{10}$/ // 2125557890
  ];
  
  return phonePatterns.some(pattern => pattern.test(value));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const cleanNumber = value.replace(/[\s\-]/g, '');
  
  // Main pattern for Argentine phone numbers
  // Optional +54, optional 0 trunk prefix, optional 9 mobile indicator, 2-4 digit area code, 6-8 digit subscriber
  const argentinePattern = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanNumber.match(argentinePattern);
  if (!match) return false;
  
  const [, countryCode, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // If no country code, must have trunk prefix
  if (!countryCode && !trunkPrefix) return false;
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Subscriber number: 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  // Total length should be reasonable (between 10 and 16 digits with separators)
  return cleanNumber.length >= 10 && cleanNumber.length <= 16;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and invalid patterns like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(value)) return false;
  
  // Reject names that contain digits or symbols not allowed
  if (/\d|[^\p{L}\p{M}'\-\s]/u.test(value)) return false;
  
  // Reject names with only spaces or punctuation
  if (value.trim().length === 0) return false;
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s\-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Visa, Mastercard, AmEx patterns with correct lengths
  const cardPatterns = [
    { prefix: /^4/, length: [13, 16] }, // Visa
    { prefix: /^5[1-5]/, length: [16] }, // Mastercard
    { prefix: /^3[47]/, length: [15] } // American Express
  ];
  
  const isValidFormat = cardPatterns.some(card => {
    if (!card.prefix.test(cleanNumber)) return false;
    return card.length.includes(cleanNumber.length);
  });
  
  if (!isValidFormat) return false;
  
  // Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function for Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
