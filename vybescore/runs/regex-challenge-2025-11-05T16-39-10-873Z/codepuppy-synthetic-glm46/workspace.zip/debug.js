// Test with correct regex literal
const text = 'xfoo 1foo foo';
const workingPattern = /\dfoo(?=\b|\W|$)/g;
console.log('Working pattern matches:', text.match(workingPattern));

// Test what the pattern should look like as string
console.log('Pattern string should be:', workingPattern.source);

// Now test with that string in RegExp constructor
const constructorPattern = new RegExp(workingPattern.source, 'g');
console.log('Constructor pattern matches:', text.match(constructorPattern));