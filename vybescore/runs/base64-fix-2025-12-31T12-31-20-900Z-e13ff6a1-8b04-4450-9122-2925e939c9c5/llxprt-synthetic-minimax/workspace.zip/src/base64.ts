/**
 * Valid Base64 characters pattern
 */
const BASE64_PATTERN = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Encode plain text to Base64 using standard Base64 alphabet.
 */
export function encode(input: string): string {
  // Use standard Base64 encoding (not URL-safe)
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64.
 */
export function decode(input: string): string {
  const normalizedInput = input.replace(/\s/g, '');
  
  // Validate Base64 format
  if (normalizedInput.length === 0) {
    throw new Error('Empty input');
  }
  
  // Check for invalid Base64 characters first
  if (!BASE64_PATTERN.test(normalizedInput)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  try {
    return Buffer.from(normalizedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
