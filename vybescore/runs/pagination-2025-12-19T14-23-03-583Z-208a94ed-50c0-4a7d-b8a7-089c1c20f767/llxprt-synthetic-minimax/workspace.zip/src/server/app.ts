import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate inputs: reject non-numeric, negative, zero, or excessive values
    const validatePositiveInt = (value: string, paramName: string): number => {
      const num = Number(value);
      
      if (!Number.isInteger(num) || isNaN(num) || num <= 0) {
        res.status(400).json({
          error: `${paramName} must be a positive integer`
        });
        return -1;
      }
      
      if (paramName === 'page' && num > 1000000) {
        res.status(400).json({
          error: `${paramName} is too large`
        });
        return -1;
      }
      
      if (paramName === 'limit' && num > 100) {
        res.status(400).json({
          error: `${paramName} is too large`
        });
        return -1;
      }
      
      return num;
    };

    let page = 1;
    let limit = 5;

    if (pageParam) {
      const validatedPage = validatePositiveInt(pageParam, 'page');
      if (validatedPage === -1) return;
      page = validatedPage;
    }

    if (limitParam) {
      const validatedLimit = validatePositiveInt(limitParam, 'limit');
      if (validatedLimit === -1) return;
      limit = validatedLimit;
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
