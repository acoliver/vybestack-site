#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { argv } from 'node:process';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries array');
  }
  
  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid entry: expected object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid label');
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error('Invalid entry: missing or invalid amount');
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = readFileSync(args.inputFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading file ${args.inputFile}:`, error instanceof Error ? error.message : 'Unknown error');
      process.exit(1);
    }
    
    // Validate report data
    const reportData = validateReportData(jsonData);
    
    const options: ReportOptions = {
      includeTotals: args.includeTotals,
    };
    
    // Render report based on format
    let output: string;
    switch (args.format.toLowerCase()) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        console.error(`Error: Unsupported format "${args.format}"`);
        process.exit(1);
    }
    
    // Output result
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
        console.log(`Report written to ${args.outputPath}`);
      } catch (error) {
        console.error(`Error writing to file ${args.outputPath}:`, error instanceof Error ? error.message : 'Unknown error');
        process.exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();