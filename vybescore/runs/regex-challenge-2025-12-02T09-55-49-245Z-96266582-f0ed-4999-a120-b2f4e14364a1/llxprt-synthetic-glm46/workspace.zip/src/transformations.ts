/**
 * Capitalizes the first character of each sentence in a text.
 * Sentences are separated by . ? or ! characters followed by whitespace or end of string.
 * Inserts exactly one space between sentences even if the input omitted it,
 * and collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, let's normalize spacing around sentence terminators
  // Replace any combination of spaces with exactly one space after sentence terminators
  let result = text.replace(/([.?!])\s+/g, '$1 ');
  
  // Handle case where there's no space after sentence terminator
  result = result.replace(/([.?!])([a-z])/g, '$1 $2');
  
  // Split into sentences using a regex that preserves the terminators
  const sentences = result.split(/(?<=[.?!])\s+/);
  
  // Capitalize each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (!sentence) return '';
    
    // Find the first alphabetic character in the sentence
    const match = sentence.match(/[a-z]/i);
    if (!match) return sentence; // No alphabetic characters to capitalize
    
    const firstCharIndex = match.index!;
    const firstChar = sentence[firstCharIndex];
    
    // Replace the first character with its uppercase version
    return sentence.substring(0, firstCharIndex) + 
           firstChar.toUpperCase() + 
           sentence.substring(firstCharIndex + 1);
  });
  
  // Join sentences back with a single space
  return capitalizedSentences.join(' ');
}

/**
 * Extracts URLs from a text string.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regular expression to match URLs with various protocols and domain patterns
  // This pattern matches:
  // - http://, https://, ftp:// protocols
  // - www. domains
  // - domain.tld patterns
  // - paths, query strings, and fragments
  const urlPattern = /\b((?:https?:\/\/|ftp:\/\/|www\.)[^\s/$.?#].[^\s]*(?:\?[^\s]*)?(?:#[^\s]*)?)/gi;
  
  // Find all matches
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Common trailing punctuation to remove
    return url.replace(new RegExp('[.,;:!?)\\]\\}]+$', 'g'), '');
  });
}

/**
 * Replaces all http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https://, but be careful not to match if there's already https://
  // Using a negative lookbehind to ensure we don't replace https://
  return text.replace(/(?<!h)http:\/\//g, 'https://');
}

/**
 * Rewrites URLs based on specific rules:
 * - Always upgrade the scheme to https://
 * - When path begins with /docs/, rewrite the host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints like cgi-bin, query strings,
 *   or legacy extensions, but still upgrade the scheme.
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Process each URL in the text
  return text.replace(/https?:\/\/[^\s]+/gi, (match) => {
    const originalUrl = match;
    
    // Always upgrade the scheme to https
    let result = originalUrl.replace(/^http:\/\//g, 'https://');
    
    // Extract the full path (everything after the domain)
    const urlParts = result.match(/^https:\/\/([^/]+)(.*)$/);
    if (!urlParts) return result;
    
    const fullPath = urlParts[2]; // Includes leading slash if present
    
    // Check if path starts with /docs/
    if (fullPath.startsWith('/docs/')) {
// Check for dynamic hints or legacy extensions in the full path
      const hasDynamicHints = /\b(cgi-bin)\b/.test(fullPath) || 
                             /[?=&]/.test(fullPath) || 
                             /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(fullPath);
      
      // Only rewrite the host if there are no dynamic hints
      if (!hasDynamicHints) {
        result = `https://docs.example.com${fullPath}`;
      }
    }
    
    return result;
  });
}

export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) return 'N/A';
  if (day < 1 || day > 31) return 'N/A';
  
  // Additional validation for specific months
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = (month === 2 && isLeapYear(parseInt(year, 10))) ? 29 : daysInMonth[month - 1];
  
  if (day > maxDays) return 'N/A';
  
  return year;
}

function isLeapYear(year: number): boolean {
  return (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
}
