/**
 * Finds words in a text that begin with a given prefix, excluding any words in the exceptions list.
 * Returns an array of matching words (case-insensitive).
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Create a case-insensitive regex pattern to find words starting with the prefix
  // \b ensures we match whole words only
  const pattern = new RegExp(String.raw`\b(${prefix}[a-zA-Z]*)`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Normalize exceptions to lowercase for case-insensitive comparison
  const lowercasedExceptions = exceptions.map(word => word.toLowerCase());
  
  // Filter out any matches that are in the exceptions list
  const filteredMatches = matches
    .map(match => match.toLowerCase()) // Normalize to lowercase
    .filter(match => !lowercasedExceptions.includes(match));
  
  // Remove duplicates and return
  return [...new Set(filteredMatches)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns an array of matching token occurrences including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
// Simple approach: use regex literal with string interpolation for token
  const pattern = new RegExp(String.raw`\d${escapedToken}`, 'g');
  
  // Find all matches using regex match
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validates password strength according to policies:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length of 10 characters
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., "abab")
  // This regex looks for any 2-4 character sequence that repeats immediately
  if (/(.{2,4})\1+/g.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand notation) in a string.
 * Returns true if an IPv6 address is found, false otherwise.
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex pattern that matches:
  // - Standard IPv6 (8 groups of 4 hex digits)
  // - Shorthand notation with :: (compressed zeros)
  // - Mixed notation with IPv4 embedded (e.g., ::ffff:192.168.0.1)
  // - Does not match standard IPv4 addresses when not part of IPv6
  
  // This is a comprehensive IPv6 pattern that should cover most cases
  const ipv6Pattern = new RegExp('(?:^|[\\s\\[\\]:])(?:(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:))(?:[\\s\\[\\]:]|$)');
  
  return ipv6Pattern.test(value);
}
