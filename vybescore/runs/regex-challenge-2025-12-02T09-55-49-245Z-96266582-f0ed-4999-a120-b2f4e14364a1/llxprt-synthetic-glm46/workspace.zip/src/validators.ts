export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to RFC standards with some practical constraints.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check: local@domain.tld
  if (!value || value.length > 254) return false;
  
  // No consecutive dots or leading/trailing dots in local or domain part
  if (value.includes('..')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.startsWith('@') || value.endsWith('@')) return false;
  
  // Split local and domain parts
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const [localPart, domainPart] = parts;
  
  // Local part validation
  // Allow letters, digits, and these special characters: !#$%&'*+/=?^_`{|}~- and dot
  // Dot cannot be at start or end and cannot appear consecutively
  if (!localPart || localPart.length > 64) return false;
  if (!/^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/.test(localPart)) return false;
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Domain part validation
  // Domain labels are separated by dots, cannot start or end with hyphen
  // Domain cannot contain underscores
  if (!domainPart || domainPart.length > 253) return false;
  if (domainPart.includes('_')) return false;
  
  const domainLabels = domainPart.split('.');
  if (domainLabels.length < 2) return false;
  
  // Validate each domain label
  for (const label of domainLabels) {
    if (!label || label.length > 63) return false;
    if (!/^[a-zA-Z0-9-]+$/.test(label)) return false;
    if (label.startsWith('-') || label.endsWith('-')) return false;
  }
  
  // TLD should be at least 2 characters
  const tld = domainLabels[domainLabels.length - 1];
  if (tld.length < 2) return false;
  
  return true;
}

/**
 * Validates US phone numbers in various formats.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (starting with 0 or 1) and inputs that are too short.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if we have the right number of digits (10 for standard, 11 if +1 prefix)
  if (digits.length === 11) {
    // If 11 digits, it must start with 1 (country code)
    if (!digits.startsWith('1')) return false;
    
    // Extract the 10-digit phone number part
    const phoneNumber = digits.substring(1);
    return validateUSPhoneNumber(phoneNumber);
  } else if (digits.length === 10) {
    return validateUSPhoneNumber(digits);
  } else {
    // Wrong number of digits
    return false;
  }
}

/**
 * Validates a 10-digit US phone number
 */
function validateUSPhoneNumber(phoneNumber: string): boolean {
  // Area code cannot start with 0 or 1, and exchange code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  const exchangeCode = phoneNumber.substring(3, 6);
  const subscriberNumber = phoneNumber.substring(6, 10);
  
  // Area code validation: can't start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code validation: can't start with 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Ensure all parts contain only digits
  if (!/^\d{3}$/.test(areaCode) || 
      !/^\d{3}$/.test(exchangeCode) || 
      !/^\d{4}$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers in various formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before the area code
 * - Optional mobile indicator 9 between country/trunk and the area code
 * - Area code must be 2-4 digits (leading digit cannot be 0)
 * - Subscriber number (after the area code) must contain 6-8 digits
 * - When the country code is omitted, the number must begin with trunk prefix 0
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for parsing, but keep track of structure
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern to extract country code, mobile indicator, area code, and subscriber number
  // This regex captures the different valid formats:
  // 1. +54 9 XXX XXXXXXXX (international with mobile)
  // 2. +54 XXX XXXXXXXXX (international without mobile)
  // 3. 0XXX XXXXXXXXX (domestic with trunk)
  // 4. XXX XXXXXXXXX (domestic without trunk - invalid)
  
  // Check if it starts with +54 (country code)
  if (cleanValue.startsWith('+54')) {
    const afterCountry = cleanValue.substring(3); // Remove +54
    
    // Check if mobile indicator 9 is present after country code
    if (afterCountry.startsWith('9')) {
      const afterMobile = afterCountry.substring(1); // Remove mobile indicator 9
      return parseArgentineNumber(afterMobile); // No trunk prefix needed
    } else {
      // No mobile indicator
      return parseArgentineNumber(afterCountry); // No trunk prefix needed
    }
  } else {
    // No country code, must start with trunk prefix 0
    if (!cleanValue.startsWith('0')) return false;
    
    const afterTrunk = cleanValue.substring(1); // Remove trunk prefix 0
    return parseArgentineNumber(afterTrunk); // Trunk prefix already accounted for
  }
}

/**
 * Helper function to validate the area code and subscriber number
 */
function parseArgentineNumber(number: string): boolean {
  // Try different area code lengths (2-4 digits)
  for (let areaCodeLength = 2; areaCodeLength <= 4; areaCodeLength++) {
    if (number.length < areaCodeLength) break;
    
    const areaCode = number.substring(0, areaCodeLength);
    const subscriberNumber = number.substring(areaCodeLength);
    
    // Area code validation: 2-4 digits, first digit cannot be 0
    if (areaCode[0] === '0') continue; // Skip invalid area codes
    
    // Subscriber number validation: 6-8 digits
    if (subscriberNumber.length >= 6 && subscriberNumber.length <= 8 && /^\d+$/.test(subscriberNumber)) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validates personal names according to common conventions.
 * Permits unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Trim whitespace
  const trimmedValue = value.trim();
  if (trimmedValue.length === 0) return false;
  
  // Check for disallowed characters: digits and special symbols (except allowed ones)
  // Allowed: unicode letters (including accented), apostrophes, hyphens, spaces
  // Disallowed: digits, and special symbols like @, #, $, %, &, *, etc.
  
  // This regex checks if the name contains only allowed character types:
  // \p{L} matches any Unicode letter (including accented letters)
  // ' matches apostrophe
  // - matches hyphen
  // \s matches whitespace
  const namePattern = /^[\p{L}'\-\s]+$/u;
  
  if (!namePattern.test(trimmedValue)) return false;
  
  // Additional check: no consecutive spaces or hyphens
  if (/\s{2,}/.test(trimmedValue)) return false; // Multiple spaces
  
  // Check for unusual patterns that suggest non-name inputs (e.g., "X Æ A-12")
  // This looks for digits in the name or excessive unusual characters
  if (/[0-9]/.test(trimmedValue)) return false;
  
  // Check for reasonable length (not too short and not too long)
  if (trimmedValue.length < 1 || trimmedValue.length > 100) return false;
  
  // Ensure the name doesn't start or end with a hyphen or apostrophe
  if (/^['\s-]|['\s-]$/.test(trimmedValue)) return false;
  
  return true;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks card prefixes and lengths, and runs a Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces, hyphens and other separators
  const cleanCardNumber = value.replace(/[\s-]/g, '');
  
  // Must be numeric and have appropriate length (13-19 digits)
  if (!/^\d+$/.test(cleanCardNumber)) return false;
  if (cleanCardNumber.length < 13 || cleanCardNumber.length > 19) return false;
  
  // Check card-specific patterns:
  const isVisa = /^4/.test(cleanCardNumber) && (cleanCardNumber.length === 13 || cleanCardNumber.length === 16);
  const isMastercard = /^5[1-5]/.test(cleanCardNumber) && cleanCardNumber.length === 16;
  const isAmex = /^3[47]/.test(cleanCardNumber) && cleanCardNumber.length === 15;
  
  // Must match one of the supported card patterns
  if (!isVisa && !isMastercard && !isAmex) return false;
  
  // Run Luhn algorithm check
  return runLuhnCheck(cleanCardNumber);
}

/**
 * Implements the Luhn algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        // Sum the digits of the product (equivalent to subtracting 9)
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
