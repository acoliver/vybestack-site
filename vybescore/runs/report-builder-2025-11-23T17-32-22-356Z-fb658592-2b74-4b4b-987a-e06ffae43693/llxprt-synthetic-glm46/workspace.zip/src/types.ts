// Report data structure
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportEntry {
  label: string;
  amount: number;
}

// Shared interface for rendering options
export interface RenderOptions {
  includeTotals?: boolean;
}

// Format type
export type ReportFormat = "markdown" | "text";

// Renderer interface
export interface ReportRenderer {
  render(data: ReportData, options?: RenderOptions): string;
}