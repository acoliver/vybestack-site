#!/usr/bin/env node

import fs from 'node:fs';
import type { ReportData, ReportFormat, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map formats to renderers
const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText
};

// Parse CLI arguments
function parseArgs(): {
  inputFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('--format is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1] as ReportFormat;
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  return { inputFile, format, outputPath, includeTotals };
}

// Validate format
function validateFormat(format: string): ReportFormat {
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}. Supported formats: markdown, text`);
  }
  return format as ReportFormat;
}

// Load and validate JSON data
function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = fs.readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Basic structure validation
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON: expected an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (!reportData.title || typeof reportData.title !== 'string') {
      throw new Error('Invalid report data: missing or invalid title');
    }
    
    if (!reportData.summary || typeof reportData.summary !== 'string') {
      throw new Error('Invalid report data: missing or invalid summary');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid report data: missing or invalid entries array');
    }
    
    // Validate entries
    for (const [index, entry] of (reportData.entries as unknown[]).entries()) {
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid entry at index ${index}: expected an object`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (!entryObj.label || typeof entryObj.label !== 'string') {
        throw new Error(`Invalid entry at index ${index}: missing or invalid label`);
      }
      
      if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
        throw new Error(`Invalid entry at index ${index}: missing or invalid amount`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Malformed JSON: ${error.message}`);
    }
    throw error;
  }
}

// Main function
function main(): void {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArgs();
    
    // Validate format
    const validatedFormat = validateFormat(format);
    
    // Load report data
    const reportData = loadReportData(inputFile);
    
    // Prepare render options
    const options: RenderOptions = { includeTotals };
    
    // Render report
    const renderer = formatRenderers[validatedFormat];
    const output = renderer.render(reportData, options);
    
    // Write output
    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf8');
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error occurred');
    process.exit(1);
  }
}

// Run main function
main();