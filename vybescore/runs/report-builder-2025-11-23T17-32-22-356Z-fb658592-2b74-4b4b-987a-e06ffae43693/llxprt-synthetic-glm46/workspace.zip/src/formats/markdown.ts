import type { ReportData, ReportRenderer, RenderOptions } from '../types.js';

export const renderMarkdown: ReportRenderer = {
  render(data: ReportData, options?: RenderOptions): string {
    const { title, summary, entries } = data;
    const { includeTotals = false } = options || {};
    
    let result = '';
    
    // Add title
    result += `# ${title}\n\n`;
    
    // Add summary
    result += `${summary}\n\n`;
    
    // Add entries section
    result += `## Entries\n`;
    
    for (const entry of entries) {
      const formattedAmount = `$${entry.amount.toFixed(2)}`;
      result += `- **${entry.label}** — ${formattedAmount}\n`;
    }
    
    // Add total if requested
    if (includeTotals) {
      const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
      const formattedTotal = `$${total.toFixed(2)}`;
      result += `\n**Total:** ${formattedTotal}`;
    }
    
    return result;
  }
};