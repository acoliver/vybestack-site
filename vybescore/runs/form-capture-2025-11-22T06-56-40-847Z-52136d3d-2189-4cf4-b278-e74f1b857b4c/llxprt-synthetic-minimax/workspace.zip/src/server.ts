import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'fs/promises';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// SQLite database setup
let db: Database | null = null;
const DB_FILE_PATH = path.join(__dirname, '../data/submissions.sqlite');

async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, `../node_modules/sql.js/dist/${file}`)
    });

    try {
      const dbFile = await fs.readFile(DB_FILE_PATH);
      db = new SQL.Database(new Uint8Array(dbFile));
    } catch (error) {
      // Database file doesn't exist, create a new one
      db = new SQL.Database();
      const schema = await fs.readFile(path.join(__dirname, '../db/schema.sql'), 'utf-8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

async function saveDatabase(): Promise<void> {
  if (db) {
    const data = db.export();
    await fs.writeFile(DB_FILE_PATH, Buffer.from(data));
  }
}

function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Validation functions
interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
  [key: string]: string | undefined;
}

function validateFormData(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields: (keyof FormData)[] = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email', 'phone'];
  
  for (const field of requiredFields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim() === '') {
      errors[field] = 'This field is required';
    }
  }

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (international formats)
  if (data.phone && !/^\+?[0-9\s\-()]{7,}$/.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]{3,10}$/.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: {}, 
    formData: {},
    title: 'Contact Us'
  });
});

app.post('/submit', async (req, res) => {
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body;

  const validation = validateFormData(req.body);

  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      formData: req.body,
      title: 'Contact Us - Please Fix Errors'
    });
  }

  if (!db) {
    return res.status(500).send('Database not available');
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone]);
    stmt.free();

    await saveDatabase();

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

// Graceful shutdown handling
function gracefulShutdown(signal: string): void {
  console.log(`
Received ${signal}. Starting graceful shutdown...`);
  
  closeDatabase();
  
  console.log('Database closed. Server shutting down.');
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer(): Promise<void> {
  await initDatabase();
  
  app.listen(PORT, () => {
    console.log(` Server running on http://localhost:${PORT}`);
    console.log(' Form available at /');
    console.log(' Database file:', DB_FILE_PATH);
  });
}

// Export the app for testing
export default app;

// Start server automatically if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}
