/**
 * Capitalizes the first character of each sentence.
 */
export function capitalizeSentences(text: string): string {
  // Split the text into sentences using .!? as delimiters
  const sentences = text.split(/([.?!])/);
  
  // Process each sentence
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i] || '';
    const punctuation = sentences[i + 1] || '';
    
    // Trim the sentence and capitalize first character if it exists
    const trimmed = sentence.trim();
    if (trimmed) {
      const capitalized = trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
      // Preserve original spacing after punctuation
      sentences[i] = capitalized;
      
      // Ensure exactly one space after punctuation before the next sentence
      if (i + 1 < sentences.length && i + 2 < sentences.length) {
        const nextSentence = sentences[i + 2] || '';
        if (nextSentence && !sentences[i + 1].endsWith('  ')) {
          sentences[i + 1] = punctuation + ' ';
        }
      }
    }
  }
  
  // Join the sentences back together
  let result = sentences.join('');
  
  // Collapse multiple spaces into single spaces, but be careful with sentence endings
  result = result.replace(/\s{2,}/g, ' ');
  
  return result;
}

/**
 * Finds URLs in the text. Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs
  const urlRegex = /https?:\/\/[-A-Z0-9+&@#/%?=~_|!:,.;]*[-A-Z0-9+&@#/%=~_|]/gi;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  // Clean up trailing punctuation
  if (!matches) return [];
  
  return matches.map(url => {
    // Remove trailing punctuation like .,!?) but not part of the URL
    return url.replace(/[.,!?)]+$/g, '');
  });
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First, ensure all URLs are https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match URLs from example.com domain with docs path  
  const docsUrlRegex = /(https?:\/\/example\.com\/docs\/.*?)(?=[\s]|$)/g;
  
  // Check if the path contains dynamic hints or legacy extensions that should prevent host rewrite
  const rewriteHost = (url: string): string => {
    // Avoid rewriting if URL contains dynamic hints or legacy extensions
    const excludePatterns = [/(\/cgi-bin\/|[?&=]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/];
    
    for (const pattern of excludePatterns) {
      if (pattern.test(url)) {
        return url;
      }
    }
    
    // Rewrite docs URLs to docs.example.com
    return url.replace(/https:\/\/example\.com\/docs\//, 'https://docs.example.com/docs/');
  };
  
  // Replace each matched docs URL
  result = result.replace(docsUrlRegex, (match) => rewriteHost(match));
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy strings. Returns 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Basic validation for month/day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Days in each month (simplified - not handling leap years in detail)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for valid day based on month
  if (dayNum > daysInMonth[monthNum - 1]) {
    // Handle February 29 for leap years
    if (monthNum === 2 && dayNum === 29) {
      const yearNum = parseInt(year, 10);
      // Check for leap year (divisible by 4, not by 100 unless also by 400)
      if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0) {
        return year;
      }
    }
    return 'N/A';
  }
  
  return year;
}
