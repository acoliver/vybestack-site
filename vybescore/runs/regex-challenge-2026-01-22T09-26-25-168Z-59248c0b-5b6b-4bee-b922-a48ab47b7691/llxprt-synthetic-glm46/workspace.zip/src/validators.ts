export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with proper RFC compliance.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  if (!emailRegex.test(value)) {
    return false;
  }
  // Disallow consecutive dots in local part
  if (value.includes('..')) {
    return false;
  }
  // Disallow dots at start or end of local part
  const [localPart, domain] = value.split('@');
  if (!localPart || !domain) {
    return false;
  }
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  // Disallow underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  // Disallow consecutive dots in domain
  if (domain.includes('..')) {
    return false;
  }
  return true;
}

/**
 * Validates US phone numbers with optional country code and common formats.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it has optional +1 prefix
  const hasCountryCode = value.startsWith('+1');
  let phoneNumber = digitsOnly;
  
  if (hasCountryCode) {
    phoneNumber = digitsOnly.substring(1);
  }
  
  // Must be 10 digits for standard US number
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check for valid area code (cannot start with 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check format with regex for common patterns
  const phoneRegex = /^\+?1?[\s-]*\(?(\d{3})\)?[\s-]*(\d{3})[\s-]*(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers with optional country code and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens first for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with optional country code and mobile indicator
  const argentinePhoneRegex = /^(\+54)?(0?)(9?)([1-9]\d{0,3})(\d{6,8})$/;
  
  if (!argentinePhoneRegex.test(cleanValue)) {
    return false;
  }
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, countryCode, trunkPrefix, , areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits starting with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // If country code is omitted, trunk prefix is required
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // Ensure pattern matches original formats when separators are considered
  const patternWithSeparators = /^(\+54[\s-]*)?(0[\s-]*)?(9[\s-]*)?([1-9]\d{0,3})[\s-]*(\d{2,4})[\s-]*(\d{4,8})$/;
  
  // Also check alternative format where area code and subscriber are separated differently
  const altPatternWithSeparators = /^(\+54[\s-]*)?(0[\s-]*)?(9[\s-]*)?([1-9]\d{0,3})[\s-]*(\d{4,4})[\s-]*(\d{4,4})$/;
  
  return patternWithSeparators.test(value) || altPatternWithSeparators.test(value);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols (except allowed punctuation)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject if contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for obvious invalid patterns like "X Æ A-12"
  const invalidPatternRegex = /.*\d+.*/;
  if (invalidPatternRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers with proper prefixes and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if the value contains only digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Check Visa (13 or 16 digits starting with 4)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard (16 digits starting with 51-55 or 2221-2720)
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]\d|3[0-8]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|[7][0-9]\d|[8][0-9]\d|[9][0-1]\d|72[0])\d{12}$/;
  
  // Check AmEx (15 digits starting with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Verify the card matches one of the accepted types
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Start from the rightmost digit
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
