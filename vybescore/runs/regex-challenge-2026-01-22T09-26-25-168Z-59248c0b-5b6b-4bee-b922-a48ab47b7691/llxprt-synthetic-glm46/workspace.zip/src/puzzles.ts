/**
 * Finds words starting with the prefix but excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words with the given prefix
  // Using \b for word boundaries and [a-zA-Z] for word characters
  const prefixRegex = new RegExp(`\\b(${prefix}[a-zA-Z]+)`, 'g');
  
  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Filter out matches that are in the exceptions list
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex pattern to match the token only when preceded by a digit
  // Using \\d for digit and \\b for word boundaries
  const tokenPattern = new RegExp(`\\d(${token})(?!\\d)`, 'g');
  
  // Find all matches
  const matches = text.match(tokenPattern) || [];
  
  // Extract just the token with the preceding digit
  return matches.map(match => match);
}

/**
 * Validates passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length of 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Check for at least one uppercase letter
  const uppercaseRegex = /[A-Z]/;
  if (!uppercaseRegex.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  const lowercaseRegex = /[a-z]/;
  if (!lowercaseRegex.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  const digitRegex = /\d/;
  if (!digitRegex.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  const symbolRegex = /[^\w\s]/;
  if (!symbolRegex.test(value)) {
    return false;
  }
  
  // Check for no whitespace
  const whitespaceRegex = /\s/;
  if (whitespaceRegex.test(value)) {
    return false;
  }
  
  // Check for no immediate repeated sequences (e.g., abab)
  const repeatedSequenceRegex = /(.{2,})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that matches various IPv6 formats including shorthand
  const ipv6Patterns = [
    // Full IPv6: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
    /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/,
    // IPv6 with :: (zero compression)
    /^([0-9a-fA-F]{1,4}:){1,7}:$/,
    /::([0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}$/,
    // Mixed IPv6 with port
    /^\[([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}](?::\d+)?$/,
    // IPv6 with 1 to 7 colons
    /^([0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4}$/,
    /^([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}$/,
    /^([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}$/,
    /^([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}$/,
    /^([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}$/,
    /^[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})$/,
    /^:((:[0-9a-fA-F]{1,4}){1,7}|:)$/
  ];
  
  // First check for IPv4 to exclude
  const ipv4Regex = /^(\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Check if the value matches any IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  // Also check for IPv6 addresses within a larger string
  const embeddedIPv6Pattern = /(([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4})|::|([0-9a-fA-F]{1,4}:){1,6}:/;
  return embeddedIPv6Pattern.test(value);
}
