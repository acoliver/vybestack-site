import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;
const app = express();

// Middleware
app.use(express.static(path.resolve(__dirname, '..', 'public')));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow leading +, digits, spaces, parentheses, dashes
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(formData: FormData): ValidationResult {
  const errors: string[] = [];

  // Required fields
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push('First name is required');
  }
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  if (!formData.city || formData.city.trim() === '') {
    errors.push('City is required');
  }
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }
  if (!formData.email || formData.email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(formData.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!formData.phone || formData.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhone(formData.phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
  }
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, spaces, and dashes');
  }
  if (!formData.country || formData.country.trim() === '') {
    errors.push('Country is required');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Try to load existing database
    let dbData: Uint8Array | undefined = undefined;
    try {
      const fs = await import('node:fs');
      if (fs.existsSync(dbPath)) {
        const buffer = fs.readFileSync(dbPath);
        dbData = new Uint8Array(buffer);
      }
    } catch (err) {
      // File doesn't exist yet, will create new database
    }

    db = new SQL.Database(dbData);

    // If database is new, run schema
    if (!dbData) {
      try {
        const fs = await import('node:fs');
        const schema = fs.readFileSync(schemaPath, 'utf-8');
        db.run(schema);
        await saveDatabase();
      } catch (err) {
        console.error('Error loading schema:', err);
      }
    }
  } catch (err) {
    console.error('Failed to initialize database:', err);
    throw err;
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) return;

  try {
    const fs = await import('node:fs');
    const data = db.export();
    const buffer = Buffer.from(data);
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, buffer);
  } catch (err) {
    console.error('Failed to save database:', err);
    throw err;
  }
}

// Close database
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form.ejs', {
      errors: validation.errors,
      formData
    });
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );

    // Save database to disk
    saveDatabase().catch((err) => {
      console.error('Failed to save database after insert:', err);
    });

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (err) {
    console.error('Database error:', err);
    res.status(500).render('form.ejs', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you.ejs');
});

// Configure EJS
// Views are always in src/views (not compiled to dist)
// When compiled, __dirname is dist, so we need to go up to src
const viewsPath = path.resolve(__dirname, '..', 'src', 'views');
app.set('views', viewsPath);
app.set('view engine', 'ejs');

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = async () => {
    console.log('Shutting down gracefully...');
    server.close(() => {
      console.log('Server closed');
      closeDatabase();
      process.exit(0);
    });

    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      closeDatabase();
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Start the server and export the ready promise
const serverReady = startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

// Export for testing
export { app, initializeDatabase, closeDatabase, saveDatabase, serverReady };
