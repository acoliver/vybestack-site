import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type Express from 'express';

let app: Express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }

  // Import and start server
  const serverModule = await import('../../src/server.js');
  app = serverModule.app;
  
  // Wait for server to be ready
  if (serverModule.serverReady) {
    await serverModule.serverReady;
  }
});

afterAll(() => {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Get In Touch');
    
    const $ = cheerio.load(response.text);
    
    // Check all required fields exist with proper labels and ids
    expect($('label[for="firstName"]').text()).toContain('First Name');
    expect($('#firstName').attr('name')).toBe('firstName');
    
    expect($('label[for="lastName"]').text()).toContain('Last Name');
    expect($('#lastName').attr('name')).toBe('lastName');
    
    expect($('label[for="streetAddress"]').text()).toContain('Street Address');
    expect($('#streetAddress').attr('name')).toBe('streetAddress');
    
    expect($('label[for="city"]').text()).toContain('City');
    expect($('#city').attr('name')).toBe('city');
    
    expect($('label[for="stateProvince"]').text()).toContain('State / Province / Region');
    expect($('#stateProvince').attr('name')).toBe('stateProvince');
    
    expect($('label[for="postalCode"]').text()).toContain('Postal / Zip Code');
    expect($('#postalCode').attr('name')).toBe('postalCode');
    
    expect($('label[for="country"]').text()).toContain('Country');
    expect($('#country').attr('name')).toBe('country');
    
    expect($('label[for="email"]').text()).toContain('Email');
    expect($('#email').attr('name')).toBe('email');
    
    expect($('label[for="phone"]').text()).toContain('Phone Number');
    expect($('#phone').attr('name')).toBe('phone');
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('POST');
  });

  it('shows validation errors for empty required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Email is required');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'invalid-email',
        phone: '+44 20 7946 0958'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });

  it('validates phone format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: 'invalid-phone!@#'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number can only contain');
  });

  it('validates postal code format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A! 1AA',
        country: 'United Kingdom',
        email: 'john@example.com',
        phone: '+44 20 7946 0958'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Postal code must contain only letters');
  });

  it('persists submission and redirects', async () => {
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 High Street',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'jane.smith@example.com',
      phone: '+54 9 11 1234-5678'
    };

    const response = await request(app)
      .post('/submit')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('renders thank you page with humorous content', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank You');
    expect(response.text.toLowerCase()).toMatch(/spam|identity|stranger/);
  });

  it('handles international phone formats', async () => {
    const testCases = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '123-456-7890'
    ];

    for (const phone of testCases) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode: '12345',
          country: 'Test Country',
          email: 'test@example.com',
          phone
        });
      
      // Should not get phone validation error
      if (response.status === 400) {
        expect(response.text).not.toContain('Phone number can only contain');
      }
    }
  });

  it('handles international postal codes', async () => {
    const testCases = [
      { postalCode: 'SW1A 1AA', country: 'United Kingdom' },
      { postalCode: 'C1000', country: 'Argentina' },
      { postalCode: 'B1675', country: 'Argentina' },
      { postalCode: '12345', country: 'United States' }
    ];

    for (const { postalCode, country } of testCases) {
      const response = await request(app)
        .post('/submit')
        .send({
          firstName: 'Test',
          lastName: 'User',
          streetAddress: '123 Test St',
          city: 'Test City',
          stateProvince: 'Test State',
          postalCode,
          country,
          email: 'test@example.com',
          phone: '+1 555-123-4567'
        });
      
      // Should not get postal code validation error
      if (response.status === 400) {
        expect(response.text).not.toContain('Postal code must contain only');
      }
    }
  });

  it('preserves form data on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'invalid-email',
        phone: '+44 20 7946 0958'
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    expect($('#firstName').attr('value')).toBe('John');
    expect($('#lastName').attr('value')).toBe('Doe');
    expect($('#city').attr('value')).toBe('London');
  });
});
