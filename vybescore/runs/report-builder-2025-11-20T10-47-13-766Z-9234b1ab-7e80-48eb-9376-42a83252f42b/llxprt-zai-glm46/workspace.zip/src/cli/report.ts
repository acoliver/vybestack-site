#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { exit } from 'node:process';

import type { ReportData, FormatOptions, FormatType, Formatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<FormatType, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  dataPath: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }
  
  const dataPath = args[0];
  
  let format: FormatType | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format': {
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          exit(1);
        }
        const formatValue = args[i + 1];
        if (formatValue !== 'markdown' && formatValue !== 'text') {
          console.error(`Error: Unsupported format "${formatValue}"`);
          exit(1);
        }
        format = formatValue as FormatType;
        i++;
        break;
      }
        
      case '--output': {
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          exit(1);
        }
        outputPath = args[i + 1];
        i++;
        break;
      }
        
      case '--includeTotals':
        includeTotals = true;
        break;
        
      default:
        console.error(`Error: Unknown argument "${args[i]}"`);
        exit(1);
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    exit(1);
  }
  
  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }
  
  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "label" field`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} missing or invalid "amount" field`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });
  
  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

async function main(): Promise<void> {
  try {
    const args = parseArgs();
    
    let data: unknown;
    try {
      const fileContent = await readFile(args.dataPath, 'utf8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file "${args.dataPath}": ${error.message}`);
      } else {
        console.error(`Error: Could not read file "${args.dataPath}": ${error instanceof Error ? error.message : String(error)}`);
      }
      exit(1);
    }
    
    let reportData: ReportData;
    try {
      reportData = validateReportData(data);
    } catch (error) {
      console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
      exit(1);
    }
    
    const formatter = formatters[args.format];
    const options: FormatOptions = { includeTotals: args.includeTotals };
    const output = formatter.render(reportData, options);
    
    if (args.outputPath) {
      try {
        await writeFile(args.outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error: Could not write to file "${args.outputPath}": ${error instanceof Error ? error.message : String(error)}`);
        exit(1);
      }
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}