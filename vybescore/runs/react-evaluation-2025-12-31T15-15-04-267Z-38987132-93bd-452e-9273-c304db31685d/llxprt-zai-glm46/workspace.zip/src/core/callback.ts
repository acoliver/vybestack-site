/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Store updateFn in an object that can be captured by reference
  const fnContainer = { fn: updateFn }
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      // Don't run if disposed
      if (observer.disposed) return prevValue as T
      // Run the actual update function which performs side effects
      // Call it and return the result
      return fnContainer.fn(prevValue)
    },
    disposed: false,
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  return () => {
    if (observer.disposed) return
    observer.disposed = true
  }
}
