/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  getActiveObserver,
  EqualFn,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // We need both an observer (to track dependencies) and a subject (to notify dependents)
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    disposed: false,
  }
  
  // Add observers set to make this computed observable by others
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }
  
  // Initialize by running the update function to track dependencies
  updateObserver(o)
  s.value = o.value!
  
  // Create a getter that returns the current value and acts as both observer and subject
  const getter: GetterFn<T> = () => {
    const active = getActiveObserver()
    // If being accessed by another observer, register this computed as a dependency
    if (active && !active.disposed && active !== o) {
      s.observers.add(active)
    }
    return s.value
  }
  
  // Override updateObserver to update both observer and subject
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    s.value = result
    // Notify all observers of this computed that it has changed
    notifyObservers(s)
    return result
  }
  
  return getter
}
