// Debug test - check if callback is called when input changes
import { createInput, createComputed, createCallback } from './src/index.ts'

const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

const valueHolder = { value: 0 }
console.log('Initial value:', valueHolder.value)

console.log('\nCreating callback...')
createCallback(() => {
  console.log('  >>> CALLBACK EXECUTING <<<')
  const out = output()
  console.log('  output() =', out)
  valueHolder.value = out
  console.log('  Set valueHolder.value to', valueHolder.value)
  console.log('  >>> CALLBACK DONE <<<')
})
console.log('After callback creation, valueHolder.value:', valueHolder.value)

console.log('\nCalling setInput(3)...')
setInput(3)
console.log('After setInput(3), valueHolder.value:', valueHolder.value)
console.log('Expected: 4')

console.log('\nCalling output() directly...')
console.log('output() =', output())
console.log('valueHolder.value =', valueHolder.value)
