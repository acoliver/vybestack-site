// Test closure behavior
let counter = 0

function createUpdater() {
  let localValue = 0
  
  return () => {
    console.log('  createUpdater called, localValue =', localValue)
    localValue = counter + 1
    console.log('  Set localValue to', localValue)
    counter = localValue
    console.log('  Set counter to', counter)
    return localValue
  }
}

const updater = createUpdater()
console.log('Initial counter:', counter)
console.log('Calling updater...')
updater()
console.log('After first call, counter:', counter)

counter = 10
console.log('\nSet counter to 10')
console.log('Calling updater again...')
updater()
console.log('After second call, counter:', counter)
