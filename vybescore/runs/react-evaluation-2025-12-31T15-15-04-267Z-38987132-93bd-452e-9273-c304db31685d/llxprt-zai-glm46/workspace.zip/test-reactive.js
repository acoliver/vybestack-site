// Simple test to understand the reactive system
import { createInput, createComputed, createCallback } from './dist/index.js'

console.log('Testing reactive system...')

// Test 1: Basic computed that depends on input
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Initial state:')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
console.log('  Expected sum: 32')

setInput(3)
console.log('After setInput(3):')
console.log('  input:', input())
console.log('  timesTwo:', timesTwo())
console.log('  timesThirty:', timesThirty())
console.log('  sum:', sum())
console.log('  Expected sum: 96')

// Test 2: Callbacks
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => { value = output() })
console.log('\nCallback test:')
console.log('  Initial value:', value)
setInput2(3)
console.log('  After setInput2(3), value:', value)
console.log('  Expected: 4')
