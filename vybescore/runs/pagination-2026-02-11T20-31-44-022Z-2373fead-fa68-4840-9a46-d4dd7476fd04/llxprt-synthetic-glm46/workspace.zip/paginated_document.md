# Example Document

This is an example document with multiple pages and tables.

**Document Version:** 1.0  
**Author:** Author Name  
**Created:** December 2023

## Document Content

Page 1:
Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

Page 2:
Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

Page 3:
Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo.

Page 4:
Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.

Page 5:
At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium voluptatum deleniti atque corrupti quos dolores et quas molestias excepturi sint occaecati cupiditate non provident.

## Tables Section

This table is on page 6:

| Name | Age | Occupation |
|------|-----|------------|
| John Doe | 35 | Software Engineer |
| Jane Smith | 28 | Data Scientist |
| Mike Johnson | 42 | Project Manager |
| Sarah Williams | 31 | UX Designer |
| Tom Brown | 39 | DevOps Engineer |
| Emily Davis | 33 | Product Manager |
| Alex Wilson | 36 | QA Engineer |

Another table on page 7:

| Product | Price | Stock |
|---------|-------|-------|
| Laptop | $999 | 45 |
| Mouse | $25 | 120 |
| Keyboard | $75 | 85 |
| Monitor | $300 | 30 |
| Headphones | $150 | 60 |
| Webcam | $80 | 95 |

The final page (page 8) contains this conclusion:

In conclusion, this document demonstrates pagination with tables across multiple pages. This allows for better organization and presentation of information.