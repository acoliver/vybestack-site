import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import cookieParser from 'cookie-parser';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const PORT = process.env.PORT || 3000;
const DB_PATH = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

interface FormValues {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

const app = express();

// Middleware to parse form data
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

// Serve static files from public directory
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

// Set up EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, 'templates'));

// Initialize SQLite database
let db: Database;

async function initDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load SQL.js
    const SQL = await initSqlJs({
      locateFile: (file) => path.resolve(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    // Initialize database (create new if doesn't exist)
    let dbBuffer: Uint8Array;
    if (fs.existsSync(DB_PATH)) {
      dbBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbBuffer);
    } else {
      // Create new database and apply schema
      db = new SQL.Database();
      const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      db.run(schema);
      saveDatabase(); // Save the newly created database
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Form validation function
function validateForm(values: FormValues): ValidationResult {
  const errors: string[] = [];

  // Required fields validation
  if (!values.firstName?.trim()) {
    errors.push('First name is required');
  }
  if (!values.lastName?.trim()) {
    errors.push('Last name is required');
  }
  if (!values.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  if (!values.city?.trim()) {
    errors.push('City is required');
  }
  if (!values.stateProvince?.trim()) {
    errors.push('State / Province / Region is required');
  }
  if (!values.postalCode?.trim()) {
    errors.push('Postal / Zip code is required');
  }
  if (!values.country?.trim()) {
    errors.push('Country is required');
  }
  if (!values.email?.trim()) {
    errors.push('Email is required');
  }
  if (!values.phone?.trim()) {
    errors.push('Phone number is required');
  }

  // Email validation using simple regex
  if (values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone number validation (allow digits, spaces, parentheses, dashes, leading +)
  if (values.phone && !/^[+]?[0-9\s\-()]+$/.test(values.phone)) {
    errors.push('Please enter a valid phone number');
  }

  // Postal code validation (alphanumeric strings)
  if (values.postalCode && !/^[a-zA-Z0-9\s]+$/.test(values.postalCode)) {
    errors.push('Please enter a valid postal code');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formValues = req.body as FormValues;
  const validation = validateForm(formValues);

  if (!validation.isValid) {
    return res.status(400).render('form', { 
      errors: validation.errors, 
      values: formValues 
    });
  }

  try {
    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formValues.firstName || '',
      formValues.lastName || '',
      formValues.streetAddress || '',
      formValues.city || '',
      formValues.stateProvince || '',
      formValues.postalCode || '',
      formValues.country || '',
      formValues.email || '',
      formValues.phone || ''
    ]);
    stmt.free();

    // Save database
    saveDatabase();

    // Store first name in a session-like way using a cookie
    res.cookie('firstName', formValues.firstName, { maxAge: 5 * 60 * 1000, httpOnly: false });
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form', { 
      errors: ['An error occurred while submitting the form. Please try again.'], 
      values: formValues 
    });
  }
});

app.get('/thank-you', (req, res) => {
  // Get first name from cookie
  const firstName = req.cookies?.firstName || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown function (currently unused but reserved for future use)
// function gracefulShutdown(signal: string): void {
//   console.log(`Received ${signal}. Closing server and database...`);
//   
//   if (db) {
//     db.close();
//     console.log('Database connection closed.');
//   }
//   
//   process.exit(0);
// }

// Start the server
async function startServer(): Promise<void> {
  try {
    await initDatabase();
    
    const httpServer = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    // Store server reference for graceful shutdown
    (global as Record<string, unknown>).server = httpServer;
    
    // Set up signal handlers for graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM signal received.');
      if (httpServer) httpServer.close(() => {
        if (db) db.close();
        console.log('Server and database closed gracefully');
        process.exit(0);
      });
    });
    
    process.on('SIGINT', () => {
      console.log('SIGINT signal received.');
      if (httpServer) httpServer.close(() => {
        if (db) db.close();
        console.log('Server and database closed gracefully');
        process.exit(0);
      });
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Define a type for the Express server
type ExpressServer = ReturnType<typeof app.listen>;

// Export server for testing
const server = {
  app,
  close: () => {
    if ((global as Record<string, unknown>).server) {
      ((global as Record<string, unknown>).server as ExpressServer).close();
    }
    if (db) db.close();
  }
};

// Only start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default server;
