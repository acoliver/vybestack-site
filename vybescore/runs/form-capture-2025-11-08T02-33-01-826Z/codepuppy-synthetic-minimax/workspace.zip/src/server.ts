import express, { Express, Request, Response } from 'express';
import path from 'path';
import fs from 'fs/promises';
import { fileURLToPath } from 'url';
import type { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

class FormServer {
  private app: Express;
  private db: Database | null = null;
  private readonly dbPath: string;
  private lastSubmittedFirstName: string | null = null;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    console.log('Database path:', this.dbPath);
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private async initializeDatabase(): Promise<void> {
    try {
      const sqlModule = await import('sql.js');
      const SQL = await sqlModule.default({
        locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
      });

      let dbData: Uint8Array | null = null;
      
      // Try to load existing database
      try {
        const existingDb = await fs.readFile(this.dbPath);
        dbData = new Uint8Array(existingDb);
      } catch (error) {
        // Database doesn't exist, create new one
        console.log('Creating new database');
      }

      this.db = new SQL.Database(dbData || undefined);

      // Create table if it doesn't exist
      let schemaPath: string;
      try {
        // Try development path first
        schemaPath = path.resolve(__dirname, '..', '..', 'db', 'schema.sql');
        await fs.access(schemaPath);
      } catch {
        // Fallback to test environment path
        schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
      }
      
      const schema = await fs.readFile(schemaPath, 'utf-8');
      if (this.db) {
        this.db.run(schema);
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private validateFormData(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation (simple regex) - always validate format regardless of emptiness
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (data.email !== undefined && !emailRegex.test(data.email?.trim() || '')) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone validation (international formats) - always validate format regardless of emptiness
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (data.phone !== undefined && !phoneRegex.test(data.phone?.trim() || '')) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    // Postal code validation (alphanumeric) - always validate format regardless of emptiness
    const postalRegex = /^[\d\s\-A-Za-z]+$/;
    if (data.postalCode !== undefined && !postalRegex.test(data.postalCode?.trim() || '')) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal/zip code' });
    }

    return errors;
  }

  private async saveSubmission(data: FormData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName?.trim(),
      data.lastName?.trim(),
      data.streetAddress?.trim(),
      data.city?.trim(),
      data.stateProvince?.trim(),
      data.postalCode?.trim(),
      data.country?.trim(),
      data.email?.trim(),
      data.phone?.trim(),
    ]);

    stmt.free();

    // Store the first name for the thank you page
    this.lastSubmittedFirstName = data.firstName?.trim() || null;

    // Save database to disk
    await this.saveDatabaseToDisk();
  }

  private async saveDatabaseToDisk(): Promise<void> {
    if (!this.db) return;

    try {
      console.log('Saving database to:', this.dbPath);
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      await fs.mkdir(dataDir, { recursive: true });

      const data = this.db.export();
      await fs.writeFile(this.dbPath, Buffer.from(data));
      console.log('Database saved successfully');
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  private setupRoutes(): void {
    // GET route for the form
    this.app.get('/', (req: Request, res: Response) => {
      const errors: string[] = [];
      const values: FormData = {};
      
      res.render('form', { errors, values });
    });

    // POST route for form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      const formData: FormData = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        streetAddress: req.body.streetAddress,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone,
      };

      const validationErrors = this.validateFormData(formData);

      if (validationErrors.length > 0) {
        const errorMessages = validationErrors.map(err => err.message);
        res.status(400).render('form', {
          errors: errorMessages,
          values: formData,
        });
        return;
      }

      try {
        await this.saveSubmission(formData);
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Failed to save submission:', error);
        const errorMessages = ['Failed to save your submission. Please try again.'];
        res.status(500).render('form', {
          errors: errorMessages,
          values: formData,
        });
      }
    });

    // GET route for thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = this.lastSubmittedFirstName || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(port?: number): Promise<void> {
    await this.initializeDatabase();
    
    const serverPort = port || (process.env.PORT ? parseInt(process.env.PORT, 10) : 3000);
    
    return new Promise((resolve) => {
      this.server = this.app.listen(serverPort, () => {
        console.log(`Server running on port ${serverPort}`);
        resolve();
      });
    });
  }

  public async stop(): Promise<void> {
    console.log('Shutting down server...');
    
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          console.log('Server closed');
          if (this.db) {
            this.db.close();
            this.db = null;
          }
          resolve();
        });
      } else {
        if (this.db) {
          this.db.close();
          this.db = null;
        }
        resolve();
      }
    });
  }

  private server: ReturnType<Express['listen']> | null = null;
  public getApp(): Express {
    return this.app;
  }
}

// Export a factory function to create server instances
export function createServer(): FormServer {
  return new FormServer();
}

// Only auto-start if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const serverInstance = new FormServer();
  
  // Graceful shutdown handling
  process.on('SIGTERM', async () => {
    console.log('Received SIGTERM, shutting down gracefully');
    await serverInstance.stop();
    process.exit(0);
  });
  
  process.on('SIGINT', async () => {
    console.log('Received SIGINT, shutting down gracefully');
    await serverInstance.stop();
    process.exit(0);
  });
  
  // Start the server
  serverInstance.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default createServer;