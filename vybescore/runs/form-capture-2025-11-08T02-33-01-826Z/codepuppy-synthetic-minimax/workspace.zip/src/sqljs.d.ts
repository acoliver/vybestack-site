declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): SqlStatement;
    export(): Uint8Array;
    close(): void;
  }

  export interface SqlStatement {
    run(...params: unknown[]): void;
    get(...params: unknown[]): unknown;
    all(...params: unknown[]): unknown[];
    free(): void;
  }

  export interface SqlJsConfig {
    locateFile?: (file: string) => string;
  }

  export function initSqlJs(config?: SqlJsConfig): Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;
  
  export default initSqlJs;
}