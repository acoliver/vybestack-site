import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: { stop: () => Promise<void>; getApp: () => unknown } | null;
let app: unknown;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import and start the server
  const serverModule = await import('../../src/server.js');
  const createServer = serverModule.default;
  const serverInstance = createServer();
  await serverInstance.start(0); // Use port 0 to get a random available port
  app = serverInstance.getApp();
  server = serverInstance;
});

afterAll(async () => {
  if (server && server.stop) {
    await server.stop();
  }
  // Clean up database file
  if (fs.existsSync(dbPath)) {
    try {
      fs.unlinkSync(dbPath);
    } catch (error) {
      // Ignore cleanup errors
    }
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form action
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john.doe@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Check that database file was created
    console.log('Expected dbPath:', dbPath);
    console.log('Current working dir:', process.cwd());
    console.log('Files in data dir:', fs.readdirSync('data').filter(f => f.includes('sqlite')));
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles validation errors', async () => {
    const invalidData = {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: 'invalid-phone',
    };

    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(invalidData);

    // Should show form with errors
    expect(response.status).toBe(400);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = cheerio.load(response.text);
    const errorMessages = $('.error-list li').map((i, el) => $(el).text()).get();
    console.log('Error messages:', errorMessages);
    console.log('Error count:', errorMessages.length);
    expect($('.error-list li')).toHaveLength(10); // All fields should have errors
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = cheerio.load(response.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('body').text()).toContain('stranger on the internet');
  });
});