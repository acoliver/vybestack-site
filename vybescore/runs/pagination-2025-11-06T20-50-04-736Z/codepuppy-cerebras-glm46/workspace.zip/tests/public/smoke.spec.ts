import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('properly paginates with default parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items).toHaveLength(5);
    
    // Check that we have the first 5 items
    expect(response.body.items[0].id).toBe(1);
    expect(response.body.items[4].id).toBe(5);
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const page1 = await request(app).get('/inventory?page=1&limit=5');
    expect(page1.status).toBe(200);
    expect(page1.body.page).toBe(1);
    expect(page1.body.limit).toBe(5);
    expect(page1.body.hasNext).toBe(true);
    expect(page1.body.items).toHaveLength(5);
    
    const page2 = await request(app).get('/inventory?page=2&limit=5');
    expect(page2.status).toBe(200);
    expect(page2.body.page).toBe(2);
    expect(page2.body.limit).toBe(5);
    expect(page2.body.hasNext).toBe(true);
    expect(page2.body.items).toHaveLength(5);
    
    // Ensure different items per page
    expect(page1.body.items[0].id).toBe(1);
    expect(page2.body.items[0].id).toBe(6);
    
    const page3 = await request(app).get('/inventory?page=3&limit=5');
    expect(page3.status).toBe(200);
    expect(page3.body.page).toBe(3);
    expect(page3.body.limit).toBe(5);
    expect(page3.body.hasNext).toBe(false); // Last page
    expect(page3.body.items).toHaveLength(5);
    
    // Last page should have items 11-15
    expect(page3.body.items[0].id).toBe(11);
    expect(page3.body.items[4].id).toBe(15);
  });

  it('validates invalid page parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test negative page
    const negativePage = await request(app).get('/inventory?page=-1');
    expect(negativePage.status).toBe(400);
    expect(negativePage.body.error).toContain('positive integer');
    
    // Test zero page
    const zeroPage = await request(app).get('/inventory?page=0');
    expect(zeroPage.status).toBe(400);
    expect(zeroPage.body.error).toContain('positive integer');
    
    // Test non-numeric page
    const textPage = await request(app).get('/inventory?page=abc');
    expect(textPage.status).toBe(400);
    expect(textPage.body.error).toContain('positive integer');
    
    // Test empty page
    const emptyPage = await request(app).get('/inventory?page=');
    expect(emptyPage.status).toBe(400);
    expect(emptyPage.body.error).toContain('positive integer');
  });

  it('validates invalid limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test negative limit
    const negativeLimit = await request(app).get('/inventory?limit=-1');
    expect(negativeLimit.status).toBe(400);
    expect(negativeLimit.body.error).toContain('positive integer');
    
    // Test zero limit
    const zeroLimit = await request(app).get('/inventory?limit=0');
    expect(zeroLimit.status).toBe(400);
    expect(zeroLimit.body.error).toContain('positive integer');
    
    // Test excessive limit
    const excessiveLimit = await request(app).get('/inventory?limit=101');
    expect(excessiveLimit.status).toBe(400);
    expect(excessiveLimit.body.error).toContain('cannot exceed 100');
    
    // Test non-numeric limit
    const textLimit = await request(app).get('/inventory?limit=abc');
    expect(textLimit.status).toBe(400);
    expect(textLimit.body.error).toContain('positive integer');
  });

  it('handles edge cases correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test page beyond available data
    const beyondPage = await request(app).get('/inventory?page=100');
    expect(beyondPage.status).toBe(200);
    expect(beyondPage.body.page).toBe(100);
    expect(beyondPage.body.items).toHaveLength(0);
    expect(beyondPage.body.hasNext).toBe(false);
    
    // Test limit larger than total items
    const largeLimit = await request(app).get('/inventory?limit=20');
    expect(largeLimit.status).toBe(200);
    expect(largeLimit.body.page).toBe(1);
    expect(largeLimit.body.items).toHaveLength(15); // All items
    expect(largeLimit.body.hasNext).toBe(false);
  });
});
