import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Parse and validate numeric inputs
    let page: number | undefined;
    let limit: number | undefined;

    if (pageParam !== undefined) {
      if (pageParam === '' || isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'Page must be a positive integer' });
      }
      page = Number(pageParam);
    }

    if (limitParam !== undefined) {
      if (limitParam === '' || isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'Limit must be a positive integer' });
      }
      limit = Number(limitParam);
    }

    try {
      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid request parameters';
      return res.status(400).json({ error: message });
    }
  });

  return app;
}
