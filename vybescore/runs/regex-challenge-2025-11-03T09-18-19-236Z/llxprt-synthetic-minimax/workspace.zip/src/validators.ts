export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern
  // Local part: letters, numbers, dots, underscores, hyphens, plus (no double dots, no leading/trailing dots)
  // Domain part: valid domain with TLD (no underscores)
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  // No double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dot before @
  const atIndex = value.indexOf('@');
  if (value[atIndex - 1] === '.') {
    return false;
  }
  
  // No domain with underscore
  const domain = value.substring(atIndex + 1);
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length (10 or 11 digits with +1)
  if (cleaned.length === 11 && cleaned.startsWith('1')) {
    // Valid 11-digit number starting with 1
  } else if (cleaned.length === 10) {
    // Valid 10-digit number
  } else {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = cleaned.length === 11 ? cleaned.substring(1, 4) : cleaned.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) and punctuation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for valid pattern:
  // Optional +54
  // Optional trunk prefix 0
  // Optional mobile indicator 9
  // Area code: 2-4 digits (first digit 1-9)
  // Subscriber number: 6-8 digits
  
  // Match various formats
  // Format 1: +54 9 11 1234 5678 (mobile with country code)
  // Format 2: 011 1234 5678 (landline without country code)
  // Format 3: +54 341 123 4567 (landline with country code)
  // Format 4: 0341 4234567 (landline with trunk prefix)
  
  // Pattern breakdown:
  // ^\+?54?9?0?(\d{2,4})(\d{6,8})$
  
  const pattern = /^\+?54?9?0?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // When country code is omitted, must begin with trunk prefix (0)
  if (!cleaned.startsWith('+54')) {
    if (!cleaned.startsWith('0')) {
      return false;
    }
  }
  
  // Area code must start with 1-9 (not 0)
  if (areaCode[0] === '0') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  throw new Error('TODO: implement isValidName');
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  throw new Error('TODO: implement isValidCreditCard');
}
