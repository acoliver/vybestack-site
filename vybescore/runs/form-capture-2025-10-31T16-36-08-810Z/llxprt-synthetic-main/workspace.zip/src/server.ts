import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Interface for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

// Interface for validation errors
interface ValidationError {
  field: string;
  message: string;
}

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../src/templates'));

// Database variables
let db: Database | null = null;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load SQL.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Check if database file exists
    if (fs.existsSync(DB_PATH)) {
      const filebuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(filebuffer);
      console.log('Database loaded from file');
    } else {
      db = new SQL.Database();
      console.log('New database created');
    }

    // Read and execute schema
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;

  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value.trim()) {
    return {
      field: fieldName,
      message: `${fieldName} is required`
    };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return {
      field: 'email',
      message: 'Please enter a valid email address'
    };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return {
      field: 'phone',
      message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +'
    };
  }
  return null;
}

function validatePostalCode(postalCode: string): ValidationError | null {
  // Allow alphanumeric postal codes with spaces
  const postalCodeRegex = /^[a-zA-Z0-9\s]+$/;
  if (!postalCodeRegex.test(postalCode)) {
    return {
      field: 'postalCode',
      message: 'Postal code can only contain letters, numbers, and spaces'
    };
  }
  return null;
}

// Validate form data
function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // Check required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const error = validateRequired(data[field] || '', field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase()));
    if (error) errors.push(error);
  }

  // Validate specific fields
  if (data.email) {
    const emailError = validateEmail(data.email);
    if (emailError) errors.push(emailError);
  }

  if (data.phone) {
    const phoneError = validatePhone(data.phone);
    if (phoneError) errors.push(phoneError);
  }

  if (data.postalCode) {
    const postalError = validatePostalCode(data.postalCode);
    if (postalError) errors.push(postalError);
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
  }

  // Save to database if no errors
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, state_province,
          postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName || '',
        formData.lastName || '',
        formData.streetAddress || '',
        formData.city || '',
        formData.stateProvince || '',
        formData.postalCode || '',
        formData.country || '',
        formData.email || '',
        formData.phone || ''
      ]);

      stmt.free();
      saveDatabase();
      console.log('Form submission saved');
    } catch (error) {
      console.error('Failed to save submission:', error);
      return res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: formData
      });
    }
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission to extract the first name
  let firstName = 'Friend';
  
  if (db) {
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      const result = stmt.get() as unknown as { first_name: string } | undefined;
      if (result && result.first_name) {
        firstName = result.first_name;
      }
      stmt.free();
    } catch (error) {
      console.error('Failed to retrieve submission:', error);
    }
  }

  res.render('thank-you', { firstName });
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  // Handle graceful shutdown
  const gracefulShutdown = (): void => {
    console.log('Shutting down gracefully...');
    
    if (server) {
      server.close(() => {
        console.log('HTTP server closed');
      });
    }
    
    if (db) {
      saveDatabase();
      db.close();
      console.log('Database connection closed');
    }
    
    process.exit(0);
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Start the application
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});