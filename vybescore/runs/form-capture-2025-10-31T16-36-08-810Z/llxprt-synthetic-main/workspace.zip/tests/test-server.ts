import { fork, ChildProcess } from 'child_process';

let serverProcess: ChildProcess | null = null;

export async function startServer(port = 3000): Promise<ChildProcess> {
  // Kill any existing server process
  await stopServer();
  
  // Set port environment variable
  process.env.PORT = port.toString();
  
  // Fork the server process
  serverProcess = fork('./dist/server.js', [], {
    detached: true,
    stdio: ['ignore', 'inherit', 'inherit', 'ipc']
  });
  
  // Wait a moment for the server to start
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  return serverProcess;
}

export async function stopServer(): Promise<void> {
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
    serverProcess = null;
  }
  
  // Also kill any stray server processes
  try {
    const { exec } = await import('child_process');
    const { promisify } = await import('util');
    const execAsync = promisify(exec);
    const { stdout } = await execAsync('pgrep -f "node dist/server.js"');
    const pids = stdout.trim().split('\n');
    
    for (const pid of pids) {
      if (pid) {
        try {
          process.kill(parseInt(pid), 'SIGTERM');
        } catch (e) {
          // Process may already be dead
        }
      }
    }
  } catch (e) {
    // No process found or other error, ignore
  }
}