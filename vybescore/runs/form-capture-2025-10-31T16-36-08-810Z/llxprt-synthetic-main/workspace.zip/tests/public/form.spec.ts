import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import supertest from 'supertest';
import { startServer, stopServer } from '../test-server';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Start the server for the tests
  await startServer();
}, 15000);

afterAll(async () => {
  // Stop the server after tests
  await stopServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await supertest('http://localhost:3000')
      .get('/')
      .expect(200);
      
    expect(response.text).toContain('Friendly Contact Form');
    expect(response.text).toContain('firstName');
    expect(response.text).toContain('lastName');
    expect(response.text).toContain('streetAddress');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
    expect(response.text).toContain('postalCode');
    expect(response.text).toContain('country');
  });

  it('persists submission and redirects', async () => {
    // Start with a clean slate
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Submit the form with proper content type
    const response = await supertest('http://localhost:3000')
      .post('/submit')
      .type('form')
      .send({
        firstName: 'Jane',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'jane@example.com',
        phone: '+1 555-123-4567'
      });
        
    // Should redirect after successful submission
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
      
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
