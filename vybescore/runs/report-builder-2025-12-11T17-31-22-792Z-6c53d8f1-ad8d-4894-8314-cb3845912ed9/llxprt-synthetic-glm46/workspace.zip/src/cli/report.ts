#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions } from '../types/report.js';
import { formatters } from '../formats/index.js';

// Parse command line arguments
function parseArgs(): { dataFile: string; options: ReportOptions } | null {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    return null;
  }

  const dataFile = args[0];
  if (!dataFile.endsWith('.json')) {
    console.error('Error: Data file must be a JSON file');
    return null;
  }

  // Find required format argument
  const formatIndex = args.findIndex(arg => arg === '--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    return null;
  }

  const format = args[formatIndex + 1];
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format "${format}"`);
    return null;
  }

  // Find optional output argument
  const outputIndex = args.findIndex(arg => arg === '--output');
  let output: string | undefined;
  if (outputIndex !== -1 && outputIndex + 1 < args.length) {
    output = args[outputIndex + 1];
  }

  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');

  return {
    dataFile,
    options: {
      format: format as 'markdown' | 'text',
      output,
      includeTotals
    }
  };
}

// Load and validate JSON data
function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Report data must have a "title" string');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Report data must have a "summary" string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Report data must have an "entries" array');
    }

    // Validate entries
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Each entry must have a "label" string');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Each entry must have an "amount" number');
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file "${filePath}": ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to load data from "${filePath}"`);
    }
    process.exit(1);
    // TypeScript doesn't know process.exit() doesn't return
    throw new Error();
  }
}

// Main function
function main(): void {
  const parsed = parseArgs();
  if (!parsed) {
    process.exit(1);
    return;
  }

  const { dataFile, options } = parsed;
  const data = loadReportData(dataFile);

  // Get the appropriate formatter
  const formatter = formatters[options.format];
  if (!formatter) {
    console.error(`Error: Unsupported format "${options.format}"`);
    process.exit(1);
    return;
  }

  // Generate the report
  const reportContent = formatter(data, { includeTotals: options.includeTotals });

  // Output the report
  if (options.output) {
    try {
      writeFileSync(options.output, reportContent);
      console.error(`Report written to ${options.output}`);
    } catch (error) {
      console.error(`Error writing to file "${options.output}":`, error);
      process.exit(1);
    }
  } else {
    console.log(reportContent);
  }
}

// Run the CLI
main();
