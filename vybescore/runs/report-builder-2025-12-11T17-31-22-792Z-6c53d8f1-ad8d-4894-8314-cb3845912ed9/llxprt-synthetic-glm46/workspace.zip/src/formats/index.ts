import type { ReportRenderer } from '../types/report.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

// Map format strings to their corresponding renderer functions
export const formatters: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText
};

// Export individual renderers for direct use if needed
export { renderMarkdown, renderText };