import type { ReportRenderer } from '../types/report.js';

export const renderText: ReportRenderer = (data, { includeTotals }) => {
  const { title, summary, entries } = data;

  // Calculate total if requested
  const total = includeTotals
    ? entries.reduce((sum, entry) => sum + entry.amount, 0)
    : null;

  // Helper to format amounts with two decimal places
  const formatAmount = (amount: number): string => {
    return `$${amount.toFixed(2)}`;
  };

  // Build the text content
  let output = `${title}

${summary}

Entries:
`;

  // Add entries as bullet list
  for (const entry of entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }

  // Add total if requested
  if (includeTotals && total !== null) {
    output += `Total: ${formatAmount(total)}\n`;
  }

  return output;
};