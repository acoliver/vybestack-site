/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

const INVALID_BASE64_MESSAGE = 'Invalid Base64 input';
const PADDING_ONLY_REGEX = /^=+$/;
const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates the input and throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding resulted in empty buffer when input wasn't just padding
    if (buffer.length === 0 && !PADDING_ONLY_REGEX.test(trimmed)) {
      throw new Error(INVALID_BASE64_MESSAGE);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }
}

/**
 * Validate that a string is properly formatted Base64.
 * Allows both padded and unpadded input.
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }

  // Check for valid Base64 characters (standard alphabet)
  if (!BASE64_REGEX.test(input)) {
    return false;
  }

  // Check that total length is a multiple of 4 (including padding)
  if (input.length % 4 !== 0) {
    return false;
  }

  // Check that padding is only at the end and properly applied
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Once padding starts, it must continue to the end
    const paddingSection = input.slice(paddingIndex);
    if (!/^=+$/.test(paddingSection)) {
      return false;
    }
    // Padding can be at most 2 characters
    if (paddingSection.length > 2) {
      return false;
    }
  }

  return true;
}
