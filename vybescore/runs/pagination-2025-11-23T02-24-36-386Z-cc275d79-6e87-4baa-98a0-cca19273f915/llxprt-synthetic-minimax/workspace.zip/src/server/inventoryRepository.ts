import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage {
  // Validate inputs
  const page = options.page;
  const limit = options.limit;

  // Validate page parameter
  if (page !== undefined && (!Number.isInteger(page) || page < 1 || page > 1000000)) {
    throw new Error('Invalid page parameter. Page must be a positive integer.');
  }

  // Validate limit parameter
  if (limit !== undefined && (!Number.isInteger(limit) || limit < 1 || limit > 100)) {
    throw new Error('Invalid limit parameter. Limit must be a positive integer between 1 and 100.');
  }

  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  const safePage = page && page > 0 ? Math.floor(page) : 1;
  const safeLimit = limit && limit > 0 ? Math.floor(limit) : DEFAULT_LIMIT;

  // Fixed: correct offset calculation (page - 1) * limit
  const offset = (safePage - 1) * safeLimit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: safeLimit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  // Fixed: correct hasNext calculation
  const hasNext = safePage * safeLimit < total;

  return {
    items: rows,
    page: safePage,
    limit: safeLimit,
    total,
    hasNext
  };
}
