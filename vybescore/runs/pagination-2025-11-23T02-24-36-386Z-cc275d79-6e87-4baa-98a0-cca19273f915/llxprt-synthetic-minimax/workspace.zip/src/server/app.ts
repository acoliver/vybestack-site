import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      // Parse and validate query parameters
      let page: number | undefined;
      let limit: number | undefined;

      if (pageParam !== undefined) {
        const parsedPage = Number(pageParam);
        if (!Number.isFinite(parsedPage) || !Number.isInteger(parsedPage)) {
          return res.status(400).json({ error: 'Invalid page parameter. Page must be a positive integer.' });
        }
        page = parsedPage;
      }

      if (limitParam !== undefined) {
        const parsedLimit = Number(limitParam);
        if (!Number.isFinite(parsedLimit) || !Number.isInteger(parsedLimit)) {
          return res.status(400).json({ error: 'Invalid limit parameter. Limit must be a positive integer.' });
        }
        limit = parsedLimit;
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      // Handle validation errors from the repository
      if (error instanceof Error && error.message.includes('Invalid')) {
        return res.status(400).json({ error: error.message });
      }
      
      // Handle other errors with generic message
      console.error('Error fetching inventory:', error);
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
