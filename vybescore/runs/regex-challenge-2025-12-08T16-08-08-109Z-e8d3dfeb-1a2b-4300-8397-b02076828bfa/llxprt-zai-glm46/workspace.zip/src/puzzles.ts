/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex to match words starting with the prefix
  // \b for word boundary, [a-zA-Z]* for remaining characters
  const wordRegex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(word => word.toLowerCase());
  
  return matches
    .filter(word => !lowerExceptions.includes(word.toLowerCase()))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find token preceded by digit but not at start of string
  // Pattern: digit + token, but not at the beginning
  const tokensWithDigits = text.match(new RegExp(`\\d${escapedToken}`, 'g')) || [];
  
  // Return the full match (digit + token), not just the token
  return tokensWithDigits;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences like abab
  // Check for any 2-character pattern repeated consecutively
  if (/(.{2})\1/.test(value)) {
    return false;
  }
  
  // Check for longer repeated patterns
  // Look for any substring of 3+ characters repeated consecutively
  for (let len = 3; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.substring(i, i + len);
      if (value.substring(i + len, i + len * 2) === pattern) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns - these should NOT match IPv4 addresses
  
  // Full IPv6: 8 groups of 1-4 hex digits separated by colons
  const fullIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // IPv6 with :: shorthand (compressing zeros)
  // Must contain at least one colon and be valid IPv6 format
  const shorthandIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){0,7}:[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{1,4})*\b/;
  
  // IPv6 with mixed IPv4 (should still count as IPv6)
  const mixedIPv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if any IPv6 pattern matches
  return fullIPv6Regex.test(value) || shorthandIPv6Regex.test(value) || mixedIPv6Regex.test(value);
}
