export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex that handles:
  // - Local part: letters, digits, +, ., -, _, single quotes
  // - Domain: letters, digits, -, . (no underscores)
  // - No double dots, no trailing dots
  // - Top-level domain: 2-63 letters
  const emailRegex = /^[a-zA-Z0-9._%+\-']+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,63}$/;
  
  // First check basic format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject leading or trailing dots in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  const domain = value.substring(value.indexOf('@') + 1);
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let phoneDigits = digitsOnly;
  if (phoneDigits.startsWith('1') && phoneDigits.length === 11) {
    phoneDigits = phoneDigits.slice(1);
  }
  
  // US phone numbers should be exactly 10 digits after removing country code
  if (phoneDigits.length !== 10) {
    return false;
  }
  
  // Extract area code, prefix, and line number
  const areaCode = phoneDigits.slice(0, 3);
  const prefix = phoneDigits.slice(3, 6);
  const lineNumber = phoneDigits.slice(6, 10);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format matches common patterns
  const patterns = [
    /^\d{10}$/, // 5555555555
    /^\d{3}-\d{3}-\d{4}$/, // 555-555-5555
    /^\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/, // (555) 555-5555, (555)555-5555
  ];
  
  return patterns.some(pattern => pattern.test(value.replace(/^\+1\s*/, '')));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const clean = value.replace(/[\s-]/g, '');
  
  // Extract the digits for detailed validation
  const digitsOnly = clean.replace(/\D/g, '');
  
  let areaCode = '';
  let subscriberNumber = '';
  
  if (digitsOnly.startsWith('54')) {
    // Has country code
    let rest = digitsOnly.slice(2);
    
    if (rest.startsWith('9')) {
      rest = rest.slice(1);
    }
    
    if (rest.startsWith('0')) {
      rest = rest.slice(1);
    }
    
    // Area code should be 2-4 digits starting with 1-9
    for (let i = 2; i <= 4 && i <= rest.length; i++) {
      const potentialAreaCode = rest.slice(0, i);
      const potentialSubscriber = rest.slice(i);
      
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode) && 
          potentialSubscriber.length >= 6 && 
          potentialSubscriber.length <= 8) {
        areaCode = potentialAreaCode;
        subscriberNumber = potentialSubscriber;
        break;
      }
    }
  } else {
    // No country code, must start with trunk prefix 0
    if (!digitsOnly.startsWith('0')) {
      return false;
    }
    
    let rest = digitsOnly.slice(1);
    
    // Area code should be 2-4 digits starting with 1-9
    for (let i = 2; i <= 4 && i <= rest.length; i++) {
      const potentialAreaCode = rest.slice(0, i);
      const potentialSubscriber = rest.slice(i);
      
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode) && 
          potentialSubscriber.length >= 6 && 
          potentialSubscriber.length <= 8) {
        areaCode = potentialAreaCode;
        subscriberNumber = potentialSubscriber;
        break;
      }
    }
  }
  
  // Validate that we found valid components
  return areaCode.length > 0 && 
         subscriberNumber.length >= 6 && 
         subscriberNumber.length <= 8;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and special characters
  const nameRegex = /^[\p{L}\p{M}'-]+(?:\s[\p{L}\p{M}'-]+)*$/u;
  return nameRegex.test(value) && value.trim().length > 0;
}

/**
 * TODO: Validate credit card numbers for major brands using regex and Luhn algorithm.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits and has valid length
  if (!/^\d+$/.test(cleanNumber)) {
    return false;
  }
  
  // Check valid lengths for different card types
  const validLengths = [13, 14, 15, 16, 17, 18, 19];
  if (!validLengths.includes(cleanNumber.length)) {
    return false;
  }
  
  // Check prefixes for major card brands
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3})?$/;
  const mastercardRegex = /^5[1-5][0-9]{14}$/;
  const amexRegex = /^3[47][0-9]{13}$/;
  
  if (!visaRegex.test(cleanNumber) && 
      !mastercardRegex.test(cleanNumber) && 
      !amexRegex.test(cleanNumber)) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}

function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}