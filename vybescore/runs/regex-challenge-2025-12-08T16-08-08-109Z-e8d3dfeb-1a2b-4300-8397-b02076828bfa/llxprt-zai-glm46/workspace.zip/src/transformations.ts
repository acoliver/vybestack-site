export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Split by sentence endings (. ? !) followed by optional whitespace
  const sentences = text.split(/([.!?])(?:\s*)/);
  
  let result = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part.match(/[.!?]/)) {
      // This is a sentence ending - add the punctuation and a space
      result += part + ' ';
      capitalizeNext = true;
    } else if (part.trim()) {
      // This is sentence content
      if (capitalizeNext) {
        // Capitalize first letter
        const capitalized = part.charAt(0).toUpperCase() + part.slice(1);
        result += capitalized;
        capitalizeNext = false;
      } else {
        result += part;
      }
    }
    // Skip empty/whitespace parts
  }
  
  // Clean up extra spaces but preserve single space after punctuation
  return result.replace(/\s+/g, ' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // More comprehensive URL regex that captures the full URL including query parameters
  // Match http/https, followed by domain name with at least one dot, and optional path/query
  const urlRegex = /https?:\/\/[^\s\)\]}\[<>'"`,;:!?]+/g;
  const matches = text.match(urlRegex) || [];
  
  // Remove only trailing punctuation, preserve query parameters and fragments
  return matches.map(url => url.replace(/[.,;:!?'"`\)\]\}]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://docs.example.com/... while preserving dynamic URLs.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs with domain and capture the path
  const urlRegex = /(https?:\/\/)([^/]+)(\/.*)?/g;
  
  return text.replace(urlRegex, (match, protocol, domain, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    if (!path) {
      return newProtocol + domain;
    }
    
    // Check if path contains dynamic hints that should prevent host rewrite
    const hasDynamicHints = /[?&=]|\/(cgi-bin|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      const newDomain = domain.startsWith('docs.') ? domain : `docs.${domain}`;
      return newProtocol + newDomain + path;
    }
    
    // Otherwise, just upgrade the protocol
    return newProtocol + domain + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check if matches mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12) and day (1-31)
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Additional validation for days per month (simplified)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
  const febDays = isLeapYear ? 29 : 28;
  
  if (month === 2 && day > febDays) {
    return 'N/A';
  }
  
  if (month !== 2 && day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}