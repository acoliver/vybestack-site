/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, ensure there's exactly one space after sentence endings .?!
  // This handles cases where there might be no space or multiple spaces
  let processed = text.replace(/([.?!])(\s*)/g, (match, punctuation) => {
    return punctuation + ' ';
  });
  
  // Now capitalize the first character after sentence endings
  processed = processed.replace(/([.?!]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize the very first character of the string
  if (processed.length > 0) {
    processed = processed[0].toUpperCase() + processed.slice(1);
  }
  
  // Collapse multiple spaces to a single space (but preserve at least one after sentences)
  processed = processed.replace(/ +/g, ' ');
  
  // Trim any leading/trailing spaces
  processed = processed.trim();
  
  return processed;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern matching http/https and www URLs
  // This pattern captures the full URL including the domain and path
  // We use a more precise pattern to match the complete URL
  const urlPattern = /(https?:\/\/[^\s<>\[\]"']+|(?:www\.)[^\s<>\[\]"']+?[^.\s])(?=[,.!?;:)\]\}\s]|$)/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => url.replace(/[,.!?;:)\]\}]+$/g, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https:// but leave https:// unchanged
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // This regex matches http://example.com URLs with various paths
  // We'll use a function to determine which URLs need special handling
  return text.replace(/(http:\/\/example\.com)(\/[^\s]*)?/gi, (match, host, path = '') => {
    // Always upgrade scheme to https
    const httpsHost = 'https://example.com';
    
    // Check if path needs special handling
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that would prevent the host rewrite
      const hasDynamicHints = 
        path.includes('cgi-bin') || 
        path.includes('?') || 
        path.includes('&') || 
        path.includes('=') ||
        /\.jsp$/.test(path) ||
        /\.php$/.test(path) ||
        /\.asp$/.test(path) ||
        /\.aspx$/.test(path) ||
        /\.do$/.test(path) ||
        /\.cgi$/.test(path) ||
        /\.pl$/.test(path) ||
        /\.py$/.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        return 'https://docs.example.com' + path;
      }
    }
    
    // Default: just upgrade scheme
    return httpsHost + path;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format where mm is 01-12, dd is 01-31, and yyyy is any 4-digit year
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  // The year is in the third capture group
  return match[3];
}
