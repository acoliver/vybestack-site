export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex:
  // - local part: allow letters, digits, dots (but not consecutive), hyphens, pluses, apostrophes
  // - @ symbol
  // - domain: allow letters, digits, hyphens, but no underscores
  // - TLD: 2-63 characters starting with a letter
  const emailRegex = /^[a-zA-Z0-9]+[a-zA-Z0-9._%+-]*[a-zA-Z0-9]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,63}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for consecutive dots in the local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Check for leading or trailing dots in the local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for trailing dot in the domain
  const domain = value.substring(value.indexOf('@') + 1);
  if (domain.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in the domain
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for standard US numbers)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Check if it has country code +1
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length > 11) {
    // If more than 11 digits, it's invalid
    return false;
  }
  
  // Check if we have exactly 10 digits now
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first digit cannot be 0 or 1)
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate the format with common separators
  const phoneRegex = /^(\+1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // If country code is present, it must be +54
  if (cleanNumber.startsWith('+54')) {
    const afterCountryCode = cleanNumber.substring(3);
    
    // Check for optional mobile indicator '9'
    let afterMobileIndicator = afterCountryCode;
    if (afterCountryCode.startsWith('9')) {
      afterMobileIndicator = afterCountryCode.substring(1);
    }
    
    // Check for trunk prefix '0' before area code
    let areaCodeAndNumber = afterMobileIndicator;
    if (afterMobileIndicator.startsWith('0')) {
      areaCodeAndNumber = afterMobileIndicator.substring(1);
    }
    
    // Area code must be 2-4 digits with leading digit 1-9
    const areaCodeMatch = areaCodeAndNumber.match(/^([1-9]\d{1,3})(\d+)$/);
    if (!areaCodeMatch) return false;
    
    const subscriberNumber = areaCodeMatch[2];
    
    // Subscriber number must be 6-8 digits
    return subscriberNumber.length >= 6 && subscriberNumber.length <= 8;
    
  } else {
    // If no country code, must start with trunk prefix '0'
    if (!cleanNumber.startsWith('0')) return false;
    
    const afterTrunkPrefix = cleanNumber.substring(1);
    
    // Check for optional mobile indicator '9'
    let areaCodeAndNumber = afterTrunkPrefix;
    if (afterTrunkPrefix.startsWith('9')) {
      areaCodeAndNumber = afterTrunkPrefix.substring(1);
    }
    
    // Area code must be 2-4 digits with leading digit 1-9
    const areaCodeMatch = areaCodeAndNumber.match(/^([1-9]\d{1,3})(\d+)$/);
    if (!areaCodeMatch) return false;
    
    const subscriberNumber = areaCodeMatch[2];
    
    // Subscriber number must be 6-8 digits
    return subscriberNumber.length >= 6 && subscriberNumber.length <= 8;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Basic format check
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject names that contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names with too many special characters relative to letters
  // This helps filter out contrived names like "X Æ A-12"
  const specialCharCount = (value.match(/['\-]/g) || []).length;
  const letterCount = (value.match(/\p{L}/gu) || []).length;
  
  // Special characters shouldn't exceed a reasonable proportion of the name
  if (letterCount > 0 && specialCharCount > letterCount / 2) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to run Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    const digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      let doubledDigit = digit * 2;
      if (doubledDigit > 9) {
        doubledDigit = doubledDigit - 9;
      }
      sum += doubledDigit;
    } else {
      sum += digit;
    }
    
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  if (/^4(\d{12}|\d{15})$/.test(cardNumber)) {
    return runLuhnCheck(cardNumber);
  }
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  if (/^(5[1-5]\d{14}|222[1-9]\d{12}|22[3-9]\d{13}|2[3-6]\d{14}|27[01]\d{13}|2720\d{12})$/.test(cardNumber)) {
    return runLuhnCheck(cardNumber);
  }
  
  // American Express: 15 digits, starts with 34 or 37
  if (/^3[47]\d{13}$/.test(cardNumber)) {
    return runLuhnCheck(cardNumber);
  }
  
  // No matching card pattern
  return false;
}
