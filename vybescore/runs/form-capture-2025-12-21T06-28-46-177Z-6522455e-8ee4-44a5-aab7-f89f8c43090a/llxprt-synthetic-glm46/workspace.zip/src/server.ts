import express from 'express';
import path from 'path';
import { database, type Submission } from './database.js';
import { FormValidator, type FormValues } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'templates'));

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    values: {}, 
    errors: [] 
  });
});

app.post('/submit', async (req, res) => {
  const formData: FormValues = req.body;
  const errors = FormValidator.validate(formData);
  
  if (errors.length > 0) {
    res.status(400).render('form', {
      values: formData,
      errors: errors.map(e => e.message)
    });
    return;
  }

  try {
    const submission: Omit<Submission, 'id' | 'created_at'> = {
      first_name: formData.firstName!.trim(),
      last_name: formData.lastName!.trim(),
      street_address: formData.streetAddress!.trim(),
      city: formData.city!.trim(),
      state_province: formData.stateProvince!.trim(),
      postal_code: formData.postalCode!.trim(),
      country: formData.country!.trim(),
      email: formData.email!.trim(),
      phone: formData.phone!.trim()
    };

    await database.insertSubmission(submission);
    await database.saveToFile();
    
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      values: formData,
      errors: ['An unexpected error occurred. Please try again.']
    });
  }
});

app.get('/thank-you', (req, res) => {
  // For the humor, we'll just use a generic name since we don't store session data
  res.render('thank-you', { firstName: 'friend' });
});

// Graceful shutdown
let server: import('http').Server;

const gracefulShutdown = async () => {
  console.log('Shutting down gracefully...');
  
  if (server) {
    server.close(() => {
      console.log('Express server closed');
    });
  }
  
  database.close();
  console.log('Database connection closed');
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer() {
  try {
    await database.initialize();
    console.log('Database initialized');
    
    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
