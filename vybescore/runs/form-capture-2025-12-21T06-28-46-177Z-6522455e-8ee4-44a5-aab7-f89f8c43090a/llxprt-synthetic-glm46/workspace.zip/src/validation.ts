export type FormValues = {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
};

export type ValidationError = {
  field: string;
  message: string;
};

export class FormValidator {
  static validate(values: FormValues): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    if (!this.isRequired(values.firstName)) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }

    if (!this.isRequired(values.lastName)) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }

    if (!this.isRequired(values.streetAddress)) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }

    if (!this.isRequired(values.city)) {
      errors.push({ field: 'city', message: 'City is required' });
    }

    if (!this.isRequired(values.stateProvince)) {
      errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
    }

    if (!this.isRequired(values.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
    }

    if (!this.isRequired(values.country)) {
      errors.push({ field: 'country', message: 'Country is required' });
    }

    if (!this.isRequired(values.email)) {
      errors.push({ field: 'email', message: 'Email is required' });
    } else if (!this.isValidEmail(values.email!)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    if (!this.isRequired(values.phone)) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    } else if (!this.isValidPhone(values.phone!)) {
      errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
    }

    if (values.postalCode && !this.isValidPostalCode(values.postalCode!)) {
      errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
    }

    return errors;
  }

  private static isRequired(value?: string): boolean {
    return value !== undefined && value.trim().length > 0;
  }

  private static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email.trim());
  }

  private static isValidPhone(phone: string): boolean {
    // Accept international formats: +44 20 7946 0958, +54 9 11 1234-5678, etc.
    const phoneRegex = /^\+?[0-9\s\-()]+$/;
    return phoneRegex.test(phone.trim()) && phone.trim().length >= 7;
  }

  private static isValidPostalCode(postalCode: string): boolean {
    // Accept alphanumeric postal codes (UK: SW1A 1AA, Argentina: C1000, B1675, etc.)
    const postalRegex = /^[a-zA-Z0-9\s-]+$/;
    return postalRegex.test(postalCode.trim()) && postalCode.trim().length >= 3;
  }
}