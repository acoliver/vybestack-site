import fs from 'fs/promises';
import path from 'path';
import createDatabase from 'sql.js';

type DatabaseInstance = {
  run: (sql: string, params?: readonly unknown[]) => void;
  exec: (sql: string) => { values: unknown[][] }[];
  export: () => Uint8Array;
  close: () => void;
};

export type Submission = {
  id?: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at?: string;
};

export class Database {
  private db: DatabaseInstance | null;
  private filePath: string;

  constructor() {
    this.db = null;
    this.filePath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    const SQL = await createDatabase();
    
    // Try to load existing database
    try {
      const fileBuffer = await fs.readFile(this.filePath);
      this.db = new SQL.Database(fileBuffer) as DatabaseInstance;
    } catch (error) {
      // Database doesn't exist, create new one
      this.db = new SQL.Database() as DatabaseInstance;
      this.createSchema();
    }
  }

  private createSchema(): void {
    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;
    
    this!.db!.run(schema);
  }

  async insertSubmission(submission: Omit<Submission, 'id' | 'created_at'>): Promise<number> {
    try {
      // Direct run method with parameters
      this!.db!.run(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `, [
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone
      ]);

      // Get the last inserted row id
      const result = this!.db!.exec('SELECT last_insert_rowid() as id');
      return result[0].values[0][0] as number;
    } catch (error) {
      console.error('Database insertion error:', error);
      throw error;
    }
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  async saveToFile(): Promise<void> {
    if (!this.db) return;
    
    const data = this.db.export();
    await fs.writeFile(this.filePath, Buffer.from(data));
  }
}

export const database = new Database();