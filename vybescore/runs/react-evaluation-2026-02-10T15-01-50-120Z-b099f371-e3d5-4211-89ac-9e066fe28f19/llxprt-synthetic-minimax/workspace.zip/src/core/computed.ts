/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  trackDependency,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      trackDependency(o, observer)
    }
    
    // Evaluate the computed value
    const newValue = o.updateFn(o.value)
    o.value = newValue
    
    // Notify any dependent observers
    if (newValue !== o.value) {
      updateObserver(o)
    }
    
    return o.value!
  }

  return read
}
