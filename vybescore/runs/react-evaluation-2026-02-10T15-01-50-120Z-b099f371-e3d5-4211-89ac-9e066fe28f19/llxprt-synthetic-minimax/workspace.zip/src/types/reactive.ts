/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Store relationships between subjects and observers
const subjects = new Map<object, Set<ObserverR>>()

export function trackDependency(subject: ObserverR, observer: ObserverR): void {
  if (!subjects.has(subject)) {
    subjects.set(subject, new Set())
  }
  subjects.get(subject)!.add(observer)
}

export function untrackDependency(subject: ObserverR, observer: ObserverR): void {
  const observers = subjects.get(subject)
  if (observers) {
    observers.delete(observer)
    if (observers.size === 0) {
      subjects.delete(subject)
    }
  }
}

export function notifyDependents(subject: ObserverR): void {
  const observers = subjects.get(subject)
  if (observers) {
    observers.forEach(observer => {
      // Type guard to check if observer has updateFn property
      const hasUpdateFn = 'updateFn' in observer && observer.updateFn
      if (hasUpdateFn) {
        updateObserver(observer as Observer<unknown>)
      }
    })
  }
}
