/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  ObserverR,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  const s: Subject<T> & { observers: Set<ObserverR> } = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observers.add(observer)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldUpdate = !equalFn || !equalFn(s.value, nextValue)
    if (shouldUpdate) {
      s.value = nextValue
      
      // Create a notification function that updates each observer
      // without going through the normal dependency tracking mechanism
      for (const observer of s.observers) {
        if ('updateFn' in observer && 'value' in observer) {
          const obs = observer as Observer<T>
          // Directly call the update function to avoid re-tracking dependencies
          if (obs.updateFn) {
            obs.value = obs.updateFn(obs.value)
            
            // If this observer is a computed value, notify its observers
            if ('observers' in obs && obs.observers instanceof Set) {
              for (const dependent of obs.observers) {
                if ('updateFn' in dependent && 'value' in dependent) {
                  const dep = dependent as Observer<unknown>
                  if (dep.updateFn) {
                    dep.value = dep.updateFn(dep.value)
                  }
                }
              }
            }
          }
        }
      }
    }
    return s.value
  }

  return [read, write]
}