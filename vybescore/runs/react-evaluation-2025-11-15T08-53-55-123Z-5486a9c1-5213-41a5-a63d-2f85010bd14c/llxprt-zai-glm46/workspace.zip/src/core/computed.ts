/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create base observer
  const baseObserver: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Extend with observers set
  const observer = baseObserver as Observer<T> & { observers: Set<ObserverR> }
  observer.observers = new Set()
  
  // Flag to prevent infinite recursion
  let isUpdating = false
  
  // Override updateFn to notify dependent observers
  const originalUpdateFn = observer.updateFn
  
  observer.updateFn = (currentValue?: T) => {
    if (isUpdating) {
      return originalUpdateFn(currentValue)
    }
    
    isUpdating = true
    try {
      const result = originalUpdateFn(currentValue)
      
      // Notify all dependent observers when this computed value changes
      if (observer.observers.size > 0) {
        notifyObservers(observer.observers)
      }
      
      return result
    } finally {
      isUpdating = false
    }
  }
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      observer.observers.add(activeObserver)
    }
    
    // For standalone computed (no dependencies), just return cached value
    if (observer.value !== undefined && !activeObserver) {
      return observer.value
    }
    
    // Always recalculate when accessed to get fresh values
    isUpdating = true
    try {
      updateObserver(observer)
      return observer.value!
    } finally {
      isUpdating = false
    }
  }
  
  // Initialize value only if not already provided
  if (observer.value === undefined) {
    isUpdating = true
    try {
      updateObserver(observer)
    } finally {
      isUpdating = false
    }
  }
  
  return getter
}