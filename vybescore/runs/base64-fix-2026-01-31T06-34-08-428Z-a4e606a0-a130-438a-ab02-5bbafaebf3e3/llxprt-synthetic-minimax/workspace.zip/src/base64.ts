

/**
 * Encode plain text to Base64 using standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 */
export function decode(input: string): string {
  // Remove whitespace which is not valid in base64
  const cleaned = input.trim();
  
  // Validate that the input contains only valid base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(cleaned)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Pad the input to make length multiple of 4 if needed
  let padded = cleaned;
  const paddingNeeded = (4 - (padded.length % 4)) % 4;
  if (paddingNeeded > 0) {
    padded += '='.repeat(paddingNeeded);
  }

  try {
    return Buffer.from(padded, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
