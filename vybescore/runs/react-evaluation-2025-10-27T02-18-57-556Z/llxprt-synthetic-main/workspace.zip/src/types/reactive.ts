/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observer?: Observer<any> | undefined
}

export type SubjectR = {
  name?: string
  observer?: Observer<any> | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<any> | undefined

// Dependencies tracking for computed values
const dependenciesMap = new WeakMap<Observer<any>, Observer<any>[]>()
const dependentsMap = new WeakMap<Observer<any>, Observer<any>[]>() // eslint-disable-line @typescript-eslint/no-explicit-any

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    
    // Trigger any dependent observers
    if (observer.observer) {
      updateObserver(observer.observer)
    }
    
    // Trigger observers that depend on this one
    const observers = dependentsMap.get(observer)
    if (observers) {
      observers.forEach(obs => updateObserver(obs))
    }
  }
}

export function addDependency(observer: Observer<any>, dependency: Observer<any>): void {
  // Add this observer to the dependency's dependents
  let dependents = dependentsMap.get(dependency)
  if (!dependents) {
    dependents = []
    dependentsMap.set(dependency, dependents)
  }
  if (dependents.indexOf(observer) === -1) {
    dependents.push(observer)
  }
  
  // Track this observer's dependencies
  let deps = dependenciesMap.get(observer)
  if (!deps) {
    deps = []
    dependenciesMap.set(observer, deps)
  }
  if (deps.indexOf(dependency) === -1) {
    deps.push(dependency)
  }
}