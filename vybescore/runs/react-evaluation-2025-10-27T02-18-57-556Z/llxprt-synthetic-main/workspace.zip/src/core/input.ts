/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  addDependency
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Set up equality function
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (a, b) => a === b
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (a, b) => a === b : () => false
  } else {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // This is the observer that will be triggered when the value changes
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (_current) => {
      return s.value // Just return the current value
    }
  }

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register the input as a dependency of the active observer
      addDependency(activeObserver, observer)
      
      // Also store the active observer for direct notification
      s.observer = activeObserver
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if values are different according to equalFn
    if (!equalFn(s.value, nextValue)) {
      s.value = nextValue
      
      // Trigger the observer
      observer.value = s.value
      updateObserver(observer)
    }
    return s.value
  }

  return [read, write]
}