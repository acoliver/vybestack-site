/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  addDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Set up equality function
  let _equalFn: EqualFn<T>
  if (equal === undefined) {
    _equalFn = (a, b) => a === b
  } else if (typeof equal === 'boolean') {
    _equalFn = equal ? (a, b) => a === b : () => false
  } else {
    _equalFn = equal
  }

  // This observer will track dependencies and update the value
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prev) => {
      // Execute the update function to get the new value
      return updateFn(prev)
    }
  }

  // Initialize the value
  updateObserver(observer)

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Register this computed as a dependency of the active observer
      addDependency(activeObserver, observer)
    }
    return observer.value!
  }

  return read
}