declare module 'sql.js' {
  export interface Database {
    exec(sql: string): Array<{ columns: string[], values: unknown[][] }>;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(...args: unknown[]): void;
    free(): void;
  }

  export interface SqlJsStatic {
    Database(data?: Uint8Array): Database;
  }

  export interface InitOptions {
    locateFile?: (file: string) => string;
  }

  export function initSqlJs(options: InitOptions): Promise<SqlJsStatic>;
}