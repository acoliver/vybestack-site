import express from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// Import better-sqlite3 as alternative to sql.js
import DatabaseConstructor from 'better-sqlite3';
type Database = InstanceType<typeof DatabaseConstructor>;

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

// Initialize database with better-sqlite3
let db: Database | null = null;

// Get port from environment or use default
const PORT = process.env.PORT || 3535;

const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set view engine for EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation rules
function validateFormData(data: express.Request): { errors: string[]; values: Record<string, string> } {
  const errors: string[] = [];
  const values: Record<string, string> = data.body || {};

  // Check required fields
  if (!values.firstName || values.firstName.trim().length === 0) {
    errors.push('First name is required');
  }
  if (!values.lastName || values.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }
  if (!values.streetAddress || values.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }
  if (!values.city || values.city.trim().length === 0) {
    errors.push('City is required');
  }
  if (!values.stateProvince || values.stateProvince.trim().length === 0) {
    errors.push('State/Province is required');
  }
  if (!values.postalCode || values.postalCode.trim().length === 0) {
    errors.push('Postal code is required');
  }
  if (!values.country || values.country.trim().length === 0) {
    errors.push('Country is required');
  }
  if (!values.email || values.email.trim().length === 0) {
    errors.push('Email is required');
  }
  if (!values.phone || values.phone.trim().length === 0) {
    errors.push('Phone number is required');
  }

  // Email validation (simple regex)
  if (values.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(values.email.trim())) {
    errors.push('Email format is invalid');
  }

  // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
  if (values.phone && !/^[+]?\d[\d()\s-\d]+$/.test(values.phone.trim())) {
    errors.push('Phone number format is invalid');
  }

  // Postal code validation - allow alphanumeric
  if (values.postalCode && !/^[a-zA-Z0-9\s]+$/.test(values.postalCode.trim())) {
    errors.push('Postal code should contain only letters and numbers');
  }

  return { errors, values };
}

// Initialize database with better-sqlite3
function initDatabase() {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Open/create database
    db = new DatabaseConstructor(DB_PATH);
    console.log('Database connected:', DB_PATH);

    // Apply schema if needed (check if submissions table exists)
    const count = db.prepare("SELECT count(*) as count FROM sqlite_master WHERE type='table' AND name='submissions'").get() as { count: number };
    
    if (count.count === 0) {
      // Table doesn't exist, create it
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
      console.log('Applied database schema');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  // better-sqlite3 handles saving automatically
  console.log('Database autosaving enabled');
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const { errors, values } = validateFormData(req);

  if (errors.length > 0) {
    // Render form with errors
    return res.status(400).render('form', { errors, values });
  }

  try {
    // Insert into database
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      values.firstName.trim(),
      values.lastName.trim(),
      values.streetAddress.trim(),
      values.city.trim(),
      values.stateProvince.trim(),
      values.postalCode.trim(),
      values.country.trim(),
      values.email.trim(),
      values.phone.trim()
    ]);

    // better-sqlite3 does not have finalize

    // Save database
    saveDatabase();

    // Redirect to thank you page, passing first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(values.firstName.trim())}`);
  } catch (error) {
    console.error('Database insertion error:', error);
    return res.status(500).render('form', {
      errors: ['Something went wrong. Please try again.'],
      values
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName || 'friend';
  res.render('thank-you', { firstName });
});

// Start server
function startServer() {
  try {
    initDatabase();
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Handle graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    saveDatabase();
    try {
      db.close();
      console.log('Database connection closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start the server
startServer();
