import { ReportData, ReportEntry } from './types.js';

export function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid title');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid summary');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid entries');
  }

  const entries: ReportEntry[] = [];
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: expected object');
    }

    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid label');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: missing or invalid amount');
    }

    entries.push({
      label: entryObj.label,
      amount: entryObj.amount
    });
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}