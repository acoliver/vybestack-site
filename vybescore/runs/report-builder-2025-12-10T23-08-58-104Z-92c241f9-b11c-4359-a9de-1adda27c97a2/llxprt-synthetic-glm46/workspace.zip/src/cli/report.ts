#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, ReportFormat, ReportOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { renderers } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[2];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  const formatArg = args[formatIndex + 1];
  if (formatArg !== 'markdown' && formatArg !== 'text') {
    console.error(`Error: Unsupported format: ${formatArg}`);
    process.exit(1);
  }

  const format = formatArg as ReportFormat;
  
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  const includeTotals = args.includes('--includeTotals');

  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}

function readJsonFile(filePath: string): unknown {
  try {
    const content = readFileSync(filePath, 'utf8');
    return JSON.parse(content);
  } catch (error) {
    console.error(`Error reading file ${filePath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

function main() {
  const args = process.argv;
  const { inputFile, format, outputPath, includeTotals } = parseArguments(args);

  // Read and validate JSON input
  const rawData = readJsonFile(inputFile);
  let reportData: ReportData;
  try {
    reportData = validateReportData(rawData);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }

  const options: ReportOptions = {
    includeTotals,
    outputPath
  };

  // Render report
  const renderer = renderers[format];
  const output = renderer.render(reportData, options);

  // Output to file or stdout
  if (outputPath) {
    try {
      writeFileSync(outputPath, output);
    } catch (error) {
      console.error(`Error writing to file ${outputPath}: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
