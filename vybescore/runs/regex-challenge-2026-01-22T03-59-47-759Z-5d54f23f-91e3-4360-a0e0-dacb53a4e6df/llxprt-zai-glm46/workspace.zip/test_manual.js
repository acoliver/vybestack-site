const { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } = require('./dist/src/validators.js');
const { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } = require('./dist/src/transformations.js');
const { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } = require('./dist/src/puzzles.js');

console.log('=== Email Validation ===');
console.log('name+tag@example.co.uk:', isValidEmail('name+tag@example.co.uk'));
console.log('user@sub.example.com:', isValidEmail('user@sub.example.com'));
console.log('user@example..com:', isValidEmail('user@example..com'));
console.log('user@example.com.:', isValidEmail('user@example.com.'));
console.log('.user@example.com:', isValidEmail('.user@example.com'));
console.log('user@ex_ample.com:', isValidEmail('user@ex_ample.com'));

console.log('\n=== US Phone Validation ===');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('2125557890:', isValidUSPhone('2125557890'));
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('012-555-7890 (bad area code):', isValidUSPhone('012-555-7890'));

console.log('\n=== Argentine Phone Validation ===');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567'));

console.log('\n=== Name Validation ===');
console.log('Jane Doe:', isValidName('Jane Doe'));
console.log('José María:', isValidName('José María'));
console.log("O'Connor:", isValidName("O'Connor"));
console.log('X Æ A-12:', isValidName('X Æ A-12'));
console.log('John123:', isValidName('John123'));

console.log('\n=== Credit Card Validation ===');
console.log('4111111111111111 (Visa):', isValidCreditCard('4111111111111111'));
console.log('5500000000000004 (MC):', isValidCreditCard('5500000000000004'));
console.log('340000000000009 (AmEx):', isValidCreditCard('340000000000009'));
console.log('4111111111111112 (bad checksum):', isValidCreditCard('4111111111111112'));

console.log('\n=== Text Transformations ===');
console.log('capitalizeSentences:', capitalizeSentences('hello world. this is a test. another sentence.'));
console.log('extractUrls:', extractUrls('Visit https://example.com/path?query=1 and http://test.com.'));
console.log('enforceHttps:', enforceHttps('Visit http://example.com and https://secure.com'));
console.log('rewriteDocsUrls:', rewriteDocsUrls('Check http://example.com/docs/guide and http://example.com/index.jsp'));
console.log('extractYear (12/25/2024):', extractYear('12/25/2024'));
console.log('extractYear (13/01/2024):', extractYear('13/01/2024'));

console.log('\n=== Regex Puzzles ===');
console.log('findPrefixedWords:', findPrefixedWords('preview prevent prefix', 'pre', ['prevent']));
console.log('findEmbeddedToken:', findEmbeddedToken('xfoo 1foo foo', 'foo'));
console.log('isStrongPassword Abcdef!234:', isStrongPassword('Abcdef!234'));
console.log('isStrongPassword weak:', isStrongPassword('weak'));
console.log('isStrongPassword ababABAB12!:', isStrongPassword('ababABAB12!'));
console.log('containsIPv6 (2001:db8::1):', containsIPv6('2001:db8::1'));
console.log('containsIPv6 (192.168.1.1):', containsIPv6('192.168.1.1'));
