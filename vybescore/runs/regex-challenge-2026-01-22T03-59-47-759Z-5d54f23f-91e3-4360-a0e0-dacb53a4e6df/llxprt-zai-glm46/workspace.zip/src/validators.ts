export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Allow + for subaddressing, standard email characters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  const [localPart, domain] = value.split('@');

  // Reject double dots
  if (value.includes('..')) {
    return false;
  }

  // Reject trailing dot in local or domain
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }

  // Reject leading dot in local or domain
  if (localPart.startsWith('.') || domain.startsWith('.')) {
    return false;
  }

  // Reject underscores in domain
  if (domain.includes('_')) {
    return false;
  }

  // Domain must have at least one dot
  if (!domain.includes('.')) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers supporting common separators and optional +1.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const cleaned = value.replace(/[\s()\\-]/g, '');

  let digits = cleaned;

  // Handle optional +1 country code
  if (digits.startsWith('+1')) {
    digits = digits.substring(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }

  // Must be exactly 10 digits
  if (!/^\d{10}$/.test(digits)) {
    return false;
  }

  const areaCode = digits.substring(0, 3);
  const exchangeCode = digits.substring(3, 6);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code cannot start with 0 or 1 (NPA rules)
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validates Argentine phone numbers covering mobile/landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Match pattern: optional +54, optional trunk 0, optional mobile 9, area code (2-4 digits starting 1-9), subscriber (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }

  const areaCode = match[1];
  const subscriberNumber = match[2];

  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Check mobile indicator pattern (9 between country code and area code)
  if (cleaned.includes('+549')) {
    const parts = cleaned.replace('+549', '').split(/^([1-9]\d{1,3})/);
    if (parts.length < 2) {
      return false;
    }
  }

  // When country code is omitted, must have trunk prefix 0
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }

  // Total digits check (area code + subscriber)
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }

  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letters, accents, apostrophes, hyphens, spaces - no digits or special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  // Check for consecutive apostrophes/hyphens or leading/trailing
  if (value.startsWith("'") || value.endsWith("'") || value.startsWith('-') || value.endsWith('-')) {
    return false;
  }

  if (value.includes("''") || value.includes('--') || value.includes("'-") || value.includes("-'")) {
    return false;
  }

  // Reject names with digits (should be caught by regex but double check)
  if (/\d/.test(value)) {
    return false;
  }

  // Reject obviously invalid symbol-heavy names
  const symbolCount = (value.match(/['-]/g) || []).length;
  const letterCount = (value.match(/[\p{L}\p{M}]/gu) || []).length;
  if (symbolCount > letterCount) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers (length/prefix + Luhn checksum).
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: 13-16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;

  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;

  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;

  const validFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validFormat) {
    return false;
  }

  return runLuhnCheck(cleaned);
}
