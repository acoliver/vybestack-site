/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences and collapses extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence boundaries (. ? !)
  // Then capitalize first letter of each sentence and ensure proper spacing
  let result = text.replace(/([.!?])\s*([a-z])/g, (_, punct, letter) => punct + ' ' + letter.toUpperCase());

  // Capitalize the very first character
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Collapse multiple spaces into one (but preserve single spaces)
  result = result.replace(/[ \t]+/g, ' ');

  // Handle cases where there's no space after punctuation
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');

  return result;
}

/**
 * Finds URLs in the text and returns them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Match http/https URLs, excluding trailing punctuation
  // URL pattern: scheme://domain/path?query#fragment
  // Allow dots in domain but exclude trailing punctuation
  const urlRegex = /https?:\/\/[^\s<>,!?;]+(?:\?[^\s<>,!?;]*)?(?:#[^\s<>,!?;]*)?/g;

  const matches = text.match(urlRegex) || [];

  // Trim trailing punctuation from each URL
  return matches.map((url) => url.replace(/[.,;!?()]+$/, ''));
}

/**
 * Converts all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\/([^/]\S*)/g, 'https://$1');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - For paths starting with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  const dynamicHints = [
    'cgi-bin',
    '\\?',
    '&',
    '=',
    '\\.jsp',
    '\\.php',
    '\\.asp',
    '\\.aspx',
    '\\.do',
    '\\.cgi',
    '\\.pl',
    '\\.py'
  ];

  return text.replace(/http:\/\/example\.com(\/[^\s]*)?/gi, (url) => {
    // Extract the path part
    const pathMatch = url.match(/http:\/\/example\.com(\/[^\s]*)?/i);
    const path = pathMatch && pathMatch[1] ? pathMatch[1] : '';

    // Check if path contains dynamic hints
    const hasDynamicHint = dynamicHints.some((hint) => new RegExp(hint).test(path));

    // Always upgrade to https
    let rewritten = url.replace('http://', 'https://');

    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHint) {
      rewritten = rewritten.replace('https://example.com', 'https://docs.example.com');
    }

    return rewritten;
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
