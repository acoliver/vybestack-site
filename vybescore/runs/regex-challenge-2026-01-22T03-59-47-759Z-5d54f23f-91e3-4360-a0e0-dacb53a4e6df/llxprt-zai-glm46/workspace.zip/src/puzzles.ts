/**
 * Finds words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match words starting with the prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}[\\w'-]*)\\b`, 'gi');
  const matches = text.match(wordRegex) || [];

  // Filter out exceptions (case-insensitive)
  return matches.filter((word) => !exceptions.some((ex) => ex.toLowerCase() === word.toLowerCase()));
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Look for token preceded by a digit - we want to include the digit in the result
  const pattern = new RegExp(`\\d${escapedToken}`, 'gi');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }

  // Check for repeated sequences of 2+ characters (e.g., abab, 123123)
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const substr = value.substring(i, i + len);
      const nextSubstr = value.substring(i + len, i + len * 2);
      if (substr === nextSubstr) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 pattern (to exclude)
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;

  // IPv6 pattern - supports full notation and :: shorthand
  // Check for multiple consecutive colons (::) or hex groups with colons
  const hasMultipleColons = /::{2,}/.test(value);
  const hasHexColons = /(?:[0-9a-fA-F]{1,4}:){3,}[0-9a-fA-F]{0,4}/.test(value);

  // First check if it looks like IPv4 - if so, reject
  if (ipv4Pattern.test(value) && !hasMultipleColons && !hasHexColons) {
    return false;
  }

  // Check if it has IPv6 characteristics
  // IPv6 addresses have colons and hex digits, with :: shorthand or 7 colons (8 groups)
  const ipv6BasicPattern = /(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}/;
  const ipv6ShorthandPattern = /::{1,2}/;

  // Must have at least one colon to be IPv6
  if (!value.includes(':')) {
    return false;
  }

  // If it has IPv6 patterns and isn't pure IPv4
  const hasIPv6Pattern = ipv6BasicPattern.test(value) || ipv6ShorthandPattern.test(value);

  return hasIPv6Pattern;
}