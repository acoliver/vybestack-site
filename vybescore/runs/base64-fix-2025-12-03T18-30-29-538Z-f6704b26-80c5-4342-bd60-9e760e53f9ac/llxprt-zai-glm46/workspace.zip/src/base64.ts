const INVALID_BASE64_ERROR = 'Invalid Base64 input';

function validateBase64Padding(input: string): void {
  // Validate padding
  const paddingLength = input.length % 4;
  if (paddingLength === 1) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  // Ensure padding only appears at the end and validate padding count
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Check for any non-padding characters after padding starts
    const afterPadding = input.slice(paddingIndex + 1);
    if (afterPadding.length > 0 && !afterPadding.startsWith('=')) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    // Check for too many padding characters
    const totalPadding = (input.match(/=/g) || []).length;
    if (totalPadding > 2) {
      throw new Error(INVALID_BASE64_ERROR);
    }
  }
}

function validateBase64Integrity(input: string, result: string): void {
  // Additional validation: ensure the result would re-encode to the same value (accounting for padding)
  const reencoded = Buffer.from(result, 'utf8').toString('base64');
  const normalizedInput = input.replace(/=+$/, '');
  const normalizedReencoded = reencoded.replace(/=+$/, '');
  
  if (normalizedInput !== normalizedReencoded) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}

/**
 * Encode plain text to standard Base64.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }

  // Validate Base64 format - only allow Base64 characters and optional padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  validateBase64Padding(input);

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    validateBase64Integrity(input, result);
    return result;
  } catch (error) {
    if (error instanceof Error && error.message === INVALID_BASE64_ERROR) {
      throw error;
    }
    throw new Error(INVALID_BASE64_ERROR);
  }
}
