/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject to hold the computed value and track its observers
  const subject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (prevValue?: T) => {
      // Compute the new value
      const newValue = updateFn(prevValue)
      // Update the subject's value
      subject.value = newValue
      // Notify all observers of this computed value
      notifyObservers(subject as Subject<unknown>)
      return newValue
    },
  }

  const getter: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // When this computed is accessed while another observer is active,
      // register this computed's subject as a dependency
      subject.observers.add(observer)
    }
    return subject.value
  }

  // Initial computation
  updateObserver(o)

  return getter
}
