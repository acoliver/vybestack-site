/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerCallbacks } from '../types/reactive.js'

// Store all dependencies for callback observers
const callbacks = new Set<Observer<unknown>>()
let allCallbacks: Set<Observer<unknown>> | null = null

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let callbackExecuted = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      // Track if this is the first execution
      const firstExecution = !callbackExecuted
      if (firstExecution) {
        callbackExecuted = true
      }
      return updateFn(prevValue)
    },
  }
  
  // Register this callback in global registry
  callbacks.add(observer as Observer<unknown>)
  allCallbacks = new Set(callbacks)
  registerCallbacks(allCallbacks)
  
  // Register observer to track dependencies and run it once
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this specific callback from global callbacks set
    const hadCallback = callbacks.has(observer as Observer<unknown>)
    
    if (hadCallback) {
      callbacks.delete(observer as Observer<unknown>)
      // Also update allCallbacks to remove it
      if (allCallbacks) {
        allCallbacks.delete(observer as Observer<unknown>)
      }
    }
    
    // Set a flag to prevent further updates
    (observer as Observer<T> & { disposed?: boolean }).disposed = true
    
    // Clear the update function to stop further updates
    observer.updateFn = () => value!
  }
}