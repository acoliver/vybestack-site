/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Options
} from '../types/reactive.js'

// Store all subscribers for computed values
const subscribers = new Map<Observer<unknown>, Set<Observer<unknown>>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = () => {
    // If this computed value is being accessed within an observer, 
    // register this computed as a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      if (!subscribers.has(o as Observer<unknown>)) {
        subscribers.set(o as Observer<unknown>, new Set())
      }
      subscribers.get(o as Observer<unknown>)!.add(activeObserver as Observer<unknown>)
    }
    
    // Compute the current value and store the old value for comparison
    const oldValue = o.value
    updateObserver(o)
    
    // If the value changed, notify all subscribers
    if (oldValue !== o.value) {
      const currentSubscribers = subscribers.get(o as Observer<unknown>)
      if (currentSubscribers) {
        // Create a copy to avoid issues with modifications during iteration
        const subsCopy = Array.from(currentSubscribers)
        for (const subscriber of subsCopy) {
          updateObserver(subscriber as Observer<unknown>)
        }
      }
    }
    
    return o.value!
  }
  
  return getter
}
