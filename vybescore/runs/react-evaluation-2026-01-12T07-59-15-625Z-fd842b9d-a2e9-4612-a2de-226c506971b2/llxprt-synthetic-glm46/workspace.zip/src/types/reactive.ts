/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Global subscriber registry for reactive dependencies
const globalSubscriberMap = new WeakMap<object, Map<string, Set<ObserverR>>>()

export function trackDependency(target: object, key: string, observer: ObserverR): void {
  if (!observer) return
  
  let depsMap = globalSubscriberMap.get(target)
  if (!depsMap) {
    depsMap = new Map()
    globalSubscriberMap.set(target, depsMap)
  }
  
  let subscribers = depsMap.get(key)
  if (!subscribers) {
    subscribers = new Set()
    depsMap.set(key, subscribers)
  }
  
  subscribers.add(observer)
}

let allCallbacks: Set<Observer<unknown>> | null = null

export function registerCallbacks(callbacks: Set<Observer<unknown>>): void {
  allCallbacks = callbacks
}



export function triggerDependencies(target: object, key: string): void {
  const depsMap = globalSubscriberMap.get(target)
  if (!depsMap) return
  
  const subscribers = depsMap.get(key)
  if (!subscribers) return
  
  // Create a copy to avoid issues with modifications during iteration
  const subsCopy = Array.from(subscribers)
  for (const subscriber of subsCopy) {
    updateObserver(subscriber as Observer<object>)
  }
  
  // If we have access to all callbacks, trigger all of them
  if (allCallbacks) {
    const allCallbacksCopy = Array.from(allCallbacks)
    for (const callback of allCallbacksCopy) {
      // Skip if the callback has been disposed
      if (!(callback as Observer<unknown> & { disposed?: boolean }).disposed) {
        updateObserver(callback as Observer<unknown>)
      }
    }
  }
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Skip if the observer has been disposed
  if ((observer as Observer<T> & { disposed?: boolean }).disposed) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// Add a utility function to notify when an observer's dependencies change
export function notifyObserverChange<T>(observer: Observer<T>): void {
  updateObserver(observer)
}
