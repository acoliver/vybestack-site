export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive checks.
 */
export function isValidEmail(value: string): boolean {
  // Email regex supporting typical addresses like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional validations
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dots in local or domain part
  if (value.endsWith('.')) {
    return false;
  }
  
  // Domain cannot have underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Cannot start or end with dots or hyphens in local part
  if (value.startsWith('.') || value.startsWith('-') || value.endsWith('.') || value.endsWith('-')) {
    return false;
  }
  
  // Cannot have consecutive dots in domain
  if (domain && domain.includes('..')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers with common formats and optional country code.
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first for length validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must be exactly 10 digits (local) or 11 digits (with country code)
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // Handle country code
  if (digitsOnly.length === 11) {
    // Must start with 1 for US country code
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
  }
  
  // For validation, use the last 10 digits (remove country code if present)
  const last10Digits = digitsOnly.slice(-10);
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = last10Digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate format matches common US phone patterns
  // Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
  const usPhoneRegex = /^(\+?1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  
  return usPhoneRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove separators (spaces, hyphens) for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // If no country code, must start with 0 (trunk prefix)
  // Optional 9 mobile indicator between country/trunk and area code
  // Area code: 2-4 digits (leading digit 1-9)
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const hasCountryCode = cleanValue.startsWith('+54');
  const hasTrunkPrefix = match[2] !== undefined;
  const areaCode = match[3];
  const subscriber = match[4];
  
  // If no country code, must have trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Area code must be 2-4 digits (we already ensured it starts with 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and weird names like "X Æ A-12"
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Basic regex check
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject names that are too short (less than 2 characters after trimming)
  if (value.trim().length < 2) {
    return false;
  }
  
  // Reject names that consist only of special characters (no letters)
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with multiple consecutive special characters
  if (/[']{2,}|[-]{2,}|\s{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start or end with apostrophe or hyphen
  if (/^['-\s]|[-\s]$/.test(value.trim())) {
    return false;
  }
  
  // Reject names with excessive special characters (more than 2 apostrophes or hyphens)
  const apostropheCount = (value.match(/'/g) || []).length;
  const hyphenCount = (value.match(/-/g) || []).length;
  if (apostropheCount > 2 || hyphenCount > 2) {
    return false;
  }
  
  // Reject names that contain special characters that shouldn't be in names
  // This includes symbols like @, #, $, %, ^, &, *, (, ), etc.
  if (/[^\p{L}\p{M}'\-\s]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers using Luhn algorithm and check valid prefixes.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Must be numeric and between 13-19 digits
  if (!/^\d+$/.test(cleanValue) || cleanValue.length < 13 || cleanValue.length > 19) {
    return false;
  }
  
  // Check valid prefixes for major card types
  const visaRegex = /^4[0-9]{12}(?:[0-9]{3,6})?$/; // 13 or 16 digits
  const mastercardRegex = /^5[1-5][0-9]{14}$/; // 16 digits
  const mastercardNewRegex = /^2[2-7][0-9]{14}$/; // New Mastercard ranges
  const amexRegex = /^3[47][0-9]{13}$/; // 15 digits
  
  const isValidPrefix = visaRegex.test(cleanValue) || 
                       mastercardRegex.test(cleanValue) || 
                       mastercardNewRegex.test(cleanValue) || 
                       amexRegex.test(cleanValue);
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to run Luhn algorithm check.
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Start from the rightmost digit and move left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}