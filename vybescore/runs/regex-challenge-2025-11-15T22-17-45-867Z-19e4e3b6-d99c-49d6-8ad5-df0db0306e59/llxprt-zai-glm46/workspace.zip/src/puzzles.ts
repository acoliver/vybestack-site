/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  ).filter((word, index, arr) => 
    // Remove duplicates
    arr.indexOf(word) === index
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all matches where token follows a digit
  const results: string[] = [];
  let index = 0;
  
  while (index < text.length) {
    const match = text.substring(index).match(new RegExp(`\\d(${escapedToken})`));
    if (match) {
      const matchIndex = index + match.index!;
      // Check if this is not at the start of the string
      if (matchIndex > 0) {
        // Return the full match including the digit
        results.push(match[0]);
      }
      index = matchIndex + match[0].length;
    } else {
      break;
    }
  }
  
  // Remove duplicates
  return [...new Set(results)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^\w\s]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like abab, abcabc, etc.)
  for (let length = 2; length <= 4; length++) {
    const repeatedPatternRegex = new RegExp(`(.{${length}})\\1`, 'i');
    if (repeatedPatternRegex.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex to exclude IPv4 addresses
  const ipv4Regex = /\b(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  
  // First, remove IPv4 addresses from the text
  const textWithoutIPv4 = value.replace(ipv4Regex, '');
  
  // Check for common IPv6 patterns
  const hasColons = textWithoutIPv4.includes(':');
  if (!hasColons) {
    return false;
  }
  
  // Check for IPv6 patterns
  const ipv6Patterns = [
    /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/, // Full IPv6
    /(?:[0-9a-fA-F]{1,4}:){1,7}:/, // Compressed with trailing :
    /::1/, // localhost
    /::/, // All zeros
    /[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}/ // Compressed in middle
  ];
  
  return ipv6Patterns.some(pattern => pattern.test(textWithoutIPv4));
}