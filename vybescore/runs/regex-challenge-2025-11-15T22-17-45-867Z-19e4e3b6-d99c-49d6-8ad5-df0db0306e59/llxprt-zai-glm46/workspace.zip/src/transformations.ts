/**
 * Capitalize the first character of each sentence while preserving spacing rules.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // First, normalize whitespace around sentence boundaries
  let result = text.replace(/([.!?])(?=\S)/g, '$1 '); // Add space after punctuation if followed by non-space
  result = result.replace(/\s+/g, ' '); // Collapse multiple spaces
  result = result.replace(/\s+([.!?])/g, '$1'); // Remove spaces before punctuation
  
  // Split into sentences and capitalize
  const sentences = result.split(/([.!?]\s*)/);
  let newResult = '';
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part.match(/[.!?]\s*/)) {
      // This is punctuation + space, add as-is
      newResult += part;
      capitalizeNext = true;
    } else if (part.trim()) {
      // This is text content
      if (capitalizeNext) {
        newResult += part.charAt(0).toUpperCase() + part.slice(1);
        capitalizeNext = false;
      } else {
        newResult += part;
      }
    } else {
      newResult += part;
    }
  }
  
  return newResult.trim();
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match URLs and capture trailing punctuation separately
  const urlRegex = /https?:\/\/[^\s<>"{}|^`[\]]+(?=[.,;:!?)]*\s|$)/gi;
  const urls: string[] = [];
  
  let match;
  while ((match = urlRegex.exec(text)) !== null) {
    // Remove trailing punctuation if present
    urls.push(match[0].replace(/[.,;:!?)]+$/, ''));
  }
  
  return urls;
}

/**
 * Replace http:// with https:// in all URLs.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite docs URLs according to the specifications.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/https?:\/\/([^/]+)(\/docs\/[^\s?#&;]*(?:\.(?!jsp|php|asp|aspx|do|cgi|pl|py)[a-zA-Z0-9]+)*)/g, (match, host, path) => {
    // Check if the path contains any of the forbidden patterns
    const forbiddenPatterns = [
      /\/cgi-bin\//i,
      /\?/,
      /&/,
      /=/,
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    const hasForbiddenPattern = forbiddenPatterns.some(pattern => pattern.test(path));
    
    if (hasForbiddenPattern) {
      // Keep the original host but upgrade to https
      return `https://${host}${path}`;
    } else {
      // Rewrite to docs.example.com
      return `https://docs.${host}${path}`;
    }
  });
}

/**
 * Extract year from mm/dd/yyyy format, return 'N/A' if invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Basic day validation (1-31)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // More specific day validation based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  
  if (month === 2 && isLeapYear) {
    if (day > 29) {
      return 'N/A';
    }
  } else if (day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}