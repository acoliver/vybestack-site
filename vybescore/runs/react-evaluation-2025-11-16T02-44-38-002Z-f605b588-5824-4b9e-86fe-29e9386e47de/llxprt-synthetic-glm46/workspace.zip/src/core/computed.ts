/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  registerComputedObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Process the equal parameter (API consistency, not currently used)
  if (equal || typeof equal === 'function') {
    // equal parameter is processed for API consistency
    // Current implementation doesn't use optimization, but keeps the interface
  }

  const observer: Observer<T> = {
    name: options?.name,
    value, // Use provided initial value or undefined
    updateFn,
  }
  
  // Register this computed observer
  registerComputedObserver(observer as Observer<unknown>)
  
  let initialized = value !== undefined
  
  const getter = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // When this computed value is accessed, it becomes a dependency
      // of the current active observer
      // Note: We don't add observers to computed values directly
      // Instead, this is handled by the global notification system
    }
    
    if (!initialized) {
      // Initialize the observer by running its update function
      // This will automatically track dependencies
      updateObserver(observer)
      initialized = true
    }
    
    return observer.value as T
  }
  
  return getter
}