/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  registerSubject,
  notifyAllObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Process the equal parameter
  let equalFn: EqualFn<T> | undefined
  if (typeof equal === 'function') {
    equalFn = equal
  } else if (equal === true) {
    // Use Object.is for strict equality when true
    equalFn = Object.is
  }

  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
    observers: new Set(),
  }

  // Register this subject with the global registry
  registerSubject(s)

  const read: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // When this input is accessed, it becomes a dependency of the active observer
      s.observers.add(activeObserver)
    }
    return s.value
  }

  const write: SetterFn<T> = (newValue: T) => {
    // Check if value has actually changed
    const hasChanged = !equalFn || !equalFn(s.value, newValue)
    if (!hasChanged) {
      return s.value
    }

    s.value = newValue

    // Notify all dependent observers
    notifyAllObservers()

    return s.value
  }

  return [read, write]
}