/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, registerCallbackObserver, unregisterObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: 'callback',
    value,
    updateFn,
  }
  
  // Register this callback observer
  registerCallbackObserver(observer as Observer<unknown>)
  
  // Initialize by running the callback once
  updateObserver(observer)
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Clean up by removing from all relevant registries
    unregisterObserver(observer)
    
    // Clear the update function to a no-op
    observer.updateFn = () => value!
    
    observer.value = undefined
  }
  
  return unsubscribe
}