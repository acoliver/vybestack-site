/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
}

export type Subject<T> = {
  name?: string
  value: T
  equalFn?: EqualFn<T>
  observers: Set<Observer<unknown>>
}

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  try {
    activeObserver = observer as Observer<unknown>
    const oldValue = observer.value
    observer.value = observer.updateFn(oldValue)
  } finally {
    activeObserver = previous
  }
}

// Global registry of all subjects for notification
const subjects = new Set<Subject<unknown>>()
const computedObservers = new Set<Observer<unknown>>()
const callbackObservers = new Set<Observer<unknown>>()

export function registerSubject<T>(subject: Subject<T>): void {
  subjects.add(subject as Subject<unknown>)
}

export function unregisterSubject<T>(subject: Subject<T>): void {
  subjects.delete(subject as Subject<unknown>)
}

export function registerComputedObserver<T>(observer: Observer<T>): void {
  computedObservers.add(observer as Observer<unknown>)
}

export function registerCallbackObserver<T>(observer: Observer<T>): void {
  callbackObservers.add(observer as Observer<unknown>)
}

export function unregisterObserver<T>(observer: Observer<T>): void {
  computedObservers.delete(observer as Observer<unknown>)
  callbackObservers.delete(observer as Observer<unknown>)
  
  // Remove the observer from all subjects that reference it
  for (const subject of subjects) {
    subject.observers.delete(observer as Observer<unknown>)
  }
}

export function getSubjects(): Set<Subject<unknown>> {
  return subjects
}

export function notifyAllObservers(): void {
  // Notify all computed observers first
  // Create a copy of the set to avoid issues with modifications during iteration
  const computedObserversToUpdate = Array.from(computedObservers)
  for (const observer of computedObserversToUpdate) {
    updateObserver(observer)
  }
  // Then notify all callback observers
  // Create a copy of the set to avoid issues with modifications during iteration
  const callbackObserversToUpdate = Array.from(callbackObservers)
  for (const observer of callbackObserversToUpdate) {
    updateObserver(observer)
  }
}