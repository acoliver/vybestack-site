import { describe, it, expect } from 'vitest'
import { createInput } from '../../src/index.ts'

describe('createInput', () => {
  it('input returns current value', () => {
    const [getter /*, _setter */] = createInput(1)
    expect(getter()).toBe(1)
  })

  it('input returns newly set value', () => {
    const [getter, setter] = createInput(1)
    setter(2)
    expect(getter()).toBe(2)
  })

  it('input setter returns new value', () => {
    const [, setter] = createInput(1)
    expect(setter(2)).toBe(2)
  })

  it('updates value through setter', () => {
    const [getter, setter] = createInput(42)
    setter(100)
    expect(getter()).toBe(100)
  })

  it('returns updated value from setter', () => {
    const [getter, setter] = createInput('hello')
    const result = setter('world')
    expect(result).toBe('world')
    expect(getter()).toBe('world')
  })
})