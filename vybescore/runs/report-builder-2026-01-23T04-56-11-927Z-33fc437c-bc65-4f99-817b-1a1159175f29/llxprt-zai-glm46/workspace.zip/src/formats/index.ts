import type { FormatRenderer } from '../types.js';
import { markdownRenderer } from './markdown.js';
import { textRenderer } from './text.js';

export const formatters: Record<string, FormatRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};

export function getFormatter(format: string): FormatRenderer {
  const formatter = formatters[format];
  if (!formatter) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return formatter;
}
