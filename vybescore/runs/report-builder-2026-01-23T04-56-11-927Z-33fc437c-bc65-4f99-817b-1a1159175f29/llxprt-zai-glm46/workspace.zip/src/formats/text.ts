import type { FormatRenderer, RenderOptions, RenderResult, ReportData } from '../types.js';

export function renderText(data: ReportData, options: RenderOptions): RenderResult {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries heading
  lines.push('Entries:');

  // Entries
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: $${entry.amount.toFixed(2)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`Total: $${total.toFixed(2)}`);
  }

  const output = lines.join('\n');
  return { output, total: options.includeTotals ? data.entries.reduce((sum, e) => sum + e.amount, 0) : undefined };
}

export const textRenderer: FormatRenderer = {
  render: renderText,
};
