/**
 * Report data model
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering reports
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Result of rendering a report
 */
export interface RenderResult {
  output: string;
  total?: number;
}

/**
 * Format-specific renderer interface
 */
export interface FormatRenderer {
  render(data: ReportData, options: RenderOptions): RenderResult;
}
