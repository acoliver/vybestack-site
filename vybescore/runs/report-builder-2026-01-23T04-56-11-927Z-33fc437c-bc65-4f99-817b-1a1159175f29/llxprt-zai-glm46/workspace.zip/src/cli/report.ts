#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { getFormatter } from '../formats/index.js';
import { loadReportData } from '../validation.js';
import type { RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    printUsage();
    process.exit(1);
  }

  const dataFile = args[0];
  const options: CliArgs = {
    dataFile,
    format: '',
    includeTotals: false,
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else if (arg.startsWith('-')) {
      console.error(`Error: Unknown option "${arg}"`);
      process.exit(1);
    } else {
      console.error(`Error: Unexpected argument "${arg}"`);
      process.exit(1);
    }
  }

  if (!options.format) {
    console.error('Error: --format is required');
    printUsage();
    process.exit(1);
  }

  return options;
}

function printUsage(): void {
  console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.error('');
  console.error('Arguments:');
  console.error('  data.json       Path to JSON file containing report data');
  console.error('');
  console.error('Options:');
  console.error('  --format <fmt>  Output format (markdown, text)');
  console.error('  --output <path> Write output to file instead of stdout');
  console.error('  --includeTotals Include total sum of entry amounts');
}

function main(): void {
  const args = process.argv.slice(2);
  const options = parseArgs(args);

  try {
    // Load and validate data
    const data = loadReportData(options.dataFile);

    // Get formatter
    const formatter = getFormatter(options.format);

    // Render
    const renderOptions: RenderOptions = {
      includeTotals: options.includeTotals,
    };
    const result = formatter.render(data, renderOptions);

    // Output
    if (options.outputPath) {
      writeFileSync(options.outputPath, result.output, 'utf-8');
    } else {
      console.log(result.output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
