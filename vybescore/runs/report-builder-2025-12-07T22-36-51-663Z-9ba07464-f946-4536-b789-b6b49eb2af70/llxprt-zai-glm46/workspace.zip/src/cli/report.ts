#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, FormatOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const cliArgs: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  let i = 0;
  while (i < args.length) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      cliArgs.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      cliArgs.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      cliArgs.includeTotals = true;
    } else if (!cliArgs.dataFile) {
      cliArgs.dataFile = arg;
    } else {
      console.error(`Error: Unexpected argument: ${arg}`);
      process.exit(1);
    }

    i++;
  }

  if (!cliArgs.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return cliArgs;
}

function main(): void {
  try {
    const args = parseArgs();

    let rawData: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${args.dataFile}: ${error.message}`);
      } else {
        console.error(`Error: Unable to read file ${args.dataFile}: ${error instanceof Error ? error.message : String(error)}`);
      }
      process.exit(1);
    }

    const reportData: ReportData = validateReportData(rawData);

    const options: FormatOptions = {
      includeTotals: args.includeTotals,
    };

    let output: string;
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown(reportData, options);
        break;
      case 'text':
        output = renderText(reportData, options);
        break;
      default:
        console.error(`Error: Unsupported format "${args.format}"`);
        process.exit(1);
    }

    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf8');
      } catch (error) {
        console.error(`Error: Unable to write to file ${args.outputPath}: ${error instanceof Error ? error.message : String(error)}`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
