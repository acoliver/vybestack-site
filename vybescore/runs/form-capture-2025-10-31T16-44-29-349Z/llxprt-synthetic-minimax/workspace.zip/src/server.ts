import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';
import initDb, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Initialize database
let db: Database | null = null;

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Initialize database connection
async function initDatabase() {
  try {
    const SQL = await initDb({
      locateFile: (file) => path.join(__dirname, '..', '..', 'node_modules', 'sql.js', 'dist', file),
    });

    const dbPath = path.join(__dirname, '..', '..', 'data', 'submissions.sqlite');
    
    // Try to load existing database
    try {
      const dbBuffer = await fs.readFile(dbPath);
      if (dbBuffer.length > 0) {
        db = new SQL.Database(dbBuffer);
        console.log('Loaded existing database');
      }
    } catch (err) {
      // Database file doesn't exist or is empty, create new one
      console.log('Creating new database');
    }

    if (!db) {
      db = new SQL.Database();
      
      // Read and execute schema
      const schemaPath = path.join(__dirname, '..', '..', 'db', 'schema.sql');
      const schema = await fs.readFile(schemaPath, 'utf-8');
      db.run(schema);
      console.log('Database initialized with schema');
    }

    // Save database immediately after initialization
    saveDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase() {
  if (db) {
    const binaryArray = db.export();
    const dbPath = path.join(__dirname, '..', '..', 'data', 'submissions.sqlite');
    fs.writeFile(dbPath, binaryArray).catch(err => {
      console.error('Failed to save database:', err);
    });
  }
}

// Close database
function closeDatabase() {
  if (db) {
    db.close();
    db = null;
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, '').length >= 7;
}

function validateForm(data: Partial<SubmissionData>): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required fields check
  const requiredFields: (keyof SubmissionData)[] = [
    'first_name',
    'last_name',
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || (data[field] as string).trim() === '') {
      errors[field] = 'This field is required';
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postal_code) {
    const postalCode = data.postal_code.trim();
    if (!/^[A-Za-z0-9\s-]+$/.test(postalCode)) {
      errors.postal_code = 'Please enter a valid postal code';
    }
  }

  return errors;
}

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', '..', 'public')));

// Routes

// GET / - Render the form
app.get('/', (req, res) => {
  res.render('form', {
    errors: {},
    formData: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', (req, res) => {
  const formData: Partial<SubmissionData> = {
    first_name: req.body.first_name?.trim(),
    last_name: req.body.last_name?.trim(),
    street_address: req.body.street_address?.trim(),
    city: req.body.city?.trim(),
    state_province: req.body.state_province?.trim(),
    postal_code: req.body.postal_code?.trim(),
    country: req.body.country?.trim(),
    email: req.body.email?.trim(),
    phone: req.body.phone?.trim()
  };

  const errors = validateForm(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      formData
    });
  }

  // Save to database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.first_name!,
      formData.last_name!,
      formData.street_address!,
      formData.city!,
      formData.state_province!,
      formData.postal_code!,
      formData.country!,
      formData.email!,
      formData.phone!
    ]);

    stmt.free();
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

// GET /thank-you - Render thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown handling
function gracefulShutdown(signal: string) {
  console.log(`\nReceived ${signal}. Starting graceful shutdown...`);
  
  const server = app.listen(PORT);
  server.close(() => {
    console.log('HTTP server closed');
  });
  
  closeDatabase();
  console.log('Database closed');
  
  setTimeout(() => {
    console.log('Forcing shutdown');
    process.exit(0);
  }, 5000);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function start() {
  await initDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });
}

start().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});