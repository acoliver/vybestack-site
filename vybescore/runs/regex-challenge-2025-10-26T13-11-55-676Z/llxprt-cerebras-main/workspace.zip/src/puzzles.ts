/**
 * Find words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern to match words starting with prefix but not in exceptions
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&'));
  
  // Build a negative lookahead for exceptions
  const exceptionsPattern = escapedExceptions.length > 0 
    ? `(?!${escapedExceptions.join('|')})` 
    : '';
  
  // Match words that begin with the prefix and are not in the exceptions list
  const regex = new RegExp(`\\b${exceptionsPattern}${escapedPrefix}\\w*`, 'gi');
  const matches = text.match(regex);
  
  return matches ? [...new Set(matches)] : [];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the matched string which includes the digit prefix (e.g. "1foo" rather than just "foo")
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create a regex with positive lookbehind to match token after a digit and return full match
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  const matches = text.match(regex);
  
  return matches ? [...matches] : [];
}

/**
 * Validates passwords according to the specified policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No repeated consecutive sequences (e.g., 'abab')
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) return false;  // Uppercase
  if (!/[a-z]/.test(value)) return false;  // Lowercase
  if (!/\d/.test(value)) return false;     // Digit
  if (!/[!@#$%^&*(),.?":{}|<>[\]\\';~`+=-]/.test(value)) return false; // Symbol
  
  // Check for repeated consecutive sequences (e.g., 'abab')
  // This regex looks for any sequence of 2 or more characters repeated immediately
  if (/(\w{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand "::") while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // A comprehensive regex for IPv6 addresses including shorthand notation
  // This pattern matches standard IPv6, compressed zeros (::), and mixed formats
  const ipv6Regex = 
    /(?:^|(?<=\s))(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,6}:|(?:[0-9a-fA-F]{1,4}:){1,5}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,4}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,5})|:((:[0-9a-fA-F]{1,4}){1,6})|::(?:[0-9a-fA-F]{1,4}){1,7}|::|(?:::[0-9a-fA-F]{1,4}){1,7}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?<=\s)(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}|(?<=\s)::(?:[0-9a-fA-F]{1,4}:){5}(?:\d{1,3}\.){3}\d{1,3}(?=\s|$)/g;
  
  // Ensure we don't match IPv4 addresses
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it contains an IPv4 address, it's not considered to contain IPv6
  if (ipv4Regex.test(value)) return false;
  
  // Check if it matches IPv6 patterns
  return ipv6Regex.test(value);
}