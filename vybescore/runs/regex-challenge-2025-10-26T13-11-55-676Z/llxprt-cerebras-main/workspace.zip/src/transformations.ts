/**
 * Capitalize the first letter of each sentence.
 * Insert exactly one space between sentences and collapse extra whitespace.
 * Try to leave abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple whitespace with single space
  let result = text.replace(/\s+/g, ' ');
  
  // Capitalize first letter of the text
  result = result.replace(/^\s*(\p{L})/u, (_, firstChar) => firstChar.toUpperCase());
  
  // Find sentence endings (.?!), followed by optional whitespace and the first letter of next sentence
  // Capitalize that first letter
  result = result.replace(/([.?!])\s*(\p{L})/gu, (_, ending, firstChar) => `${ending} ${firstChar.toUpperCase()}`);
  
  return result.trim();
}

/**
 * Extract URLs from text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Match URLs starting with http:// or https://
  // Allow domain names, paths, query parameters, etc.
  // Exclude trailing punctuation marks like .,!?;:
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_+.~#?&=]*[^.,!?:;\s])?/g;
  const matches = text.match(urlRegex);
  return matches ? matches.map(url => url.trim()) : [];
}

/**
 * Replace all http:// URLs with https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't touch URLs that are already https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs to https://... and move docs paths to docs.example.com.
 * Skip the host rewrite when the path contains dynamic hints or legacy extensions.
 */
export function rewriteDocsUrls(text: string): string {
  const docUrlsRegex = /http:\/\/(?!docs\.)([^\/\s]+)\/docs\/([^\s.,!?:;]*)/gi;
  
  return text.replace(docUrlsRegex, (match, domain, path) => {
     // Only rewrite docs URLs if they don't contain dynamic elements
     if (!path.includes('cgi-bin') && 
         !/\.(jsp|php|asp|aspx|do|cgi|pl|py)/.test(path) &&
         !/[?&=]/.test(path)) {
       return `https://docs.${domain}/docs/${path}`;
     }
     // Otherwise, just change scheme to https
     return match.replace(/^http:/, 'https:');
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12) and day (1-31)
  if (monthNum < 1 || monthNum > 12 || dayNum < 1 || dayNum > 31) {
    return 'N/A';
  }
  
  return year;
}