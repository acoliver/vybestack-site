export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using regex pattern.
 * Accepts typical addresses such as name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // Supports typical email addresses with special cases like +tag in local part
  // Rejects double dots, trailing dots in local/domain parts, and underscores in domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks:
  // - No double dots
  // - No trailing dots in local part or domain
  // - No underscores in domain part
  if (!emailRegex.test(value)) return false;
  if (value.includes('..')) return false;
  if (value.endsWith('.')) return false;
  const [localPart, domainPart] = value.split('@');
  if (localPart.endsWith('.')) return false;
  if (domainPart.includes('_')) return false;
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890 with optional +1 prefix.
 * Disallows impossible area codes (leading 0 or 1).
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except for + at the beginning
  let cleaned = value.replace(/\D/g, '');
  
  // Handle optional +1 prefix
  if (value.startsWith('+1') && cleaned.length === 11 && cleaned.startsWith('1')) {
    cleaned = cleaned.substring(1); // Remove the leading '1'
  }
  
  // Check for impossible area codes (must not start with 0 or 1)
  if (cleaned.length !== 10) return false;
  const areaCode = cleaned.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate the entire 10-digit phone number
  const phoneRegex = /^\d{10}$/;
  return phoneRegex.test(cleaned);
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Supports formats such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Area code must be 2-4 digits (leading digit 1-9).
 * Subscriber number must be 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the value by removing spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Handle optional +54 prefix
  let withoutCountryCode = cleaned;
  if (cleaned.startsWith('+54')) {
    withoutCountryCode = cleaned.substring(3);
  }
  
  // Handle optional trunk prefix (0) and mobile indicator (9)
  let digits = withoutCountryCode;
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Validate area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = /^([1-9]\d{1,3})/.exec(digits);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = digits.substring(areaCode.length);
  
  // Validate subscriber number (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  if (!/^\d+$/.test(subscriberNumber)) return false;
  
  // Check if we have a valid overall structure
  // Either it starts with +54 or with 0 (trunk prefix)
  const argentinePhoneRegex = /^(\+54|0)([1-9]\d{1,3})\d{6,8}$/;
  return argentinePhoneRegex.test(cleaned);
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Check for empty value
  if (!value || value.trim() === '') return false;
  
  // Regex pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes (')
  // - Hyphens (-) 
  // - Spaces
  const nameRegex = /^[\p{L}\s'-]+$/u;
  
  // Additional check to reject names like "X Æ A-12" (containing digits)
  if (/\d/.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * Validates credit card numbers using regex patterns and Luhn algorithm.
 * Supports Visa, Mastercard, and AmEx with their respective prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check basic format with regex (for prefix and length)
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starting with 4
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/; // 16 digits, starting with 51-55 or 2221-2720
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starting with 34 or 37
  
  // Check if card matches any pattern
  if (!(visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned))) {
    return false;
  }
  
  // Luhn algorithm implementation
  return runLuhnCheck(cleaned);
}

/**
 * Implements the Luhn algorithm to validate credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Loop through values starting from the rightmost side
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}