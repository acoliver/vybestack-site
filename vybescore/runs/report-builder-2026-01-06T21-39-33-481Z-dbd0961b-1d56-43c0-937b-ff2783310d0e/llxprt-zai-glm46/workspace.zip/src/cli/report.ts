#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import type { ReportData } from '../types.js';
import { FORMAT_RENDERERS, SUPPORTED_FORMATS } from '../formats/index.js';

/**
 * Parse CLI arguments using Node's standard library
 */
function parseArgs(args: string[]): {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  let inputFile = '';
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (!inputFile) {
      inputFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!inputFile) {
    throw new Error('Input file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { inputFile, format, outputPath, includeTotals };
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: missing or invalid "entries" field (expected array)');
  }

  const entries = obj.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: expected an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid entry at index ${index}: missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid entry at index ${index}: missing or invalid "amount" field (expected number)`
      );
    }

    return { label: entryObj.label, amount: entryObj.amount };
  });

  return { title: obj.title, summary: obj.summary, entries };
}

/**
 * Load and parse JSON input file
 */
function loadInputFile(filePath: string): ReportData {
  const resolvedPath = path.resolve(filePath);

  if (!fs.existsSync(resolvedPath)) {
    throw new Error(`Input file not found: ${filePath}`);
  }

  const content = fs.readFileSync(resolvedPath, 'utf-8');

  let parsed: unknown;
  try {
    parsed = JSON.parse(content);
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    throw new Error(`Failed to parse JSON: ${message}`);
  }

  return validateReportData(parsed);
}

/**
 * Main CLI entry point
 */
function main(): void {
  try {
    const args = process.argv.slice(2);
    const { inputFile, format, outputPath, includeTotals } = parseArgs(args);

    if (!SUPPORTED_FORMATS.includes(format)) {
      console.error(`Unsupported format: ${format}`);
      console.error(`Supported formats: ${SUPPORTED_FORMATS.join(', ')}`);
      process.exit(1);
    }

    const data = loadInputFile(inputFile);
    const renderer = FORMAT_RENDERERS[format];
    const output = renderer(data, { includeTotals });

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();

