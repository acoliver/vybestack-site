import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Renderer function type
 */
export type Renderer = (data: ReportData, options: RenderOptions) => string;

/**
 * Map of supported format names to their renderer functions
 */
export const FORMAT_RENDERERS: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * List of supported format names
 */
export const SUPPORTED_FORMATS = Object.keys(FORMAT_RENDERERS);
