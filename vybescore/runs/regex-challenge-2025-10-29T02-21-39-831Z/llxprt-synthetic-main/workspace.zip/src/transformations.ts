/**
 * Capitalize the first character of each sentence after sentence-ending punctuation.
 * Handles spaces between sentences and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Capitalize first character of the text (if it's a lowercase letter)
  let result = text.replace(/^([a-z])/, (match, firstChar) => {
    return firstChar.toUpperCase();
  });
  
  // Find sentence boundaries (., ?, !) followed by optional spaces before the next sentence
  result = result.replace(/([.?!]\s*)([a-z])/g, (match, punctuation, nextChar) => {
    return punctuation + nextChar.toUpperCase();
  });
  
  return result;
}

/**
 * Find URLs in the text and return an array of matched URL strings.
 * Excludes trailing punctuation marks.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex pattern to match URLs
  // Matches http://, https://, and www. patterns
  // Includes common TLDs and paths, query strings, and fragments
  // Excludes trailing punctuation like ., ), :, etc.
  const urlRegex = /(?:https?:\/\/|www\.)[^\s]{2,}(?=[,.!?]|$|[^\w\-_./~?:#\[\]@!$&'()*+,;=%])/g;
  
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Remove any trailing punctuation
  return matches.map(url => url.replace(/[.,;!?):]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace all http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/(http:\/\/)([^\/]+)(\/[^ \n]*)/g, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/') && 
        !path.includes('/cgi-bin') && 
        !path.includes('?') && 
        !path.includes('&') && 
        !path.includes('=') &&
        !/\.(jsp|php|asp|aspx|do|cgi|pl|py)$/.test(path)) {
      
      // Rewrite host to docs.example.com
      const newHost = 'docs.' + host;
      return newScheme + newHost + path;
    }
    
    // Just upgrade the scheme if no rewrite needed
    return newScheme + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regex to extract month, day, and year from mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = dateRegex.exec(value);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (dayNum < 1 || dayNum > daysInMonth[monthNum]) return 'N/A';
  
  // For February, we should check for leap years if day is 29
  if (monthNum === 2 && dayNum === 29) {
    const yearNum = parseInt(year, 10);
    
    // Check if it's a leap year
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) return 'N/A';
  }
  
  return year;
}