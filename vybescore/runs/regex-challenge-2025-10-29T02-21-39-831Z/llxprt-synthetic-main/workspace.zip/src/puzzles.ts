/**
 * Match words starting with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Create regex to find whole words that start with the prefix
  // Use word boundaries \b to match whole words
  // Escape the prefix for any special regex characters
  const escapeRegex = (str: string): string => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedPrefix = escapeRegex(prefix);
  const regex = new RegExp(`\\b${escapedPrefix}\\w*`, 'g');
  
  // Find all matches
  const matches = text.match(regex);
  if (!matches) return [];
  
  // Filter out exceptions and create unique list
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  return Array.from(
    new Set(
      matches
        .map(word => word)
        .filter(word => !exceptionsSet.has(word.toLowerCase()))
    )
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Escape the token for regex special characters
  const escapeRegex = (str: string): string => str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedToken = escapeRegex(token);
  
  // Build regex to find token preceded by a digit, then capture digit+token
  const regex = new RegExp(`([0-9])${escapedToken}(?![0-9])`, 'g');
  
  const result = [];
  let match;
  
  // Reset lastIndex to ensure accurate matching
  regex.lastIndex = 0;
  
  while ((match = regex.exec(text)) !== null) {
    // Return the digit + token as expected by test
    result.push(match[0]);
  }
  
  return result;
}

/**
 * Validate passwords according to the policy:
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // Must contain at least one uppercase, one lowercase, one digit, and one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?`~]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab, 123123, etc.)
  // Check for patterns like xyxy where x and y are 2+ characters
  const repeatedPatternRegex = /(.{2,})\1/;
  if (repeatedPatternRegex.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // First, remove potential IPv4 addresses from consideration to avoid false positives
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/g;
  
  // Create a copy without IPv4 for matching
  const valueFiltered = value.replace(ipv4Pattern, '');
  
  // IPv6 patterns (simplified approach):
  // Match basic IPv6 patterns with colons including :: shorthand
  // and ensure we're not matching IPv4
  
  // Pattern to match IPv6 addresses
  const ipv6Pattern = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b|\b[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/;
  
  // Test if the filtered value (without IPv4) contains IPv6 patterns
  return ipv6Pattern.test(valueFiltered);
}