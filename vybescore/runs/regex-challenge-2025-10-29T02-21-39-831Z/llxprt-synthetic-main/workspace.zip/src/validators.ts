export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic structure check: local part @ domain part
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  if (!emailRegex.test(value)) return false;
  
  // Disallow double dots
  if (value.includes('..')) return false;
  
  // Disallow trailing dot in local part or domain
  if (value.endsWith('.')) return false;
  
  // Disallow leading or trailing dot in local part
  const [localPart] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Disallow underscores in domain
  const domain = value.split('@')[1];
  if (domain.includes('_')) return false;
  
  // Disallow domain segments starting or ending with hyphen
  const domainSegments = domain.split('.');
  for (const segment of domainSegments) {
    if (segment.startsWith('-') || segment.endsWith('-')) return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallow impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it starts with country code +1
  const hasCountryCode = value.startsWith('+1');
  
  // Minimum length should be 10 digits (without country code)
  // With country code, minimum is 11
  if (hasCountryCode && digitsOnly.length < 11) return false;
  if (!hasCountryCode && digitsOnly.length < 10) return false;
  
  // Extract relevant digits (without country code if present)
  const phoneNumber = hasCountryCode ? digitsOnly.substring(1) : digitsOnly;
  
  // If the phone number has more than 10 digits, it's invalid
  // (Could be valid if extension is allowed, but we don't have that option)
  if (phoneNumber.length > 10) return false;
  
  // Area code cannot start with 0 or 1
  if (phoneNumber.length >= 10 && (phoneNumber[0] === '0' || phoneNumber[0] === '1')) return false;
  
  // Validate the structure of the complete phone number
  // This matches various formats: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const phoneRegex = /^(\+1[\s-]?)?(\([2-9]\d{2}\)[\s-]?|[2-9]\d{2}[-]?)[2-9]\d{2}[-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern
  // Optional country code +54
  // If country code is present, optional trunk prefix 0 before area code
  // If country code is absent, must start with trunk prefix 0
  // Optional mobile indicator 9 before area code
  // Area code: 2-4 digits, first digit must be 1-9
  // Subscriber number: 6-8 digits
  const phoneRegex = /^(?:\+54)?(?:0)?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Check if the structure is valid
  if (!normalized.startsWith('+54') && !normalized.startsWith('0')) return false;
  
  const match = phoneRegex.exec(normalized);
  if (!match) return false;
  
  // Area code and subscriber number extraction (unused but needed for parsing)
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const [, _areaCode, _subscriberNumber] = match; // Prefix with underscore to indicate intentionally unused
  
  // Area code must be 2-4 digits (already enforced by regex)
  // Subscriber number must be 6-8 digits (already enforced by regex)
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters (including accented chars), apostrophes, hyphens, and spaces
  // Reject digits, special symbols, and multiple consecutive spaces
  const nameRegex = /^[\p{L}'-]+(\s[\p{L}'-]+)*$/u;
  
  // Check for basic structure
  if (!nameRegex.test(value)) return false;
  
  // Reject names with consecutive spaces or special characters
  if (value.includes('  ') || value.includes('--') || value.includes("''")) return false;
  
  // Reject names that start or end with space, apostrophe, or hyphen
  if (value.match(/^[ \'-]|[ \'-]$/)) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm helper function.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let isEven = false;
  let sum = 0;

  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for valid lengths for major card types (typically 13-19 digits)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) return false;
  
  // Check for valid prefixes:
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // American Express: 34, 37
  const visaRegex = /^4/;
  const mastercardRegex1 = /^5[1-5]/;
  const mastercardRegex2 = /^2(2[2-9][0-9]|[3-6][0-9]{2}|7([01][0-9]|20))/;
  const amexRegex = /^3[47]/;
  
  const isValidPrefix = visaRegex.test(digitsOnly) || 
                        mastercardRegex1.test(digitsOnly) || 
                        mastercardRegex2.test(digitsOnly) || 
                        amexRegex.test(digitsOnly);
  
  if (!isValidPrefix) return false;
  
  // Run Luhn algorithm
  return runLuhnCheck(digitsOnly);
}
