import type { Renderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const formatters: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const supportedFormats = Object.keys(formatters);
