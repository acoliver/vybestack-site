#!/usr/bin/env node

import * as fs from 'node:fs';
import { formatters, supportedFormats } from '../formats/index.js';
import { validateReportData } from '../validator.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  const positional: string[] = [];
  let format: string = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      i += 1;
      format = args[i];
      continue;
    }

    if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      i += 1;
      outputPath = args[i];
      continue;
    }

    if (arg === '--includeTotals') {
      includeTotals = true;
      continue;
    }

    if (arg.startsWith('--')) {
      throw new Error(`Unknown option: ${arg}`);
    }

    positional.push(arg);
  }

  if (positional.length !== 1) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    inputFile: positional[0],
    format,
    outputPath,
    includeTotals,
  };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Validate format
    if (!supportedFormats.includes(args.format)) {
      console.error(`Unsupported format: ${args.format}`);
      console.error(`Supported formats: ${supportedFormats.join(', ')}`);
      process.exit(1);
    }

    // Read and parse input file
    let inputContent: string;
    try {
      inputContent = fs.readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
        console.error(`Error: File not found: ${args.inputFile}`);
        process.exit(1);
      }
      throw error;
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(inputContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file ${args.inputFile}`);
      if ((error as SyntaxError).message) {
        console.error(`Details: ${(error as SyntaxError).message}`);
      }
      process.exit(1);
    }

    // Validate report data structure
    const reportData: ReportData = validateReportData(jsonData);

    // Render report
    const renderer = formatters[args.format];
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    const output = renderer(reportData, options);

    // Write output
    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
