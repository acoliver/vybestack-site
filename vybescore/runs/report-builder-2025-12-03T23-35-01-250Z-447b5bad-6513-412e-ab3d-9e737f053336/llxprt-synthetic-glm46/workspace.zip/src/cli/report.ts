#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(): { dataFile: string; options: ReportOptions } | null {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    return null;
  }
  
  const dataFile = args[0];
  
  if (args[1] !== '--format') {
    return null;
  }
  
  const format = args[2] as 'markdown' | 'text';
  
  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }
  
  const options: ReportOptions = { format };
  
  let i = 3;
  while (i < args.length) {
    if (args[i] === '--output' && i + 1 < args.length) {
      options.output = args[i + 1];
      i += 2;
    } else if (args[i] === '--includeTotals') {
      options.includeTotals = true;
      i += 1;
    } else {
      throw new Error(`Unknown argument: ${args[i]}`);
    }
  }
  
  return { dataFile, options };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Report must have a title field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Report must have a summary field');
    }
    
    if (!Array.isArray(data.entries) || data.entries.length === 0) {
      throw new Error('Report must have a non-empty entries array');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Each entry must have a label field');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Each entry must have a numeric amount field');
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

function renderReport(data: ReportData, options: ReportOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function main(): void {
  try {
    const parsed = parseArguments();
    
    if (!parsed) {
      console.error('Usage: node dist/cli/report.js <data.json> --format <markdown|text> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
    
    const { dataFile, options } = parsed;
    const data = loadReportData(dataFile);
    const output = renderReport(data, options);
    
    if (options.output) {
      writeFileSync(options.output, output, 'utf-8');
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
