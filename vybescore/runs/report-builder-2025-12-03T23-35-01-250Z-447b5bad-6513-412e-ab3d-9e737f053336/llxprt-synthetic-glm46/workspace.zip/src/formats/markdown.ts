import type { ReportData, ReportOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: ReportOptions): string {
  const lines: string[] = [];
  
  lines.push(`# ${data.title}`);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('## Entries');
  
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    lines.push(`**Total:** $${total.toFixed(2)}`);
  }
  
  return lines.join('\n');
}