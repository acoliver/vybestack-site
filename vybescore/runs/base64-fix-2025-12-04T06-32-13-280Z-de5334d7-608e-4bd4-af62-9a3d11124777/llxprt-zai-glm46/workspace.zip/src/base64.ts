/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

// Constants to avoid duplicate strings
const ERROR_MESSAGE = 'Invalid Base64 input';

/**
 * Validates if a string has proper Base64 padding.
 */
function hasValidPadding(input: string): boolean {
  const paddingIndex = input.indexOf('=');
  if (paddingIndex === -1) {
    return true; // No padding is valid
  }
  
  const paddingLength = input.length - paddingIndex;
  
  // Padding must be at the end and can be 1 or 2 characters
  if (paddingLength > 2) {
    return false;
  }
  
  // Check that padding length is correct for the total length
  if (input.length % 4 !== 0) {
    return false;
  }
  
  // When there's padding, check that padding character position makes sense
  const dataLength = paddingIndex;
  const remainder = dataLength % 4;
  if (remainder === 1) {
    return false; // Can't have padding when data length % 4 === 1
  }
  
  // For proper padding:
  // If we have 1 padding char (=), data length should be divisible by 4 with remainder 3
  // If we have 2 padding chars (==), data length should be divisible by 4 with remainder 2
  return (paddingLength === 1 && remainder === 3) ||
         (paddingLength === 2 && remainder === 2) ||
         (paddingLength === 0);
}

/**
 * Validates if an unpadded string has a valid length.
 */
function hasValidUnpaddedLength(input: string): boolean {
  const remainder = input.length % 4;
  return remainder !== 1; // Length % 4 === 1 is never valid
}

/**
 * Validates if a string is valid Base64 according to the standard specification.
 * Returns true if the string contains only valid Base64 characters and proper padding.
 */
function isValidBase64(input: string): boolean {
  // Empty string is technically valid but not useful
  if (input.length === 0) {
    return false;
  }
  
  // Check for valid Base64 characters: A-Z, a-z, 0-9, +, /, and = for padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  const paddingIndex = input.indexOf('=');
  
  return paddingIndex === -1 
    ? hasValidUnpaddedLength(input)
    : hasValidPadding(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects invalid Base64 input and throws an error for malformed data.
 */
export function decode(input: string): string {
  // Validate using our own validation function first
  if (!isValidBase64(input)) {
    throw new Error(ERROR_MESSAGE);
  }

  try {
    // Let Buffer handle the actual decoding - it will fail if the input is truly invalid
    // even if it passes our validation
    const result = Buffer.from(input, 'base64').toString('utf8');
    // Additional check: try to encode back and see if we get the same (modulo padding)
    // This catches cases where Node.js silently decodes garbage
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Remove padding for comparison
    const normalizedOriginal = input.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    if (normalizedOriginal !== normalizedReencoded) {
      throw new Error(ERROR_MESSAGE);
    }
    return result;
  } catch (error) {
    throw new Error(ERROR_MESSAGE);
  }
}
