/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64.
 */
export function decode(input: string): string {
  const normalized = input.trim();

  // Basic validation for Base64 input
  if (normalized.length === 0) {
    throw new Error('Empty input provided');
  }

  // Check for invalid characters (only allow Base64 alphabet and padding)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(normalized)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Validate padding is correct
  if (normalized.includes('==') && !normalized.endsWith('==')) {
    throw new Error('Invalid Base64 padding');
  }
  if (normalized.includes('=') && !normalized.endsWith('==') && !normalized.endsWith('=')) {
    throw new Error('Invalid Base64 padding');
  }

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
