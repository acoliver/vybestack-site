import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import sqlite3 from 'sql.js';
import fs from 'fs';

// Get the directory name in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express app
const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
let db: sqlite3.Database;

function initDB() {
  try {
    const dbFileBuffer = fs.readFileSync(DB_PATH);
    db = new sqlite3.Database(dbFileBuffer);
  } catch (err) {
    // Database file doesn't exist, create new
    db = new sqlite3.Database();
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schema);
  }
}

// Render form
app.get('/', (req, res) => {
  res.render('form');
});

// TODO: Add validation logic and submission handling

// TODO: Add thank-you page route

// TODO: Implement graceful shutdown

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
  initDB();
});

export default app;