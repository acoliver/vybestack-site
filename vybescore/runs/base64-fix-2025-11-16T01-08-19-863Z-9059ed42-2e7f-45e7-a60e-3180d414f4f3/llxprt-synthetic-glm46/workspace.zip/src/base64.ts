/**
 * Encode plain text to Base64 using standard alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using standard Base64 alphabet.
 * Throws an error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input.trim()) {
    throw new Error('Invalid Base64 input: empty input');
  }

  // Check for obviously invalid Base64 characters
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Pattern.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check if padding is correct (only at the end and at most 2 characters)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only be in the last one or two positions
    if (paddingIndex < input.length - 2) {
      throw new Error('Invalid Base64 input: padding in wrong position');
    }
    // Verify all padding characters are at the end
    const afterPadding = input.substring(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      throw new Error('Invalid Base64 input: invalid padding sequence');
    }
  }

  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // Check if the input length is valid for Base64
    // Valid Base64 strings must have a length that is a multiple of 4
    // (except when padding is missing)
    const normalizedInput = input.replace(/=+$/, '');
    if (normalizedInput.length % 4 !== 0) {
      // If it's not a multiple of 4, Buffer.from might still decode but it's valid Base64
      // only if the encoded data was actually correct
      // Let's do an additional check by re-encoding what we decoded
      const reencoded = Buffer.from(decoded, 'utf8').toString('base64');
      const reencodedWithoutPadding = reencoded.replace(/=+$/, '');
      
      // If re-encoding doesn't match the original (without padding), 
      // the input was likely malformed
      if (reencodedWithoutPadding !== normalizedInput) {
        throw new Error('Invalid Base64 input: malformed');
      }
    }
    
    return decoded;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
