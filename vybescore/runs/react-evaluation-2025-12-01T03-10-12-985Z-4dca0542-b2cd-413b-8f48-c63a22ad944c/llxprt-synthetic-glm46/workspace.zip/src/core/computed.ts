/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  getActiveObserver, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

// Global computation tracking to prevent infinite recursion
let computing = false
const computingStack: string[] = []

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle boolean and function equality parameters
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'boolean') {
    equalFn = _equal ? (a, b) => a === b : undefined
  } else if (_equal) {
    equalFn = _equal
  }

  const observerId = options?.name || `computed_${Math.random().toString(36).substr(2, 9)}`

  // Create a simple observer
  const observer: Observer<T> = {
    name: observerId,
    value,
    updateFn: (prev?: T) => {
      // Prevent infinite recursion
      if (computing && computingStack.includes(observerId)) {
        return observer.value as T
      }

      const previousComputing = computing
      computing = true
      computingStack.push(observerId)
      
      try {
        // Set this observer as the active one to track dependencies
        const previousActive = getActiveObserver()
        ;(globalThis as Record<string, unknown>).__activeObserver = observer
        
        // Execute the computation function
        // For initial call, call without argument to trigger default parameter
        const result = updateFn()
        
        if (result !== undefined && (observer.value === undefined || !equalFn?.(result, observer.value as T))) {
          observer.value = result
          // Always update subject value
          subject.value = result as T
          
          // Notify observers if this is a change (not initial computation)
          if (prev !== undefined) {
            // Run callbacks registered globally
            const callbacks = (globalThis as Record<string, unknown>).__callbacks as Array<() => void>
            if (callbacks) {
              callbacks.forEach((callback: () => void) => {
                try {
                  callback()
                } catch (e) {
                  // Ignore callback errors
                }
              })
            }
          }
        }
      } finally {
        computing = previousComputing
        computingStack.pop()
        // Clean up global observer reference
        const currentActive = getActiveObserver()
        if (currentActive && currentActive === observer) {
          delete (globalThis as Record<string, unknown>).__activeObserver
        }
      }

      return observer.value as T
    },
  }

  // Create a subject wrapper for this computed value
  const subject: Subject<T> = {
    name: observerId,
    observer: undefined,
    value: observer.value as T,
    equalFn,
  }

  // The computed getter function
  const computeGetter: GetterFn<T> = () => {
    // Set this observer as active to track dependencies
    const previousActive = getActiveObserver()
    ;(globalThis as Record<string, unknown>).__activeObserver = observer
    
    // Store this observer to be notified when dependencies change
    if (previousActive) {
      subject.observer = previousActive
    }
    
    // Always trigger computation to ensure value is up to date
    // This ensures that even when no dependencies changed, the value is computed
    observer.updateFn(observer.value as T)
    
    // Restore the previous active observer
    if (previousActive) {
      (globalThis as Record<string, unknown>).__activeObserver = previousActive
    } else {
      delete (globalThis as Record<string, unknown>).__activeObserver
    }
    
    return observer.value!
  }

  // Initial computation 
  // Always compute using the updateFn to get the initial value
  // The value parameter is just used as the first argument to updateFn
  
  // Set this observer as active for dependency tracking
  ;(globalThis as Record<string, unknown>).__activeObserver = observer
  
  try {
    const result = updateFn() // no argument should trigger default parameter in updateFn
    if (result !== undefined) {
      observer.value = result
      subject.value = result
    }
  } catch (e) {
    // Ignore errors during initial computation
  } finally {
    const currentPreviousActive = getActiveObserver()
    if (currentPreviousActive && currentPreviousActive !== observer) {
      (globalThis as Record<string, unknown>).__activeObserver = currentPreviousActive
    } else {
      delete (globalThis as Record<string, unknown>).__activeObserver
    }
  }

  return computeGetter
}