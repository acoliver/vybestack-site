/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle boolean and function equality parameters
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'boolean') {
    equalFn = _equal ? (a, b) => a === b : undefined
  } else if (_equal) {
    equalFn = _equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    // Store this observer to be notified when value changes
    if (observer && typeof observer === 'object') {
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (newValue: T) => {
    // Only update if value actually changed
    if (equalFn ? !equalFn(newValue, s.value) : newValue !== s.value) {
      s.value = newValue
      
      // Notify observer if it exists
      if (s.observer) {
        updateObserver(s.observer)
      }
      
      // Trigger callbacks registered globally
      const callbacks = (globalThis as Record<string, unknown>).__callbacks as Array<() => void>
      if (callbacks) {
        callbacks.forEach((callback: () => void) => {
          try {
            callback()
          } catch (e) {
            // Ignore callback errors
          }
        })
      }
    }
    
    return newValue
  }

  return [read, write]
}