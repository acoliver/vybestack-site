/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create an observer that will execute the side effects
  const observer: Observer<T> = {
    value,
    updateFn: (prev?: T) => {
      // Execute the side effect function
      const result = updateFn(prev)
      return result
    },
  }
  
  // Initially track dependencies by running the update function to collect dependencies
  const previousActive = getActiveObserver()
  
  // Set this callback observer as active to track its dependencies
  ;(globalThis as Record<string, unknown>).__activeObserver = observer
  
  // Execute the update function to track dependencies
  try {
    updateFn(value)
  } catch (e) {
    // Ignore errors during initial tracking
  } finally {
    // Restore the previous active observer
    if (previousActive) {
      (globalThis as Record<string, unknown>).__activeObserver = previousActive
    } else {
      delete (globalThis as Record<string, unknown>).__activeObserver
    }
  }
  
  let disposed = false
  
  // Store this callback globally to make sure it gets triggered
  // This ensures that the callback remains in memory and can be triggered by dependencies
  if (!(globalThis as Record<string, unknown>).__callbacks) {
    (globalThis as Record<string, unknown>).__callbacks = []
  }
  const callbackArray = (globalThis as Record<string, unknown>).__callbacks as Array<(prev?: T) => void>
  callbackArray.push((prev?: T) => {
    if (!disposed) {
      observer.updateFn(prev)
    }
  })
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from global callbacks
    const callbacks = (globalThis as Record<string, unknown>).__callbacks as Array<(prev?: T) => void>
    const index = callbacks.findIndex((fn: (prev?: T) => void) => fn === observer.updateFn)
    if (index > -1) {
      callbacks.splice(index, 1)
    }
  }
}