/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T | undefined

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverV<T> = {
  value?: T
  updateFn: (value?: T) => T | undefined | void
}

export type ObserverR = {
  name?: string
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: Observer<any> | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  const globalObserver = (globalThis as Record<string, unknown>).__activeObserver
  return (globalObserver as Observer<any>) || activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<any>
  try {
    // Check if the observer has a valid updateFn before calling it
    if (observer && typeof observer.updateFn === 'function') {
      const result = observer.updateFn(observer.value)
      if (result !== undefined) {
        observer.value = result
      }
    }
  } finally {
    activeObserver = previous
  }
}