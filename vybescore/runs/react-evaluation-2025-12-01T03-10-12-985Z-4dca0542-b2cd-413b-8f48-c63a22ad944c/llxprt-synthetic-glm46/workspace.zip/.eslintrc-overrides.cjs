module.exports = {
  rules: {
    "@typescript-eslint/no-unused-vars": "off",
    "@typescript-eslint/semi": "off",
    "semi": "off"
  }
}