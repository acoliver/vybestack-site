/**
 * TypeScript type definitions for the report builder tool
 */

// Base interface that all report data items should extend
export interface BaseReportItem {
  name?: string; // optional name property for report items
  [key: string]: any; // allow additional properties
}

// Input data type - can accept any JSON-serializable array
export type ReportData = Array<BaseReportItem>;

// Output format options
export enum OutputFormat {
  MARKDOWN = 'markdown',
  TEXT = 'text',
  JSON = 'json'
}

// CLI options interface
export interface ReportBuilderOptions {
  /** Output format (markdown, text, or json) */
  format: OutputFormat;
  /** File path to output the report */
  output?: string;
  /** Additional title for the report */
  title?: string;
  /** Whether to include a table of contents */
  includeToc?: boolean;
}

// Default options
export const defaultOptions: Partial<ReportBuilderOptions> = {
  format: OutputFormat.MARKDOWN,
  includeToc: true
};