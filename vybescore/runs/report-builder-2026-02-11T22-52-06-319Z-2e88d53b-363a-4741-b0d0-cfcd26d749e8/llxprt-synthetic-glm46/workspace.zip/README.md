# Report Builder UI

A flexible and customizable React component library for building interactive reports with rich features including dynamic grouping, filtering, sorting, data visualization, and export capabilities.

## Features

- Dynamic Grouping - Nested hierarchical structure with expandable/collapsible sections
- Advanced Filtering - Multi-criteria filtering with various filter types
- Data Visualization - Interactive charts and graphs using Chart.js
- Exporting Reports - Multiple export formats (PDF, CSV, Excel, PNG)
- Customizable Layout - Grid, List, Card views with drag-to-resize columns
- Search Functionality - Real-time search with highlighting
- Data Manipulation - Inline editing with validation
- Summary Statistics - Aggregate calculations for report data

## Installation

```bash
npm install @your-org/report-builder-ui
```

## Quick Start

```jsx
import { ReportBuilder } from '@your-org/report-builder-ui';

function App() {
  return (
    <ReportBuilder
      data={yourData}
      config={{
        title: "Sales Report",
        columns: [
          { key: 'name', title: 'Product Name', sortable: true },
          { key: 'price', title: 'Price', sortable: true, type: 'number' },
          { key: 'category', title: 'Category', filterable: true }
        ]
      }}
      onExport={(format, data) => {
        // Handle export action
        console.log(`Exporting to ${format}:`, data);
      }}
    />
  );
}
```

## Configuration

The ReportBuilder accepts a powerful configuration object that allows you to customize every aspect of your report:

```js
const config = {
  // General settings
  title: "My Report",
  theme: "light",
  density: "comfortable",
  height: "auto",
  
  // Column configuration
  columns: [
    {
      key: 'id',
      title: 'ID',
      sortable: false,
      filterable: false,
      resizable: false,
      type: 'string',
      width: 100
    },
    // ... more columns
  ],
  
  // Grouping
  defaultGroupBy: [],
  groupExpansionState: 'expanded',
  
  // Filtering
  filters: {},
  
  // Sorting
  sortBy: [],
  sortDirection: 'asc',
  
  // Search
  searchTerm: '',
  searchColumns: ['name', 'description'],
  
  // Layout
  layout: 'grid',
  
  // Data visualization
  charts: [
    {
      type: 'bar',
      title: 'Sales by Region',
      config: { /* chart config */ }
    }
  ],
  
  // Export
  exportFormats: ['pdf', 'csv', 'excel'],
  exportFileName: 'report',
  
  // Data manipulation
  editable: false,
  
  // Summary
  summary: {
    enabled: true,
    fields: ['total', 'count'],
    aggregates: ['sum', 'count']
  }
};
```

## API Reference

### ReportBuilder Props

| Prop | Type | Default | Description |
|------|------|---------|-------------|
| data | Array | [] | The data to display in the report |
| config | Object | {} | Configuration object for the report |
| onExport | Function | () => {} | Callback when export is triggered |
| onFilterChange | Function | () => {} | Callback when filters change |
| onSortChange | Function | () => {} | Callback when sorting changes |
| onSearch | Function | () => {} | Callback when search is performed |
| onDataChange | Function | () => {} | Callback when data is modified |

## License

MIT