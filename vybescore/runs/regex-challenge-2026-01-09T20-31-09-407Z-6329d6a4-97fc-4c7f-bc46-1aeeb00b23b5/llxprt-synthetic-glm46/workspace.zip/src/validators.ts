export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Basic format validation
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  // No consecutive dots in local part
  if (value.includes('..')) {
    return false;
  }
  
  // No dots at beginning or end of local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must not start or end with dot or hyphen
  if (domain.startsWith('.') || domain.startsWith('-') || domain.endsWith('.') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 prefix.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove spaces, hyphens, parentheses for validation
  const cleaned = value.replace(/[\s\-()]/g, '');
  
  // Check for optional +1 prefix
  const phoneNumber = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;
  
  // Check length: should be exactly 10 digits after removing prefix
  if (phoneNumber.length !== 10 || !/^\d+$/.test(phoneNumber)) {
    return false;
  }
  
  // Area code validation: cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Extension handling (if allowed)
  if (options?.allowExtensions && value.includes('ext')) {
    // Allow extensions if specified in options
    return true;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Optional country code +54.
 * Optional trunk prefix 0 immediately before the area code.
 * Optional mobile indicator 9 between country/trunk and the area code.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern: 
  // Optional +54 (country code)
  // Optional 0 (trunk prefix)
  // Optional 9 (mobile indicator)
  // Area code (2-4 digits, leading 1-9)
  // Subscriber number (6-8 digits)
  const pattern = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleaned.match(pattern);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // Area code validation: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number validation: 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // When country code is omitted, the number must begin with trunk prefix 0
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Check for empty string
  const trimmedValue = value.trim();
  if (!trimmedValue) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, symbols, and invalid patterns
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  return nameRegex.test(trimmedValue);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if the cleaned value contains only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // AmEx: starts with 34 or 37, length 15
  const validPatterns = [
    /^4(\d{12}|\d{15})$/,          // Visa (13 or 16 digits)
    /^5[1-5]\d{14}$/,              // Mastercard (starting with 51-55)
    /^2(2[2-9]\d|3[0-9]\d|[4-9]\d{2}|[1-9]\d{3})\d{10}$/, // Mastercard (2221-2720)
    /^3[47]\d{13}$/                 // AmEx (34 or 37)
  ];
  
  // Check if the card number matches any valid pattern
  const matchesPattern = validPatterns.some(pattern => pattern.test(cleaned));
  if (!matchesPattern) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

// Helper function to perform Luhn checksum
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
