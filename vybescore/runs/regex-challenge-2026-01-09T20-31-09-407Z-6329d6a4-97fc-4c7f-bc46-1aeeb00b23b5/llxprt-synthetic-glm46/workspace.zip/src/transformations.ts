/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Split the text into sentences using sentence terminators (., !, ?)
  // but preserve abbreviations containing periods like "i.e.", "e.g.", etc.
  const sentences = text.split(/(?<=[.!?])(?=\s|$)/);
  
  return sentences.map(sentence => {
    const trimmed = sentence.trim();
    if (!trimmed) return '';
    
    // Capitalize the first character of the sentence
    const firstChar = trimmed.charAt(0).toUpperCase();
    const rest = trimmed.slice(1);
    
    // Return the capitalized sentence
    return firstChar + rest;
  }).join(' ').trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regular expression to match URLs without trailing punctuation
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s.,;:!?'"(){}]*)?/g;
  
  // Extract all matches
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
  // Remove trailing punctuation from each URL
  return matches.map(url => url.replace(/[.,;:!?'"{}()\s]*$/, ''));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace all http:// with https:// without affecting existing https:// URLs
  return text.replace(
    /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g,
    (match) => match.startsWith('https://') ? match : match.replace('http://', 'https://')
  );
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const httpExampleUrlPattern = /http:\/\/example\.com([^\s]*)/g;
  
  return text.replace(httpExampleUrlPattern, (match, path) => {
    // Always upgrade to https://
    const upgradedUrl = `https://example.com${path}`;
    
    // Check if path starts with /docs/ and doesn't contain dynamic hints
    if (path.startsWith('/docs/')) {
// Check for dynamic hints that should skip host rewrite
    const hasDynamicHints = /(cgi-bin|[?&]|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)/.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com
        return `https://docs.example.com${path}`;
      }
    }
    
    // Return the upgraded URL with original host
    return upgradedUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day] = match;
  
  // Validate month and day combinations
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for invalid day/month combinations
  if (
    (monthNum === 2 && dayNum > 29) || // February
    ((monthNum === 4 || monthNum === 6 || monthNum === 9 || monthNum === 11) && dayNum > 30) || // April, June, September, November
    (dayNum > 31) // All other months
  ) {
    return 'N/A';
  }
  
  // Return the year part
  return match[3];
}
