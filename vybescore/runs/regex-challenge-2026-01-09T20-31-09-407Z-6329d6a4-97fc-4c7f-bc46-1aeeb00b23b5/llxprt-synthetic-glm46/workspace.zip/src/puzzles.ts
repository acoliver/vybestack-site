/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regular expression to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${prefix}\\w+\\b`, 'gi');
  const matches = text.match(wordPattern) || [];
  
  // Filter out the exceptions (case-insensitive)
  const exceptionsSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  return matches.filter(word => !exceptionsSet.has(word.toLowerCase()));
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find matches and include the leading digit
  const matches = text.match(new RegExp(`\\d${escapedToken}(?!^)`, 'g'));
  
  return matches || [];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab should fail)
  // Check for 2-char repeated patterns
  if (/(.{2})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  // Standard format: eight groups of four hexadecimal digits
  // Shorthand: can have :: for consecutive groups of zeros
  // IPv6 can be mixed with IPv4 in the last two groups
  
  // Simple IPv6 pattern that doesn't have IPv4 components
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::1?:[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/;
  
  // Check for IPv4 pattern to exclude false positives
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If the entire text is a pure IPv4 address, return false
  if (ipv4Pattern.test(value.trim()) && !ipv6Pattern.test(value)) {
    return false;
  }
  
  // Find IPv6 addresses in the text
  return ipv6Pattern.test(value);
}
