/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  // \b ensures we match whole words, using Unicode property for broader character support
  const pattern = new RegExp(`\\b${prefix}[\\p{L}\\p{N}]*\\b`, 'gu');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  return matches.filter(word => !exceptionsLower.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern to match a digit followed by the token
  const pattern = new RegExp(`\\d${token}`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out matches that start at position 0 (beginning of string)
  return matches.filter(match => {
    const index = text.indexOf(match);
    return index > 0;
  });
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // One uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // One lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // One digit
  if (!/\d/.test(value)) return false;
  
  // One symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab should fail)
  // Check for patterns like abab, xyxy, 1212, etc.
  for (let i = 0; i < value.length - 3; i++) {
    const chunk = value.substring(i, i + 2);
    const nextChunk = value.substring(i + 2, i + 4);
    if (chunk === nextChunk) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address pattern
  // Matches various IPv6 formats including shorthand with ::
  // Ensures it doesn't match IPv4 addresses
  
  // First, check if there are any dots (which would indicate IPv4)
  if (value.includes('.')) {
    // If it contains dots, check if it's a valid IPv6 representation with dots
    // (though pure IPv6 shouldn't have dots)
    // We'll be conservative and only accept IPv6 with colons and hex digits
  }
  
  // IPv6 patterns to match:
  // 1. Full IPv6: 8 groups of 4 hex digits separated by colons
  // 2. Shorthand with :: compression
  // 3. Mixed notation with IPv4 at the end
  
  // Pattern for full IPv6 (including shorthand)
  // This pattern is complex and needs to handle :: compression
  const ipv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/; // Full form
  const ipv6CompressedPattern = /^(?:[0-9a-fA-F]{1,4}:)*(?::[0-9a-fA-F]{1,4})*$/; // With ::
  const ipv6WithIPv4Pattern = /^(?:[0-9a-fA-F]{1,4}:){6}(\d{1,3}\.){3}\d{1,3}$/; // IPv6 with IPv4
  
  // Also check for IPv6 in longer strings
  const embeddedIpv6Pattern = /(^|[^0-9a-fA-F:])([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}([^0-9a-fA-F:]|$)/;
  const embeddedIpv6CompressedPattern = /(^|[^0-9a-fA-F:])(?:[0-9a-fA-F]{1,4}:)*(?::[0-9a-fA-F]{1,4})*([^0-9a-fA-F:]|$)/;
  
  // Test the string against various IPv6 patterns
  if (ipv6Pattern.test(value) || 
      ipv6CompressedPattern.test(value) || 
      ipv6WithIPv4Pattern.test(value) ||
      embeddedIpv6Pattern.test(value) || 
      embeddedIpv6CompressedPattern.test(value)) {
    
    // Extra check: make sure it doesn't look like IPv4
    // IPv4 pattern: 4 numbers separated by dots, each 0-255
    const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    
    if (ipv4Pattern.test(value)) {
      return false; // This is IPv4, not IPv6
    }
    
    return true;
  }
  
  return false;
}
