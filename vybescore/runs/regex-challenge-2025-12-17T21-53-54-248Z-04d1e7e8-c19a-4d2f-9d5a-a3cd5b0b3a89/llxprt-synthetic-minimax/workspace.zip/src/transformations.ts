/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Pattern to match sentence boundaries (.?!)
  // We'll split and process sentences individually
  const sentences = text.split(/([.?!]+\s*)/);
  
  let result = '';
  let shouldCapitalize = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const sentence = sentences[i];
    
    if (/^[.?!]+\s*$/.test(sentence)) {
      // This is punctuation and whitespace
      result += sentence;
      shouldCapitalize = true; // Next sentence should be capitalized
    } else if (sentence.trim()) {
      // This is actual text content
      if (shouldCapitalize) {
        // Capitalize first letter and add the rest
        const trimmed = sentence.trimStart();
        const spaces = sentence.substring(0, sentence.length - trimmed.length);
        result += spaces + trimmed.charAt(0).toUpperCase() + trimmed.substring(1);
        shouldCapitalize = false;
      } else {
        result += sentence;
      }
    } else {
      result += sentence;
    }
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  // Matches http(s):// with valid domain and optional path
  const urlRegex = /https?:\/\/[^\s<>"']+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation that might be part of sentences
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http URLs with capture groups
  // Group 1: protocol (http://)
  // Group 2: domain 
  // Group 3: path (starting with /)
  const urlPattern = /(https?:\/\/)([^/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    
    // Check if path contains dynamic hints that should skip host rewrite
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    // Check if path begins with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    if (isDocsPath && !hasDynamicHints) {
      // Rewrite host to docs.domain.com
      const newDomain = `docs.${domain}`;
      return `${newProtocol}${newDomain}${path}`;
    } else {
      // Just upgrade protocol, keep original domain
      return `${newProtocol}${domain}${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, checking for specific month lengths and leap years would be more complex)
  // For basic validation, just check if day is between 1-31
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Validate year (reasonable range, e.g., 1900-2100)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return year.toString();
}
