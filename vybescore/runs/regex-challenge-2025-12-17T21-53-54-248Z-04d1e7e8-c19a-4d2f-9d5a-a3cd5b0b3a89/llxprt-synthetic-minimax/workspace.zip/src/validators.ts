export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  // Basic email pattern with comprehensive validation
  // Local part: letters, numbers, dots, underscores, percent, plus, hyphens (but not double dots, leading/trailing dots)
  // Domain part: letters, numbers, dots, hyphens (but not double dots, leading/trailing dots, underscores)
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  // Additional checks to reject obviously invalid forms
  if (!emailRegex.test(trimmed)) return false;
  
  // Reject double dots
  if (trimmed.includes('..')) return false;
  
  // Reject trailing dots
  if (trimmed.endsWith('.')) return false;
  
  // Reject domain with underscores (they're technically allowed in local part but not domains)
  const domain = trimmed.split('@')[1];
  if (domain.includes('_')) return false;
  
  return true;
}

/**
 * Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // If it starts with +1, remove it for easier processing
  let digits = cleaned;
  if (cleaned.startsWith('+1')) {
    digits = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    digits = cleaned.substring(1);
  }
  
  // Must have exactly 10 digits
  if (!/^\d{10}$/.test(digits)) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // If extensions are allowed, they should be separated by common extension indicators
  if (options?.allowExtensions) {
    const extMatch = value.match(/(?:ext|extension|x)\s*(\d{1,5})/i);
    if (extMatch) {
      // Extension found and is valid (1-5 digits), but main number still needs to be valid
      const ext = extMatch[1];
      if (!/^\d{1,5}$/.test(ext)) return false;
    }
  }
  
  return true;
}

/**
 * Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for easier processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Group 1: Country code +54 (optional)
  // Group 2: Mobile indicator 9 (optional)
  // Group 3: Trunk prefix 0 (optional, but required when no country code)
  // Group 4: Area code (2-4 digits, first digit 1-9)
  // Group 5: Subscriber number (remaining digits, should be 6-8 total digits including area code)
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Area code validation: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] < '1' || areaCode[0] > '9') return false;
  
  // Total number validation: area code + subscriber number should be 8-12 digits total
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) return false;
  
  // Additional validation: subscriber number should be 4-8 digits
  if (subscriberNumber.length < 4 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Remove leading/trailing whitespace
  const trimmed = value.trim();
  
  if (trimmed.length === 0) return false;
  
  // Pattern for valid names:
  // - Unicode letters (including accents) 
  // - Spaces between parts
  // - Apostrophes (O'Connor, D'Angelo)
  // - Hyphens (Jean-Pierre, Smith-Jones)
  // Must start with a letter
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  if (!nameRegex.test(trimmed)) return false;
  
  // Reject names that contain digits
  if (/\d/.test(trimmed)) return false;
  
  // Reject unusual symbols (beyond apostrophes and hyphens)
  if (/[^\p{L}\s'-]/u.test(trimmed)) return false;
  
  // Reject "X Æ A-12" style names - check for non-alphabetic symbols in middle
  if (/[ÆØÅ]/.test(trimmed)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */

/**
 * Helper function to calculate Luhn checksum
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;

  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  const length = cleaned.length;
  const firstDigit = cleaned[0];
  const firstTwoDigits = parseInt(cleaned.substring(0, 2), 10);
  const firstFourDigits = parseInt(cleaned.substring(0, 4), 10);
  
  // Visa: starts with 4, length 13, 16, or 19
  if (firstDigit === '4') {
    if (length === 13 || length === 16 || length === 19) {
      return runLuhnCheck(cleaned);
    }
    return false;
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if ((firstTwoDigits >= 51 && firstTwoDigits <= 55) || 
      (firstFourDigits >= 2221 && firstFourDigits <= 2720)) {
    if (length === 16) {
      return runLuhnCheck(cleaned);
    }
    return false;
  }
  
  // American Express: starts with 34 or 37, length 15
  if ((firstTwoDigits === 34 || firstTwoDigits === 37) && length === 15) {
    return runLuhnCheck(cleaned);
  }
  
  return false;
}
