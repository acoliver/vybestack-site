#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import { exit, stderr } from 'node:process';
import type { ReportData, ReportOptions } from '../types.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    stderr.write('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]\n');
    exit(1);
  }
  
  const dataFile = args[0];
  
  // Find format argument
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    stderr.write('Error: --format argument is required\n');
    exit(1);
  }
  const format = args[formatIndex + 1];
  
  // Find output argument (optional)
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  
  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateFormat(format: string): void {
  if (!(format in formatters)) {
    stderr.write(`Error: Unsupported format "${format}"\n`);
    exit(1);
  }
}

async function loadReportData(filePath: string): Promise<ReportData> {
  try {
    const fileContent = await readFile(filePath, 'utf-8');
    const data = JSON.parse(fileContent) as unknown;
    
    // Validate data structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: root must be an object');
    }
    
    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field');
    }
    
    for (const entry of reportData.entries) {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error('Invalid JSON: entry must be an object');
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error('Invalid JSON: entry missing or invalid "label" field');
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error('Invalid JSON: entry missing or invalid "amount" field');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      stderr.write(`Error: Invalid JSON in file "${filePath}": ${error.message}\n`);
    } else {
      stderr.write(`Error: ${error instanceof Error ? error.message : String(error)}\n`);
    }
    exit(1);
  }
}

async function writeOutput(content: string, outputPath?: string): Promise<void> {
  if (outputPath) {
    try {
      await writeFile(outputPath, content, 'utf-8');
    } catch (error) {
      stderr.write(`Error writing to output file "${outputPath}": ${error instanceof Error ? error.message : String(error)}\n`);
      exit(1);
    }
  } else {
    console.log(content);
  }
}

async function main(): Promise<void> {
  const args = parseArguments();
  validateFormat(args.format);
  
  const data = await loadReportData(args.dataFile);
  const options: ReportOptions = {
    includeTotals: args.includeTotals,
  };
  
  const formatter = formatters[args.format];
  const output = formatter(data, options);
  
  await writeOutput(output, args.outputPath);
}

main();