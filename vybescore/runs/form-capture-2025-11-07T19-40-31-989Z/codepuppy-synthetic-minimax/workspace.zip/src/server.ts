import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
// @ts-expect-error - sql.js types may not be available
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

let db: Database | null = null;
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    let dbBuffer: Uint8Array;
    if (fs.existsSync(DB_PATH)) {
      const fileData = fs.readFileSync(DB_PATH);
      dbBuffer = new Uint8Array(fileData);
    } else {
      // Create empty database
      dbBuffer = new Uint8Array([]);
      db = new SQL.Database(dbBuffer);
      
      // Create schema
      const schema = fs.readFileSync(
        path.join(__dirname, '..', 'db', 'schema.sql'), 
        'utf8'
      );
      db.run(schema);
      
      // Save initial database
      saveDatabase();
      return;
    }
    
    db = new SQL.Database(dbBuffer);
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email.trim());
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s-()]+$/;
  return phoneRegex.test(phone.trim()) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric characters, spaces, and dashes for international formats
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postalCode.trim()) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): { isValid: boolean; errors: ValidationError[] } {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const value = data[field]?.trim();
    if (!value || value.length === 0) {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    }
  }

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number (digits, spaces, +, -, parentheses allowed)'
    });
  }

  // Postal code validation
  if (data.postalCode && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code (letters and numbers allowed)'
    });
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateFormData(formData);

  if (!validation.isValid) {
    const errorMessages = validation.errors.map(error => error.message);
    res.render('form', {
      errors: errorMessages,
      values: formData
    });
    return;
  }

  // Save to database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName!.trim(),
      formData.lastName!.trim(),
      formData.streetAddress!.trim(),
      formData.city!.trim(),
      formData.stateProvince!.trim(),
      formData.postalCode!.trim(),
      formData.country!.trim(),
      formData.email!.trim(),
      formData.phone!.trim()
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank you page with first name in query param
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.render('form', {
      errors: ['Failed to save your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Unknown Friend';
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {}
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`\nReceived ${signal}. Shutting down gracefully...`);
  
  if (server) {
    server.close(() => {
      console.log('HTTP server closed.');
      if (db) {
        db.close();
        console.log('Database closed.');
      }
      process.exit(0);
    });

    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Could not close connections in time, forcefully shutting down');
      if (db) {
        db.close();
      }
      process.exit(1);
    }, 10000);
  }
}

// Start server
let server: ReturnType<typeof app.listen>;
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  server = app.listen(PORT, () => {
    console.log(`🐶 VybePup's scammy form server running on port ${PORT}`);
  });

  // Handle graceful shutdown
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Handle uncaught exceptions
process.on('uncaughtException', (error: Error) => {
  console.error('Uncaught Exception:', error);
  if (db) db.close();
  process.exit(1);
});

process.on('unhandledRejection', (reason: unknown) => {
  console.error('Unhandled Rejection:', reason);
  if (db) db.close();
  process.exit(1);
});

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});