import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class FormDatabase {
  private db: any = null;
  private sqlJs: any = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = process.env.DB_PATH || './data/submissions.sqlite';
    this.schemaPath = process.env.SCHEMA_PATH || './db/schema.sql';
  }

  async initialize(): Promise<void> {
    // Initialize SQL.js with WASM files
    const SqlJsModule = await import('sql.js');
    const SqlJsConstructor = SqlJsModule.default;
    
    this.sqlJs = await SqlJsConstructor({
      locateFile: (file: string) => {
        // Use local WASM files from node_modules
        const localPath = join(process.cwd(), 'node_modules', 'sql.js', 'dist', file);
        return localPath;
      }
    });

    // Load existing database or create new one
    if (existsSync(this.dbPath)) {
      const dbFile = readFileSync(this.dbPath);
      this.db = new this.sqlJs.Database(dbFile);
    } else {
      this.db = new this.sqlJs.Database();
    }

    // Initialize schema
    this.initializeSchema();
  }

  private initializeSchema(): void {
    if (!this.db) throw new Error('Database not initialized');

    try {
      const schemaSql = readFileSync(this.schemaPath, 'utf8');
      this.db.exec(schemaSql);
    } catch (error) {
      console.error('Error initializing schema:', error);
      throw error;
    }
  }

  insertSubmission(data: ContactFormData): void {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.firstName,
      data.lastName,
      data.streetAddress,
      data.city,
      data.stateProvinceRegion,
      data.postalCode,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    this.saveDatabase();
  }

  private saveDatabase(): void {
    if (!this.db) return;

    const binaryDb = this.db.export();
    
    // Ensure data directory exists
    const dataDir = join(process.cwd(), 'data');
    
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }

    writeFileSync(this.dbPath, Buffer.from(binaryDb));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const formDatabase = new FormDatabase();