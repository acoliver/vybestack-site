import express, { Request, Response } from 'express';
import path from 'path';
import { formDatabase } from './database.js';
import { validateContactForm, ValidationResult } from './validation.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Configure EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    errors: [],
    formData: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validation: ValidationResult = validateContactForm(req);
  
  if (!validation.isValid) {
    // Re-render form with errors
    res.status(400).render('index', {
      errors: validation.errors,
      formData: req.body
    });
    return;
  }

  if (!validation.data) {
    res.status(400).render('index', {
      errors: [{ field: 'general', message: 'Invalid form data' }],
      formData: req.body
    });
    return;
  }

  try {
    // Insert submission into database
    formDatabase.insertSubmission(validation.data);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('index', {
      errors: [{ field: 'general', message: 'Server error. Please try again later.' }],
      formData: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Health check endpoint
app.get('/health', (req: Request, res: Response) => {
  res.json({ 
    status: 'healthy', 
    timestamp: new Date().toISOString(),
    port: PORT 
  });
});

// Graceful shutdown
function gracefulShutdown(signal: string) {
  console.log(`Received ${signal}. Shutting down gracefully...`);
  
  formDatabase.close();
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize database and start server
async function startServer() {
  try {
    await formDatabase.initialize();
    console.log('Database initialized successfully');
    
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
      console.log(`Health check: http://localhost:${PORT}/health`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export app for testing
export default app;

// Start server if this file is run directly
if (require.main === module) {
  startServer();
}
