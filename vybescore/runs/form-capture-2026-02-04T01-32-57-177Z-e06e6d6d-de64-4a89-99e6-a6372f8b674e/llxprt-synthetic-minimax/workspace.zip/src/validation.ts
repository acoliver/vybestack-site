import { Request } from 'express';

export interface ValidationError {
  field: string;
  message: string;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data?: FormData;
}

export function validateContactForm(req: Request): ValidationResult {
  const errors: ValidationError[] = [];
  
  // Extract form data from request body
  const data: FormData = {
    firstName: (req.body.firstName || '').trim(),
    lastName: (req.body.lastName || '').trim(),
    streetAddress: (req.body.streetAddress || '').trim(),
    city: (req.body.city || '').trim(),
    stateProvinceRegion: (req.body.stateProvinceRegion || '').trim(),
    postalCode: (req.body.postalCode || '').trim(),
    country: (req.body.country || '').trim(),
    email: (req.body.email || '').trim(),
    phone: (req.body.phone || '').trim()
  };

  // Required field validation
  const requiredFields: Array<keyof FormData> = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field]) {
      errors.push({
        field: field,
        message: `${formatFieldName(field)} is required`
      });
    }
  });

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (data.phone && !isValidPhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation (accept alphanumeric)
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    data: errors.length === 0 ? data : undefined
  };
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  return phoneRegex.test(phone.trim());
}

function isValidPostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (handle UK "SW1A 1AA", Argentine "C1000", etc.)
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  return postalRegex.test(postalCode.trim());
}

function formatFieldName(field: string): string {
  return field
    .replace(/([A-Z])/g, ' $1')
    .replace(/^./, str => str.toUpperCase())
    .replace(/([A-Z])/g, ' $1')
    .trim();
}