import { describe, it, beforeEach, afterEach } from 'mocha';
import { expect } from 'chai';
import fs from 'node:fs';
import path from 'node:path';
import { formDatabase } from '../../src/database';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  beforeEach(async () => {
    // Clean up database file before each test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Initialize database
    await formDatabase.initialize();
  });

  afterEach(async () => {
    // Clean up database file after each test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Close database connection
    formDatabase.close();
  });

  it('creates database and initializes schema', async () => {
    // Test that database can be initialized
    expect(formDatabase).to.be.an('object');
    
    // Verify database file is created with correct path
    const testDbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    
    // Clean database before test
    if (fs.existsSync(testDbPath)) {
      fs.unlinkSync(testDbPath);
    }
    
    // Re-initialize database
    await formDatabase.initialize();
    
    // Check if data directory and file exist
    const dataDir = path.dirname(testDbPath);
    expect(fs.existsSync(dataDir)).to.be.true;
    
    // Clean up
    if (fs.existsSync(testDbPath)) {
      fs.unlinkSync(testDbPath);
    }
  });

  it('has proper form structure in templates', async () => {
    // Test that form template exists and has required fields
    const formTemplatePath = path.resolve('views', 'index.ejs');
    expect(fs.existsSync(formTemplatePath)).to.be.true;
    
    const formTemplate = fs.readFileSync(formTemplatePath, 'utf8');
    
    // Check for required form fields in template
    expect(formTemplate).to.contain('name="firstName"');
    expect(formTemplate).to.contain('name="lastName"');
    expect(formTemplate).to.contain('name="streetAddress"');
    expect(formTemplate).to.contain('name="city"');
    expect(formTemplate).to.contain('name="stateProvinceRegion"');
    expect(formTemplate).to.contain('name="postalCode"');
    expect(formTemplate).to.contain('name="country"');
    expect(formTemplate).to.contain('name="email"');
    expect(formTemplate).to.contain('name="phone"');
  });

  it('has proper CSS styling', async () => {
    // Test that CSS file exists and has content
    const cssPath = path.resolve('public', 'styles.css');
    expect(fs.existsSync(cssPath)).to.be.true;
    
    const css = fs.readFileSync(cssPath, 'utf8');
    
    // Check for CSS content
    expect(css).to.contain('body');
    expect(css).to.contain('.container');
    expect(css).to.contain('.form-group');
  });

  it('creates thank you page template', async () => {
    // Test that thank you template exists
    const thankYouTemplatePath = path.resolve('views', 'thank-you.ejs');
    expect(fs.existsSync(thankYouTemplatePath)).to.be.true;
    
    const thankYouTemplate = fs.readFileSync(thankYouTemplatePath, 'utf8');
    
    // Check for thank you content
    expect(thankYouTemplate).to.contain('Thank You');
    expect(thankYouTemplate).to.contain('internet');
  });

  it('handles database persistence', async () => {
    // Test database insertion
    const testData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '456 Test Ave',
      city: 'Testville',
      stateProvinceRegion: 'TS',
      postalCode: 'T1234',
      country: 'Testland',
      email: 'test@example.com',
      phone: '+1 555-000-0000'
    };

    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Re-initialize database
    await formDatabase.initialize();
    
    // Insert test data
    formDatabase.insertSubmission(testData);
    
    // Verify database file was created and has content
    expect(fs.existsSync(dbPath)).to.be.true;
    
    // Clean up
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
  });
});
