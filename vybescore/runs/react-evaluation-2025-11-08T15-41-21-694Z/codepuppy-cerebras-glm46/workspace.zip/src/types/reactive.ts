/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  dependencies?: Set<SubjectR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observers: Set<ObserverR>
}

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Track the current observer during computation
let activeObserver: ObserverR | undefined
let currentDependencies: Set<SubjectR> | undefined

// Export functions to manipulate these directly
export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function setCurrentDependencies(deps: Set<SubjectR> | undefined): void {
  currentDependencies = deps
}

export function getCurrentDependencies(): Set<SubjectR> | undefined {
  return currentDependencies
}

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  const previousDependencies = currentDependencies
  
  console.log('updateObserver called for:', observer.name || 'unnamed')
  
  activeObserver = observer
  currentDependencies = new Set()
  
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    // Clear old dependencies and add new ones, but only if there are existing dependencies
    // This prevents clearing dependencies that were just established during initial setup
    console.log('Clearing old dependencies for:', observer.name || 'unnamed', 'old deps:', (observer as any).dependencies?.size || 0)
    if ((observer as any).dependencies && (observer as any).dependencies.size > 0) {
      for (const subject of (observer as any).dependencies) {
        console.log('Removing observer from subject:', subject.name || 'unnamed', 'observers before:', subject.observers.size)
        subject.observers.delete(observer)
        console.log('Removing observer from subject:', subject.name || 'unnamed', 'observers after:', subject.observers.size)
      }
    }
    
    (observer as any).dependencies = currentDependencies
    console.log('New dependencies for:', observer.name || 'unnamed', 'count:', currentDependencies.size)
    
    // Notify observers of this computed value
    if (observer.observers) {
      notifyObservers(observer.observers)
    }
    
    activeObserver = previous
    currentDependencies = previousDependencies
  }
}

export function addDependency(subject: SubjectR): void {
  if (currentDependencies && activeObserver) {
    currentDependencies.add(subject)
    subject.observers.add(activeObserver)
  }
}

export function notifyObservers(observers: Set<ObserverR>): void {
  for (const observer of observers) {
    updateObserver(observer as Observer<unknown>)
  }
}
