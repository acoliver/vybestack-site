/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  return (): T => {
    // If we're being called from another observer, this computed value is now a dependency
    const observer = getActiveObserver()
    if (observer) {
      // Add this observer to the computed value's observers
      o.observers.add(observer)
      console.log('Computed value', o.name || 'unnamed', 'adding observer', observer.name || 'unnamed', 'observers count:', o.observers.size)
      
      // Also add this computed value to the observer's dependencies
      if (!(observer as any).dependencies) {
        (observer as any).dependencies = new Set()
      }
      (observer as any).dependencies.add(o)
      console.log('Observer', observer.name || 'unnamed', 'adding dependency to computed', o.name || 'unnamed', 'deps count:', (observer as any).dependencies.size)
    }
    return o.value!
  }
}