/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, setActiveObserver, setCurrentDependencies, getCurrentDependencies } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    name: `callback-${Math.random().toString(36).substr(2, 9)}`,
    value,
    updateFn,
    observers: new Set(),
  }
  
  console.log('Creating callback:', observer.name)
  
  // Manually establish dependencies without the clearing behavior of updateObserver
  const previousObserver = getActiveObserver()
  const previousDeps = getCurrentDependencies()
  
  setActiveObserver(observer)
  setCurrentDependencies(new Set())
  
  try {
    // Execute the callback to establish dependencies
    observer.value = updateFn(value)
    
    // Store the dependencies that were established
    (observer as any).dependencies = getCurrentDependencies() || new Set()
    console.log('Callback', observer.name, 'dependencies after creation:', (observer as any).dependencies.size)
  } finally {
    // Restore previous state
    setActiveObserver(previousObserver)
    setCurrentDependencies(previousDeps)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    console.log('Unsubscribing callback:', observer.name, 'dependencies:', (observer as any).dependencies?.size || 0)
    
    // Remove this observer from all its dependencies
    if ((observer as any).dependencies) {
      for (const subject of (observer as any).dependencies) {
        console.log('Removing observer from subject', subject.name || 'unnamed', 'observers before:', subject.observers.size)
        subject.observers.delete(observer)
        console.log('Removing observer from subject', subject.name || 'unnamed', 'observers after:', subject.observers.size)
      }
    }
    
    // Mark as disposed to prevent further updates
    observer.updateFn = () => observer.value // No-op function
  }
}