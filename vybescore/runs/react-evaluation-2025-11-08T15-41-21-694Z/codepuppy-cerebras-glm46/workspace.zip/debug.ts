import { createInput, createComputed, createCallback } from './src/index.js'

// Test unsubscribe behavior
const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => {
  console.log('Callback 1 triggered, value:', output())
  values1.push(output())
})
const values2: number[] = []
createCallback(() => {
  console.log('Callback 2 triggered, value:', output())
  values2.push(output())
})

console.log('Setting input to 31')
setInput(31)
console.log('After setInput(31) - values1:', values1.length, 'values2:', values2.length)

console.log('Calling unsubscribe1')
unsubscribe1()
console.log('Setting input to 41')
setInput(41)
console.log('After setInput(41) - values1:', values1.length, 'values2:', values2.length)