import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Test 1: compute cells can depend on other compute cells ===')
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 32')

console.log('\nSetting input to 3...')
setInput(3)

console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())
console.log('Expected sum: 96')

console.log('\n=== Test 2: compute cells fire callbacks ===')
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => (value = output()))

console.log('input2:', input2())
console.log('output:', output())
console.log('value:', value)

console.log('\nSetting input2 to 3...')
setInput2(3)

console.log('input2:', input2())
console.log('output:', output())
console.log('value:', value)
console.log('Expected value: 4')

console.log('\n=== Test 3: callbacks can be added and removed ===')
const [input3, setInput3] = createInput(11)
const output3 = createComputed(() => input3() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => values1.push(output3()))
const values2: number[] = []
createCallback(() => values2.push(output3()))

console.log('values1.length:', values1.length)
console.log('values2.length:', values2.length)

console.log('\nSetting input3 to 31...')
setInput3(31)

console.log('values1:', values1)
console.log('values2:', values2)
console.log('values1.length:', values1.length)
console.log('values2.length:', values2.length)

console.log('\nCalling unsubscribe1...')
unsubscribe1()

console.log('\nSetting input3 to 41...')
setInput3(41)

console.log('values1:', values1)
console.log('values2:', values2)
console.log('values1.length:', values1.length)
console.log('values2.length:', values2.length)
console.log('Expected: values2.length > values1.length')
