import { createInput, createComputed, createCallback } from './src/index.js'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('Test 1: sum() should be 32, got', sum())
setInput(3)
console.log('Test 1: sum() should be 96, got', sum())

// Test 2: callbacks
const [input2, setInput2] = createInput(1)
const output = createComputed(() => input2() + 1)
let value = 0
createCallback(() => {
  console.log('  [callback called] output() =', output())
  value = output()
})
setInput2(3)
console.log('Test 2: value should be 4, got', value)
