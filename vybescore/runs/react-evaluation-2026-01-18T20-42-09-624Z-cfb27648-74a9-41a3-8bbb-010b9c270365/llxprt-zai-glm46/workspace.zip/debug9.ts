import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Minimal reproduction ===')

const [input, setInput] = createInput(1)

const comp = createComputed(() => {
  console.log('Computing...')
  return input() + 1
})

console.log('Initial: comp() =', comp())

let captured = 0
createCallback(() => {
  console.log('Callback running')
  captured = comp()
  console.log('Captured:', captured)
})

console.log('After callback creation: captured =', captured)

console.log('\nChanging input to 3...')
setInput(3)

console.log('After change: captured =', captured)
console.log('comp() =', comp())
