/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    // First try to get the observer from the reactive system
    let observer = getActiveObserver()
    
    // If that doesn't work, try the global fallback
    if (!observer) {
      observer = (globalThis as unknown as { __activeObserver?: Observer<unknown> }).__activeObserver
    }
    
    if (observer) {
      s.observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers that depend on this subject
    const observersCopy = new Set(s.observers)
    for (const observer of observersCopy) {
      if ('updateFn' in observer) {
        const obs = observer as Observer<unknown>
        updateObserver(obs)
      }
    }
    return s.value
  }

  return [read, write]
}
