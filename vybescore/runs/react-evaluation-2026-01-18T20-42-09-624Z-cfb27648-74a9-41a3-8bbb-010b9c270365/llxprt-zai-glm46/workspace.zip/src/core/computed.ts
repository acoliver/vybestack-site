/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  getActiveObserver,
  updateObserver,
  Subject,
  ObserverR,
  setActiveObserver,
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Track subjects that this computed depends on
  const dependencies = new Set<Subject<unknown>>()

  // Create a set to track observers that depend on this computed
  const dependents = new Set<ObserverR>()

  // The getter function - returns the cached value and tracks dependencies
  const read = (): T => {
    const activeObserver = getActiveObserver()
    
    // If another observer is accessing this computed, register it as a dependent
    if (activeObserver && activeObserver !== o) {
      dependents.add(activeObserver)
    }
    
    return o.value!
  }

  // Wrap the updateFn to handle dependency tracking
  const wrappedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    // Clear previous dependencies from this subject's observer sets
    for (const dep of dependencies) {
      dep.observers.delete(o)
    }
    dependencies.clear()
    
    // Set this computed as the active observer so dependencies can register it
    const previousActive = getActiveObserver()
    setActiveObserver(o)
    
    // Call the original update function which will access subjects
    // Those subjects will add this observer to their observers sets
    const result = updateFn(prevValue)
    
    setActiveObserver(previousActive)
    
    // Notify all dependents AFTER we've computed and cached the new value
    // But we need to update o.value first so that when dependents read from us, they get the new value
    o.value = result
    
    // Use notifyObservers utility to handle the notification properly
    // This handles type checking better since it works with ObserverR sets
    const observersSet = dependents as Set<ObserverR>
    const observersCopy = new Set(observersSet)
    for (const dependent of observersCopy) {
      if ('updateFn' in dependent) {
        const dep = dependent as Observer<unknown>
        try {
          updateObserver(dep)
        } catch (e) {
          // Ignore errors from disposed observers
        }
      }
    }
    
    return result
  }
  
  o.updateFn = wrappedUpdateFn

  // Initial computation
  updateObserver(o)

  return read
}
