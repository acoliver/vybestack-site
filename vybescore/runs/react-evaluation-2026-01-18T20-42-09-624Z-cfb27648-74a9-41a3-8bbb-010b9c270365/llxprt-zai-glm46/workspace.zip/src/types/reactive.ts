/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  _isComputing?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Prevent infinite recursion
  if (observer._isComputing) {
    return
  }
  
  const previous = activeObserver
  activeObserver = observer
  observer._isComputing = true
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
  } finally {
    observer._isComputing = false
    activeObserver = previous
  }
}

export function notifyObservers(observers: Set<ObserverR>): void {
  // Create a copy of the set to avoid issues if observers are modified during iteration
  const observersCopy = new Set(observers)
  
  for (const observer of observersCopy) {
    if ('updateFn' in observer) {
      const obs = observer as Observer<unknown>
      // Check if the updateFn is a no-op (indicates disposed callback)
      try {
        updateObserver(obs)
      } catch (e) {
        // Ignore errors from disposed observers
      }
    }
  }
}
