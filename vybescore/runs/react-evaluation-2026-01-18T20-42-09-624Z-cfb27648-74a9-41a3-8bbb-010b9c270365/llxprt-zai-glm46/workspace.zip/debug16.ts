import { createInput, createComputed } from './src/index.js'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('[timesTwo computed]')
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log('[timesThirty computed]')
  return input() * 30
})
const sum = createComputed(() => {
  console.log('[sum computed]')
  const two = timesTwo()
  const thirty = timesThirty()
  console.log('  two =', two, ', thirty =', thirty)
  return two + thirty
})

console.log('=== Initial state ===')
console.log('sum() =', sum())

console.log('\n=== Setting input to 3 ===')
setInput(3)

console.log('\n=== After update ===')
console.log('sum() =', sum())
