import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Testing callbacks with computed chain ===')

const [input, setInput] = createInput(1)

console.log('1. Creating computed chain...')
const timesTwo = createComputed(() => {
  console.log('   Computing timesTwo')
  return input() * 2
})

const plusTen = createComputed(() => {
  console.log('   Computing plusTen')
  return timesTwo() + 10
})

console.log('\n2. Creating callback...')
let callbackCount = 0
let lastValue = 0
createCallback(() => {
  console.log('   Executing callback')
  callbackCount++
  lastValue = plusTen()
  console.log('   Callback #' + callbackCount + ', value: ' + lastValue)
})

console.log('\n3. Initial state:')
console.log('   Callback was called', callbackCount, 'time(s)')
console.log('   Last value:', lastValue)

console.log('\n4. Changing input to 3...')
setInput(3)

console.log('\n5. After change:')
console.log('   Callback was called', callbackCount, 'time(s)')
console.log('   Last value:', lastValue)
console.log('   Expected: callbackCount=2, lastValue=16')
