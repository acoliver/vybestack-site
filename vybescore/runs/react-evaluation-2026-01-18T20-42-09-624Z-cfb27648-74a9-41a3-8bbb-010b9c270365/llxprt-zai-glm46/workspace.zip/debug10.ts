import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Debugging callback capture ===')

const [input, setInput] = createInput(1)

const comp = createComputed(() => {
  console.log('Computing comp...')
  return input() + 1
})

console.log('comp() =', comp())

let captured = 0
createCallback(() => {
  console.log('Callback running, about to call comp()')
  const val = comp()
  console.log('comp() returned', val)
  captured = val
  console.log('Captured:', captured)
})

console.log('\nAfter callback creation: captured =', captured)

console.log('\nChanging input to 3...')
setInput(3)

console.log('\nAfter change: captured =', captured)
console.log('Expected: captured = 4')
