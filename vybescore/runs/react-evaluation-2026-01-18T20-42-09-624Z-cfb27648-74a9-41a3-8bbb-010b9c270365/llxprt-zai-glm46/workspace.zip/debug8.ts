import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Testing what observers are registered ===')

const [input, setInput] = createInput(1)

console.log('1. Creating computed...')
const timesTwo = createComputed(() => {
  console.log('   Computing timesTwo')
  return input() * 2
})

console.log('\n2. Creating callback...')
let callbackValue = 0
const cb = createCallback(() => {
  console.log('   Executing callback')
  callbackValue = timesTwo()
})

console.log('\n3. Accessing computed getter...')
const val = timesTwo()
console.log('   timesTwo() =', val)

console.log('\n4. Changing input...')
setInput(5)

console.log('\n5. After change:')
console.log('   callbackValue =', callbackValue)
console.log('   timesTwo() =', timesTwo())
