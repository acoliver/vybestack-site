import { createInput, createComputed } from './src/index.ts'

console.log('=== Understanding the notification flow ===')

const [input, setInput] = createInput(1)

console.log('1. Creating timesTwo computed...')
const timesTwo = createComputed(() => {
  console.log('   Computing timesTwo, input() =', input())
  return input() * 2
})

console.log('2. Creating sum computed (depends on timesTwo)...')
const sum = createComputed(() => {
  console.log('   Computing sum, timesTwo() =', timesTwo())
  return timesTwo() + 10
})

console.log('\n3. Initial state:')
console.log('   sum() =', sum(), '(expected 12)')

console.log('\n4. Accessing timesTwo getter directly...')
const val = timesTwo()
console.log('   timesTwo() =', val, '(expected 2)')

console.log('\n5. Changing input to 5...')
setInput(5)

console.log('\n6. After setInput(5):')
console.log('   sum() =', sum(), '(expected 20)')
