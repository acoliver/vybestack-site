import { createInput, createComputed, createCallback } from './src/index.js'

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

console.log('input = 1:')
console.log('  input():', input())
console.log('  timesTwo():', timesTwo())
console.log('  timesThirty():', timesThirty())
console.log('  sum():', sum())
console.log('  Expected sum: 32')
console.log('  Match:', sum() === 32 ? 'YES' : 'NO')

console.log('\ninput = 3:')
setInput(3)
console.log('  input():', input())
console.log('  timesTwo():', timesTwo())
console.log('  timesThirty():', timesThirty())
console.log('  sum():', sum())
console.log('  Expected sum: 96')
console.log('  Match:', sum() === 96 ? 'YES' : 'NO')
