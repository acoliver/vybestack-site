import { createInput, createComputed } from './src/index.ts'

console.log('=== Debugging observer registration ===')

const [input, setInput] = createInput(1)

console.log('Creating computed...')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo, accessing input...')
  const val = input()
  console.log('  Got value from input:', val)
  return val * 2
})

console.log('\nInitial: timesTwo() =', timesTwo(), '(expected 2)')

console.log('\nSetting input to 5...')
setInput(5)

console.log('After change: timesTwo() =', timesTwo(), '(expected 10)')
