import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Debugging computed getter behavior ===')

const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo...')
  return input() * 2
})

const sum = createComputed(() => {
  console.log('  Computing sum...')
  return timesTwo() + 10
})

console.log('Initial computation:')
console.log('sum() =', sum())
console.log('Expected: 12 (1 * 2 + 10)')

console.log('\nChanging input to 5...')
setInput(5)

console.log('After change:')
console.log('sum() =', sum())
console.log('Expected: 20 (5 * 2 + 10)')

console.log('\nCalling sum() again without changing input:')
console.log('sum() =', sum())
console.log('Expected: 20 (should recompute)')
