import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Understanding the reactive flow ===')

const [input, setInput] = createInput(1)

console.log('1. Creating computed that depends on input...')
const timesTwo = createComputed(() => {
  console.log('   - Executing timesTwo updateFn')
  const result = input() * 2
  console.log('   - timesTwo result:', result)
  return result
})

console.log('\n2. Creating computed that depends on another computed...')
const plusTen = createComputed(() => {
  console.log('   - Executing plusTen updateFn')
  console.log('   - About to call timesTwo()')
  const result = timesTwo() + 10
  console.log('   - plusTen result:', result)
  return result
})

console.log('\n3. Initial values:')
console.log('   input:', input())
console.log('   timesTwo:', timesTwo())
console.log('   plusTen:', plusTen())

console.log('\n4. Creating callback that depends on plusTen...')
let callbackValue = 0
createCallback(() => {
  console.log('   - Executing callback')
  callbackValue = plusTen()
  console.log('   - callbackValue updated to:', callbackValue)
})

console.log('\n5. After creating callback:')
console.log('   callbackValue:', callbackValue)

console.log('\n6. Changing input to 5...')
setInput(5)

console.log('\n7. After setInput(5):')
console.log('   input:', input())
console.log('   timesTwo:', timesTwo())
console.log('   plusTen:', plusTen())
console.log('   callbackValue:', callbackValue)

console.log('\nExpected: callbackValue should be 20 (5 * 2 + 10)')
