import { createInput, createComputed } from './src/index.ts'

console.log('=== Debugging computed depending on computed ===')

const [input, setInput] = createInput(1)

console.log('Creating timesTwo...')
const timesTwo = createComputed(() => {
  console.log('  Computing timesTwo...')
  return input() * 2
})

console.log('Creating sum (depends on timesTwo)...')
const sum = createComputed(() => {
  console.log('  Computing sum...')
  console.log('    Calling timesTwo()...')
  const result = timesTwo() + 10
  console.log('    Got result from timesTwo:', result - 10)
  return result
})

console.log('\nInitial: sum() =', sum(), '(expected 12)')

console.log('\nSetting input to 5...')
setInput(5)

console.log('After change: sum() =', sum(), '(expected 20)')
