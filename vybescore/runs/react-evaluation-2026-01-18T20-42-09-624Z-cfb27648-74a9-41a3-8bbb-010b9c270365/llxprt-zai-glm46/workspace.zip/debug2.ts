import { createInput, createComputed, createCallback } from './src/index.ts'

console.log('=== Debugging callback unsubscribe ===')
const [input, setInput] = createInput(11)
const output = createComputed(() => input() + 1)

const values1: number[] = []
const unsubscribe1 = createCallback(() => values1.push(output()))
const values2: number[] = []
createCallback(() => values2.push(output()))

console.log('Initial values1:', values1)
console.log('Initial values2:', values2)

console.log('\nSetting input to 31...')
setInput(31)

console.log('After setInput(31) values1:', values1)
console.log('After setInput(31) values2:', values2)

console.log('\nCalling unsubscribe1...')
unsubscribe1()

console.log('\nSetting input to 41...')
setInput(41)

console.log('After setInput(41) values1:', values1)
console.log('After setInput(41) values2:', values2)

console.log('\nExpected: values2.length > values1.length')
console.log('Actual: values2.length =', values2.length, ', values1.length =', values1.length)
