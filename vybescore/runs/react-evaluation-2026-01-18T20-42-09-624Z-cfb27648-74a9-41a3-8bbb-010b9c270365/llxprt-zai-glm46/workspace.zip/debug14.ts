import { createInput, createComputed, createCallback } from './src/index.js'

const [input, setInput] = createInput(1)

console.log('Creating timesTwo...')
const timesTwo = createComputed(() => input() * 2)

console.log('Creating timesThirty...')
const timesThirty = createComputed(() => input() * 30)

console.log('Creating sum...')
const sum = createComputed(() => {
  console.log('  [sum computed called]')
  const twoVal = timesTwo()
  const thirtyVal = timesThirty()
  console.log('  timesTwo() =', twoVal, ', timesThirty() =', thirtyVal)
  return twoVal + thirtyVal
})

console.log('\n--- input = 1 ---')
console.log('input():', input())
console.log('timesTwo():', timesTwo())
console.log('timesThirty():', timesThirty())
console.log('sum():', sum())

console.log('\n--- Changing input to 3 ---')
setInput(3)

console.log('\n--- After update ---')
console.log('input():', input())
console.log('timesTwo():', timesTwo())
console.log('timesThirty():', timesThirty())
console.log('sum():', sum())
console.log('Expected: 96, Got:', sum())
