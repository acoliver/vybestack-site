#!/usr/bin/env node

import fs from 'node:fs';
import path from 'node:path';
import type { ReportData, RenderOptions } from '../types.js';
import { formatters, getSupportedFormats } from '../formats/index.js';

interface CliArgs {
  inputFile: string;
  format: string;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1];
  const outputIndex = args.indexOf('--output');
  const outputFile = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  return {
    inputFile,
    format,
    outputFile,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: title is required and must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: summary is required and must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: entries is required and must be an array');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry ${i} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i} label is required and must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry ${i} amount is required and must be a number`);
    }
  }
  
  return obj as unknown as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const absolutePath = path.resolve(filePath);
    const fileContent = fs.readFileSync(absolutePath, 'utf-8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = parseArgs();
    
    // Validate format
    if (!getSupportedFormats().includes(args.format)) {
      throw new Error(`Unsupported format: ${args.format}. Supported formats: ${getSupportedFormats().join(', ')}`);
    }
    
    // Load and validate data
    const reportData = loadReportData(args.inputFile);
    
    // Render report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };
    
    const renderer = formatters[args.format];
    const output = renderer(reportData, options);
    
    // Write output
    if (args.outputFile) {
      fs.writeFileSync(args.outputFile, output, 'utf-8');
      console.log(`Report written to ${args.outputFile}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}