import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type Renderer = (data: ReportData, options?: RenderOptions) => string;

export const formatters: Record<string, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getSupportedFormats(): string[] {
  return Object.keys(formatters);
}