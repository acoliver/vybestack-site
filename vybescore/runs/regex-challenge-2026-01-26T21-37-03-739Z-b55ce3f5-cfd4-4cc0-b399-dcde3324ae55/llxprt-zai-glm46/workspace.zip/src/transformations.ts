/**
 * Capitalize the first character of each sentence.
 * Insert one space between sentences, collapse extra spaces, preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Split on sentence-ending punctuation (. ! ?) followed by optional space and lowercase
  // Use a regex that preserves the delimiters
  let result = '';
  let sentenceStart = true;
  let i = 0;

  while (i < text.length) {
    const char = text[i];

    if (sentenceStart) {
      // Skip whitespace at start of sentence
      if (/\s/.test(char)) {
        result += char;
        i++;
        continue;
      }

      // Capitalize first letter
      if (char !== char.toUpperCase()) {
        result += char.toUpperCase();
      } else {
        result += char;
      }
      sentenceStart = false;
      i++;
      continue;
    }

    // Check for sentence end
    if (char === '.' || char === '!' || char === '?') {
      result += char;

      // Look ahead for whitespace
      let j = i + 1;
      let hasSpace = false;
      while (j < text.length && /\s/.test(text[j])) {
        if (text[j] === ' ') hasSpace = true;
        j++;
      }

      // Add single space after punctuation
      result += ' ';

      // Skip to next non-whitespace
      i = j;

      // Check if this might be an abbreviation (e.g., "Dr.", "Mr.", "U.S.A.")
      // Look at the word before the punctuation
      const beforeSentence = result.substring(0, result.length - 2).trim();
      const lastWord = beforeSentence.split(/\s+/).pop() || '';

      // Common abbreviations that don't end sentences
      const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St', 'etc', 'vs', 'U.S.A', 'U.K', 'U.S', 'E.U', 'U.N'];

      // Check if last word ends with a dot and is an abbreviation
      const isAbbreviation = abbreviations.some(abbr => {
        const abbrWithDot = abbr + '.';
        return lastWord.endsWith(abbrWithDot) || lastWord === abbrWithDot;
      });

      // Also check for single letter followed by dot (like middle initials)
      const isSingleLetter = /^[A-Z]\.$/.test(lastWord);

      // If it's an abbreviation or single letter, don't capitalize next word
      if (isAbbreviation || isSingleLetter) {
        // Remove the space we just added if the original didn't have one
        if (!hasSpace) {
          result = result.slice(0, -1);
        }
        sentenceStart = false;
      } else {
        sentenceStart = true;
      }

      continue;
    }

    // Collapse multiple spaces into one
    if (char === ' ' && i > 0 && text[i - 1] === ' ') {
      i++;
      continue;
    }

    result += char;
    i++;
  }

  // Trim trailing whitespace
  result = result.trim();

  return result;
}

/**
 * Find all URLs in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // URL pattern: protocol://domain/path?query#fragment
  // Match http, https, ftp, ftps
  const urlRegex = /(https?:\/\/|ftp:\/\/|ftps:\/\/)?[a-zA-Z0-9][a-zA-Z0-9-]*(\.[a-zA-Z0-9][a-zA-Z0-9-]*)+([/?][^\s]*)?/gi;

  const matches: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];

    // Remove trailing punctuation (. , ; : ! ?)
    url = url.trim();
    while (url.length > 0 && /[.,;:!?]$/.test(url)) {
      url = url.slice(0, -1);
    }

    // Remove trailing parentheses (if not part of URL)
    while (url.length > 0 && url.endsWith(')')) {
      url = url.slice(0, -1);
    }

    // Must have at least a domain with a dot
    if (url.includes('.') && url.length > 7) {
      // Add protocol if missing for http/https URLs
      if (!url.match(/^[a-zA-Z][a-zA-Z0-9+.-]*:\/\//)) {
        if (url.startsWith('www.') || url.includes('.') && !url.includes('://')) {
          url = 'http://' + url;
        }
      }
      matches.push(url);
    }
  }

  return matches;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Replace http:// with https://, but not https://
  // Use negative lookbehind to avoid replacing https twice
  const result = text.replace(/(?<!:)http:\/\//g, 'https://');

  return result;
}

/**
 * Rewrite http://example.com/... URLs to https://...
 * When path begins with /docs/, rewrite host to docs.example.com
 * Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Match http://example.com/... URLs
  // We need to carefully handle various cases

  const urlPattern = /(https?:\/\/)([^/\s]+)([/?][^\s]*)?/gi;

  const result = text.replace(urlPattern, (match, protocol, host, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https://';

    // Check if this is an example.com URL
    const isExampleCom = host === 'example.com' || host.startsWith('example.com:');

    if (isExampleCom && path) {
      // Check for dynamic hints that should prevent host rewrite
      const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');
      const hasCgiBin = path.includes('/cgi-bin/');
      const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|$|\?|#)/i.test(path);

      if (!hasQueryString && !hasCgiBin && !hasLegacyExtension) {
        // Check if path starts with /docs/
        if (path.startsWith('/docs/') || path === '/docs') {
          // Rewrite host to docs.example.com
          const newHost = 'docs.example.com';
          return newProtocol + newHost + path;
        }
      }
    }

    // Just upgrade the protocol
    return newProtocol + host + path;
  });

  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or date is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) return 'N/A';

  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];

  // Validate month
  if (month < 1 || month > 12) return 'N/A';

  // Validate day
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';

  // Basic year validation
  const yearNum = parseInt(year, 10);
  if (yearNum < 1900 || yearNum > 2100) return 'N/A';

  // Special check for February in non-leap years
  if (month === 2 && day === 29) {
    // Check if leap year
    const isLeap = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeap) return 'N/A';
  }

  return year;
}
