export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name@tag@example.co.uk.
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Basic structure: local@domain
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(value)) return false;

  // Reject double dots (..) anywhere
  if (/\.\./.test(value)) return false;

  // Reject trailing dots in local part or domain
  if (/@\./.test(value) || /\.$/.test(value)) return false;

  // Reject leading dots in local part
  if (/^\./.test(value)) return false;

  // Reject underscores in domain
  const [local, domain] = value.split('@');
  if (domain.includes('_')) return false;

  // Domain must have at least one dot and valid TLD (2+ chars)
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;

  // Local part should not be empty and can contain common characters
  // Allow: letters, digits, dots, hyphens, plus, underscore
  const localRegex = /^[a-zA-Z0-9][a-zA-Z0-9._+-]*[a-zA-Z0-9]$/;
  if (!localRegex.test(local) && local.length > 1) {
    // Single character local part is valid
    if (local.length === 1 && !/^[a-zA-Z0-9]$/.test(local)) return false;
    if (local.length > 1) return false;
  }

  // Domain parts should be valid
  for (const part of domainParts) {
    if (part.length === 0) return false;
    // Domain parts can contain letters, digits, hyphens (but not start/end with hyphen)
    if (!/^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(part)) return false;
  }

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890.
 * Optional +1 prefix. Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Extract digits only
  const digits = value.replace(/\D/g, '');

  // Check for optional +1 country code
  let phoneDigits = digits;

  // Must have 10 digits (standard US number) or 11 with leading 1
  if (phoneDigits.length === 11 && phoneDigits.startsWith('1')) {
    phoneDigits = phoneDigits.substring(1);
  } else if (phoneDigits.length === 10) {
    // Standard 10-digit number
  } else {
    return false;
  }

  if (phoneDigits.length !== 10) return false;

  // Area code cannot start with 0 or 1
  const areaCode = phoneDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Exchange code (second 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneDigits.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;

  // Validate format with optional +1 prefix
  // Accept: (212) 555-7890, 212-555-7890, 2125557890, +1 212 555 7890
  const patterns = [
    /^\+1\s*\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/, // +1 (212) 555-7890
    /^\+1\s*\d{3}[-\s]?\d{3}[-\s]?\d{4}$/, // +1 212-555-7890
    /^\(\d{3}\)\s*\d{3}[-\s]?\d{4}$/, // (212) 555-7890
    /^\d{3}[-\s]\d{3}[-\s]\d{4}$/, // 212-555-7890
    /^\d{10}$/, // 2125557890
  ];

  // Check if the original value matches any valid pattern
  const testValue = value.trim();
  for (const pattern of patterns) {
    if (pattern.test(testValue)) {
      return true;
    }
  }

  return false;
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Extract digits only
  const digits = value.replace(/\D/g, '');

  // Check for country code +54
  const hasCountryCode = digits.startsWith('54');

  let workingDigits = digits;

  if (hasCountryCode) {
    workingDigits = digits.substring(2);
  } else {
    // Without country code, must start with 0 (trunk prefix)
    if (!workingDigits.startsWith('0')) return false;
    workingDigits = workingDigits.substring(1);
  }

  // Check for mobile indicator 9 (after country code if present)
  if (workingDigits.startsWith('9')) {
    workingDigits = workingDigits.substring(1);
  }

  // Now workingDigits should have: area code (2-4 digits) + subscriber (6-8 digits)
  // Total should be 8-12 digits
  if (workingDigits.length < 8 || workingDigits.length > 12) return false;

  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCode = '';
  let subscriber = '';

  // Try to determine area code length
  if (workingDigits.length >= 10) {
    // Likely 4-digit area code
    areaCode = workingDigits.substring(0, 4);
    subscriber = workingDigits.substring(4);
  } else if (workingDigits.length >= 9) {
    // Likely 3-digit area code
    areaCode = workingDigits.substring(0, 3);
    subscriber = workingDigits.substring(3);
  } else {
    // 2-digit area code
    areaCode = workingDigits.substring(0, 2);
    subscriber = workingDigits.substring(2);
  }

  // Validate area code
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] < '1' || areaCode[0] > '9') return false;

  // Validate subscriber number
  if (subscriber.length < 6 || subscriber.length > 8) return false;

  // Additional format validation
  // Accept formats: +54 9 11 1234 5678, +54 341 123 4567, 011 1234 5678, 0341 4234567
  const patterns = [
    /^\+54\s+9\s+\d{2,4}\s+\d{4}\s+\d{4}$/, // +54 9 11 1234 5678
    /^\+54\s+\d{3}\s+\d{3}\s+\d{4}$/, // +54 341 123 4567
    /^0\d{2,3}\s+\d{4}\s+\d{4}$/, // 011 1234 5678
    /^0\d{3,4}\s?\d{6,8}$/, // 0341 4234567
    /^\+54\s+\d{2,4}\s+\d{4,8}$/, // +54 341 1234567
  ];

  const testValue = value.trim();
  for (const pattern of patterns) {
    if (pattern.test(testValue)) {
      return true;
    }
  }

  // Also accept without strict format if digits are valid
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  if (value.trim().length === 0) return false;

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols (except apostrophe/hyphen), and multiple consecutive special chars
  const nameRegex = /^[\p{L}\p{M}][\p{L}\p{M}'\-\s]*[\p{L}\p{M}]$/u;

  if (!nameRegex.test(value.trim())) {
    // Allow single character names
    const singleCharRegex = /^[\p{L}\p{M}]$/u;
    if (!singleCharRegex.test(value.trim())) {
      return false;
    }
  }

  // Reject digits
  if (/\d/.test(value)) return false;

  // Reject common symbols (except apostrophe and hyphen)
  const invalidSymbols = /[!"#$%&()*+,./:;<=>?@[\\\]^_`{|}~]/;
  if (invalidSymbols.test(value)) return false;

  // Reject multiple consecutive spaces or hyphens or apostrophes
  if (/\s{2,}/.test(value)) return false;
  if (/-{2,}/.test(value)) return false;
  if (/'{2,}/.test(value)) return false;

  // Reject names with special character sequences like Æ
  // This is tricky - Æ is a valid letter in some languages
  // But X Æ A-12 should be rejected because of the digit
  if (/\d/.test(value)) return false;

  // Reject starting or ending with space, hyphen, or apostrophe
  if (/^[\s'-]/.test(value) || /[\s'-]$/.test(value)) return false;

  return true;
}

/**
 * Luhn algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  if (digits.length < 13) return false;

  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Extract digits only
  const digits = value.replace(/\D/g, '');

  // Check length: Visa/MC are 13-16 digits, AmEx is 15 digits
  if (digits.length < 13 || digits.length > 16) return false;

  // Check prefix and length combinations
  let isValid = false;

  // Visa: starts with 4, length 13-16
  if (/^4/.test(digits) && digits.length >= 13 && digits.length <= 16) {
    isValid = true;
  }

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if ((/^5[1-5]/.test(digits) || /^2[2-7][0-9]{2}/.test(digits)) && digits.length === 16) {
    isValid = true;
  }

  // American Express: starts with 34 or 37, length 15
  if (/^3[47]/.test(digits) && digits.length === 15) {
    isValid = true;
  }

  if (!isValid) return false;

  // Run Luhn check
  return runLuhnCheck(digits);
}
