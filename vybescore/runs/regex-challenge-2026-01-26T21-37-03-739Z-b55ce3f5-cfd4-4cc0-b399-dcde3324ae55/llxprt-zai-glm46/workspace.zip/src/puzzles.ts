/**
 * Find words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];

  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match whole words starting with prefix
  const wordPattern = new RegExp(`\\b(${escapedPrefix}[a-zA-Z]*)\\b`, 'gi');
  const matches: string[] = [];

  let match: RegExpExecArray | null;
  while ((match = wordPattern.exec(text)) !== null) {
    const word = match[1];

    // Check if word is in exceptions list (case-insensitive)
    const isException = exceptions.some(ex =>
      ex.toLowerCase() === word.toLowerCase()
    );

    if (!isException && !matches.includes(word)) {
      matches.push(word);
    }
  }

  return matches;
}

/**
 * Find occurrences of a token only when it appears after a digit and not at string start.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];

  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match digit + token, but not at start of string
  // Use word boundary to ensure we're matching complete tokens
  const pattern = new RegExp(`\\b\\d${escapedToken}\\b`, 'g');

  const matches: string[] = [];
  let match: RegExpExecArray | null;

  while ((match = pattern.exec(text)) !== null) {
    matches.push(match[0]);
  }

  return matches;
}

/**
 * Validate passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  if (value.length < 10) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;

  // Check for at least one digit
  if (!/\d/.test(value)) return false;

  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;

  // Check for immediate repeated sequences (e.g., abab, 1212)
  // This looks for patterns where a 2-4 character sequence repeats immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const seq1 = value.substring(i, i + len);
      const seq2 = value.substring(i + len, i + 2 * len);
      if (seq1 === seq2) {
        return false;
      }
    }
  }

  // Check for longer repeated patterns (e.g., abcabc)
  for (let len = 2; len <= 3; len++) {
    const repeatedPattern = new RegExp(`^(.{${len}})\\1+$`);
    if (repeatedPattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::).
 * Ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // IPv6 patterns:
  // Full form: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can replace one or more consecutive groups of zeros

  // First, exclude IPv4 addresses
  // IPv4: 4 groups of 1-3 digits, 0-255, separated by dots
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;

  if (ipv4Pattern.test(value)) {
    // Check if this is actually an IPv6 address (IPv6 can contain embedded IPv4)
    // For now, if it matches IPv4 pattern, we need to check for IPv6 syntax too
  }

  // IPv6 patterns
  // Full IPv6: 8 groups of hex digits
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;

  // IPv6 with :: shorthand (compressed)
  const ipv6Compressed = /(?:[0-9a-fA-F]{1,4}:)*:(?::[0-9a-fA-F]{1,4})*/;

  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6EmbeddedIPv4 =
    /(?:[0-9a-fA-F]{1,4}:)*:(?::[0-9a-fA-F]{1,4})*:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)/;

  // Check for IPv6 patterns
  if (ipv6Full.test(value) || ipv6Compressed.test(value) || ipv6EmbeddedIPv4.test(value)) {
    // Make sure it's not just an IPv4 address
    // Extract potential IPv6 addresses and verify they have colons
    const potentialIPv6 = value.match(/[[0-9a-fA-F:]+/g);
    if (potentialIPv6) {
      for (const candidate of potentialIPv6) {
        // Must contain colons for IPv6
        if (candidate.includes(':') && candidate.split(':').length >= 2) {
          // Not a pure IPv4 address
          if (!ipv4Pattern.test(candidate) || candidate.includes('::')) {
            return true;
          }
        }
      }
    }
  }

  // More specific IPv6 detection
  // Look for patterns with multiple colons or ::
  const hasIPv6Syntax = /::|[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/;

  if (hasIPv6Syntax.test(value)) {
    // Verify it's actually IPv6 and not something else
    const candidates = value.match(/[0-9a-fA-F:]+/g);
    if (candidates) {
      for (const candidate of candidates) {
        // Must have at least 2 colons or :: for IPv6
        if ((candidate.includes(':') && candidate.split(':').length >= 3) || candidate.includes('::')) {
          return true;
        }
      }
    }
  }

  return false;
}
