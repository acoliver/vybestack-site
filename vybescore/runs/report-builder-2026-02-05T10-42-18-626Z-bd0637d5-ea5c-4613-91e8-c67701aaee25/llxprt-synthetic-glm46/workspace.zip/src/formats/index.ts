import { ReportRenderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export const renderers: Record<string, ReportRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export function getSupportedFormats(): string[] {
  return Object.keys(renderers);
}