import { ReportRenderer } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export const renderMarkdown: ReportRenderer = (data, options) => {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries heading
  lines.push('## Entries');

  // Entries list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(``);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};