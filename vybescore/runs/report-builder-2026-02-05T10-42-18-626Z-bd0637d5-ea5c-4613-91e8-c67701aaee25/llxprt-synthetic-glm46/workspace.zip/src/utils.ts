import { ReportEntry } from './types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}