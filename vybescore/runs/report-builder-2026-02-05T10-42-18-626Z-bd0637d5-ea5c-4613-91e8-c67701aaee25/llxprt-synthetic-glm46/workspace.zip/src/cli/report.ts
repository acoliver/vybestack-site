#!/usr/bin/env node

import fs from 'node:fs';
import { renderers, getSupportedFormats } from '../formats/index.js';
import { loadReportData } from '../validation.js';

function parseArguments(): { dataFile: string; format: string; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const formatFlagIndex = args.indexOf('--format');
  
  if (formatFlagIndex === -1 || formatFlagIndex + 1 >= args.length) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  const format = args[formatFlagIndex + 1];
  const outputFlagIndex = args.indexOf('--output');
  const outputPath = outputFlagIndex !== -1 && outputFlagIndex + 1 < args.length ? args[outputFlagIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');

  return { dataFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments();

    if (!getSupportedFormats().includes(format)) {
      console.error(`Error: Unsupported format "${format}". Supported formats: ${getSupportedFormats().join(', ')}`);
      process.exit(1);
    }

    const reportData = loadReportData(dataFile);
    const renderer = renderers[format];
    const output = renderer(reportData, { includeTotals });

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf8');
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();
