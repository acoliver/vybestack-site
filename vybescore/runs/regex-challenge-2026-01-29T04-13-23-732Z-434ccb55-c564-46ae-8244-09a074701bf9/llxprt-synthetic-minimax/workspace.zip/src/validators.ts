export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to validate credit card numbers using Luhn checksum
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Must have @ symbol, valid local part, domain with at least 2 chars TLD
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for double dots and trailing dots
  if (value.includes('..') || value.endsWith('.') || value.includes('@.')) {
    return false;
  }
  
  // Check domain doesn't contain underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digits except leading + for country code
  let cleaned = value.trim();
  
  // Check for leading +1
  let hasCountryCode = false;
  if (cleaned.startsWith('+1')) {
    hasCountryCode = true;
    cleaned = cleaned.substring(2).trim();
  } else if (cleaned.startsWith('+')) {
    // Other country codes not allowed for US format
    return false;
  }
  
  // Remove all non-digits
  const digitsOnly = cleaned.replace(/\D/g, '');
  
  // Must be 10 digits without country code, or 11 with country code
  if (hasCountryCode) {
    if (digitsOnly.length !== 11 || digitsOnly[0] !== '1') {
      return false;
    }
  } else {
    if (digitsOnly.length !== 10) {
      return false;
    }
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const startIndex = hasCountryCode ? 1 : 0;
  const areaCode = digitsOnly.substring(startIndex, startIndex + 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate the actual format with regex to ensure proper separators
  // Allow: (xxx) xxx-xxxx, xxx-xxx-xxxx, xxxxxxxxxx, xxx.xxx.xxxx
  const phoneRegex = /^(\+?1[\s.-]?)?\(?([2-9][0-9]{2})\)?[\s.-]?([2-9][0-9]{2})[\s.-]?([0-9]{4})$/;
  
  if (!phoneRegex.test(value.trim())) {
    // Also allow plain digits format
    const plainDigitsRegex = /^(\+?1)?[2-9][0-9]{2}[2-9][0-9]{2}[0-9]{4}$/;
    if (!plainDigitsRegex.test(value.trim())) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Extract components
  let temp = value.trim();
  
  // Check for optional country code +54
  let hasCountryCode = false;
  if (temp.startsWith('+54')) {
    hasCountryCode = true;
    temp = temp.substring(3).trim();
  }
  
  // Check for optional mobile indicator 9 (only if country code present)
  if (hasCountryCode && temp.startsWith('9')) {
    temp = temp.substring(1).trim();
  } else if (!hasCountryCode && temp.startsWith('9')) {
    return false; // 9 without country code is invalid
  }
  
  // Check for trunk prefix 0 (must be present if no country code)
  if (temp.startsWith('0')) {
    temp = temp.substring(1).trim();
  } else if (!hasCountryCode) {
    return false; // Trunk prefix required when no country code
  }
  
  // Now temp should start with area code (2-4 digits, first digit 1-9)
  const areaCodeMatch = temp.match(/^([1-9][0-9]{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const remainingTemp = temp.substring(areaCode.length).trim();
  
  // Remove any separators (spaces, hyphens) for remaining digits count
  const remainingDigits = remainingTemp.replace(/[\s-]/g, '');
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Check area code first digit (1-9)
  if (areaCode[0] < '1' || areaCode[0] > '9') {
    return false;
  }
  
  // Remaining digits (subscriber number) should be 6-8 total without area code
  const subscriberDigits = remainingDigits.length;
  
  // Subscriber number (excluding area code) should be 6-8 digits
  if (subscriberDigits < 6 || subscriberDigits > 8) {
    return false;
  }
  
  // Validate that the remaining part contains only digits, spaces, and hyphens
  const subscriberPattern = /^[\d\s-]*[\d\s-]$/;
  if (!subscriberPattern.test(remainingTemp)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u024F]/.test(value)) {
    return false;
  }
  
  // Check for digits or symbols (reject X Æ A-12 style names)
  if (/[0-9!@#$%^&*()_+\-=[\]{};':"\\|,.<>/]/.test(value.replace(/[\s\-\u2013\u2014']/g, ''))) {
    return false;
  }
  
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Pattern allows letters from various languages, spaces, hyphens, apostrophes
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must not be empty or just spaces
  if (value.trim().length === 0) {
    return false;
  }
  
  // Minimum length check (at least 2 characters for a name)
  if (value.trim().length < 2) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits
  const cardNumber = value.replace(/\D/g, '');
  
  // Check minimum length (13 for Visa/Mastercard/AmEx)
  if (cardNumber.length < 13) {
    return false;
  }
  
  // Check maximum length (19 is typical maximum)
  if (cardNumber.length > 19) {
    return false;
  }
  
  // Check prefixes for major card types
  // Visa: 4xxxx
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34xx, 37xx
  let isValidPrefix = false;
  
  // Visa (13, 16, 19 digits)
  if (cardNumber.length === 13 || cardNumber.length === 16 || cardNumber.length === 19) {
    if (cardNumber.startsWith('4')) {
      isValidPrefix = true;
    }
  }
  
  // Mastercard (16 digits)
  if (cardNumber.length === 16) {
    const prefix2 = parseInt(cardNumber.substring(0, 2), 10);
    const prefix4 = parseInt(cardNumber.substring(0, 4), 10);
    
    if ((prefix2 >= 51 && prefix2 <= 55) || (prefix4 >= 2221 && prefix4 <= 2720)) {
      isValidPrefix = true;
    }
  }
  
  // AmEx (15 digits)
  if (cardNumber.length === 15) {
    if (cardNumber.startsWith('34') || cardNumber.startsWith('37')) {
      isValidPrefix = true;
    }
  }
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cardNumber);
}
