/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // Split on sentence endings (.?!), preserving the delimiters
  const sentences = text.match(/[^.!?]+[.!?]*/g) || [];
  
  // Process each sentence
  const processedSentences = sentences.map(sentence => {
    // Trim leading spaces but preserve the sentence structure
    const trimmed = sentence.trim();
    if (trimmed.length === 0) {
      return sentence; // Keep empty parts as-is
    }
    
    // Capitalize the first letter
    return trimmed.charAt(0).toUpperCase() + trimmed.slice(1);
  });
  
  // Join with exactly one space between sentences
  return processedSentences.join(' ');
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs including http/https and www variants
  // Remove trailing punctuation like .,!?;:()
  const urlRegex = /(?:https?:\/\/|www\.)[^\s<>"')\]]*[^\s<>"'),.!?:;)]/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up trailing punctuation from each URL
  const cleanUrls = matches.map(url => {
    let cleanUrl = url;
    
    // Remove trailing punctuation while being careful not to remove valid URL parts
    while (cleanUrl.length > 0 && /[.,!?;:)}]/.test(cleanUrl.charAt(cleanUrl.length - 1))) {
      cleanUrl = cleanUrl.slice(0, -1);
    }
    
    return cleanUrl;
  });
  
  return cleanUrls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while preserving the rest of the URL
  // Use word boundaries to avoid replacing partial matches
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Regex to match http:// URLs with various patterns
  const urlRegex = /http:\/\/[^\s<>"']+/gi;
  
  return text.replace(urlRegex, (match) => {
    // Always upgrade http to https
    let rewritten = match.replace(/^http:\/\//i, 'https://');
    
    // Check if this is a docs path that needs host rewriting
    const docsPathRegex = /^https:\/\/[^/]+(\/docs\/)/i;
    const hasDocsPath = docsPathRegex.test(rewritten);
    
    if (hasDocsPath) {
      // Check for dynamic hints or legacy extensions
      const dynamicExtensions = /(cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)|\?|&|=)/i;
      const hasDynamicHints = dynamicExtensions.test(rewritten);
      
      if (!hasDynamicHints) {
        // Replace the host with docs.example.com
        rewritten = rewritten.replace(/^https:\/\/[^/]+/i, 'https://docs.example.com');
      }
    }
    
    return rewritten;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check basic mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check for leap year in February
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (isLeapYear && day > 29) {
      return 'N/A';
    } else if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  }
  
  // Check day range for other months
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return match[3]; // Return the year part
}
