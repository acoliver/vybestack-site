/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  // Use word boundary to ensure we match complete words
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const filteredMatches = matches.filter(word => 
    !exceptionsLower.includes(word.toLowerCase())
  );
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use regex to match token that comes immediately after a digit (not at string start)
  // Pattern: (?<!^) ensures not at start, then digit followed by token
  const embedRegex = new RegExp(`(?<!^)\\d${escapedToken}[a-zA-Z]*`, 'gi');
  
  // Find matches for the pattern (returns full matches including digit)
  const matches = text.match(embedRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check requirements: one uppercase, one lowercase, one digit, one symbol
  const checks = {
    hasUppercase: /[A-Z]/.test(value),
    hasLowercase: /[a-z]/.test(value),
    hasDigit: /[0-9]/.test(value),
    hasSymbol: /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/]/.test(value)
  };
  
  if (!checks.hasUppercase || !checks.hasLowercase || !checks.hasDigit || !checks.hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // Look for patterns like "abab", "123123", etc.
  for (let i = 0; i < value.length - 3; i++) {
    const substring = value.substring(i, i + 4);
    // Check if the first two characters repeat immediately
    if (substring.length >= 4) {
      const part1 = substring.substring(0, 2);
      const part2 = substring.substring(2, 4);
      if (part1 === part2) {
        return false;
      }
    }
  }
  
  // Additional check for longer immediate repetitions
  for (let i = 0; i < value.length - 2; i++) {
    const char = value[i];
    if (value[i + 1] === char && value[i + 2] === char) {
      return false; // Three consecutive same characters
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this looks like an IPv4 address (x.x.x.x pattern)
  // If it matches IPv4 pattern, it's definitely not IPv6
  const ipv4Regex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // IPv6 patterns to match (search within string, not full match)
  // 1. Full IPv6 with all 8 groups: 2001:0db8:0000:0000:0000:ff00:0042:8329
  const full_ipv6 = /(?<![a-fA-F0-9:])[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){7}(?![a-fA-F0-9:])/;
  
  // 2. IPv6 with compression (::): 2001:db8::ff00:42:8329, ::1, 2001:db8::
  const compressed_ipv6 = /(?<![a-fA-F0-9:])[0-9a-fA-F]{0,4}:{1,2}[0-9a-fA-F]{0,4}(?![a-fA-F0-9:])/;
  
  // 3. IPv6 with some compression in middle
  const middle_compressed = /(?<![a-fA-F0-9:])[0-9a-fA-F]{1,6}(?:::)[0-9a-fA-F]{0,6}(?![a-fA-F0-9:])/;
  
  // 4. Loopback ::1 and unspecified ::
  const loopback = /(?<![a-fA-F0-9:])::1(?![a-fA-F0-9:])/;
  const unspecified = /(?<![a-fA-F0-9:])::(?![a-fA-F0-9:])/;
  
  // 5. Simple pattern that catches compressed IPv6 like 2001:db8::1
  const simple_compressed = /[0-9a-fA-F]*:[0-9a-fA-F]*::[0-9a-fA-F]*/;
  
  // Test against all IPv6 patterns
  const ipv6_patterns = [
    full_ipv6,
    compressed_ipv6,
    middle_compressed,
    loopback,
    unspecified,
    simple_compressed
  ];
  
  // Check if value contains any IPv6 pattern
  const contains_ipv6 = ipv6_patterns.some(pattern => {
    return pattern.test(value);
  });
  
  return contains_ipv6;
}
