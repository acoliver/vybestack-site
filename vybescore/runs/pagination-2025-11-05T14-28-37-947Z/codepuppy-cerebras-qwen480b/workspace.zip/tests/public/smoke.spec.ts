import { describe, expect, it, beforeAll } from 'vitest';
import request from 'supertest';
import type { Express } from 'express';
import type { Database } from 'sql.js';
import type { InventoryItem } from '../../src/shared/types';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  let db: Database;
  let app: Express;

  beforeAll(async () => {
    db = await createDatabase();
    app = await createApp(db);
  });

  it('returns some inventory rows', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('uses default pagination parameters', async () => {
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBeLessThanOrEqual(5);
    expect(response.body.total).toBe(15); // Based on seed data
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('validates invalid page parameters', async () => {
    // Non-numeric page
    let response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');

    // Negative page
    response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);

    // Zero page
    response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);

    // Decimal page
    response = await request(app).get('/inventory?page=1.5');
    expect(response.status).toBe(400);
  });

  it('validates invalid limit parameters', async () => {
    // Non-numeric limit
    let response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');

    // Negative limit
    response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);

    // Zero limit
    response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);

    // Excessive limit
    response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
  });

  it('returns correct data slice without skipping or duplicating', async () => {
    // First page
    const firstPageResponse = await request(app).get('/inventory?page=1&limit=3');
    expect(firstPageResponse.status).toBe(200);
    expect(firstPageResponse.body.items.length).toBe(3);
    const firstItemIds = firstPageResponse.body.items.map((item: InventoryItem) => item.id);
    expect(firstItemIds).toEqual([1, 2, 3]);

    // Second page
    const secondPageResponse = await request(app).get('/inventory?page=2&limit=3');
    expect(secondPageResponse.status).toBe(200);
    expect(secondPageResponse.body.items.length).toBe(3);
    const secondItemIds = secondPageResponse.body.items.map((item: InventoryItem) => item.id);
    expect(secondItemIds).toEqual([4, 5, 6]);

    // Verify no overlap
    expect(firstItemIds).not.toEqual(expect.arrayContaining(secondItemIds));
  });

  it('calculates hasNext flag correctly', async () => {
    // Page 1 with limit 5 should have next (15 total items)
    let response = await request(app).get('/inventory?page=1&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.hasNext).toBe(true);

    // Page 2 with limit 5 should have next
    response = await request(app).get('/inventory?page=2&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.hasNext).toBe(true);

    // Page 3 with limit 5 should NOT have next (last page with items 11-15)
    response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.hasNext).toBe(false);

    // Page 2 with limit 6 should NOT have next (2 * 6 = 12 >= 15, but 3 * 6 = 18 > 15)
    response = await request(app).get('/inventory?page=2&limit=6');
    expect(response.status).toBe(200);
    expect(response.body.hasNext).toBe(false);
  });

  it('handles last page with fewer items', async () => {
    // Last page with limit 5 (items 11-15)
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(5);
    expect(response.body.hasNext).toBe(false);
    const lastItemIds = response.body.items.map((item: InventoryItem) => item.id);
    expect(lastItemIds).toEqual([11, 12, 13, 14, 15]);
  });

  it('returns empty result for page beyond data', async () => {
    const response = await request(app).get('/inventory?page=10&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items.length).toBe(0);
    expect(response.body.hasNext).toBe(false);
  });
});
