/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type Observer<T> = {
  name?: string
  value?: T
  updateFn: UpdateFn<T>
  dependents?: Set<Observer<T>>
  subscribers?: Set<Observer<T>>
  isDisposed?: boolean
}

export type Subject<T> = {
  name?: string
  value: T
  subscribers?: Set<Observer<T>>
  equalFn?: EqualFn<T>
}

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.isDisposed) return
  
  const previous = activeObserver
  activeObserver = observer as Observer<any>
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifySubscribers<T>(subject: Subject<T>): void {
  if (!subject.subscribers || subject.subscribers.size === 0) return
  
  // Make a copy to avoid iteration issues
  const subscribers = Array.from(subject.subscribers)
  
  for (const subscriber of subscribers) {
    if (!subscriber.isDisposed) {
      updateObserver(subscriber as Observer<T>)
    }
  }
}
