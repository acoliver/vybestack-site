/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, notifySubscribers } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    subscribers: new Set(),
    isDisposed: false
  }
  
  const executeCallback = () => {
    if (observer.isDisposed) return
    observer.updateFn(observer.value)
  }
  
  // Execute immediately to register dependencies and run the callback
  const activeObserver = getActiveObserver()
  if (activeObserver && !activeObserver.subscribers) {
    activeObserver.subscribers = new Set()
  }
  if (activeObserver) {
    activeObserver.subscribers.add(observer as Observer<any>)
  }
  
  try {
    executeCallback()
  } finally {
    // Note: we don't restore previous observer because callbacks should
    // execute in isolation to avoid interference
  }
  
  return () => {
    observer.isDisposed = true
    // Clean up subscription
    if (activeObserver && activeObserver.subscribers) {
      activeObserver.subscribers.delete(observer as Observer<any>)
    }
  }
}
