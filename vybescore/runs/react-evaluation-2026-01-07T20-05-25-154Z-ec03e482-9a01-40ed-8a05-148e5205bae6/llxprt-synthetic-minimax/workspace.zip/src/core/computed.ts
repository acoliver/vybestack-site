/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  setActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn
  }
  
  const computedGetter: GetterFn<T> = () => {
    const activeObs = getActiveObserver()
    
    // When accessed during another observer's evaluation,
    // establish the dependency relationship
    if (activeObs) {
      // Store this computed value as a dependency for the active observer
      if (!activeObs.dependents) {
        activeObs.dependents = new Set()
      }
      activeObs.dependents.add(o as Observer<any>)
    }
    
    // Re-evaluate the computed value when called
    const previous = getActiveObserver()
    setActiveObserver(o)
    try {
      o.value = updateFn(o.value)
    } finally {
      setActiveObserver(previous)
    }
    
    return o.value!
  }
  
  return computedGetter
}
