/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate Base64 input
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  // Check for proper padding if present
  const hasPadding = input.includes('=');
  if (hasPadding && input.length % 4 !== 0) {
    throw new Error('Invalid Base64 input: padding length is incorrect');
  }
  
  // For strings with padding, ensure padding is at the end only
  if (hasPadding && input.replace(/=+$/, '').includes('=')) {
    throw new Error('Invalid Base64 input: padding characters must be at the end');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
