import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';
import initSqlJs, { Database, SqlJsStatic } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  [key: string]: string;
}

const app = express();
const port = process.env.PORT || 3535;
let db: Database | null = null;
let SQL: SqlJsStatic | null = null;
const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Initialize SQL.js
    SQL = await initSqlJs({
      locateFile: (file: string) => path.join(process.cwd(), 'node_modules', 'sql.js', 'dist', file)
    });

    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    await fs.mkdir(dataDir, { recursive: true });

    // Check if database file exists
    let dbBuffer: Uint8Array | null = null;
    try {
      dbBuffer = await fs.readFile(dbPath);
    } catch (error) {
      console.log('Database file not found, creating new database');
    }

    // Initialize database
    if (dbBuffer) {
      db = new SQL.Database(dbBuffer);
    } else {
      db = new SQL.Database();
    }

    // Create table if not exists
    const schema = await fs.readFile(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
    if (db) {
      db.run(schema);
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) throw new Error('Database not initialized');

  try {
    const data = db.export();
    await fs.writeFile(dbPath, Buffer.from(data));
    console.log('Database saved to disk');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

// Validation functions
function validateFormData(formData: FormData): ValidationError {
  const errors: ValidationError = {};

  // Required fields
  const requiredFields: (keyof FormData)[] = [
    'first_name', 'last_name', 'street_address', 'city',
    'state_province', 'postal_code', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    if (!formData[field] || formData[field].trim() === '') {
      errors[field] = `${field.replace('_', ' ')} is required`;
    }
  }

  // Email validation
  if (formData.email && formData.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(formData.email.trim())) {
      errors.email = 'Please enter a valid email address';
    }
  }

// Phone validation
  if (formData.phone && formData.phone.trim() !== '') {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(formData.phone.trim())) {
      errors.phone = 'Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading +';
    }
  }

  // Postal code validation - accept alphanumeric characters and spaces
  if (formData.postal_code && formData.postal_code.trim() !== '') {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(formData.postal_code.trim())) {
      errors.postal_code = 'Postal code can only contain letters, digits, spaces, and hyphens';
    }
  }

  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { formData: null, errors: {} });
});

app.post('/submit', async (req, res) => {
  try {
    const formData: FormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province: req.body.state_province || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate form data
    const errors = validateFormData(formData);

    if (Object.keys(errors).length > 0) {
      return res.render('form', { formData, errors });
    }

    // Insert into database
    if (!db || !SQL) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.bind([
      formData.first_name.trim(),
      formData.last_name.trim(),
      formData.street_address.trim(),
      formData.city.trim(),
      formData.state_province.trim(),
      formData.postal_code.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    ]);
    
    stmt.step();
    stmt.free();

    // Save database
    await saveDatabase();

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      formData: req.body,
      errors: { general: 'An error occurred while submitting the form. Please try again.' }
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
async function gracefulShutdown(): Promise<void> {
  console.log('Received shutdown signal, closing database connections...');
  
  if (db) {
    // Save database before closing
    try {
      await saveDatabase();
      console.log('Database saved during shutdown');
    } catch (error) {
      console.error('Failed to save database during shutdown:', error);
    }
    
    db.close();
    db = null;
  }
  
  process.exit(0);
}

process.on('SIGTERM', () => gracefulShutdown());
process.on('SIGINT', () => gracefulShutdown());

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
