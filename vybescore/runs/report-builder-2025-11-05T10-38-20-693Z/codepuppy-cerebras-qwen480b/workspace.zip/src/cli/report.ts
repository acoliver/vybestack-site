#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, ReportOptions, Formatter } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputFile?: string;
  includeTotals: boolean;
}

function parseArguments(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const result: Partial<CliArgs> = {
    dataFile: args[0],
    includeTotals: false,
  };

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        console.error('Error: Unsupported format: ' + format);
        process.exit(1);
      }
      result.format = format;
      i++; // Skip the next argument
    } else if (arg === '--output') {
      result.outputFile = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else {
      console.error('Error: Unknown argument: ' + arg);
      process.exit(1);
    }
  }

  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return result as CliArgs;
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    // Validate the structure
    if (typeof data !== 'object' || data === null) {
      throw new Error('JSON must be an object');
    }
    
    const obj = data as Record<string, unknown>;
    
    if (typeof obj.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (typeof obj.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(obj.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    const entries = obj.entries as unknown[];
    for (const entry of entries) {
      if (typeof entry !== 'object' || entry === null) {
        throw new Error('Each entry must be an object');
      }
      
      const entryObj = entry as Record<string, unknown>;
      if (typeof entryObj.label !== 'string') {
        throw new Error('Each entry must have a "label" string');
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error('Each entry must have an "amount" number');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in ${filePath}: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Unknown error reading ${filePath}`);
    }
    process.exit(1);
  }
}

function getFormatter(format: string): Formatter {
  switch (format) {
    case 'markdown':
      return markdownFormatter;
    case 'text':
      return textFormatter;
    default:
      console.error('Error: Unsupported format: ' + format);
      process.exit(1);
      // This line is unreachable but TypeScript needs it
      throw new Error('Unreachable');
  }
}

function main(): void {
  const args = parseArguments();
  const data = loadAndValidateData(args.dataFile);
  const formatter = getFormatter(args.format);
  
  const options: ReportOptions = {
    includeTotals: args.includeTotals,
  };
  
  const output = formatter.render(data, options);
  
  if (args.outputFile) {
    try {
      writeFileSync(args.outputFile, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Could not write to ${args.outputFile}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();