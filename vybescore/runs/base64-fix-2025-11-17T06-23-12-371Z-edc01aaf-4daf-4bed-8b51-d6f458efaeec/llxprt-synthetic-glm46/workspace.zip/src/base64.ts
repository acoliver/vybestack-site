/**
 * Encode plain text to Base64 using the standard alphabet (A-Z, a-z, 0-9, +, /)
 * with proper padding (=) when required.
 */
export function encode(input: string): string {
  // Use Buffer's built-in base64 encoding which uses the standard Base64 alphabet
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the standard Base64 alphabet.
 * Rejects clearly invalid inputs by throwing an error.
 */
export function decode(input: string): string {
  // First validate the input contains only Base64 characters (A-Z, a-z, 0-9, +, /, and optional padding =)
  const base64Pattern = /^[A-Za-z0-9+/]*={0,2}$/;
  
  if (!base64Pattern.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check padding is valid (padding can only appear at the end and in specific patterns)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const paddingPart = input.substring(paddingIndex);
    // Padding must be 1 or 2 '=', and only valid positions are at the end
    if (paddingPart.length > 2 || !/^={1,2}$/.test(paddingPart)) {
      throw new Error('Invalid Base64 input: invalid padding');
    }
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
