/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validation function for Base64 input
 */
function isValidBase64(input: string): boolean {
  // Check for valid Base64 characters (standard Base64 alphabet)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check that padding is correct (only at the end)
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    const padding = input.substring(paddingIndex);
    // Padding can only be 0, 1, or 2 '=' characters and must be at the end
    if (!/^={0,2}$/.test(padding)) {
      return false;
    }
    
    // For non-empty strings, padding should only appear at the end
    if (padding.length === 1 && (input.length - 1) % 4 !== 3) {
      return false;
    }
    
    if (padding.length === 2 && (input.length - 2) % 4 !== 2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input format and throws error for invalid Base64 data.
 */
export function decode(input: string): string {
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
