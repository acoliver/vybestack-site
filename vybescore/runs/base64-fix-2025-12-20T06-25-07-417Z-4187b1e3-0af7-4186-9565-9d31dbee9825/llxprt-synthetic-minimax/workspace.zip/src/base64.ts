/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Includes padding characters as required by the Base64 specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both padded and unpadded standard Base64 input.
 */
export function decode(input: string): string {
  // Validate input contains only valid Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  // Add missing padding if necessary
  const missingPadding = input.length % 4;
  const paddedInput = missingPadding === 0 ? input : input + '='.repeat(4 - missingPadding);

  try {
    return Buffer.from(paddedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
