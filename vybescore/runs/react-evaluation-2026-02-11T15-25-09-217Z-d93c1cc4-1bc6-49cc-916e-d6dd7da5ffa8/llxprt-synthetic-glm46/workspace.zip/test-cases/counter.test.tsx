import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';
import Counter from '../components/Counter';

// Mock the CSS import
jest.mock('../components/Counter', () => {
  const actual = jest.requireActual('../components/Counter');
  return {
    ...actual,
    // Remove the CSS import requirement for testing
  };
});

describe('Counter Component', () => {
  test('renders initial state correctly', () => {
    render(<Counter />);
    
    expect(screen.getByText('Counter Component')).toBeInTheDocument();
    expect(screen.getByText('Count: 0')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Increase' })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'Decrease' })).toBeInTheDocument();
  });

  test('increments count when increase button is clicked', async () => {
    const user = userEvent.setup();
    render(<Counter />);
    
    const increaseButton = screen.getByRole('button', { name: 'Increase' });
    await user.click(increaseButton);
    
    expect(screen.getByText('Count: 1')).toBeInTheDocument();
  });

  test('decrements count when decrease button is clicked', async () => {
    const user = userEvent.setup();
    render(<Counter />);
    
    const decreaseButton = screen.getByRole('button', { name: 'Decrease' });
    await user.click(decreaseButton);
    
    expect(screen.getByText('Count: -1')).toBeInTheDocument();
  });

  test('handles multiple clicks correctly', async () => {
    const user = userEvent.setup();
    render(<Counter />);
    
    const increaseButton = screen.getByRole('button', { name: 'Increase' });
    const decreaseButton = screen.getByRole('button', { name: 'Decrease' });
    
    await user.click(increaseButton);
    await user.click(increaseButton);
    await user.click(decreaseButton);
    
    expect(screen.getByText('Count: 1')).toBeInTheDocument();
  });

  test('components are properly styled', () => {
    render(<Counter />);
    
    // Check if the main container has the expected className
    const container = screen.getByText('Counter Component').parentElement;
    expect(container).toHaveClass('counter-container');
    
    // Check if the count display has the expected className
    const countDisplay = screen.getByText('Count: 0');
    expect(countDisplay).toHaveClass('count-display');
  });
});