import React from 'react';
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import '@testing-library/jest-dom';

// Test case: Basic Component Creation and Props
// Description: Creates a simple component that accepts and displays props
export const BasicComponentTest = () => {
  const Button = ({ label, variant = 'primary' }) => {
    return (
      <button className={`btn btn-${variant}`} data-testid="button">
        {label}
      </button>
    );
  };

  return (
    <div>
      <h2 data-testid="test-title">Basic Component Test</h2>
      <Button label="Click me" variant="secondary" />
    </div>
  );
};

// Test case: State Management with useState
// Description: Manages click counter state and displays it
export const StateManagementTest = () => {
  const ClickCounter = () => {
    const [count, setCount] = React.useState(0);
    
    return (
      <div>
        <h2 data-testid="counter-title">State Management Test</h2>
        <p data-testid="count-display">Count: {count}</p>
        <button 
          data-testid="increment-button"
          onClick={() => setCount(prev => prev + 1)}
        >
          Increment
        </button>
      </div>
    );
  };

  return <ClickCounter />;
};

// Test case: Conditional Rendering
// Description: Shows/hides content based on state
export const ConditionalRenderingTest = () => {
  const ToggleContent = () => {
    const [isVisible, setIsVisible] = React.useState(false);
    
    return (
      <div>
        <h2 data-testid="toggle-title">Conditional Rendering Test</h2>
        <button 
          data-testid="toggle-button"
          onClick={() => setIsVisible(!isVisible)}
        >
          {isVisible ? 'Hide' : 'Show'} Content
        </button>
        {isVisible && (
          <p data-testid="conditional-content">
            This content is conditionally rendered!
          </p>
        )}
      </div>
    );
  };

  return <ToggleContent />;
};

// Test case: List Rendering with map
// Description: Renders an array of items as a list
export const ListRenderingTest = () => {
  const ItemList = () => {
    const items = ['Apple', 'Banana', 'Cherry', 'Date'];
    
    return (
      <div>
        <h2 data-testid="list-title">List Rendering Test</h2>
        <ul data-testid="item-list">
          {items.map((item, index) => (
            <li key={index} data-testid={`item-${index}`}>
              {item}
            </li>
          ))}
        </ul>
      </div>
    );
  };

  return <ItemList />;
};

// Test case: Form Handling
// Description: Manages form inputs and submission
export const FormHandlingTest = () => {
  const FormExample = () => {
    const [name, setName] = React.useState('');
    const [email, setEmail] = React.useState('');
    const [submitted, setSubmitted] = React.useState(false);
    
    const handleSubmit = (e) => {
      e.preventDefault();
      setSubmitted(true);
    };
    
    return (
      <div>
        <h2 data-testid="form-title">Form Handling Test</h2>
        <form data-testid="contact-form" onSubmit={handleSubmit}>
          <input
            data-testid="name-input"
            type="text"
            placeholder="Name"
            value={name}
            onChange={(e) => setName(e.target.value)}
          />
          <input
            data-testid="email-input"
            type="email"
            placeholder="Email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <button data-testid="submit-button" type="submit">
            Submit
          </button>
        </form>
        {submitted && (
          <p data-testid="success-message">Form submitted successfully!</p>
        )}
      </div>
    );
  };

  return <FormExample />;
};

// Test case: Component Lifecycle with useEffect
// Description: Demonstrates useEffect for side effects
export const LifecycleTest = () => {
  const useDocumentTitle = (title) => {
    React.useEffect(() => {
      document.title = title;
      console.log('Document title updated to:', title);
      return () => {
        console.log('Cleanup: title was', title);
      };
    }, [title]);
  };

  const LifecycleExample = () => {
    const [count, setCount] = React.useState(0);
    
    useDocumentTitle(`Count: ${count}`);
    
    React.useEffect(() => {
      console.log('Component mounted');
      return () => {
        console.log('Component unmounted');
      };
    }, []);
    
    React.useEffect(() => {
      console.log('Count changed to:', count);
    }, [count]);
    
    return (
      <div>
        <h2 data-testid="lifecycle-title">Lifecycle Test</h2>
        <p data-testid="count-display">Count: {count}</p>
        <button 
          data-testid="increment-button"
          onClick={() => setCount(count + 1)}
        >
          Increment
        </button>
      </div>
    );
  };

  return <LifecycleExample />;
};

// Test case: Custom Hook
// Description: Shows how to create and use custom hooks
export const CustomHookTest = () => {
  const useCounter = (initialValue = 0) => {
    const [count, setCount] = React.useState(initialValue);
    
    const increment = () => setCount(prev => prev + 1);
    const decrement = () => setCount(prev => prev - 1);
    const reset = () => setCount(initialValue);
    
    return { count, increment, decrement, reset };
  };

  const CustomHookExample = () => {
    const { count, increment, decrement, reset } = useCounter(5);
    
    return (
      <div>
        <h2 data-testid="custom-hook-title">Custom Hook Test</h2>
        <p data-testid="counter-display">Count: {count}</p>
        <button data-testid="increment-button" onClick={increment}>
          Increment
        </button>
        <button data-testid="decrement-button" onClick={decrement}>
          Decrement
        </button>
        <button data-testid="reset-button" onClick={reset}>
          Reset
        </button>
      </div>
    );
  };

  return <CustomHookExample />;
};

// Test case: Context API
// Description: Shows usage of React Context for state sharing
export const ContextTest = () => {
  const ThemeContext = React.createContext('light');
  
  const ThemedButton = () => {
    const theme = React.useContext(ThemeContext);
    const className = `button-${theme}`;
    
    return (
      <button 
        data-testid="themed-button"
        className={className}
      >
        {theme === 'light' ? 'Light Theme' : 'Dark Theme'}
      </button>
    );
  };

  const ThemeToggle = () => {
    const [theme, setTheme] = React.useState('light');
    
    const handleThemeChange = () => {
      setTheme(prevTheme => prevTheme === 'light' ? 'dark' : 'light');
    };
    
    return (
      <ThemeContext.Provider value={theme}>
        <div>
          <h2 data-testid="context-title">Context API Test</h2>
          <button 
            data-testid="theme-toggle"
            onClick={handleThemeChange}
          >
            Toggle Theme
          </button>
          <ThemedButton />
        </div>
      </ThemeContext.Provider>
    );
  };

  return <ThemeToggle />;
};

// Test case: Error Boundaries
// Description: Shows React Error Boundary usage
export const ErrorBoundaryTest = () => {
  class ErrorBoundary extends React.Component {
    constructor(props) {
      super(props);
      this.state = { hasError: false, error: null };
    }

    static getDerivedStateFromError(error) {
      return { hasError: true };
    }

    componentDidCatch(error, errorInfo) {
      console.error('Error caught by boundary:', error, errorInfo);
      this.setState({ error });
    }

    render() {
      if (this.state.hasError) {
        return (
          <div data-testid="error-boundary">
            <h2>Something went wrong!</h2>
            <p data-testid="error-message">
              {this.state.error && this.state.error.toString()}
            </p>
            <button 
              data-testid="reset-button"
              onClick={() => this.setState({ hasError: false, error: null })}
            >
              Try Again
            </button>
          </div>
        );
      }

      return this.props.children;
    }
  }

  const ComponentThatMayError = ({ shouldError }) => {
    if (shouldError) {
      throw new Error('Intentional error for testing');
    }
    return <p data-testid="normal-content">Everything is fine!</p>;
  };

  return (
    <ErrorBoundary>
      <div>
        <h2 data-testid="error-boundary-title">Error Boundary Test</h2>
        <ComponentThatMayError shouldError={true} />
      </div>
    </ErrorBoundary>
  );
};

// Test case: Component Composition
// Description: Demonstrates component composition patterns
export const ComponentCompositionTest = () => {
  const Card = ({ children, title }) => (
    <div className="card" data-testid="card">
      <h3 data-testid="card-title">{title}</h3>
      <div data-testid="card-content">{children}</div>
    </div>
  );

  const UserCard = ({ user }) => (
    <Card title={user.name}>
      <p data-testid="user-email">{user.email}</p>
      <p data-testid="user-role">{user.role}</p>
      <button data-testid="contact-button">
        Contact {user.name.split(' ')[0]}
      </button>
    </Card>
  );

  const CompositionExample = () => {
    const [users] = React.useState([
      { name: 'Alice Johnson', email: 'alice@example.com', role: 'Developer' },
      { name: 'Bob Smith', email: 'bob@example.com', role: 'Designer' }
    ]);

    return (
      <div>
        <h2 data-testid="composition-title">Component Composition Test</h2>
        {users.map((user, index) => (
          <UserCard key={index} user={user} />
        ))}
      </div>
    );
  };

  return <CompositionExample />;
};

// Test case: Performance Optimization with useMemo
// Description: Shows use of useMemo for performance optimization
export const PerformanceTest = () => {
  const useExpensiveCalculation = (num) => {
    const [result, setResult] = React.useState(null);
    const [isCalculating, setIsCalculating] = React.useState(false);
    
    const expensiveFunction = (n) => {
      // Simulate expensive calculation
      const startTime = Date.now();
      while (Date.now() - startTime < 50) {
        // Busy wait
      }
      return n * 2;
    };
    
    const memoizedResult = React.useMemo(() => {
      console.log('Performing expensive calculation...');
      return expensiveFunction(num);
    }, [num]);
    
    React.useEffect(() => {
      setIsCalculating(true);
      setResult(memoizedResult);
      setIsCalculating(false);
    }, [memoizedResult]);
    
    return { result, isCalculating };
  };

  const PerformanceExample = () => {
    const [input, setInput] = React.useState(10);
    const { result, isCalculating } = useExpensiveCalculation(input);
    
    return (
      <div>
        <h2 data-testid="performance-title">Performance Test</h2>
        <div>
          <label htmlFor="input-number">Number:</label>
          <input
            id="input-number"
            data-testid="number-input"
            type="number"
            value={input}
            onChange={(e) => setInput(Number(e.target.value))}
          />
        </div>
        <div>
          <p data-testid="calculation-status">
            {isCalculating ? 'Calculating...' : 'Calculation complete'}
          </p>
          <p data-testid="calculation-result">
            Result: {result !== null ? result : 'N/A'}
          </p>
        </div>
      </div>
    );
  };

  return <PerformanceExample />;
};