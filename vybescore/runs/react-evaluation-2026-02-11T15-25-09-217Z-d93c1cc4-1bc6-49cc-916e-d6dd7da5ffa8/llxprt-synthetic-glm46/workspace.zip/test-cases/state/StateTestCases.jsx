export const StateTestCases = [
  {
    id: 'useState-basic',
    name: 'useState Basic',
    description: 'Basic state management with useState hook',
    difficulty: 'beginner',
    tags: ['hooks', 'state', 'useState'],
    test: `
import React, { useState } from 'react';

// Complete this component to maintain a counter that increments when button is clicked
export default function Counter() {
  // TODO: Add useState to track count
  const [count, setCount] = useState(0);
  
  return (
    <div>
      <p>Count: {count}</p>
      {/* TODO: Add onClick handler to increment count */}
      <button onClick={() => setCount(count + 1)}>
        Increment
      </button>
    </div>
  );
}
    `,
    solution: `
import React, { useState } from 'react';

// Complete this component to maintain a counter that increments when button is clicked
export default function Counter() {
  // Add useState to track count
  const [count, setCount] = useState(0);
  
  return (
    <div>
      <p>Count: {count}</p>
      {/* Add onClick handler to increment count */}
      <button onClick={() => setCount(count + 1)}>
        Increment
      </button>
    </div>
  );
}
    `,
    hints: [
      'Import useState from React',
      'Initialize the hook with default value',
      'Use the setter function to update state'
    ]
  },
  {
    id: 'useState-object',
    name: 'useState with Objects',
    description: 'Managing complex state with useState and objects',
    difficulty: 'intermediate',
    tags: ['hooks', 'state', 'useState', 'objects'],
    test: `
import React, { useState } from 'react';

// Complete this component to manage a user profile form
export default function UserProfile() {
  // TODO: Create a state object for user profile with name, email, and age
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    age: 0
  });
  
  // TODO: Implement handleChange function to update any field
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  return (
    <div>
      <input 
        name="name" 
        value={profile.name}
        onChange={handleChange}
        placeholder="Name"
      />
      <input 
        name="email" 
        value={profile.email}
        onChange={handleChange}
        placeholder="Email"
      />
      <input 
        name="age" 
        value={profile.age}
        onChange={handleChange}
        placeholder="Age"
      />
      <button>Submit</button>
    </div>
  );
}
    `,
    solution: `
import React, { useState } from 'react';

export default function UserProfile() {
  // Create a state object for user profile with name, email, and age
  const [profile, setProfile] = useState({
    name: '',
    email: '',
    age: 0
  });
  
  // Implement handleChange function to update any field
  const handleChange = (e) => {
    const { name, value } = e.target;
    setProfile(prev => ({
      ...prev,
      [name]: value
    }));
  };
  
  return (
    <div>
      <input 
        name="name" 
        value={profile.name}
        onChange={handleChange}
        placeholder="Name"
      />
      <input 
        name="email" 
        value={profile.email}
        onChange={handleChange}
        placeholder="Email"
      />
      <input 
        name="age" 
        value={profile.age}
        onChange={handleChange}
        placeholder="Age"
      />
      <button>Submit</button>
    </div>
  );
}
    `,
    hints: [
      'Use object spreading to maintain previous values',
      'Use computed property name syntax for dynamic key updates',
      'Remember to handle all form fields properly'
    ]
  },
  {
    id: 'useEffect-basic',
    name: 'useEffect Basics',
    description: 'Using useEffect for side effects',
    difficulty: 'intermediate',
    tags: ['hooks', 'effects', 'useEffect'],
    test: `
import React, { useState, useEffect } from 'react';

// Complete this component to fetch data when it mounts
export default function DataFetcher() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // TODO: Add useEffect to fetch data when component mounts
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Simulate API call
        const response = await fetch('/api/data');
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []); // Empty dependency array means run once on mount
  
  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  
  return (
    <div>
      {/* TODO: Render the data */}
      {data.map(item => (
        <div key={item.id}>{item.name}</div>
      ))}
    </div>
  );
}
    `,
    solution: `
import React, { useState, useEffect } from 'react';

export default function DataFetcher() {
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  // Add useEffect to fetch data when component mounts
  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      try {
        // Simulate API call
        const response = await fetch('/api/data');
        const result = await response.json();
        setData(result);
      } catch (err) {
        setError(err.message);
      } finally {
        setLoading(false);
      }
    };
    
    fetchData();
  }, []); // Empty dependency array means run once on mount
  
  if (loading) return <div>Loading...</div>;
  if (error) return <div>Error: {error}</div>;
  
  return (
    <div>
      {/* Render the data */}
      {data.map(item => (
        <div key={item.id}>{item.name}</div>
      ))}
    </div>
  );
}
    `,
    hints: [
      'Use an empty dependency array to run the effect only once',
      'Always handle loading and error states in async operations',
      'Don\'t forget the cleanup function if needed'
    ]
  },
  {
    id: 'useEffect-dependencies',
    name: 'useEffect Dependencies',
    description: 'Controlling when effects run with dependencies',
    difficulty: 'intermediate',
    tags: ['hooks', 'effects', 'useEffect', 'dependencies'],
    test: `
import React, { useState, useEffect } from 'react';

// Complete this component to filter users based on search term
export default function UserSearch() {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);
  
  // TODO: Add useEffect to fetch users when component mounts
  // TODO: Add useEffect to filter users when searchTerm or users change
  useEffect(() => {
    // Fetch users (mock data)
    setUsers([
      { id: 1, name: 'Alice', role: 'admin' },
      { id: 2, name: 'Bob', role: 'user' },
      { id: 3, name: 'Charlie', role: 'editor' }
    ]);
  }, []);
  
  useEffect(() => {
    // Filter users based on search term
    const filtered = users.filter(user =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredUsers(filtered);
  }, [users, searchTerm]);
  
  return (
    <div>
      <input
        placeholder="Search users..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
      />
      <div>
        {filteredUsers.map(user => (
          <div key={user.id}>
            {user.name} - {user.role}
          </div>
        ))}
      </div>
    </div>
  );
}
    `,
    solution: `
import React, { useState, useEffect } from 'react';

export default function UserSearch() {
  const [users, setUsers] = useState([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [filteredUsers, setFilteredUsers] = useState([]);
  
  // Add useEffect to fetch users when component mounts
  useEffect(() => {
    // Fetch users (mock data)
    setUsers([
      { id: 1, name: 'Alice', role: 'admin' },
      { id: 2, name: 'Bob', role: 'user' },
      { id: 3, name: 'Charlie', role: 'editor' }
    ]);
  }, []);
  
  // Add useEffect to filter users when searchTerm or users change
  useEffect(() => {
    // Filter users based on search term
    const filtered = users.filter(user =>
      user.name.toLowerCase().includes(searchTerm.toLowerCase())
    );
    setFilteredUsers(filtered);
  }, [users, searchTerm]);
  
  return (
    <div>
      <input
        placeholder="Search users..."
        value={searchTerm}
        onChange={e => setSearchTerm(e.target.value)}
      />
      <div>
        {filteredUsers.map(user => (
          <div key={user.id}>
            {user.name} - {user.role}
          </div>
        ))}
      </div>
    </div>
  );
}
    `,
    hints: [
      'Specify all variables used in the effect in the dependency array',
      'Multiple effects can work together for different concerns',
      'Think about when you want the effect to re-run'
    ]
  },
  {
    id: 'custom-hook',
    name: 'Custom Hook',
    description: 'Creating and using custom hooks',
    difficulty: 'advanced',
    tags: ['hooks', 'custom', 'reusability'],
    test: `
import React, { useState, useEffect } from 'react';

// TODO: Create a custom hook for managing local storage
function useLocalStorage(key, initialValue) {
  // Get value from local storage or use initial value
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });
  
  // TODO: Create a custom setter function that also updates local storage
  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(error);
    }
  };
  
  return [storedValue, setValue];
}

// TODO: Use the custom hook in a component
export default function LocalStorageComponent() {
  const [name, setName] = useLocalStorage('name', '');
  
  return (
    <div>
      <input
        value={name}
        onChange={e => setName(e.target.value)}
        placeholder="Enter your name"
      />
      <p>Hello, {name || 'stranger'}!</p>
    </div>
  );
}
    `,
    solution: `
import React, { useState, useEffect } from 'react';

// Create a custom hook for managing local storage
function useLocalStorage(key, initialValue) {
  // Get value from local storage or use initial value
  const [storedValue, setStoredValue] = useState(() => {
    try {
      const item = window.localStorage.getItem(key);
      return item ? JSON.parse(item) : initialValue;
    } catch (error) {
      console.error(error);
      return initialValue;
    }
  });
  
  // Create a custom setter function that also updates local storage
  const setValue = (value) => {
    try {
      const valueToStore = value instanceof Function ? value(storedValue) : value;
      setStoredValue(valueToStore);
      window.localStorage.setItem(key, JSON.stringify(valueToStore));
    } catch (error) {
      console.error(error);
    }
  };
  
  return [storedValue, setValue];
}

// Use the custom hook in a component
export default function LocalStorageComponent() {
  const [name, setName] = useLocalStorage('name', '');
  
  return (
    <div>
      <input
        value={name}
        onChange={e => setName(e.target.value)}
        placeholder="Enter your name"
      />
      <p>Hello, {name || 'stranger'}!</p>
    </div>
  );
}
    `,
    hints: [
      'Custom hooks must start with "use"',
      'They can call other hooks internally',
      'Custom hooks encapsulate and reuse stateful logic'
    ]
  }
];

export default StateTestCases;