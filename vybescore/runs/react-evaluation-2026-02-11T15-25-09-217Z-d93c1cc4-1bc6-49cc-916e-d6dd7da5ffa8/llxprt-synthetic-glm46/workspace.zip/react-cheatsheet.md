# React Quick Reference Cheat Sheet

## Core Concepts

### Functional Components with Hooks (Recommended)
```typescript
import React, { useState, useEffect, useCallback, useMemo } from 'react';

interface Props {
  title: string;
  onClick?: () => void;
}

const Component: React.FC<Props> = ({ title, onClick }) => {
  const [state, setState] = useState(initialValue);
  
  useEffect(() => {
    // Side effects
    return () => cleanup();
  }, [dependencies]);
  
  const handleClick = useCallback(() => {
    // Memoized callback
  }, [dependencies]);
  
  const computedValue = useMemo(() => {
    return expensiveCalculation();
  }, [dependencies]);
  
  return <div>{title}</div>;
};
```

## State Management

### Local State
```typescript
// Simple state
const [count, setCount] = useState(0);

// Complex state with useReducer
const [state, dispatch] = useReducer(reducer, initialState);
```

### Global State - Zustand (Recommended for most apps)
```typescript
import create from 'zustand';

const useStore = create((set) => ({
  count: 0,
  increment: () => set((state) => ({ count: state.count + 1 })),
}));

// Usage
const { count, increment } = useStore();
```

### Server State - TanStack Query
```typescript
import { useQuery, useMutation } from '@tanstack/react-query';

// Fetch data
const { data, isLoading, error } = useQuery({
  queryKey: ['users'],
  queryFn: fetchUsers,
});

// Mutate data
const mutation = useMutation({
  mutationFn: createUser,
  onSuccess: () => queryClient.invalidateQueries(['users']),
});
```

## Component Patterns

### Custom Hooks
```typescript
const useLocalStorage = (key: string, initialValue: T) => {
  const [storedValue, setStoredValue] = useState(() => {
    // Initialize from localStorage
  });
  
  const setValue = (value: T) => {
    // Update both state and localStorage
  };
  
  return [storedValue, setValue] as const;
};
```

### Compound Components
```typescript
const Tabs = ({ children }) => {
  const [active, setActive] = useState(0);
  
  return (
    <TabContext.Provider value={{ active, setActive }}>
      {children}
    </TabContext.Provider>
  );
};

Tabs.List = TabList;
Tabs.Tab = Tab;
Tabs.Panel = TabPanel;
```

### Error Boundaries
```typescript
class ErrorBoundary extends Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false };
  }
  
  static getDerivedStateFromError(error) {
    return { hasError: true };
  }
  
  componentDidCatch(error, errorInfo) {
    console.error('Error:', error);
  }
  
  render() {
    if (this.state.hasError) {
      return <div>Something went wrong.</div>;
    }
    return this.props.children;
  }
}
```

## Performance Optimization

### React.memo
```typescript
const ExpensiveComponent = React.memo(({ data, onClick }) => {
  return <div>{/* component content */}</div>;
});
```

### useMemo / useCallback
```typescript
const MemoizedComponent = ({ items }) => {
  const processedData = useMemo(() => {
    return items.map(item => expensiveOperation(item));
  }, [items]);
  
  const handleClick = useCallback((id) => {
    // Handle click
  }, []);
  
  return <>{/* JSX */}</>;
};
```

### Code Splitting
```typescript
import { lazy, Suspense } from 'react';

const HeavyComponent = lazy(() => import('./HeavyComponent'));

const App = () => (
  <Suspense fallback={<Loading />}>
    <HeavyComponent />
  </Suspense>
);
```

## Styling Approaches

### CSS Modules
```typescript
import styles from './Component.module.css';

const Component = () => (
  <div className={styles.container}>
    <button className={styles.button}>Click me</button>
  </div>
);
```

### Styled-components
```typescript
import styled from 'styled-components';

const Button = styled.button`
  background: ${props => props.primary ? 'blue' : 'gray'};
  color: white;
  padding: 8px 16px;
`;
```

### Tailwind CSS (Atomic)
```typescript
const Component = () => (
  <div className="flex justify-center items-center p-4">
    <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded">
      Click me
    </button>
  </div>
);
```

## Forms & Input Handling

### Controlled Components
```typescript
const Form = () => {
  const [formData, setFormData] = useState({
    email: '',
    password: '',
  });
  
  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Submit logic
  };
  
  return (
    <form onSubmit={handleSubmit}>
      <input
        type="email"
        name="email"
        value={formData.email}
        onChange={handleChange}
      />
      <input
        type="password"
        name="password"
        value={formData.password}
        onChange={handleChange}
      />
      <button type="submit">Submit</button>
    </form>
  );
};
```

## Routing with React Router

### Basic Setup
```typescript
import { Routes, Route, Link, Navigate } from 'react-router-dom';

const App = () => (
  <Router>
    <nav>
      <Link to="/">Home</Link>
      <Link to="/about">About</Link>
    </nav>
    
    <Routes>
      <Route path="/" element={<Home />} />
      <Route path="/about" element={<About />} />
      <Route path="/users/:id" element={<UserProfile />} />
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  </Router>
);
```

### Route Parameters
```typescript
const UserProfile = () => {
  const { id } = useParams();
  const [user, setUser] = useState(null);
  
  useEffect(() => {
    fetchUser(id).then(setUser);
  }, [id]);
  
  return user ? <div>{user.name}</div> : <div>Loading...</div>;
};
```

## Testing with React Testing Library

### Component Testing
```typescript
import { render, screen, fireEvent, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

describe('Component', () => {
  it('renders correctly', () => {
    render(<Component />);
    expect(screen.getByText('Hello')).toBeInTheDocument();
  });
  
  it('handles user interaction', async () => {
    const handleClick = jest.fn();
    render(<Component onClick={handleClick} />);
    
    await userEvent.click(screen.getByRole('button'));
    
    expect(handleClick).toHaveBeenCalled();
  });
});
```

### Hook Testing
```typescript
import { renderHook, act } from '@testing-library/react';

describe('useCustomHook', () => {
  it('initializes correctly', () => {
    const { result } = renderHook(() => useCustomHook());
    expect(result.current.value).toBe(initialValue);
  });
  
  it('updates state', () => {
    const { result } = renderHook(() => useCustomHook());
    
    act(() => {
      result.current.updateValue('new value');
    });
    
    expect(result.current.value).toBe('new value');
  });
});
```

## Common Patterns

### Conditional Rendering
```typescript
// Using ternary operator
{isLoading ? <Spinner /> : <Component />}

// Using logical AND
{showMessage && <Message text="Hello" />}

// Using if statement in JSX
const renderContent = () => {
  if (isLoading) return <Spinner />;
  if (error) return <Error />;
  return <Component />;
};

return <div>{renderContent()}</div>;
```

### List Rendering
```typescript
const List = ({ items }) => (
  <ul>
    {items.map((item, index) => (
      <li key={item.id || index}>
        {item.name}
      </li>
    ))}
  </ul>
);
```

### Props Destructuring with Defaults
```typescript
interface Props {
  title?: string;
  count?: number;
  disabled?: boolean;
}

const Component = ({ 
  title = 'Default Title', 
  count = 0, 
  disabled = false 
}: Props) => (
  <div className={disabled ? 'disabled' : ''}>
    {title} ({count})
  </div>
);
```

## Quick Tips

- Use functional components with hooks
- Prefer TS for type safety
- Memoize expensive operations
- Keep components small and focused
- Use semantic HTML for accessibility
- Test behavior, not implementation
- Handle errors gracefully with error boundaries
- Use proper TypeScript interfaces for props
- Extract reusable logic into custom hooks
- Consider bundle size when adding dependencies

## Most Used Hooks

```typescript
// State management
useState(initialValue)
useReducer(reducer, initialState)

// Side effects
useEffect(() => {}, [deps])
useLayoutEffect(() => {}, [deps])

// Performance
useCallback(() => {}, [deps])
useMemo(() => computeValue(), [deps])
React.memo(Component)

// Context
useContext(MyContext)

// Refs
useRef(initialValue)
useImperativeHandle(ref, () => ({}))

// Built-in hooks
useId()
useDeferredValue(value)
useTransition()
```