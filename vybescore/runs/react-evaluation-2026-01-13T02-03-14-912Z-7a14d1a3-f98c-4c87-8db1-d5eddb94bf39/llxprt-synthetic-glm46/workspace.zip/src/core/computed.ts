/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  setActiveObserver,
  notifyObservers,
  Options,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  let isDirty = true
  
  const getter: GetterFn<T> = () => {
    const previousObserver = getActiveObserver()
    
    // Set this observer as active to track dependencies
    setActiveObserver(o)
    
    try {
      if (isDirty) {
        o.updateFn(o.value)
        isDirty = false
      }
    } finally {
      // Restore previous observer
      setActiveObserver(previousObserver)
    }
    
    return o.value!
  }
  
  // Make the computed value reactive
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    
    // Check for equality to avoid unnecessary updates
    let shouldUpdate = true
    if (_equal) {
      if (typeof _equal === 'boolean') {
        shouldUpdate = o.value !== newValue
      } else {
        shouldUpdate = !_equal(o.value!, newValue)
      }
    }
    
    if (shouldUpdate) {
      o.value = newValue
      // Notify dependent observers when the computed value changes
      notifyObservers(dependentObservers)
    }
    
    return o.value!
  }
  
  // Make the computed value aware of all observers that depend on it
  const dependentObservers: ObserverR[] = []
  
  function trackDependentObserver() {
    const currentObserver = getActiveObserver()
    if (currentObserver && !dependentObservers.includes(currentObserver)) {
      dependentObservers.push(currentObserver)
    }
  }
  
  // Override the current computed to mark dirty when accessed by a new observer
  const originalGetter = getter
  
  const newGetter: GetterFn<T> = () => {
    trackDependentObserver()
    return originalGetter()
  }
  
  // Compute initial value
  newGetter()
  
  return newGetter
}
