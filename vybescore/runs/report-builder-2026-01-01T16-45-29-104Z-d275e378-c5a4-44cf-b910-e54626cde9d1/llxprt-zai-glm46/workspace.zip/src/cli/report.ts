#!/usr/bin/env node

import * as fs from 'node:fs';
import * as path from 'node:path';
import { formatters } from '../formats/index.js';
import type { ReportData, RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';

function parseArgs(args: string[]): {
  inputPath: string;
  format: string;
  outputPath: string | undefined;
  options: RenderOptions;
} {
  const inputPath = args[0];

  if (!inputPath) {
    console.error('Error: Missing input file argument');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      format = args[i];
    } else if (arg === '--output') {
      i++;
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: Missing --format argument');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return { inputPath, format, outputPath, options: { includeTotals } };
}

function main(): void {
  const args = process.argv.slice(2);

  if (args.length === 0) {
    console.error('Error: Missing arguments');
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const { inputPath, format, outputPath, options } = parseArgs(args);

  // Validate format
  if (!formatters[format]) {
    console.error(`Error: Unsupported format: ${format}`);
    console.error('Supported formats: markdown, text');
    process.exit(1);
  }

  // Read and parse input file
  let inputData: unknown;
  try {
    const absolutePath = path.resolve(inputPath);
    const fileContent = fs.readFileSync(absolutePath, 'utf-8');
    inputData = JSON.parse(fileContent);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file '${inputPath}': ${error.message}`);
      process.exit(1);
    }
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: ${inputPath}`);
      process.exit(1);
    }
    console.error(`Error: Failed to read file '${inputPath}': ${(error as Error).message}`);
    process.exit(1);
  }

  // Validate report data
  let reportData: ReportData;
  try {
    reportData = validateReportData(inputData);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }

  // Render report
  const renderer = formatters[format];
  const output = renderer(reportData, options);

  // Write output
  if (outputPath) {
    try {
      const absoluteOutputPath = path.resolve(outputPath);
      fs.writeFileSync(absoluteOutputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to file '${outputPath}': ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
