#!/usr/bin/env node

import fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { formatRenderers, supportedFormats } from '../formats/index.js';

function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  const dataPath = args[0];
  if (!dataPath) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    if (arg === '--format') {
      format = args[++i] || '';
    } else if (arg === '--output') {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateAndLoadData(dataPath: string): ReportData {
  if (!fs.existsSync(dataPath)) {
    console.error(`Error: File not found: ${dataPath}`);
    process.exit(1);
  }

  let content: string;
  try {
    content = fs.readFileSync(dataPath, 'utf-8');
  } catch (err) {
    console.error(`Error reading file: ${dataPath}`);
    process.exit(1);
  }

  let data: unknown;
  try {
    data = JSON.parse(content);
  } catch (err) {
    console.error(`Error: Invalid JSON in file: ${dataPath}`);
    console.error((err as Error).message);
    process.exit(1);
  }

  // Validate structure
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Invalid report data: expected an object');
    process.exit(1);
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error('Error: Invalid report data: missing or invalid "title" field');
    process.exit(1);
  }

  if (typeof obj.summary !== 'string') {
    console.error('Error: Invalid report data: missing or invalid "summary" field');
    process.exit(1);
  }

  if (!Array.isArray(obj.entries)) {
    console.error('Error: Invalid report data: missing or invalid "entries" field');
    process.exit(1);
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Invalid entry at index ${i}: expected an object`);
      process.exit(1);
    }

    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Invalid entry at index ${i}: missing or invalid "label" field`);
      process.exit(1);
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Invalid entry at index ${i}: missing or invalid "amount" field`);
      process.exit(1);
    }
  }

  return data as ReportData;
}

function main() {
  const args = process.argv.slice(2);
  const { dataPath, format, outputPath, includeTotals } = parseArgs(args);

  // Validate format
  if (!supportedFormats.includes(format)) {
    console.error(`Error: Unsupported format: ${format}`);
    console.error(`Supported formats: ${supportedFormats.join(', ')}`);
    process.exit(1);
  }

  // Load and validate data
  const data = validateAndLoadData(dataPath);

  // Render report
  const options: RenderOptions = { includeTotals };
  const renderer = formatRenderers[format];
  const output = renderer(data, options);

  // Write output
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (err) {
      console.error(`Error writing to file: ${outputPath}`);
      console.error((err as Error).message);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
