/**
 * Report data model
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report rendering
 */
export interface RenderOptions {
  includeTotals: boolean;
}
