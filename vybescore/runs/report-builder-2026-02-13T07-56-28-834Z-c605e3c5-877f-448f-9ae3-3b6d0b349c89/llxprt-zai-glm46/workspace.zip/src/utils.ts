/**
 * Format amount with exactly two decimal places
 */
export function formatAmount(amount: number): string {
  return amount.toFixed(2);
}
