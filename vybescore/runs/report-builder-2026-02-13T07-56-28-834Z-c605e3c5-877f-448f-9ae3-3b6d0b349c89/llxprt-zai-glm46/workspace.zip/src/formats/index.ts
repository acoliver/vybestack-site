import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

export type FormatRenderer = (data: ReportData, options: RenderOptions) => string;

export const formatRenderers: Record<string, FormatRenderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

export const supportedFormats = Object.keys(formatRenderers);
