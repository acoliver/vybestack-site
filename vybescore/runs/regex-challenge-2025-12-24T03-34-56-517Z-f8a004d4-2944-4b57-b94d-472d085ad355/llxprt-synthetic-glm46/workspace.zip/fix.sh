#!/bin/bash
# Read the current file content, fix line 63 to use the proper regex
sed -n '1,62p' src/puzzles.ts > src/puzzles_new.ts
echo 'const hasSymbol = /[!@#$%^&*()_+[\\]{};'"'"':"'"'"'|,.<>\/?]/.test(value);' >> src/puzzles_new.ts
sed -n '64,$p' src/puzzles.ts >> src/puzzles_new.ts
mv src/puzzles_new.ts src/puzzles.ts