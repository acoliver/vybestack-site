/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') return [];
  
  // Create a Set for exception lookup
  const exceptionSet = new Set(exceptions.filter(e => typeof e === 'string'));
  
  // Escape the prefix for regex and create the pattern
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w+\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions
  return matches.filter(match => 
    !exceptionSet.has(match.toLowerCase()) && 
    !exceptionSet.has(match)
  );
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') return [];
  
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\\\]\\]/g, '\\$&');
  
  // Use lookbehind to match token preceded by a digit, but not at start
  const pattern = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  // Find all matches with lookbehind
  const matches = [];
  let match;
  while ((match = pattern.exec(text)) !== null) {
    // Get the full match including the digit
    const fullMatch = text.substring(match.index - 1, match.index + token.length);
    matches.push(fullMatch);
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // At least 10 characters
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\\s/.test(value)) return false;
  
// At least one uppercase, one lowercase, one digit, one symbol
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /[0-9]/.test(value);
const hasSymbol = /[!@#$%^&*()_+[\]{};':|"|,.<>/?]/.test(value);

  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) return false;

  // No immediate repeated sequences (e.g., abab, 123123)
  // Check for immediate repeated patterns of length 2-3
  for (let len = 2; len <= 3; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const pattern = value.slice(i, i + len);
      const nextPattern = value.slice(i + len, i + len * 2);
      if (pattern === nextPattern) return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 regex patterns - various forms including shorthand :: notation
  const ipv6Patterns = [
    // Full IPv6 - 8 groups of 4 hex digits
    /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/,
    // IPv6 with :: (consecutive groups of zeros can be collapsed)
    /^(?:[0-9a-fA-F]{1,4}:){1,7}:$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}$/,
    /^[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})$/,
    // :: can appear at the start, middle, or end (but not both start and end unless it's just ::)
    /^::(?:(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4})$/,
    /^(?:[0-9a-fA-F]{1,4}:){1,6}:$/,
    
    // IPv4-mapped IPv6 addresses (::ffff:192.168.1.1)
    /^::ffff:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
    
    // IPv6 with embedded IPv4
    /^(?:[0-9a-fA-F]{1,4}:){1,4}:(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/,
    
    // Just :: is valid IPv6 address
    /^::$/
  ];
  
  // First check if this looks like an IPv4 address (to exclude those)
  const ipv4Regex = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Regex.test(value.trim())) return false;
  
  // Check against IPv6 pattern with word boundaries
  const ipv6InTextRegex = /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:\b|\b:(?:(?:[0-9a-fA-F]{1,4}:){1,6}[0-9a-fA-F]{1,4})\b|\b::\b/;
  
  // Test if text contains IPv6 pattern
  const containsIPv6InText = ipv6InTextRegex.test(value);
  if (!containsIPv6InText) return false;
  
  // Extract potential IPv6 addresses and validate them
  const potentialIPv6 = value.match(/[0-9a-fA-F:]+/g);
  if (!potentialIPv6) return false;
  
  return potentialIPv6.some(addr => {
    // If it's just an IPv4 address, skip it
    if (ipv4Regex.test(addr)) return false;
    
    // Check if it matches any IPv6 pattern
    return ipv6Patterns.some(pattern => pattern.test(addr));
  });
}
