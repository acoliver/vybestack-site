export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with strict rules.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Email regex: local@domain.tld with strict rules
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Basic structure check
  if (!emailRegex.test(value)) return false;
  
  // Additional checks for invalid patterns
  const [localPart, domain] = value.split('@');
  
  // Reject double dots anywhere
  if (value.includes('..')) return false;
  
  // Reject local part starting or ending with dot
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Reject domain with underscore
  if (domain.includes('_')) return false;
  
  // Reject domain starting or ending with dot or hyphen
  if (domain.startsWith('.') || domain.startsWith('-') || 
      domain.endsWith('.') || domain.endsWith('-')) return false;
  
  // Validate domain segments
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false; // Need at least domain.tld
  
  // Check each domain segment
  for (const part of domainParts) {
    // Empty segments or segments starting/ending with hyphen
    if (!part || part.startsWith('-') || part.endsWith('-')) return false;
  }
  
  // Ensure TLD is valid (at least 2 chars)
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  return true;
}

/**
 * Validate US phone numbers with common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // options is currently unused but kept for API compatibility
  void options;
  
  // Extract digits only for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if it starts with +1 and remove it
  let cleanDigits = digits;
  if (cleanDigits.startsWith('1') && value.includes('+')) {
    cleanDigits = cleanDigits.substring(1);
  }
  
  // Must be exactly 10 digits for US phone number
  if (cleanDigits.length !== 10) return false;
  
  // Validate area code - cannot start with 0 or 1
  const areaCode = cleanDigits.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check format patterns - should match valid US phone formats
  const validPatterns = [
    /^\+?1?\s*\(\s*\d{3}\s*\)\s*\d{3}[-.\s]?\d{4}$/, // (212) 555-7890
    /^\+?1?\s*\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/, // 212-555-7890
    /^\+?1?\s*\d{10}$/, // 2125557890
  ];
  
  // Normalize by removing extra spaces for pattern matching
  const normalizedValue = value.replace(/\s+/g, ' ').trim();
  
  return validPatterns.some(pattern => pattern.test(normalizedValue));
}

/**
 * Validate Argentine phone numbers (landlines and mobiles).
 * Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Format: [+54] [9] 0?AreaCode SubscriberNumber
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all separators for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Match pattern for Argentine phone numbers
  const pattern = /^(?:\+54)?(?:9)?0?(\d{2,4})(\d{6,8})$/;
  
  if (!pattern.test(cleanNumber)) return false;
  
  // If country code is omitted, must start with trunk prefix 0
  if (!cleanNumber.startsWith('+54') && !cleanNumber.startsWith('0')) return false;
  
  // Extract components
  const match = cleanNumber.match(/^(?:\+54)?(9)?0?(\d{2,4})(\d{6,8})$/);
  if (!match) return false;
  
  const [, mobileIndicator, areaCode, subscriberNumber] = match;
  
  // Area code: 2-4 digits, leading digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4 || areaCode[0] === '0') return false;
  
  // Subscriber number: 6-8 digits total
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  // If mobile indicator is present, it should be '9'
  if (mobileIndicator && mobileIndicator !== '9') return false;
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must contain at least one letter
  const nameRegex = /^[\p{L}\p{M}'-]+(?:[\s\p{L}\p{M}'-]+)*$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Ensure there's at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
// Reject digits and common symbols
  const hasInvalidChars = /[0-9@#$%&*+=<>{}[\]|/]/.test(value);
  if (hasInvalidChars) return false;
  
  return true;
}

/**
 * Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleanNumber)) return false;
  
  // Check Visa (13 or 16 digits, starts with 4)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  // Check Mastercard (16 digits, starts with 51-55, or 2221-2720)
  const mastercardRegex16 = /^5[1-5]\d{14}$/;
  const mastercardRegex2221 = /^2(2[2-9]\d{12}|[3-6]\d{13}|7[01]\d{12}|720\d{12})$/;
  const mastercardRegex = new RegExp(`^(${mastercardRegex16.source.slice(1, -1)}|${mastercardRegex2221.source.slice(1, -1)})$`);
  // Check American Express (15 digits, starts with 34 or 37)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any card type
  if (!(visaRegex.test(cleanNumber) || 
        mastercardRegex.test(cleanNumber) || 
        amexRegex.test(cleanNumber))) {
    return false;
  }
  
  // Perform Luhn checksum
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cleanNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cleanNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
