/**
 * Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Split on sentence terminators followed by optional spaces
  const sentences = text.split(/([.?!])(\s*)/);
  
  const result = [];
  let capitalizeNext = true;
  
  for (let i = 0; i < sentences.length; i++) {
    let part = sentences[i];
    
    // If this is a sentence terminator, add it and set next for capitalization
    if (/[.?!]/.test(part)) {
      result.push(part);
      capitalizeNext = true;
      continue;
    }
    
    // If this is whitespace, add one space
    if (/^\s+$/.test(part)) {
      result.push(' ');
      continue;
    }
    
    // If we need to capitalize this sentence part
    if (capitalizeNext && part.length > 0) {
      // Find the first letter and capitalize it
      const firstLetterIndex = part.search(/[a-zA-Z]/);
      if (firstLetterIndex !== -1) {
        part = part.slice(0, firstLetterIndex) + 
               part.charAt(firstLetterIndex).toUpperCase() + 
               part.slice(firstLetterIndex + 1);
      }
      capitalizeNext = false;
    }
    
    result.push(part);
  }
  
  return result.join('');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // URL regex - matches http(s)://www.xxx or http(s)://xxx or www.xxx
  const urlRegex = /\bhttps?:\/\/[^\s/$.?#].[^\s]*|www\.[^\s/$.?#].[^\s]*/gi;
  
  const matches = text.match(urlRegex);
  if (!matches) return [];
  
  // Remove trailing punctuation while preserving valid URLs
  return matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?)\]}]+$/, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  // Replace http:// with https:// globally
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return text;
  
  return text.replace(/\bhttp:\/\/example\.com(\/docs\/[^\s?#]+)(?=[^\s]*$)/gi, (match, docsPath) => {
    // Check if path contains dynamic hints or legacy extensions
    const dynamicHints = /(cgi-bin|[?&]|\.jsp$|\.php$|\.asp$|\.aspx$|\.do$|\.cgi$|\.pl$|\.py$)/i;
    if (dynamicHints.test(docsPath)) {
      return 'https://docs.example.com' + docsPath;
    }
    
    return 'https://docs.example.com' + docsPath;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Match mm/dd/yyyy format and extract year
  const match = value.match(/^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (match && match[3]) {
    const year = match[3];
    // Additional validation for reasonable year range (optional)
    if (year >= '1900' && year <= '2100') {
      return year;
    }
  }
  
  return 'N/A';
}
