import type { ReportData, RenderOptions, Formatter } from '../types.js';

/**
 * Format amount as currency with exactly two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate total from all entries
 */
function calculateTotal(data: ReportData): number {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Render report in plain text format
 */
export function renderText(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(data.title);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('Entries:');
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    lines.push(`Total: ${formatAmount(calculateTotal(data))}`);
  }

  return lines.join('\n');
}

/**
 * Text formatter implementing the Formatter interface
 */
export const textFormatter: Formatter = {
  render: renderText,
};
