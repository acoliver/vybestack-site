/**
 * Report data model
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Rendering options
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Formatter interface for consistent API across formats
 */
export interface Formatter {
  render(data: ReportData, options: RenderOptions): string;
}
