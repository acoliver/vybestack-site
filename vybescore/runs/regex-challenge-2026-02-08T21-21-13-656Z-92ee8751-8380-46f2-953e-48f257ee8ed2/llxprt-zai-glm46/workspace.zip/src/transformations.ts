/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after .?!
 * - Ensures exactly one space between sentences
 * - Collapses extra spaces
 * - Tries to preserve abbreviations
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  let result = text.replace(/\s+/g, ' ').trim();

  // Ensure exactly one space after sentence terminators
  result = result.replace(/([.!?])(?=[^\s])/g, '$1 ');

  // Capitalize first character of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Capitalize after sentence terminators, but be careful with abbreviations
  // Common abbreviations that should NOT trigger capitalization
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'i.e', 'e.g', 'St', 'Ave', 'Blvd', 'Rd'];

  // Split into potential sentences and capitalize
  result = result.replace(/([.!?])\s+([a-z])/g, (match, terminator, letter, offset) => {
    // Check if this might be an abbreviation
    const beforeMatch = result.substring(Math.max(0, offset - 10), offset);

    // If the word before the period is a common abbreviation, don't capitalize
    const wordBefore = beforeMatch.split(/\s+/).pop() || '';
    if (abbreviations.some(abbr => wordBefore.toLowerCase().startsWith(abbr.toLowerCase()))) {
      return match;
    }

    return terminator + ' ' + letter.toUpperCase();
  });

  return result;
}

/**
 * Find URLs in the text, returning them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern: protocol://domain/path?query
  // Domain: letters, digits, hyphens, dots
  // Path: various characters
  // Exclude trailing punctuation: .,?!;:
  const urlRegex = /https?:\/\/[^\s<>(){}"]+(?<![,?!.;:])/g;

  const matches = text.match(urlRegex);

  if (!matches) {
    return [];
  }

  // Additional cleanup: remove any trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[,?!.;:]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when it's not already https
  return text.replace(/http:\/\/(?!https:)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - For /docs/ paths, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const exampleUrlRegex = /(https?):\/\/example\.com(\/[^\s<>(){}"]*)/gi;

  return text.replace(exampleUrlRegex, (match, protocol, path) => {
    // Always upgrade to https
    const newProtocol = 'https';

    // Check if path has dynamic hints or legacy extensions
    const dynamicHints = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];

    // Check for query strings
    const hasQueryString = path.includes('?') || path.includes('&') || path.includes('=');

    // Check for legacy extensions or dynamic hints
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));

    // If path starts with /docs/ and no dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasQueryString && !hasDynamicHint) {
      return `${newProtocol}://docs.example.com${path}`;
    }

    // Otherwise just upgrade the protocol
    return `${newProtocol}://example.com${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;

  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, yearStr] = match;

  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);

  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }

  // Validate reasonable year range (optional, but practical)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }

  return yearStr;
}
