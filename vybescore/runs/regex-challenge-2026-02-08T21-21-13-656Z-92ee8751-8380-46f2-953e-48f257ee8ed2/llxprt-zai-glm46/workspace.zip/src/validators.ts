export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 * - Accepts typical addresses like name@tag@example.co.uk
 * - Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain.tld
  // Local part: letters, digits, dots, hyphens, underscores, but no consecutive dots
  // Domain: letters, digits, hyphens, dots (no underscores)
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;

  if (!emailRegex.test(value)) {
    return false;
  }

  // Additional checks
  const [local, domain] = value.split('@');

  // No double dots in local part
  if (local.includes('..')) {
    return false;
  }

  // No trailing dot in local part
  if (local.endsWith('.')) {
    return false;
  }

  // No leading dot in local part
  if (local.startsWith('.')) {
    return false;
  }

  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }

  // No double dots in domain
  if (domain.includes('..')) {
    return false;
  }

  // Domain must have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }

  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }

  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Formats: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');

  // Note: options parameter reserved for future extensions (e.g., allowExtensions)
  void options;

  // Check for optional +1 prefix
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.slice(1);
  }

  // Must be exactly 10 digits
  if (digits.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digits.slice(0, 3);

  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Exchange code (digits 4-6) cannot start with 0 or 1
  const exchangeCode = digits.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }

  return true;
}

/**
 * Validate Argentine phone numbers for landlines and mobiles.
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');

  // Pattern breakdown:
  // Optional +54 country code
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber number: 6-8 digits
  const argentinaPhoneRegex = /^(?:\+54)?(?:0)?([1-9]\d{1,3})(?:9)?(\d{6,8})$/;

  const match = cleaned.match(argentinaPhoneRegex);

  if (!match) {
    return false;
  }

  const [, areaCode, subscriberNumber] = match;

  // Check area code is 2-4 digits (already enforced by regex)
  // Check subscriber number is 6-8 digits (already enforced by regex)

  // If country code is omitted, trunk prefix must be present
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = cleaned.startsWith('0');

  if (!hasCountryCode && !hasTrunkPrefix) {
    // When no country code, must start with 0 trunk prefix
    return false;
  }

  // Total digits check (excluding country code and trunk prefix)
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }

  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and strange names like X Æ A-12.
 */
export function isValidName(value: string): boolean {
  // Must have at least 2 characters
  if (value.length < 2) {
    return false;
  }

  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(value)) {
    return false;
  }

  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }

  // Must have at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }

  // Reject names that are just symbols/spaces
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }

  // No consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Luhn algorithm checksum for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;

  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    isEven = !isEven;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx).
 * Checks prefix, length, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;

  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;

  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;

  const validLength = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);

  if (!validLength) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
