/**
 * Find words starting with the prefix, excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  // Word boundary at start, then prefix, then more word characters
  const pattern = new RegExp(`\\b${escapeRegex(prefix)}\\w+`, 'gi');

  const matches = text.match(pattern) || [];

  // Filter out exceptions (case-insensitive)
  const filtered = matches.filter(
    word => !exceptions.some(exception => exception.toLowerCase() === word.toLowerCase())
  );

  // Remove duplicates while preserving order
  const unique = [...new Set(filtered)];

  return unique;
}

/**
 * Escape special regex characters in a string.
 */
function escapeRegex(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = escapeRegex(token);
  const results: string[] = [];

  // Find all occurrences of the token
  const pattern = new RegExp(escapedToken, 'g');
  let match;

  while ((match = pattern.exec(text)) !== null) {
    const index = match.index;

    // Check if token is not at the start of the string
    if (index > 0) {
      // Check if preceded by a digit
      const charBefore = text[index - 1];
      if (/\d/.test(charBefore)) {
        // Include the digit in the result
        results.push(charBefore + token);
      }
    }
  }

  return results;
}

/**
 * Validate passwords according to strong password policy:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length
  if (value.length < 10) {
    return false;
  }

  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // At least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // At least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // At least one symbol (non-word character)
  if (!/[\W_]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (e.g., abab, 123123)
  // This checks for patterns of length 2-4 that repeat immediately
  for (let len = 2; len <= 4; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const segment = value.substring(i, i + len);
      const nextSegment = value.substring(i + len, i + len * 2);

      if (segment === nextSegment) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses don't match.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - 8 groups of 1-4 hex digits separated by colons
  // - Can use :: to represent consecutive groups of zeros
  // - Cannot be an IPv4 address

  // First, check if it's an IPv4 address (should return false for these)
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }

  // IPv6 patterns - search within the string, not exact match
  // Full form: 8 groups of 1-4 hex digits
  const ipv6Full = /(?:^|\s)([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:\s|$)/;

  // Compressed form with :: (can appear once)
  const ipv6Compressed = /(?:^|\s)([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}(?:\s|$)/;

  // IPv6 with embedded IPv4 (last two groups can be IPv4)
  const ipv6EmbeddedIPv4 = /(?:^|\s)([0-9a-fA-F]{1,4}:){6}(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?:\s|$)/;

  // Compressed IPv6 with embedded IPv4
  const ipv6CompressedEmbeddedIPv4 = /(?:^|\s)([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})(?:\s|$)/;

  // Also check for simpler patterns that might be in the middle of text
  const ipv6InText = /[0-9a-fA-F]{1,4}:[0-9a-fA-F:]+/;

  // Check if any IPv6 pattern matches
  return ipv6Full.test(value) ||
         ipv6Compressed.test(value) ||
         ipv6EmbeddedIPv4.test(value) ||
         ipv6CompressedEmbeddedIPv4.test(value) ||
         ipv6InText.test(value);
}
