import { readFileSync } from 'node:fs';
import { ReportData } from '../types.js';

export interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArgs(argv: string[]): CliArgs {
  if (argv.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = argv[2];
  
  // Find format flag
  const formatIndex = argv.indexOf('--format');
  if (formatIndex === -1 || formatIndex + 1 >= argv.length) {
    throw new Error('--format flag is required');
  }
  const format = argv[formatIndex + 1];
  
  // Find output flag (optional)
  const outputIndex = argv.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < argv.length ? argv[outputIndex + 1] : undefined;
  
  // Check for includeTotals flag
  const includeTotals = argv.includes('--includeTotals');

  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

export function loadReportData(path: string): ReportData {
  try {
    const fileContent = readFileSync(path, 'utf-8');
    const data = JSON.parse(fileContent) as unknown;
    
    if (!validateReportData(data)) {
      throw new Error('Invalid report data structure');
    }
    
    return data;
  } catch (error: unknown) {
    if (error instanceof Error && error.message.includes('ENOENT')) {
      throw new Error(`File not found: ${path}`);
    }
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file: ${path}`);
    }
    throw error;
  }
}

function validateReportData(data: unknown): data is ReportData {
  if (
    typeof data !== 'object' ||
    data === null ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    return false;
  }

  const reportData = data as Record<string, unknown>;

  if (
    typeof reportData.title !== 'string' ||
    typeof reportData.summary !== 'string' ||
    !Array.isArray(reportData.entries)
  ) {
    return false;
  }

  for (const entry of reportData.entries) {
    if (
      typeof entry !== 'object' ||
      entry === null ||
      !('label' in entry) ||
      !('amount' in entry)
    ) {
      return false;
    }

    const entryData = entry as Record<string, unknown>;

    if (
      typeof entryData.label !== 'string' ||
      typeof entryData.amount !== 'number'
    ) {
      return false;
    }
  }

  return true;
}