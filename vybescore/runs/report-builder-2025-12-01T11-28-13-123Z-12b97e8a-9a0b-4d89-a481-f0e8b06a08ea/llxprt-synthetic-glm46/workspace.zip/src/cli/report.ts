#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { parseArgs, loadReportData } from './args.js';
import { getRenderer } from '../formats/index.js';

function main(): void {
  try {
    const args = parseArgs(process.argv);
    const reportData = loadReportData(args.dataPath);
    const renderer = getRenderer(args.format);
    
    const result = renderer(reportData, { includeTotals: args.includeTotals });
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, result, 'utf-8');
      console.error(`Report written to ${args.outputPath}`);
    } else {
      console.log(result);
    }
  } catch (error: unknown) {
    console.error('Error:', error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
