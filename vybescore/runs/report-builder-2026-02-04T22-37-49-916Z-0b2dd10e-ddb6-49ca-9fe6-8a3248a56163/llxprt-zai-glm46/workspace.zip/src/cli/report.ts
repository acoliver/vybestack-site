#!/usr/bin/env node

import * as fs from 'fs';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const formatters: Record<string, (data: ReportData, options: RenderOptions) => string> = {
  markdown: renderMarkdown,
  text: renderText,
};

function parseArgs(args: string[]): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  let dataFile = '';
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--')) {
      if (dataFile) {
        throw new Error(`Unexpected argument: ${arg}`);
      }
      dataFile = arg;
    } else {
      throw new Error(`Unknown option: ${arg}`);
    }
  }

  if (!dataFile) {
    throw new Error('Data file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Missing or invalid "entries" field');
  }

  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid entry: must be an object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid entry: missing or invalid "label" field');
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid entry: missing or invalid "amount" field');
    }
  }

  return true;
}

function main() {
  try {
    const args = process.argv.slice(2);

    const { dataFile, format, outputPath, includeTotals } = parseArgs(args);

    if (!formatters[format]) {
      console.error(`Unsupported format: ${format}`);
      console.error(`Supported formats: ${Object.keys(formatters).join(', ')}`);
      process.exit(1);
    }

    let fileContent: string;
    try {
      fileContent = fs.readFileSync(dataFile, 'utf-8');
    } catch (error) {
      console.error(`Error reading file: ${dataFile}`);
      if (error instanceof Error) {
        console.error(error.message);
      }
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error parsing JSON: ${dataFile}`);
      if (error instanceof Error) {
        console.error(error.message);
      }
      process.exit(1);
    }

    if (!validateReportData(jsonData)) {
      console.error('Invalid report data structure');
      process.exit(1);
    }

    const options: RenderOptions = { includeTotals };
    const formatter = formatters[format];
    const output = formatter(jsonData, options);

    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();

