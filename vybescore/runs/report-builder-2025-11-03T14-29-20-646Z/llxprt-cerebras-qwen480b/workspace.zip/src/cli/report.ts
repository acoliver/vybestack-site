import { readFile } from 'fs/promises';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Map of format names to their render functions
const formatRenderers = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArguments {
  dataFile: string;
  format: keyof typeof formatRenderers;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArguments {
  if (args.length < 2) {
    throw new Error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  let format: keyof typeof formatRenderers | undefined;
  let outputFile: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i + 1] as keyof typeof formatRenderers;
      i++; // Skip the next argument as it's the format value
    } else if (args[i] === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      outputFile = args[i + 1];
      i++; // Skip the next argument as it's the output file path
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${args[i]}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (!formatRenderers[format]) {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataFile, format, outputFile, includeTotals };
}

async function readDataFile(filePath: string): Promise<ReportData> {
  try {
    const content = await readFile(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Missing or invalid title field');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Missing or invalid summary field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid entries field');
    }
    
    for (const entry of data.entries) {
      if (typeof entry.label !== 'string') {
        throw new Error('Missing or invalid label in entry');
      }
      if (typeof entry.amount !== 'number') {
        throw new Error('Missing or invalid amount in entry');
      }
    }
    
    return data;
  } catch (err) {
    if (err instanceof SyntaxError) {
      throw new Error('Invalid JSON in data file');
    }
    throw err;
  }
}

async function main() {
  try {
    const args = parseArguments(process.argv.slice(2));
    const data = await readDataFile(args.dataFile);
    const output = formatRenderers[args.format](data, { includeTotals: args.includeTotals });
    
    if (args.outputFile) {
      // Use writeFile to output to a file
      const { writeFile } = await import('fs/promises');
      await writeFile(args.outputFile, output);
    } else {
      // Output to stdout
      console.log(output);
    }
  } catch (err) {
    console.error(err instanceof Error ? err.message : 'Unknown error');
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}