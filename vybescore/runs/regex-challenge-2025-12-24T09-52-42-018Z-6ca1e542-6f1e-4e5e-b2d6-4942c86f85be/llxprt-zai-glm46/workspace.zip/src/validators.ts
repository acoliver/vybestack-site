export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts: name+tag@example.co.uk, user.name@example.com
 * Rejects: double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Local part: alphanumeric, dots, hyphens, underscores, plus
  // Domain: alphanumeric labels with dots, no underscores
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?:(?!.*\.\.)[a-zA-Z0-9-]+\.)*[a-zA-Z0-9-]+\.[a-zA-Z]{2,}$/;

  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) return false;

  // No consecutive dots in local part
  if (value.includes('..')) return false;

  // No trailing dot before @
  const atPos = value.indexOf('@');
  if (value[atPos - 1] === '.') return false;

  // Domain cannot start or end with dot
  const domain = value.slice(atPos + 1);
  if (domain.startsWith('.') || domain.endsWith('.')) return false;

  // Domain cannot have underscores
  if (domain.includes('_')) return false;

  // TLD must be at least 2 chars and only letters
  const lastDotIndex = domain.lastIndexOf('.');
  const tld = domain.slice(lastDotIndex + 1);
  if (!/^[a-zA-Z]{2,}$/.test(tld)) return false;

  return true;
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: area codes starting with 0 or 1, too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Options parameter exists for future extensibility (e.g., allowExtensions)
  void options;

  if (!value || typeof value !== 'string') return false;

  // Remove spaces and parentheses for parsing
  const cleaned = value.replace(/[\s()]/g, '');

  // Check for optional +1 country code
  let digits = cleaned;
  if (digits.startsWith('+1')) {
    digits = digits.slice(2);
  } else if (digits.length === 11 && digits.startsWith('1')) {
    // If 11 digits and starts with 1, it's likely country code
    digits = digits.slice(1);
  }

  // Extract just the digits
  const digitOnly = digits.replace(/\D/g, '');

  // Must have 10 digits (3 area code + 7 number)
  if (digitOnly.length !== 10) return false;

  // Area code cannot start with 0 or 1
  const areaCode = digitOnly.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Exchange code (first digit of the 7-digit number) cannot be 0 or 1
  if (digitOnly[3] === '0' || digitOnly[3] === '1') return false;

  return true;
}

/**
 * Validates Argentine phone numbers.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces, hyphens, and parentheses for validation
  const cleaned = value.replace(/[\s()-]/g, '');

  // Main regex pattern for Argentine phone numbers
  // Optional +54 country code
  // Optional 0 trunk prefix (required if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  const argentinaPhoneRegex = /^(?:\+54)?0?9?([1-9]\d{1,3})(\d{6,8})$/;

  const match = cleaned.match(argentinaPhoneRegex);
  if (!match) return false;

  const [, areaCode, subscriber] = match;

  // If no country code, trunk prefix (0) must be present before area code
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = /^\+54?0/.test(cleaned) || cleaned.startsWith('0');

  if (!hasCountryCode && !hasTrunkPrefix) return false;

  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) return false;

  // Validate subscriber number length (6-8 digits)
  if (subscriber.length < 6 || subscriber.length > 8) return false;

  return true;
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and strange names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const trimmed = value.trim();

  if (trimmed.length === 0) return false;

  // Name regex: unicode letters, apostrophes, hyphens, spaces
  // Must have at least one letter
  const nameRegex = /^[\p{L}'-]+(?:[\s][\p{L}'-]+)*$/u;

  if (!nameRegex.test(trimmed)) return false;

  // Must contain at least one letter (not just symbols/spaces)
  const hasLetter = /[\p{L}]/u.test(trimmed);
  if (!hasLetter) return false;

  // Reject if contains digits
  if (/\d/.test(trimmed)) return false;

  // Reject common symbols that shouldn't be in names
  const invalidChars = /["#$%&()*+,.:;<=>?@[\\\]^_`{|}~0-9]/;
  if (invalidChars.test(trimmed)) return false;

  return true;
}

/**
 * Helper function for Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);

  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx with correct prefix and length, plus Luhn check.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be only digits
  if (!/^\d+$/.test(cleaned)) return false;

  // Card type patterns
  const patterns = [
    { name: 'Visa', prefix: /^4/, lengths: [13, 16, 19] },
    { name: 'Mastercard', prefix: /^5[1-5]|^2[2-7]/, lengths: [16] },
    { name: 'AmEx', prefix: /^3[47]/, lengths: [15] },
  ];

  // Check against known patterns
  let valid = false;
  for (const pattern of patterns) {
    if (pattern.prefix.test(cleaned) && pattern.lengths.includes(cleaned.length)) {
      valid = true;
      break;
    }
  }

  if (!valid) return false;

  // Run Luhn check
  return runLuhnCheck(cleaned);
}
