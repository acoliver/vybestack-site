/**
 * Capitalizes the first character of each sentence.
 * - Capitalizes first letter after sentence-ending punctuation (.!?)
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces
 * - Tries to preserve abbreviations (single letter followed by dot)
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // First, collapse multiple spaces into single space
  let result = text.replace(/\s+/g, ' ').trim();

  // Capitalize first character of the string
  result = result.replace(/^[a-z]/, (c) => c.toUpperCase());

  // Capitalize after sentence-ending punctuation (. ! ?)
  // Use a regex that handles the punctuation directly
  result = result.replace(/([.!?]\s+)([a-z])/g, (_, punct, letter) => punct + letter.toUpperCase());

  // Also handle the case where there's no space after punctuation
  result = result.replace(/([.!?])([a-z])/g, (_, punct, letter) => punct + ' ' + letter.toUpperCase());

  return result;
}

/**
 * Extracts all URLs from text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // URL regex pattern
  // Matches http:// or https:// followed by domain and path
  const urlRegex = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s\])}"',!?]*)?/gi;

  const matches = text.match(urlRegex) || [];

  // Remove trailing punctuation
  return matches.map((url) => url.replace(/[.,;!?]+$/, ''));
}

/**
 * Converts all http:// URLs to https://
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';

  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs for docs.example.com.
 * - Upgrades http to https
 * - For example.com URLs with /docs/ path, rewrites to docs.example.com
 * - Skips host rewrite for dynamic URLs (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';

  return text.replace(/https?:\/\/example\.com(\/[^\s]*)?/gi, (match, path) => {
    // Always upgrade to https
    const finalUrl = 'https://example.com' + (path || '');

    // Check if we should skip host rewrite
    if (path) {
      // Check for dynamic hints
      const hasQueryString = /[?&=]/.test(path);
      const hasCgiBin = path.includes('/cgi-bin');
      const hasLegacyExt = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i.test(path);

      if (hasQueryString || hasCgiBin || hasLegacyExt) {
        // Only upgrade scheme, don't rewrite host
        return finalUrl;
      }

      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        return 'https://docs.example.com' + path;
      }
    }

    // Just upgrade to https
    return finalUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or date is not valid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Match mm/dd/yyyy format exactly
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  if (!match) return 'N/A';

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month
  if (month < 1 || month > 12) return 'N/A';

  // Validate day based on month
  const daysInMonth = [
    31, // Jan
    29, // Feb (leap year check not required per spec)
    31, // Mar
    30, // Apr
    31, // May
    30, // Jun
    31, // Jul
    31, // Aug
    30, // Sep
    31, // Oct
    30, // Nov
    31, // Dec
  ];

  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';

  return year;
}
