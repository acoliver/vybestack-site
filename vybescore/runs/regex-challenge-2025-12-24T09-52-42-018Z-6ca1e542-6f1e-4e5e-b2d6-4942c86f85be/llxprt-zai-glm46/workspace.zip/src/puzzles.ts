/**
 * Finds words starting with a prefix, excluding exception words.
 * Words are sequences of word characters (letters, digits, underscores).
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Build regex to find words starting with prefix
  // \b word boundary, then prefix, then more word chars
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'g');

  const matches = text.match(pattern) || [];

  // Filter out exceptions
  return matches.filter((word) => !exceptions.includes(word));
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Returns the full match including the digit (e.g., "1foo" for token "foo").
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Find digit followed by token, not at the start
  // This returns the full match including the digit
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');

  const matches = text.match(pattern) || [];

  // Filter out matches that are at the start of the string
  return matches.filter(match => text.indexOf(match) > 0);
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Minimum length check
  if (value.length < 10) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for uppercase
  if (!/[A-Z]/.test(value)) return false;

  // Check for lowercase
  if (!/[a-z]/.test(value)) return false;

  // Check for digit
  if (!/\d/.test(value)) return false;

  // Check for symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) return false;

  // Check for repeated sequences of length 2 or more
  // e.g., "abab", "123123", "abcabc"
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const pattern = value.slice(i, i + len);
      const nextSequence = value.slice(i + len, i + 2 * len);
      if (pattern === nextSequence) {
        return false;
      }
    }
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand :: notation).
 * IPv4 addresses should not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // First, let's be more precise about IPv6 patterns
  // IPv6 can contain:
  // - Full form: 8 groups of 1-4 hex digits separated by colons
  // - Compressed form: :: can replace one or more consecutive groups of zeros
  // - Can have IPv4 embedded at the end (e.g., ::ffff:192.168.1.1)

  // Check if it looks like IPv4 and NOT IPv6
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // Check for IPv6 pattern (including shorthand)
  // We need to be more precise - IPv6 should have colons and hex groups
  const ipv6Pattern = /(?:^|[\s[\]])([0-9a-fA-F:]+)(?:$|[\s[\]])/;

  const match = value.match(ipv6Pattern);
  if (!match) return false;

  const potentialIp = match[1];

  // More thorough IPv6 validation
  // Must have at least one colon
  if (!potentialIp.includes(':')) return false;

  // Count colons - IPv6 should have 2-7 colons (full form has 7, compressed has fewer)
  const colonCount = (potentialIp.match(/:/g) || []).length;
  if (colonCount < 2 || colonCount > 7) return false;

  // Check for valid IPv6 structure
  // Groups of hex digits separated by colons, optionally with :: for compression
  const ipv6GroupPattern = /^[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4})*::?[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{1,4})*$/;

  if (!ipv6GroupPattern.test(potentialIp)) {
    // Check for IPv4 embedded in IPv6
    const embeddedIpPattern = /^[0-9a-fA-F:]+:(?:\d{1,3}\.){3}\d{1,3}$/;
    if (!embeddedIpPattern.test(potentialIp)) {
      return false;
    }
  }

  // Make sure it's not just IPv4 with some colons around
  if (potentialIp.match(/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/)) {
    // If it has IPv4, it should have other IPv6 elements
    const hexParts = potentialIp.split(':').filter(p => p && !p.match(/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/));
    if (hexParts.length === 0) return false;
  }

  // Make sure we have some hex content (not just colons)
  const hexContent = potentialIp.replace(/:/g, '');
  if (hexContent.length === 0) return false;

  return true;
}
