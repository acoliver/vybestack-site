/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  ObserverR
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = 
    typeof _equal === 'function' ? _equal : 
    _equal === false ? () => false :
    _equal === true ? (lhs, rhs) => lhs === rhs :
    undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
    dependents: []
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track multiple dependents instead of just one
      if (s.dependents && !s.dependents.includes(observer)) {
        s.dependents.push(observer)
      }
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      
      // Update all dependents
      if (s.dependents) {
        s.dependents.forEach(dep => {
          if ('updateFn' in dep && dep.updateFn) {
            updateObserver(dep as Observer<T>)
          }
        })
      }
    }
    return s.value
  }

  return [read, write]
}
