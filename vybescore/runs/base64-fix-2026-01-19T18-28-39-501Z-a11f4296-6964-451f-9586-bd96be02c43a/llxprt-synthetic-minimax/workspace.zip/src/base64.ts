/**
 * Encode plain text to Base64 using standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and uses standard Base64 alphabet.
 */
export function decode(input: string): string {
  // Validate Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Add padding if missing
  const normalized = input + '==='.slice((input.length + 3) % 4);

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
