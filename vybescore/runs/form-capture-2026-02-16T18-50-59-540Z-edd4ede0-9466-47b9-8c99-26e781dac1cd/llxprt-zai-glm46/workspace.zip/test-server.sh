#!/bin/bash
# Manual server test script

echo "Starting server..."
node dist/server.js &
SERVER_PID=$!

echo "Waiting for server to start..."
sleep 2

echo "Testing GET /..."
curl -s http://localhost:3535/ | head -20

echo -e "\n\nTesting POST /submit with valid data..."
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Test&LastName=User&streetAddress=123+Test+St&city=Test+City&stateProvince=Test+State&postalCode=12345&country=Test+Country&email=test@example.com&phone=1234567890" \
  -w "\nHTTP Status: %{http_code}\nRedirect: %{redirect_url}\n"

echo -e "\n\nTesting GET /thank-you..."
curl -s http://localhost:3535/thank-you | head -20

echo -e "\n\nStopping server..."
kill $SERVER_PID 2>/dev/null || true
wait $SERVER_PID 2>/dev/null || true

echo "Test complete!"
