import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { startServer } from '../../src/server';

let server: ReturnType<typeof import('http').Server>;
let app: import('express').Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const result = await startServer();
  app = result.app;
  server = result.server;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);
    
    const $ = cheerio.load(response.text);
    
    // Check for all form fields with proper labels and IDs
    const fields = [
      { id: 'firstName', label: 'First name' },
      { id: 'lastName', label: 'Last name' },
      { id: 'streetAddress', label: 'Street address' },
      { id: 'city', label: 'City' },
      { id: 'stateProvince', label: 'State / Province / Region' },
      { id: 'postalCode', label: 'Postal / Zip code' },
      { id: 'country', label: 'Country' },
      { id: 'email', label: 'Email' },
      { id: 'phone', label: 'Phone number' },
    ];

    fields.forEach((field) => {
      const input = $(`#${field.id}`);
      const label = $(`label[for="${field.id}"]`);
      
      expect(input.length).toBe(1);
      expect(label.length).toBe(1);
      expect(label.text()).toContain(field.label);
      expect(input.attr('name')).toBe(field.id);
    });

    // Check form action
    const form = $('form');
    expect(form.attr('action')).toBe('/submit');
    expect(form.attr('method')).toBe('post');
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app)
      .post('/submit')
      .send({})
      .type('form');
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    const errorList = $('.error-list');
    expect(errorList.length).toBe(1);
    expect(errorList.find('li').length).toBeGreaterThan(0);
  });

  it('persists submission and redirects', async () => {
    // Clean up database file before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app)
      .post('/submit')
      .send(formData)
      .type('form');

    // Check for redirect
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('accepts international phone and postal formats', async () => {
    const formData = {
      firstName: 'Maria',
      lastName: 'Garcia',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria.garcia@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app)
      .post('/submit')
      .send(formData)
      .type('form');

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('validates email format', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'invalid-email',
        phone: '1234567890',
      })
      .type('form');

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/email/i);
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);
    
    const $ = cheerio.load(response.text);
    const thankYouCard = $('.thankyou-card');
    expect(thankYouCard.length).toBe(1);
    
    // Check for humorous content
    const pageText = $('.thankyou-card').text().toLowerCase();
    expect(pageText).toMatch(/stranger|internet|identity|spam/);
    
    // Check for link back to form
    const backLink = $('.thankyou-card a[href="/"]');
    expect(backLink.length).toBe(1);
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        // Missing required fields
        email: 'jane@example.com',
        phone: '1234567890',
      })
      .type('form');

    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check that entered values are preserved
    expect($('#firstName').attr('value')).toBe('Jane');
    expect($('#lastName').attr('value')).toBe('Smith');
    expect($('#email').attr('value')).toBe('jane@example.com');
  });
});
