import { readFileSync, writeFileSync } from 'fs';
import { ReportData, RenderOptions, FormatType } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: FormatType;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const args = argv.slice(2);
  const dataFile = args[0];
  
  if (!dataFile.endsWith('.json')) {
    console.error('Error: Input file must be a JSON file');
    process.exit(1);
  }

  let format: FormatType | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      
      if (nextArg !== 'markdown' && nextArg !== 'text') {
        console.error(`Error: Unsupported format '${nextArg}'. Supported formats: markdown, text`);
        process.exit(1);
      }
      
      format = nextArg as FormatType;
      i++;
    } else if (arg === '--output') {
      const nextArg = args[i + 1];
      if (!nextArg) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      
      outputPath = nextArg;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument '${arg}'`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return {
    dataFile,
    format,
    outputPath,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null || Array.isArray(data)) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  if (typeof reportData.title !== 'string' || !reportData.title.trim()) {
    throw new Error('Invalid JSON: "title" must be a non-empty string');
  }

  if (typeof reportData.summary !== 'string' || !reportData.summary.trim()) {
    throw new Error('Invalid JSON: "summary" must be a non-empty string');
  }

  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  if (reportData.entries.length === 0) {
    throw new Error('Invalid JSON: "entries" array cannot be empty');
  }

  const validatedEntries = reportData.entries.map((entry: unknown, index: number) => {
    if (typeof entry !== 'object' || entry === null || Array.isArray(entry)) {
      throw new Error(`Invalid JSON: entry at index ${index} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string' || !entryObj.label.trim()) {
      throw new Error(`Invalid JSON: entry at index ${index} must have a non-empty "label"`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry at index ${index} must have a valid "amount" number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries: validatedEntries
  };
}

function renderReport(data: ReportData, format: FormatType, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error(`Unsupported format '${format}'`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    // Read and parse JSON data
    let rawData: unknown;
    try {
      const fileContent = readFileSync(args.dataFile, 'utf-8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File '${args.dataFile}' not found`);
      } else if (error instanceof SyntaxError) {
        console.error('Error: Invalid JSON file');
      } else {
        console.error(`Error reading file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      }
      process.exit(1);
    }

    // Validate and normalize data
    let reportData: ReportData;
    try {
      reportData = validateReportData(rawData);
    } catch (error) {
      console.error(`Error: ${error instanceof Error ? error.message : 'Invalid data format'}`);
      process.exit(1);
    }

    // Render the report
    const options: RenderOptions = {
      includeTotals: args.includeTotals
    };

    const output = renderReport(reportData, args.format, options);

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing to file: ${error instanceof Error ? error.message : 'Unknown error'}`);
        process.exit(1);
      }
    } else {
      process.stdout.write(output);
    }

  } catch (error) {
    console.error(`Unexpected error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();