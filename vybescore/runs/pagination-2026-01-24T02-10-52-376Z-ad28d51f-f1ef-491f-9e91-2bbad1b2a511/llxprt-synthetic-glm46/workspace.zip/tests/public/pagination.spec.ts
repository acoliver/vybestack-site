import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination', () => {
  it('rejects invalid page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test negative page
    let response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
    
    // Test zero page
    response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
    
    // Test non-numeric page
    response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('rejects invalid limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test negative limit
    let response = await request(app).get('/inventory?limit=-5');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
    
    // Test zero limit
    response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
    
    // Test non-numeric limit
    response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('returns correct pagination structure', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('items');
    expect(response.body).toHaveProperty('page', 1);
    expect(response.body).toHaveProperty('limit', 3);
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
    
    // Verify items array has correct length
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeLessThanOrEqual(3);
    
    // Verify pagination metadata
    expect(typeof response.body.total).toBe('number');
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('correctly calculates offset for different pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get first page
    const firstPage = await request(app).get('/inventory?page=1&limit=3');
    expect(firstPage.status).toBe(200);
    
    // Get second page
    const secondPage = await request(app).get('/inventory?page=2&limit=3');
    expect(secondPage.status).toBe(200);
    
    // Ensure page numbers are correct
    expect(firstPage.body.page).toBe(1);
    expect(secondPage.body.page).toBe(2);
    
    // Ensure no overlapping items between pages
    const firstPageIds = firstPage.body.items.map((item: { id: number }) => item.id);
    const secondPageIds = secondPage.body.items.map((item: { id: number }) => item.id);
    
    const overlapping = firstPageIds.filter((id: number) => 
      secondPageIds.includes(id)
    );
    expect(overlapping).toHaveLength(0);
  });

  it('correctly sets hasNext based on remaining items', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get a page that should have more items
    const pageWithNext = await request(app).get('/inventory?page=1&limit=2');
    expect(pageWithNext.status).toBe(200);
    
    // Get total count to calculate if there should be next page
    const totalCount = await request(app).get('/inventory');
    const total = totalCount.body.total;
    
    // Validate hasNext logic
    const hasNext = (pageWithNext.body.page * pageWithNext.body.limit) < total;
    expect(pageWithNext.body.hasNext).toBe(hasNext);
  });
});