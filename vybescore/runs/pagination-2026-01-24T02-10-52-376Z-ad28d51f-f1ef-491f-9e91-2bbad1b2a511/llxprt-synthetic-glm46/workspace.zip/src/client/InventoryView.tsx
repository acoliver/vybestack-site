import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ currentPage, hasNextPage }: { currentPage: number; hasNextPage: boolean }): JSX.Element {
  const handlePrevious = (): void => {
    window.location.href = `/?page=${Math.max(1, currentPage - 1)}`;
  };

  const handleNext = (): void => {
    if (hasNextPage) {
      window.location.href = `/?page=${currentPage + 1}`;
    }
  };

  return (
    <nav aria-label="Pagination">
      <button 
        type="button" 
        onClick={handlePrevious} 
        disabled={currentPage <= 1}
      >
        Previous
      </button>
      <span style={{ margin: '0 16px' }}>Page {currentPage}</span>
      <button 
        type="button" 
        onClick={handleNext} 
        disabled={!hasNextPage}
      >
        Next
      </button>
    </nav>
  );
}

function getCurrentPageFromUrl(): number {
  if (typeof window === 'undefined') return 1;
  
  const urlParams = new URLSearchParams(window.location.search);
  const pageParam = urlParams.get('page');
  
  if (pageParam !== null) {
    const pageNumber = parseInt(pageParam, 10);
    return isNaN(pageNumber) || pageNumber < 1 ? 1 : pageNumber;
  }
  
  return 1;
}

export function InventoryView(): JSX.Element {
  const currentPage = getCurrentPageFromUrl();
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls currentPage={currentPage} hasNextPage={data.hasNext} />
    </section>
  );
}
