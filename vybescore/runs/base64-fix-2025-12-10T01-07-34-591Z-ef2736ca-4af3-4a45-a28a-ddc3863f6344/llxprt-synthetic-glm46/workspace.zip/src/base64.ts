/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check for invalid Base64 characters (anything not in A-Z, a-z, 0-9, +, /, =)
  if (!/^[A-Za-z0-9+/=]*$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check padding patterns
  const paddingIndex = input.indexOf('=');
  
  if (paddingIndex !== -1) {
    // If padding exists, it must be at the end and can only be 1 or 2 '=' characters
    if (paddingIndex !== input.length - 1 && paddingIndex !== input.length - 2) {
      throw new Error('Invalid Base64 input: padding must be at the end');
    }
    
    // Only allow trailing '=' characters after the first padding character
    const paddingSection = input.substring(paddingIndex);
    if (!/^={1,2}$/.test(paddingSection)) {
      throw new Error('Invalid Base64 input: invalid padding pattern');
    }
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
