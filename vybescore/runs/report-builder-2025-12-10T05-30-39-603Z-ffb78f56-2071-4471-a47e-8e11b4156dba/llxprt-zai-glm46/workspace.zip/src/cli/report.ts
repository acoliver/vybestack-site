#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  const cliArgs = args.slice(2);

  if (cliArgs.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = cliArgs[0];
  const formatIndex = cliArgs.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === cliArgs.length - 1) {
    console.error('Error: --format is required and must specify a format');
    process.exit(1);
  }

  const format = cliArgs[formatIndex + 1];
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format. Supported formats are: markdown, text');
    process.exit(1);
  }

  const outputIndex = cliArgs.indexOf('--output');
  const output = outputIndex !== -1 && outputIndex < cliArgs.length - 1 
    ? cliArgs[outputIndex + 1] 
    : undefined;

  const includeTotals = cliArgs.includes('--includeTotals');

  return {
    dataFile,
    format: format as 'markdown' | 'text',
    output,
    includeTotals
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: title must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: summary must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: entries must be an array');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry ${i}.label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry ${i}.amount must be a number`);
    }
  }

  return {
    title: obj.title,
    summary: obj.summary,
    entries: obj.entries
  };
}

function main() {
  try {
    const args = parseArguments(process.argv);

    // Read and parse JSON data
    let jsonContent: string;
    try {
      jsonContent = readFileSync(args.dataFile, 'utf8');
    } catch (readError) {
      console.error(`Error reading file ${args.dataFile}: ${readError instanceof Error ? readError.message : 'Unknown error'}`);
      process.exit(1);
    }
    
    let data: unknown;
    
    try {
      data = JSON.parse(jsonContent);
    } catch (parseError) {
      console.error(`Error parsing JSON file ${args.dataFile}: ${parseError instanceof Error ? parseError.message : 'Unknown error'}`);
      process.exit(1);
    }

    // Validate data structure
    const reportData = validateReportData(data);

    // Select renderer based on format
    const renderer = args.format === 'markdown' ? renderMarkdown : renderText;
    
    // Generate report
    const report = renderer.render(reportData, { includeTotals: args.includeTotals });

    // Output report
    if (args.output) {
      try {
        writeFileSync(args.output, report, 'utf8');
      } catch (error) {
        console.error(`Error writing to output file ${args.output}: ${error instanceof Error ? error.message : 'Unknown error'}`);
        process.exit(1);
      }
    } else {
      console.log(report);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();
