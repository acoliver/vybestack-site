/**
 * Capitalizes the first character of each sentence in the text.
 * Handles properly spacing between sentences and collapses extra spaces.
 * Preserves abbreviations when possible by checking for common patterns.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // List of common abbreviations and honorifics to avoid breaking sentences
  const abbreviations = [
    'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e',
    'Jan', 'Feb', 'Mar', 'Apr', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
    'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun', 'AM', 'PM'
  ];

  // Create a regex pattern for abbreviations to avoid breaking sentences at them
  const abbrevPattern = abbreviations.join('|');

  // Step 1: Standardize line breaks and remove extra whitespace
  let processedText = text
    .replace(/\r\n/g, '\n')  // Normalize line breaks
    .replace(/\s+/g, ' ')     // Collapse multiple spaces to single space
    .trim();

  // Step 2: We'll use a manual approach to split sentences while considering abbreviation exceptions
  // This helps preserve the original meaning and formatting of the text

  // Step 3: Temporarily replace abbreviation periods to avoid splitting
  const abbrevRegex = new RegExp(`\\b(${abbrevPattern})\\.`, 'g');
  const tempAbbrevMarker = '___ABBREVMARK___';
  processedText = processedText.replace(abbrevRegex, `$1${tempAbbrevMarker}`);

  // Step 4: Identify sentence boundaries using simple regex for ., ?, !
  const sentences: string[] = [];
  let currentSentence = '';
  let i = 0;

  while (i < processedText.length) {
    const char = processedText[i];

    currentSentence += char;

    // If we hit a sentence-ender
    if (['.', '!', '?'].includes(char)) {
      // Look ahead to see if we're at a real sentence boundary
      const nextChar = processedText[i + 1];
      if (nextChar && (nextChar === ' ' || nextChar === '\n')) {
        // Save the current sentence
        sentences.push(currentSentence);
        currentSentence = '';
        // Skip spaces after the punctuation
        while (i + 1 < processedText.length && processedText[i + 1] === ' ') {
          i++;
        }
      }
    }

    i++;
  }

  // Add any remaining text as the last sentence
  if (currentSentence.trim()) {
    sentences.push(currentSentence);
  }

  // Step 5: Capitalize each sentence
  const capitalizedSentences = sentences.map(sentence => {
    // Restore abbreviation markers
    sentence = sentence.replace(new RegExp(tempAbbrevMarker, 'g'), '.');

    // Trim and capitalize
    sentence = sentence.trim();
    if (sentence.length > 0) {
      sentence = sentence[0].toUpperCase() + sentence.slice(1);
    }
    return sentence;
  });

  // Step 6: Rejoin sentences with proper spacing
  let result = capitalizedSentences.join(' ');

  // Step 7: Final cleanup - fix any extra spaces that might remain
  result = result.replace(/\s+/g, ' ').trim();

  return result;
}

/**
 * Extracts URLs from the given text.
 * Returns an array of URLs without trailing punctuation.
 * Extracts both HTTP/HTTPS URLs and裸 domains (like example.com).
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // URL pattern that matches:
  // - http:// or https:// protocols
  // - www domains without protocol
  // - domain names with extensions
  // - IP addresses
  // - Common top-level domains
  const urlPattern = /(?:https?:\/\/|www\.|(?<!\w)[a-z0-9]([a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,}(?:\/[^\s]*)?/gi;

  // Find potential URLs in the text
  const matches = text.match(urlPattern);

  if (!matches) {
    return [];
  }

  // Clean up the matches to remove trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation like .,?!;: that's not part of the URL
    return url.replace(/[.,;:!?)]+$/g, '');
  });

  // Filter out empty strings and duplicates
  const uniqueUrls = [...new Set(cleanedUrls.filter(url => url.trim().length > 0))];

  return uniqueUrls;
}

/**
 * Replaces all http:// URL schemes with https:// while leaving existing HTTPS URLs unchanged.
 * Handles different variations of HTTP URLs while preserving the rest of the URL.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Replace http:// with https://, but not https:// (use negative lookbehind)
  // This regex matches "http://" not preceded by "s"
  return text.replace(/(?<!s)http:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Upgrades http:// to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic paths with cgi-bin, query strings, or legacy extensions
 * - Preserves nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Pattern to match URLs with various schemes, focusing on example.com
  // We'll process each match individually to apply the complex transformation rules
  const urlRegex = /(https?:\/\/)(example\.com)([^\s]*)/gi;

  return text.replace(urlRegex, (match, scheme, domain, path) => {
    // Always upgrade to https://
    const newScheme = 'https://';

    // Determine if we should rewrite the host to docs.example.com
    // Only if the path starts with /docs/ and doesn't contain dynamic elements
    let shouldRewriteHost = false;

    // Condition 1: Path must start with /docs/
    if (path.startsWith('/docs/')) {
      shouldRewriteHost = true;

      // Condition 2: Path must not contain dynamic elements
      const dynamicPatterns = [
        /cgi-bin/i,
        /[?&=]/,  // Query string characters
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:\?|$)/i  // Legacy extensions
      ];

      for (const pattern of dynamicPatterns) {
        if (pattern.test(path)) {
          shouldRewriteHost = false;
          break;
        }
      }
    }

    // Determine the domain part based on the conditions
    const newDomain = shouldRewriteHost ? 'docs.example.com' : domain;

    return newScheme + newDomain + path;
  });
}

/**
 * Extracts the four-digit year from a date string in mm/dd/yyyy format.
 * Returns 'N/A' when the format is invalid or month/day values are out of range.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Use regex to match the mm/dd/yyyy pattern
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;

  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  // Validate day based on month (account for February, leap years, etc.)
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);

  // Days in each month (non-leap year)
  const daysInMonth = [31, year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  if (month < 1 || month > 12 || day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  // Return the year as a string
  return year.toString();
}
