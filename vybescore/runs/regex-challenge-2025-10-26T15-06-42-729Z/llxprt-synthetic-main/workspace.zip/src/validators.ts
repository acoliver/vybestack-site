export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules to reject invalid formats.
 * Accepts typical addresses including plus tags and various domain extensions.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Basic structure check: local@domain
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) {
    return false;
  }

  const [localPart, domain] = value.split('@');
  
  // Validate local part
  if (!localPart || localPart.length > 64) {
    return false;
  }
  
  // Reject leading or trailing dots
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject consecutive dots
  if (localPart.includes('..')) {
    return false;
  }
  
  // Allowed characters in local part per RFC 5322
  const localPartRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localPartRegex.test(localPart)) {
    return false;
  }
  
  // Validate domain
  if (!domain || domain.length > 253) {
    return false;
  }
  
  // Reject leading or trailing dots
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Reject consecutive dots
  if (domain.includes('..')) {
    return false;
  }
  
  // Domain cannot contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Validate domain structure
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false; // Must have at least second-level domain and TLD
  }
  
  // Each part must be valid
  const domainPartRegex = /^[a-zA-Z0-9-]+$/;
  for (const part of domainParts) {
    if (!part || part.length > 63) {
      return false;
    }
    
    // Cannot start or end with hyphen
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
    
    if (!domainPartRegex.test(part)) {
      return false;
    }
  }
  
  // TLD validation (should be at least 2 characters)
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) {
    return false;
  }
  
  // Ensure TLD has at least one letter
  if (!/[a-zA-Z]/.test(tld)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats and optional +1 country code.
 * Accepts formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and inputs that are too short.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters to extract the numeric part
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have at least 10 digits (standard US number without country code)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // If we have more than 11 digits, it's not a valid US number
  if (digitsOnly.length > 11) {
    return false;
  }
  
  // Extract the country code if present
  let countryCode = '';
  let phoneNumber = digitsOnly;
  
  if (digitsOnly.length === 11) {
    countryCode = digitsOnly.substring(0, 1);
    phoneNumber = digitsOnly.substring(1);
    
    // Country code must be 1 for US
    if (countryCode !== '1') {
      return false;
    }
  }
  
  // At this point, phoneNumber should be exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format using regex to ensure the original string follows acceptable patterns
  // This regex matches:
  // - Optional +1 country code (with or without separators)
  // - Area code in parentheses or not
  // - Various separators (space, hyphen, dot, or no separator)
  const usPhoneRegex = /^\+?1?\s*\(?\d{3}\)?[\s.-]?\d{3}[\s.-]?\d{4}$/;
  
  if (!usPhoneRegex.test(value.trim())) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers supporting both landlines and mobiles.
 * Handles formats like:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (landline with trunk prefix)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline with trunk prefix)
 * - Allows single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Let's use a simpler approach to validate the format
  // We'll check the structure manually rather than using a complex regex
  
  // Check for basic pattern - at least one digit
  if (!/^\+?54\s*\d+/.test(value.replace(/-/g, '')) && !/^0\d+/.test(value.replace(/-/g, ''))) {
    return false;
  }
  
  // Additional validation: check specific patterns and constraints
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Check if it starts with country code +54
  const hasCountryCode = cleanValue.startsWith('+54');
  
  // Remove country code for validation
  let phoneNumber = hasCountryCode ? cleanValue.substring(3) : cleanValue;
  
  // If no country code, it must start with trunk prefix 0
  if (!hasCountryCode && !phoneNumber.startsWith('0')) {
    return false;
  }
  
  // Check if it has trunk prefix 0
  const hasTrunkPrefix = phoneNumber.startsWith('0');
  
  // Remove trunk prefix for validation
  if (hasTrunkPrefix) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Check if it has mobile indicator 9 (only present with country code or trunk prefix)
  if (phoneNumber.startsWith('9')) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // At this point, phoneNumber should start with the area code
  // Area code must be 2-4 digits, starting with 1-9
  let areaCodeLength = 0;
  let areaCode = '';
  
  // Try to extract area code (2-4 digits)
  for (let len = 4; len >= 2; len--) {
    if (phoneNumber.length >= len) {
      const possibleAreaCode = phoneNumber.substring(0, len);
      if (/^[1-9]\d{0,3}$/.test(possibleAreaCode)) {
        areaCode = possibleAreaCode;
        areaCodeLength = len;
        break;
      }
    }
  }
  
  if (!areaCode) {
    return false; // Valid area code not found
  }
  
  // Remove area code to get subscriber number
  phoneNumber = phoneNumber.substring(areaCodeLength);
  
  // Subscriber number must contain 6-8 digits
  if (!/^\d{6,8}$/.test(phoneNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unconventional names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Basic sanity check: must have at least one character
  if (value.trim().length === 0) {
    return false;
  }

  // Reject names with digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, and spaces
  // This regex matches:
  // - Unicode letters (\p{L})
  // - Apostrophes (')
  // - Hyphens (-)
  // - Spaces (\s)
  // Diacritic marks are included with the letter categories
  const nameRegex = /^[\p{L}'\-]+(\s[\p{L}'\-]+)*$/u;
  
  // Reject if it doesn't match the basic pattern
  if (!nameRegex.test(value.trim())) {
    return false;
  }
  
  // Additional checks for problematic patterns
  // Reject names with multiple consecutive spaces
  if (/\s{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that start or end with a space, apostrophe, or hyphen
  if (/^[\s'\-]|[\s'\-]$/.test(value)) {
    return false;
  }
  
  // Reject names with multiple consecutive apostrophes or hyphens
  if (/['\-]{2,}/.test(value)) {
    return false;
  }
  
  // Reject names that contain non-standard characters or symbols
  if (/[^\p{L}\s'\-]/u.test(value)) {
    return false;
  }
  
  // Reject unconventional names like "X Æ A-12" or names with special Unicode symbols
  if (/[^\p{L}\s'\-]/u.test(value)) {
    return false;
  }

  return true;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express.
 * Checks for proper prefixes, lengths, and validates using the Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if the result contains only digits
  if (!/^\d+$/.test(digitsOnly)) {
    return false;
  }
  
  // Basic length check (should be 13-19 digits for major cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16 digits
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55, 2221-2720, length 16 digits
  const mastercardRegex = /^(5[1-5]\d{14}|(222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12})$/;
  
  // American Express: starts with 34 or 37, length 15 digits
  const amexRegex = /^3(4|7)\d{13}$/;
  
  // Check if it matches any of the supported card types
  const isValidFormat = 
    visaRegex.test(digitsOnly) || 
    mastercardRegex.test(digitsOnly) || 
    amexRegex.test(digitsOnly);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn algorithm checksum validation.
 * Returns true if the number passes the check, false otherwise.
 */
function runLuhnCheck(cardNumber: string): boolean {
  if (!cardNumber || typeof cardNumber !== 'string') {
    return false;
  }
  
  // Check if the input contains only digits
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Convert to array of digits
  const digits = cardNumber.split('').map(digit => parseInt(digit, 10));
  
  // Double every second digit from the right
  let sum = 0;
  const isEven = digits.length % 2 === 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    // Double every second digit from the right
    if (i % 2 === (isEven ? 0 : 1)) {
      digit *= 2;
      
      // If the result is two digits, add them together
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  // If the sum is divisible by 10, the number is valid
  return sum % 10 === 0;
}
