/**
 * Finds all words in the text that begin with the specified prefix, excluding any exceptions.
 * Returns an array of matched words without duplicates.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') {
    return [];
  }

  // Create a Set of exception words for quick lookup
  const exceptionSet = new Set(exceptions);
  
  // Use regex to find all words starting with the prefix
  // \b matches word boundary
  // \w+ matches one or more word characters (letters, digits, underscores)
  const pattern = new RegExp(`\\b${escapeRegexSpecialChars(prefix)}\\w*`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions and remove duplicates
  const results = matches
    .map(word => word.trim())  // Remove whitespace
    .filter(word => !exceptionSet.has(word))  // Exclude exceptions
    .filter((value, index, self) => self.indexOf(value) === index);  // Remove duplicates
  
  return results;
}

/**
 * Escapes special regex characters in the string to safely use in regex patterns.
 */
function escapeRegexSpecialChars(str: string): string {
  return str.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Returns the full matched pattern including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = escapeRegexSpecialChars(token);
  
  // Create a regex pattern that finds the digit+token pattern only when:
  // 1. It's preceded by a digit
  // 2. It's not at the beginning of the string
  // 3. It's followed by a word boundary or non-word character
  const pattern = new RegExp(`\\d${escapedToken}(?=\\b|[\\W_])`, 'g');
  
  // Find all matches
  const matches = text.match(pattern);
  
  if (!matches) {
    return [];
  }
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * Validates password strength according to specific policy:
 * - At least 10 characters long
 * - Contains at least one uppercase letter
 * - Contains at least one lowercase letter
 * - Contains at least one digit
 * - Contains at least one symbol
 * - No whitespace characters
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Check minimum length requirement
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace characters
  if (/\s/.test(value)) {
    return false;
  }

  // Check for required character types
  const hasUpperCase = /[A-Z]/.test(value);
  const hasLowerCase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\w\s]/.test(value); // Non-alphanumeric, non-whitespace

  if (!hasUpperCase || !hasLowerCase || !hasDigit || !hasSymbol) {
    return false;
  }

  // Check for immediate repeated sequences (like abab, 1212, etc.)
  // This pattern looks for any 2-4 character sequence that repeats consecutively
  const repeatedSequenceRegex = /(.{1,4})\1+/g;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }

  // Check for patterns of the form XYXY (where X and Y are characters)
  // This catches patterns like "abab", "1212", etc.
  const patternXYXYRegex = /(.)(.)\1\2/g;
  if (patternXYXYRegex.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detects IPv6 addresses in the given text, including shorthand notation.
 * Returns true if an IPv6 address is found, false otherwise.
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 address regex pattern that matches valid IPv6 addresses including shorthand
  // This pattern matches:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Shorthand: 2001:db8::1
  // - With embedded IPv4: 2001:db8::192.168.1.1
  // - Loopback: ::1
  // - Unspecified: ::
  const ipv6Regex = /\b((?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|(?:[0-9a-fA-F]{1,4}:){6}:(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?))\b/g;

  // Check for IPv6 address with regex
  const matches = value.match(ipv6Regex);
  
  if (!matches) {
    return false;
  }
  
  // Ensure at least one match contains a colon (to exclude IPv4 addresses)
  return matches.some(match => match.includes(':'));
}