/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (text.length === 0) return text;
  
  // Normalize whitespace to single spaces
  let result = text.replace(/\s+/g, ' ').trim();
  
  if (result.length === 0) return result;
  
  // Capitalize the first letter of the text
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Pattern to match sentence endings and capitalize following letters
  // This regex matches punctuation followed by a letter, with possible whitespace
  result = result.replace(/([.!?])\s*([a-zA-Z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Handle abbreviations by not capitalizing after certain patterns
  // Common abbreviations that shouldn't trigger sentence capitalization
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'e.g', 'i.e', 'U.S'];
  
  abbreviations.forEach(abbrev => {
    const pattern = new RegExp(`\\b${abbrev}\\.\\s+([a-z])`, 'g');
    result = result.replace(pattern, (match, letter) => `${abbrev}. ${letter}`);
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http, https, www variations)
  // More inclusive pattern that allows domain extensions like .com
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s<>"'()[\]{}]*[^\s<>"'()[\]{}]/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation but preserve valid URL characters
    return url.replace(/[.,!?;:)\\]}]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, leave existing https:// URLs untouched
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Find all HTTP URLs and process them individually
  return text.replace(/http:\/\/[^\s<>"'()[\]{}]+/gi, (url) => {
    // Check for excluded patterns in the URL
    const excludedPatterns = ['cgi-bin', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    const hasQueryString = url.includes('?') || url.includes('&') || url.includes('=');
    const hasExcludedPattern = excludedPatterns.some(pattern => url.includes(pattern));
    
    // Always upgrade scheme to https
    let resultUrl = url.replace(/^http:\/\//, 'https://');
    
    // Only rewrite host for /docs/ paths without excluded patterns or query strings
    if (!hasQueryString && !hasExcludedPattern) {
      const match = resultUrl.match(/^https:\/\/([^/]+)(\/.*)$/);
      if (match) {
        const path = match[2];
        
        // Check if path begins with /docs/
        if (path.startsWith('/docs/')) {
          // Replace host with docs.example.com
          resultUrl = 'https://docs.example.com' + path;
        }
      }
    }
    
    return resultUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match the pattern mm/dd/yyyy where:
  // - mm: 01-12 (month)
  // - dd: 01-31 (day, we'll validate loosely)
  // - yyyy: 4 digits (year)
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = match[3];
  
  // Basic validation
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Return the year if format is valid
  return year;
}
