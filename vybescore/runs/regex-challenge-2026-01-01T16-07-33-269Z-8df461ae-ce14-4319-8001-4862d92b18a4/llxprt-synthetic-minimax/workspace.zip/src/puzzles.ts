/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  // Use word boundaries to ensure we're matching complete words
  const pattern = new RegExp(`\\b${escapeRegExp(prefix)}[a-zA-Z]*\\b`, 'gi');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  const normalizedExceptions = exceptions.map(e => e.toLowerCase());
  const result = matches.filter(match => {
    const normalizedMatch = match.toLowerCase();
    return !normalizedExceptions.includes(normalizedMatch);
  });
  
  return result;
}

function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all matches - include the digit in the result
  // The test expects ['1foo'] which includes the digit before the token
  const matches = text.match(new RegExp(`\\d${escapedToken}`, 'gi')) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[a-z]/.test(value)) return false; // lowercase
  if (!/[A-Z]/.test(value)) return false; // uppercase
  if (!/[0-9]/.test(value)) return false; // digit
  if (!/[^a-zA-Z0-9]/.test(value)) return false; // symbol
  
  // Check for immediate repeated sequences like "abab", "xyxy"
  // This pattern looks for 2-character sequences that repeat immediately
  if (/(..){1,}\1/.test(value)) {
    return false;
  }
  
  // Check for 3-character repeated patterns like "abcabc"
  if (/(.{3,})\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's a valid IPv4 address (to exclude those)
  const ipv4Pattern = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 address patterns (various formats):
  // 1. Full notation: 8 groups of 4 hex digits separated by colons
  // 2. Shorthand notation with :: compression
  // 3. IPv4-mapped addresses (these might appear in text)
  
  const patterns = [
    // Full IPv6: 8 groups of 1-4 hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/i,
    
    // IPv6 with :: compression (various positions)
    /\b(?:[0-9a-fA-F]{1,4}:)*(?:[0-9a-fA-F]{1,4})?::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/i,
    
    // Shorthand with leading :: compression
    /\b::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b/i,
    
    // Shorthand with trailing :: compression
    /\b(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}::\b/i,
    
    // Shorthand in the middle
    /\b(?:[0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{0,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{0,4}\b/i
  ];
  
  // Test against all IPv6 patterns
  return patterns.some(pattern => pattern.test(value));
}
