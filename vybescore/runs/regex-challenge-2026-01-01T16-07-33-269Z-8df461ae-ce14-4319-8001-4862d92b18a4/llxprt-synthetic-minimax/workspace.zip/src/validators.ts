export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Allow typical addresses like name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9+._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for double dots and trailing dots
  if (value.includes('..') || value.endsWith('.') || value.startsWith('.') || value.includes('@.')) {
    return false;
  }
  
  // Check for underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it starts with +1 (optional)
  const isCountryCode = cleaned.startsWith('+1');
  const phoneNumber = isCountryCode ? cleaned.slice(2) : cleaned;
  
  // Must be exactly 10 digits (excluding country code)
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = parseInt(phoneNumber.slice(0, 3));
  
  // Check for impossible area codes (leading 0 or 1)
  if (areaCode < 200 || areaCode > 999) {
    return false;
  }
  
  // Check for impossible exchange codes (leading 0 or 1) 
  const exchangeCode = parseInt(phoneNumber.slice(3, 6));
  if (exchangeCode < 200 || exchangeCode > 999) {
    return false;
  }
  
  // Check for impossible line numbers
  const lineNumber = parseInt(phoneNumber.slice(6, 10));
  if (lineNumber < 1000 || lineNumber > 9999) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces, hyphens, and punctuation for validation
  const cleaned = value.replace(/[\s\-().]/g, '');
  
  // Check for country code +54
  if (cleaned.startsWith('+54')) {
    const rest = cleaned.slice(3);
    // Handle mobile indicator 9
    if (rest.startsWith('9')) {
      const afterMobile = rest.slice(1);
      return validateArgentineNumber(afterMobile);
    } else {
      return validateArgentineNumber(rest);
    }
  } else {
    // No country code, must start with trunk prefix 0
    if (!cleaned.startsWith('0')) {
      return false;
    }
    const afterTrunk = cleaned.slice(1);
    // Handle mobile indicator 9
    if (afterTrunk.startsWith('9')) {
      const afterMobile = afterTrunk.slice(1);
      return validateArgentineNumber(afterMobile);
    } else {
      return validateArgentineNumber(afterTrunk);
    }
  }
}

function validateArgentineNumber(number: string): boolean {
  // Extract area code (first 2-4 digits, leading digit 1-9)
  if (number.length < 2) return false;
  
  const areaCodeLength = Math.min(4, number.length - 6); // Minimum subscriber length is 6
  if (areaCodeLength < 2 || areaCodeLength > 4) return false;
  
  const areaCodeStr = number.slice(0, areaCodeLength);
  const areaCode = parseInt(areaCodeStr);
  
  // Leading digit of area code must be 1-9
  if (areaCodeStr[0] < '1' || areaCodeStr[0] > '9') {
    return false;
  }
  
  // Area code must be at least 10 (2-digit minimum)
  if (areaCode < 10) return false;
  
  // Extract subscriber number (remaining digits)
  const subscriberNumber = number.slice(areaCodeLength);
  
  // Subscriber number must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // All remaining characters must be digits
  if (!/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace
  const trimmed = value.trim();
  
  if (trimmed.length === 0) {
    return false;
  }
  
  // Check if the name contains any digits or symbols (excluding allowed characters)
  // Allow: unicode letters, accents (combining marks), apostrophes, hyphens, spaces
  // Reject: digits, symbols, and names like "X Æ A-12"
  const invalidPattern = /[0-9.,!?@#$%^&*()[{}]|\/|<>~`:'" ]/;
  
  // Check for digits or forbidden symbols
  if (invalidPattern.test(trimmed)) {
    return false;
  }
  
  // Check for the special pattern "X Æ A-12" style names or similar unusual patterns
  // This catches names with unusual character combinations
  if (/[XÆÅ]/i.test(trimmed) && /\d/.test(trimmed)) {
    return false;
  }
  
  // Must contain at least one letter (unicode)
  const hasLetter = /\p{L}/u.test(trimmed);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for Visa/Mastercard/AmEx prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16 (simplified check)
  // AmEx: starts with 34 or 37, length 15
  const isVisa = cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19);
  
  // Simplified Mastercard check: 51-55 range, or 2221-2720 range (4 digits)
  const isMastercard = ((cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
                        cleaned.startsWith('54') || cleaned.startsWith('55')) && cleaned.length === 16) ||
                       (cleaned.startsWith('222') || cleaned.startsWith('223') || cleaned.startsWith('224') ||
                        cleaned.startsWith('225') || cleaned.startsWith('226') || cleaned.startsWith('227') ||
                        cleaned.startsWith('228') || cleaned.startsWith('229') || cleaned.startsWith('230') ||
                        cleaned.startsWith('231') || cleaned.startsWith('232') || cleaned.startsWith('233') ||
                        cleaned.startsWith('234') || cleaned.startsWith('235') || cleaned.startsWith('236') ||
                        cleaned.startsWith('237') || cleaned.startsWith('238') || cleaned.startsWith('239') ||
                        cleaned.startsWith('240') || cleaned.startsWith('241') || cleaned.startsWith('242') ||
                        cleaned.startsWith('243') || cleaned.startsWith('244') || cleaned.startsWith('245') ||
                        cleaned.startsWith('246') || cleaned.startsWith('247') || cleaned.startsWith('248') ||
                        cleaned.startsWith('249') || cleaned.startsWith('250') || cleaned.startsWith('251') ||
                        cleaned.startsWith('252') || cleaned.startsWith('253') || cleaned.startsWith('254') ||
                        cleaned.startsWith('255') || cleaned.startsWith('256') || cleaned.startsWith('257') ||
                        cleaned.startsWith('258') || cleaned.startsWith('259') || cleaned.startsWith('260') ||
                        cleaned.startsWith('261') || cleaned.startsWith('262') || cleaned.startsWith('263') ||
                        cleaned.startsWith('264') || cleaned.startsWith('265') || cleaned.startsWith('266') ||
                        cleaned.startsWith('267') || cleaned.startsWith('268') || cleaned.startsWith('269') ||
                        cleaned.startsWith('270') || cleaned.startsWith('271') || cleaned.startsWith('2720')) && cleaned.length === 16;
  const isAmex = (cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15;
  
  // If it's not a recognized card type, reject it
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i]);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit = Math.floor(digit / 10) + (digit % 10);
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
