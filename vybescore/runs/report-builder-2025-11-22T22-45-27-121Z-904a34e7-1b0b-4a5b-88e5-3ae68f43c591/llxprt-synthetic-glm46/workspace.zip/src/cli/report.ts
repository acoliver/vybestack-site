#!/usr/bin/env node

import { readFileSync } from 'fs';
import { writeFile } from 'fs/promises';
import type { ReportData, ReportOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

const formatters = {
  markdown: markdownFormatter,
  text: textFormatter,
};

function parseArguments(): {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 1) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  
  const format = args[formatIndex + 1];
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex + 1 < args.length ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const dataObj = data as Record<string, unknown>;
  
  if (typeof dataObj.title !== 'string') {
    throw new Error('Invalid report data: title is required and must be a string');
  }
  
  if (typeof dataObj.summary !== 'string') {
    throw new Error('Invalid report data: summary is required and must be a string');
  }
  
  if (!Array.isArray(dataObj.entries)) {
    throw new Error('Invalid report data: entries is required and must be an array');
  }
  
  for (const [index, entry] of dataObj.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: label is required and must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: amount is required and must be a number`);
    }
  }
  
  return dataObj as unknown as ReportData;
}

function loadReportData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    throw error;
  }
}

async function main(): Promise<void> {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments();
    
    // Validate format
    if (!(format in formatters)) {
      console.error(`Error: Unsupported format "${format}". Supported formats: ${Object.keys(formatters).join(', ')}`);
      process.exit(1);
    }
    
    // Load and validate data
    const data = loadReportData(dataFile);
    
    // Options for formatting
    const options: ReportOptions = { includeTotals };
    
    // Render the report
    const formatter = formatters[format as keyof typeof formatters];
    const output = formatter.render(data, options);
    
    // Output to file or stdout
    if (outputPath) {
      await writeFile(outputPath, output, 'utf8');
      console.log(`Report saved to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error(`Unhandled error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  });
}