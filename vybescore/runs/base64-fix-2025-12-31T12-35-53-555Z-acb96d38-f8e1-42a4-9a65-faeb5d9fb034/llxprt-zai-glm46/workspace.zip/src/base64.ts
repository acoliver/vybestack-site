const BASE64_ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';
const PADDING_CHAR = '=';
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Validate that a string is valid Base64.
 * Checks for:
 * - Valid Base64 characters (A-Z, a-z, 0-9, +, /, =)
 * - Correct padding (only at the end, 0-2 characters)
 * - Correct length (multiple of 4, or unpadded with valid length)
 */
function isValidBase64(input: string): boolean {
  // Empty string is not valid Base64
  if (input.length === 0) {
    return false;
  }

  // Count padding characters at the end
  const paddingMatch = input.match(/=+$/);
  const paddingLength = paddingMatch ? paddingMatch[0].length : 0;
  const dataLength = input.length - paddingLength;

  // Padding can only be 0, 1, or 2 characters
  if (paddingLength > 2) {
    return false;
  }

  // If there's padding, total length must be a multiple of 4
  // Without padding, we allow any length (Node.js is lenient)
  if (paddingLength > 0 && input.length % 4 !== 0) {
    return false;
  }

  // Check each character
  for (let i = 0; i < input.length; i++) {
    const char = input[i];
    
    if (char === PADDING_CHAR) {
      // Padding can only appear at the end
      if (i < dataLength) {
        return false;
      }
    } else if (!BASE64_ALPHABET.includes(char)) {
      // Invalid character
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  const buffer = Buffer.from(input, 'utf8');
  return buffer.toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the buffer is empty, which indicates invalid input
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
