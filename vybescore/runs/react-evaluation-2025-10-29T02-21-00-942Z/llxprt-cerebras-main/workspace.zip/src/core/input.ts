/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part of an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Convert boolean equal parameter to proper equal function
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === true ? Object.is : 
    equal === false ? () => false : 
    undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track this observer as a dependency
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value has actually changed using equalFn or Object.is as default
    const hasChanged = equalFn 
      ? !equalFn(s.value, nextValue) 
      : !Object.is(s.value, nextValue)

    if (hasChanged) {
      s.value = nextValue
      
      // If there's an observer, update it
      if (s.observer) {
        updateObserver(s.observer as Observer<unknown>)
      }
    }
    
    return s.value
  }

  return [read, write]
}