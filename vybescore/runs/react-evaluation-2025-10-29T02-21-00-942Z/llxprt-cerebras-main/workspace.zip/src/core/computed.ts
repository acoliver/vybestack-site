/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equal parameter to proper equal function
  const equalFn: EqualFn<T> | undefined = 
    typeof equal === 'function' ? equal : 
    equal === true ? Object.is : 
    equal === false ? () => false : 
    undefined

  const o: Observer<T> = {
    name: options?.name,
    value,
    equalFn,
    updateFn,
    dependencies: new Set(), // Track dependencies
  }

  // Initialize the computed value by running updateFn
  updateObserver(o)

  const read: GetterFn<T> = () => {
    return o.value!
  }

  return read
}