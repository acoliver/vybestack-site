// React component with various animation implementations
import React, { useState, useEffect, useRef } from 'react';
import { motion, AnimatePresence } from 'framer-motion';

const AnimatedComponents = () => {
  const [isVisible, setIsVisible] = useState(true);
  const [items, setItems] = useState([
    { id: 1, text: 'Item 1' },
    { id: 2, text: 'Item 2' },
    { id: 3, text: 'Item 3' },
  ]);
  const [progress, setProgress] = useState(0);
  const [isHovered, setIsHovered] = useState(false);
  const animationRef = useRef();

  // Progress animation with useEffect
  useEffect(() => {
    let interval;
    if (progress < 100) {
      interval = setInterval(() => {
        setProgress(prev => Math.min(prev + 5, 100));
      }, 200);
    }
    return () => clearInterval(interval);
  }, [progress]);

  // Toggle function for testing animations
  const toggleVisibility = () => setIsVisible(!isVisible);
  
  const addItem = () => {
    const newItem = {
      id: Date.now(),
      text: `Item ${items.length + 1}`
    };
    setItems([...items, newItem]);
  };
  
  const removeItem = (id) => {
    setItems(items.filter(item => item.id !== id));
  };

  // Animation presets for framer-motion
  const containerVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: {
        duration: 0.5,
        staggerChildren: 0.1,
        delayChildren: 0.2,
      }
    }
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: 'spring',
        stiffness: 100,
      }
    },
    exit: {
      y: -20,
      opacity: 0,
      transition: {
        duration: 0.3
      }
    }
  };

  const floatingAnimation = {
    y: [0, -10, 0],
    transition: {
      duration: 2,
      repeat: Infinity,
      repeatType: 'loop',
      ease: 'easeInOut'
    }
  };

  return (
    <div className="animated-components">
      <h2>Animated Components</h2>
      
      {/* Progress Bar Animation */}
      <section className="progress-section">
        <h3>Progress Bar Animation</h3>
        <div className="progress-container">
          <div className="progress-bar">
            <div
              className="progress-fill"
              style={{ width: `${progress}%` }}
            >
              <span>{progress}%</span>
            </div>
          </div>
          <button onClick={() => setProgress(0)}>Reset</button>
        </div>
      </section>

      {/* Toggle Animation */}
      <section className="toggle-section">
        <h3>Toggle Animation</h3>
        <button onClick={toggleVisibility}>
          {isVisible ? 'Hide' : 'Show'} Content
        </button>
        <AnimatePresence>
          {isVisible && (
            <motion.div
              className="toggle-content"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
              exit={{ opacity: 0, height: 0 }}
              transition={{ duration: 0.3 }}
            >
              <p>This content can be toggled with animation</p>
            </motion.div>
          )}
        </AnimatePresence>
      </section>

      {/* Item List with Stagger Animation */}
      <section className="list-section">
        <h3>Item List with Stagger Animation</h3>
        <motion.div
          className="item-container"
          variants={containerVariants}
          initial="hidden"
          animate="visible"
        >
          <AnimatePresence>
            {items.map(item => (
              <motion.div
                key={item.id}
                className="list-item"
                variants={itemVariants}
                exit="exit"
                layout
              >
                <span>{item.text}</span>
                <button onClick={() => removeItem(item.id)}>Remove</button>
              </motion.div>
            ))}
          </AnimatePresence>
        </motion.div>
        <button onClick={addItem}>Add Item</button>
      </section>

      {/* Hover Animation */}
      <section className="hover-section">
        <h3>Hover Animation</h3>
        <motion.div
          className="hover-card"
          whileHover={{ scale: 1.05, rotate: 2 }}
          onHoverStart={() => setIsHovered(true)}
          onHoverEnd={() => setIsHovered(false)}
          style={{ cursor: 'pointer' }}
        >
          <p>Hover over me</p>
          {isHovered && <p className="hover-text">Nice hover!</p>}
        </motion.div>
      </section>

      {/* Floating Animation */}
      <section className="floating-section">
        <h3>Floating Animation</h3>
        <motion.div
          className="floating-element"
          animate={floatingAnimation}
        >
          <p>Floating Element</p>
        </motion.div>
      </section>

      {/* Morphing Shape Animation */}
      <section className="morph-section">
        <h3>Shape Morphing Animation</h3>
        <motion.div
          className="morphing-shape"
          animate={{
            borderRadius: ['20%', '50%', '20%'],
            rotate: [0, 180, 360]
          }}
          transition={{
            duration: 3,
            repeat: Infinity,
            ease: 'easeInOut'
          }}
        />
      </section>
    </div>
  );
};

export default AnimatedComponents;