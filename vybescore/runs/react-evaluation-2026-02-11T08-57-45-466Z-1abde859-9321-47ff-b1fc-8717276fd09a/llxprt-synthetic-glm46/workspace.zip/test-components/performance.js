// Performance Optimization Testing Components
// These components test React performance techniques

import React, { memo, useMemo, useCallback } from 'react';

// Memoized Component - tests React.memo for performance
const MemoizedComponent = memo(function MemoizedComponent({ data, onItemClick }) {
  console.log('MemoizedComponent render');
  
  return (
    <div className="memoized-component" data-testid="memoized-component">
      <h4>Memoized Component</h4>
      <ul className="item-list">
        {data.map(item => (
          <li key={item.id} onClick={() => onItemClick(item.id)} data-testid={`item-${item.id}`}>
            {item.name}
          </li>
        ))}
      </ul>
    </div>
  );
});

// Expensive Computation Component - tests useMemo
const ExpensiveComputationComponent = ({ items, filter }) => {
  const filteredItems = useMemo(() => {
    console.log('Expensive computation running');
    return items.filter(item => 
      item.name.toLowerCase().includes(filter.toLowerCase())
    );
  }, [items, filter]);
  
  return (
    <div className="expensive-computation" data-testid="expensive-computation">
      <h4>Expensive Computation</h4>
      <p>Filter: {filter}</p>
      <ul>
        {filteredItems.map(item => (
          <li key={item.id}>{item.name}</li>
        ))}
      </ul>
      <p>Total: {filteredItems.length} items</p>
    </div>
  );
};

// Callback Component - tests useCallback
const CallbackComponent = ({ items, onItemSelect }) => {
  const handleClick = useCallback((id) => {
    console.log(`Item ${id} clicked`);
    onItemSelect(id);
  }, [onItemSelect]);
  
  return (
    <div className="callback-component" data-testid="callback-component">
      <h4>Callback Component</h4>
      <button 
        onClick={() => handleClick(1)}
        data-testid="item-button-1"
      >
        Select Item 1
      </button>
      <button 
        onClick={() => handleClick(2)}
        data-testid="item-button-2"
      >
        Select Item 2
      </button>
    </div>
  );
};

export { MemoizedComponent, ExpensiveComputationComponent, CallbackComponent };