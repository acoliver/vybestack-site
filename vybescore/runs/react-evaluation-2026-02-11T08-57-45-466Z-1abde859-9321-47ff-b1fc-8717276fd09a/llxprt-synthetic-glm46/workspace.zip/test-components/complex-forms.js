import React, { useState, useEffect, useCallback, useMemo } from 'react';

// Complex form component with validation, custom hooks, and performance optimizations
function useFormState(initialState, validationSchema) {
  const [values, setValues] = useState(initialState);
  const [errors, setErrors] = useState({});
  const [touched, setTouched] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);

  const validateField = useCallback((name, value) => {
    if (!validationSchema || !validationSchema[name]) {
      return '';
    }
    
    const rules = validationSchema[name];
    for (const rule of rules) {
      if (rule.required && (!value || value.trim() === '')) {
        return rule.message || `${name} is required`;
      }
      
      if (rule.pattern && !rule.pattern.test(value)) {
        return rule.message || `${name} is invalid`;
      }
      
      if (rule.minLength && value.length < rule.minLength) {
        return rule.message || `${name} must be at least ${rule.minLength} characters`;
      }
      
      if (rule.custom && !rule.custom(value, values)) {
        return rule.message || `${name} is invalid`;
      }
    }
    return '';
  }, [validationSchema, values]);

  const validateAll = useCallback(() => {
    const newErrors = {};
    Object.keys(validationSchema || {}).forEach(name => {
      const error = validateField(name, values[name]);
      if (error) {
        newErrors[name] = error;
      }
    });
    return newErrors;
  }, [validationSchema, validateField, values]);

  const handleChange = useCallback((e) => {
    const { name, value, type, checked } = e.target;
    const newValue = type === 'checkbox' ? checked : value;
    
    setValues(prev => ({
      ...prev,
      [name]: newValue
    }));
    
    if (touched[name]) {
      setErrors(prev => ({
        ...prev,
        [name]: validateField(name, newValue)
      }));
    }
  }, [touched, validateField]);

  const handleBlur = useCallback((e) => {
    const { name } = e.target;
    setTouched(prev => ({
      ...prev,
      [name]: true
    }));
    
    setErrors(prev => ({
      ...prev,
      [name]: validateField(name, values[name])
    }));
  }, [validateField, values]);

  const handleSubmit = useCallback(async (onSubmit) => {
    const validationErrors = validateAll();
    setErrors(validationErrors);
    
    if (Object.keys(validationErrors).length > 0) {
      return;
    }
    
    setIsSubmitting(true);
    
    try {
      await onSubmit(values);
      setValues(initialState);
      setTouched({});
      setErrors({});
    } catch (error) {
      setErrors({ _form: error.message || 'Submission failed' });
    } finally {
      setIsSubmitting(false);
    }
  }, [validateAll, values, initialState]);

  return {
    values,
    errors,
    touched,
    isSubmitting,
    handleChange,
    handleBlur,
    handleSubmit,
    setFieldValue: (name, value) => setValues(prev => ({ ...prev, [name]: value }))
  };
}

const ComplexForm = ({ onSubmit, validationSchema, initialValues = {} }) => {
  const defaultValues = {
    username: '',
    email: '',
    password: '',
    confirmPassword: '',
    age: '',
    gender: '',
    interests: [],
    termsAccepted: false
  };
  
  const formState = useFormState({ ...defaultValues, ...initialValues }, validationSchema);
  
  const isPasswordValid = useMemo(() => {
    const { password } = formState.values;
    return password.length >= 8 && /[A-Za-z]/.test(password) && /[0-9]/.test(password);
  }, [formState.values.password]);
  
  const passwordStrength = useMemo(() => {
    const { password } = formState.values;
    if (!password) return { score: 0, label: 'None' };
    
    let score = 0;
    if (password.length >= 8) score++;
    if (password.length >= 12) score++;
    if (/[a-z]/.test(password)) score++;
    if (/[A-Z]/.test(password)) score++;
    if (/[0-9]/.test(password)) score++;
    if (/[^A-Za-z0-9]/.test(password)) score++;
    
    const labels = ['Very Weak', 'Weak', 'Fair', 'Good', 'Strong', 'Very Strong'];
    return { score, label: labels[score] || 'Unknown' };
  }, [formState.values.password]);
  
  const handleInterestChange = useCallback((interest, checked) => {
    const { interests } = formState.values;
    const newInterests = checked
      ? [...interests, interest]
      : interests.filter(i => i !== interest);
    
    formState.setFieldValue('interests', newInterests);
  }, [formState]);
  
  return (
    <div className="complex-form">
      <h2>Complex Form Example</h2>
      
      {formState.errors._form && (
        <div className="form-error" role="alert">
          {formState.errors._form}
        </div>
      )}
      
      <form onSubmit={(e) => {
        e.preventDefault();
        formState.handleSubmit(onSubmit);
      }} noValidate>
        
        <div className="form-group">
          <label htmlFor="username">Username *</label>
          <input
            type="text"
            id="username"
            name="username"
            value={formState.values.username}
            onChange={formState.handleChange}
            onBlur={formState.handleBlur}
            disabled={formState.isSubmitting}
            aria-invalid={!!formState.errors.username}
            aria-describedby={formState.errors.username ? "username-error" : null}
          />
          {formState.errors.username && (
            <div id="username-error" className="error-message">
              {formState.errors.username}
            </div>
          )}
        </div>
        
        <div className="form-group">
          <label htmlFor="email">Email *</label>
          <input
            type="email"
            id="email"
            name="email"
            value={formState.values.email}
            onChange={formState.handleChange}
            onBlur={formState.handleBlur}
            disabled={formState.isSubmitting}
            aria-invalid={!!formState.errors.email}
          />
          {formState.errors.email && (
            <div className="error-message">{formState.errors.email}</div>
          )}
        </div>
        
        <div className="form-group">
          <label htmlFor="password">Password *</label>
          <input
            type="password"
            id="password"
            name="password"
            value={formState.values.password}
            onChange={formState.handleChange}
            onBlur={formState.handleBlur}
            disabled={formState.isSubmitting}
            aria-invalid={!!formState.errors.password}
          />
          {formState.values.password && (
            <div className="password-strength">
              <div className="strength-bar">
                <div
                  className="strength-fill"
                  style={{
                    width: `${(passwordStrength.score / 6) * 100}%`,
                    backgroundColor: ['red', 'orange', 'yellow', '#90EE90', '#8FBC8F', 'green'][passwordStrength.score]
                  }}
                />
              </div>
              <span className="strength-label">{passwordStrength.label}</span>
            </div>
          )}
          {formState.errors.password && (
            <div className="error-message">{formState.errors.password}</div>
          )}
        </div>
        
        <div className="form-group">
          <label htmlFor="confirmPassword">Confirm Password *</label>
          <input
            type="password"
            id="confirmPassword"
            name="confirmPassword"
            value={formState.values.confirmPassword}
            onChange={formState.handleChange}
            onBlur={formState.handleBlur}
            disabled={formState.isSubmitting}
            aria-invalid={!!formState.errors.confirmPassword}
          />
          {formState.errors.confirmPassword && (
            <div className="error-message">{formState.errors.confirmPassword}</div>
          )}
        </div>
        
        <div className="form-group">
          <label htmlFor="age">Age</label>
          <input
            type="number"
            id="age"
            name="age"
            value={formState.values.age}
            onChange={formState.handleChange}
            onBlur={formState.handleBlur}
            disabled={formState.isSubmitting}
            min="18"
            max="120"
          />
          {formState.errors.age && (
            <div className="error-message">{formState.errors.age}</div>
          )}
        </div>
        
        <div className="form-group">
          <legend>Gender</legend>
          <div className="radio-group">
            {['male', 'female', 'other', 'prefer not to say'].map(gender => (
              <div key={gender} className="radio-option">
                <input
                  type="radio"
                  id={`gender-${gender}`}
                  name="gender"
                  value={gender}
                  checked={formState.values.gender === gender}
                  onChange={formState.handleChange}
                  disabled={formState.isSubmitting}
                />
                <label htmlFor={`gender-${gender}`}>
                  {gender.charAt(0).toUpperCase() + gender.slice(1)}
                </label>
              </div>
            ))}
          </div>
          {formState.errors.gender && (
            <div className="error-message">{formState.errors.gender}</div>
          )}
        </div>
        
        <div className="form-group">
          <legend>Interests</legend>
          {['Sports', 'Music', 'Reading', 'Travel', 'Technology', 'Cooking'].map(interest => (
            <div key={interest} className="checkbox-option">
              <input
                type="checkbox"
                id={`interest-${interest}`}
                name={interest}
                checked={formState.values.interests.includes(interest)}
                onChange={(e) => handleInterestChange(interest, e.target.checked)}
                disabled={formState.isSubmitting}
              />
              <label htmlFor={`interest-${interest}`}>{interest}</label>
            </div>
          ))}
          {formState.errors.interests && (
            <div className="error-message">{formState.errors.interests}</div>
          )}
        </div>
        
        <div className="form-group">
          <div className="checkbox-option">
            <input
              type="checkbox"
              id="terms"
              name="termsAccepted"
              checked={formState.values.termsAccepted}
              onChange={formState.handleChange}
              onBlur={formState.handleBlur}
              disabled={formState.isSubmitting}
            />
            <label htmlFor="terms">
              I accept the terms and conditions *
            </label>
          </div>
          {formState.errors.termsAccepted && (
            <div className="error-message">{formState.errors.termsAccepted}</div>
          )}
        </div>
        
        <button type="submit" disabled={formState.isSubmitting || !isPasswordValid}>
          {formState.isSubmitting ? 'Submitting...' : 'Submit'}
        </button>
      </form>
    </div>
  );
};

export default ComplexForm;