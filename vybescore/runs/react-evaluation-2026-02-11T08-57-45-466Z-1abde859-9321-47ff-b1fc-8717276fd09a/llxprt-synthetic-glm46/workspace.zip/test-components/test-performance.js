/**
 * Test rendering performance
 */
import { renderToString } from 'react-dom/server';

export default {
  async test() {
    const startTime = performance.now();
    
    // Perform render operations
    for (let i = 0; i < 1000; i++) {
      renderToString(<div>Performance test {i}</div>);
    }
    
    const endTime = performance.now();
    const duration = endTime - startTime;
    
    return {
      passed: duration < 1000, // Should take less than 1 second
      message: `Performance: ${duration.toFixed(2)}ms`,
      data: {
        duration,
        threshold: 1000
      }
    };
  },
  
  description: 'Tests rendering to string performance',
  category: 'performance'
};