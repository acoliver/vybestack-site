import React, { useState, useEffect, useRef } from 'react';
import { testPerformance } from '../../test-components/test-performance';

const PerformanceTest = () => {
  const [testResults, setTestResults] = useState([]);
  const [isRunning, setIsRunning] = useState(false);
  const [testType, setTestType] = useState('render');
  const [iterations, setIterations] = useState(1000);
  
  const runTests = async () => {
    setIsRunning(true);
    try {
      const results = await testPerformance();
      setTestResults(results);
    } catch (error) {
      console.error('Performance test failed:', error);
    } finally {
      setIsRunning(false);
    }
  };

  const renderResults = () => {
    if (!testResults.length) return <div>No test results available</div>;
    
    return (
      <div className="performance-results">
        <h3>Performance Test Results</h3>
        <table className="results-table">
          <thead>
            <tr>
              <th>Test Name</th>
              <th>Average (ms)</th>
              <th>Min (ms)</th>
              <th>Max (ms)</th>
              <th>Status</th>
            </tr>
          </thead>
          <tbody>
            {testResults.map((result, index) => (
              <tr key={index}>
                <td>{result.name}</td>
                <td>{result.avg.toFixed(2)}</td>
                <td>{result.min.toFixed(2)}</td>
                <td>{result.max.toFixed(2)}</td>
                <td className={result.status}>
                  {result.status}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        <div className="status-legend">
          <h4>Status Legend:</h4>
          <div><span className="pass">PASS:</span> Meets performance targets</div>
          <div><span className="warn">WARN:</span> Performance concerns</div>
          <div><span className="fail">FAIL:</span> Does not meet requirements</div>
        </div>
      </div>
    );
  };

  return (
    <div className="performance-test-container">
      <h2>React Performance Tests</h2>
      <p>This component runs performance tests and displays the results.</p>
      
      <div className="controls">
        <button 
          onClick={runTests} 
          disabled={isRunning}
          className="test-button"
        >
          {isRunning ? 'Running...' : 'Run Performance Tests'}
        </button>
      </div>
      
      {testResults.length > 0 && renderResults()}
    </div>
  );
};

export default PerformanceTest;