/**
 * Core Event Bus Implementation
 * Provides centralized event management for the application
 */

export type EventCallback = (data: any) => void | Promise<void>;

interface EventSubscription {
  id: string;
  callback: EventCallback;
  once: boolean;
  context?: any;
}

interface SubscriptionConfig {
  callback: EventCallback;
  once?: boolean;
  context?: any;
}

export class EventEmitter {
  private events = new Map<string, EventSubscription[]>();
  private history = new Map<string, any[]>();
  private maxHistorySize = 50;

  /**
   * Subscribe to an event
   * @param event The event name
   * @param callback The callback function
   * @param once Whether to only call the callback once
   * @param context Optional context to bind to the callback
   * @returns Subscription ID for unsubscribing
   */
  on(event: string, callback: EventCallback, once = false, context?: any): string {
    const id = this.generateId();
    const subscription: EventSubscription = { id, callback, once, context };

    if (!this.events.has(event)) {
      this.events.set(event, []);
    }
    
    this.events.get(event)!.push(subscription);
    return id;
  }

  /**
   * Subscribe to an event once
   * @param event The event name
   * @param callback The callback function
   * @returns Subscription ID
   */
  once(event: string, callback: EventCallback): string {
    return this.on(event, callback, true);
  }

  /**
   * Subscribe with configuration object
   * @param event The event name
   * @param config Configuration object
   * @returns Subscription ID
   */
  subscribe(event: string, config: SubscriptionConfig): string {
    return this.on(
      event,
      config.callback,
      config.once || false,
      config.context
    );
  }

  /**
   * Emit an event
   * @param event The event name
   * @param data The event data
   * @returns Promise that resolves when all callbacks have completed
   */
  async emit(event: string, data?: any): Promise<void> {
    // Store event in history
    this.addToHistory(event, data);

    const subscriptions = this.events.get(event) || [];
    const promises: Promise<void>[] = [];

    for (const subscription of subscriptions) {
      const promise = this.executeCallback(subscription, data);
      promises.push(promise);

      if (subscription.once) {
        this.unsubscribe(event, subscription.id);
      }
    }

    await Promise.allSettled(promises);
  }

  /**
   * Unsubscribe from an event
   * @param event The event name
   * @param id The subscription ID
   * @returns True if unsubscribed successfully
   */
  unsubscribe(event: string, id: string): boolean {
    const subscriptions = this.events.get(event);
    if (!subscriptions) return false;

    const index = subscriptions.findIndex(sub => sub.id === id);
    if (index === -1) return false;

    subscriptions.splice(index, 1);
    
    if (subscriptions.length === 0) {
      this.events.delete(event);
    }

    return true;
  }

  /**
   * Unsubscribe all listeners for an event
   * @param event The event name
   * @returns Number of subscriptions removed
   */
  unsubscribeAll(event: string): number {
    const subscriptions = this.events.get(event);
    if (!subscriptions) return 0;

    const count = subscriptions.length;
    this.events.delete(event);
    return count;
  }

  /**
   * Get all event names that have listeners
   * @returns Array of event names
   */
  getEventNames(): string[] {
    return Array.from(this.events.keys());
  }

  /**
   * Get the number of listeners for an event
   * @param event The event name
   * @returns Number of listeners
   */
  listenerCount(event: string): number {
    return this.events.get(event)?.length || 0;
  }

  /**
   * Get event history
   * @param event Optional event name to filter by
   * @param maxResults Maximum number of events to return
   * @returns Array of historical events
   */
  getHistory(event?: string, maxResults = 10): Array<{ event: string; data: any; timestamp: number }> {
    const history: Array<{ event: string; data: any; timestamp: number }> = [];
    
    if (event) {
      const eventHistory = this.history.get(event) || [];
      return eventHistory.slice(-maxResults).map(data => ({ event, data, timestamp: Date.now() }));
    }

    for (const [eventName, events] of this.history.entries()) {
      events.forEach(data => {
        history.push({ event: eventName, data, timestamp: Date.now() });
      });
    }

    return history.slice(-maxResults);
  }

  /**
   * Clear all listeners and history
   */
  clear(): void {
    this.events.clear();
    this.history.clear();
  }

  /**
   * Execute a callback safely
   * @param subscription The subscription object
   * @param data The event data
   * @returns Promise that resolves when callback completes
   */
  private async executeCallback(subscription: EventSubscription, data: any): Promise<void> {
    try {
      await subscription.callback.call(subscription.context, data);
    } catch (error) {
      console.error('Event callback error:', error);
      // Optionally emit an error event
      this.emit('error', { 
        event: subscription.id, 
        error 
      }).catch(() => {});
    }
  }

  /**
   * Add event to history
   * @param event The event name
   * @param data The event data
   */
  private addToHistory(event: string, data: any): void {
    if (!this.history.has(event)) {
      this.history.set(event, []);
    }

    const eventHistory = this.history.get(event)!;
    eventHistory.push(data);

    // Limit history size
    if (eventHistory.length > this.maxHistorySize) {
      eventHistory.shift();
    }
  }

  /**
   * Generate a unique ID
   * @returns Unique string ID
   */
  private generateId(): string {
    return `sub_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }
}

// Create and export a singleton instance
export const eventBus = new EventEmitter();

// Export types for external use
export type { EventSubscription, SubscriptionConfig };