import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const page = pageParam ? Number(pageParam) : undefined;
      const limit = limitParam ? Number(limitParam) : undefined;

      // Validate parameters before passing to repository
      if (pageParam && (!Number.isFinite(Number(pageParam)) || Number(pageParam) <= 0)) {
        return res.status(400).json({ error: 'Invalid page parameter' });
      }
      if (limitParam && (!Number.isFinite(Number(limitParam)) || Number(limitParam) <= 0)) {
        return res.status(400).json({ error: 'Invalid limit parameter' });
      }
      if (limitParam && Number(limitParam) > 1000) {
        return res.status(400).json({ error: 'Limit parameter excessive' });
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      if (error instanceof Error) {
        if (error.message === 'INVALID_PAGE') {
          return res.status(400).json({ error: 'Invalid page parameter' });
        }
        if (error.message === 'INVALID_LIMIT') {
          return res.status(400).json({ error: 'Invalid limit parameter' });
        }
        if (error.message === 'EXCESSIVE_LIMIT') {
          return res.status(400).json({ error: 'Limit parameter excessive' });
        }
      }
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
