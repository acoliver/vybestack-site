import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';
import { useState } from 'react';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  page, 
  limit, 
  total, 
  hasNext, 
  onPageChange 
}: { 
  page: number;
  limit: number;
  total: number;
  hasNext: boolean;
  onPageChange: (newPage: number) => void;
}): JSX.Element {
  const canGoPrevious = page > 1;
  const startItem = (page - 1) * limit + 1;
  const endItem = Math.min(page * limit, total);

  return (
    <div>
      <p>Items {startItem}-{endItem} of {total}</p>
      <div>
        <button 
          onClick={() => onPageChange(page - 1)} 
          disabled={!canGoPrevious}
        >
          Previous
        </button>
        <span> Page {page} </span>
        <button 
          onClick={() => onPageChange(page + 1)} 
          disabled={!hasNext}
        >
          Next
        </button>
      </div>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePageChange = (newPage: number): void => {
    setCurrentPage(newPage);
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return (
      <div>
        <p role="alert">{error ?? 'Unable to load inventory.'}</p>
        <button onClick={() => setCurrentPage(1)}>Try again</button>
      </div>
    );
  }

  if (data.items.length === 0) {
    return (
      <section>
        <h1>Inventory</h1>
        <p>No items found.</p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls 
        page={data.page}
        limit={data.limit}
        total={data.total}
        hasNext={data.hasNext}
        onPageChange={handlePageChange}
      />
    </section>
  );
}
