/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after sentence-ending punctuation (. ? !)
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving readability
 * - Leaves abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces into one
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Split into sentences by sentence-ending punctuation
  // This regex matches ., ?, or ! followed by optional space(s) and then a letter
  const sentences: string[] = [];
  let current = '';
  let i = 0;
  
  while (i < normalized.length) {
    const char = normalized[i];
    
    if (char === '.' || char === '?' || char === '!') {
      // Include the punctuation
      current += char;
      i++;
      
      // Skip any spaces after punctuation
      while (i < normalized.length && normalized[i] === ' ') {
        i++;
      }
      
      sentences.push(current);
      current = '';
    } else {
      current += char;
      i++;
    }
  }
  
  if (current) {
    sentences.push(current);
  }
  
  // Capitalize each sentence
  const result = sentences.map((sentence) => {
    if (!sentence) return '';
    
    // Capitalize first letter of sentence (except very first if it's already capitalized)
    const trimmed = sentence.trim();
    if (trimmed.length === 0) return '';
    
    // Find first alphabetic character
    const firstAlphaIndex = trimmed.search(/[a-zA-Z]/);
    
    if (firstAlphaIndex === -1) {
      return trimmed;
    }
    
    const prefix = trimmed.substring(0, firstAlphaIndex);
    const firstChar = trimmed[firstAlphaIndex];
    const rest = trimmed.substring(firstAlphaIndex + 1);
    
    return prefix + firstChar.toUpperCase() + rest;
  });
  
  // Join with single spaces
  return result.join(' ').replace(/\s+/g, ' ').trim();
}

/**
 * Find URLs in text.
 * - Returns array of matched URL strings
 * - Excludes trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, ftp, etc.
  const urlRegex = /(https?:\/\/[^\s<>]+|www\.[^\s<>]+)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL
  return matches.map(url => {
    // Remove trailing punctuation marks
    return url.replace(/[.,;:!?(){}[\]"'<>]+$/, '');
  });
}

/**
 * Force all http URLs to https.
 * - Leaves already secure URLs untouched
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only when not followed by s:// (to avoid https://)
  return text.replace(/http:\/\/(?!s)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Still upgrade scheme even when skipping host rewrite
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlRegex = /(https?:\/\/)(example\.com)(\/[^\s<>]*)?/gi;
  
  return text.replace(urlRegex, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // If no path, just upgrade scheme
    if (!path || path === '/') {
      return newScheme + host + path;
    }
    
    // Check if we should skip host rewrite
    // Dynamic hints: cgi-bin, query strings, legacy extensions
    const hasDynamicHint = 
      path.includes('cgi-bin') ||
      path.includes('?') ||
      path.includes('&') ||
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i.test(path);
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    if (isDocsPath && !hasDynamicHint) {
      // Rewrite host to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade scheme, keep original host
      return newScheme + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy format.
 * - Returns 4-digit year if valid
 * - Returns 'N/A' if format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: { [key: number]: number } = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return year;
}
