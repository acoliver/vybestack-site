export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * - Accepts standard formats like user@example.com, name@tag@example.co.uk
 * - Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Email regex that rejects common invalid patterns
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?!.*\.\.)[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for specific rejection criteria
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for trailing dot in local part or domain
  if (value.endsWith('.') || value.includes('..')) {
    return false;
  }
  
  // Check for underscores in domain
  const parts = value.split('@');
  if (parts.length === 2 && parts[1].includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * - Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallows impossible area codes (leading 0 or 1)
 */
export function isValidUSPhone(_value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = _value.replace(/[^\d+]/g, '');
  
  // Future: use options.allowExtensions for phone extensions
  void options;
  
  // Check minimum length (10 digits for US number, 11 with country code)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Extract digits only
  let digits = cleaned.replace(/\+/g, '');
  
  // Remove optional +1 country code
  if (digits.startsWith('1') && digits.length === 11) {
    digits = digits.substring(1);
  }
  
  // Should be exactly 10 digits after country code removal
  if (digits.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  // const areaCode = parseInt(digits.substring(0, 3), 10);
  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) - cannot start with 0 or 1
  if (digits[3] === '0' || digits[3] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers.
 * - Handles landlines and mobiles
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber: 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other punctuation except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Extract digits
  let digits = cleaned.replace(/\+/g, '');
  
  // Check for country code +54
  let hasCountryCode = false;
  if (digits.startsWith('54')) {
    hasCountryCode = true;
    digits = digits.substring(2);
  }
  
  // Check for trunk prefix 0 (required if no country code)
  let hasTrunkPrefix = false;
  if (digits.startsWith('0')) {
    hasTrunkPrefix = true;
    digits = digits.substring(1);
  }
  
  // If no country code, trunk prefix is required
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  // Check for mobile indicator 9
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Now we should have area code + subscriber number
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }
  
  // Try different area code lengths (2-4 digits)
  for (const areaLen of [2, 3, 4]) {
    if (digits.length < areaLen + 6) {
      continue;
    }
    
    const areaCode = digits.substring(0, areaLen);
    const subscriber = digits.substring(areaLen);
    
    // Area code must start with 1-9
    if (!/^[1-9]/.test(areaCode)) {
      continue;
    }
    
    // Subscriber must be 6-8 digits
    if (subscriber.length >= 6 && subscriber.length <= 8) {
      return true;
    }
  }
  
  return false;
}

/**
 * Validate personal names.
 * - Allows unicode letters, accents, apostrophes, hyphens, spaces
 * - Rejects digits, symbols, and invalid patterns like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Name must have at least one character
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Regex that allows unicode letters, accents, apostrophes, hyphens, and spaces
  // But rejects digits and other symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for patterns that shouldn't be in a valid name
  // Reject if it contains sequences that look like "X Æ A-12" (numbers mixed with letters)
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for excessive special characters
  const specialCharCount = (value.match(/['-]/g) || []).length;
  if (specialCharCount > 3) {
    return false;
  }
  
  return true;
}

/**
 * Run Luhn algorithm checksum on credit card number.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  
  let sum = 0;
  let doubleDigit = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (doubleDigit) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    doubleDigit = !doubleDigit;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * - Accepts Visa, Mastercard, AmEx
 * - Validates prefix and length
 * - Runs Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d{13,19}$/.test(cleaned)) {
    return false;
  }
  
  // Check card type prefixes and lengths
  const isValidPrefixAndLength = 
    // Visa: starts with 4, length 13, 16, or 19
    (/^4\d{12}(?:\d{3,6})?$/.test(cleaned)) ||
    // Mastercard: starts with 51-55 or 2221-2720, length 16
    (/^(?:5[1-5]\d{14}|2[2-7][0-9]{14})$/.test(cleaned)) ||
    // AmEx: starts with 34 or 37, length 15
    (/^3[47]\d{13}$/.test(cleaned));
  
  if (!isValidPrefixAndLength) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
