/**
 * Find words starting with a prefix, excluding specified exceptions.
 * - Uses word boundaries to match complete words
 * - Returns array of matched words
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with prefix
  // \b ensures we match whole words only
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions and duplicates
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  const uniqueMatches = [...new Set(matches.map(m => m.toLowerCase()))];
  
  return uniqueMatches.filter(word => !exceptionSet.has(word));
}

/**
 * Find occurrences of token only when it appears after a digit and not at string start.
 * - Uses lookahead/lookbehind to enforce position constraints
 * - Returns array of matched token occurrences (including the digit)
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token
  // Then filter out matches that are at the start of the string
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches: string[] = [];
  let match: RegExpExecArray | null;
  
  while ((match = pattern.exec(text)) !== null) {
    // Only include if not at the start of the string
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validate password strength.
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol/special character
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one special character (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, abcabc, 123123)
  // This looks for any pattern of 2-4 characters that repeats immediately
  const repeatedPattern = /(.{2,4})\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses.
 * - Detects IPv6 including shorthand with ::
 * - Ensures IPv4 addresses don't trigger positive result
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern:
  // - Can use :: for shorthand (compressed zeros)
  // - Contains hexadecimal groups separated by colons
  // - Has 8 groups of 1-4 hex digits (fewer when using ::)
  // - Can have IPv4 embedded in last 32 bits (::ffff:192.168.1.1)
  
  // First, ensure it's not a plain IPv4 address
  // IPv4: 4 groups of 1-3 digits separated by dots
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // More precise IPv6 regex that handles all valid formats
  // 1-7 groups of hex digits, optional ::, potentially ending with IPv4
  const ipv6DetailedPattern = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}\d){0,1}\d)\.){3}(25[0-5]|(2[0-4]|1{0,1}\d){0,1}\d)|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}\d){0,1}\d)\.){3}(25[0-5]|(2[0-4]|1{0,1}\d){0,1}\d))/;
  
  // Check for IPv6 patterns in the text
  return ipv6DetailedPattern.test(value);
}
