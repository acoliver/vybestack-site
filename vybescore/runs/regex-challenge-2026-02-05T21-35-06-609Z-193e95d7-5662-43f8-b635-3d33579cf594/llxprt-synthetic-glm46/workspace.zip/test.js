#!/usr/bin/env node

// Test script to verify the implementations work correctly
import { isValidEmail, isValidUSPhone, isValidArgentinePhone, isValidName, isValidCreditCard } from './lib/validators.js';
import { capitalizeSentences, extractUrls, enforceHttps, rewriteDocsUrls, extractYear } from './lib/transformations.js';
import { findPrefixedWords, findEmbeddedToken, isStrongPassword, containsIPv6 } from './lib/puzzles.js';

console.log('=== Email Validation ===');
console.log(`user@example.com -> ${isValidEmail('user@example.com')}`);
console.log(`user@@example..com -> ${isValidEmail('user@@example..com')}`);
console.log(`name+tag@example.co.uk -> ${isValidEmail('name+tag@example.co.uk')}`);

console.log('\n=== Phone Validation ===');
console.log(`(212) 555-7890 -> ${isValidUSPhone('(212) 555-7890')}`);
console.log(`+54 9 11 1234 5678 -> ${isValidArgentinePhone('+54 9 11 1234 5678')}`);

console.log('\n=== Transformations ===');
console.log(`capitalizeSentences -> "${capitalizeSentences('hello world. how are you?')}"`);
console.log(`extractUrls -> ${JSON.stringify(extractUrls('Visit http://example.com and https://test.org!'))}`);
console.log(`enforceHttps -> "${enforceHttps('http://example.com https://secure.com')}"`);

console.log('\n=== Puzzles ===');
console.log(`findPrefixedWords -> ${JSON.stringify(findPrefixedWords('preview prevent prefix', 'pre', ['prevent']))}`);
console.log(`findEmbeddedToken -> ${JSON.stringify(findEmbeddedToken('xfoo 1foo foo', 'foo'))}`);
console.log(`isStrongPassword -> ${isStrongPassword('Abcdef!234')}`);
console.log(`containsIPv6 -> ${containsIPv6('Address: 2001:db8::1')}`);
console.log(`containsIPv6 -> ${containsIPv6('IP: 192.168.1.1')}`);