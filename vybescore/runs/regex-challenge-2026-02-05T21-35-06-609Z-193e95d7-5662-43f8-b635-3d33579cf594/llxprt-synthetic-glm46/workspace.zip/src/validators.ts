export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using regex patterns
 * - Accept typical addresses like name+tag@example.co.uk
 * - Reject double dots, trailing dots, domains with underscores
 * - Reject other obviously invalid forms
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  const noDoubleDots = !value.includes('..');
  const noTrailingDot = !value.endsWith('.');
  const noUnderscoreInDomain = !/@.*_/.test(value);
  
  return emailRegex.test(value) && noDoubleDots && noTrailingDot && noUnderscoreInDomain;
}

/**
 * Validate US phone numbers supporting common formats
 * - Formats: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallow impossible area codes (leading 0/1)
 * - Disallow too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  const cleanNumber = value.replace(/\D/g, ''); // Remove non-digit characters
  
  // Too short or too long
  if (cleanNumber.length < 10 || cleanNumber.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with 1 for country code
  if (cleanNumber.length === 11 && cleanNumber[0] !== '1') {
    return false;
  }
  
  // Extract area code (first 3 digits of the actual 10-digit number)
  const areaCodeIndex = cleanNumber.length === 11 ? 1 : 0;
  const areaCode = cleanNumber.substring(areaCodeIndex, areaCodeIndex + 3);
  
  // Disallow area codes starting with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check overall format using regex
  const phoneRegex = /^(?:\+1\s*)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers for landlines and mobiles
 * Formats: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - When no country code, must begin with trunk prefix 0
 * - Allow spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleanNumber = value.replace(/[-\s]/g, '');
  
  // Check for +54 country code
  const hasCountryCode = cleanNumber.startsWith('+54');
  const numberWithoutCountry = hasCountryCode ? cleanNumber.slice(3) : cleanNumber;
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !numberWithoutCountry.startsWith('0')) {
    return false;
  }
  
  // Extract components
  let areaCode = '';
  let subscriberNumber = '';
  
  const remaining = numberWithoutCountry;
  
  // Extract area code (2-4 digits, first digit 1-9)
  let areaCodeLength = 2;
  while (areaCodeLength <= 4 && areaCodeLength <= remaining.length && remaining[areaCodeLength - 1] !== '0') {
    areaCodeLength++;
  }
  if (areaCodeLength > 4) areaCodeLength = 4;
  
  areaCodeLength--; // Adjust for while loop condition
  
  areaCode = remaining.slice(0, areaCodeLength);
  if (areaCode.length < 2 || areaCode[0] === '0') {
    return false;
  }
  
  // Extract subscriber number (remaining digits)
  subscriberNumber = remaining.slice(areaCodeLength);
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  // Validate all parts are digits
  if (!/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  // Final regex validation for overall structure
  const argentinePhoneRegex = /^(?:\+54[-\s]*)?(?:0[-\s]*)?(?:9[-\s]*)?[1-9]\d{1,3}[-\s]?\d{2,4}[-\s]?\d{2,4}$/;
  return argentinePhoneRegex.test(value);
}

/**
 * Validate personal names allowing unicode characters
 * - Permits unicode letters, accents, apostrophes, hyphens, spaces
 * - Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accented chars, apostrophes, hyphens, and spaces
  const validNameRegex = /^[\p{L}][\p{L}'\-\s]*[\p{L}]$/u;
  
  // Additional check for valid characters only
  const containsOnlyValidChars = /^[\p{L}'\-\s]+$/u.test(value);
  
  return validNameRegex.test(value) && containsOnlyValidChars;
}

// Helper function for Luhn checksum validation
function runLuhnCheck(digitString: string): boolean {
  const digits = digitString.split('').reverse().map(Number);
  const sum = digits.reduce((acc, digit, index) => {
    if (index % 2 === 1) {
      const doubled = digit * 2;
      return acc + (doubled > 9 ? doubled - 9 : doubled);
    }
    return acc + digit;
  }, 0);
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx)
 * Accept Visa/Mastercard/AmEx prefixes and lengths
 * Run a Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  // Remove non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(?:\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55, or 2221-2720 for new range
  const mastercardRegex = /^5[1-5]\d{14}$|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check format
  const isValidFormat = visaRegex.test(cleanValue) || 
                       mastercardRegex.test(cleanValue) || 
                       amexRegex.test(cleanValue);
  
  // Run Luhn checksum if format is valid
  return isValidFormat && runLuhnCheck(cleanValue);
}
