/**
 * Capitalize the first character of each sentence
 * - Capitalize first character after .?!
 * - Insert exactly one space between sentences
 * - Collapse extra spaces while preserving abbreviations
 */
export function capitalizeSentences(text: string): string {
  // First, trim and collapse multiple spaces to single spaces
  const cleanedText = text.replace(/\s+/g, ' ').trim();
  
  // Process sentences: look for sentence boundaries .?!
  const capitalizedText = cleanedText.replace(/(^|[.!?]\s+)([a-z])/g, (match, boundary, firstLetter) => {
    return boundary + firstLetter.toUpperCase();
  });
  
  return capitalizedText;
}

/**
 * Find URLs in the text and return them without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs
  const urlPattern = /https?:\/\/(?:[a-zA-Z0-9-]+\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/g;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation from matches
  return matches.map(url => url.replace(/[.!?,;:)]*$/g, ''));
}

/**
 * Force all http URLs to https
 * Replace http:// with https:// while leaving existing secure URLs untouched
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite URLs for example.com based on rules:
 * - Always upgrade the scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite when path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/[^\s]*)/g, (match, path) => {
    // Always upgrade to https:// first
    let newUrl = 'https://example.com' + path;
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints that should prevent host rewrite
      const dynamicPatterns = [
        /\/cgi-bin\//,
        /[?&=]/,
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?&]|$)/
      ];
      
      const hasDynamicHint = dynamicPatterns.some(pattern => 
        path.match(pattern)
      );
      
      // If no dynamic hints, rewrite host to docs.example.com
      if (!hasDynamicHint) {
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings
 * Return 'N/A' when the format is invalid or month/day are invalid
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, month, day, year] = dateMatch;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month (1-12)
  if (monthNum < 1 || monthNum > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const maxDays = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const yearNum = parseInt(year, 10);
  let febMax = 28;
  if ((yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0)) {
    febMax = 29;
  }
  
  // Check day validity
  const isLeapYear = febMax === 29 && monthNum === 2 && (dayNum >= 1 && dayNum <= febMax);
  const isNormalDay = dayNum >= 1 && dayNum <= maxDays[monthNum - 1];
  
  if (isLeapYear || isNormalDay) {
    return year;
  }
  
  return 'N/A';
}
