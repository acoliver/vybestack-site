/**
 * Find words starting with the prefix but excluding exceptions
 * Return array of matches
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
// Build a regex to match words with the prefix
  const prefixRegex = new RegExp('\\b(' + prefix + '\\w*)\\b', 'g');
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case insensitive)
  const filteredMatches = matches.filter(match => {
    return !exceptions.some(exception => 
      exception.toLowerCase() === match.toLowerCase()
    );
  });
  
  return filteredMatches;
}

/**
 * Find occurrences of token only when it appears after a digit and not at start
 * Use lookaheads/lookbehinds to find specific cases
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use lookbehind to find token preceded by digit, but not at string start
  const tokenRegex = new RegExp('\\d' + escapedToken, 'g');
  
  // Find all matches (including the digit)
  return (text.match(tokenRegex) || []).map(match => match);
}

/**
 * Validate passwords according to policy
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for required character classes
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^\w\s]/.test(value); // Non-alphanumeric and non-whitespace
  const noWhitespace = !/\s/.test(value);
  
  // Check for immediate repeated sequences (like 'abab')
  const hasImmediateRepeats = /(.+?)\1/.test(value);
  
  // Additional check for complex repeats like pattern repeats
  const hasComplexRepeats = /(.{3,}).*\1/.test(value);
  
  return hasUpper && hasLower && hasDigit && hasSymbol && noWhitespace 
    && !hasImmediateRepeats && !hasComplexRepeats;
}

/**
 * Detect IPv6 addresses (including shorthand ::)
 * Ensure IPv4 addresses do not trigger positive result
 */
export function containsIPv6(value: string): boolean {
  // First check for IPv4 addresses to exclude them
  const hasIPv4 = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/.test(value);
  
  if (hasIPv4) {
    // Check if it might be an IPv6 address with IPv4 embedded (IPv4-mapped IPv6)
    // In this case, we should consider it IPv6
    return /::ffff:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(value);
  }
  
  // Find any IPv6 address in the string
  const ipv6Match = value.match(/\b(?:[0-9a-f]{1,4}:){1,7}[0-9a-f]{1,4}\b|\b(?:[0-9a-f]{1,4}:)*:(?:[0-9a-f]{1,4}:)*[0-9a-f]{1,4}?\b/gi);
  
  return ipv6Match !== null && ipv6Match.length > 0;
}
