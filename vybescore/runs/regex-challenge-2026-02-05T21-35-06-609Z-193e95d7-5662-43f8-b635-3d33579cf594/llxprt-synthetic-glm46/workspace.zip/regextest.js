// Test regex patterns for our implementations
console.log("=== EMAIL VALIDATION ===");
const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
console.log("user@example.com:", emailRegex.test("user@example.com"));
console.log("user@@example..com:", emailRegex.test("user@@example..com"));
console.log("name+tag@example.co.uk:", emailRegex.test("name+tag@example.co.uk"));

console.log("\n=== PHONE VALIDATION ===");
const usPhoneRegex = /^(?:\+1\s*)?\(?([2-9]\d{2})\)?[-.\s]?([2-9]\d{2})[-.\s]?(\d{4})$/;
console.log("(212) 555-7890:", usPhoneRegex.test("(212) 555-7890"));
console.log("2125557890:", usPhoneRegex.test("2125557890"));
console.log("+1 (212) 555-7890:", usPhoneRegex.test("+1 (212) 555-7890"));

console.log("\n=== TRANSFORMATION ===");
const capitalized = "hello world. how are you?i'm fine".trim().replace(/\s+/g, ' ').replace(/(^|[.!?]\s+)([a-z])/g, (match, boundary, firstLetter) => boundary + firstLetter.toUpperCase());
console.log("Capitalize result:", capitalized);

console.log("\n=== PUZZLES ===");
const ipv6Regex = /\b(?:[0-9a-f]{1,4}:){1,7}[0-9a-f]{1,4}\b|\b(?:[0-9a-f]{1,4}:)*:(?:[0-9a-f]{1,4}:)*[0-9a-f]{1,4}?\b/gi;
console.log("IPv6 detection:", ipv6Regex.test("Address: 2001:db8::1"));
console.log("IPv4 detection:", ipv6Regex.test("IP: 192.168.1.1"));

const prefixMatches = "preview prevent prefix".match(/\b(pre\w*)\b/g) || [];
const filteredMatches = prefixMatches.filter(match => !["prevent"].includes(match));
console.log("Prefix matches:", filteredMatches);