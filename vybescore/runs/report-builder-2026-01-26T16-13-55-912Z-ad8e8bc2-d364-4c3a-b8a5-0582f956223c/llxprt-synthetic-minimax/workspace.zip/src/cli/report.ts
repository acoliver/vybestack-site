import { readFileSync, writeFileSync } from 'fs';
import { join } from 'path';
import { ReportData, ReportOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

const formatters = {
  markdown: markdownFormatter,
  text: textFormatter
};

interface ParsedArgs {
  dataFile: string;
  options: ReportOptions;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[2];
  const options: ReportOptions = { format: 'markdown' };
  let i = 3;

  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      const format = args[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        console.error('Unsupported format');
        process.exit(1);
      }
      options.format = format as 'markdown' | 'text';
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
      i += 1;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!options.format || (options.format !== 'markdown' && options.format !== 'text')) {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  return { dataFile, options };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: missing or invalid "entries" field');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}] missing or invalid "label" field`);
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error(`Invalid data: entries[${i}] missing or invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('JSON')) {
        console.error('Error: Invalid JSON file');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read or parse data file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: ReportOptions): string {
  const formatter = formatters[options.format];
  
  if (!formatter) {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  return formatter.render(data, options);
}

function main(): void {
  const args = process.argv;
  const { dataFile, options } = parseArgs(args);
  
  // Ensure .json extension if not provided
  const finalDataFile = dataFile.endsWith('.json') ? dataFile : `${dataFile}.json`;
  const dataPath = join(process.cwd(), finalDataFile);
  
  const reportData = loadReportData(dataPath);
  const output = renderReport(reportData, options);
  
  if (options.output) {
    try {
      const outputPath = join(process.cwd(), options.output);
      writeFileSync(outputPath, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file - ${error instanceof Error ? error.message : 'unknown error'}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
