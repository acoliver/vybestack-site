import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createServer } from 'node:http';

let server: import('node:http').Server | undefined;
const dbPath = path.resolve('data', 'submissions.sqlite');

// Import the built application
let app: import('express').Express;

beforeAll(async () => {
  // Clean up any existing test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import the built application
  const module = await import('../../dist/server.js');
  app = module.default || module.app;
  
  // Create and start test server
  server = createServer(app);
  await new Promise(resolve => server.listen(0, resolve));
  (global as typeof globalThis & { server?: import('node:http').Server }).server = server;
});

beforeAll(async () => {
  // Clean up any existing test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import and start server
  const { createServer } = await import('node:http');
  server = createServer(app);
  await new Promise(resolve => server.listen(0, resolve));
  (global as typeof globalThis & { server?: import('node:http').Server }).server = server;
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = load(response.text);
    
    // Check for all form fields
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check for form structure
    expect($('form[method="post"]').length).toBe(1);
    expect($('form[action="/submit"]').length).toBe(1);
    expect($('form button[type="submit"]').length).toBe(1);
  });

  it('handles validation errors', async () => {
    // Submit incomplete form
    const response = await request(app)
      .post('/submit')
      .type('application/x-www-form-urlencoded')
      .send({
        firstName: 'John',
        lastName: '', // Missing required field
        email: 'invalid-email' // Invalid email
      });
    
    expect(response.status).toBe(400);
    
    const $ = load(response.text);
    expect($('.error-list').length).toBeGreaterThan(0);
    expect($('input[name="firstName"]').val()).toBe('John');
  });

  it('persists submission and redirects', async () => {
    // Clean database first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const submissionData = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62704',
      country: 'USA',
      email: 'jane.doe@example.com',
      phone: '+1 (555) 123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('application/x-www-form-urlencoded')
      .send(submissionData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database was created and contains data
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = load(response.text);
    expect($('h1').text()).toContain('Thank you');
    expect($('a[href="/"]').length).toBe(1);
    expect($('.thankyou-card').length).toBe(1);
  });

  it('accepts international phone numbers and postal codes', async () => {
    // Clean database first
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const internationalData = {
      firstName: 'Giovanni',
      lastName: 'Rossi',
      streetAddress: 'Via del Corso 123',
      city: 'Roma',
      stateProvince: 'RM',
      postalCode: '00186',
      country: 'Italia',
      email: 'giovanni.rossi@esempio.it',
      phone: '+39 06 1234 5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('application/x-www-form-urlencoded')
      .send(internationalData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
