import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Configure EJS templates
app.set('views', path.join(process.cwd(), 'dist', 'templates'));
app.set('view engine', 'ejs');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files from public directory
app.use('/public', express.static(path.join(process.cwd(), 'public')));

// Database setup
let db: Database | null = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone'
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors.push({
        field,
        message: `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`
      });
    }
  }

  // Email validation (simple but effective)
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation (allow digits, spaces, parentheses, dashes, and leading +)
  if (data.phone && !/^[+]?[\d\s()-]+$/.test(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal code'
    });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    return res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
  }

  // Insert into database
  if (db) {
    try {
      db.run(
        `INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]
      );

      // Save database to file
      const data = db.export();
      const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      fs.writeFileSync(dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Database error:', error);
      return res.status(500).render('form', {
        errors: ['An error occurred while saving your information. Please try again.'],
        values: formData
      });
    }
  }

  // Redirect to thank you page
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.name || 'friend';
  res.render('thank-you', {
    firstName
  });
});

// Database initialization
async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => {
      return `node_modules/sql.js/dist/${file}`;
    }
  });

  const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');

  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(dbPath)) {
    // Load existing database
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    // Create new database
    db = new SQL.Database();
    
    // Read and execute schema
    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      
      // Split schema into individual statements and execute
      const statements = schema.split(';').filter(stmt => stmt.trim());
      for (const statement of statements) {
        if (statement.trim()) {
          db.exec(statement.trim());
        }
      }
    }
  }
}

// Graceful shutdown
async function gracefulShutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  
  if (db) {
    const data = db.export();
    const dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    
    try {
      fs.writeFileSync(dbPath, Buffer.from(data));
      db.close();
      console.log('Database saved and closed.');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

// Hook into SIGTERM for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log('Visit http://localhost:' + PORT + ' to see the form');
    });

    // Store server reference for tests
    (global as typeof globalThis & { server?: typeof server }).server = server;
    
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(console.error);

export default app;
