/**
 * Finds words beginning with the specified prefix but excluding the listed exceptions.
 * Returns an array of matched words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix || typeof text !== 'string' || typeof prefix !== 'string') {
    return [];
  }

  if (!Array.isArray(exceptions)) {
    return [];
  }

  // Create a Set of exceptions for efficient lookup (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  
  // Pattern to match words with the specified prefix
  // \b ensures we match whole words
  const wordPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions and remove duplicates
  const uniqueWords = new Set<string>();
  
  for (const word of matches) {
    const lowerWord = word.toLowerCase();
    if (!exceptionSet.has(lowerWord)) {
      uniqueWords.add(word);
    }
  }
  
  return Array.from(uniqueWords);
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to ensure the token is properly positioned.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token || typeof text !== 'string' || typeof token !== 'string') {
    return [];
  }

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to find token that:
  // - Is preceded by a digit (lookbehind)
  // - Is not at the start of the string
  // - Uses word boundaries to avoid partial matches
  const tokenPattern = new RegExp(`\\b\\d${escapedToken}\\b`, 'g');
  
  const matches = text.match(tokenPattern) || [];
  
  // Extract just the digit+token part to match expected output
  const digitTokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const results = matches.map(match => {
    const match2 = match.match(digitTokenPattern);
    return match2 ? match2[0] : match;
  });
  
  // Remove duplicates while preserving order
  const uniqueMatches: string[] = [];
  const seen = new Set<string>();
  
  for (const match of results) {
    if (!seen.has(match)) {
      seen.add(match);
      uniqueMatches.push(match);
    }
  }
  
  return uniqueMatches;
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Minimum length requirement
  if (value.length < 10) {
    return false;
  }

  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }

  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }

  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }

  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }

  // Check for at least one symbol (non-alphanumeric)
  if (!/[^\w]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (pattern like abab, abcabc, etc.)
  // This regex looks for any sequence of 2-4 characters that repeats immediately
  if (/(.{2,4})\1/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 * Returns true if IPv6 address is found, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // IPv6 address patterns
  // Full IPv6: eight groups of four hex digits separated by colons
  const fullIPv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Compressed IPv6 with :: (can compress any number of groups)
  const compressedIPv6Pattern = /(?:[0-9a-fA-F]{1,4}:){0,6}::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}/;
  
  // IPv6 with embedded IPv4 (e.g., ::ffff:192.168.1.1)
  const ipv6WithIPv4Pattern = /(?:[0-9a-fA-F]{1,4}:){1,6}:(?:\d{1,3}\.){3}\d{1,3}/;
  
  // IPv6 with :: and embedded IPv4
  const compressedIPv6WithIPv4Pattern = /::(?:[0-9a-fA-F]{1,4}:){0,4}:(?:\d{1,3}\.){3}\d{1,3}/;

  // Check for IPv4 addresses to ensure they don't trigger false positives
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;

  // First check if this looks like an IPv4 address
  if (ipv4Pattern.test(value)) {
    // If it's just IPv4 without IPv6 context, return false
    if (!fullIPv6Pattern.test(value) && !compressedIPv6Pattern.test(value) && 
        !ipv6WithIPv4Pattern.test(value) && !compressedIPv6WithIPv4Pattern.test(value)) {
      return false;
    }
  }

  // Check for IPv6 patterns
  return fullIPv6Pattern.test(value) || 
         compressedIPv6Pattern.test(value) || 
         ipv6WithIPv4Pattern.test(value) || 
         compressedIPv6WithIPv4Pattern.test(value);
}
