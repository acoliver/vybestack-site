export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive rules.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Basic structure check for email
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Check for invalid patterns
  const invalidPatterns = [
    /\.\./,           // double dots
    /\.$/,            // trailing dot
    /^\./,            // leading dot
    /@.*_/,           // underscore in domain
    /@.*\.\./,        // double dots in domain
    /@\./,            // domain starts with dot
    /\.@/,            // domain ends with dot before @
    /@.*\.$/,         // domain ends with dot
  ];

  // If any invalid pattern is found, reject
  for (const pattern of invalidPatterns) {
    if (pattern.test(value)) {
      return false;
    }
  }

  return emailRegex.test(value);
}

/**
 * Validates US phone numbers supporting common formats.
 * Accepts (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove all non-digit characters except + for country code
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check if it has a valid country code
  const hasCountryCode = cleaned.startsWith('+1');
  const digitsOnly = hasCountryCode ? cleaned.substring(2) : (cleaned.startsWith('+') ? cleaned.substring(1) : cleaned);
  
  // Must have exactly 10 digits for US phone number
  if (digitsOnly.length !== 10) {
    return false;
  }

  // Extract area code (first 3 digits)
  const areaCode = digitsOnly.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }

  // Validate the original format is one of the accepted patterns
  const validPatterns = [
    /^\+?1?\s*\(\s*\d{3}\s*\)\s*\d{3}\s*-\s*\d{4}$/,    // (212) 555-7890 with optional +1
    /^\+?1?\s*\d{3}\s*-\s*\d{3}\s*-\s*\d{4}$/,          // 212-555-7890 with optional +1
    /^\+?1?\s*\d{10}$/,                                 // 2125557890 with optional +1
    /^\+?1?\s*\d{3}\s*\d{3}\s*\d{4}$/,                  // 212 555 7890 with optional +1
  ];

  return validPatterns.some(pattern => pattern.test(value));
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - When country code is omitted, number must begin with trunk prefix 0
 * - Allow single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern for Argentine phone numbers
  // Format: [+54][9][areaCode][subscriber]
  const argentinePhoneRegex = /^\+?(54)?(9)?(\d{2,4})(\d{6,8})$/;
  
  // Pattern for numbers without country code (must start with 0)
  const localPhoneRegex = /^0(\d{2,4})(\d{6,8})$/;
  
  let match;
  let hasCountryCode = false;
  
  // Try to match with country code pattern first
  if (cleaned.startsWith('+')) {
    match = cleaned.match(argentinePhoneRegex);
    hasCountryCode = true;
  } else {
    // Try local pattern first (must start with 0)
    if (cleaned.startsWith('0')) {
      match = cleaned.match(localPhoneRegex);
    } else {
      // Try country code pattern without +
      match = cleaned.match(argentinePhoneRegex);
      if (match && match[1]) {
        hasCountryCode = true;
      }
    }
  }
  
  if (!match) {
    return false;
  }
  
  // Extract area code and subscriber number
  const areaCode = match[3];
  const subscriberNumber = match[4];
  
  // Validate area code: 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // If no country code in match, it must be a local number starting with 0
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 * Accepts names like John Doe, María García, O'Connor, Jean-Luc, but rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Trim whitespace
  const trimmed = value.trim();
  
  // Must have at least one character and not be empty after trimming
  if (!trimmed) {
    return false;
  }

  // Pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes and hyphens
  // - Spaces
  // - Must contain at least one letter
  const namePattern = /^[a-zA-Z\u00C0-\u017F\s'-]+$/u;
  
  // Check if the name contains only allowed characters
  if (!namePattern.test(trimmed)) {
    return false;
  }

  // Must contain at least one letter (to reject names with only symbols)
  const hasLetter = /[a-zA-Z\u00C0-\u017F]/.test(trimmed);
  if (!hasLetter) {
    return false;
  }

// Reject names that contain numbers or other symbols
  if (/[0-9@#$%^&*()_+=[\]{}|\\;:'",.<>?/~`]/.test(trimmed)) {
    return false;
  }

// Reject names that have consecutive symbols that look weird
  if (/['’-]{2,}/.test(trimmed)) {
    return false;
  }

  // Reject names that start or end with symbols
  if (/^[‘''-]/.test(trimmed) || /[‘''-]$/.test(trimmed)) {
    return false;
  }

  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit card numbers.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(digit => parseInt(digit, 10));
  
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx.
 * Checks valid prefixes, lengths, and runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }

  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length (13-19 digits for major cards)
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }

  // Visa: starts with 4, length 13 or 16 digits
  const visaPattern = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55, 2221-2720, length 16 digits
  const mastercardPattern = /^((51|52|53|54|55)\d{14}|(222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12})$/;
  
  // American Express: starts with 34 or 37, length 15 digits
  const amexPattern = /^3[47]\d{13}$/;

  // Check if it matches any of the supported card patterns
  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
