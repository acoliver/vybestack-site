/**
 * Capitalizes the first character of each sentence.
 * Rules:
 * - Capitalize the first character after .?!
 * - Insert exactly one space between sentences if missing
 * - Collapse extra spaces while preserving abbreviations when possible
 * - Handle quoted text properly
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // First, normalize spaces around sentence punctuation
  const processed = text
    // Replace multiple spaces with single space
    .replace(/\s+/g, ' ')
    // Ensure space after sentence punctuation if not followed by space
    .replace(/([.!?])(?=[A-Za-z])/g, '$1 ')
    // Remove space before punctuation
    .replace(/\s+([.!?])/g, '$1')
    // Handle quotes properly - space before opening quote after punctuation
    .replace(/([.!?])\s*"/g, '$1 "')
    // Trim leading/trailing spaces
    .trim();

  // Common abbreviations that shouldn't trigger capitalization
  const abbreviations = [
    'Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Ave', 'Blvd', 'Rd', 'St',
    'etc', 'e.g', 'i.e', 'vs', 'al', 'et', 'ca', 'approx', 'est', 'no', 'vol',
    'fig', 'ref', 'p', 'pp', 'ed', 'eds', 'trans', 'dept', 'univ', 'assn', 'bldg',
    'ft', 'lbs', 'oz', 'sq', 'mi', 'km', 'mph', 'hz', 'khz', 'mhz', 'ghz'
  ];

  // Split text into sentences using a more sophisticated approach
  const sentences = processed.split(/(?<=[.!?])\s+/);
  
  const capitalizedSentences = sentences.map((sentence, index) => {
    if (!sentence) return '';
    
    // For the first sentence, always capitalize the first letter
    if (index === 0) {
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    // For subsequent sentences, check if the punctuation before was followed by an abbreviation
    const prevSentenceEnd = sentences[index - 1];
    if (prevSentenceEnd) {
      const lastWords = prevSentenceEnd.toLowerCase().split(/\s+/).slice(-2);
      const isAbbreviation = abbreviations.some(abbr => 
        lastWords.some(word => word.includes(abbr.toLowerCase()))
      );
      
      if (isAbbreviation) {
        return sentence; // Don't capitalize if it follows an abbreviation
      }
    }
    
    // Capitalize the first character that's a letter
    const firstLetterIndex = sentence.search(/[a-zA-Z\u00C0-\u017F]/);
    if (firstLetterIndex === -1) {
      return sentence;
    }
    
    return sentence.slice(0, firstLetterIndex) + 
           sentence.charAt(firstLetterIndex).toUpperCase() + 
           sentence.slice(firstLetterIndex + 1);
  });

  return capitalizedSentences.join(' ');
}

/**
 * Extracts URLs from text, returning matches without trailing punctuation.
 * Supports http, https, ftp protocols and common URL patterns.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') {
    return [];
  }

  // Comprehensive URL pattern that matches most common URL formats
  const urlPattern = /(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"'`{}|\\^`[\]]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that's unlikely to be part of the URL
    return url.replace(/[.,;:!?'"`)\]}]+$/g, '');
  }).filter(url => url.length > 0); // Filter out empty strings after cleaning

  // Remove duplicates while preserving order
  const uniqueUrls: string[] = [];
  const seen = new Set<string>();
  
  for (const url of cleanedUrls) {
    if (!seen.has(url)) {
      seen.add(url);
      uniqueUrls.push(url);
    }
  }

  return uniqueUrls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// with https:// in all occurrences.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Replace http:// with https://, but not https:// (to avoid double replacement)
  // Use negative lookbehind to avoid matching https://
  return text.replace(/(?<!https:)http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to specific rules:
 * - Always upgrade the scheme to https://
 * - When the path begins with /docs/, rewrite the host to docs.example.com
 * - Skip the host rewrite when the path contains dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') {
    return '';
  }

  // Pattern to match URLs with example.com host
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;

  return text.replace(urlPattern, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if we should skip host rewrite due to dynamic hints
    const dynamicHints = [
      'cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', 
      '.aspx', '.do', '.cgi', '.pl', '.py'
    ];
    
    const hasDynamicHints = dynamicHints.some(hint => path.includes(hint));
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      return newScheme + 'docs.' + host + path;
    }
    
    // Otherwise, just upgrade the scheme
    return newScheme + host + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }

  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3]; // Keep as string for return
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    28, // February (leap year handled below)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  // Check leap year for February
  const isLeapYear = (year: string): boolean => {
    const yearNum = parseInt(year, 10);
    return (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  };
  
  const maxDays = month === 2 && isLeapYear(year) ? 29 : daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
