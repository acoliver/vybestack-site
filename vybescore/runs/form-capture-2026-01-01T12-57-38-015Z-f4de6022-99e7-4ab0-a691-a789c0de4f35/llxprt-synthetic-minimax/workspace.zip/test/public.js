const http = require('http');

const BASE_URL = 'http://localhost:3535';

// Test server endpoints
function testServer() {
  console.log(' Testing public endpoints...\n');

  // Test GET /
  testEndpoint('GET /', '/', (res, body) => {
    const success = res.statusCode === 200 && 
                   body.includes('Friendly International Contact Form') &&
                   body.includes('name="firstName"') &&
                   body.includes('name="email"');
    
    return {
      passed: success,
      message: success ? 'Form page loads correctly' : 'Form page missing required elements'
    };
  });

  // Test POST /submit with valid data
  setTimeout(() => {
    testEndpoint('POST /submit (valid)', '/submit', (res, body) => {
      // Should redirect to /thank-you
      const success = res.statusCode === 302 && 
                    res.headers.location === '/thank-you';
      
      return {
        passed: success,
        message: success ? 'Valid submission redirects correctly' : 'Valid submission failed to redirect'
      };
    }, {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvinceRegion: 'NY',
      postalZipCode: '10001',
      country: 'United States',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    });
  }, 1000);

  // Test POST /submit with invalid data
  setTimeout(() => {
    testEndpoint('POST /submit (invalid)', '/submit', (res, body) => {
      const success = res.statusCode === 400 && 
                    body.includes('Please fix the following errors');
      
      return {
        passed: success,
        message: success ? 'Invalid submission shows errors' : 'Invalid submission failed validation'
      };
    }, {
      firstName: '',
      lastName: '',
      email: 'invalid-email',
      phone: ''
    });
  }, 2000);

  // Test GET /thank-you
  setTimeout(() => {
    testEndpoint('GET /thank-you', '/thank-you', (res, body) => {
      const success = res.statusCode === 200 && 
                    body.includes('Thank You') &&
                    body.includes('definitely not suspicious');
      
      return {
        passed: success,
        message: success ? 'Thank you page loads correctly' : 'Thank you page missing elements'
      };
    });
  }, 3000);

  // Test static CSS
  setTimeout(() => {
    testEndpoint('GET /styles.css', '/styles.css', (res, body) => {
      const success = res.statusCode === 200 && 
                    body.includes('body') &&
                    body.includes('.container');
      
      return {
        passed: success,
        message: success ? 'CSS file served correctly' : 'CSS file missing or incorrect'
      };
    });
  }, 4000);

  console.log('\n[OK] Public API tests completed!');
}

function testEndpoint(testName, path, callback, formData = null) {
  const options = {
    hostname: 'localhost',
    port: 3535,
    path: path,
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    }
  };

  // If no form data, it's a GET request
  if (!formData) {
    options.method = 'GET';
    delete options.headers['Content-Type'];
  }

  const req = http.request(options, (res) => {
    let body = '';
    
    res.on('data', (chunk) => {
      body += chunk;
    });
    
    res.on('end', () => {
      try {
        const result = callback(res, body);
        const icon = result.passed ? '[OK]' : '[ERROR]';
        console.log(`${icon} ${testName}: ${result.message}`);
        if (!result.passed) {
          console.log(`   Status: ${res.statusCode}`);
          console.log(`   Headers: ${JSON.stringify(res.headers)}`);
        }
      } catch (error) {
        console.log(`[ERROR] ${testName}: Error processing response - ${error.message}`);
      }
    });
  });

  req.on('error', (error) => {
    console.log(`[ERROR] ${testName}: Connection error - ${error.message}`);
  });

  if (formData) {
    const params = new URLSearchParams();
    Object.keys(formData).forEach(key => {
      params.append(key, formData[key]);
    });
    req.write(params.toString());
  }

  req.end();
}

// Wait a moment for server to be ready, then run tests
console.log(' Waiting for server to be ready...');
setTimeout(testServer, 2000);