import express, { Request, Response } from 'express';
import path from 'path';
import * as sqljs from 'sql.js';
import { DatabaseManager } from './database';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT) : 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// Database manager
const dbManager = new DatabaseManager(path.join(__dirname, '../data/submissions.sqlite'));
let serverInstance: import('http').Server | null = null;

// Types for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: keyof FormData;
  message: string;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Remove common formatting characters
  const cleanedPhone = phone.replace(/[\s\-()]/g, '');
  // Check if it starts with + and has digits, or just has digits
  const phoneRegex = /^(\+\d{1,3}\d{8,14}|\d{8,15})$/;
  return phoneRegex.test(cleanedPhone);
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with reasonable length for international formats
  const postalRegex = /^[A-Za-z0-9\s]{3,15}$/;
  return postalRegex.test(postalCode.trim());
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields check
  const requiredFields: (keyof FormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalZipCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors.push({ field, message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required` });
    }
  });

  // Email validation
  if (data.email && !validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation
  if (data.phone && !validatePhone(data.phone)) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation
  if (data.postalZipCode && !validatePostalCode(data.postalZipCode)) {
    errors.push({ field: 'postalZipCode', message: 'Please enter a valid postal/zip code' });
  }

  return errors;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', { 
    errors: [], 
    formData: {} 
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: (req.body.firstName || '').trim(),
    lastName: (req.body.lastName || '').trim(),
    streetAddress: (req.body.streetAddress || '').trim(),
    city: (req.body.city || '').trim(),
    stateProvinceRegion: (req.body.stateProvinceRegion || '').trim(),
    postalZipCode: (req.body.postalZipCode || '').trim(),
    country: (req.body.country || '').trim(),
    email: (req.body.email || '').trim(),
    phone: (req.body.phone || '').trim(),
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    return res.status(400).render('index', { 
      errors, 
      formData 
    });
  }

  try {
    await dbManager.insertSubmission(formData);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('index', { 
      errors: [{ field: 'general', message: 'An error occurred. Please try again.' }], 
      formData 
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal Server Error');
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  if (serverInstance) {
    serverInstance.close(() => {
      console.log('HTTP server closed');
      dbManager.close();
      console.log('Database closed');
      process.exit(0);
    });
  } else {
    dbManager.close();
    console.log('Database closed');
    process.exit(0);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Start server
async function startServer() {
  try {
    // Initialize SQL.js module
    const SQLModule = await sqljs.default();
    
    // Initialize database with the SQL module
    await dbManager.initialize(SQLModule);
    
    serverInstance = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;
