import * as fs from 'fs';
import * as path from 'path';

export interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseManager {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private db: any = null; // sql.js Database instance
  private dbPath: string;
  private schemaPath: string;
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  private sqlModule: any = null;

  constructor(dbPath: string, schemaPath?: string) {
    this.dbPath = dbPath;
    this.schemaPath = schemaPath || path.join(__dirname, '../db/schema.sql');
  }

  async initialize(sqlModule: any): Promise<void> {
    this.sqlModule = sqlModule;
    try {
      // Check if database file exists, create it if not
      const dir = path.dirname(this.dbPath);
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }

      if (fs.existsSync(this.dbPath)) {
        // Load existing database
        const buffer = fs.readFileSync(this.dbPath);
        this.db = new sqlModule.Database(buffer);
      } else {
        // Create new database
        this.db = new sqlModule.Database();
        this.createSchema();
      }
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private createSchema(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      // Read and execute schema
      const schema = fs.readFileSync(this.schemaPath, 'utf8');
      this.db.exec(schema);
      console.log('Database schema created successfully');
    } catch (error) {
      console.error('Failed to create schema:', error);
      throw error;
    }
  }

  async insertSubmission(submission: Submission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    try {
      const sql = `
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province_region, postal_zip_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `;

      const stmt = this.db.prepare(sql);
      stmt.run([
        submission.firstName,
        submission.lastName,
        submission.streetAddress,
        submission.city,
        submission.stateProvinceRegion,
        submission.postalZipCode,
        submission.country,
        submission.email,
        submission.phone
      ]);

      stmt.free();
      this.persistToDisk();
      console.log('Submission inserted successfully');
    } catch (error) {
      console.error('Failed to insert submission:', error);
      throw error;
    }
  }

  private persistToDisk(): void {
    if (!this.db) {
      return;
    }

    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error('Failed to persist database to disk:', error);
    }
  }

  close(): void {
    if (this.db) {
      try {
        this.persistToDisk();
        this.db.close();
        this.db = null;
        console.log('Database closed successfully');
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }
  }
}