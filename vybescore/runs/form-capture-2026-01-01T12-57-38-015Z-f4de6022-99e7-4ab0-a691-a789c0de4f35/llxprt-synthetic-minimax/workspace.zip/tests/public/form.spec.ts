import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import app from '../../src/server';
import type { Server } from 'http';

let server: Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // Start test server
  return new Promise<void>((resolve) => {
    const testPort = 3536;
    server = app.listen(testPort, () => {
      console.log(`Test server running on port ${testPort}`);
      resolve();
    });
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvinceRegion').length).toBe(1);
    expect($('#postalZipCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'New York',
      stateProvinceRegion: 'NY',
      postalZipCode: '10001',
      country: 'United States',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .type('formurlencoded')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Verify database was created and contains data
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
