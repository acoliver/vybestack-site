export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive regex.
 * Accept typical addresses such as name+tag@example.co.uk.
 * Reject double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for invalid patterns
  // No consecutive dots
  if (/\.\./.test(value)) {
    return false;
  }
  
  // No trailing dot in local or domain part
  if (/^\.|\.$/.test(value) || /@\./.test(value) || /\.$/.test(value.split('@')[1])) {
    return false;
  }
  
  // No underscores in domain
  if (/@.*_/.test(value)) {
    return false;
  }
  
  // Validate each part of the domain doesn't start or end with hyphen
  const domainParts = value.split('@')[1].split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers with common formats and optional +1 prefix.
 * Support (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallow impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Handle options parameter for future extensibility
  void options;
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits without country code, 11 with +1)
  if (digitsOnly.length < 10) {
    return false;
  }
  
  // Remove +1 prefix if present
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11 && digitsOnly.startsWith('1')) {
    phoneNumber = digitsOnly.substring(1);
  } else if (digitsOnly.length > 10) {
    // Invalid length (too long or wrong country code)
    return false;
  }
  
  // At this point, phone should be exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first 3 digits) - can't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate full format with regex
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\s*([2-9]\d{2})\s*\)|([2-9]\d{2})[\s-]?)(\d{3})[\s-]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers with mobile/landline formats.
 * Handle landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54.
 * - Optional trunk prefix 0 immediately before the area code.
 * - Optional mobile indicator 9 between country/trunk and the area code.
 * - Area code must be 2-4 digits (leading digit 1-9).
 * - Subscriber number (after the area code) must contain 6-8 digits in total.
 * - When the country code is omitted, the number must begin with trunk prefix 0 before the area code.
 * - Allow single spaces or hyphens as separators; ignore punctuation when validating.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanedPhone = value.replace(/[\s-]/g, '');
  
  // Regex to match Argentine phone format
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanedPhone.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validations - if country code is included, area code should not start with 0
  // If country code is omitted, area code must start with 0
  const hasCountryCode = cleanedPhone.startsWith('+54');
  if (hasCountryCode && areaCode.startsWith('0')) {
    return false;
  }
  if (!hasCountryCode && !areaCode.startsWith('0')) {
    return false;
  }
  
  // Check area code length (2-4 digits)
  const actualAreaCode = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (actualAreaCode.length < 2 || actualAreaCode.length > 4) {
    return false;
  }
  
  // Check subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Permit unicode letters, accents, apostrophes, hyphens, spaces.
 * Reject digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Regex to match names with unicode letters, spaces, hyphens, and apostrophes
  // \p{L} matches any unicode letter
  // \p{M} matches diacritical marks (accents)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject multiple consecutive apostrophes or hyphens
  if (/''|--/.test(value)) {
    return false;
  }
  
  // Reject names starting or ending with hyphen or apostrophe
  if (/^[-']|[-']$/.test(value.trim())) {
    return false;
  }
  
  // Don't allow only spaces or special characters
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for major brands and perform Luhn checksum.
 * Accept Visa/Mastercard/AmEx prefixes and lengths. Run a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleanedCard = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanedCard)) {
    return false;
  }
  
  // Check Luhn checksum first
  if (!runLuhnCheck(cleanedCard)) {
    return false;
  }
  
  // Check for valid credit card prefixes and lengths
  // Visa: starts with 4, length 13 or 16 digits
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16 digits
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d|3[0-9]\d|4[0-9]\d|5[0-9]\d|6[0-9]\d|7[01]\d|720)\d{12})$/;
  
  // American Express: starts with 34 or 37, length 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card matches any of the supported brands
  return visaRegex.test(cleanedCard) || mastercardRegex.test(cleanedCard) || amexRegex.test(cleanedCard);
}
