/**
 * Capitalize the first character of each sentence.
 * Capitalize the first character of each sentence (after .?!), insert exactly one space between sentences even if the input omitted it, and collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Return text with each sentence properly capitalized
  if (!text) return text;
  
  // First, collapse multiple spaces into a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Add space after sentence ending punctuation if missing
  // Match punctuation followed by lowercase letter or number without space
  result = result.replace(/([.?!])([a-z0-9])/g, '$1 $2');
  
  // Capitalize the first letter of the entire string
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Capitalize letters after sentence-ending punctuation
  result = result.replace(/([.?!])\s*([a-z])/g, function(match, punctuation, letter) {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Remove spaces before sentence-ending punctuation
  result = result.replace(/\s+([.?!])/g, '$1');
  
  // Ensure there's exactly one space after punctuation when followed by a letter or number
  result = result.replace(/([.?!])(?=\w)/g, '$1 ');
  
  // Handle common abbreviations and acronyms to preserve their format
  const abbreviations = ['e.g', 'i.e', 'etc', 'mr', 'mrs', 'ms', 'dr', 'prof', 'sr', 'jr', 'vs', 'etc', 'u.s', 'u.k'];
  const regex = new RegExp(`\\\\b(${abbreviations.join('|')})\\.\\s+([a-z])`, 'gi');
  
  result = result.replace(regex, (match, abbr, nextLetter) => {
    return abbr.toLowerCase() + '. ' + nextLetter.toLowerCase();
  });
  
  return result.trim();
}

/**
 * Find URLs in the text and return them without trailing punctuation.
 * Return all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs with various protocols and formats
  // Match protocol (http, https, ftp), optional www, domain name, optional port, path, query, fragment
  const urlRegex = /\b((https?:\/\/|ftp:\/\/|www\.)[^\s<>"']+)\b/gi;
  
  // Find all matches
  const matches = text.match(urlRegex);
  
  if (!matches) {
    return [];
  }
  
// Process each match to remove trailing punctuation
  return matches.map(match => {
    // Remove trailing punctuation marks that are typically not part of URLs
    return match.replace(/[.,;:!?)\]\}'']+$/g, '');
  });
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 * Replace http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but match only when it's a URL (not at the end of another word)
  // Use negative lookbehind to ensure we're not matching after @符号 to avoid changing things like "http://example.com" in an email
  return text.replace(/(?<!@)http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com so the final URL becomes https://docs.example.com/....
 * - Skip the host rewrite when the path contains dynamic hints such as cgi-bin, query strings (?, &, =), or legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py, but still upgrade the scheme to https://.
 * - Preserve nested paths (e.g., /docs/api/v1).
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs in the text
  const urlPattern = /(https?:\/\/)([^\/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to https
    const newProtocol = 'https://';
    let newHost = host;
    
    // Check if we should rewrite the docs host
    // First check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Then check if path doesn't contain any legacy indicators
      const legacyIndicators = [
        'cgi-bin', '?', '&', '=', 
        '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'
      ];
      
      const hasLegacyIndicator = legacyIndicators.some(indicator => path.includes(indicator));
      
      // If no legacy indicators, rewrite the host
      if (!hasLegacyIndicator) {
        newHost = `docs.${host}`;
      }
    }
    
    return newProtocol + newHost + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 * Return the four-digit year for mm/dd/yyyy. If the string doesn't match that format or month/day are invalid, return 'N/A'.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern where mm and dd are valid dates
  const dateRegex = /^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic date validation (excluding complex leap year calculations for brevity)
  // Check for invalid dates
  if (month === 2 && day > 29) {
    return 'N/A'; // February has at most 29 days
  }
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A'; // These months have only 30 days
  }
  if (day > 31) {
    return 'N/A'; // No month has more than 31 days
  }
  
  return year;
}