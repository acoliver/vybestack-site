/**
 * Find words starting with a given prefix, excluding specified exceptions.
 * Find words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to match words starting with the prefix
  // \b ensures we match whole words
  // [a-zA-Z]* matches the remaining part of the word
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions
  const filteredMatches = matches.filter(word => {
    const lowerWord = word.toLowerCase();
    const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
    return !lowerExceptions.includes(lowerWord);
  });
  
  // Remove duplicates and return
  return [...new Set(filteredMatches)];
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Return occurrences where the token appears after a digit and not at the start of the string (use lookaheads/lookbehinds).
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a positive lookbehind to match token that comes after a digit
  // Also include the digit in the match by using a capturing group
  const tokenRegex = new RegExp(`(\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches: string[] = [];
  let match;
  
  while ((match = tokenRegex.exec(text)) !== null) {
    // Ensure the token is not at the beginning of the string by checking match index
    if (match.index > 0) {
      matches.push(match[0]);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to security policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol, no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // This pattern matches repeated sequences in common patterns
  // 1. Any sequence of 2+ characters immediately repeated (abcabc, 123123)
  // 2. Any single character repeated 2+ times in a row (aa, 111)
  const repeatedPattern = /(.{2,})\1|(.)\2{1,}/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses and exclude IPv4 addresses.
 * Detect IPv6 addresses (including shorthand ::) and ensure IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex that excludes IPv4 patterns
  // Match standard IPv6 format (8 groups separated by colons)
  // Match shorthand with :: 
  // Match IPv6 with embedded IPv4
  
  // First create a negative lookbehind to ensure we're not matching IPv4
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it contains IPv4 pattern, don't treat as IPv6
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 patterns
  // Standard IPv6: 8 groups of 1-4 hex digits
  const standardIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Shorthand with :: (can be at beginning, middle, or end)
  const shorthandIPv6 = /\b(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}\b/;
  
  // IPv4-mapped IPv6: ::ffff:192.168.0.1
  // This includes IPv4 format but is considered IPv6
  const ipv4MappedIPv6 = /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // Check if any IPv6 pattern is found
  return standardIPv6.test(value) || shorthandIPv6.test(value) || ipv4MappedIPv6.test(value);
}