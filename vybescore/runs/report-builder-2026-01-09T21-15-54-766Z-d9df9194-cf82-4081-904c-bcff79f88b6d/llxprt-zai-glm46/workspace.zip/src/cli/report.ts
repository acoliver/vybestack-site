#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions } from '../types.js';
import { validateReportData } from '../utils.js';
import { formatters } from '../formats/index.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const formatArgIndex = args.indexOf('--format');

  if (formatArgIndex === -1 || formatArgIndex + 1 >= args.length) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  const format = args[formatArgIndex + 1];
  const outputArgIndex = args.indexOf('--output');
  const outputPath = outputArgIndex !== -1 && outputArgIndex + 1 < args.length ? args[outputArgIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');

  return { dataFile, format, outputPath, includeTotals };
}

function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
    let rawData: unknown;

    try {
      rawData = JSON.parse(fileContent);
    } catch (parseError) {
      console.error(`Error: Failed to parse JSON file "${args.dataFile}"`);
      if (parseError instanceof SyntaxError) {
        console.error(`Details: ${parseError.message}`);
      }
      process.exit(1);
    }

    const data: ReportData = validateReportData(rawData);

    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Error: Unsupported format "${args.format}"`);
      console.error('Supported formats: markdown, text');
      process.exit(1);
    }

    const options: RenderOptions = { includeTotals: args.includeTotals };
    const output = formatter(data, options);

    if (args.outputPath) {
      fs.writeFileSync(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
