import { Formatter } from '../types.js';
import { formatAmount, calculateTotal } from './markdown.js';

export const renderText: Formatter['render'] = (data, includeTotals) => {
  const lines: string[] = [];
  
  // Title
  lines.push(data.title);
  lines.push(''); // blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Entries section
  lines.push('Entries:');
  
  // Bullet list of entries
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  // Total if requested
  if (includeTotals) {
    lines.push('');
    lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
  }
  
  return lines.join('\n');
};