import { ReportData, Formatter } from '../types.js';

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderMarkdown: Formatter['render'] = (data, includeTotals) => {
  const lines: string[] = [];
  
  // Title
  lines.push(`# ${data.title}`);
  lines.push(''); // blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Entries section
  lines.push('## Entries');
  
  // Bullet list of entries
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }
  
  // Total if requested
  if (includeTotals) {
    lines.push('');
    lines.push(`**Total:** ${formatAmount(calculateTotal(data.entries))}`);
  }
  
  return lines.join('\n');
};