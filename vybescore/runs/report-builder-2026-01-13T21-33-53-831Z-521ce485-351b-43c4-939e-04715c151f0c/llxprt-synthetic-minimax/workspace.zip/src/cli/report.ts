#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): CLIOptions {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = args[0];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          throw new Error('--format requires a value');
        }
        format = args[i + 1] as 'markdown' | 'text';
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          throw new Error('--output requires a value');
        }
        outputPath = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (args[i].startsWith('--')) {
          throw new Error(`Unknown option: ${args[i]}`);
        }
        break;
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error(`Unsupported format: ${format}`);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function validateAndParseData(jsonPath: string): ReportData {
  try {
    const content = readFileSync(jsonPath, 'utf8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid or missing "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid or missing "summary" field');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing "entries" field');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid entry at index ${i}: missing "label"`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid entry at index ${i}: missing or invalid "amount"`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${jsonPath}`);
    }
    throw error;
  }
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const options = parseArgs(args);
    const data = validateAndParseData(options.dataFile);

    let output: string;
    switch (options.format) {
      case 'markdown':
        output = renderMarkdown(data, options.includeTotals);
        break;
      case 'text':
        output = renderText(data, options.includeTotals);
        break;
      default:
        throw new Error(`Unsupported format: ${options.format}`);
    }

    if (options.outputPath) {
      writeFileSync(options.outputPath, output, 'utf8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
