/**
 * Interface for a single report entry
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Interface for the complete report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for report rendering
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Interface for report formatters
 */
export interface ReportFormatter {
  render(data: ReportData, options: RenderOptions): string;
}