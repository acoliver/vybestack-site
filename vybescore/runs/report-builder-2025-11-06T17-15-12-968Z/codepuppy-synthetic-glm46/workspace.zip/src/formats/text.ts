import type { ReportData, ReportFormatter, RenderOptions } from '../types.js';

/**
 * Calculate total amount from entries
 */
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Format amount with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Text formatter implementation
 */
export const renderText: ReportFormatter = {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(data.title);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries heading
    lines.push('Entries:');
    
    // Entries list
    for (const entry of data.entries) {
      lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
    }
    
    // Optional total
    if (options.includeTotals) {
      lines.push(`Total: ${formatAmount(calculateTotal(data.entries))}`);
    }
    
    return lines.join('\n');
  }
};