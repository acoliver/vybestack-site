#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs/promises';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Parse command line arguments
 */
function parseArgs(): {
  inputFile: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  
  // Parse flags
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i++; // Skip next argument as it's the value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip next argument as it's the value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }
  
  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (expected string)`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (expected number)`);
    }
  }
}

/**
 * Map format name to formatter
 */
const formatters = {
  markdown: renderMarkdown,
  text: renderText
};

/**
 * Main CLI function
 */
async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const { inputFile, format, outputPath, includeTotals } = parseArgs();
    
    // Validate format
    if (!(format in formatters)) {
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
    }
    
    // Read and parse JSON file
    let jsonData: unknown;
    try {
      const fileContent = await readFile(inputFile, 'utf-8');
      jsonData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Invalid JSON in file ${inputFile}: ${error.message}`);
      } else if (error instanceof Error && 'code' in error) {
        console.error(`Error reading file ${inputFile}: ${error.message}`);
      } else {
        console.error(`Error reading file ${inputFile}: ${String(error)}`);
      }
      process.exit(1);
    }
    
    // Validate data structure
    validateReportData(jsonData);
    const reportData = jsonData as ReportData;
    
    // Render report
    const formatter = formatters[format as keyof typeof formatters];
    const options: RenderOptions = { includeTotals };
    const output = formatter.render(reportData, options);
    
    // Write output
    if (outputPath) {
      try {
        await writeFile(outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing to output file ${outputPath}: ${String(error)}`);
        process.exit(1);
      }
    } else {
      // Write to stdout
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${String(error)}`);
    process.exit(1);
  }
}

// Run the CLI
main().catch((error) => {
  console.error(`Unhandled error: ${String(error)}`);
  process.exit(1);
});