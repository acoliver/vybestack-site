declare module 'sql.js' {
  export interface Database {
    run(sql: string): void;
    exec(sql: string): Array<{ columns: string[]; values: unknown[][] }>;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): void;
    getAsObject(params?: unknown[]): unknown;
    step(): boolean;
    free(): void;
  }

  export interface SqlJsStatic {
    new (config?: { locateFile?: (file: string) => string }): Database;
  }

  const initSqlJs: (config?: { locateFile?: (file: string) => string }) => Promise<SqlJsStatic>;
  export default initSqlJs;
}