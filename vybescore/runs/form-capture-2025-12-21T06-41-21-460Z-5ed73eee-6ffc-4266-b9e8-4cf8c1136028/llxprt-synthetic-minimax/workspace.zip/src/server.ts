import express, { Request, Response } from 'express';
import * as path from 'path';
import DatabaseManager, { Submission } from './database';
import validateContactForm, { ContactFormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
const dbManager = new DatabaseManager();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: null,
    formData: null
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData: ContactFormData = {
      first_name: req.body.first_name || '',
      last_name: req.body.last_name || '',
      street_address: req.body.street_address || '',
      city: req.body.city || '',
      state_province_region: req.body.state_province_region || '',
      postal_code: req.body.postal_code || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    // Validate form data
    const validation = validateContactForm(formData);

    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        formData
      });
    }

    // Insert into database
    const submission: Submission = {
      first_name: formData.first_name,
      last_name: formData.last_name,
      street_address: formData.street_address,
      city: formData.city,
      state_province_region: formData.state_province_region,
      postal_code: formData.postal_code,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    };

    await dbManager.insertSubmission(submission);
    await dbManager.save();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      errors: { general: 'An error occurred while processing your submission. Please try again.' },
      formData: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown handling
process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully...');
  await dbManager.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer(): Promise<void> {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT} to see the form`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
