import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    const wasmPath = require('path').resolve(__dirname, '..', 'node_modules', 'sql.js', 'dist', 'sql-wasm.wasm');
    this.sqlJs = await initSqlJs({
      locateFile: () => wasmPath
    });

    let dbBuffer: Uint8Array | null = null;
    
    // Check if database file exists
    if (fs.existsSync(this.dbPath)) {
      const dbFileBuffer = fs.readFileSync(this.dbPath);
      dbBuffer = new Uint8Array(dbFileBuffer);
    }

    this.db = new (this.sqlJs as any).Database(dbBuffer);
    
    // Run schema initialization
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf-8');
    this.db!.exec(schema);
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (this.db === null) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province_region,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    
    // Get the last insert rowid
    const result = this.db!.exec("SELECT last_insert_rowid() as id");
    return result[0].values[0][0] as number;
  }

  async save(): Promise<void> {
    if (this.db === null) {
      throw new Error('Database not initialized');
    }

    const data = this.db!.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default DatabaseManager;
export type { Submission };