interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

interface ContactFormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province_region: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[0-9\s\-()]{7,20}$/;
  return phoneRegex.test(phone.replace(/\s/g, ''));
}

function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings, handle UK "SW1A 1AA" and other formats
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  return postalRegex.test(postalCode.trim());
}

function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

function validateContactForm(data: ContactFormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Validate required fields
  if (!validateRequired(data.first_name)) {
    errors.first_name = 'First name is required';
  }

  if (!validateRequired(data.last_name)) {
    errors.last_name = 'Last name is required';
  }

  if (!validateRequired(data.street_address)) {
    errors.street_address = 'Street address is required';
  }

  if (!validateRequired(data.city)) {
    errors.city = 'City is required';
  }

  if (!validateRequired(data.state_province_region)) {
    errors.state_province_region = 'State/Province/Region is required';
  }

  if (!validateRequired(data.postal_code)) {
    errors.postal_code = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Please enter a valid postal/Zip code';
  }

  if (!validateRequired(data.country)) {
    errors.country = 'Country is required';
  }

  if (!validateRequired(data.email)) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!validateRequired(data.phone)) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

export default validateContactForm;
export type { ValidationResult, ContactFormData };