#!/usr/bin/env node

import * as fs from 'node:fs';
import type { ReportData, RenderOptions, Formatter } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

/**
 * Map of format names to their formatter implementations
 */
const FORMATTERS: Record<string, Formatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

/**
 * Parse command line arguments
 */
function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    if (arg === '--format') {
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = nextArg;
      i++; // Skip next arg
    } else if (arg === '--output') {
      if (!nextArg) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = nextArg;
      i++; // Skip next arg
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

/**
 * Load and parse JSON data from file
 */
function loadData(filePath: string): ReportData {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;

    // Validate required fields
    if (typeof data !== 'object' || data === null) {
      throw new Error('Invalid JSON: expected an object');
    }

    const obj = data as Record<string, unknown>;

    if (typeof obj.title !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
    }

    if (typeof obj.summary !== 'string') {
      throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
    }

    if (!Array.isArray(obj.entries)) {
      throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
    }

    for (let i = 0; i < obj.entries.length; i++) {
      const entry = obj.entries[i];
      if (typeof entry !== 'object' || entry === null) {
        throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
      }

      const entryObj = entry as Record<string, unknown>;

      if (typeof entryObj.label !== 'string') {
        throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (must be a string)`);
      }

      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (must be a number)`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON file: ${error.message}`);
      process.exit(1);
    }
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    }
    console.error('Error: An unknown error occurred while loading data');
    process.exit(1);
  }
}

/**
 * Main CLI execution
 */
function main(): void {
  const args = process.argv.slice(2);
  const { dataPath, format, outputPath, includeTotals } = parseArgs(args);

  // Check if format is supported
  const formatter = FORMATTERS[format];
  if (!formatter) {
    console.error(`Error: Unsupported format: ${format}`);
    console.error(`Supported formats: ${Object.keys(FORMATTERS).join(', ')}`);
    process.exit(1);
  }

  // Load and validate data
  const data = loadData(dataPath);

  // Render report
  const options: RenderOptions = { includeTotals };
  const output = formatter.render(data, options);

  // Write output
  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to output file: ${outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
