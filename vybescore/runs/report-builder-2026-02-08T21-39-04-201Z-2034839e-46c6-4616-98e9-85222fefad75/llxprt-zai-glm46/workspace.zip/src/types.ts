/**
 * Report data structure matching the JSON schema
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Individual report entry with label and amount
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Options for rendering reports
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Formatter interface for consistent rendering across formats
 */
export interface Formatter {
  render(data: ReportData, options: RenderOptions): string;
}
