/**
 * Capitalize the first character of each sentence and normalize spacing.
 */
export function capitalizeSentences(text: string): string {
  // Ensure proper sentence spacing and prevent consecutive spaces
  const normalized = text
    // Replace multiple spaces with a single space
    .replace(/ {2,}/g, ' ')
    // Ensure there's a space after sentence-ending punctuation if followed by a character
    .replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Split into sentences and capitalize each one
  const sentences = normalized.split(/([.!?]\s*)/);
  
  // Capitalize the first letter of each sentence
  for (let i = 0; i < sentences.length; i += 2) {
    if (sentences[i].length > 0) {
      sentences[i] = sentences[i].charAt(0).toUpperCase() + sentences[i].slice(1);
    }
  }
  
  // Join back the sentences
  return sentences.join('');
}

/**
 * Find URLs in the text and return them without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches http(s)://www.domain.com, http(s)://domain.com
  const urlRegex = /(https?:\/\/[^\s]+)/g;
  const matches = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation that's not part of the URL
    url = url.replace(/[.,;:!?)[\]{}]+$/g, '');
    
    matches.push(url);
  }
  
  return matches;
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Pattern to match example.com URLs
  
  // Check if the path should be rewritten (no dynamic hints)
  const shouldRewrite = (url: string): boolean => {
    const match = url.match(/https:\/\/example\.com(\/.*)/);
    if (!match) return false;
    
    // Extract path after domain
    // const path = match[1]; // path variable is defined but not used for validation logic
    
    // Skip rewrite if path contains dynamic hints or legacy extensions
    const patternsToSkip = [
      /\/cgi-bin\//,
      /[?&=]/,
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)/
    ];
    
    // Check path components by extracting from URL
    const pathMatch = url.match(/https:\/\/example\.com(\/[^?\s]*)/);
    if (!pathMatch) return false;
    
    const path = pathMatch[1];
    
    // If path contains any of the above patterns, skip rewrite
    for (const pattern of patternsToSkip) {
      if (pattern.test(path)) {
        return false;
      }
    }
    
    // Only rewrite if path begins with /docs/
    return path.startsWith('/docs/');
  };
  
  // Process each URL that matches example.com
  result = result.replace(
    /https:\/\/example\.com(\/[^\s]*)/g,
    (match) => {
      if (shouldRewrite(match)) {
        return match.replace('https://example.com', 'https://docs.example.com');
      }
      return match;
    }
  );
  
  return result;
}

/**
 * Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Check for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  // Extract year part
  const year = match[3];
  return year;
}
