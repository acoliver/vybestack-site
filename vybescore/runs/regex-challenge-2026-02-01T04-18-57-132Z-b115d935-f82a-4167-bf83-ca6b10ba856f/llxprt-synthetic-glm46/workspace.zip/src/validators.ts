export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with common requirements.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  const basicCheck = emailRegex.test(value);
  if (!basicCheck) return false;

  // No double dots in local part or domain
  if (value.includes('..')) return false;

  // No trailing dots in local part
  if (value.match(/\.@/)) return false;

  // No domains with underscores
  if (value.includes('_') && value.split('@')[1].includes('_')) return false;

  return true;
}

/**
 * Validate US phone numbers with optional +1 country code.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Handle options if needed for future extensions
  if (options?.allowExtensions) {
    // Could handle extension logic here in the future
  }
  
  // Remove all non-digit characters
  const cleanNumber = value.replace(/\D/g, '');
  
  // Must have 10 digits (without country code) or 11 digits (with +1)
  if (cleanNumber.length !== 10 && cleanNumber.length !== 11) return false;
  
  // If 11 digits, must start with +1
  if (cleanNumber.length === 11 && !cleanNumber.startsWith('1')) return false;
  
  // Extract the 10-digit phone number
  const phoneNumber = cleanNumber.length === 11 ? cleanNumber.substring(1) : cleanNumber;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Check if the format matches common phone patterns
  const validFormat = /^(\+?1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})$/.test(value);
  
  return validFormat;
}

/**
 * Validate Argentine phone numbers including mobile and landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Argentina phone formats:
  // +54 9 11 1234 5678  (mobile with country code)
  // +54 341 123 4567   (landline with country code)
  // 011 1234 5678      (local format)
  // 0341 4234567       (local format without spaces)
  // Optional country code +54, optional trunk prefix 0, optional mobile indicator 9
  
  // Remove all non-digit, non-space, non-hyphen, non-plus characters
  const cleanValue = value.replace(/[^+\d\s-]/g, '');
  
  // Convert all spaces and hyphens to single spaces for validation
  const normalized = cleanValue.replace(/[-\s]+/g, ' ').trim();
  
  // Pattern for Argentine phone with country code (+54)
  // Allow for area codes of 2-4 digits (341 in the test case)
  // and subscriber numbers of 6-8 digits (123 4567 becomes 1234567 after removing spaces)
  const withCountryCodeRegex = /^\+54\s?9?\s?([1-9]\d{1,3})\s?(\d{3})\s?(\d{4})$/;
  if (withCountryCodeRegex.test(normalized)) {
    const parts = normalized.match(withCountryCodeRegex);
    if (parts) {
      const areaCode = parts[1];
      // const firstPart = parts[2]; // Not used in validation
      // const secondPart = parts[3]; // Not used in validation
      
      // Area code must be 2-4 digits
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      
      return true;
    }
  }
  
  // Pattern for local format with trunk prefix (0)
  const localFormatRegex = /^0([1-9]\d{1,3})\s?(\d{3})\s?(\d{4})$/;
  if (localFormatRegex.test(normalized)) {
    const parts = normalized.match(localFormatRegex);
    if (parts) {
      const areaCode = parts[1];
      // const firstPart = parts[2]; // Not used in validation
      // const secondPart = parts[3]; // Not used in validation
      
      // Area code must be 2-4 digits
      if (areaCode.length < 2 || areaCode.length > 4) return false;
      
      return true;
    }
  }
  
  return false;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 */
export function isValidName(value: string): boolean {
  // Check for basic name pattern (unicode letters with accents, apostrophes, hyphens, spaces)
  const nameRegex = /^[\p{L}\p{M}]+(['-]?[\p{L}\p{M}]+)*(\s(['-]?[\p{L}\p{M}]+)+)*$/u;
  if (!nameRegex.test(value)) return false;
  
  // Reject digits and most symbols
  if (/\d/.test(value)) return false;
  
  // Reject overly stylized names like "X Æ A-12" (non-name symbols and numbers)
  // This pattern allows letters from various languages, spaces, hyphens, and apostrophes
  // but rejects other symbols like "Æ" which is not typically used in names
  if (/[^\-\s'\p{L}\p{M}]/u.test(value)) return false;
  
  return true;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx) with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanValue = value.replace(/\D/g, '');
  
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: 16 digits, starts with 51-55, or 2221-2720
  const mastercardRegex = /^5[1-5]\d{14}$|^2(2[2-9]|[3-6]\d|7[01])\d{12}$/;
  
  // AmEx: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if the card number matches any valid format
  if (visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue)) {
    return runLuhnCheck(cleanValue);
  }
  
  return false;
}

/**
 * Helper function to run Luhn checksum validation.
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
