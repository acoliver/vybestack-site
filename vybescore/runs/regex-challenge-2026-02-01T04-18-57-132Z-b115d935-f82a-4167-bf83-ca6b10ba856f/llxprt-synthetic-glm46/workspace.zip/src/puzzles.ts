/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with the prefix
  const pattern = new RegExp(`\\b${prefix}[A-Za-z]*`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create pattern to match token preceded by a digit, but not at the start of the string
  // Since negative lookbehind isn't widely supported, we'll use a different approach
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = pattern.exec(text)) !== null) {
    const fullMatch = match[0];
    const matchIndex = match.index;
    
    // Check if this match is not at the beginning of the string
    if (matchIndex > 0) {
      matches.push(fullMatch);
    }
  }
  
  return matches;
}

/**
 * Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Password must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol character
  if (!/[!@#$%^&*()_+=[\]{};':"|,.<>/?]/.test(value)) return false;
  
  // Must not contain whitespace
  if (/\s/.test(value)) return false;
  
  // Must not contain immediate repeated sequences (e.g., "abab")
  // Check for any 2-character sequence that repeats immediately
  if (/(..)\1/.test(value)) return false;
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Pattern for IPv4 addresses - we want to exclude these
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it looks like an IPv4 address, return false
  if (ipv4Regex.test(value)) return false;
  
  // Pattern for full IPv6 addresses (8 groups of 1-4 hex digits separated by colons)
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // Pattern for shorthand with :: (compressed zeros)
  const ipv6Compressed = /::/;
  
  // Pattern for IPv6 with :: (any format with compressed zeros)
  const ipv6WithCompressed = /\b(?:[0-9a-fA-F]{1,4}:){0,5}(?::[0-9a-fA-F]{1,4}){0,5}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b/;
  
  // Pattern for IPv6 with :: at the end
  const ipv6WithCompressedEnd = /\b(?:[0-9a-fA-F]{1,4}:){0,7}::\b/;
  
  // Pattern for IPv6 with :: at the beginning
  const ipv6WithCompressedStart = /\b::(?:[0-9a-fA-F]{1,4}:){0,7}[0-9a-fA-F]{1,4}\b/;
  
  // General IPv6 pattern (covers all cases)
  const ipv6General = /\b([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}\b/;
  
  // Check if text contains any IPv6 pattern
  return ipv6Full.test(value) || 
         ipv6Compressed.test(value) && (ipv6WithCompressed.test(value) || ipv6WithCompressedEnd.test(value) || ipv6WithCompressedStart.test(value)) ||
         ipv6General.test(value);
}
