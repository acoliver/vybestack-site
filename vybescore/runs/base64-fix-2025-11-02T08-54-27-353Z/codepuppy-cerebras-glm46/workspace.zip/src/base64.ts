/**
 * Validates if a string contains only valid Base64 characters.
 * Allows standard Base64 alphabet with optional padding.
 */
function isValidBase64(input: string): boolean {
  // Check for invalid characters (anything other than A-Z, a-z, 0-9, +, /, =)
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return validBase64Regex.test(input);
}

/**
 * Validates Base64 padding according to RFC 4648.
 * - No padding, or 1-2 padding characters at the end
 * - Padding length must be consistent with the string length
 */
function hasValidPadding(input: string): boolean {
  if (!input.includes('=')) {
    return true; // No padding is valid
  }
  
  const paddingIndex = input.indexOf('=');
  const padding = input.slice(paddingIndex);
  
  // Padding can only be 1 or 2 characters
  if (padding.length > 2) {
    return false;
  }
  
  // All padding characters must be '='
  if (!/^=+$/.test(padding)) {
    return false;
  }
  
  // Total length must be a multiple of 4
  if (input.length % 4 !== 0) {
    return false;
  }
  
  return true;
}

/**
 * Encode plain text to Base64 using canonical RFC 4648 alphabet.
 * Includes required padding characters.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 alphabet with optional padding.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Basic validation of characters
  if (!isValidBase64(input)) {
    throw new Error('Input contains invalid Base64 characters');
  }
  
  // Validate padding
  if (!hasValidPadding(input)) {
    throw new Error('Input has invalid Base64 padding');
  }
  
  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}