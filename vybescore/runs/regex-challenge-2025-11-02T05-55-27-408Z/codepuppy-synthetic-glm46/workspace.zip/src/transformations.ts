/**
 * Capitalizes the first character of each sentence after .?!, inserts one space between sentences,
 * collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  // Split by sentence endings .?!
  const sentences = text.split(/([.?!])/);
  
  let result = '';
  let currentSentence = '';
  let lastWasEnd = false;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part.match(/[.?!]/)) {
      // It's a sentence ending
      currentSentence += part;
      
      // Capitalize the sentence and add to result
      const trimmedSentence = currentSentence.trim();
      if (trimmedSentence.length > 0) {
        if (result.length > 0 && !result.endsWith(' ')) {
          result += ' ';
        }
        result += trimmedSentence.charAt(0).toUpperCase() + trimmedSentence.slice(1);
      }
      
      currentSentence = '';
      lastWasEnd = true;
    } else {
      // Regular text part
      if (lastWasEnd && part.trim().length > 0) {
        // Start of new sentence
        currentSentence = part;
        lastWasEnd = false;
      } else if (!lastWasEnd) {
        // Continuation of current sentence
        currentSentence += part;
        lastWasEnd = false;
      } else {
        // Leading whitespace or empty
        if (result.length === 0) {
          result = part;
        } else {
          result += ' ' + part.trim();
        }
        lastWasEnd = false;
      }
    }
  }
  
  // Handle remaining part if any
  if (currentSentence.trim().length > 0) {
    const trimmedSentence = currentSentence.trim();
    if (result.length > 0 && !result.endsWith(' ')) {
      result += ' ';
    }
    result += trimmedSentence.charAt(0).toUpperCase() + trimmedSentence.slice(1);
  }
  
  // Collapse multiple spaces to single spaces
  result = result.replace(/\s+/g, ' ');
  
  return result.trim();
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern that matches:
  // - http://, https://, ftp:// protocols
  // - www. domains without protocol
  // - Domain names with subdomains
  // - Optional port numbers
  // - Paths, query strings, fragments
  // - Doesn't include trailing punctuation like .,!?)
  const urlPattern = /\b(?:https?:\/\/|ftp:\/\/|www\.)[^\s<>"'(){}[\]<>]+/gi;
  
  const matches = text.match(urlPattern);
  if (!matches) {
    return [];
  }
  
  // Clean each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation marks
    return url.replace(/[.,!?;:)'"\]\}]+$/g, '');
  }).filter(url => url.length > 0);
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but not https:// (to avoid double replacement)
  return text.replace(/http:\/\/([^\/])/, 'https://$1');
}

/**
 * Rewrites URLs:
 * - Always upgrades http:// to https://
 * - When path begins with /docs/, moves to docs.example.com
 * - Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match URLs from example.com
  const urlPattern = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(urlPattern, (match, protocol, domain, path) => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if path contains dynamic hints
    const dynamicIndicators = [
      'cgi-bin',
      '?',
      '&',
      '=',
      '.jsp',
      '.php',
      '.asp',
      '.aspx',
      '.do',
      '.cgi',
      '.pl',
      '.py'
    ];
    
    const hasDynamicContent = dynamicIndicators.some(indicator => path.includes(indicator));
    
    // If path starts with /docs/ and doesn't have dynamic content
    if (path.startsWith('/docs/') && !hasDynamicContent) {
      return secureProtocol + 'docs.' + domain + path;
    }
    
    // Otherwise, just upgrade the scheme
    return secureProtocol + domain + path;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate day against month (basic validation)
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Check if day is valid for the month
  const maxDays = daysInMonth[month - 1];
  if (day > maxDays || day < 1) {
    return 'N/A';
  }
  
  // Check reasonable year range (1900-2100)
  if (year < 1900 || year > 2100) {
    return 'N/A';
  }
  
  return yearStr;
}
