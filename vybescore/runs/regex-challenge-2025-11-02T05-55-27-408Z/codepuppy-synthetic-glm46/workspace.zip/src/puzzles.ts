/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Simple approach for escaping the most common regex special characters
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match word boundaries and words starting with prefix
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern);
  if (!matches) {
    return [];
  }
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const lowerExceptions = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions and remove duplicates
  const uniqueWords = [...new Set(
    matches
      .filter(word => !lowerExceptions.includes(word.toLowerCase()))
      .map(word => word)
  )];
  
  return uniqueWords;
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Simple approach for escaping the most common regex special characters
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit + token, but ensure it's not at the start of the string
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern);
  return matches || [];
}

/**
 * Validates password strength:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Length must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must have at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must have at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must have at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must have at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (like abab, ababa, etc.)
  const repeatedSequencePattern = /(.{2,})\1+/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  // Check for repeated patterns with small variations
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const pattern1 = value.substr(i, len);
      const pattern2 = value.substr(i + len, len);
      if (pattern1 === pattern2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger positive result.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex patterns
  const ipv6Patterns = [
    // Full IPv6 format
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Shorthand with ::
    /\b(?:[0-9a-fA-F]{1,4}:){0,7}:\b/,
    /\b:(?::[0-9a-fA-F]{1,4}){1,7}\b/,
    // IPv6 with embedded IPv4
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?:\d{1,3}\.){3}\d{1,3}\b/,
  ];
  
  // First, check if it's pure IPv4 (which should not match)
  const ipv4Pattern = /^\b(?:\d{1,3}\.){3}\d{1,3}\b$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Check for IPv6 patterns
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}