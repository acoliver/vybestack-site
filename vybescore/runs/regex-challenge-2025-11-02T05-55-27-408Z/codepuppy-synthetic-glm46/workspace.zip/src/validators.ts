export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses supporting international domains and local tags.
 * Rejects double dots, trailing dots, underscores in domain names.
 */
export function isValidEmail(value: string): boolean {
  // Email regex pattern supporting:
  // - Local part: letters, digits, dots, hyphens, plus, apostrophes
  // - Domain: letters, digits, hyphens, subdomains, TLDs 2-63 chars
  // - No double dots, no trailing dots, no underscores in domain
  const emailPattern = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*\.[a-zA-Z]{2,63}$/;
  
  if (!emailPattern.test(value)) {
    return false;
  }
  
  // Additional checks:
  // - No consecutive dots in local part
  // - No starting/ending dot in local part
  const [localPart, domain] = value.split('@');
  
  if (localPart.includes('..') || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain shouldn't contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting (212) 555-7890, 212-555-7890, 2125557890, optional +1.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length === 11) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Should be exactly 10 digits for US numbers
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code can't start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Common US phone format patterns
  const patterns = [
    /^\+?1?\s*\(\d{3}\)\s*\d{3}[-.\s]?\d{4}$/, // (212) 555-7890, +1 (212) 555-7890
    /^\+?1?\s*\d{3}[-.\s]?\d{3}[-.\s]?\d{4}$/, // 212-555-7890, 212.555.7890, 212 555 7890
    /^\+?1?\s*\d{10}$/, // 2125557890, +12125557890
  ];
  
  return patterns.some(pattern => pattern.test(value.trim()));
}

/**
 * Validates Argentine phone numbers supporting landlines and mobiles.
 * Examples: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix (when no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, first digit 1-9
  // Subscriber number: 6-8 digits
  const pattern = /^(?:\+54|0)?(?:9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(pattern);
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // When country code is omitted, must start with trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  if (!hasCountryCode && !cleaned.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and "X Æ A-12" style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letter pattern including:
  // - Basic latin letters (A-Z, a-z)
  // - International letters (accented, diacritics)
  // - Apostrophes, hyphens, spaces
  // - Reject digits, special symbols like Æ unless part of proper names
  const namePattern = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!namePattern.test(value.trim())) {
    return false;
  }
  
  // Additional checks
  const trimmed = value.trim();
  
  // Should not be empty or just spaces/hyphens/apostrophes
  if (trimmed.length === 0 || /^[\s'\-]+$/.test(trimmed)) {
    return false;
  }
  
  // Reject names with consecutive non-letter characters (like X Æ A-12)
  // This is a heuristic to catch clearly invalid names
  const hasConsecutiveSpecials = /[\s'\-]{2,}/.test(trimmed);
  if (hasConsecutiveSpecials) {
    return false;
  }
  
  // Should contain at least one letter
  if (!/[\p{L}\p{M}]/u.test(trimmed)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) checking prefixes, lengths, and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Basic length and prefix patterns for major cards
  const cardPatterns = [
    // Visa: starts with 4, 13 or 16 digits
    { pattern: /^4(\d{12}|\d{15})$/, type: 'visa' },
    // Mastercard: starts with 51-55 or 2221-2720, 16 digits
    { pattern: /^(5[1-5]\d{14}|2[2-7]\d{14}|222[1-9]\d{12}|22[3-9]\d{13}|2[3-6]\d{14}|27[01]\d{13}|2720\d{12})$/, type: 'mastercard' },
    // American Express: starts with 34 or 37, 15 digits
    { pattern: /^3[47]\d{13}$/, type: 'amex' },
  ];
  
  // Check if it matches any card pattern
  const isValidPattern = cardPatterns.some(card => card.pattern.test(cleaned));
  if (!isValidPattern) {
    return false;
  }
  
  // Luhn checksum validation
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Start from the rightmost digit and work backwards
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
