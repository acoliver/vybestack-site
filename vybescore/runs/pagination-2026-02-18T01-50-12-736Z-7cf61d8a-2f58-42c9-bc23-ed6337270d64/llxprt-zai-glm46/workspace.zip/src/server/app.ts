import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const pageNum = pageParam !== undefined ? Number(pageParam) : undefined;
    const limitNum = limitParam !== undefined ? Number(limitParam) : undefined;

    if (pageParam !== undefined && (pageNum === undefined || isNaN(pageNum) || !Number.isInteger(pageNum) || pageNum < 1)) {
      return res.status(400).json({ error: 'Invalid page parameter: must be a positive integer' });
    }

    if (limitParam !== undefined && (limitNum === undefined || isNaN(limitNum) || !Number.isInteger(limitNum) || limitNum < 1)) {
      return res.status(400).json({ error: 'Invalid limit parameter: must be a positive integer' });
    }

    const payload = listInventory(db, { page: pageNum, limit: limitNum });
    res.json(payload);
  });

  return app;
}
