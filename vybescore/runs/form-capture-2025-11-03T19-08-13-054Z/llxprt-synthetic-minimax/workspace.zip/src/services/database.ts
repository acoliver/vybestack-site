import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import fs from 'fs/promises';
import path from 'path';

interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export class DatabaseService {
  private db: Database | null = null;
  private sqlJs: SqlJsStatic | null = null;
  private dbPath: string;

  constructor(dbPath: string) {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    this.sqlJs = await initSqlJs({
      locateFile: (file) => {
        if (file === 'sql-wasm.wasm') {
          return require('sql.js/dist/sql-wasm.wasm');
        }
        return file;
      }
    });

    try {
      const dbExists = await this.checkIfDbExists();
      
      if (dbExists) {
        const dbBuffer = await fs.readFile(this.dbPath);
        this.db = new this.sqlJs.Database(dbBuffer);
      } else {
        this.db = new this.sqlJs.Database();
        await this.createSchema();
        await this.saveDatabase();
      }
    } catch (error) {
      console.error('Error initializing database:', error);
      throw error;
    }
  }

  private async checkIfDbExists(): Promise<boolean> {
    try {
      await fs.access(this.dbPath);
      return true;
    } catch {
      return false;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const schemaPath = path.join(__dirname, '../../db/schema.sql');
    const schema = await fs.readFile(schemaPath, 'utf-8');
    
    this.db.exec(schema);
  }

  async insertSubmission(data: SubmissionData): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);

    stmt.free();
    await this.saveDatabase();
  }

  private async saveDatabase(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbDir = path.dirname(this.dbPath);
    await fs.mkdir(dbDir, { recursive: true });

    const data = this.db.export();
    const buffer = Buffer.from(data);
    await fs.writeFile(this.dbPath, buffer);
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}