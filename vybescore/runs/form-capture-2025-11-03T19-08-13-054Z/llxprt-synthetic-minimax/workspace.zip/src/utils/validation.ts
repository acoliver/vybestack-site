interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateFormData(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};

  // Required field validation
  if (!data.firstName) {
    errors.firstName = 'First name is required';
  }

  if (!data.lastName) {
    errors.lastName = 'Last name is required';
  }

  if (!data.streetAddress) {
    errors.streetAddress = 'Street address is required';
  }

  if (!data.city) {
    errors.city = 'City is required';
  }

  if (!data.stateProvince) {
    errors.stateProvince = 'State/Province/Region is required';
  }

  if (!data.postalCode) {
    errors.postalCode = 'Postal code is required';
  }

  if (!data.country) {
    errors.country = 'Country is required';
  }

  if (!data.email) {
    errors.email = 'Email is required';
  } else if (!isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  if (!data.phone) {
    errors.phone = 'Phone number is required';
  } else if (!isValidPhone(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

function isValidEmail(email: string): boolean {
  // Simple email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  // Phone validation: digits, spaces, parentheses, dashes, and leading +
  // Must have at least some digits
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  const hasDigits = /\d/.test(phone);
  return phoneRegex.test(phone) && hasDigits;
}

function isValidPostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings (UK "SW1A 1AA", Argentine "C1000" or "B1675")
  // Letters, numbers, spaces, hyphens allowed
  const postalRegex = /^[A-Za-z0-9\s\-]+$/;
  return postalRegex.test(postalCode);
}