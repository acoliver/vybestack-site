import express, { Request, Response, NextFunction } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { DatabaseService } from './services/database.js';
import { validateFormData } from './utils/validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '../public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database service
const dbService = new DatabaseService(path.join(__dirname, '../data/submissions.sqlite'));

// Form data interface
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  errors?: Record<string, string>;
}

// GET / - Render form
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    data: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: ''
    },
    errors: {}
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: FormData = {
      firstName: req.body.firstName?.trim() || '',
      lastName: req.body.lastName?.trim() || '',
      streetAddress: req.body.streetAddress?.trim() || '',
      city: req.body.city?.trim() || '',
      stateProvince: req.body.stateProvince?.trim() || '',
      postalCode: req.body.postalCode?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phone: req.body.phone?.trim() || ''
    };

    const validation = validateFormData(formData);

    if (!validation.isValid) {
      return res.status(200).render('form', {
        data: formData,
        errors: validation.errors
      });
    }

    await dbService.insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    });

    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response, next: NextFunction) => {
  console.error('Error:', err);
  res.status(500).send('An error occurred');
});

// Graceful shutdown
const server = app.listen(PORT, async () => {
  await dbService.initialize();
  console.log(`Server running on port ${PORT}`);
});

process.on('SIGTERM', async () => {
  console.log('SIGTERM received, shutting down gracefully');
  await dbService.close();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

process.on('SIGINT', async () => {
  console.log('SIGINT received, shutting down gracefully');
  await dbService.close();
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
});

export default app;