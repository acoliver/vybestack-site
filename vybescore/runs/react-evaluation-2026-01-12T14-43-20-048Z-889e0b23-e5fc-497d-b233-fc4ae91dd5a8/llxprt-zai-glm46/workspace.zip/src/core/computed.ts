/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    subjects: new Set(),
  }
  updateObserver(o)
  
  return (): T => {
    const active = getActiveObserver()
    if (active && active !== o) {
      // If we're being called from another observer, register as a dependency
      for (const subject of o.subjects || []) {
        subject.observers.add(active)
        if (!active.subjects) {
          active.subjects = new Set()
        }
        active.subjects.add(subject)
      }
    }
    return o.value!
  }
}
