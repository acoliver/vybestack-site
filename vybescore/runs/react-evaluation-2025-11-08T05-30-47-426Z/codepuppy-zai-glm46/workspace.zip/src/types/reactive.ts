/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<Subject<unknown>> // Track dependencies
}

export type Observer<T> = ObserverR & ObserverV<T>

export type BaseObserver = Observer<unknown>

export type SubjectR = {
  name?: string
  observers: Set<BaseObserver>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: BaseObserver | undefined

export function getActiveObserver(): BaseObserver | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as BaseObserver
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addObserver<T>(subject: Subject<T>, observer: BaseObserver): void {
  subject.observers.add(observer)
  
  // Track this subject as a dependency
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject as Subject<unknown>)
}

export function removeObserver<T>(subject: Subject<T>, observer: BaseObserver): void {
  subject.observers.delete(observer)
  
  // Remove from dependencies
  if (observer.dependencies) {
    observer.dependencies.delete(subject as Subject<unknown>)
  }
}

export function trackDependency<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer) {
    addObserver(subject, observer)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Create a copy to avoid issues with modification during iteration
  const observersArray = Array.from(subject.observers)
  observersArray.forEach(observer => {
    try {
      updateObserver(observer as Observer<unknown>)
    } catch (error) {
      // Continue with others even if one fails
      console.error('Observer update failed:', error)
    }
  })
}

export function cleanupObserver(observer: BaseObserver): void {
  // Remove observer from all its dependencies
  if (observer.dependencies) {
    observer.dependencies.forEach(subject => {
      subject.observers.delete(observer)
    })
    observer.dependencies.clear()
  }
}

export function createSubjectContainer<T>(): {
  subject: Subject<T>
  addToObservers: (observer: BaseObserver) => void
  notifyObservers: () => void
} {
  const subject: Subject<T> = {
    observers: new Set(),
    value: undefined as T,
  }
  
  return {
    subject,
    addToObservers: (observer: BaseObserver) => subject.observers.add(observer),
    notifyObservers: () => {
      const observersArray = Array.from(subject.observers)
      observersArray.forEach(observer => {
        try {
          updateObserver(observer as Observer<unknown>)
        } catch (error) {
          console.error('Observer update failed:', error)
        }
      })
    }
  }
}
