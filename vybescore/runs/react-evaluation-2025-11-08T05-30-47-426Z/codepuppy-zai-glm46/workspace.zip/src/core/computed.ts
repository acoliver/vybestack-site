/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  updateObserver,
  EqualFn,
  trackDependency,
  createSubjectContainer
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Handle equality function
  let equalFn: EqualFn<T>
  if (equal === undefined) {
    equalFn = (a: T, b: T) => a === b
  } else if (typeof equal === 'boolean') {
    equalFn = equal ? (a: T, b: T) => a === b : () => false
  } else {
    equalFn = equal
  }

  let computedValue: T | undefined = value
  
  const subjectContainer = createSubjectContainer<T>()
  subjectContainer.subject.value = computedValue!
  subjectContainer.subject.equalFn = equalFn
  subjectContainer.subject.name = options?.name
  
  const observer: Observer<T> = {
    name: options?.name,
    value: computedValue,
    updateFn: (currentValue?: T) => {
      const newValue = updateFn(currentValue)
      if (computedValue === undefined || !equalFn(computedValue, newValue)) {
        computedValue = newValue
        observer.value = computedValue
        subjectContainer.subject.value = computedValue
        
        // Notify observers of this computed value when it changes
        subjectContainer.notifyObservers()
      }
      return computedValue as T
    },
  }

  const read: GetterFn<T> = () => {
    // Track this computed value as a dependency
    trackDependency(subjectContainer.subject)
    
    // Compute the value if needed
    if (computedValue === undefined) {
      updateObserver(observer)
    }
    
    return computedValue as T
  }

  // Initialize the computed value
  if (computedValue === undefined) {
    updateObserver(observer)
  }

  return read
}