/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, BaseObserver, UpdateFn, updateObserver, cleanupObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (currentValue?: T): T => {
      if (disposed) return currentValue || value!
      
      // Execute the callback side effect
      const result = updateFn(currentValue)
      observer.value = result
      return result
    },
  }
  
  // Initial execution to establish dependencies
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clean up all dependencies
    cleanupObserver(observer as BaseObserver)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}