/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Convert boolean equal flag to proper equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    // Default strict equality
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (equal === false) {
    // No equality check - always trigger updates
    equalFn = undefined
  } else if (typeof equal === 'function') {
    // Custom equality function
    equalFn = equal
  }
  
  // Track all observers for this input
  const observers = new Set<Observer<unknown>>()
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer with the subject
      // Only add if it's a full Observer with updateFn
      if ('updateFn' in observer) {
        observers.add(observer as Observer<unknown>)
      }
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check equality if we have an equality function
    if (equalFn && equalFn(value, nextValue)) {
      return value // No change needed
    }
    
    value = nextValue
    
    // Notify all observers when value changes
    observers.forEach(observer => {
      // Observer must have updateFn, cast to full Observer interface
      if ('updateFn' in observer) {
        updateObserver(observer as Observer<unknown>)
      }
    })
    
    return value
  }

  return [read, write]
}