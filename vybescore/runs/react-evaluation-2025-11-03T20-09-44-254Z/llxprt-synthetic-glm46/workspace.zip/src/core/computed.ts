/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Convert boolean equal flag to proper equality function
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }
  
  let currentValue: T
  let dirty = true
  let computing = false
  
  // Track dependencies for this computed value
  const dependencies = new Set<Observer<unknown>>()
  
  // Create observer object for this computation
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn: (_prev) => {
      dirty = true
      return compute()
    }
  }
  
  const compute = (): T => {
    if (computing) {
      // Prevent infinite recursion
      return currentValue
    }
    
    if (!dirty) {
      return currentValue
    }
    
    computing = true
    
    try {
      // Clear previous dependencies
      dependencies.clear()
      
      // Set this computed as active observer to track dependencies
      const previous = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        // Compute new value
        const oldValue = currentValue
        currentValue = updateFn(oldValue)
        
        // Check equality if we have an equality function
        if (equalFn && oldValue !== undefined && equalFn(oldValue, currentValue)) {
          // No change needed
        } else {
          // Value has changed
        }
        
        dirty = false
      } finally {
        // Restore previous active observer
        setActiveObserver(previous)
      }
    } finally {
      computing = false
    }
    
    return currentValue
  }
  
  // Initial computation - if we have an initial value, use it
  if (value !== undefined) {
    currentValue = value
    dirty = false
  }
  
  return (): T => {
    // When this computed value is accessed, register as a dependency
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      dependencies.add(activeObserver as Observer<unknown>)
    }
    
    // Compute and return the value
    return compute()
  }
}