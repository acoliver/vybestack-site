import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState<number>(1);
  const PAGE_LIMIT = 5;

  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const pageLimit = PAGE_LIMIT; // Used for useInventory but not directly in UI

  const goToPreviousPage = (): void => {
    setCurrentPage((prev) => Math.max(1, prev - 1));
  };

  const goToNextPage = (): void => {
    setCurrentPage((prev) => (data?.hasNext ? prev + 1 : prev));
  };

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const hasPreviousPage = currentPage > 1;
  const hasNextPage = data.hasNext;

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      {data.items.length === 0 ? (
        <p>No inventory items available.</p>
      ) : (
        <nav aria-label="Pagination" style={{ marginTop: '1rem' }}>
          <button
            onClick={goToPreviousPage}
            disabled={!hasPreviousPage}
            aria-label="Previous page"
          >
            Previous
          </button>
          <span style={{ margin: '0 1rem' }}>
            Page {currentPage} of {hasNextPage ? 'many' : currentPage}
          </span>
          <button
            onClick={goToNextPage}
            disabled={!hasNextPage}
            aria-label="Next page"
          >
            Next
          </button>
        </nav>
      )}
    </section>
  );
}
