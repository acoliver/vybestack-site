export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive regex rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation with additional restrictions
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for edge cases
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots in local part or domain
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local part or domain
  if (value.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  // Reject domains starting/ending with hyphen
  if (domain && (domain.startsWith('-') || domain.endsWith('-'))) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats and separators.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Handle optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // Must have exactly 10 digits for standard US phone numbers
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate format using regex
  const usPhoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[-.\s]?)?\d{3}[-.\s]?\d{4}$/;
  
  return usPhoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits after area code
 * - When country code omitted, must start with trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all whitespace and hyphens for validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with all possible components
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(\d{1})(\d{1,3})(\d{6,8})$/;
  const withMobileIndicator = /^(?:\+54)?0?9(\d{1})(\d{1,3})(\d{6,8})$/;
  
  // Try matching patterns
  const match = cleanNumber.match(withMobileIndicator) || cleanNumber.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  let areaCode: string;
  let subscriberNumber: string;
  
  if (cleanNumber.includes('9') && cleanNumber.length > 10) {
    // Mobile format with 9 indicator
    const mobileMatch = cleanNumber.match(withMobileIndicator);
    if (mobileMatch) {
      areaCode = mobileMatch[1] + mobileMatch[2];
      subscriberNumber = mobileMatch[3];
    } else {
      return false;
    }
  } else {
    // Standard format
    const standardMatch = cleanNumber.match(argentinePhoneRegex);
    if (standardMatch) {
      areaCode = standardMatch[1] + standardMatch[2];
      subscriberNumber = standardMatch[3];
    } else {
      return false;
    }
  }
  
  // Validate area code: 2-4 digits, leading digit 1-9
  if (!/^[2-4]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number: 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  // If country code is omitted, must start with trunk prefix 0
  if (!cleanNumber.startsWith('+54') && !cleanNumber.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Trim whitespace from both ends
  const trimmedName = value.trim();
  
  // Name must not be empty
  if (trimmedName.length === 0) {
    return false;
  }
  
  // Name validation regex:
  // - \p{L} matches any unicode letter
  // - \p{M} matches combining marks (accents, diacritics)
  // - Allow apostrophes, hyphens, and spaces
  // - Require at least one letter
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(trimmedName)) {
    return false;
  }
  
  // Ensure there's at least one letter (reject names with only symbols/spaces)
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmedName);
  if (!hasLetter) {
    return false;
  }
  
  // Reject names with digits (ex: "X Æ A-12" contains digits)
  if (/\d/.test(trimmedName)) {
    return false;
  }
  
  // Reject names with excessive consecutive symbols (more than 2)
  if (/(?:[' -]){3,}/.test(trimmedName)) {
    return false;
  }
  
  // Reject names that are just symbols or have unusual symbol-to-letter ratio
  const letterCount = (trimmedName.match(/[\p{L}\p{M}]/gu) || []).length;
  const symbolCount = (trimmedName.match(/[' -]/g) || []).length;
  
  if (letterCount === 0 || (letterCount < 2 && symbolCount > 2)) {
    return false;
  }
  
  return true;
}

/**
 * Validate credit card numbers for Visa/Mastercard/AmEx with Luhn checksum verification.
 * Accepts correct prefixes and lengths for major card types.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if we have a reasonable number of digits (13-19 digits for most cards)
  if (digitsOnly.length < 13 || digitsOnly.length > 19) {
    return false;
  }
  
  // Validate card patterns for major brands
  const cardPatterns = [
    // Visa: starts with 4, length 13 or 16
    { regex: /^4(\d{12}|\d{15})$/, type: 'visa' },
    // Mastercard: starts with 2221-2720 or 51-55, length 16
    { regex: /^(5[1-5]\d{14}|2[2-7]\d{13})$/, type: 'mastercard' },
    // American Express: starts with 34 or 37, length 15
    { regex: /^3[47]\d{13}$/, type: 'amex' },
    // Discover: starts with 6011, 65, 644-649, length 16
    { regex: /^(6011\d{12}|65\d{14}|6[4-9]\d{13})$/, type: 'discover' },
    // Diners Club: starts with 36, 38-39, length 14
    { regex: /^3(?:0[0-5]|[68]\d)\d{11}$/, type: 'diners' },
    // JCB: starts with 3528-3589, length 16
    { regex: /^35(2[89]|[3-8]\d)\d{12}$/, type: 'jcb' }
  ];
  
  // Check if the number matches any known card pattern
  const validPattern = cardPatterns.some(pattern => pattern.regex.test(digitsOnly));
  if (!validPattern) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digitsOnly);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
