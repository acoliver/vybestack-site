/**
 * Capitalize the first character of each sentence while preserving spacing rules.
 * Capitalizes after .!? punctuation, inserts exactly one space between sentences,
 * collapses extra spaces, and preserves abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) {
    return text;
  }
  
  // First, normalize spacing around sentence endings
  const result = text
    // Ensure single space after sentence-ending punctuation
    .replace(/([.!?])(?=\S)/g, '$1 ')
    // Remove extra spaces between words
    .replace(/\s+/g, ' ')
    // Remove space before punctuation
    .replace(/\s+([.!?])/g, '$1')
    .trim();
  
  // Common abbreviations to avoid capitalizing after
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'St', 'Ave', 'Blvd', 'Rd', 'etc', 'e.g', 'i.e', 'vs', 'U.S', 'U.K', 'U.N', 'N.A', 'S.A', 'p.m', 'a.m'];
  
  // Split into sentences using punctuation that marks sentence boundaries
  const sentences = result.split(/([.!?]\s)/);
  
  let capitalizeNext = true;
  const capitalizedSentences = sentences.map((sentence, index) => {
    if (!sentence.trim()) return sentence;
    
    // Check if this is a sentence-ending punctuation followed by space
    if (/[.!?]\s/.test(sentence)) {
      capitalizeNext = true;
      return sentence;
    }
    
    // Don't capitalize if the previous sentence ended with an abbreviation
    if (index > 0 && abbreviations.some(abbr => sentences[index - 1].includes(abbr + '.'))) {
      capitalizeNext = false;
    }
    
    if (capitalizeNext) {
      capitalizeNext = false;
      // Capitalize first letter if it exists
      return sentence.charAt(0).toUpperCase() + sentence.slice(1).toLowerCase();
    }
    
    return sentence;
  });
  
  return capitalizedSentences.join('');
}

/**
 * Extract URLs from text, returning all detected URLs without trailing punctuation.
 * Handles both full URLs and domain-only URLs.
 */
export function extractUrls(text: string): string[] {
  // URL pattern to match:
  // - URLs starting with http:// or https://
  // - URLs starting with www.
  // - Domain-only URLs
  // - Include paths, query strings, fragments
  // - IP addresses
  // - Port numbers
  // - Paths, query strings, fragments
  // - Common file extensions
  const urlRegex = /\b((?:https?:\/\/|www\.)[^\s<">]+|(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?:[^\s<">]*)?)\b/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up matches by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters that are unlikely to be part of the URL
    return url.replace(/[.,;:!?'"()[\]{}]+$/g, '');
  });
}

/**
 * Replace all http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite documentation URLs according to specific rules.
 * For URLs http://example.com/...:
 * - Always upgrade the scheme to https://.
 * - When the path begins with /docs/, rewrite the host to docs.example.com.
 * - Skip host rewrite for dynamic hints or legacy extensions, but still upgrade the scheme.
 */
export function rewriteDocsUrls(text: string): string {
  // URL pattern to match http://example.com/... URLs
  const urlPattern = /(https?:\/\/)([^\/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlPattern, (match, protocol, host, path) => {
    // Always upgrade to HTTPS
    const secureProtocol = 'https://';
    
    if (!path) {
      return secureProtocol + host;
    }
    
    // Check if we should skip host rewrite
    const skipHostRewrite = 
      path.includes('cgi-bin') ||
      path.includes('?') ||
      path.includes('&') ||
      path.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$/i.test(path);
    
if (path.startsWith('/docs/') && !skipHostRewrite) {
      // Rewrite to docs.example.com for docs paths
      return secureProtocol + 'docs.example.com' + path;
    }
    
    // Just upgrade the protocol for other cases
    return secureProtocol + host + path;
  });
}

/**
 * Extract year from mm/dd/yyyy format, returning "N/A" for invalid formats or dates.
 */
export function extractYear(value: string): string {
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(datePattern);
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Check for valid dates considering month lengths
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Handle leap years for February
  const yearNum = parseInt(year, 10);
  const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
  if (isLeapYear) {
    daysInMonth[1] = 29;
  }
  
  if (dayNum > daysInMonth[monthNum - 1]) {
    return 'N/A';
  }
  
  return year;
}