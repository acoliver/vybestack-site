/**
 * Match words starting with the prefix but excluding banned words.
 * Returns an array of matched words that start with the given prefix but are not in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex to find words starting with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  return matches
    .filter(word => !exceptionSet.has(word.toLowerCase()))
    .sort((a, b) => a.localeCompare(b));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads and lookbehinds to find the token in the correct context.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex using lookbehind to find token preceded by a digit
  // and negative lookbehind to ensure it's not at the start of string
  const tokenRegex = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches and extract the full match (including the digit)
  const matches = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return [...new Set(matches)]; // Return unique matches
}

/**
 * Validate passwords according to the security policy.
 * Requirements: at least 10 characters, one uppercase, one lowercase, one digit, one symbol, 
 * no whitespace, no immediate repeated sequences (e.g., abab should fail).
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Only check for patterns that repeat exactly twice
  for (let i = 0; i < value.length - 4; i++) {
    const pattern1 = value.substring(i, i + 2);
    const pattern2 = value.substring(i + 2, i + 4);
    if (pattern1 === pattern2) {
      return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 * Returns true if the text contains a valid IPv6 address, false otherwise.
 */
export function containsIPv6(value: string): boolean {
  // IPv4 regex pattern - we'll use this to exclude IPv4 addresses
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // IPv6 pattern - simplified to avoid syntax issues
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|\b(?:[0-9a-fA-F]{1,4}:){1,7}:|\b[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|\b:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|\b::(?:ffff:)?(?:(?:\d{1,3}\.){3}\d{1,3})\b/g;
  
  // First check if there's an IPv6 match
  const ipv6Matches = value.match(ipv6Regex);
  if (!ipv6Matches) {
    return false;
  }
  
  // For each IPv6 match, ensure it's not an IPv4 address
  for (const match of ipv6Matches) {
    // If the match is a pure IPv4 address, skip it
    if (ipv4Regex.test(match)) {
      continue;
    }
    
    // This is a genuine IPv6 address
    return true;
  }
  
  return false;
}