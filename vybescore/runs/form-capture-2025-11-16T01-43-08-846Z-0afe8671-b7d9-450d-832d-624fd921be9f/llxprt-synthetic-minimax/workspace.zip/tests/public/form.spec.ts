import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load as loadCheerio } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { createApp } from '../../src/server.js';
import DatabaseManager from '../../src/database.js';
import type { Server } from 'http';

let server: Server;
let testDbManager: DatabaseManager;
const dbPath = path.resolve('data', 'submissions_test.sqlite');

beforeAll(async () => {
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Create test database manager
  testDbManager = new DatabaseManager(dbPath);
  await testDbManager.initialize();
  
  // Create app with test database
  const { app } = createApp(testDbManager);
  server = app.listen(0); // Use port 0 to let the system choose an available port
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
  
  if (testDbManager) {
    testDbManager.close();
  }
  
  // Clean up test database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server)
      .get('/')
      .expect(200);
    
    expect(response.text).toBeDefined();
    const $ = loadCheerio(response.text);
    
    // Check for all form fields
    expect($('#first_name').length).toBe(1);
    expect($('#last_name').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
    expect($('#street_address').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#state_province').length).toBe(1);
    expect($('#postal_code').length).toBe(1);
    expect($('#country').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const formData = {
      first_name: 'John',
      last_name: 'Doe',
      email: 'john.doe@example.com',
      phone: '+1 (555) 123-4567',
      street_address: '123 Main St',
      city: 'Anytown',
      state_province: 'CA',
      postal_code: '12345',
      country: 'United States'
    };
    
    const response = await request(server)
      .post('/submit')
      .send(formData)
      .expect(302);
    
    expect(response.headers.location).toBe('/thank-you');
  });
});
