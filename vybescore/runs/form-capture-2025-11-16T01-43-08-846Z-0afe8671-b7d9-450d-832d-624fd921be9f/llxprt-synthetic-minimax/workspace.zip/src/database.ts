import initSqlJs from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

export interface ContactSubmission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseManager {
  private db: import('sql.js').Database | null = null;
  private dbPath: string;
  private SQL: Awaited<ReturnType<typeof initSqlJs>> | null = null;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  async initialize(): Promise<void> {
    // Initialize sql.js
    this.SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Ensure data directory exists
    const dataDir = join(process.cwd(), 'data');
    if (!existsSync(dataDir)) {
      mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    try {
      if (existsSync(this.dbPath)) {
        const dbBuffer = readFileSync(this.dbPath);
        this.db = new this.SQL!.Database(dbBuffer);
      } else {
        this.db = new this.SQL!.Database();
        this.createSchema();
      }
    } catch (error) {
      console.error('Error initializing database:', error);
      throw error;
    }
  }

  private createSchema(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    this.db.exec(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
  }

  async insertSubmission(submission: ContactSubmission): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  async save(): Promise<void> {
    if (this.db && this.SQL) {
      const data = this.db.export();
      writeFileSync(this.dbPath, data);
    }
  }

  async shutdown(): Promise<void> {
    await this.close();
    await this.save();
  }
}

export default DatabaseManager;