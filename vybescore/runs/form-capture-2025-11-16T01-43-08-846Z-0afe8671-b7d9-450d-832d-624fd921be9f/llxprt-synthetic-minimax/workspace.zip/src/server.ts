import express from 'express';
import { join } from 'path';
import DatabaseManager from './database.js';
import { FormValidator } from './validation.js';

// Create Express app with dependency injection
export const createApp = (dbManager?: DatabaseManager) => {
  const app = express();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());

  // Set up view engine
  app.set('view engine', 'ejs');
  app.set('views', join(process.cwd(), 'src', 'templates'));

  // Serve static files
  app.use(express.static('public'));

  // Use provided dbManager or create default one
  const database = dbManager || new DatabaseManager();

  // GET / - Render contact form
  app.get('/', (req: express.Request, res: express.Response) => {
    res.render('form', {
      errors: [],
      formData: {},
      title: 'Contact Us'
    });
  });

  // POST /submit - Handle form submission
  app.post('/submit', async (req: express.Request, res: express.Response) => {
    try {
      const formData = req.body;
      
      // Validate form data
      const validation = FormValidator.validateContactForm(formData);
      
      if (!validation.isValid) {
        return res.status(400).render('form', {
          errors: validation.errors,
          formData,
          title: 'Contact Us'
        });
      }
      
      // Insert submission into database
      await database.insertSubmission(formData);
      await database.save();
      
      // Redirect to thank you page
      res.redirect(302, '/thank-you');
      
    } catch (error) {
      console.error('Error processing submission:', error);
      res.status(500).render('form', {
        errors: [{ field: 'general', message: 'An error occurred. Please try again.' }],
        formData: req.body,
        title: 'Contact Us'
      });
    }
  });

  // GET /thank-you - Render thank you page
  app.get('/thank-you', (req: express.Request, res: express.Response) => {
    res.render('thank-you', {
      title: 'Thank You!'
    });
  });

  // 404 handler
  app.use((req: express.Request, res: express.Response) => {
    res.status(404).send('Page not found');
  });

  return { app, database };
};

// Start server function for production
const startProductionServer = async () => {
  const PORT = process.env.PORT || 3535;

  // Initialize default database manager
  const defaultDbManager = new DatabaseManager();

  // Graceful shutdown
  const gracefulShutdown = async () => {
    console.log('Shutting down gracefully...');
    await defaultDbManager.close();
    process.exit(0);
  };

  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);

  try {
    await defaultDbManager.initialize();
    console.log('Database initialized successfully');
    
    const { app } = createApp(defaultDbManager);
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

// Only start server if this file is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  startProductionServer();
}