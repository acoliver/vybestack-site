export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export class FormValidator {
  private static emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  private static phoneRegex = /^\+?[\d\s\-()]+$/;
  
  private static requiredFields = [
    'first_name',
    'last_name', 
    'street_address',
    'city',
    'state_province',
    'postal_code',
    'country',
    'email',
    'phone'
  ];

  static validateContactForm(data: Record<string, string>): ValidationResult {
    const errors: ValidationError[] = [];

    // Check required fields
    for (const field of this.requiredFields) {
      if (!data[field] || data[field].trim() === '') {
        errors.push({
          field,
          message: `${this.formatFieldName(field)} is required`
        });
      }
    }

    // Validate email format if email is provided and not empty
    if (data.email && data.email.trim() !== '') {
      if (!this.emailRegex.test(data.email.trim())) {
        errors.push({
          field: 'email',
          message: 'Please enter a valid email address'
        });
      }
    }

    // Validate phone number format if phone is provided and not empty
    if (data.phone && data.phone.trim() !== '') {
      const phone = data.phone.trim();
      if (!this.phoneRegex.test(phone) || phone.replace(/\D/g, '').length < 7) {
        errors.push({
          field: 'phone',
          message: 'Please enter a valid phone number (minimum 7 digits)'
        });
      }
    }

    // Validate postal code (should be alphanumeric, 3-10 characters)
    if (data.postal_code && data.postal_code.trim() !== '') {
      const postalCode = data.postal_code.trim();
      if (!/^[A-Za-z0-9\s-]{3,10}$/.test(postalCode)) {
        errors.push({
          field: 'postal_code',
          message: 'Please enter a valid postal code (3-10 alphanumeric characters)'
        });
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private static formatFieldName(field: string): string {
    return field
      .replace(/_/g, ' ')
      .split(' ')
      .map(word => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  }
}