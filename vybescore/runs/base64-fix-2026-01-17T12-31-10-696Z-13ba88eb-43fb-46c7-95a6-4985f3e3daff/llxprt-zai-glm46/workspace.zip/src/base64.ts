/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 * Output includes padding characters (=) as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding).
 * Throws an error if the input is invalid Base64.
 */
export function decode(input: string): string {
  // Validate that input only contains valid Base64 characters
  // Valid characters: A-Z, a-z, 0-9, +, /, and optional padding (=)
  const strictBase64Regex = /^[A-Za-z0-9+/]+={0,2}$/;
  
  if (!strictBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check that padding is only at the end and properly formed
  const paddingMatch = input.match(/=+$/);
  if (paddingMatch) {
    const paddingLength = paddingMatch[0].length;
    if (paddingLength > 2 || input.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  }

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Validate that we got valid UTF-8 output
    // If the input was truly invalid Base64 (e.g., random characters that 
    // happen to be in the alphabet), the re-encode check will catch it
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedInput = input.padEnd(Math.ceil(input.length / 4) * 4, '=');
    
    if (reencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: corrupted data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
