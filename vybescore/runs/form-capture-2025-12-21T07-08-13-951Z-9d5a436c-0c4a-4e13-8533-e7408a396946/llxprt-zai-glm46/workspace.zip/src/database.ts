import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import sql.js
import initSqlJs from 'sql.js';

// Import type definitions
import type SqlJs from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface Database {
  insertSubmission: (data: FormData) => Promise<void>;
  close: () => Promise<void>;
}

export async function createDatabase(): Promise<Database> {
  // Initialize sql.js
  const SQL = await initSqlJs();
  
  // Database file path
  const dbPath = path.join(__dirname, '../data/submissions.sqlite');
  
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  // Load or create database
  let db: SqlJs.Database;
  try {
    if (fs.existsSync(dbPath)) {
        const fileBuffer = fs.readFileSync(dbPath);
        const arrayBuffer = fileBuffer.buffer.slice(
          fileBuffer.byteOffset,
          fileBuffer.byteOffset + fileBuffer.byteLength
        );
        db = new SQL.Database(arrayBuffer);
        console.log('Loaded existing database');
      } else {
        db = new SQL.Database();
        console.log('Created new database');
      }
  } catch (error) {
    console.error('Error loading database:', error);
    db = new SQL.Database();
  }

  // Initialize schema if needed
  const schemaPath = path.join(__dirname, '../db/schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  
  try {
    // Create the submissions table
    db.run(schema);
    console.log('Database schema initialized');
  } catch (error) {
    // Table might already exist, which is fine
    console.log('Schema initialization note:', error);
  }

  return {
    async insertSubmission(data: FormData): Promise<void> {
      try {
        const stmt = db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province,
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);

        stmt.run([
          data.firstName,
          data.lastName,
          data.streetAddress,
          data.city,
          data.stateProvince,
          data.postalCode,
          data.country,
          data.email,
          data.phone
        ]);

        stmt.free();

        // Save database to disk
        await saveDatabase(db);
      } catch (error) {
        console.error('Error inserting submission:', error);
        throw error;
      }
    },

    async close(): Promise<void> {
      try {
        await saveDatabase(db);
        db.close();
      } catch (error) {
        console.error('Error closing database:', error);
      }
    }
  };
}

async function saveDatabase(db: SqlJs.Database): Promise<void> {
  return new Promise((resolve, reject) => {
    try {
      const data = db.export();
      const dbPath = path.join(__dirname, '../data/submissions.sqlite');
      
      // Convert Uint8Array to Buffer properly
      const buffer = Buffer.alloc(data.length);
      for (let i = 0; i < data.length; i++) {
        buffer[i] = data[i];
      }
      
      fs.writeFileSync(dbPath, buffer);
      resolve();
    } catch (error) {
      reject(error);
    }
  });
}