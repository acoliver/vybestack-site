import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createDatabase } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: Awaited<ReturnType<typeof createDatabase>>;

async function initializeDatabase() {
  db = await createDatabase();
}

async function startServer() {
  try {
    await initializeDatabase();
    
    // Routes
    app.get('/', (req, res) => {
      res.render('form', { 
        errors: [], 
        values: {} 
      });
    });

    app.post('/submit', async (req, res) => {
      const formData = req.body as FormData;
      const errors = validateFormData(formData);

      if (errors.length > 0) {
        res.status(400).render('form', { 
          errors: errors.map(e => e.message), 
          values: formData 
        });
        return;
      }

      // Insert into database
      try {
        await db.insertSubmission({
          firstName: formData.firstName!,
          lastName: formData.lastName!,
          streetAddress: formData.streetAddress!,
          city: formData.city!,
          stateProvince: formData.stateProvince!,
          postalCode: formData.postalCode!,
          country: formData.country!,
          email: formData.email!,
          phone: formData.phone!
        });
        res.redirect('/thank-you');
      } catch (error) {
        console.error('Database insertion error:', error);
        res.status(500).render('form', { 
          errors: ['An error occurred while saving your submission. Please try again.'], 
          values: formData 
        });
      }
    });

    app.get('/thank-you', (req, res) => {
      // In a real app, we'd get the first name from the session or recent submission
      // For this demo, we'll just use a generic greeting
      res.render('thank-you', { firstName: 'friend' });
    });

    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown
    const gracefulShutdown = async () => {
      console.log('Shutting down gracefully...');
      server.close(async () => {
        console.log('HTTP server closed');
        await db.close();
        console.log('Database closed');
        process.exit(0);
      });
    };

    process.on('SIGTERM', gracefulShutdown);
    process.on('SIGINT', gracefulShutdown);

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  }

  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }

  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Email validation (simple regex)
  if (data.email?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

// Phone validation (international formats)
  if (data.phone?.trim() && !/^\+?[\d\s\-()]+$/.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode?.trim() && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode?.trim() && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  return errors;
}

// Export app for testing
export { app };

// Function to initialize database for testing
export async function initializeTestDatabase() {
  if (!db) {
    await initializeDatabase();
  }
}

// Start the server only if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(console.error);
}
