import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { createDatabase } from './database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
let db: Awaited<ReturnType<typeof createDatabase>>;

async function initializeDatabase() {
  db = await createDatabase();
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    values: {} 
  });
});

app.post('/submit', async (req, res) => {
  const formData = req.body as FormData;
  const errors = validateFormData(formData);

  if (errors.length > 0) {
    res.status(400).render('form', { 
      errors: errors.map(e => e.message), 
      values: formData 
    });
    return;
  }

  // Insert into database
  try {
    await db.insertSubmission({
      firstName: formData.firstName!,
      lastName: formData.lastName!,
      streetAddress: formData.streetAddress!,
      city: formData.city!,
      stateProvince: formData.stateProvince!,
      postalCode: formData.postalCode!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!
    });
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Database insertion error:', error);
    res.status(500).render('form', { 
      errors: ['An error occurred while saving your submission. Please try again.'], 
      values: formData 
    });
  }
});

app.get('/thank-you', (req, res) => {
  // In a real app, we'd get the first name from the session or recent submission
  // For this demo, we'll just use a generic greeting
  res.render('thank-you', { firstName: 'friend' });
});

function validateFormData(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields validation
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  }

  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  }

  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  }

  // Email validation (simple regex)
  if (data.email?.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  // Phone validation (international formats)
  if (data.phone?.trim() && !/^\+?[\d\s\-()]+$/.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Please enter a valid phone number' });
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode?.trim() && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Please enter a valid postal code' });
  }

  return errors;
}

// Initialize database and export app for testing
initializeDatabase().then(() => {
  console.log('Test app database initialized');
}).catch(console.error);

export { app, db };