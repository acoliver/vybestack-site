/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface Observer {
  name?: string
  value?: unknown
  updateFn: (value?: unknown) => unknown
  readFn?: () => unknown
}

export interface Subject {
  name?: string
  observer?: Observer
  value: unknown
  equalFn?: EqualFn<unknown>
  subscribers?: Set<Observer>
  readFn?: () => unknown
}

let activeObserver: Observer | undefined

export function getActiveObserver(): Observer | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer | undefined): Observer | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver(observer: Observer): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    if (observer.readFn) {
      observer.value = observer.readFn()
    } else {
      observer.value = observer.updateFn(observer.value)
    }
  } finally {
    activeObserver = previous
  }
}

export function subscribe(subject: Subject, observer: Observer): void {
  if (!subject.subscribers) {
    subject.subscribers = new Set()
  }
  subject.subscribers.add(observer)
}

export function unsubscribe(subject: Subject, observer: Observer): void {
  subject.subscribers?.delete(observer)
}

export function notifySubscribers(subject: Subject): void {
  if (!subject.subscribers) return
  
  const subscribers = Array.from(subject.subscribers)
  for (const subscriber of subscribers) {
    updateObserver(subscriber)
  }
}
