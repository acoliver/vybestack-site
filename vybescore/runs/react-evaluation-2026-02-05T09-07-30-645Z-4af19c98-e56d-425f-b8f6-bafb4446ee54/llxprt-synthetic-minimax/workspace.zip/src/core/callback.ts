/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  setActiveObserver,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer = {
    value,
    updateFn: (currentValue) => {
      if (disposed) return currentValue
      return updateFn(currentValue as T)
    },
  }
  
  // Execute the callback to establish dependencies and get initial value
  // This will automatically subscribe the observer to any subjects it reads
  const previousActive = setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previousActive)
  }
  
  return () => {
    if (disposed) return
    disposed = true
  }
}
