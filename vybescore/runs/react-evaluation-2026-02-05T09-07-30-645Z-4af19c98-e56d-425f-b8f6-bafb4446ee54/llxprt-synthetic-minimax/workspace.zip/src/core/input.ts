/**
 * Input closure implementation for reactive primitives.
 */

/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  subscribe,
  notifySubscribers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    subscribers: new Set(),
    readFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      subscribe(s, observer)
      s.observer = observer
    }
    return s.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    const previousValue = s.value
    s.value = nextValue
    
    // Notify all subscribers about the change
    if (previousValue !== nextValue) {
      notifySubscribers(s)
    }
    
    return s.value as T
  }

  return [read, write]
}
