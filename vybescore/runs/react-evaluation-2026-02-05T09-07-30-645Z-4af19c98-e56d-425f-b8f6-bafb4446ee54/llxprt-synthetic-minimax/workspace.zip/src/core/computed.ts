/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  setActiveObserver,
  EqualFn,
  notifySubscribers,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer = {
    name: options?.name,
    value,
    updateFn: (val) => updateFn(val as T),
    readFn: undefined,
  }
  
  // Create a subject for this computed value to enable subscription
  const subject: Subject = {
    name: options?.name,
    observer: o,
    value: undefined,
    subscribers: new Set(),
  }
  
  o.readFn = () => {
    // Set this observer as active to track dependencies
    const previousActive = setActiveObserver(o)
    try {
      o.value = o.updateFn(o.value)
    } finally {
      setActiveObserver(previousActive)
    }
    
    // Update subject and notify all subscribers when dependencies change
    subject.value = o.value
    notifySubscribers(subject)
    
    return o.value as T
  }
  
  const read: GetterFn<T> = () => {
    // Use the readFn to properly track dependencies and notify subscribers
    return o.readFn!() as T
  }
  
  // Initialize the computed value exactly once, but only if value is provided
  if (value !== undefined) {
    o.value = o.updateFn(o.value)
  }
  
  return read
}
