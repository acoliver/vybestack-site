import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { ReportData, RenderOptions } from './types.js';

export const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

export type { ReportData, ReportEntry, RenderOptions } from './types.js';