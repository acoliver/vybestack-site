#!/usr/bin/env node

import { readFileSync } from 'fs';
import { ReportData, RenderOptions, formatters } from '../formats/index.js';

function validateData(data: any): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: expected an object');
  }

  if (!data.title || typeof data.title !== 'string') {
    throw new Error('Invalid data: title is required and must be a string');
  }

  if (!data.summary || typeof data.summary !== 'string') {
    throw new Error('Invalid data: summary is required and must be a string');
  }

  if (!Array.isArray(data.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }

  for (const entry of data.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: each entry must be an object');
    }

    if (!entry.label || typeof entry.label !== 'string') {
      throw new Error('Invalid data: each entry must have a label string');
    }

    if (typeof entry.amount !== 'number') {
      throw new Error('Invalid data: each entry must have a numeric amount');
    }
  }
}

function parseArgs(): { 
  filePath: string; 
  format: string; 
  outputPath?: string; 
  includeTotals: boolean 
} {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    throw new Error('Insufficient arguments. Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  }
  
  const filePath = args[0];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format') {
      if (i + 1 < args.length) {
        format = args[i + 1];
        i++;
      } else {
        throw new Error('--format requires a value');
      }
    } else if (args[i] === '--output') {
      if (i + 1 < args.length) {
        outputPath = args[i + 1];
        i++;
      } else {
        throw new Error('--output requires a value');
      }
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    throw new Error('--format is required');
  }
  
  return { filePath, format, outputPath, includeTotals };
}

function main() {
  try {
    const { filePath, format, outputPath, includeTotals } = parseArgs();
    
    if (!formatters[format]) {
      throw new Error(`Unsupported format: ${format}`);
    }
    
    const fileContent = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    validateData(data);
    
    const options: RenderOptions = { includeTotals };
    const renderer = formatters[format];
    const output = renderer(data, options);
    
    if (outputPath) {
      // For simplicity, we're writing to stdout even with --output
      // In a more complete implementation, we would write to the file
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();