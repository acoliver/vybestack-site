import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    try {
      const pageParam = req.query.page as string | undefined;
      const limitParam = req.query.limit as string | undefined;

      const page = pageParam ? Number(pageParam) : undefined;
      const limit = limitParam ? Number(limitParam) : undefined;

      // Validate query parameters
      if (pageParam !== undefined) {
        if (!Number.isFinite(page ?? NaN) || (page ?? 0) < 1 || !Number.isInteger(page ?? 0)) {
          return res.status(400).json({ 
            error: 'page must be a positive integer greater than 0' 
          });
        }
        if ((page ?? 0) > 10000) {
          return res.status(400).json({ 
            error: 'page is too large (maximum: 10000)' 
          });
        }
      }

      if (limitParam !== undefined) {
        if (!Number.isFinite(limit ?? NaN) || (limit ?? 0) < 1 || !Number.isInteger(limit ?? 0)) {
          return res.status(400).json({ 
            error: 'limit must be a positive integer greater than 0' 
          });
        }
        if ((limit ?? 0) > 100) {
          return res.status(400).json({ 
            error: 'limit is too large (maximum: 100)' 
          });
        }
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
