import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    let page: number | undefined;
    let limit: number | undefined;

    try {
      if (pageParam !== undefined) {
        if (pageParam === '' || isNaN(Number(pageParam))) {
          return res.status(400).json({ error: 'Page must be a valid number' });
        }
        page = Number(pageParam);
        if (page <= 0 || !Number.isInteger(page)) {
          return res.status(400).json({ error: 'Page must be a positive integer' });
        }
        if (page > 10000) {
          return res.status(400).json({ error: 'Page number too large' });
        }
      }

      if (limitParam !== undefined) {
        if (limitParam === '' || isNaN(Number(limitParam))) {
          return res.status(400).json({ error: 'Limit must be a valid number' });
        }
        limit = Number(limitParam);
        if (limit <= 0 || !Number.isInteger(limit)) {
          return res.status(400).json({ error: 'Limit must be a positive integer' });
        }
        if (limit > 100) {
          return res.status(400).json({ error: 'Limit cannot exceed 100' });
        }
      }

      const payload = listInventory(db, { page, limit });
      res.json(payload);
    } catch (error) {
      res.status(500).json({ error: 'Internal server error' });
    }
  });

  return app;
}
