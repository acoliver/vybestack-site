import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '..', 'db', 'schema.sql');

interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: Partial<Record<keyof Submission, string>>;
}

let db: Database | null = null;
let dbInitialized: boolean = false;
let initPromise: Promise<void> | null = null;

const app = express();

app.use(express.static(path.join(__dirname, '..', 'public')));
app.use(express.urlencoded({ extended: true }));

// Views are in src/views, but when running from dist, we need to look there
const viewsPath = fs.existsSync(path.join(__dirname, 'views'))
  ? path.join(__dirname, 'views')
  : path.join(__dirname, '..', 'src', 'views');

app.set('view engine', 'ejs');
app.set('views', viewsPath);

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

function validatePostalCode(postal: string): boolean {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

function validateSubmission(data: Submission): ValidationResult {
  const errors: Partial<Record<keyof Submission, string>> = {};
  
  if (!data.first_name?.trim()) {
    errors.first_name = 'First name is required';
  }
  
  if (!data.last_name?.trim()) {
    errors.last_name = 'Last name is required';
  }
  
  if (!data.street_address?.trim()) {
    errors.street_address = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.state_province?.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!data.postal_code?.trim()) {
    errors.postal_code = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postal_code)) {
    errors.postal_code = 'Postal code must contain only letters, digits, spaces, and hyphens';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +';
  }
  
  return {
    valid: Object.keys(errors).length === 0,
    errors
  };
}

async function initDatabase(): Promise<void> {
  if (dbInitialized) {
    return;
  }
  
  if (initPromise) {
    return initPromise;
  }
  
  initPromise = (async () => {
    const SQL = await initSqlJs();
    
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(buffer);
    } else {
      db = new SQL.Database();
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
      saveDatabase();
    }
    
    dbInitialized = true;
  })();
  
  return initPromise;
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {},
    formData: {},
    success: false
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  await initDatabase();
  
  const submission: Submission = {
    first_name: req.body.first_name || '',
    last_name: req.body.last_name || '',
    street_address: req.body.street_address || '',
    city: req.body.city || '',
    state_province: req.body.state_province || '',
    postal_code: req.body.postal_code || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateSubmission(submission);
  
  if (!validation.valid) {
    res.status(400);
    return res.render('form', {
      errors: validation.errors,
      formData: submission,
      success: false
    });
  }
  
  if (db) {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      submission.first_name,
      submission.last_name,
      submission.street_address,
      submission.city,
      submission.state_province,
      submission.postal_code,
      submission.country,
      submission.email,
      submission.phone
    ]);
    stmt.free();
    saveDatabase();
  }
  
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {});
});

export async function startServer(port: number = 3535): Promise<void> {
  await initDatabase();
  
  return new Promise<void>((resolve) => {
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
      resolve();
    });
    
    setupGracefulShutdown(server);
  });
}

function setupGracefulShutdown(server: { close: (cb?: () => void) => void }): void {
  const shutdown = (signal: string) => {
    console.log(`\n${signal} received, closing server gracefully...`);
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      console.log('Server closed');
      process.exit(0);
    });
    
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };
  
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

export default app;

if (import.meta.url === `file://${process.argv[1]}`) {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  startServer(port);
}
