import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: { close: (cb?: () => void) => void } | null;
let app: ReturnType<typeof import('../../src/server.js').default>;
const dbPath = path.resolve('data', 'submissions.sqlite');

function cleanDatabase() {
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
}

beforeAll(async () => {
  // Create data directory and clean database before starting server
  const dataDir = path.resolve('data');
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  cleanDatabase();
  
  const serverModule = await import('../../src/server.js');
  app = serverModule.default;
  // Start the server in the background
  const port = 3535;
  server = await new Promise((resolve) => {
    const s = app.listen(port, () => resolve(s));
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/html/);
    
    const $ = cheerio.load(response.text);
    
    // Check all input fields exist
    expect($('#first_name')).toHaveLength(1);
    expect($('#last_name')).toHaveLength(1);
    expect($('#street_address')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#state_province')).toHaveLength(1);
    expect($('#postal_code')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check form action and method
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="POST"]')).toHaveLength(1);
  });

  it('shows validation errors for empty submission', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({});
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check error messages appear
    expect($('.error-message')).toHaveLength(9);
    expect(response.text).toContain('is required');
  });

  it('shows validation errors for invalid email', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'John',
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'New York',
        state_province: 'NY',
        postal_code: '10001',
        country: 'USA',
        email: 'not-an-email',
        phone: '+1 555-123-4567'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email');
  });

  it('shows validation errors for invalid phone', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'John',
        last_name: 'Doe',
        street_address: '123 Main St',
        city: 'New York',
        state_province: 'NY',
        postal_code: '10001',
        country: 'USA',
        email: 'john@example.com',
        phone: 'abc123'
      });
    
    expect(response.status).toBe(400);
    expect(response.text).toContain('Phone number');
  });

  it('persists submission and redirects', async () => {
    cleanDatabase();
    
    const formData = {
      first_name: 'Jane',
      last_name: 'Smith',
      street_address: '456 Oak Avenue',
      city: 'London',
      state_province: 'England',
      postal_code: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.co.uk',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check redirect leads to thank you page
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank You');
  });

  it('accepts international phone and postal formats', async () => {
    cleanDatabase();
    
    const formData = {
      first_name: 'Carlos',
      last_name: 'García',
      street_address: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      state_province: 'Buenos Aires',
      postal_code: 'C1000',
      country: 'Argentina',
      email: 'carlos@example.com.ar',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        first_name: 'Test',
        last_name: 'User',
        street_address: '',
        city: '',
        state_province: '',
        postal_code: '',
        country: '',
        email: 'invalid-email',
        phone: ''
      });
    
    expect(response.status).toBe(400);
    const $ = cheerio.load(response.text);
    
    // Check that entered values are preserved
    expect($('#first_name').val()).toBe('Test');
    expect($('#last_name').val()).toBe('User');
  });

  it('renders thank you page with humorous content', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.text).toMatch(/thank you/i);
    expect(response.text).toMatch(/spam|stranger|internet/i);
    expect(response.text).toMatch(/submit/i);
  });

  it('handles alphanumeric postal codes', async () => {
    cleanDatabase();
    
    const testCases = [
      'SW1A 1AA',    // UK
      '10001',       // US
      'C1000',       // Argentina
      'B1675',       // Argentina
      'K1A0B1'       // Canada
    ];
    
    for (const postalCode of testCases) {
      const response = await request(app)
        .post('/submit')
        .type('form')
        .send({
          first_name: 'Test',
          last_name: 'User',
          street_address: '123 Test St',
          city: 'Test City',
          state_province: 'TS',
          postal_code: postalCode,
          country: 'Test Country',
          email: 'test@example.com',
          phone: '+1 555-123-4567'
        });
      
      expect(response.status).toBe(302);
    }
  });
});
