#!/usr/bin/env node

import * as fs from 'node:fs';
import { formatters } from '../formats/index.js';
import type { ReportData, RenderOptions } from '../types.js';

function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  let dataPath = '';
  let format = 'markdown';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unknown option: ${arg}`);
    } else if (dataPath === '') {
      dataPath = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (dataPath === '') {
    throw new Error('Missing required argument: <data.json>');
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid JSON: entry at index ${i} missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(
        `Invalid JSON: entry at index ${i} missing or invalid "amount" field (expected number)`
      );
    }
  }

  return data as ReportData;
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const { dataPath, format, outputPath, includeTotals } = parseArgs(args);

    // Read and parse JSON file
    let jsonContent: string;
    try {
      jsonContent = fs.readFileSync(dataPath, 'utf-8');
    } catch (error) {
      if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        throw new Error(`File not found: ${dataPath}`);
      }
      throw error;
    }

    let data: unknown;
    try {
      data = JSON.parse(jsonContent);
    } catch (error) {
      throw new Error(`Invalid JSON in file: ${dataPath}`);
    }

    // Validate data structure
    const reportData = validateReportData(data);

    // Get formatter
    const formatter = formatters[format];
    if (!formatter) {
      throw new Error(`Unsupported format: ${format}`);
    }

    // Render report
    const options: RenderOptions = { includeTotals };
    const output = formatter(reportData, options);

    // Write output
    if (outputPath) {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    console.error(`Error: ${message}`);
    process.exit(1);
  }
}

main();
