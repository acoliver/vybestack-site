/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  const equalFn: EqualFn<T> | undefined = (equal === undefined) 
    ? undefined 
    : (typeof equal === 'function') 
      ? equal 
      : (a, b) => a === b

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter: GetterFn<T> = (): T => {
    // When the computed value is accessed, register the current observer
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      // Register this computed value as a dependency of the current observer
      const obs = observer as Observer<T>
      if (!obs.subjects) {
        obs.subjects = []
      }
      if (!obs.subjects.includes(o)) {
        obs.subjects.push(o)
        
        // Also establish reverse dependency tracking for proper propagation
        if (!o.observers) {
          o.observers = []
        }
        if (!o.observers.includes(obs)) {
          o.observers.push(obs)
        }
      }
    }
    
    return o.value!
  }
  
  // Wrap the update function to track dependencies
  const wrappedUpdateFn: UpdateFn<T> = (prev) => {
    // Set this observer as active to track dependencies during computation
    const previousObserver = getActiveObserver()
    setActiveObserver(o)
    
    // Reset tracked dependencies
    o.subjects = []
    
    try {
      return updateFn(prev)
    } finally {
      // Restore previous observer
      setActiveObserver(previousObserver)
    }
  }
  
  o.updateFn = wrappedUpdateFn
  
  // Initial computation
  updateObserver(o)
  
  return getter
}
