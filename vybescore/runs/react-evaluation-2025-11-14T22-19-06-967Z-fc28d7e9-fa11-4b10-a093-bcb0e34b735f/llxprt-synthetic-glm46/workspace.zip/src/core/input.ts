/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = (equal === undefined) 
    ? undefined 
    : (typeof equal === 'function') 
      ? equal 
      : (a, b) => a === b

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    observers: [],
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Track which observers depend on this input
      if (!s.observers.includes(observer)) {
        s.observers.push(observer)
      }
      
// Also register this input as a dependency of the current observer
      const obs = observer as Observer<T>
      if (!obs.subjects) {
        obs.subjects = []
      }
      if (!obs.subjects.includes(s)) {
        obs.subjects.push(s)
      }
      
      // Track which observers depend on this input and establish reverse dependency
      if (!s.observers.includes(observer)) {
        s.observers.push(observer)
      }
      if (!obs.subjects.includes(s)) {
        obs.subjects.push(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
  // Check if value has actually changed
  if (s.equalFn && s.equalFn(s.value, nextValue)) {
    return s.value
  }
  
  s.value = nextValue
  
// Update all observers that depend on this input
  // Create a copy to avoid issues with array modification during iteration
  const currentObservers = [...s.observers]
  currentObservers.forEach(observer => {
    // Cast to Observer to access updateFn
    const obs = observer as Observer<T>
    if (typeof obs.updateFn === 'function') {
      updateObserver(obs)
    }
  })
  
  return s.value
}

  return [read, write]
}
