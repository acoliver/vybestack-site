/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register observer to track dependencies and run the initial effect
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects it was attached to
    if (observer.subjects) {
      observer.subjects.forEach((subject: Subject<unknown>) => {
        // Remove this observer from the subject's observers array
        if (subject.observers) {
          const index = subject.observers.indexOf(observer)
          if (index !== -1) {
            subject.observers.splice(index, 1)
          }
        }
      })
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
