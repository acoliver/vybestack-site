/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  subjects?: any[] // Track dependencies
  observers?: ObserverR[] // Track observers that depend on this one
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
  observers: ObserverR[]
} & {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  [key: string]: any // Allow additional properties for backward compatibility
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    if (typeof observer.updateFn === 'function') {
      const newValue = observer.updateFn(observer.value)
      // Only update if value has changed
      if (observer.value !== newValue) {
        observer.value = newValue
        
        // Notify dependent observers (forward dependencies)
        if (observer.subjects) {
          // eslint-disable-next-line @typescript-eslint/no-explicit-any
          observer.subjects.forEach((dependent: any) => {
            if (dependent.updateFn) {
              updateObserver(dependent)
            }
          })
        }
        
        // Also notify observers chain for reverse dependencies
        if (observer.observers) {
          observer.observers.forEach((subjectObserver: ObserverR) => {
            const obs = subjectObserver as Observer<unknown>
            if (typeof obs.updateFn === 'function') {
              updateObserver(obs)
            }
          })
        }
      }
    }
  } finally {
    activeObserver = previous
  }
}