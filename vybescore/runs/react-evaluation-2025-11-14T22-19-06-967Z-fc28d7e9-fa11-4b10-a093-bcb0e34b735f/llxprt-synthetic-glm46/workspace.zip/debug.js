// Debug script to understand the reactive system
import { createInput, createComputed, createCallback } from './src/index.js'

console.log("=== Testing reactive system ===")

// Test 1: Basic dependencies
console.log("\nTest 1: Basic dependencies")
const [input, setInput] = createInput(1)
const timesTwo = createComputed(() => {
  console.log("  timesTwo: computing with input =", input())
  return input() * 2
})
const timesThirty = createComputed(() => {
  console.log("  timesThirty: computing with input =", input())
  return input() * 30
})
const sum = createComputed(() => {
  console.log("  sum: computing with timesTwo =", timesTwo(), "timesThirty =", timesThirty())
  return timesTwo() + timesThirty()
})

console.log("Initial sum:", sum())
console.log("Setting input to 3")
setInput(3)
console.log("After change, sum:", sum())

// Test 2: Callbacks
console.log("\nTest 2: Callbacks")
const [input2, setInput2] = createInput(1)
const output = createComputed(() => {
  console.log("  output: computing with input2 =", input2())
  return input2() + 1
})
let value = 0
const unsubscribe = createCallback(() => {
  console.log("  callback: output =", output())
  value = output()
})

console.log("Initial value:", value)
console.log("Setting input2 to 3")
setInput2(3)
console.log("Final value:", value)
unsubscribe()