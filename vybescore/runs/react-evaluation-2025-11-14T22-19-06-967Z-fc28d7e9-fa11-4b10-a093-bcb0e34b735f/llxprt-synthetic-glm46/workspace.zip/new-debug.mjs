// Simpler debug script to understand the reactive system
import { createInput, createComputed, createCallback } from './dist/src/index.js'

console.log("=== Testing callbacks ===")
const [input, setInput] = createInput(1)
const output = createComputed(() => input() + 1)

let callCount = 0
const unsubscribe = createCallback(() => {
  console.log(`Callback called! output = ${output()}`)
  callCount++
})

console.log(`Initial call count: ${callCount}`)
console.log("Setting input to 2")
setInput(2)
console.log(`Final call count: ${callCount}`)