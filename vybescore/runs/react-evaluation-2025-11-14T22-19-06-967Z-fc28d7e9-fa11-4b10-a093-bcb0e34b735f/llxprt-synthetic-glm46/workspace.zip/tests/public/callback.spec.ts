import { describe, it, expect } from 'vitest'
import { createCallback } from '../../src/index.js'

describe('createCallback', () => {
  it('returns unsubscribe function', () => {
    const unsubscribe = createCallback(() => { /* test side effect */ })
    expect(typeof unsubscribe).toBe('function')
  })

  it('unsubscribe function can be called without error', () => {
    const unsubscribe = createCallback(() => { /* test side effect */ })
    expect(() => unsubscribe()).not.toThrow()
  })
})
