import express, { Express, Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { Database } from 'sql.js';

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}



const app: Express = express();
const PORT = process.env.PORT || 3535;
const dbPath = path.resolve('data', 'submissions.sqlite');
const schemaPath = path.resolve('db', 'schema.sql');

let db: Database | null = null;
const initDatabase = async (): Promise<void> => {
  try {
    const sqlite3 = await import('sql.js');
    const initSqlJs = sqlite3.default;
    const SQL = await initSqlJs();
    
    let dbBuffer: Uint8Array | undefined = undefined;
    if (fs.existsSync(dbPath)) {
      dbBuffer = fs.readFileSync(dbPath);
    }
    
    db = new SQL.Database(dbBuffer);
    
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db!.exec(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
};

const saveDatabase = (): void => {
  if (db && fs.existsSync(path.dirname(dbPath))) {
    try {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Database saved successfully');
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
};

const stopDatabase = (): void => {
  if (db) {
    saveDatabase();
    db.close();
    db = null;
    console.log('Database closed');
  }
};

const validateForm = (data: Partial<FormData>): string[] => {
  const errors: string[] = [];
  
  if (!data.firstName?.trim()) {
    errors.push('First name is required');
  }
  
  if (!data.lastName?.trim()) {
    errors.push('Last name is required');
  }
  
  if (!data.streetAddress?.trim()) {
    errors.push('Street address is required');
  }
  
  if (!data.city?.trim()) {
    errors.push('City is required');
  }
  
  if (!data.stateProvince?.trim()) {
    errors.push('State/Province/Region is required');
  }
  
  if (!data.postalCode?.trim()) {
    errors.push('Postal/Zip code is required');
  }
  
  if (!data.country?.trim()) {
    errors.push('Country is required');
  }
  
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!data.email?.trim()) {
    errors.push('Email is required');
  } else if (!emailRegex.test(data.email)) {
    errors.push('Please provide a valid email address');
  }
  
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!data.phone?.trim()) {
    errors.push('Phone number is required');
  } else if (!phoneRegex.test(data.phone)) {
    errors.push('Please provide a valid phone number');
  }
  
  return errors;
};

app.use('/public', express.static('public'));
app.use(express.urlencoded({ extended: true }));

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  if (!db) {
    res.status(500).send('Database not initialized');
    return;
  }

  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);
  
  if (errors.length > 0) {
    res.status(400).render('form', {
      errors,
      values: formData
    });
    return;
  }

  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province,
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    stmt.free();
    
    saveDatabase();
    res.redirect(302, '/thank-you');
  } catch (error) {
    stmt.free();
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['Sorry, something went wrong. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {});
});

const gracefulShutdown = (): void => {
  console.log('Received shutdown signal, closing gracefully...');
  stopDatabase();
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

const startServer = async (): Promise<void> => {
  await initDatabase();
  
  app.set('view engine', 'ejs');
  app.set('views', path.join(process.cwd(), 'src', 'templates'));
  
  const server = app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
  });
  
  server.on('close', gracefulShutdown);
};

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
