declare module 'sql.js' {
  export class Database {
    constructor(data?: Uint8Array);
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export class Statement {
    run(values?: unknown[]): Statement;
    free(): void;
    get(values?: unknown[]): unknown[];
    step(): boolean;
    columns(): string[];
    getAsObject(values?: unknown[]): Record<string, unknown>;
  }
  
  export function create_db(data?: Uint8Array): Database;
  
  export default function(): Promise<{
    Database: typeof Database;
  }>;
}