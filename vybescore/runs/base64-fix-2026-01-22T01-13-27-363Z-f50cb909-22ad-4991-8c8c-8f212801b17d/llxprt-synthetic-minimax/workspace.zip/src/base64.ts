/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Handles both standard Base64 and base64url variants.
 */
export function decode(input: string): string {
  // Normalize input: handle both standard and URL-safe variants
  const normalized = input.trim().replace(/-/g, '+').replace(/_/g, '/');
  
  // Validate input - allow missing padding, check only character set
  const clean = normalized.replace(/\s+/g, '').replace(/=+$/g, '');
  if (!/^[A-Za-z0-9+/]*$/.test(clean)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }
  
  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input: invalid encoding');
  }
}
