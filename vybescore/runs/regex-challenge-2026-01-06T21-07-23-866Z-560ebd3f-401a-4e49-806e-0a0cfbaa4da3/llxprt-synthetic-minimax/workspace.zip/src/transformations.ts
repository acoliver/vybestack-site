/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace and sentence boundaries
  let result = text.trim();
  
  // Replace multiple spaces with single space
  result = result.replace(/\s+/g, ' ');
  
  // Capitalize first character of the entire text
  result = result.replace(/^([a-z])/, (match) => match.toUpperCase());
  
  // Capitalize first character after sentence endings (.?!)
  result = result.replace(/([.!?]\s+)([a-z])/g, (match, p1, p2) => {
    return p1 + p2.toUpperCase();
  });
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern to match URLs (http/https/ftp) with optional punctuation
  const urlPattern = /\bhttps?:\/\/[^\s<>"'()]+|\bftp:\/\/[^\s<>"'()]+/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation like . , ! ? ; : )
    return url.replace(/[.,!?;:)]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Use word boundaries to avoid replacing in the middle of words
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match complete http:// URLs including path
  const httpPattern = /\bhttp:\/\/[^\s<>"'()]+\b/gi;
  
  return text.replace(httpPattern, (match) => {
    // Extract host and path by parsing the URL
    const urlMatch = match.match(/\bhttp:\/\/([^\s<>"'()]+)/i);
    if (!urlMatch) {
      return 'https://' + match.slice(7); // Simple scheme upgrade
    }
    
    const afterScheme = match.slice(7); // Remove 'http://'
    
    // Split the rest to separate host from path
    const firstSlash = afterScheme.indexOf('/');
    let host, path;
    
    if (firstSlash === -1) {
      // No path, just host
      host = afterScheme;
      path = '';
    } else {
      host = afterScheme.substring(0, firstSlash);
      path = afterScheme.substring(firstSlash);
    }
    
    // Check if path begins with /docs/
    if (path.startsWith('/docs/')) {
      // Skip host rewrite if path contains dynamic hints or legacy extensions
      const hasDynamicHints = /(cgi-bin|[?&]=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.example.com and upgrade scheme
        const newHost = host.replace('example.com', 'docs.example.com');
        return 'https://' + newHost + path;
      } else {
        // Just upgrade scheme, keep original host
        return 'https://' + host + path;
      }
    } else {
      // For non-docs URLs, just upgrade scheme
      return 'https://' + host + path;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, basic check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic leap year and month day validation
  if (month === 2) {
    // February
    const isLeapYear = (parseInt(year) % 4 === 0 && parseInt(year) % 100 !== 0) || parseInt(year) % 400 === 0;
    if (day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else if ([4, 6, 9, 11].includes(month)) {
    // April, June, September, November - max 30 days
    if (day > 30) {
      return 'N/A';
    }
  }
  
  return year;
}
