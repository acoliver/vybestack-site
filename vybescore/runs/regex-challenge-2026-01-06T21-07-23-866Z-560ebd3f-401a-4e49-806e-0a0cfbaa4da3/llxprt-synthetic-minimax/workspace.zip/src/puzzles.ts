/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern to match words starting with prefix
  // Use word boundaries to ensure we match complete words
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(match => {
    const normalizedMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      normalizedMatch.toLowerCase() === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of the token
  const matches: string[] = [];
  
  // Iterate through the text to find all token occurrences
  for (let i = 0; i < text.length - token.length + 1; i++) {
    const substring = text.substring(i, i + token.length);
    if (substring === token) {
      // Check if token appears at the beginning of the string
      if (i === 0) {
        continue;
      }
      
      // Check if there's a digit before the token
      const beforeChar = text.charAt(i - 1);
      if (/\d/.test(beforeChar)) {
        // Found token after digit, include it (digit + token)
        matches.push(beforeChar + token);
      }
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Empty password check
  if (value.length === 0) {
    return false;
  }
  
  // Check minimum length (10+ characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check at least one symbol
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences like "abab"
  // This regex looks for patterns where two characters repeat immediately
  if (/(..)\1/.test(value)) {
    return false;
  }
  
  // Check for repeated single characters like "aaa" or "bbb"
  if (/([A-Za-z0-9])\1{2,}/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Check if it's definitely an IPv4 address first (to exclude)
  if (isIPv4(value)) {
    return false;
  }
  
  // Pattern for IPv6 addresses including shorthand with ::
  // IPv6 format: 8 groups of 4 hex digits, or shorthand with ::
  const ipv6Patterns = [
    // Full IPv6 with all 8 groups
    /^[0-9A-Fa-f]{1,4}:([0-9A-Fa-f]{1,4}:){7}[0-9A-Fa-f]{1,4}$/,
    
    // Shorthand with :: (allowing multiple groups in shorthand)
    /^([0-9A-Fa-f]{1,4}:){1,7}:|^:([0-9A-Fa-f]{1,4}:){1,7}|[0-9A-Fa-f]{1,4}::([0-9A-Fa-f]{1,4}:){0,7}[0-9A-Fa-f]{0,4}$/,
    
    // Another IPv6 pattern that handles most cases
    /^(([0-9A-Fa-f]{1,4}:){1,7}|(([0-9A-Fa-f]{1,4}:){0,7})::)(([0-9A-Fa-f]{1,4}:){0,7})$/,
    
    // Simplified pattern for common IPv6 formats
    /^([0-9A-Fa-f]{1,4}:){0,7}([0-9A-Fa-f]{1,4})?$/,
  ];
  
  // Check if any pattern matches
  return ipv6Patterns.some(pattern => {
    try {
      return pattern.test(value);
    } catch {
      return false;
    }
  });
}

function isIPv4(value: string): boolean {
  // Simple IPv4 pattern: 4 groups of 1-3 digits, each 0-255
  const ipv4Pattern = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  return ipv4Pattern.test(value);
}
