export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Remove leading/trailing whitespace
  const email = value.trim();
  
  // Basic structure check
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  
  if (!emailRegex.test(email)) {
    return false;
  }
  
  // Check for double dots
  if (email.includes('..')) {
    return false;
  }
  
  // Check for trailing dot in domain
  if (/\.[\s]*$/.test(email)) {
    return false;
  }
  
  // Check for underscores in domain
  if (/@[^@]*\.[^@]*_/.test(email)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const phone = value.trim();
  
  // Check for extensions
  const extMatch = phone.match(/ext.?\s*(\d+)/i) || phone.match(/x\s*(\d+)/i);
  if (options?.allowExtensions && extMatch) {
    return false; // Don't allow extensions for now
  }
  
  // Remove common separators and spaces
  const digitsOnly = phone.replace(/[\s-.]/g, '');
  
  // Check length (10 digits for US numbers)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) {
    return false;
  }
  
  // Handle optional +1
  if (digitsOnly.length === 11) {
    if (!digitsOnly.startsWith('1')) {
      return false;
    }
  }
  
  // Extract area code (first 3 digits)
  const areaCode = digitsOnly.slice(-10, -7);
  
  // Check that area code doesn't start with 0 or 1
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Format validation
  const phonePatterns = [
    /^\+?1?[\s-.]?\(?[2-9]\d{2}\)?[\s-.]?\d{3}[\s-.]?\d{4}$/,
    /^\+?1[\s-.]?[2-9]\d{2}[\s-.]?\d{3}[\s-.]?\d{4}$/
  ];
  
  return phonePatterns.some(pattern => pattern.test(phone));
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const phone = value.replace(/[\s-]/g, '');
  
  // Pattern for different formats:
  // 1. +54 9 11 1234 5678 (mobile with country code and mobile indicator)
  // 2. +54 341 123 4567 (landline with country code)
  // 3. 011 1234 5678 (landline without country code)
  // 4. 0341 4234567 (landline without country code)
  
  const patterns = [
    // Mobile with country code +54 and mobile indicator 9
    /^\+549[1-9]\d{8}$/, // +54 9 11 1234 5678 -> +54911 12345678 (9 total digits)
    
    // Landline with country code +54
    /^\+54[1-9]\d{2,4}\d{6}$/, // +54 341 123 4567 -> +549341 1234567 (8-10 total digits)
    
    // Landline Buenos Aires area code
    /^011\d{7}$/,   // 011 1234 5678 -> 0111234567 (10 digits)
    
    // Landline other area codes (starting with 0 trunk prefix)
    /^0[1-9]\d{2,4}\d{6}$/   // 0341 4234567 -> 0341 4234567 (9-11 total digits)
  ];
  
  // Check if matches any valid pattern
  const isValidFormat = patterns.some(pattern => pattern.test(phone));
  
  if (!isValidFormat) {
    return false;
  }
  
  // Additional validation for minimum length and area code structure
  if (phone.length < 10 || phone.length > 15) {
    return false;
  }
  
  // Check that it's not all the same digit
  if (/^(\d)\1+$/.test(phone)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Remove leading/trailing whitespace
  const name = value.trim();
  
  // Empty name check
  if (name.length === 0) {
    return false;
  }
  
  // Pattern for valid names:
  // - Unicode letters (including accented characters)
  // - Apostrophes and hyphens
  // - Spaces between names
  // - Cannot contain digits or symbols except allowed ones
  const namePattern = /^[A-Za-zÀ-ÖØ-öø-ÿ'-]+(?:\s+[A-Za-zÀ-ÖØ-öø-ÿ'-]+)*$/;
  
  // Additional check for the specific invalid name pattern
  if (/^X\s*Æ\s*A-12$/i.test(name)) {
    return false;
  }
  
  // Check that it doesn't contain digits
  if (/\d/.test(name)) {
    return false;
  }
  
  return namePattern.test(name);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check length (should be 13-19 digits for most cards)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check prefix patterns for different card types
  const cardPatterns = [
    /^4\d{12}(\d{3})?$/,        // Visa (13, 16, or 19 digits)
    /^3[47]\d{13}$/,            // American Express (15 digits)
    /^5[1-5]\d{14}$/,           // Mastercard (16 digits)
    /^2(2[2-9]\d|[3-6]\d{2}|7([01]\d|20))\d{12}$/, // Mastercard 2221-2720
    /^6(?:011|5\d{2})\d{12}$/,  // Discover
    /^35(2[89]|[3-8]\d)\d{12,13}$/ // JCB
  ];
  
  // Check if matches any valid card pattern
  const isValidCardType = cardPatterns.some(pattern => pattern.test(digits));
  
  if (!isValidCardType) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  return runLuhnCheck(digits);
}

function runLuhnCheck(digits: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits.charAt(i), 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  // Return true if sum is divisible by 10
  return sum % 10 === 0;
}
