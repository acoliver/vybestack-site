export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation with regex
  // Pattern breakdown:
  // - Local part: alphanumeric, dots, underscores, plus signs, hyphens
  // - @ symbol required
  // - Domain part: subdomains, domain, TLD with 2+ chars
  // - Reject double dots, trailing dots, underscores in domains
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if we have exactly 10 digits (without country code) or 11 digits (with +1)
  if (digits.length === 10) {
    // No country code, area code cannot start with 0 or 1
    const areaCode = digits.substring(0, 3);
    return /^[2-9][0-9][0-9]$/.test(areaCode);
  } else if (digits.length === 11 && digits.startsWith('1')) {
    // With country code +1, area code cannot start with 0 or 1
    const areaCode = digits.substring(1, 4);
    return /^[2-9][0-9][0-9]$/.test(areaCode);
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit, non-space, non-hyphen characters but keep the structure
  const clean = value.replace(/[^\d\s-]/g, ' ').replace(/\s+/g, ' ').trim();
  
  const digits = clean.replace(/\D/g, '');
  
  // Must have 8-12 digits for valid Argentine phone numbers
  if (digits.length < 8 || digits.length > 12) {
    return false;
  }
  
  // Split into parts to analyze structure
  const parts = clean.split(/\s+/);
  
  // Handle various valid formats:
  // "+54 341 123 4567" -> ["54", "341", "123", "4567"]
  // "011 1234 5678" -> ["11", "1234", "5678"] 
  // "+54 9 11 1234 5678" -> ["54", "9", "11", "1234", "5678"]
  
  if (parts.length < 3) return false;
  
  // Pattern 1: Country code + Area + Subscriber (4+ parts)
  if (parts.length >= 4) {
    const country = parseInt(parts[0]);
    const area = parts[1];
    const subscriber = parts.slice(2).join('');
    
    if (parts[0] === '+54' || country === 54) {
      // Valid country code
      if (/^\d{3,4}$/.test(area) && /^\d{4,8}$/.test(subscriber)) {
        return true;
      }
    }
  }
  
  // Pattern 2: Area + Subscriber (3 parts)
  if (parts.length === 3) {
    const area = parts[0];
    const subscriber = parts[1] + parts[2];
    
    // Could be international (54) or national (0, 9)
    if ((/^\d{3,4}$/.test(area) && /^\d{6,8}$/.test(subscriber)) ||
        (/^(0|9)\d{1,3}$/.test(parts[0]) && /^\d{6,8}$/.test(parts[1] + parts[2]))) {
      return true;
    }
  }
  
  // Pattern 3: Direct area code + subscriber number
  if (parts.length === 2) {
    const area = parts[0];
    const subscriber = parts[1];
    if (/^\d{2,4}$/.test(area) && /^\d{6,8}$/.test(subscriber)) {
      return true;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name should contain at least one letter and can contain:
  // - Unicode letters (with accents)
  // - Apostrophes and hyphens 
  // - Spaces
  // But no digits or special symbols
  
  // Pattern explanation:
  // - ^(?=.*[\p{L}]) - must contain at least one unicode letter
  // - [\p{L}\s'-]* - followed by letters, spaces, apostrophes, or hyphens
  // - [\p{L}] - must end with a letter
  // - $ - end of string
  const nameRegex = /^(?=.*[\p{L}])[\p{L}\s'-]*[\p{L}]$/u;
  
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit cards with proper prefixes and lengths, plus Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const clean = value.replace(/\D/g, '');
  
  // Check if the number has a valid length (13-19 digits for most cards)
  if (clean.length < 13 || clean.length > 19) {
    return false;
  }
  
  // Check for valid card prefixes
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  // American Express: starts with 34 or 37, length 15
  const isVisa = /^4/.test(clean) && [13, 16, 19].includes(clean.length);
  const isMastercard = /^(5[1-5]|222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)/.test(clean) && clean.length === 16;
  const isAmex = /^(34|37)/.test(clean) && clean.length === 15;
  
  if (!isVisa && !isMastercard && !isAmex) {
    return false;
  }
  
  // Apply Luhn checksum algorithm
  return isValidLuhnChecksum(clean);
}

/**
 * Helper function to validate Luhn checksum
 */
function isValidLuhnChecksum(number: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = number.length - 1; i >= 0; i--) {
    let digit = parseInt(number.charAt(i));
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
