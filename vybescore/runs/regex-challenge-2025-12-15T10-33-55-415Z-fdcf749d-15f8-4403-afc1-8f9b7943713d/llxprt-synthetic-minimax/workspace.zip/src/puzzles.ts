/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a word boundary pattern to find words starting with prefix
  const wordRegex = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out the exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit and not at string start
  const regex = new RegExp(`\\d[^\\d]*?${token}`, 'gi');
  
  const matches = text.match(regex) || [];
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // No immediate repeated sequences (like "abab")
  // This checks for any pattern that repeats immediately
  for (let i = 0; i < value.length - 2; i++) {
    const seq = value.substring(i, i + 2);
    if (value.indexOf(seq, i + 2) === i + 2) {
      // Found immediate repetition
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns:
  // 1. Full IPv6: groups of hex digits separated by colons
  // 2. Shortened IPv6 with :: compression
  // 3. IPv4-mapped IPv6 (::ffff:x.x.x.x)
  
  // Pattern to match IPv6 but NOT pure IPv4
  // This excludes patterns that are just IPv4 (dotted decimal with dots)
  const ipv6Patterns = [
    // Pattern with :: compression
    /^.*::.*$/,
    // Standard IPv6 with colons and hex digits
    /^([0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}$/,
    // IPv4-mapped IPv6
    /^::(ffff:)?(\d{1,3}\.){3}\d{1,3}$/,
    // IPv6 starting with common patterns
    /^(2001:|fc00:|fe80:|::1)/i
  ];
  
  // First check if it contains any IPv6-like patterns
  const hasIPv6Pattern = ipv6Patterns.some(pattern => pattern.test(value));
  
  // But exclude pure IPv4 addresses
  const isPureIPv4 = /^(\d{1,3}\.){3}\d{1,3}$/.test(value);
  
  return hasIPv6Pattern && !isPureIPv4;
}