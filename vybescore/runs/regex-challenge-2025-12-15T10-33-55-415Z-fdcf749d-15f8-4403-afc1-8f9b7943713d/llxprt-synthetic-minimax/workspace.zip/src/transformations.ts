/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to find sentence boundaries: . ? ! followed by spaces
  // Capitalize the letter after sentence endings
  return text.replace(/\s+/g, ' ').replace(/([.!?]\s+)([a-z])/g, (match, sentenceEnd, letter) => {
    return sentenceEnd + letter.toUpperCase();
  }).replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern that matches common URL formats
  // - http:// or https://
  // - Domain with optional www.
  // - Path and query parameters
  // - Remove trailing punctuation like ., !, ?, comma
  const urlRegex = /\bhttps?:\/\/[^\s<>{}[\]()"'`!,;?]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?:;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but only if https:// doesn't already exist
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs and capture the host and path
  const urlRegex = /http:\/\/([^/\s]+)(\/[^\s]*)?/g;
  
  return text.replace(urlRegex, (match, host, path = '') => {
    const newPath = path;
    
    // Check if path contains dynamic hints that should prevent host rewriting
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (newPath.startsWith('/docs/') && !hasDynamicHints) {
      // Extract the domain part (e.g., example.com from example.com)
      const domain = host.replace(/^www\./, ''); // Remove www if present
      const newHost = `docs.${domain}`;
      return `https://${newHost}${newPath}`;
    } else {
      // Just upgrade to https://
      return `https://${host}${newPath}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const year = parseInt(match[3]);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, with basic month validation)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (reasonable range)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  return year.toString();
}