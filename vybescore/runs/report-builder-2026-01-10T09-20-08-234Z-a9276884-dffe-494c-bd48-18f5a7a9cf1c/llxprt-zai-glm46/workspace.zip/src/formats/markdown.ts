/**
 * Markdown formatter for reports.
 */

import type { Formatter, ReportData, RenderOptions } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

/**
 * Render a report in Markdown format.
 */
export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries heading
  lines.push('## Entries');

  // Entries list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push('');
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
}

/**
 * Markdown formatter implementation.
 */
export const markdownFormatter: Formatter = {
  render: renderMarkdown,
};
