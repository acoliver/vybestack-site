#!/usr/bin/env node

/**
 * Report Builder CLI
 *
 * Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
 */

import * as fs from 'node:fs';
import * as path from 'node:path';

import type { RenderOptions, ReportData } from '../types.js';
import { getFormatter } from '../formats/index.js';
import { validateReportData } from '../utils.js';

interface CliArgs {
  inputPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command-line arguments.
 * Uses Node's standard library (no third-party parsers).
 */
function parseArgs(args: string[]): CliArgs {
  if (args.length < 2) {
    throw new Error(
      'Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
  }

  const inputPath = args[0];
  const formatFlagIndex = args.indexOf('--format');

  if (formatFlagIndex === -1 || formatFlagIndex + 1 >= args.length) {
    throw new Error('Missing required argument: --format <format>');
  }

  const format = args[formatFlagIndex + 1];

  const outputFlagIndex = args.indexOf('--output');
  const outputPath =
    outputFlagIndex !== -1 && outputFlagIndex + 1 < args.length
      ? args[outputFlagIndex + 1]
      : undefined;

  const includeTotals = args.includes('--includeTotals');

  return {
    inputPath,
    format,
    outputPath,
    includeTotals,
  };
}

/**
 * Read and parse JSON input file.
 */
function readInputFile(filePath: string): unknown {
  try {
    const absolutePath = path.resolve(filePath);
    const content = fs.readFileSync(absolutePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file "${filePath}": ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: "${filePath}"`);
    }
    throw error;
  }
}

/**
 * Write output to a file.
 */
function writeOutputFile(filePath: string, content: string): void {
  try {
    const absolutePath = path.resolve(filePath);
    const dir = path.dirname(absolutePath);
    fs.mkdirSync(dir, { recursive: true });
    fs.writeFileSync(absolutePath, content, 'utf-8');
  } catch (error) {
    throw new Error(`Failed to write to file "${filePath}": ${error instanceof Error ? error.message : String(error)}`);
  }
}

/**
 * Main entry point.
 */
function main(): void {
  try {
    const args = parseArgs(process.argv.slice(2));

    // Read and parse input file
    const rawData = readInputFile(args.inputPath);

    // Validate report data
    const validationError = validateReportData(rawData);
    if (validationError) {
      console.error(validationError);
      process.exit(1);
    }

    const data = rawData as ReportData;

    // Get the appropriate formatter
    const formatter = getFormatter(args.format);

    // Render the report
    const options: RenderOptions = {
      includeTotals: args.includeTotals,
    };

    const output = formatter.render(data, options);

    // Write output
    if (args.outputPath) {
      writeOutputFile(args.outputPath, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
