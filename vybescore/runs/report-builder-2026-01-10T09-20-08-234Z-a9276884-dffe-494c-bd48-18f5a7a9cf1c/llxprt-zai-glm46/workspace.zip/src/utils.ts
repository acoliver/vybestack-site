/**
 * Utility functions for the report builder CLI.
 */

import type { ReportEntry } from './types.js';

/**
 * Format an amount with two decimal places and a dollar sign.
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate the total of all entry amounts.
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Validate report data and return a helpful error message if invalid.
 */
export function validateReportData(data: unknown): string | null {
  if (!data || typeof data !== 'object') {
    return 'Invalid JSON: expected an object';
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    return 'Invalid report data: missing or invalid "title" field (expected string)';
  }

  if (typeof obj.summary !== 'string') {
    return 'Invalid report data: missing or invalid "summary" field (expected string)';
  }

  if (!Array.isArray(obj.entries)) {
    return 'Invalid report data: missing or invalid "entries" field (expected array)';
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      return `Invalid report data: entry at index ${i} is not an object`;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      return `Invalid report data: entry at index ${i} has missing or invalid "label" field (expected string)`;
    }

    if (typeof entryObj.amount !== 'number') {
      return `Invalid report data: entry at index ${i} has missing or invalid "amount" field (expected number)`;
    }
  }

  return null;
}
