// Use dynamic import for sql.js due to WASM module issues
const initSqlJs = import('sql.js');
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { dirname } from 'path';
import { FormSubmission } from '../interfaces/form-submission.js';

interface Database {
  run(sql: string, ...params: unknown[]): void;
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  step(): boolean;
  getAsObject(): Record<string, unknown>;
  free(): void;
}



export class DatabaseService {
 private db: Database | null = null;
 private dbPath = './data/submissions.sqlite';

async initialize(): Promise<void> {
  try {
   const sqljsModule = await initSqlJs;
   const SQL = await sqljsModule.default({ locateFile: (file: string) => `node_modules/sql.js/dist/${file}` });

   let dbBuffer: Uint8Array;

   if (existsSync(this.dbPath)) {
    const fileContents = readFileSync(this.dbPath);
    dbBuffer = new Uint8Array(fileContents);
    this.db = new (SQL as any).Database(dbBuffer);
    console.log('Database loaded from file');
   } else {
    this.db = new (SQL as any).Database();
    await this.createSchema();
    await this.save();
   }
  } catch (error) {
   console.error('Failed to initialize database:', error);
   throw error;
  }
 }

 async createSchema(): Promise<void> {
  if (!this.db) {
   throw new Error('Database not initialized');
  }

  const schema = readFileSync('./db/schema.sql', 'utf8');
  
  try {
   this.db.exec(schema);
   console.log('Database schema created successfully');
  } catch (error) {
   console.error('Error creating schemas:', error);
   throw error;
  }
 }

 async insertSubmission(submission: FormSubmission): Promise<void> {
  if (!this.db) {
   throw new Error('Database not initialized');
  }

  try {
   const stmt = this.db.prepare(`
    INSERT INTO submissions (
     first_name, last_name, street_address, city, 
     state_province, postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
   `);

   stmt.run([
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvince,
    submission.postalCode,
    submission.country,
    submission.email,
    submission.phone
   ]);

   stmt.free();
  } catch (error) {
   console.error('Error inserting submission:', error);
   throw error;
  }
 }

 async getAllSubmissions(): Promise<Record<string, unknown>[]> {
  if (!this.db) {
   throw new Error('Database not initialized');
  }

  try {
   const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
   const results: Record<string, unknown>[] = [];
   
   while (stmt.step()) {
    results.push(stmt.getAsObject());
   }
   
   stmt.free();
   return results;
  } catch (error) {
   console.error('Error retrieving submissions:', error);
   return [];
  }
 }

 async save(): Promise<void> {
  if (!this.db) {
   throw new Error('Database not initialized');
  }

  try {
   const data = this.db.export();
   
   const dataDir = dirname(this.dbPath);
   if (!existsSync(dataDir)) {
    mkdirSync(dataDir, { recursive: true });
   }

   writeFileSync(this.dbPath, Buffer.from(data));
  } catch (error) {
   console.error('Error saving database:', error);
   throw error;
  }
 }

 close(): void {
  if (this.db) {
   this.db.close();
   this.db = null;
  }
 }
}