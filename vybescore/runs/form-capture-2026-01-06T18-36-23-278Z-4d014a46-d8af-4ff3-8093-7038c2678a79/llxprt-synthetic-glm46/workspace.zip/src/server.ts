import express from 'express';
import { FormSubmission } from './interfaces/form-submission.js';
import { FormValidator } from './validators/form-validator.js';
import { DatabaseService } from './services/database-service.js';

const app = express();
const port = process.env.PORT || 3535;
const dbService = new DatabaseService();

app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static('public'));

app.set('view engine', 'ejs');
app.set('views', 'src/templates');

async function initializeServer(): Promise<void> {
 try {
  await dbService.initialize();
  console.log('Database initialized successfully');
  startServer();
 } catch (error) {
  console.error('Failed to initialize server:', error);
  process.exit(1);
 }
}

function startServer(): void {
 app.listen(port, () => {
  console.log(`Server running on http://localhost:${port}`);
 });
}

function renderForm(req: express.Request, res: express.Response, errors?: string[], values?: Partial<FormSubmission>): void {
 res.render('form', {
  errors: errors || [],
  values: values || {},
 });
}

function renderThankYou(req: express.Request, res: express.Response, firstName: string): void {
 res.render('thank-you', { firstName });
}

app.get('/', (req: express.Request, res: express.Response) => {
 renderForm(req, res);
});

app.post('/submit', async (req: express.Request, res: express.Response) => {
 try {
  const submission: FormSubmission = {
   firstName: req.body.firstName,
   lastName: req.body.lastName,
   streetAddress: req.body.streetAddress,
   city: req.body.city,
   stateProvince: req.body.stateProvince,
   postalCode: req.body.postalCode,
   country: req.body.country,
   email: req.body.email,
   phone: req.body.phone,
  };

  const validationErrors = FormValidator.validate(submission);
  
  if (validationErrors.length > 0) {
   const errorMessages = validationErrors.map(error => error.message);
   renderForm(req, res, errorMessages, submission);
   return;
  }

  await dbService.insertSubmission(submission);
  await dbService.save();
  
  res.redirect('/thank-you');
 } catch (error) {
  console.error('Error during form submission:', error);
  renderForm(req, res, ['An unexpected error occurred. Please try again.'], req.body);
 }
});

app.get('/thank-you', async (req: express.Request, res: express.Response) => {
 const firstName = 'Friend';
 const submissions = await dbService.getAllSubmissions();
 const firstNameFromLastSubmission = submissions.length > 0 && submissions[0]?.first_name ? String(submissions[0].first_name) : firstName;
 renderThankYou(req, res, firstNameFromLastSubmission);
});

function gracefulShutdown(): void {
 console.log('Shutting down gracefully...');
 dbService.close();
 process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

initializeServer().catch(console.error);
