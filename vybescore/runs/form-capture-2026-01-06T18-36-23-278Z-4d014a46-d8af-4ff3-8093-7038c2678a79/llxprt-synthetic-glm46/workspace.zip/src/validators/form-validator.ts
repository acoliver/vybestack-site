import { FormSubmission, ValidationError } from '../interfaces/form-submission.js';

export class FormValidator {
 static validate(data: FormSubmission): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName || data.firstName.trim().length < 1) {
   errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!data.lastName || data.lastName.trim().length < 1) {
   errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!data.streetAddress || data.streetAddress.trim().length < 1) {
   errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!data.city || data.city.trim().length < 1) {
   errors.push({ field: 'city', message: 'City is required' });
  }

  if (!data.stateProvince || data.stateProvince.trim().length < 1) {
   errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }

  if (!data.postalCode || data.postalCode.trim().length < 1) {
   errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  }

  if (!data.country || data.country.trim().length < 1) {
   errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!data.email || data.email.trim().length < 1) {
   errors.push({ field: 'email', message: 'Email is required' });
  } else if (!this.isValidEmail(data.email)) {
   errors.push({ field: 'email', message: 'Email is not valid' });
  }

  if (!data.phone || data.phone.trim().length < 1) {
   errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!this.isValidPhone(data.phone)) {
   errors.push({ field: 'phone', message: 'Phone number format is invalid' });
  }

  return errors;
 }

 private static isValidEmail(email: string): boolean {
  const emailRegex = /^[\w.-]+@[\w.-]+\.[a-zA-Z]{2,}$/;
  return emailRegex.test(email);
 }

 private static isValidPhone(phone: string): boolean {
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
 }
}