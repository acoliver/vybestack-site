/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  setActiveObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  let cachedValue = value
  
  // Create a subject-like structure to manage observers of this computed value
  const computedSubject = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value: cachedValue,
    equalFn: typeof _equal === 'function' ? _equal : undefined
  }
  
  const observer: Observer<T> = {
    name: options?.name,
    dependents: new Set(),
    value: cachedValue,
    updateFn: (previousValue) => {
      // Set this observer as active so dependencies can track it
      setActiveObserver(observer)
      try {
        // Re-compute the value and cache it
        const computedValue = updateFn(previousValue)
        cachedValue = computedValue
        computedSubject.value = computedValue
        observer.value = computedValue
        return computedValue
      } finally {
        setActiveObserver(undefined)
      }
    }
  }
  
  const getter: GetterFn<T> = () => {
    const previousValue = observer.value
    
    // Track this computed value as an observer of any dependencies it reads
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add this observer to the set of active observer's dependents
      activeObserver.dependents.add(observer)
      // Add active observer to this computed value's observers
      computedSubject.observers.add(activeObserver)
    }
    
    // Force re-computation to capture dependencies and get latest value
    updateObserver(observer)
    
    // If value changed, notify all observers that depend on this computed value
    if (observer.value !== previousValue) {
      for (const dependentObserver of computedSubject.observers) {
        if ('updateFn' in dependentObserver && dependentObserver.updateFn) {
          updateObserver(dependentObserver as Observer<unknown>)
        } else if ('getter' in dependentObserver && typeof dependentObserver.getter === 'function') {
          // For callbacks with getters, call the getter to re-establish dependencies
          dependentObserver.getter()
        }
      }
    }
    
    return observer.value!
  }
  
  return getter
}
