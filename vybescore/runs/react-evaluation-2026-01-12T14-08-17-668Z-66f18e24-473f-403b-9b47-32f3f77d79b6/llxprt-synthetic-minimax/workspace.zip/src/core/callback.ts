/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    dependents: new Set(),
    updateFn: (currentValue) => {
      if (disposed) return currentValue!
      
      // Execute the callback function to perform side effects
      // and establish new dependencies
      const result = updateFn(currentValue)
      observer.value = result
      
      return result
    }
  }
  
  // Execute immediately to establish initial dependencies
  updateObserver(observer)
  
  // Create a getter that establishes dependencies and executes the callback
  const callbackGetter = () => {
    if (disposed) return observer.value!
    
    setActiveObserver(observer)
    try {
      const result = updateFn(observer.value)
      observer.value = result
      return result
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Store the getter so dependencies can call it
  observer.getter = callbackGetter
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear update function to stop future updates
    observer.updateFn = () => observer.value!
  }
}
