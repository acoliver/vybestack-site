export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email pattern that allows typical formats like name+tag@example.co.uk
  // Rejects double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific invalid patterns
  if (value.includes('..') || value.endsWith('.') || value.includes('@_') || value.includes('_@')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Handle optional +1 prefix
  const phoneRegex = /^\+?1?(\d{10})$/;
  const match = cleaned.match(phoneRegex);
  
  if (!match) {
    return false;
  }
  
  const digits = match[1];
  
  // Check that area code doesn't start with 0 or 1
  const areaCode = digits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and other punctuation except digits and +
  const cleaned = value.replace(/[\s\-().]/g, '');
  
  // Pattern for Argentine phone numbers
  // Optional +54 followed by optional 9 (mobile indicator)
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits total
  
  const phoneRegex = /^(\+54)?9?(\d{2,4})(\d{6,8})$/;
  const match = cleaned.match(phoneRegex);
  
  if (!match) {
    // Check for format with trunk prefix 0 (no country code)
    const trunkRegex = /^0(\d{2,4})(\d{6,8})$/;
    return trunkRegex.test(cleaned);
  }
  
  const [, countryCode] = match;
  
  // When no country code, must have mobile indicator 9 or trunk prefix handled above
  if (!countryCode && !cleaned.startsWith('9')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits and symbols
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter and not be just whitespace/punctuation
  if (!/\p{L}/u.test(value) || /^[^\p{L}]*$/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for validating credit card numbers
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let alternate = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (alternate) {
      digit *= 2;
      if (digit > 9) {
        digit = (digit % 10) + 1;
      }
    }
    
    sum += digit;
    alternate = !alternate;
  }
  
  return (sum % 10) === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length and prefix patterns for different card types
  // Visa: starts with 4, length 13, 16, or 19
  // Mastercard: starts with 51-55, length 16
  // American Express: starts with 34 or 37, length 15
  
  const isVisa = /^4(\d{12}|\d{15}|\d{18})$/.test(cleaned);
  const isMastercard = /^5[1-5]\d{14}$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}