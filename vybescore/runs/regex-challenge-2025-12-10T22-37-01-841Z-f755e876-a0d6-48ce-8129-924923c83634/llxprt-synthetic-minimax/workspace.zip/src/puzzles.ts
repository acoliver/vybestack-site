/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex to find words starting with the prefix
  const regex = new RegExp(`\\b${prefix}[\\w]*\\b`, 'gi');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions (case insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  return matches.filter(match => 
    !exceptionsLower.includes(match.toLowerCase())
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find token that appears after a digit and not at the start of string
  // We need to return the digit + token, not just the token
  const regex = new RegExp(`(?<!^)(?<=\\d)${token}`, 'gi');
  
  const matches = [];
  let match;
  
  // Use exec in a loop to get all matches
  while ((match = regex.exec(text)) !== null) {
    const tokenStart = match.index;
    const tokenEnd = tokenStart + match[0].length;
    
    // Find the preceding digit
    let digitStart = tokenStart - 1;
    while (digitStart >= 0 && /\d/.test(text[digitStart])) {
      digitStart--;
    }
    digitStart++;
    
    if (digitStart < tokenStart) {
      // Include the digit with the token
      const fullMatch = text.slice(digitStart, tokenEnd);
      matches.push(fullMatch);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check character requirements
  const hasUpper = /[A-Z]/.test(value);
  const hasLower = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9\s]/.test(value);
  
  if (!hasUpper || !hasLower || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., "abab" should fail)
  // This checks for any sequence of 4 characters that repeats immediately
  for (let i = 0; i <= value.length - 4; i++) {
    const sequence = value.slice(i, i + 4);
    if (sequence.length === 4 && value.slice(i + 4, i + 8) === sequence) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 addresses contain colons and can have :: shorthand
  // We need to match IPv6 patterns while excluding pure IPv4
  
  // Check for IPv6 patterns
  // IPv6 can have :: shorthand, hex digits, and contains colons
  const ipv6Patterns = [
    // Full IPv6 with 8 groups of 4 hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // IPv6 with :: shorthand (various positions)
    /\b(?:[0-9a-fA-F]{1,4}:)*(?:[0-9a-fA-F]{1,4})?(?:::[0-9a-fA-F]{1,4})?(?::[0-9a-fA-F]{1,4})*\b/,
    // IPv4-mapped IPv6
    /\b::ffff:(?:\d{1,3}\.){3}\d{1,3}\b/,
    // IPv4-compatible IPv6
    /\b(?:[0-9a-fA-F]{1,4}:){6}(?:\d{1,3}\.){3}\d{1,3}\b/,
    // General IPv6 with :: (more flexible)
    /\b[0-9a-fA-F]*::[0-9a-fA-F:]+\b/
  ];
  
  // Check if any IPv6 pattern matches
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      // Verify it's not just an IPv4 address
      const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
      if (ipv4Pattern.test(value) && !value.includes(':')) {
        // It's pure IPv4, not IPv6
        continue;
      }
      return true;
    }
  }
  
  return false;
}