/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  return text
    .replace(/([.!?])([^\s])/g, '$1 $2')
    .replace(/(^|[.!?]\s+)([a-z])/g, (match, p1, p2) => {
      return p1 + p2.toUpperCase();
    })
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Find URLs in the text without trailing punctuation
  const urlRegex = /\bhttps?:\/\/[^\s)\]}>"']*[^\s)\]}>"'>.,!?]/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite docs URLs according to the specific rules described in problem.md.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/]+)(\/docs\/[^\s]*)/g, (match, host, path) => {
    // Check if path contains dynamic hints or legacy extensions
    const hasDynamicHints = /[?&]|(cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    if (hasDynamicHints) {
      // Just upgrade to https without changing host
      return `https://${host}${path}`;
    } else {
      // Change host to docs.domain.com
      return `https://docs.${host}${path}`;
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy format, return N/A for invalid inputs.
 */
export function extractYear(value: string): string {
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}