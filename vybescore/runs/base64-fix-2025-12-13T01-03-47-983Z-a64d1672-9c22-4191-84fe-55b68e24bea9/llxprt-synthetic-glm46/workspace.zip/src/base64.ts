/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validates if a string is proper Base64 format.
 */
function isValidBase64(input: string): boolean {
  // Base64 alphabet characters + padding
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check overall format
  if (!base64Regex.test(input)) {
    return false;
  }
  
  // Check padding constraints
  const paddingCount = (input.match(/=/g) || []).length;
  if (paddingCount > 2) {
    return false;
  }
  
  // If there's padding, it must be at the end
  if (paddingCount > 0) {
    const paddingIndex = input.indexOf('=');
    const paddingSegment = input.substring(paddingIndex);
    
    // All padding characters must be at the end
    if (!/^[=]+$/.test(paddingSegment)) {
      return false;
    }
    
    // Cannot have stray padding characters not at the end
    const mainContent = input.substring(0, paddingIndex);
    if (mainContent.includes('=')) {
      return false;
    }
  }
  
  // Try to decode to check if it's actually valid Base64
  try {
    Buffer.from(input, 'base64').toString('utf8');
    
    // Additional validation: proper Base64 string when re-encoded should match the original
    const decoded = Buffer.from(input, 'base64');
    const reencoded = decoded.toString('base64');
    
    // If the original had no padding, allow that as valid (since Node allows it)
    if (paddingCount === 0) {
      const originalWithoutPadding = input;
      const reencodedWithoutPadding = reencoded.replace(/=+$/, '');
      return reencodedWithoutPadding === originalWithoutPadding;
    }
    
    // If original had padding, it must match exactly
    return input === reencoded;
  } catch {
    return false;
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }
  
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input');
  }
}
