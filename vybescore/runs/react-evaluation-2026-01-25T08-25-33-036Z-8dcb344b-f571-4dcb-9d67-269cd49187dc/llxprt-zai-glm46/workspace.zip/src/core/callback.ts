/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }

  // Track dependencies for this callback
  const dependencies = new Set<Observer<unknown>>()
  ;(observer as unknown as { dependencies: Set<Observer<unknown>> }).dependencies = dependencies

  // Track if disposed
  let disposed = false
  ;(observer as unknown as { disposed: boolean }).disposed = false

  // Track all subjects that this callback observes
  const subjects = new Set<unknown>()
  ;(observer as unknown as { subjects: Set<unknown> }).subjects = subjects

  // Register observer to track dependencies and run initially
  updateObserver(observer as Observer<unknown>)

  return () => {
    if (disposed) return
    disposed = true
    ;(observer as unknown as { disposed: boolean }).disposed = true

    // Clear the observer to stop further updates
    observer.value = undefined
    ;(observer as unknown as { updateFn: () => T }).updateFn = () => value!

    // Remove this observer from all tracked subjects
    subjects.forEach(subject => {
      const subjectObservers = (subject as unknown as { observers: Set<Observer<unknown>> }).observers
      if (subjectObservers) {
        subjectObservers.delete(observer as Observer<unknown>)
      }
    })
    subjects.clear()

    // Clear dependencies
    dependencies.clear()
  }
}
