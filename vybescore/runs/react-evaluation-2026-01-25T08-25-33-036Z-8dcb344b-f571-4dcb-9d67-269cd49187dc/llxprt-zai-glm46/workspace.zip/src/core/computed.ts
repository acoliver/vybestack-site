/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }

  // Track dependent observers that depend on this computed
  const dependencies = new Set<Observer<unknown>>()
  ;(o as unknown as { dependencies: Set<Observer<unknown>> }).dependencies = dependencies

  // Track all subjects (inputs and other computeds) that this computed observes
  const subjects = new Set<unknown>()
  ;(o as unknown as { subjects: Set<unknown> }).subjects = subjects

  // Track if this computed is also a subject (has observers depending on it)
  const observers = new Set<Observer<unknown>>()
  ;(o as unknown as { observers: Set<Observer<unknown>> }).observers = observers

  // Track if disposed
  ;(o as unknown as { disposed?: boolean }).disposed = false

  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this computed as a dependency of the active observer
      // This means the active observer depends on this computed
      const observerDeps = (observer as unknown as { dependencies: Set<Observer<unknown>> }).dependencies
      if (observerDeps) {
        observerDeps.add(o as Observer<unknown>)
      }

      // Track this computed in the active observer's subjects set
      // This is used for cleanup when the observer is disposed
      const observerSubjects = (observer as unknown as { subjects: Set<unknown> }).subjects
      if (observerSubjects) {
        observerSubjects.add(o)
      }

      // Register the active observer as an observer of this computed
      observers.add(observer as Observer<unknown>)
    }
    return o.value!
  }

  // Initial computation
  updateObserver(o as Observer<unknown>)

  return getter
}
