/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer as Observer<unknown>)
      // Track subject in observer's subjects
      const subjects = (observer as unknown as { subjects: Set<unknown> }).subjects
      if (subjects) {
        subjects.add(s)
      }
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify all observers
    const observersArray = Array.from(s.observers)
    observersArray.forEach(observer => {
      const disposed = (observer as unknown as { disposed?: boolean }).disposed
      const isUpdating = (observer as unknown as { isUpdating?: boolean }).isUpdating
      if (!disposed && !isUpdating) {
        (observer as unknown as { isUpdating: boolean }).isUpdating = true
        try {
          updateObserver(observer as Observer<unknown>)
        } finally {
          (observer as unknown as { isUpdating: boolean }).isUpdating = false
        }
      }
    })
    return s.value
  }

  return [read, write]
}
