/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observers?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Check if disposed
  if ((observer as unknown as { disposed?: boolean }).disposed) {
    return
  }

  const previous = activeObserver
  activeObserver = observer
  try {
    // Clear previous subjects before recomputing
    const subjects = (observer as unknown as { subjects: Set<unknown> }).subjects
    const previousSubjects = subjects ? new Set(subjects) : new Set()
    
    if (subjects) {
      subjects.clear()
    }
    
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
    
    // Remove observer from old subjects that are no longer tracked
    previousSubjects.forEach(subject => {
      if (!subjects.has(subject)) {
        const subjectObservers = (subject as unknown as { observers: Set<ObserverR> }).observers
        if (subjectObservers) {
          subjectObservers.delete(observer as ObserverR)
        }
      }
    })
  } finally {
    activeObserver = previous
  }

  // After updating, propagate changes to dependent observers
  // Collect all dependent observers first
  const observerObservers = (observer as unknown as { observers: Set<ObserverR> }).observers as Set<ObserverR>
  if (observerObservers && observerObservers.size > 0) {
    const depsArray = Array.from(observerObservers)
    depsArray.forEach(dep => {
      const disposed = (dep as unknown as { disposed?: boolean }).disposed
      const isUpdating = (dep as unknown as { isUpdating?: boolean }).isUpdating
      if (!disposed && !isUpdating) {
        (dep as unknown as { isUpdating: boolean }).isUpdating = true
        try {
          updateObserver(dep as Observer<unknown>)
        } finally {
          (dep as unknown as { isUpdating: boolean }).isUpdating = false
        }
      }
    })
  }
}
