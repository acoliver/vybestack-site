import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate input parameters
    let page: number | undefined = undefined;
    let limit: number | undefined = undefined;

    if (pageParam !== undefined) {
      // Check if page is numeric
      if (isNaN(Number(pageParam))) {
        return res.status(400).json({ error: 'Page parameter must be a positive number' });
      }
      page = Number(pageParam);
      // Check if page is positive
      if (page <= 0) {
        return res.status(400).json({ error: 'Page parameter must be greater than 0' });
      }
    }

    if (limitParam !== undefined) {
      // Check if limit is numeric
      if (isNaN(Number(limitParam))) {
        return res.status(400).json({ error: 'Limit parameter must be a positive number' });
      }
      limit = Number(limitParam);
      // Check if limit is positive
      if (limit <= 0) {
        return res.status(400).json({ error: 'Limit parameter must be greater than 0' });
      }
      // Check if limit is excessive (set a reasonable max of 100)
      if (limit > 100) {
        return res.status(400).json({ error: 'Limit parameter must not exceed 100' });
      }
    }

    const payload = listInventory(db, { page, limit });
    res.json(payload);
  });

  return app;
}
