#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData, RenderOptions, ReportFormatter } from '../types.js';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';

/**
 * CLI arguments interface
 */
interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

/**
 * Parse command line arguments using Node's standard library
 */
function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const cliArgs: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };
  
  // Parse arguments
  let i = 0;
  while (i < args.length) {
    const arg = args[i];
    
    if (!arg.startsWith('-')) {
      // This must be the data file
      if (cliArgs.dataFile) {
        console.error('Error: Multiple data files specified');
        process.exit(1);
      }
      cliArgs.dataFile = arg;
    } else if (arg === '--format') {
      i++;
      if (i >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      cliArgs.format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      cliArgs.outputPath = args[i];
    } else if (arg === '--includeTotals') {
      cliArgs.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
    
    i++;
  }
  
  if (!cliArgs.dataFile) {
    console.error('Error: Data file is required');
    process.exit(1);
  }
  
  if (!cliArgs.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  return cliArgs;
}

/**
 * Validate and load report data from JSON file
 */
function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate the data structure
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }
    
    for (const entry of data.entries) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error('Entry missing or invalid "label" field');
      }
      
      if (typeof entry.amount !== 'number') {
        throw new Error('Entry missing or invalid "amount" field');
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Invalid JSON in file ${filePath}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: Failed to load file ${filePath}`);
    }
    process.exit(1);
  }
}

/**
 * Get formatter for specified format
 */
function getFormatter(format: string): ReportFormatter {
  switch (format.toLowerCase()) {
    case 'markdown':
      return new MarkdownFormatter();
    case 'text':
      return new TextFormatter();
    default:
      console.error(`Error: Unsupported format: ${format}`);
      process.exit(1);
  }
}

/**
 * Main CLI function
 */
function main(): void {
  const args = parseArgs();
  const data = loadReportData(args.dataFile);
  const formatter = getFormatter(args.format);
  
  const options: RenderOptions = {
    includeTotals: args.includeTotals
  };
  
  const output = formatter.render(data, options);
  
  if (args.outputPath) {
    try {
      writeFileSync(args.outputPath, output, 'utf-8');
      console.log(`Report written to ${args.outputPath}`);
    } catch (error) {
      console.error(`Error: Failed to write output file ${args.outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

// Run the CLI
main();
