import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import type { InventoryPage } from '../shared/types';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

interface ErrorResponse {
  error: string;
}

const MAX_LIMIT = 100;

function validatePaginationParams(pageParam: string | undefined, limitParam: string | undefined): { page: number; limit: number } | ErrorResponse {
  const page = pageParam ? Number(pageParam) : 1;
  const limit = limitParam ? Number(limitParam) : 5;

  // Validate page parameter
  if (pageParam && (isNaN(page) || page <= 0 || !Number.isInteger(page))) {
    return { error: 'Invalid page parameter: must be a positive integer' };
  }

  // Validate limit parameter
  if (limitParam && (isNaN(limit) || limit <= 0 || !Number.isInteger(limit) || limit > MAX_LIMIT)) {
    return { error: `Invalid limit parameter: must be a positive integer <= ${MAX_LIMIT}` };
  }

  return { page: page <= 0 ? 1 : page, limit: limit <= 0 ? 5 : limit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response<InventoryPage | ErrorResponse>) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const validation = validatePaginationParams(pageParam, limitParam);

    if ('error' in validation) {
      res.status(400).json(validation);
      return;
    }

    const payload = listInventory(db, { page: validation.page, limit: validation.limit });
    res.json(payload);
  });

  return app;
}
