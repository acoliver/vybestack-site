import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { Database } from 'sql.js';
import initSqlJs from 'sql.js';

// Export app for testing
export const app = express();



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}


const port = process.env.PORT || 3535;

let db: Database | null = null;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  
  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    
    let dbData: Uint8Array | null = null;
    
    // Load existing database if it exists
    if (fs.existsSync(dbPath)) {
      const dbFile = fs.readFileSync(dbPath);
      dbData = new Uint8Array(dbFile);
    }
    
    // Initialize database
    const SQL = await initSqlJs();
    if (dbData) {
      db = new SQL.Database(dbData);
    } else {
      db = new SQL.Database();
    }
    
    // Create schema if needed
    if (fs.existsSync(schemaPath)) {
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.run(schema);
    }
    
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    const data = db.export();
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateForm(data: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};
  
  // Required fields
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else {
    // Simple email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else {
    // Phone validation: digits, spaces, parentheses, dashes, leading +
    const phoneRegex = /^[+]?[0-9\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Routes
app.get('/', async (req: Request, res: Response) => {
  await initializeDatabase();
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  await initializeDatabase();
  
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    const errorMessages = Object.values(validation.errors);
    return res.render('form', {
      errors: errorMessages,
      values: formData
    });
  }
  
  try {
    // Insert into database
    const stmt = db!.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
    
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', async (req: Request, res: Response) => {
  await initializeDatabase();
  
  // Get the most recent submission for the name
  let firstName = 'Friend';
  try {
    const result = db!.exec('SELECT first_name FROM submissions ORDER BY created_at DESC LIMIT 1');
    if (result.length > 0 && result[0].values.length > 0) {
      firstName = result[0].values[0][0] as string;
    }
  } catch (error) {
    console.error('Failed to get recent submission:', error);
  }
  
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
    console.log('Database closed');
  }
  
  process.exit(0);
}

// Start server
async function startServer(): Promise<import('http').Server> {
  await initializeDatabase();
  
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle graceful shutdown
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
  
  return server;
}

// Only start server if this file is run directly (not imported)
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(console.error);
}
