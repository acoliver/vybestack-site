/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: { name?: string }
): GetterFn<T> {
  // Create an observer for this computed value
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Also create a subject so this computed can be observed by others
  const subject: Subject<T> = {
    name: options?.name,
    observers: [],
    value: value as T,
  }
  
  // Initial computation to establish dependencies and get initial value
  updateObserver(observer)
  
  // Store the computed value in the subject
  subject.value = observer.value as T
  
  // Return a getter that tracks dependencies and returns the cached value
  const getter: GetterFn<T> = (): T => {
    // If there's an active observer, register this subject as a dependency
    const activeObs = getActiveObserver()
    if (activeObs) {
      // Add this observer to the list if not already present
      if (!subject.observers.includes(activeObs)) {
        subject.observers.push(activeObs)
      }
    }
    
    // Return the current cached value
    return subject.value
  }
  
  // Monkey-patch the observer's updateFn to also update the subject and notify observers
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T): T => {
    // Recompute the value
    const newValue = originalUpdateFn(prevValue)
    subject.value = newValue
    
    // Notify all observers of this subject
    for (const obs of subject.observers) {
      updateObserver(obs as { value?: T; updateFn: (val?: T) => T; name?: string })
    }
    
    return newValue
  }
  
  return getter
}
