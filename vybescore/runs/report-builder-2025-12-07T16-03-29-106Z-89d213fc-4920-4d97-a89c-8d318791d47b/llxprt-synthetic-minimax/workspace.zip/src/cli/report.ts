import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, ReportFormat, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArguments(argv: string[]): {
  dataFile: string;
  format: ReportFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];

  const args = argv.slice(3);
  let format: ReportFormat | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1] as ReportFormat;
      i++; // Skip next argument as it's the format value
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[i + 1];
      i++; // Skip next argument as it's the output path value
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format: ${format}. Supported formats: markdown, text`);
    process.exit(1);
  }

  return { dataFile, format, outputPath, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (typeof data.title !== 'string') {
      throw new Error('Invalid data: title must be a string');
    }
    if (typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary must be a string');
    }
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries must be an array');
    }

    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${i}].label must be a string`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entries[${i}].amount must be a number`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error.message.startsWith('Unexpected token')) {
        console.error(`Error: Invalid JSON in file: ${filePath}`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Unknown error occurred');
    }
    process.exit(1);
  }
}

function main(): void {
  const { dataFile, format, outputPath, includeTotals } = parseArguments(process.argv);
  const reportData = loadReportData(dataFile);
  const options: RenderOptions = { includeTotals };

  let output: string;

  switch (format) {
    case 'markdown':
      output = renderMarkdown.render(reportData, options);
      break;
    case 'text':
      output = renderText.render(reportData, options);
      break;
    default:
      console.error(`Error: Unsupported format: ${format}`);
      process.exit(1);
  }

  if (outputPath) {
    try {
      writeFileSync(outputPath, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write to file: ${outputPath}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();