import initSqlJs, { Database } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

const SQL_PATH = require.resolve('sql.js/dist/sql-wasm.js');
const DATA_DIR = path.join(__dirname, '..', 'data');
const DB_FILE = path.join(DATA_DIR, 'submissions.sqlite');

export interface Submission {
  firstName: string;
  lastName: string;
  street: string;
  city: string;
  region: string;
  postalCode: string;
  country: string;
  email: string;
  phone?: string | null;
  submittedAt: string;
}

export interface ContactFormData {
  firstName: string;
  lastName: string;
  street: string;
  city: string;
  region: string;
  postalCode: string;
  country: string;
  email: string;
  phone?: string | null;
}

interface SqlJsModule {
  Database: unknown;
}

export class DatabaseHandler {
  private SQL: SqlJsModule | null = null;
  private db: Database | null = null;

  async initialize(): Promise<void> {
    try {
      const initResult = await initSqlJs({
        locateFile: (file: string) => {
          return path.join(path.dirname(SQL_PATH), file);
        }
      });
      this.SQL = initResult;

      // Ensure data directory exists
      if (!fs.existsSync(DATA_DIR)) {
        fs.mkdirSync(DATA_DIR, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(DB_FILE)) {
        const dbBuffer = fs.readFileSync(DB_FILE);
        this.db = new (this.SQL.Database as any)(dbBuffer);
      } else {
        this.db = new (this.SQL.Database as any)();
        this.createSchema();
      }

      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private createSchema(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    // Create submissions table
    this.db.run(`
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street TEXT NOT NULL,
        city TEXT NOT NULL,
        region TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT,
        submitted_at TEXT NOT NULL
      )
    `);

    console.log('Database schema created');
  }

  async saveSubmission(formData: ContactFormData): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street, city, region, 
        postal_code, country, email, phone, submitted_at
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    const submission: Submission = {
      firstName: formData.firstName.trim(),
      lastName: formData.lastName.trim(),
      street: formData.street.trim(),
      city: formData.city.trim(),
      region: formData.region.trim(),
      postalCode: formData.postalCode.trim(),
      country: formData.country.trim(),
      email: formData.email.trim(),
      phone: formData.phone ? formData.phone.trim() : null,
      submittedAt: new Date().toISOString()
    };

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.street,
      submission.city,
      submission.region,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone || null,
      submission.submittedAt
    ]);

    stmt.free();

    // Export database to file after each insert
    await this.exportToFile();

    return this.db.getRowsModified();
  }

  private async exportToFile(): Promise<void> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const dbBuffer = this.db.export();
    fs.writeFileSync(DB_FILE, Buffer.from(dbBuffer));
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
      console.log('Database connection closed');
    }
  }

  getAllSubmissions(): Submission[] {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY submitted_at DESC');
    const submissions: Submission[] = [];
    
    while (stmt.step()) {
      const row = stmt.getAsObject() as Record<string, unknown>;
      const submission: Submission = {
        firstName: String(row['first_name'] || ''),
        lastName: String(row['last_name'] || ''),
        street: String(row['street'] || ''),
        city: String(row['city'] || ''),
        region: String(row['region'] || ''),
        postalCode: String(row['postal_code'] || ''),
        country: String(row['country'] || ''),
        email: String(row['email'] || ''),
        phone: row['phone'] ? String(row['phone']) : null,
        submittedAt: String(row['submitted_at'] || '')
      };
      submissions.push(submission);
    }
    
    stmt.free();
    return submissions;
  }
}