import express, { Request, Response } from 'express';
import path from 'path';
import { DatabaseHandler } from './db';

const app = express();
const PORT = process.env['PORT'] ? parseInt(process.env['PORT']!) : 3535;

// Initialize database handler
const db = new DatabaseHandler();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Validation functions
interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
}

interface ContactFormData {
  firstName: string;
  lastName: string;
  street: string;
  city: string;
  region: string;
  postalCode: string;
  country: string;
  email: string;
  phone?: string;
}

function validateFormData(data: Record<string, string>): ValidationResult {
  const errors: Record<string, string> = {};

  // Required fields
  const requiredFields = ['firstName', 'lastName', 'street', 'city', 'region', 'postalCode', 'country', 'email'];
  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || value.toString().trim() === '') {
      errors[field] = `${field} is required`;
    }
  });

  // Email validation
  const email = data['email'];
  if (email && email.toString().trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email.toString())) {
      const field = 'email';
      errors[field] = 'Please enter a valid email address';
    }
  }

  // Phone validation (optional but format check if provided)
  const phone = data['phone'];
  if (phone && phone.toString().trim() !== '') {
    const phoneRegex = /^@?\d[\d\s\-()]*$/;
    if (!phoneRegex.test(phone.toString())) {
      const field = 'phone';
      errors[field] = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (allow alphanumeric)
  const postalCode = data['postalCode'];
  if (postalCode && postalCode.toString().trim() !== '') {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(postalCode.toString())) {
      const field = 'postalCode';
      errors[field] = 'Please enter a valid postal code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('contact', { 
    errors: {}, 
    formData: {},
    title: 'Contact Us - Friendly Form Capture'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const formData = req.body as Record<string, string>;
    const validation = validateFormData(formData);

    if (!validation.isValid) {
      // Validation failed - re-render form with errors
      return res.status(400).render('contact', {
        errors: validation.errors,
        formData: req.body,
        title: 'Contact Us - Please Fix Errors'
      });
    }

    // Validation passed - save to database
    await db.saveSubmission(req.body as ContactFormData);
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', { 
    title: 'Thank You - We promise not to spam you forever... probably'
  });
});

// Error handler
app.use((err: Error, _req: Request, res: Response) => {
  console.error(err);
  res.status(500).send('Oops! Something went wrong! :(');
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Shutting down gracefully...');
  await db.close();
  process.exit(0);
});

// Start server
const server = app.listen(PORT, async () => {
  await db.initialize();
  console.log(`Server running on port ${PORT}`);
});

export default server;