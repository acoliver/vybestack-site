const { spawn } = require('child_process');
const http = require('http');

// Helper function to make HTTP requests
function makeRequest(options, data = null) {
  return new Promise((resolve, reject) => {
    const req = http.request(options, (res) => {
      let body = '';
      res.on('data', (chunk) => {
        body += chunk;
      });
      res.on('end', () => {
        resolve({
          statusCode: res.statusCode,
          headers: res.headers,
          body: body
        });
      });
    });

    req.on('error', reject);

    if (data) {
      req.write(data);
    }
    req.end();
  });
}

// Test suite
async function runTests() {
  console.log('Starting public tests...\n');

  let serverProcess;
  let serverReady = false;

  try {
    // Start the server
    console.log('Starting server...');
    serverProcess = spawn('npm', ['run', 'build'], {
      stdio: 'pipe',
      detached: true
    });

    // Wait for build to complete
    await new Promise((resolve) => {
      serverProcess.on('close', resolve);
    });

    console.log('Starting compiled server...');
    serverProcess = spawn('node', ['dist/src/server.js'], {
      stdio: 'pipe',
      detached: true
    });

    // Wait for server to be ready
    console.log('Waiting for server to start...');
    await new Promise((resolve, reject) => {
      let attempts = 0;
      const maxAttempts = 20;
      
      const checkServer = setInterval(() => {
        attempts++;
        makeRequest({
          hostname: 'localhost',
          port: 3535,
          path: '/',
          method: 'GET'
        }).then((res) => {
          if (res.statusCode === 200) {
            clearInterval(checkServer);
            serverReady = true;
            console.log('Server is ready!');
            resolve();
          }
        }).catch(() => {
          if (attempts >= maxAttempts) {
            clearInterval(checkServer);
            reject(new Error('Server failed to start'));
          }
        });
      }, 500);
    });

    // Test 1: GET homepage
    console.log('\nTest 1: Checking homepage...');
    const homeResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/',
      method: 'GET'
    });

    if (homeResponse.statusCode === 200) {
      console.log('[OK] Homepage loads successfully');
      if (homeResponse.body.includes('Contact Our Friendly Team')) {
        console.log('[OK] Homepage contains expected content');
      } else {
        console.log(' Homepage missing expected content');
      }
    } else {
      console.log(` Homepage failed with status ${homeResponse.statusCode}`);
    }

    // Test 2: Submit valid form data
    console.log('\nTest 2: Submitting valid form data...');
    const validData = 'firstName=John&lastName=Doe&streetAddress=123+Main+St&city=New+York&stateProvinceRegion=NY&postalCode=10001&country=USA&email=john@example.com&phoneNumber=%2B1+555-123-4567';
    
    const submitResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': validData.length
      }
    }, validData);

    if (submitResponse.statusCode === 302) {
      console.log('[OK] Valid form submission redirects properly');
      if (submitResponse.headers.location === '/thank-you') {
        console.log('[OK] Redirects to thank you page');
      } else {
        console.log(' Redirects to wrong location');
      }
    } else {
      console.log(` Valid form submission failed with status ${submitResponse.statusCode}`);
    }

    // Test 3: Submit invalid form data
    console.log('\nTest 3: Submitting invalid form data...');
    const invalidData = 'firstName=&lastName=Test&streetAddress=456+Oak+Ave&city=Los+Angeles&stateProvinceRegion=CA&postalCode=90210&country=USA&email=invalid-email&phoneNumber=123';
    
    const invalidResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': invalidData.length
      }
    }, invalidData);

    if (invalidResponse.statusCode === 400) {
      console.log('[OK] Invalid form submission returns 400');
      if (invalidResponse.body.includes('Please fix the following errors')) {
        console.log('[OK] Invalid submission shows error messages');
      } else {
        console.log(' Invalid submission missing error messages');
      }
    } else {
      console.log(` Invalid form submission should return 400, got ${invalidResponse.statusCode}`);
    }

    // Test 4: Check thank you page
    console.log('\nTest 4: Checking thank you page...');
    const thankYouResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/thank-you',
      method: 'GET'
    });

    if (thankYouResponse.statusCode === 200) {
      console.log('[OK] Thank you page loads successfully');
      if (thankYouResponse.body.includes('Why did you give your information to a stranger on the internet')) {
        console.log('[OK] Thank you page contains humorous scam copy');
      } else {
        console.log(' Thank you page missing expected content');
      }
    } else {
      console.log(` Thank you page failed with status ${thankYouResponse.statusCode}`);
    }

    // Test 5: Check static CSS file
    console.log('\nTest 5: Checking static CSS file...');
    const cssResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/styles.css',
      method: 'GET'
    });

    if (cssResponse.statusCode === 200) {
      console.log('[OK] Static CSS file served successfully');
      if (cssResponse.body.length > 100) {
        console.log('[OK] CSS file contains substantial content');
      } else {
        console.log(' CSS file appears too small');
      }
    } else {
      console.log(` CSS file request failed with status ${cssResponse.statusCode}`);
    }

    // Test 6: International phone and postal code formats
    console.log('\nTest 6: Testing international formats...');
    const internationalData = 'firstName=Maria&lastName=Gonzalez&streetAddress=Av+Corrientes+1234&city=Buenos+Aires&stateProvinceRegion=Argentina&postalCode=C1000&country=Argentina&email=maria@test.com&phoneNumber=%2B54+9+11+1234-5678';
    
    const internationalResponse = await makeRequest({
      hostname: 'localhost',
      port: 3535,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Content-Length': internationalData.length
      }
    }, internationalData);

    if (internationalResponse.statusCode === 302) {
      console.log('[OK] International phone and postal code accepted');
    } else {
      console.log(` International format submission failed with status ${internationalResponse.statusCode}`);
    }

    console.log('\n=== Public Tests Complete ===');
    console.log('All core functionality has been verified!');

  } catch (error) {
    console.error('Test suite failed:', error.message);
    process.exit(1);
  } finally {
    // Clean up server process
    if (serverProcess && !serverProcess.killed) {
      console.log('\nShutting down server...');
      serverProcess.kill('SIGTERM');
    }
  }
}

// Run the tests
runTests().catch((error) => {
  console.error('Fatal error in test suite:', error);
  process.exit(1);
});