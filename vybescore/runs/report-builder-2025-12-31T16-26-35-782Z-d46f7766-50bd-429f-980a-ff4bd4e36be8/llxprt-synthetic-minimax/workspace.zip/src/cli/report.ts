import { readFileSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, CLIOptions } from '../types/index.js';

interface ParsedArgs {
  dataPath: string;
  options: CLIOptions;
}

function parseArguments(argv: string[]): ParsedArgs {
  if (argv.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = argv[2];
  
  const options: CLIOptions = {
    format: 'markdown',
    includeTotals: false
  };

  // Parse arguments starting from index 3 (after node, script, and data file)
  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        throw new Error('--format requires a value');
      }
      const format = argv[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      options.format = format;
      i++; // Skip the next argument since we consumed it
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        throw new Error('--output requires a value');
      }
      options.outputPath = argv[i + 1];
      i++; // Skip the next argument since we consumed it
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return { dataPath, options };
}

function loadReportData(dataPath: string): ReportData {
  try {
    const rawData = readFileSync(join(process.cwd(), dataPath), 'utf-8');
    const data = JSON.parse(rawData);
    
    // Validate required fields
    if (!data.title || !data.summary || !data.entries || !Array.isArray(data.entries)) {
      throw new Error('Invalid report data: missing required fields (title, summary, entries)');
    }
    
    // Validate entries
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${i}: missing label or invalid amount`);
      }
    }
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      const nodeError = error as NodeJS.ErrnoException;
      if (nodeError.code === 'ENOENT') {
        throw new Error(`File not found: ${dataPath}`);
      }
      throw error;
    }
    throw new Error(`Failed to load data: ${error}`);
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  if (options.format === 'markdown') {
    return renderMarkdown(data, options.includeTotals);
  } else if (options.format === 'text') {
    return renderText(data, options.includeTotals);
  } else {
    throw new Error(`Unsupported format: ${options.format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf-8');
  } else {
    console.log(content);
  }
}

// Main execution
try {
  const { dataPath, options } = parseArguments(process.argv);
  const reportData = loadReportData(dataPath);
  const output = renderReport(reportData, options);
  writeOutput(output, options.outputPath);
} catch (error) {
  console.error('Error:', error instanceof Error ? error.message : String(error));
  process.exit(1);
}
