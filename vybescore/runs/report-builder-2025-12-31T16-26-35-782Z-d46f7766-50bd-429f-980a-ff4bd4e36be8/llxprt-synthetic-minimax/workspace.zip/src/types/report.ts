// Shared interfaces for report data and CLI options

export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface CliOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}