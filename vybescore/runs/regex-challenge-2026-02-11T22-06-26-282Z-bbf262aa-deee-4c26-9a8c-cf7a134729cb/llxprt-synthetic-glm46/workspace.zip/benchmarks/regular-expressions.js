const utils = require('../../utils/measure');
const regexPatterns = require('../../patterns/regexPatterns');

/**
 * Regular Expression Benchmarks
 * 
 * This file measures performance of various regex operations using Node.js regex engine
 */

// Data for matching and parsing
const emailAddress = 'user.name@example.com';
const phoneNumber = '(555) 123-4567';
const date = '2023-04-15';
const url = 'https://www.example.com/path/to/resource?query=value';
const html = '<div class="test">Content</div>';
const csv = 'Name,Age,City\nJohn,25,New York';

// HTML snippet for tag extraction performance
const htmlSnippet = `
<html>
  <head>
    <title>Test Page</title>
  </head>
  <body>
    <div class="container">
      <h1>Welcome</h1>
      <p>This is a <strong>test</strong> page.</p>
      <ul>
        <li>Item 1</li>
        <li>Item 2</li>
        <li>Item 3</li>
      </ul>
    </div>
  </body>
</html>
`;

/**
 * Test email validation performance
 */
function testEmailValidation() {
  return utils.measureTime('Email Validation', () => {
    for (let i = 0; i < 1000; i++) {
      const isValid = regexPatterns.validateEmail(emailAddress);
    }
  });
}

/**
 * Test phone number parsing performance
 */
function testPhoneParsing() {
  return utils.measureTime('Phone Number Parsing', () => {
    for (let i = 0; i < 1000; i++) {
      const phoneObj = regexPatterns.parsePhoneNumber(phoneNumber);
    }
  });
}

/**
 * Test date parsing performance
 */
function testDateParsing() {
  return utils.measureTime('Date Parsing', () => {
    for (let i = 0; i < 1000; i++) {
      const dateObj = regexPatterns.parseDate(date);
    }
  });
}

/**
 * Test URL parsing performance
 */
function testUrlParsing() {
  return utils.measureTime('URL Parsing', () => {
    for (let i = 0; i < 1000; i++) {
      const urlObj = regexPatterns.parseUrl(url);
    }
  });
}

/**
 * Test HTML tag parsing performance
 */
function testHtmlParsing() {
  return utils.measureTime('HTML Tag Parsing', () => {
    for (let i = 0; i < 1000; i++) {
      const tags = regexPatterns.parseHtmlTags(htmlSnippet);
    }
  });
}

/**
 * Test CSV parsing performance
 */
function testCsvParsing() {
  return utils.measureTime('CSV Parsing', () => {
    for (let i = 0; i < 1000; i++) {
      const data = regexPatterns.parseCsv(csv);
    }
  });
}

/**
 * Test simple pattern matching performance
 */
function testSimplePatternMatching() {
  return utils.measureTime('Simple Pattern Matching', () => {
    const text = 'The quick brown fox jumps over the lazy dog. The quick brown fox is quick.';
    for (let i = 0; i < 1000; i++) {
      const matches = regexPatterns.findMatches(text, 'quick');
    }
  });
}

/**
 * Test advanced pattern matching performance
 */
function testAdvancedPatternMatching() {
  return utils.measureTime('Advanced Pattern Matching', () => {
    const text = 'Contact us at support@example.com or sales@example.org or info@example.net';
    for (let i = 0; i < 1000; i++) {
      const matches = regexPatterns.findMatches(text, '\\b[A-Za-z][A-Za-z0-9._%+-]*@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}\\b');
    }
  });
}

/**
 * Run all regex benchmarks
 */
function runAllBenchmarks() {
  console.log('Running Regular Expression Benchmarks...\n');
  
  const results = [
    testEmailValidation(),
    testPhoneParsing(),
    testDateParsing(),
    testUrlParsing(),
    testHtmlParsing(),
    testCsvParsing(),
    testSimplePatternMatching(),
    testAdvancedPatternMatching()
  ];
  
  utils.reportResults(results);
}

// Run benchmarks if this file is executed directly
if (require.main === module) {
  runAllBenchmarks();
}

module.exports = {
  testEmailValidation,
  testPhoneParsing,
  testDateParsing,
  testUrlParsing,
  testHtmlParsing,
  testCsvParsing,
  testSimplePatternMatching,
  testAdvancedPatternMatching,
  runAllBenchmarks
};