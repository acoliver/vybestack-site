#!/usr/bin/env python3
"""
Regex Patterns for AI Tools Processor
"""

import os
import re
import json
from pathlib import Path
from typing import Dict, List, Any, Optional
from datetime import datetime

class RegexPatternsProcessor:
    def __init__(self, input_dir: str):
        self.input_dir = Path(input_dir)
        self.tools = []
        self.patterns = {
            'name': r'name:\s*["\']([^"\']+)["\']',
            'description': r'description:\s*["\']([^"\']+)["\']',
            'parameters': r'parameters:\s*\{([^}]*)\}',
            'tool_calls': r'tool_calls.*?\[([^\]]*)\]',
            'search_query': r'matchquery:\s*["\']([^"\']+)["\']',
            'file_path': r'matchfilepath:\s*["\']([^"\']+)["\']',
            'code_content': r'matchfilecontent:\s*["\']([^"\']+)["\']',
        }
        self.sanitization_map = {
            'description': self._sanitize_description,
            'name': self._sanitize_name
        }

    def _sanitize_name(self, name: str) -> str:
        """Sanitize tool name by converting to lowercase and replacing non-alphanumeric chars with underscores."""
        return re.sub(r'[^a-zA-Z0-9]', '_', name.lower())

    def _sanitize_description(self, description: str) -> str:
        """Sanitize description by converting to lowercase and replacing non-alphanumeric chars with underscores."""
        return re.sub(r'[^a-zA-Z0-9]', '_', description.lower())

    def _extract_pattern_matches(self, content: str, pattern_name: str) -> List[str]:
        """Extract all matches for a given pattern."""
        pattern = self.patterns.get(pattern_name, '')
        matches = re.findall(pattern, content, re.MULTILINE | re.DOTALL)
        return matches

    def _process_single_file(self, file_path: Path) -> Optional[Dict[str, Any]]:
        """Process a single YAML file and extract tool information."""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Extract basic information
            name = self._extract_pattern_matches(content, 'name')
            description = self._extract_pattern_matches(content, 'description')
            
            if not name or not description:
                print(f"Warning: No name or description found in {file_path}")
                return None
            
            # Extract parameter block
            parameters_match = re.search(r'parameters:\s*\{([^}]*)\}', content, re.MULTILINE | re.DOTALL)
            parameters = parameters_match.group(1) if parameters_match else ""
            
            # Extract tool calls
            tool_calls = self._extract_pattern_matches(content, 'tool_calls')[0] if self._extract_pattern_matches(content, 'tool_calls') else ""
            
            # Extract specific patterns
            patterns_found = {}
            
            # Check for search pattern
            search_queries = self._extract_pattern_matches(content, 'search_query')
            if search_queries:
                patterns_found['search_query'] = search_queries
            
            # Check for file path pattern
            file_paths = self._extract_pattern_matches(content, 'file_path')
            if file_paths:
                patterns_found['file_path'] = file_paths
            
            # Check for code content pattern
            code_contents = self._extract_pattern_matches(content, 'code_content')
            if code_contents:
                patterns_found['code_content'] = code_contents
            
            # Sanitize name and description
            sanitized_name = self._sanitize_name(name[0])
            sanitized_description = self._sanitize_description(description[0])
            
            return {
                'name': name[0],
                'description': description[0],
                'sanitized_name': sanitized_name,
                'sanitized_description': sanitized_description,
                'parameters': parameters,
                'tool_calls': tool_calls,
                'patterns_found': patterns_found,
                'file_name': file_path.name
            }
            
        except Exception as e:
            print(f"Error processing {file_path}: {e}")
            return None

    def process_directory(self) -> List[Dict[str, Any]]:
        """Process all YAML files in the directory."""
        print(f"Processing directory: {self.input_dir}")
        
        # Find all YAML files
        yaml_files = list(self.input_dir.glob("**/*.yaml")) + list(self.input_dir.glob("**/*.yml"))
        
        print(f"Found {len(yaml_files)} YAML files")
        
        for file_path in yaml_files:
            print(f"Processing: {file_path}")
            tool_data = self._process_single_file(file_path)
            if tool_data:
                self.tools.append(tool_data)
        
        print(f"Successfully processed {len(self.tools)} tools")
        return self.tools

    def generate_summary_statistics(self) -> Dict[str, Any]:
        """Generate statistics about the processed tools."""
        if not self.tools:
            return {"error": "No tools processed"}
        
        # Count categories of patterns found
        pattern_categories = {}
        for tool in self.tools:
            for pattern_type in tool['patterns_found']:
                pattern_categories[pattern_type] = pattern_categories.get(pattern_type, 0) + 1
        
        # Parameter statistics
        tools_with_parameters = sum(1 for tool in self.tools if tool['parameters'])
        
        # Tool call statistics
        tools_with_calls = sum(1 for tool in self.tools if tool['tool_calls'])
        
        return {
            'total_tools': len(self.tools),
            'tools_with_parameters': tools_with_parameters,
            'tools_with_calls': tools_with_calls,
            'pattern_categories': pattern_categories,
            'pattern_types_found': list(pattern_categories.keys())
        }

    def export_to_json(self, output_path: str) -> None:
        """Export all extracted data and summary to a JSON file."""
        export_data = {
            'metadata': {
                'timestamp': datetime.now().isoformat(),
                'total_tools': len(self.tools),
                'directory_processed': str(self.input_dir)
            },
            'summary_statistics': self.generate_summary_statistics(),
            'tools': self.tools
        }
        
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(export_data, f, indent=2, ensure_ascii=False)
        
        print(f"Data exported to {output_path}")

    def generate_markdown_documentation(self, output_path: str) -> None:
        """Generate a markdown documentation file with the extracted information."""
        if not self.tools:
            print("No tools to document")
            return
        
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write("# Regex Patterns for AI Tools Documentation\n\n")
            f.write(f"Generated on: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n\n")
            
            # Summary statistics
            stats = self.generate_summary_statistics()
            f.write("## Summary Statistics\n\n")
            f.write(f"- **Total Tools**: {stats['total_tools']}\n")
            f.write(f"- **Tools with Parameters**: {stats['tools_with_parameters']}\n")
            f.write(f"- **Tools with Calls**: {stats['tools_with_calls']}\n")
            f.write(f"- **Pattern Types Found**: {', '.join(stats['pattern_types_found'])}\n\n")
            
            # Pattern categories
            if stats['pattern_categories']:
                f.write("### Pattern Categories\n\n")
                for category, count in stats['pattern_categories'].items():
                    f.write(f"- {category}: {count} tools\n\n")
            
            # Detailed tool information
            f.write("## Tool Details\n\n")
            for tool in self.tools:
                f.write(f"### {tool['name']}\n\n")
                f.write(f"**File**: `{tool['file_name']}`\n\n")
                f.write(f"**Description**: {tool['description']}\n\n")
                f.write(f"**Sanitized Name**: `{tool['sanitized_name']}`\n\n")
                f.write(f"**Sanitized Description**: `{tool['sanitized_description']}`\n\n")
                
                if tool['parameters']:
                    f.write(f"**Parameters Block**:\n```yaml\n{tool['parameters']}\n```\n\n")
                
                if tool['tool_calls']:
                    f.write(f"**Tool Calls**:\n```json\n{tool['tool_calls']}\n```\n\n")
                
                if tool['patterns_found']:
                    f.write("**Patterns Found**:\n")
                    for pattern_type, patterns in tool['patterns_found'].items():
                        f.write(f"- {pattern_type}: {', '.join(patterns)}\n")
                    f.write("\n")
                
                f.write("---\n\n")
        
        print(f"Markdown documentation generated at {output_path}")

if __name__ == "__main__":
    import argparse
    
    parser = argparse.ArgumentParser(description="Process AI tool YAML files and extract regex patterns")
    parser.add_argument("--input-dir", required=True, help="Directory containing tool YAML files")
    parser.add_argument("--output-dir", default="./outputs", help="Output directory for results")
    
    args = parser.parse_args()
    
    # Create output directory if it doesn't exist
    os.makedirs(args.output_dir, exist_ok=True)
    
    # Process the files
    processor = RegexPatternsProcessor(args.input_dir)
    tools_data = processor.process_directory()
    
    # Export results
    json_output = os.path.join(args.output_dir, "regex_patterns_data.json")
    processor.export_to_json(json_output)
    
    markdown_output = os.path.join(args.output_dir, "regex_patterns_documentation.md")
    processor.generate_markdown_documentation(markdown_output)
    
    print(f"Processing complete. Results saved to {args.output_dir}")