# Rate Limiting Implementation for Node.js/Express Applications

This project demonstrates how to implement effective rate limiting in Node.js/Express applications using the `express-rate-limit` package.

## Features Demonstrated

- Basic rate limiting setup
- Custom error responses
- Request validation middleware
- Memory store vs. Redis store configuration
- Different limit strategies for different endpoints

## Rate Limiting Strategies

### 1. Basic Rate Limiting

```javascript
// General API rate limiting (15 requests per 15 minutes per IP)
const rateLimit = require('express-rate-limit');

const apiLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // Limit each IP to 100 requests per windowMs
  message: {
    error: 'Too many requests from this IP, please try again after 15 minutes'
  },
  standardHeaders: true, // Return rate limit info in headers
  legacyHeaders: false,
});
```

### 2. Endpoint-Specific Rate Limiting

```javascript
// Strict rate limiting for auth endpoints (5 requests per 15 minutes)
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 5, // Limit each IP to 5 requests per windowMs
  message: {
    error: 'Too many authentication attempts, please try again after 15 minutes'
  },
  standardHeaders: true,
  legacyHeaders: false,
  handler: (req, res) => {
    res.status(429).json({
      error: 'Too many authentication attempts',
      retryAfter: '15 minutes'
    });
  }
});

// Apply only to auth routes
app.use('/api/auth', authLimiter);
```

### 3. Dynamic Rate Limiting Based on User

```javascript
const createUserRateLimiter = () => {
  return rateLimit({
    windowMs: 15 * 60 * 1000,
    max: (req) => {
      // Premium users get higher limits
      return req.user && req.user.isPremium ? 1000 : 100;
    },
    keyGenerator: (req) => {
      return req.user ? `user_${req.user.id}` : req.ip;
    }
  });
};
```

### 4. Memory Store vs Redis Store

```javascript
// Memory store (default, good for development)
const memoryLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: 100,
  store: new MemoryStore()
});

// Redis store (recommended for production)
const RedisStore = require('rate-limit-redis');
const redis = require('redis');

const client = redis.createClient({
  host: 'localhost',
  port: 6379,
});

const redisLimiter = rateLimit({
  store: new RedisStore({
    sendCommand: (...args) => client.call(...args),
  }),
  windowMs: 15 * 60 * 1000,
  max: 100,
});
```

## Implementation Options

### Option 1: Basic Implementation

Create a `rateLimiter.js` file:
```javascript
const rateLimit = require('express-rate-limit');

module.exports = {
  // General API rate limiting
  api: rateLimit({
    windowMs: 15 * 60 * 1000, // 15 minutes
    max: 100, // 100 requests per 15 minutes per IP
    message: {
      error: 'Too many requests, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
  }),
  
  // Auth endpoints
  auth: rateLimit({
    windowMs: 15 * 60 * 1000,
    max: 5,
    message: {
      error: 'Too many authentication attempts, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
  }),
  
  // Password reset
  passwordReset: rateLimit({
    windowMs: 60 * 60 * 1000, // 1 hour
    max: 3,
    message: {
      error: 'Too many password reset attempts, please try again later.'
    },
    standardHeaders: true,
    legacyHeaders: false,
  })
};
```

### Option 2: Advanced Implementation with Custom Store

For production environments with multiple server instances:

```javascript
// rateLimiter.js
const rateLimit = require('express-rate-limit');
const RedisStore = require('rate-limit-redis');
const redis = require('redis');

const client = redis.createClient({
  host: process.env.REDIS_HOST || 'localhost',
  port: process.env.REDIS_PORT || 6379,
  password: process.env.REDIS_PASSWORD,
});

// Function to create limiters with Redis store
const createRateLimiter = (options) => {
  return rateLimit({
    store: new RedisStore({
      sendCommand: (...args) => client.call(...args),
    }),
    ...options,
  });
};

module.exports = {
  // General API limiter
  api: createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 100,
    message: { error: 'Too many requests from this IP' },
  }),
  
  // Auth limiter
  auth: createRateLimiter({
    windowMs: 15 * 60 * 1000,
    max: 5,
    message: { error: 'Too many auth attempts' },
  }),
};
```

## Integration Steps

1. **Install dependencies**:
   ```bash
   npm install express express-rate-limit
   # For Redis store:
   npm install redis rate-limit-redis
   ```

2. **Create limiter configuration**:
   Create a `rateLimiter.js` file with your desired limits.

3. **Apply limiters in your Express app**:
   ```javascript
   const express = require('express');
   const { api, auth, passwordReset } = require('./rateLimiter');
   
   const app = express();
   
   // Apply general API rate limiting
   app.use('/api/', api);
   
   // Apply stricter limits to auth routes
   app.use('/api/auth/', auth);
   app.use('/api/auth/password-reset/', passwordReset);
   ```

4. **Test your implementation**:
   Use tools like Postman or curl to test that the limits are working correctly.

## Monitoring and Testing

### Testing Rate Limiting

```bash
# Using curl to test rate limiting (replace with your endpoint)
for i in {1..105}; do
  echo "Request $i:"
  curl -w "\nStatus: %{http_code}\n" http://localhost:3000/api/data
done
```

### Monitoring

Monitor rate limiting effectiveness by:
1. Checking logs for rate limit hits
2. Monitoring Redis if using Redis store
3. Setting up alerts for excessive rate limit triggers

## Best Practices

1. **Different limits for different endpoints**: Auth endpoints should have stricter limits
2. **Use appropriate windows**: Shorter windows for sensitive operations
3. **Clear error messages**: Tell users when they can try again
4. **Monitor effectiveness**: Adjust limits based on usage patterns
5. **Use Redis in production**: Ensures rate limiting works across multiple server instances
6. **Consider user tiers**: Premium users might get higher limits
7. **Document your limits**: Make limits clear in API documentation

## Security Considerations

- Rate limiting helps prevent brute force attacks
- Consider implementing exponential backoff for repeated violations
- Monitor for distributed attacks (multiple IPs targeting the same endpoint)
- Combine with other security measures like CAPTCHA for sensitive operations