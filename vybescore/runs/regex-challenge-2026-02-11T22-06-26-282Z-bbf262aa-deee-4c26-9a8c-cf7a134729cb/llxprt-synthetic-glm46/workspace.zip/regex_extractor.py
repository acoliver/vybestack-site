import re
import json
import argparse
import os

class RegexExtractor:
    """Tool for extracting text patterns using regular expressions."""
    
    def __init__(self, log_level='CRITICAL'):
        """Initialize the extractor with error handling and log level."""
        self.log_level = log_level
        
    def _log_message(self, level, message):
        """Log a message based on current log level."""
        levels = {'DEBUG': 0, 'INFO': 1, 'WARNING': 2, 'ERROR': 3, 'CRITICAL': 4}
        current_level = levels.get(self.log_level, 4)
        message_level = levels.get(level, 4)
        
        if current_level <= message_level:
            print(f"[{level}] {message}")
    
    def extract_pattern(self, text, pattern, flags=0, error_handling='strict'):
        """
        Extract all matches of a regex pattern from text.
        
        Args:
            text (str): Source text.
            pattern (str): Regular expression pattern.
            flags (int): Regex flags (e.g., re.IGNORECASE).
            error_handling (str): 'strict', 'log', or 'silent'.
        
        Returns:
            list: List of matches (empty if none or error).
        """
        try:
            self._log_message('DEBUG', f"Extracting using pattern: {pattern}")
            matches = re.findall(pattern, text, flags=flags)
            self._log_message('DEBUG', f"Successfully extracted {len(matches)} match(es)")
            return matches
        except Exception as e:
            error_message = f"Error using pattern '{pattern}': {str(e)}"
            if error_handling == 'strict':
                raise ValueError(error_message)
            elif error_handling == 'log':
                self._log_message('ERROR', error_message)
            # silent: no action
            return []
    
    def extract_groups(self, text, pattern, flags=0, error_handling='strict'):
        """
        Extract all matches and their groups from text.
        
        Returns:
            list: List of tuples (full match, groups), where groups is a tuple.
        """
        try:
            matches = []
            for match in re.finditer(pattern, text, flags=flags):
                # Get the full match and any capture groups
                groups = match.groups()
                if groups:
                    matches.append((match.group(0), groups))
                else:
                    matches.append((match.group(0), ()))
            return matches
        except Exception as e:
            error_message = f"Error using pattern '{pattern}': {str(e)}"
            if error_handling == 'strict':
                raise ValueError(error_message)
            elif error_handling == 'log':
                self._log_message('ERROR', error_message)
            return []

def save_results(results, output_filename):
    """Save results to a file as JSON."""
    try:
        with open(output_filename, 'w') as f:
            json.dump(results, f, indent=2)
        print(f"Results saved to {output_filename}")
    except Exception as e:
        print(f"Error saving results: {e}")

def load_text_from_file(filename):
    """Load text from a file."""
    try:
        with open(filename, 'r') as f:
            content = f.read()
            print(f"Successfully loaded {len(content)} characters from {filename}")
            return content
    except Exception as e:
        print(f"Error reading file {filename}: {e}")
        return ""

def main():
    """Main function with command-line parsing."""
    
    parser = argparse.ArgumentParser(description='Extract text patterns using regular expressions.')
    
    parser.add_argument('--source', help='Source file for text extraction', default='')
    parser.add_argument('--pattern', help='Regular expression pattern', default='')
    parser.add_argument('--output', help='Output file for results', default='extraction_results.json')
    parser.add_argument('--log-level', choices=['DEBUG', 'INFO', 'WARNING', 'ERROR', 'CRITICAL'], default='CRITICAL', help='Log level (default: CRITICAL)')
    parser.add_argument('--error-handling', choices=['strict', 'log', 'silent'], default='strict', help='Error handling mode (default: strict)')
    parser.add_argument('--extract-groups', action='store_true', help='Extract groups instead of just matches')
    parser.add_argument('--case-insensitive', action='store_true', help='Use case-insensitive matching')
    
    args = parser.parse_args()
    
    # If no arguments provided, use default ones
    if not args.source and not args.pattern:
        args.source = 'data.txt'
        args.pattern = '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        args.log_level = 'DEBUG'
        args.error_handling = 'log'
    
    # Initialize the extractor
    extractor = RegexExtractor(log_level=args.log_level)
    
    # Set flags based on arguments
    flags = 0
    if args.case_insensitive:
        flags |= re.IGNORECASE
    
    # Try to extract from file
    if args.source and os.path.exists(args.source):
        text = load_text_from_file(args.source)
    else:
        # Create a string with at least 10 examples matching the pattern
        if not args.pattern:
            args.pattern = '[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}'
        
        # Generate sample text based on the pattern (default is email pattern)
        text = """
        This is a sample text with multiple email addresses to extract.
        Some examples:
        - Contact: contact@example.com
        - Support: support@my-company.org
        - Personal: john.doe.smith@gmail.com
        - Business: jane_doe123@company-name.co.uk
        - Info: info@test-site.net
        - Sales: sales@marketing-team.info
        - Admin: admin@system-operations.edu
        - Support2: support@help-desk.io
        - User1: user12345@domain-name.org
        - User2: alice.bob@sample-domain.com
        """
    
    print(f"Using pattern: {args.pattern}")
    
    # Extract matches or groups
    if args.extract_groups:
        results = extractor.extract_groups(text, args.pattern, flags=flags, error_handling=args.error_handling)
    else:
        results = extractor.extract_pattern(text, args.pattern, flags=flags, error_handling=args.error_handling)
    
    print(f"Found {len(results)} match(es)")
    
    # Save results to file
    save_results(results, args.output)
    
    return results

if __name__ == '__main__':
    main()