document.addEventListener('DOMContentLoaded', function() {
    // DOM elements
    const patternInput = document.getElementById('pattern');
    const testStringInput = document.getElementById('test-string');
    const testAllButton = document.getElementById('test-all');
    const testCurrentButton = document.getElementById('test-current');
    const clearButton = document.getElementById('clear');
    const resultsContainer = document.getElementById('results');
    const successCount = document.getElementById('success-count');
    const failureCount = document.getElementById('failure-count');
    const passRateElement = document.getElementById('pass-rate');
    const solutionText = document.getElementById('solution-text');
    
    // Current solution and challenges
    let currentChallenges = [];
    
    // Test a specific string against the pattern
    function testPattern(pattern, testString) {
        try {
            const regex = new RegExp(pattern);
            return regex.test(testString);
        } catch (e) {
            return false;
        }
    }
    
    // Load challenges from the JSON file
    async function loadChallenges() {
        try {
            const response = await fetch('challenges.json');
            const data = await response.json();
            currentChallenges = data.challenges;
            return true;
        } catch (error) {
            console.error('Error loading challenges:', error);
            return false;
        }
    }
    
    // Test the current pattern against all challenges
    async function testAllChallenges() {
        if (currentChallenges.length === 0) {
            await loadChallenges();
        }
        
        const pattern = patternInput.value.trim();
        if (!pattern) {
            resultsContainer.innerHTML = '<p style="color: red;">Please enter a regex pattern</p>';
            return;
        }
        
        let success = 0;
        let failure = 0;
        resultsContainer.innerHTML = '';
        
        // Test each challenge
        for (const challenge of currentChallenges) {
            // Test all "should match" test cases
            for (const testCase of challenge.should_match) {
                const result = testPattern(pattern, testCase);
                if (result) {
                    success++;
                    addResult(testCase, true, challenge);
                } else false {
                    failure++;
                    addResult(testCase, false, challenge);
                }
            }
            
            // Test all "should not match" test cases
            for (const testCase of challenge.should_not_match) {
                const result = testPattern(pattern, testCase);
                if (!result) {
                    success++;  // Correctly rejected
                    addResult(testCase, true, challenge);
                } else {
                    failure++;  // Incorrectly accepted
                    addResult(testCase, false, challenge);
                }
            }
        }
        
        updateStats(success, failure);
    }
    
    // Test a custom string
    function testCustomString() {
        const pattern = patternInput.value.trim();
        const testString = testStringInput.value.trim();
        
        if (!pattern || !testString) {
            resultsContainer.innerHTML = '<p style="color: red;">Please enter both pattern and test string</p>';
            return;
        }
        
        resultsContainer.innerHTML = '';
        const result = testPattern(pattern, testString);
        addResult(testString, result);
        updateStats(result ? 1 : 0, result ? 0 : 1);
    }
    
    // Add a result to the display
    function addResult(testString, passed, challenge) {
        const resultElement = document.createElement('div');
        resultElement.className = passed ? 'result pass' : 'result fail';
        
        const passText = passed ? '[OK] PASS' : ' FAIL';
        const challengeInfo = challenge ? `<strong>[${challenge.id}] ${challenge.description}</strong><br>` : '';
        
        resultElement.innerHTML = `${challengeInfo}<code>${testString}</code> - ${passText}`;
        resultsContainer.appendChild(resultElement);
    }
    
    // Update the statistics display
    function updateStats(success, failure) {
        successCount.textContent = success;
        failureCount.textContent = failure;
        
        const total = success + failure;
        const passRate = total > 0 ? Math.round((success / total) * 100) : 0;
        passRateElement.textContent = `${passRate}%`;
    }
    
    // Clear all inputs and results
    function clearAll() {
        patternInput.value = '';
        testStringInput.value = '';
        resultsContainer.innerHTML = '';
        updateStats(0, 0);
    }
    
    // Set a solution in the input field
    function setSolution(solution) {
        patternInput.value = solution;
    }
    
    // Event listeners
    testAllButton.addEventListener('click', testAllChallenges);
    testCurrentButton.addEventListener('click', testCustomString);
    clearButton.addEventListener('click', clearAll);
    
    // Initialize with challenges when page loads
    loadChallenges();
    
    // Expose the setSolution function for HTML onclick handlers
    window.setSolution = setSolution;
});