/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  Subject,
  addObserver,
  removeObserver,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Check if updateFn has a default parameter (function of the form (x: number = 3) => x * 2)
  const fnStr = updateFn.toString()
  const hasDefaultParam = fnStr.includes('=') && fnStr.includes(':')
  
  let o: Observer<T>
  
  if (hasDefaultParam) {
    // For functions with default parameters, use a wrapper that calls without args
    o = {
      name: options?.name,
      value,
      updateFn: () => (updateFn as () => T)()
    }
  } else {
    // For functions without default parameters, use as is
    o = {
      name: options?.name,
      value,
      updateFn,
    }
  }
  
  // Create a subject for the computed value to track observers
  const s: Subject<T> = {
    name: `computed-${options?.name}`,
    observers: new Set(),
    value: value! as T,
    equalFn: undefined,
  }
  
  // Track whether we're currently computing to avoid infinite recursion
  let computing = false
  
  // Compute initial value
  computing = true
  updateObserver(o)
  s.value = o.value!
  computing = false
  
  const getter = (): T => {
    // When a computed value is accessed, it becomes a dependency for active observer
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      addObserver(s, activeObserver)
    }
    
    // Only recompute if we're not already computing (to avoid recursion)
    if (!computing) {
      computing = true
      updateObserver(o)
      s.value = o.value!
      computing = false
    }
    
    return s.value
  }
  
  // Override the updateObserver function to handle reactive updates
  const originalUpdateFn = o.updateFn
  o.updateFn = (prevValue) => {
    if (computing) return o.value
    return originalUpdateFn(prevValue)
  }
  
  // Function to handle updates from dependencies
  const updateFromDeps = () => {
    if (computing) return
    
    computing = true
    const newValue = originalUpdateFn(o.value)
    if (newValue !== o.value) {
      o.value = newValue
      s.value = newValue
      notifyObservers(s)
    }
    computing = false
  }
  
  // Register with updateObserver override if dependencies change
  ;(o as any)._updateFromDeps = updateFromDeps
  
  return getter
}
