/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, Subject } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const trackedSubjects: Subject<unknown>[] = []
  
  // Prevent infinite recursion
  let executing = false
  
  const observer: Observer<T> = {
    value,
    updateFn: (prevValue) => {
      if (disposed || executing) return prevValue
      
      executing = true
      const result = updateFn(prevValue)
      observer.value = result
      executing = false
      
      return result
    }
  }
  
  // Track subjects this callback depends on
  const observerWithTracking = observer as Observer<T> & { _trackedSubjects: Subject<unknown>[] }
  observerWithTracking._trackedSubjects = trackedSubjects
  
  // Register observer to track dependencies during initial execution
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all tracked subjects
    trackedSubjects.forEach(subject => {
      subject.observers.delete(observer)
    })
    trackedSubjects.length = 0
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
