export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical formats like name@tag@example.co.uk, user@example.com
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Local part: letters, digits, dots, hyphens, underscores, plus signs, @ tags
  // Cannot start/end with dot, no consecutive dots
  // Domain: letters, digits, hyphens (no underscores), must have at least one dot
  // TLD: 2-6 letters
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?!.*\.\.)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,6}$/;
  
  // Also support tagged addresses like name@tag@example.co.uk
  const taggedEmailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?!.*\.\.)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,6}$/;
  
  return emailRegex.test(value) || taggedEmailRegex.test(value);
}

/**
 * Validates US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Rejects: impossible area codes (leading 0/1), too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except +
  const digitsOnly = value.replace(/[^\d+]/g, '');
  
  // Placeholder for future options handling (e.g., extensions)
  if (options?.allowExtensions) {
    // Future implementation for extension handling
  }
  
  // Extract number after +1 if present
  const actualNumber = digitsOnly.startsWith('+1') ? digitsOnly.substring(2) : digitsOnly;
  
  // Must be exactly 10 digits
  if (actualNumber.length !== 10) {
    return false;
  }
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = actualNumber.substring(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = actualNumber.substring(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles with optional country code, trunk prefix, and mobile indicator.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Match: optional +54, optional 0 trunk prefix, optional 9 mobile indicator, area code (2-4 digits starting 1-9), subscriber 6-8 digits
  // When country code is omitted, must have trunk prefix 0 before area code
  const argentinePhoneRegex = /^(?:\+54|54)?(?:0)?[9]?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!argentinePhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Additional validation: when no country code, must start with 0 (trunk prefix)
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  
  if (!hasCountryCode) {
    // Must have trunk prefix (leading 0 before area code)
    if (!cleaned.startsWith('0')) {
      return false;
    }
  }
  
  // Extract area code and subscriber number for detailed validation
  let numberPart = cleaned;
  
  // Remove country code if present
  if (numberPart.startsWith('+54')) {
    numberPart = numberPart.substring(3);
  } else if (numberPart.startsWith('54')) {
    numberPart = numberPart.substring(2);
  }
  
  // Remove trunk prefix if present
  if (numberPart.startsWith('0')) {
    numberPart = numberPart.substring(1);
  }
  
  // Remove mobile indicator if present
  if (numberPart.startsWith('9')) {
    numberPart = numberPart.substring(1);
  }
  
  // Now numberPart starts with area code
  // Area code: 2-4 digits, leading digit 1-9
  // Subscriber: 6-8 digits
  // Total length should be area code (2-4) + subscriber (6-8) = 8-12 digits
  if (numberPart.length < 8 || numberPart.length > 12) {
    return false;
  }
  
  // Verify area code starts with 1-9
  const areaCodeMatch = numberPart.match(/^[1-9]\d{1,3}/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[0];
  const subscriberNumber = numberPart.substring(areaCode.length);
  
  // Subscriber must be 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and invalid names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // At least 2 characters, only letters (including unicode), spaces, hyphens, apostrophes
  // Must start with a letter
  const nameRegex = /^[\p{L}][\p{L}\s'-]*[\p{L}]$/u;
  
  return nameRegex.test(value) && value.length >= 2;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts: Visa (starts with 4, 13-19 digits), Mastercard (starts with 51-55 or 2221-2720, 16 digits), AmEx (starts with 34 or 37, 15 digits)
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13-19
  const visaRegex = /^4\d{12,18}$/;
  
  // Mastercard: starts with 51-55, 16 digits OR starts with 2221-2720, 16 digits
  const mastercardRegex = /^(?:5[1-5]\d{14}|(?:222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)\d{12})$/;
  
  // AmEx: starts with 34 or 37, 15 digits
  const amexRegex = /^3[47]\d{13}$/;
  
  const validPrefix = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validPrefix) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
