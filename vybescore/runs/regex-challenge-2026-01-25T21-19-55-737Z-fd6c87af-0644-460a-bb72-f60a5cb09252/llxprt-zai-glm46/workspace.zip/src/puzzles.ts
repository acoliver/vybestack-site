/**
 * Finds words starting with the given prefix, excluding words in the exceptions list.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with prefix (word boundaries)
  const wordRegex = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const uniqueWords = new Set(matches.map(m => m.toLowerCase()));
  
  return Array.from(uniqueWords).filter(word => 
    !exceptionsLower.includes(word)
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Uses lookahead/lookbehind for precise matching.
 * Returns the full match including the preceding digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Filter to ensure matches are not at position 0 (not at start of string)
  const results: string[] = [];
  let match;
  const regex = new RegExp(`\\d${escapedToken}`, 'g');
  
  while ((match = regex.exec(text)) !== null) {
    // Check that the match is not at position 0
    if (match.index > 0) {
      results.push(match[0]);
    }
  }
  
  return results;
}

/**
 * Validates password strength.
 * Requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol (special character)
 * - No whitespace
 * - No immediate repeated sequences (e.g., "abab" should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for symbol (non-alphanumeric, non-space)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (patterns like abab, abcabc, etc.)
  // A sequence of length 2+ that repeats immediately
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const seq1 = value.substring(i, i + len);
      const seq2 = value.substring(i + len, i + len * 2);
      if (seq1 === seq2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand :: notation).
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Check if the value contains an IPv6 address
  // This handles strings that may have additional text around the IPv6 address
  
  // Full IPv6 pattern: 8 groups of 1-4 hex digits separated by colons
  // Compressed with :: shorthand
  // Also handles addresses with zone IDs or CIDR notation
  
  // Match IPv6 within larger text or as standalone
  const ipv6Patterns = [
    // Full IPv6: 8 groups of hex
    /[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}/,
    // Compressed with ::
    /[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){0,6}::[0-9a-fA-F]{0,4}/,
    // Starting with ::
    /::[0-9a-fA-F]{1,4}/,
    // Just ::
    /::/,
    // IPv6 with zone ID
    /[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,7}%[a-zA-Z0-9]+/,
    // IPv6 with CIDR
    /[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){1,7}\/\d{1,3}/,
    // Embedded IPv4 in IPv6
    /::[fF]{4}:(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})/,
  ];
  
  // Check each pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
