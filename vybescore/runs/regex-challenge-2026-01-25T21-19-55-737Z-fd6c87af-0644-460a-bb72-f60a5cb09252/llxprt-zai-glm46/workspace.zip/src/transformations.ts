/**
 * Capitalizes the first character of each sentence.
 * - Inserts exactly one space between sentences
 * - Collapses extra spaces while preserving spacing within sentences
 * - Preserves abbreviations when possible (short words followed by sentence enders)
 */
export function capitalizeSentences(text: string): string {
  if (!text) return '';
  
  // Step 1: Normalize sentence endings - ensure proper spacing after .!?
  // Also handle cases like "word.Next" with no space
  let normalized = text.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Step 2: Collapse multiple spaces into single spaces
  normalized = normalized.replace(/\s+/g, ' ');
  
  // Step 3: Trim leading/trailing whitespace
  normalized = normalized.trim();
  
  // Step 4: Capitalize first letter of text
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Step 5: Capitalize after sentence terminators, being careful with abbreviations
  // Common abbreviations: Mr., Mrs., Ms., Dr., Prof., Sr., Jr., etc., vs., e.g., i.e.
  const abbreviations = [
    'Mr\\.', 'Mrs\\.', 'Ms\\.', 'Dr\\.', 'Prof\\.', 'Sr\\.', 'Jr\\.',
    'etc\\.', 'vs\\.', 'e\\.g\\.', 'i\\.e\\.', 'approx\\.', 'est\\.',
    'Capt\\.', 'Lt\\.', 'Col\\.', 'Gen\\.', 'Sen\\.', 'Rep\\.', 'Gov\\.',
    'St\\.', 'Ave\\.', 'Blvd\\.', 'Rd\\.', 'dept\\.', 'univ\\.', 'assn\\.',
    'No\\.', 'vol\\.', 'ed\\.', 'p\\.', 'pp\\.', 'Jan\\.', 'Feb\\.', 'Mar\\.',
    'Apr\\.', 'Jun\\.', 'Jul\\.', 'Aug\\.', 'Sep\\.', 'Sept\\.', 'Oct\\.',
    'Nov\\.', 'Dec\\.', 'ft\\.', 'in\\.', 'lb\\.', 'oz\\.', 'sq\\.'
  ].join('|');
  
  // Split into potential sentence boundaries and capitalize
  const sentenceRegex = new RegExp(`([.!?]\\s+)(?!(?:${abbreviations}))([a-z])`, 'gi');
  
  normalized = normalized.replace(sentenceRegex, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  return normalized;
}

/**
 * Extracts all URLs from the given text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex
  const urlRegex = /(?:https?:\/\/)?(?:www\.)?[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?:\/[^\s.,!?;:()"]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,!?;:()"']+$/, ''));
}

/**
 * Enforces HTTPS by replacing all http:// URLs with https://
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites documentation URLs.
 * - Always upgrades scheme to https://
 * - For URLs from http://example.com with /docs/ paths, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic/legacy paths (cgi-bin, query strings, .jsp, .php, etc.)
 * - Preserves nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com/... URLs
  const exampleUrlRegex = /(https?:\/\/)(example\.com)(\/[^\s]*)?/gi;
  
  return text.replace(exampleUrlRegex, (match, scheme, host, path = '') => {
    // Always upgrade scheme to https
    const newScheme = 'https://';
    const newPath = path || '/';
    
    // Check if path starts with /docs/
    const isDocsPath = newPath.startsWith('/docs/');
    
    // Check for dynamic/legacy indicators that should skip host rewrite
    const dynamicIndicators = [
      'cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx',
      '.do', '.cgi', '.pl', '.py'
    ];
    
    const hasDynamicIndicator = dynamicIndicators.some(indicator => 
      newPath.toLowerCase().includes(indicator)
    );
    
    // Rewrite host to docs.example.com only if:
    // - Path starts with /docs/
    // - No dynamic/legacy indicators present
    if (isDocsPath && !hasDynamicIndicator) {
      return newScheme + 'docs.example.com' + newPath;
    }
    
    // Otherwise just upgrade the scheme
    return newScheme + host + newPath;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns 'N/A' if the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDays) {
    return 'N/A';
  }
  
  // Special check for February 29 (leap year)
  if (month === 2 && day === 29) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || year % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return yearStr;
}
