// Manual edge case testing script
import {
  isValidEmail,
  isValidUSPhone,
  isValidArgentinePhone,
  isValidName,
  isValidCreditCard
} from './src/validators.js';

import {
  capitalizeSentences,
  extractUrls,
  enforceHttps,
  rewriteDocsUrls,
  extractYear
} from './src/transformations.js';

import {
  findPrefixedWords,
  findEmbeddedToken,
  isStrongPassword,
  containsIPv6
} from './src/puzzles.js';

console.log('=== EMAIL VALIDATION ===');
console.log('name@tag@example.co.uk:', isValidEmail('name@tag@example.co.uk'));
console.log('user@example.com:', isValidEmail('user@example.com'));
console.log('user@@example..com:', isValidEmail('user@@example..com'));
console.log('user@example_.com:', isValidEmail('user@example_.com'));
console.log('.user@example.com:', isValidEmail('.user@example.com'));

console.log('\n=== US PHONE VALIDATION ===');
console.log('(212) 555-7890:', isValidUSPhone('(212) 555-7890'));
console.log('212-555-7890:', isValidUSPhone('212-555-7890'));
console.log('2125557890:', isValidUSPhone('2125557890'));
console.log('+1 212-555-7890:', isValidUSPhone('+1 212-555-7890'));
console.log('012-555-7890:', isValidUSPhone('012-555-7890'));
console.log('212-555-789:', isValidUSPhone('212-555-789'));

console.log('\n=== ARGENTINE PHONE VALIDATION ===');
console.log('+54 9 11 1234 5678:', isValidArgentinePhone('+54 9 11 1234 5678'));
console.log('011 1234 5678:', isValidArgentinePhone('011 1234 5678'));
console.log('+54 341 123 4567:', isValidArgentinePhone('+54 341 123 4567'));
console.log('0341 4234567:', isValidArgentinePhone('0341 4234567'));
console.log('341 123 4567:', isValidArgentinePhone('341 123 4567'));

console.log('\n=== NAME VALIDATION ===');
console.log('Jane Doe:', isValidName('Jane Doe'));
console.log("José María:", isValidName('José María'));
console.log("O'Connor:", isValidName("O'Connor"));
console.log('X Æ A-12:', isValidName('X Æ A-12'));
console.log('John123:', isValidName('John123'));

console.log('\n=== CREDIT CARD VALIDATION ===');
console.log('4111111111111111:', isValidCreditCard('4111111111111111'));
console.log('5500000000000004:', isValidCreditCard('5500000000000004'));
console.log('340000000000009:', isValidCreditCard('340000000000009'));
console.log('4111111111111112:', isValidCreditCard('4111111111111112'));

console.log('\n=== CAPITALIZE SENTENCES ===');
console.log(capitalizeSentences('hello.world.how are you?i am fine.'));
console.log(capitalizeSentences('mr. smith went to washington. he met dr. jones.'));

console.log('\n=== EXTRACT URLS ===');
console.log(extractUrls('Visit https://example.com or http://test.com/path!'));

console.log('\n=== ENFORCE HTTPS ===');
console.log(enforceHttps('Visit http://example.com and https://secure.com'));

console.log('\n=== REWRITE DOCS URLS ===');
console.log(rewriteDocsUrls('See http://example.com/docs/api and http://example.com/docs/api/v1 and http://example.com/cgi-bin/script and http://example.com/docs/test.jsp'));

console.log('\n=== EXTRACT YEAR ===');
console.log('12/25/2023:', extractYear('12/25/2023'));
console.log('02/29/2024:', extractYear('02/29/2024'));
console.log('02/29/2023:', extractYear('02/29/2023'));
console.log('13/01/2023:', extractYear('13/01/2023'));

console.log('\n=== FIND PREFIXED WORDS ===');
console.log(findPrefixedWords('test testing tester toast', 'test', ['tester']));

console.log('\n=== FIND EMBEDDED TOKEN ===');
console.log(findEmbeddedToken('abc123def 123 456token', 'token'));

console.log('\n=== STRONG PASSWORD ===');
console.log('Abcdef123!:', isStrongPassword('Abcdef123!'));
console.log('abab123456A@:', isStrongPassword('abab123456A@'));
console.log('Abc123!:', isStrongPassword('Abc123!'));

console.log('\n=== CONTAINS IPV6 ===');
console.log('2001:db8::1:', containsIPv6('2001:db8::1'));
console.log('192.168.1.1:', containsIPv6('192.168.1.1'));
console.log('::1:', containsIPv6('::1'));
