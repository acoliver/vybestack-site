/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences, collapses extra spaces,
 * and leaves abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text) {
    return text;
  }
  
  // First, normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after sentence boundaries if missing
  // Look for punctuation followed by letter without space
  normalized = normalized.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Capitalize first character of each sentence
  // This regex matches sentence boundaries and captures the following character
  const result = normalized.replace(/(?:^|[.!?]\s+)([a-z])/g, (match) => {
    return match.toUpperCase();
  });
  
  return result;
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text) {
    return [];
  }
  
  // Comprehensive URL regex
  // Matches http://, https://, and www. protocols
  // Captures domain, subdomains, paths, query strings, fragments
  // Excludes trailing punctuation
  const urlRegex = /\b((?:https?:\/\/|www\.)[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9](?:\.[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9])*(?:\.[a-zA-Z]{2,})(?:\/[\w\-._~:/?#\[\]@!$&'()*+,;=%]*)?)\b/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation characters that aren't part of URLs
    return url.replace(/[.,;:!?]+$/g, '');
  });
  
  return cleanedUrls;
}

/**
 * Forces all http:// URLs to https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text) {
    return text;
  }
  
  // Replace http:// with https:// but don't touch https:// URLs
  // Use negative lookahead to avoid matching https://
  return text.replace(/http:\/\/(?!\/)/g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 * - Still upgrades scheme to https:// in all cases
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) {
    return text;
  }
  
  // First, upgrade all http to https
  let result = text.replace(/http:\/\//g, 'https://');
  
  // Then handle docs.example.com rewriting for specific patterns
  // Match https://example.com/... where path starts with /docs/
  // But exclude urls with cgi-bin, query strings, or legacy extensions
  result = result.replace(
    /https:\/\/([a-zA-Z0-9.-]+)(\/docs\/(?!.*(?:\?(?:[^&]*&)*|&(?:[^=]*=)*|=(?:[^&]*)&|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py)[^\s]*).*?)(?=\s|$)/g,
    (match, domain, path) => {
      // Build the full URL path to check for exclusions
      const fullPath = match.substring(match.indexOf('/'));
      
      // Check if path contains excluded elements
      const hasCgiBin = /\/cgi-bin\//i.test(fullPath);
      const hasQueryString = /[?&=]/.test(fullPath);
      const hasLegacyExtension = /\.(jsp|php|asp|aspx|do|cgi|pl|py)([?#]|$)/i.test(fullPath);
      
      // Skip host rewrite if any exclusions found
      if (hasCgiBin || hasQueryString || hasLegacyExtension) {
        return match;
      }
      
      // Rewrite to docs.example.com
      return `https://docs.${domain}${path}`;
    }
  );
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value) {
    return 'N/A';
  }
  
  // Match mm/dd/yyyy format exactly
  const dateMatch = value.match(/^(0?[1-9]|1[0-2])\/(0?[1-9]|[12]\d|3[01])\/(\d{4})$/);
  
  if (!dateMatch) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate that the day is valid for the given month
  // Simple validation - doesn't account for all calendar edge cases
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Simple leap year check for February
  const leapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
  const maxDays = month === 2 ? (leapYear ? 29 : 28) : daysInMonth[month - 1];
  
  if (day > maxDays) {
    return 'N/A';
  }
  
  return year;
}
