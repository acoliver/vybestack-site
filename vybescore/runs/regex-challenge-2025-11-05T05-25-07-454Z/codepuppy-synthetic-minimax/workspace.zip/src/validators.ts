export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with strict patterns.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Email regex that validates:
  // - Local part: letters, digits, dots (not consecutive/trailing), plus, hyphens
  // - @ symbol
  // - Domain: no underscores, valid TLD patterns
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9+._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)*\.[a-zA-Z]{2,}$/;
  
  // Basic format check
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for edge cases
  // No consecutive dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // No dot at start or end of local part
  const [localPart, domain] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain shouldn't start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers with various formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, + optional country code)
  if (cleaned.length < 10) {
    return false;
  }
  
  // Handle optional +1 country code
  let phoneNumber = cleaned;
  if (phoneNumber.startsWith('1')) {
    if (phoneNumber.length === 11) {
      phoneNumber = phoneNumber.slice(1); // Remove the country code
    } else if (phoneNumber.length > 11) {
      return false; // Too long even with country code
    }
  } else if (phoneNumber.length > 10) {
    return false; // Too long without country code
  }
  
  // Must be exactly 10 digits at this point
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits) and validate
  const areaCode = phoneNumber.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Validate original format matches common US phone patterns
  // This regex matches: (212) 555-7890, 212-555-7890, 2125557890, +1-212-555-7890, etc.
  const usPhoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)[\s-]?|\d{3}[\s-]?)\d{3}[\s-]?\d{4}$/;
  
  return usPhoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54 country code
  // Optional 0 trunk prefix (must be immediately before area code if no country code)
  // Optional 9 mobile indicator
  // Area code: 2-4 digits, leading 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(9?)([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, mobileIndicator, areaCode, subscriber] = match;
  
  // Validate area code length (2-4 digits, already enforced by regex)
  const areaCodeLength = areaCode.length;
  if (areaCodeLength < 2 || areaCodeLength > 4) {
    return false;
  }
  
  // Validate subscriber length (6-8 digits, already enforced by regex)
  const subscriberLength = subscriber.length;
  if (subscriberLength < 6 || subscriberLength > 8) {
    return false;
  }
  
  // If no country code (+54), must start with trunk prefix (0)
  if (!cleaned.startsWith('+54') && !cleaned.startsWith('0')) {
    return false;
  }
  
  // More strict validation for the original format
  // This matches the exact formats with separators allowed
  const strictArgentineRegex = /^(?:\+54[\s-]?)?(?:0)?(9?[\s-]?)?[1-9]\d{1,3}[\s-]?\d{6,8}$/;
  
  return strictArgentineRegex.test(value.trim());
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and unusual names like X Æ A-12
 */
export function isValidName(value: string): boolean {
  // Trim whitespace from ends
  const name = value.trim();
  
  // Empty name is invalid
  if (!name) {
    return false;
  }
  
  // Name regex that allows:
  // - Unicode letters (including accents and international characters)
  // - Apostrophes (') and hyphens (-)
  // - Spaces
  // - Names must contain at least one letter
  // - Reject digits and most symbols
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(name)) {
    return false;
  }
  
  // Ensure there's at least one unicode letter
  if (!/[\p{L}]/u.test(name)) {
    return false;
  }
  
  // Reject names that are just symbols or punctuation
  if (!/[\p{L}]/u.test(name.replace(/[ '\-]/g, ''))) {
    return false;
  }
  
  // Reject names that contain digit-like characters or excessive symbols
  // Specifically targeting the X Æ A-12 style names
  if (/\d|[Ææ]/.test(name) && /\d/.test(name)) {
    return false;
  }
  
  // Reject names with consecutive non-letter characters (except apostrophe+hypen combos)
  if (/["'\-\s]{2,}/.test(name)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers (Visa/Mastercard/AmEx) with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits and reasonable length (13-19 digits)
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check valid prefixes for major card types
  // Visa: 4
  // Mastercard: 51-55, 2221-2720
  // AmEx: 34, 37
  const visaRegex = /^4/;
  const mastercardRegex = /^5[1-5]|^2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))/;
  const amexRegex = /^3[47]/;
  
  const isValidPrefix = visaRegex.test(cleaned) || 
                       mastercardRegex.test(cleaned) || 
                       amexRegex.test(cleaned);
  
  if (!isValidPrefix) {
    return false;
  }
  
  // Validate length based on card type
  const isVisa = visaRegex.test(cleaned);
  const isAmex = amexRegex.test(cleaned);
  const isMastercard = mastercardRegex.test(cleaned);
  
  if (isVisa && (cleaned.length !== 13 && cleaned.length !== 16)) {
    return false;
  }
  
  if (isAmex && cleaned.length !== 15) {
    return false;
  }
  
  if (isMastercard && cleaned.length !== 16) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn algorithm checksum.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
