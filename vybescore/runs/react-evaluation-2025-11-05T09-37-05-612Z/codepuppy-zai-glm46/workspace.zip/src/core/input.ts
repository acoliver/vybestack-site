/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: typeof equal === 'function' ? equal : 
              equal === false ? undefined : 
              (a: T, b: T) => a === b,
    observers: new Set<Observer<unknown>>(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
      s.observers.add(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers in the dependency chain
    // We need to collect all observers recursively to handle nested dependencies
    const notified = new Set<Observer<unknown>>()
    
    const notifyObservers = (observers: Set<Observer<unknown>>) => {
      observers.forEach(observer => {
        if (!notified.has(observer)) {
          notified.add(observer)
          // Execute the observer's update function
          observer.value = observer.updateFn(observer.value)
          
          // If this observer has its own observers (computed values), notify them too
          // This creates the cascade effect
          if ((observer as Observer<unknown> & { observers?: Set<Observer<unknown>> }).observers) {
            notifyObservers((observer as Observer<unknown> & { observers?: Set<Observer<unknown>> }).observers!)
          }
        }
      })
    }
    
    notifyObservers(s.observers)
    
    return s.value
  }

  return [read, write]
}
