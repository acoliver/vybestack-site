/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Computed values need to track their own observers for the cascade
  const computedObservers: Set<Observer<unknown>> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Attach observers to the observer for the cascade notification
  ;(o as Observer<T> & { observers: Set<Observer<unknown>> }).observers = computedObservers
  
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // When this computed value is accessed, register any active observer
    if (activeObserver) {
      computedObservers.add(activeObserver as Observer<unknown>)
    }
    
    // When this computed value is accessed, we need to recompute it
    // to establish the dependency chain
    updateObserver(o)
    
    return o.value!
  }
  
  return getter
}