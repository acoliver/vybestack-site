declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): unknown;
    exec(sql: string): unknown;
    export(): Uint8Array;
    close(): void;
    prepare(sql: string): SqlStatement;
    freemem(): void;
  }

  export interface SqlStatement {
    run(params?: unknown[]): unknown;
    get(params?: unknown[]): unknown;
    all(params?: unknown[]): unknown[];
    free(): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export default function initSqlJs(config?: unknown): Promise<SqlJsStatic>;
}
