import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || 3535;
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

const app = express();
let db: Database | null = null;

// Ensure data directory exists
const dataDir = path.resolve('data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir, { recursive: true });
}

// Types
interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

interface ValidationErrors {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.resolve('public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'views'));

// Initialize database
async function initDatabase(): Promise<void> {
  const SQL = await initSqlJs();
  
  if (fs.existsSync(DB_PATH)) {
    const dbFile = fs.readFileSync(DB_PATH);
    db = new SQL.Database(dbFile);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    saveDatabase();
  }
}

function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^[\d\s+\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postal: string): boolean {
  const postalRegex = /^[\dA-Za-z\s-]+$/;
  return postalRegex.test(postal) && postal.trim().length > 0;
}

function validateFormData(data: FormData): { isValid: boolean; errors: ValidationErrors } {
  const errors: ValidationErrors = {};
  
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province/Region is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/Zip code is required';
  } else if (!validatePostalCode(data.postalCode)) {
    errors.postalCode = 'Invalid postal code format';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!validateEmail(data.email)) {
    errors.email = 'Invalid email address';
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!validatePhone(data.phone)) {
    errors.phone = 'Invalid phone number format';
  }
  
  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', { 
    formData: {}, 
    errors: {},
    title: 'Friendly International Contact Form'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };
  
  const validation = validateFormData(formData);
  
  if (!validation.isValid) {
    res.status(400);
    return res.render('index', { 
      formData, 
      errors: validation.errors,
      title: 'Friendly International Contact Form'
    });
  }
  
  // Insert into database
  if (db) {
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
  }
  
  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Graceful shutdown
async function closeServer(): Promise<void> {
  console.log('\nShutting down gracefully...');
  if (db) {
    db.close();
    db = null;
  }
  process.exit(0);
}

process.on('SIGTERM', closeServer);
process.on('SIGINT', closeServer);

// Start server
async function startServer(): Promise<void> {
  await initDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Failed to start server:', err);
  process.exit(1);
});

export { app, closeServer };
