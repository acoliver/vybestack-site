import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';

let server: import('http').Server;
let app: express.Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the app from the compiled server
  const module = await import('../../dist/server.js');
  app = module.app;
  
  // Start the server on a random available port for testing
  server = await new Promise((resolve) => {
    const s = app.listen(0, () => resolve(s));
  });
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form has the right action
    expect($('form[action="/submit"]')).toHaveLength(1);
    
    // Check for labels with proper for attributes
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    expect($('label[for="phone"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up database before this test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'john@example.com',
      phone: '+54 9 11 1234-5678'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    // Should redirect to thank you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Follow the redirect
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    const $ = cheerio.load(thankYouResponse.text);
    // Check for humorous scam warning text
    const pageText = $('body').text();
    expect(pageText).toMatch(/stranger|internet|spam|data|identity/i);
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('validates required fields', async () => {
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send({
        firstName: '',
        lastName: '',
        email: 'invalid-email',
        phone: 'invalid-phone'
      });
    
    // Should return the form with errors
    expect(response.status).toBe(400);
    
    const $ = cheerio.load(response.text);
    const pageText = $('body').text();
    
    // Should contain error messages
    expect(pageText).toMatch(/required/i);
  });

  it('accepts international phone and postal formats', async () => {
    // Clean up database before this test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '221B Baker Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
  });
});
