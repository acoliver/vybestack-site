/**
 * Encode plain text to standard Base64 with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 with or without padding and rejects invalid input.
 */
export function decode(input: string): string {
  // Validate input is valid Base64 alphabet
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside valid Base64 alphabet');
  }
  
  // Check padding constraints
  validatePadding(input);
  
  return tryDecodeWithPadding(input);
}

/**
 * Validates padding in Base64 input.
 */
function validatePadding(input: string): void {
  // Check padding constraint: at most 2 padding characters and only at the end
  const paddingMatch = input.match(/=/g);
  if (paddingMatch && paddingMatch.length > 2) {
    throw new Error('Invalid Base64 input: too many padding characters');
  }
  
  // Padding must only appear at the end
  if (input.includes('=') && !/={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: padding characters in the middle');
  }
}

/**
 * Attempts to decode Base64 input with appropriate padding.
 */
function tryDecodeWithPadding(input: string): string {
  // Try to decode with the original input first
  // This handles standard Base64 and padded inputs correctly
  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    
    // Check if the result is valid UTF-8 and not empty
    if (result.length > 0 || (input.length === 0)) {
      return result;
    }
  } catch (error) {
    // If that fails, we may need to add padding for unpadded inputs
  }
  
  // For unpadded inputs that need it, add the correct padding
  if (!input.includes('=')) {
    // Add padding if needed to make length divisible by 4
    const paddingNeeded = (4 - (input.length % 4)) % 4;
    const normalizedInput = input + '='.repeat(paddingNeeded);
    
    try {
      return Buffer.from(normalizedInput, 'base64').toString('utf8');
    } catch (error) {
      throw new Error('Failed to decode Base64 input');
    }
  }
  
  throw new Error('Failed to decode Base64 input');
}
