import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: Express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  process.env.NODE_ENV = 'test';
  server = (await import('../../dist/server.js')).default;
});

afterAll(() => {
  // No cleanup needed
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const res = await request(server).get('/');
    expect(res.status).toBe(200);
    
    const $ = cheerio.load(res.text);
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const res = await request(server)
      .post('/submit')
      .type('form')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'CA',
        postalCode: '12345',
        country: 'USA',
        email: 'john.doe@example.com',
        phone: '+1-234-567-8900'
      });
      
    expect(res.status).toBe(302);
    expect(res.header.location).toBe('/thank-you?firstName=John');
  });
});
