import express, { Express, Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';
import initSqlJs from 'sql.js';

// Get the directory name for ESM modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Initialize express app
const app: Express = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;

// Set view engine and views directory
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Middleware for parsing form data
app.use(express.urlencoded({ extended: true }));

// Serve static files
app.use('/public', express.static(path.join(__dirname, '../public')));

// Type definitions
type FormValues = {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
};

type ValidationError = string;

// Ensure data directory exists
const dataDir = path.join(__dirname, '../data');
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

const dbPath = path.join(dataDir, 'submissions.sqlite');

// Database initialization
let db: initSqlJs.Database;
let SQL: initSqlJs.SqlJsStatic;

async function initDatabase(): Promise<void> {
  SQL = await initSqlJs({
    locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
  });
  
  if (fs.existsSync(dbPath)) {
    const fileBuffer = fs.readFileSync(dbPath);
    db = new SQL.Database(fileBuffer);
  } else {
    db = new SQL.Database();
    const schemaSql = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    db.run(schemaSql);
    saveDatabase();
  }
}

// Save database to file
function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  const data = db.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(dbPath, buffer);
}

// Form validation functions
function validateForm(values: FormValues): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields check
  if (!values.firstName?.trim()) errors.push('First name is required');
  if (!values.lastName?.trim()) errors.push('Last name is required');
  if (!values.streetAddress?.trim()) errors.push('Street address is required');
  if (!values.city?.trim()) errors.push('City is required');
  if (!values.stateProvince?.trim()) errors.push('State/Province is required');
  if (!values.postalCode?.trim()) errors.push('Postal code is required');
  if (!values.country?.trim()) errors.push('Country is required');
  if (!values.email?.trim()) errors.push('Email is required');
  if (!values.phone?.trim()) errors.push('Phone number is required');
  
  // Email validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (values.email && !emailRegex.test(values.email)) {
    errors.push('Please enter a valid email address');
  }
  
  // Phone number validation (accepting international formats)
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (values.phone && !phoneRegex.test(values.phone)) {
    errors.push('Please enter a valid phone number');
  }
  
  // Postal code validation (alphanumeric, accepting international formats)
  const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;
  if (values.postalCode && !postalCodeRegex.test(values.postalCode)) {
    errors.push('Please enter a valid postal code');
  }
  
  return errors;
}

// Define routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };
  
  const errors = validateForm(values);
  
  if (errors.length > 0) {
    return res.status(400).render('form', { errors, values });
  }
  
  // Insert into database
  if (!db) {
    return res.status(500).send('Database not initialized');
  }
  
  try {
    const stmt = db.prepare(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
    );
    
    stmt.run([
      values.firstName,
      values.lastName,
      values.streetAddress,
      values.city,
      values.stateProvince,
      values.postalCode,
      values.country,
      values.email,
      values.phone
    ]);
    
    stmt.free();
    saveDatabase();
  } catch (err) {
    console.error('Database error:', err);
    return res.status(500).send('Failed to save submission');
  }
  
  res.redirect(302, '/thank-you?firstName=' + encodeURIComponent(values.firstName));
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = (req.query.firstName as string) || 'friend';
  res.render('thank-you', { firstName });
});

// Initialize database and start server
initDatabase().then(() => {
  // Export server for testing
  if (process.env.NODE_ENV === 'test') {
    module.exports = app;
  } else {
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle graceful shutdown
    process.on('SIGTERM', () => {
      console.log('SIGTERM signal received: closing HTTP server and database');
      server.close(() => {
        console.log('HTTP server closed');
        if (db) {
          db.close();
          console.log('Database closed');
        }
        process.exit(0);
      });
    });
    
    process.on('SIGINT', () => {
      console.log('SIGINT signal received: closing HTTP server and database');
      server.close(() => {
        console.log('HTTP server closed');
        if (db) {
          db.close();
          console.log('Database closed');
        }
        process.exit(0);
      });
    });
    
    module.exports = app;
  }
}).catch(err => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});