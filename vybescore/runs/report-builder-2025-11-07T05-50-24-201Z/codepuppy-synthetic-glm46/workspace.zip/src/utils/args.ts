import type { CliArgs } from '../types.js';

/**
 * Parse command line arguments
 */
export function parseArgs(argv: string[]): CliArgs {
  const args = argv.slice(2); // Remove node and script name
  
  if (args.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  let dataFile: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      i++;
      if (i >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[i];
    } else if (arg === '--output') {
      i++;
      if (i >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!dataFile) {
      dataFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
  }

  if (!dataFile) {
    throw new Error('Data file path is required');
  }

  if (!format) {
    throw new Error('--format is required');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error('Unsupported format');
  }

  return {
    dataFile,
    format: format as 'markdown' | 'text',
    outputPath,
    includeTotals,
  };
}
