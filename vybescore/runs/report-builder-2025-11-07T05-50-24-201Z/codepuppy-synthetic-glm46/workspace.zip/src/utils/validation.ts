import type { ReportData } from '../types.js';
import { readFile } from 'node:fs/promises';

/**
 * Validate that a value is a valid report entry
 */
function isValidEntry(entry: unknown): entry is { label: string; amount: number } {
  return (
    typeof entry === 'object' &&
    entry !== null &&
    'label' in entry &&
    'amount' in entry &&
    typeof entry.label === 'string' &&
    typeof entry.amount === 'number'
  );
}

/**
 * Validate that a value is a valid report data object
 */
export function validateReportData(data: unknown): data is ReportData {
  if (
    typeof data !== 'object' ||
    data === null ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data)
  ) {
    return false;
  }

  const reportData = data as Record<string, unknown>;

  if (
    typeof reportData.title !== 'string' ||
    typeof reportData.summary !== 'string' ||
    !Array.isArray(reportData.entries)
  ) {
    return false;
  }

  return reportData.entries.every(isValidEntry);
}

/**
 * Load and parse JSON report data from file
 */
export async function loadReportData(filePath: string): Promise<ReportData> {
  try {
    const fileContent = await readFile(filePath, 'utf-8');
    const data = JSON.parse(fileContent);
    
    if (!validateReportData(data)) {
      throw new Error('Invalid report data: missing required fields or invalid structure');
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in file ${filePath}: ${error.message}`);
    }
    if (error instanceof Error && error.message.startsWith('Invalid report data')) {
      throw error;
    }
    throw new Error(`Failed to read file ${filePath}: ${error instanceof Error ? error.message : String(error)}`);
  }
}
