import type { ReportRenderer } from '../types.js';
import { MarkdownRenderer } from './markdown.js';
import { TextRenderer } from './text.js';

/**
 * Registry of available report formatters
 */
export const FORMATTERS: Record<string, ReportRenderer> = {
  markdown: new MarkdownRenderer(),
  text: new TextRenderer(),
};

/**
 * Get list of supported formats
 */
export function getSupportedFormats(): string[] {
  return Object.keys(FORMATTERS);
}

/**
 * Check if a format is supported
 */
export function isFormatSupported(format: string): boolean {
  return format in FORMATTERS;
}

/**
 * Get formatter for a specific format
 */
export function getFormatter(format: string): ReportRenderer {
  if (!isFormatSupported(format)) {
    throw new Error(`Unsupported format: ${format}`);
  }
  return FORMATTERS[format]!;
}
