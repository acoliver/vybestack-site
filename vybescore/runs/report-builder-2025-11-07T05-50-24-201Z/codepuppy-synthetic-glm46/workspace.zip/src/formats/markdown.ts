import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';

/**
 * Format amount as currency with two decimal places
 */
function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculate total amount from entries
 */
function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Markdown report renderer
 */
export class MarkdownRenderer implements ReportRenderer {
  render(data: ReportData, options: ReportOptions): string {
    const lines: string[] = [];

    // Title
    lines.push(`# ${data.title}`);
    lines.push(''); // blank line

    // Summary
    lines.push(data.summary);
    lines.push(''); // blank line

    // Entries
    lines.push('## Entries');
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }

    // Total if requested
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push(`**Total:** ${formatAmount(total)}`);
    }

    return lines.join('\n');
  }
}

/**
 * Export singleton instance for easy usage
 */
export const renderMarkdown = (data: ReportData, options: ReportOptions): string => {
  const renderer = new MarkdownRenderer();
  return renderer.render(data, options);
};
