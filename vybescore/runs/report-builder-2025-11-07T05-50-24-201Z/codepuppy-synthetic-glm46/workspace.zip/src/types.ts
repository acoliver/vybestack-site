/**
 * Report data structure matching the JSON schema
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: Array<{
    label: string;
    amount: number;
  }>;
}

/**
 * Options for report rendering
 */
export interface ReportOptions {
  includeTotals: boolean;
}

/**
 * Report renderer interface
 */
export interface ReportRenderer {
  render(data: ReportData, options: ReportOptions): string;
}

/**
 * CLI arguments interface
 */
export interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}
