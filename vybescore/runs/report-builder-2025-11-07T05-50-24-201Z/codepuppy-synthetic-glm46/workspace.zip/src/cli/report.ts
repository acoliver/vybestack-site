#!/usr/bin/env node

import { writeFile } from 'node:fs';
import { stdout } from 'node:process';
import { parseArgs } from '../utils/args.js';
import { loadReportData } from '../utils/validation.js';
import { getFormatter } from '../formats/index.js';

/**
 * Main CLI entry point
 */
async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const args = parseArgs(process.argv);
    
    // Load and validate report data
    const reportData = await loadReportData(args.dataFile);
    
    // Get the appropriate formatter
    const formatter = getFormatter(args.format);
    
    // Render the report
    const output = formatter.render(reportData, { includeTotals: args.includeTotals });
    
    // Write output to file or stdout
    if (args.outputPath) {
      writeFile(args.outputPath, output, (error) => {
        if (error) {
          console.error(`Error writing to file: ${error.message}`);
          process.exit(1);
        }
      });
    } else {
      stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

// Run the CLI
main();
