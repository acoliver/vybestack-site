const BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_INPUT_ERROR = 'Invalid Base64 input';

/**
 * Encode plain text to Base64 using the standard Base64 alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates that the input is properly formatted Base64 and rejects invalid inputs.
 */
export function decode(input: string): string {
  // Remove whitespace
  const normalized = input.trim().replace(/\s/g, '');
  
  // Validate Base64 format
  if (!BASE64_REGEX.test(normalized)) {
    throw new Error(INVALID_INPUT_ERROR);
  }
  
  // Check for proper padding
  const paddingCount = (normalized.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error(INVALID_INPUT_ERROR);
  }
  
  // Check that padding only appears at the end
  const paddingIndex = normalized.indexOf('=');
  if (paddingIndex !== -1 && paddingIndex < normalized.length - paddingCount) {
    throw new Error(INVALID_INPUT_ERROR);
  }

  try {
    const decoded = Buffer.from(normalized, 'base64').toString('utf8');
    
    // Validate round-trip to ensure the input was valid
    // Accept both padded and unpadded forms that decode correctly
    const reencoded = Buffer.from(decoded).toString('base64');
    const unpadded = reencoded.replace(/=+$/, '');
    
    if (normalized !== reencoded && normalized !== unpadded) {
      throw new Error(INVALID_INPUT_ERROR);
    }
    
    return decoded;
  } catch (error) {
    throw new Error(INVALID_INPUT_ERROR);
  }
}
