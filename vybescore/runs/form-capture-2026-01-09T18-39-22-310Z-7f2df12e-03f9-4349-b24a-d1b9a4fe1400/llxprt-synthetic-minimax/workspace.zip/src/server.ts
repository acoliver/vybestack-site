import express from 'express';
import path from 'path';
import fs from 'fs';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(__dirname, '..', 'public')));

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'views'));

// Database setup
let db: unknown = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
  data: Partial<FormData>;
}

// Email validation regex (simple but effective)
const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

// Phone validation regex (allows international formats)
const phoneRegex = /^\+?[\d\s\-()]+$/;

// Postal code validation (alphanumeric, supports various international formats)
const postalCodeRegex = /^[A-Za-z0-9\s-]+$/;

async function initDatabase(): Promise<void> {
  try {
    const initSqlJs = (await import('sql.js')).default;
    
    const SQLModule = await initSqlJs({
      locateFile: (file: string) => {
        return require.resolve(`sql.js/dist/${file}`);
      }
    });

    const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQLModule.Database(filebuffer);
    } else {
      db = new SQLModule.Database();
      
      // Read and execute schema
      const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
      if (fs.existsSync(schemaPath)) {
        const schemaSql = fs.readFileSync(schemaPath, 'utf8');
        db.exec(schemaSql);
        
        // Create data directory if it doesn't exist
        const dataDir = path.dirname(dbPath);
        if (!fs.existsSync(dataDir)) {
          fs.mkdirSync(dataDir, { recursive: true });
        }
        
        // Save initial database
        const buffer = db.export() as Uint8Array;
        fs.writeFileSync(dbPath, buffer);
      }
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function validateForm(data: FormData): ValidationResult {
  const errors: Record<string, string> = {};
  const result: ValidationResult = {
    isValid: true,
    errors,
    data
  };

  // Required field validation
  if (!data.firstName?.trim()) {
    errors.firstName = 'First name is required';
  }
  
  if (!data.lastName?.trim()) {
    errors.lastName = 'Last name is required';
  }
  
  if (!data.streetAddress?.trim()) {
    errors.streetAddress = 'Street address is required';
  }
  
  if (!data.city?.trim()) {
    errors.city = 'City is required';
  }
  
  if (!data.stateProvince?.trim()) {
    errors.stateProvince = 'State/Province is required';
  }
  
  if (!data.postalCode?.trim()) {
    errors.postalCode = 'Postal/ZIP code is required';
  }
  
  if (!data.country?.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!data.email?.trim()) {
    errors.email = 'Email is required';
  } else if (!emailRegex.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!data.phone?.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!phoneRegex.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code format validation
  if (data.postalCode && !postalCodeRegex.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  result.isValid = Object.keys(errors).length === 0;
  return result;
}

// Routes
app.get('/', (req, res) => {
  res.render('index', { 
    errors: {}, 
    data: {},
    title: 'Friendly Contact Form'
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const validation = validateForm(formData);

  if (!validation.isValid) {
    // Re-render form with errors and previously entered values
    res.status(400).render('index', {
      errors: validation.errors,
      data: formData,
      title: 'Friendly Contact Form - Please Correct Errors'
    });
    return;
  }

  // Insert valid data into database
  try {
    db?.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName.trim(),
        formData.lastName.trim(),
        formData.streetAddress.trim(),
        formData.city.trim(),
        formData.stateProvince.trim(),
        formData.postalCode.trim(),
        formData.country.trim(),
        formData.email.trim(),
        formData.phone.trim()
      ]
    );

    // Save database to file
    const buffer = db?.export() as Uint8Array;
    if (buffer) {
      const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
      fs.writeFileSync(dbPath, buffer);
    }

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('index', {
      errors: { general: 'Sorry, there was an error processing your submission. Please try again.' },
      data: formData,
      title: 'Friendly Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      db.close();
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Initialize database and start server
initDatabase().then(() => {
  app.listen(PORT, () => {
    console.log(`Friendly Form Capture server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to see the form`);
  });
}).catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export { app };
export default app;
