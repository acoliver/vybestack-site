const INVALID_BASE64_MESSAGE = 'Invalid Base64 input: contains invalid characters or incorrect padding';

/**
 * Pad Base64 string to proper length if needed
 */
function padBase64(input: string): string {
  const trimmed = input.replace(/\s+/g, '');
  const paddingNeeded = (4 - (trimmed.length % 4)) % 4;
  return trimmed + '='.repeat(paddingNeeded);
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Validates input and throws error for invalid Base64 data.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Invalid Base64 input: empty string');
  }

  // Remove any whitespace before validation and decoding
  const cleanedInput = input.replace(/\s+/g, '');
  
  // Check for valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(cleanedInput)) {
    throw new Error(INVALID_BASE64_MESSAGE);
  }
  
  // Validate padding rules and length
  if (cleanedInput.includes('=')) {
    // If padding exists, it must be at the end and length must be divisible by 4
    const paddingIndex = cleanedInput.indexOf('=');
    const paddingPart = cleanedInput.substring(paddingIndex);
    
    // Padding must be only '=' characters and at the end
    if (!/^=+$/.test(paddingPart)) {
      throw new Error(INVALID_BASE64_MESSAGE);
    }
    
    // With padding, length must be divisible by 4
    if (cleanedInput.length % 4 !== 0) {
      throw new Error(INVALID_BASE64_MESSAGE);
    }
    
    // Only 0, 1, or 2 padding characters allowed
    if (paddingPart.length > 2) {
      throw new Error(INVALID_BASE64_MESSAGE);
    }
  }

  try {
    // Pad the input if needed for proper Base64 decoding
    const paddedInput = padBase64(cleanedInput);
    const buffer = Buffer.from(paddedInput, 'base64');
    
    // Verify the decoded buffer makes sense (not empty if input wasn't just padding)
    if (buffer.length === 0 && !/^=+$/.test(paddedInput)) {
      throw new Error('Invalid Base64 input: no data decoded');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
