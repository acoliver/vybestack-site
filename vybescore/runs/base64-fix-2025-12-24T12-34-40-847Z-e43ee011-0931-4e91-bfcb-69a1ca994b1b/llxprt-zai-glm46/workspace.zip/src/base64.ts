const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_BASE64_ERROR = 'Invalid Base64 input';

/**
 * Validates whether a string is valid Base64.
 * A valid Base64 string contains only characters from the Base64 alphabet
 * and has at most 2 padding characters at the end.
 */
function isValidBase64(input: string): boolean {
  if (input.length === 0) {
    return false;
  }

  // Remove any whitespace for validation
  const trimmed = input.trim();

  // Check for valid Base64 characters
  if (!VALID_BASE64_REGEX.test(trimmed)) {
    return false;
  }

  // Check padding is only at the end and there are at most 2 padding chars
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding must only appear at the end
    const afterPadding = trimmed.slice(paddingIndex);
    if (!/^=+$/.test(afterPadding)) {
      return false;
    }
    // At most 2 padding characters
    if (afterPadding.length > 2) {
      return false;
    }
    // When padding is present, total length must be multiple of 4
    if (trimmed.length % 4 !== 0) {
      return false;
    }
  }

  return true;
}

/**
 * Encode plain text to Base64.
 * Uses the canonical Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws an error for invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  if (!isValidBase64(trimmed)) {
    throw new Error(INVALID_BASE64_ERROR);
  }

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // If the buffer is empty but input was not, it likely means invalid input
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error(INVALID_BASE64_ERROR);
    }

    return buffer.toString('utf8');
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
