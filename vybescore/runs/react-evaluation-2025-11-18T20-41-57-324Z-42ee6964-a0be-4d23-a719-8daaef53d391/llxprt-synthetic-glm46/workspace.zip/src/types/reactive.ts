/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observer?: ObserverR | undefined
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
const subjects: Subject<any>[] = []
const computedObservers: Observer<any>[] = []

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const newValue = observer.updateFn(observer.value)
    if (newValue !== observer.value) {
      observer.value = newValue
      // Trigger all computed values that depend on this observer
      notifyComputedValues()
    }
  } finally {
    activeObserver = previous
  }
}

export function registerSubject<T>(subject: Subject<T>): void {
  subjects.push(subject as any)
}

export function registerComputed<T>(observer: Observer<T>): void {
  computedObservers.push(observer as any)
}

export function notifyComputedValues(): void {
  // Each computed observer re-runs their function with current dependencies
  for (const observer of computedObservers) {
    try {
      updateObserver(observer)
    } catch (e) {
      // Ignore errors in notification
    }
  }
}

// Legacy functions for compatibility
export function unregisterSubject<T>(subject: Subject<T>): void {
  const index = subjects.indexOf(subject as any)
  if (index >= 0) {
    subjects.splice(index, 1)
  }
}

export function unregisterComputed<T>(observer: Observer<T>): void {
  const index = computedObservers.indexOf(observer as any)
  if (index >= 0) {
    computedObservers.splice(index, 1)
  }
}