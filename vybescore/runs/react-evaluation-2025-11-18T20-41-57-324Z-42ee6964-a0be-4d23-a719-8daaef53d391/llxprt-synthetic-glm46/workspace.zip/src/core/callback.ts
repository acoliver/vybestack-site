/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, getActiveObserver, registerComputed, unregisterComputed } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register the callback as a computed observer to track dependencies
  registerComputed(observer)
  
  // Run the callback once to establish dependencies
  const previousObserver = getActiveObserver()
  if (previousObserver !== observer) {
    updateObserver(observer)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from computed observers list to prevent further updates
    unregisterComputed(observer)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.observer = undefined
    observer.updateFn = () => value!
  }
}