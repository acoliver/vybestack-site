/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerSubject
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Handle equality function parameter
  let equalFn: EqualFn<T> | undefined
  if (typeof _equal === 'function') {
    equalFn = _equal
  } else if (_equal === true) {
    equalFn = (lhs: T, rhs: T) => lhs === rhs
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Register this subject for notifications
  registerSubject(s)

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value changed using equality function
    if (equalFn && equalFn(s.value, nextValue)) {
      return s.value // No change, return current value
    }
    
    // Update the value 
    s.value = nextValue
    
    // Notify through the subject system - create an Observer wrapper for the subject
    if (s.observer) {
      const observerWrapper: Observer<T> = {
        name: s.name,
        observer: s.observer.observer,
        value: s.value,
        updateFn: () => s.value
      }
      updateObserver(observerWrapper)
    }
    
    return s.value
  }

  return [read, write]
}