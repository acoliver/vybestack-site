/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type Dependencies = Set<Subject<unknown>>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T | undefined
  equalFn?: EqualFn<T>
  dependencies?: Dependencies
  subscribers?: Set<Observer<T>>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const prev = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = prev
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observer && 'updateFn' in subject.observer) {
    updateObserver(subject.observer as Observer<T>)
  }
  
  // Notify all subscribers
  if (subject.subscribers) {
    for (const subscriber of subject.subscribers) {
      updateObserver(subscriber)
    }
  }
}

export function dependOn<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer && observer !== subject.observer && 'updateFn' in observer) {
    if (!subject.subscribers) {
      subject.subscribers = new Set()
    }
    // Type assertion needed because we've confirmed observer has updateFn
    subject.subscribers.add(observer as Observer<T>)
  }
}

export function unsubscribe<T>(subject: Subject<T>, observer: Observer<T>): void {
  if (subject.subscribers) {
    subject.subscribers.delete(observer)
  }
  
  // Remove the observer from the subject's main observer too
  if (subject.observer === observer) {
    subject.observer = undefined
  }
}
