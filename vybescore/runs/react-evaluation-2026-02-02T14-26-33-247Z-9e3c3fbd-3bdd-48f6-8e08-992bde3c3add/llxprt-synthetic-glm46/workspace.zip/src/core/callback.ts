/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  const callbackId = `callback-${Math.random().toString(36).substr(2, 9)}`
  
  const observer: Observer<T> = {
    name: callbackId,
    value,
    updateFn: (prevValue?: T) => {
      // Only run the callback if it's not disposed
      if (!disposed) {
        const result = updateFn(prevValue)
        return result
      }
      return prevValue!
    },
  }
  
  // Run the callback initially to track dependencies
  updateObserver(observer)
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
