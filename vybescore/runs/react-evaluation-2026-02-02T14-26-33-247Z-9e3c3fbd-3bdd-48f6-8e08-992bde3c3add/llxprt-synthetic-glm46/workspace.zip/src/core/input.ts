/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  notifyObservers,
  dependOn,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

function isEqualFn<T>(val: boolean | EqualFn<T> | undefined): val is EqualFn<T> {
  return typeof val === 'function'
}

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return lhs === rhs
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: isEqualFn(equal) ? equal : equal === false ? undefined : defaultEqual,
  }

  const read: GetterFn<T> = () => {
    dependOn(s)
    return s.value!
  }

  const write: SetterFn<T> = (nextValue) => {
    const equalFn = s.equalFn
    if (equalFn && equalFn(s.value!, nextValue)) {
      return s.value!
    }
    s.value = nextValue
    
    // Notify dependent observers
    notifyObservers(s)
    
    return s.value!
  }

  return [read, write]
}
