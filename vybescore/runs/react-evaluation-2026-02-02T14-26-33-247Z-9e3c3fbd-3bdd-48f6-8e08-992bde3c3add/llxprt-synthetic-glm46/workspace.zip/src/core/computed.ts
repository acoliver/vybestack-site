/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  EqualFn,
  dependOn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let isComputing = false
  
  // Create a subject to hold the computed value
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
  }
  
  const o: Observer<T> = {
    name: options?.name,
    value: value as T,
    updateFn: (prevValue?: T) => {
      if (isComputing) {
        return prevValue!
      }
      isComputing = true
      try {
        // Recompute the value
        const newValue = updateFn(prevValue)
        subject.value = newValue
        return newValue
      } finally {
        isComputing = false
      }
    },
  }
  
  subject.observer = o
  
  const computed: GetterFn<T> = (): T => {
    // When accessed, establish dependency and compute if needed
    dependOn(subject)
    // Compute the value on access
    const newValue = o.updateFn(o.value!)
    return newValue!
  }
  
  // Store the observer for dependency tracking
  ;(computed as unknown as { _observer: Observer<T> })._observer = o
  ;(computed as unknown as { _subject: Subject<T> })._subject = subject
  
  return computed
}
