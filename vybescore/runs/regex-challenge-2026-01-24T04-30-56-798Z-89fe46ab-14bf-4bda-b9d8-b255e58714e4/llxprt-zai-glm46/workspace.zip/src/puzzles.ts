/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix (case-insensitive)
  const pattern = new RegExp(`\\b(${escapedPrefix}\\w*)`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionSet = new Set(exceptions.map(e => e.toLowerCase()));
  const filtered = matches.filter(word => !exceptionSet.has(word.toLowerCase()));
  
  // Return unique matches
  return [...new Set(filtered)];
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use positive lookbehind to match token after a digit
  // (?<=\d) ensures there's a digit before the token
  // Also match the digit so we return the full match
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validates passwords according to policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  const symbolPattern = /^[^!@#$%^&*()_+[\]{};':"\\|,.<>/?]*$/;
  if (symbolPattern.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (like abab, abcabc, etc.)
  // This looks for patterns of 2+ characters that repeat
  for (let i = 0; i < value.length - 2; i++) {
    for (let len = 2; len <= (value.length - i) / 2; len++) {
      const substring = value.slice(i, i + len);
      const nextSubstring = value.slice(i + len, i + len * 2);
      if (substring === nextSubstring) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Special IPv6 addresses: :: (unspecified) and ::1 (loopback)
  // Use word boundary at end but need to handle : carefully
  const specialIPv6 = /::(?:1\b|\b)/;
  
  if (specialIPv6.test(value)) {
    return true;
  }
  
  // Full IPv6: 8 groups of 1-4 hex digits
  const fullIPv6 = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/;
  
  // Compressed IPv6 with ::
  const compressedIPv6 = /\b[0-9a-fA-F]{1,4}:[0-9a-fA-F:]*(?<!:)::(?!:)[0-9a-fA-F:]*/;
  
  // Check if any IPv6 pattern matches
  if (fullIPv6.test(value) || compressedIPv6.test(value)) {
    // Verify it's not just an IPv4 address
    const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
    
    // Find all potential IPv6 strings
    const potentialMatches = value.match(/\b[0-9a-fA-F:]{3,}\b/g) || [];
    
    for (const match of potentialMatches) {
      // Must contain colons
      if (!match.includes(':')) {
        continue;
      }
      
      // Skip pure IPv4
      if (ipv4Pattern.test(match)) {
        continue;
      }
      
      // Validate structure
      const parts = match.split(':');
      
      // Valid hex parts
      const allValid = parts.every(p => 
        p === '' || /^[0-9a-fA-F]{1,4}$/.test(p)
      );
      
      if (allValid && parts.length >= 3) {
        return true;
      }
    }
  }
  
  return false;
}
