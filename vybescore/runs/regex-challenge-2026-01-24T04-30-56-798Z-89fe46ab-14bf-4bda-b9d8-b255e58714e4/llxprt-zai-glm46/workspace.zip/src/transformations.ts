/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if the input omitted it.
 * Collapses extra spaces while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations that shouldn't trigger sentence capitalization
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'etc', 'vs', 'St', 'Ave'];
  const abbrPattern = new RegExp(`\\b(${abbreviations.join('|')})\\.`, 'gi');
  
  // Protect abbreviations by temporarily replacing them
  let result = text;
  const abbrPlaceholders: string[] = [];
  let abbrIndex = 0;
  
  result = result.replace(abbrPattern, (match) => {
    const placeholder = `__ABBR${abbrIndex}__`;
    abbrPlaceholders.push(match);
    abbrIndex++;
    return placeholder;
  });
  
  // First, normalize spacing: collapse multiple spaces into one
  result = result.replace(/ +/g, ' ');
  
  // Insert space after sentence endings if missing (but not before line breaks)
  result = result.replace(/([.!?])([^\s\n])/g, '$1 $2');
  
  // Capitalize first character of the string
  result = result.replace(/^[a-z]/, (char) => char.toUpperCase());
  
  // Capitalize first character after sentence-ending punctuation followed by space
  result = result.replace(/([.!?]\s)([a-z])/g, (_, punct, letter) => {
    return punct + letter.toUpperCase();
  });
  
  // Restore abbreviations
  result = result.replace(/__ABBR(\d+)__/g, (_, index) => {
    return abbrPlaceholders[parseInt(index, 10)];
  });
  
  return result;
}

/**
 * Finds URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https URLs
  const urlPattern = /https?:\/\/(?:[-\w.]|(?:%[\da-fA-F]{2})|[!*(),]|(?:[\w+]*[\w+]))+(?:[:][0-9]+)?(?:\/(?:[-\w.!~*'();:@&=+$,/?#[\]]|%[\da-fA-F]{2})*)?/gi;
  
  const urls: string[] = [];
  let match: RegExpExecArray | null;
  
  // Reset regex state
  urlPattern.lastIndex = 0;
  
  while ((match = urlPattern.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?(){}[\]"']+$/, '');
    
    // Remove trailing closing parenthesis if not part of URL
    if (url.endsWith(')') && !url.includes('(')) {
      url = url.slice(0, -1);
    }
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/\bhttp:\/\//gi, 'https://');
}

/**
 * Rewrites http://example.com/... to https://...
 * Moves docs paths to https://docs.example.com/ where applicable.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for cgi-bin, query strings, or legacy extensions
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/\bhttp:\/\/example\.com(\/[^\s]*)?/gi, (match, path) => {
    const fullPath = path || '';
    
    // Check if this should have host rewrite (docs path but no dynamic hints)
    const hasDocsPath = /^\/docs\//i.test(fullPath);
    
    // Dynamic hints that prevent host rewrite
    const hasDynamicHint = /[?&=]|\/cgi-bin\/|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(fullPath);
    
    // Always upgrade to https
    if (hasDocsPath && !hasDynamicHint) {
      return `https://docs.example.com${fullPath}`;
    } else {
      return `https://example.com${fullPath}`;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth: Record<number, number> = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  return yearStr;
}
