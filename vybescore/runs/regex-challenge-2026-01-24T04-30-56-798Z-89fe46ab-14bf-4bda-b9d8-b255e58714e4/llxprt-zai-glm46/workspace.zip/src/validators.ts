export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}(?:\.[a-zA-Z]{2,})?$/;
  
  // Additional checks for edge cases
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dot in local or domain part
  const [localPart, domainPart] = value.split('@');
  if (localPart.endsWith('.') || domainPart.endsWith('.')) {
    return false;
  }
  
  // Reject underscores in domain
  if (domainPart.includes('_')) {
    return false;
  }
  
  // Reject consecutive special characters in local part
  if (/[._%+-]{2,}/.test(localPart)) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters
  const digitsOnly = value.replace(/\D/g, '');
  
  // Remove optional +1 country code for validation
  let numberToCheck = digitsOnly;
  if (numberToCheck.startsWith('1') && numberToCheck.length === 11) {
    numberToCheck = numberToCheck.slice(1);
  }
  
  // Must be exactly 10 digits (NPA-NXX-XXXX format)
  if (numberToCheck.length !== 10) {
    return false;
  }
  
  // Area code (NPA) cannot start with 0 or 1
  const areaCode = numberToCheck.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (NXX) cannot start with 0 or 1
  const exchangeCode = numberToCheck.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate format with proper separators if they're present
  const formatRegex = /^\+?1?[\s-]?\(?[2-9]\d{2}\)?[\s-]?[2-9]\d{2}[\s-]?\d{4}(?:\s?(?:ext|x)\s?\d+)?$/i;
  if (!formatRegex.test(value.trim())) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code must be 2-4 digits (leading digit 1-9)
 * - Subscriber number must contain 6-8 digits
 * - When country code omitted, must begin with trunk prefix 0
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+? - optional + for country code
  // 54? - optional country code digits
  // (\s?0)? - optional trunk prefix 0 (with optional space before it)
  // (\s?9)? - optional mobile indicator 9 (with optional space before it)
  // ([1-9]\d{1,3}) - area code: 2-4 digits, leading digit 1-9
  // [\s-]? - optional separator
  // (\d{6,8})$ - subscriber number: 6-8 digits
  
  const patternWithCountry = /^\+?54\s?0?\s?9?([1-9]\d{1,3})\s?(\d{6,8})$/;
  const patternWithoutCountry = /^0([1-9]\d{1,3})\s?(\d{6,8})$/;
  
  const matchWithCountry = cleaned.match(patternWithCountry);
  const matchWithoutCountry = cleaned.match(patternWithoutCountry);
  
  if (matchWithCountry) {
    const [, areaCode, subscriberNumber] = matchWithCountry;
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    return true;
  }
  
  if (matchWithoutCountry) {
    const [, areaCode, subscriberNumber] = matchWithoutCountry;
    // Area code must be 2-4 digits
    if (areaCode.length < 2 || areaCode.length > 4) {
      return false;
    }
    // Subscriber number must be 6-8 digits
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
      return false;
    }
    return true;
  }
  
  return false;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Pattern: unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least 2 characters
  const nameRegex = /^[\p{L}\p{M}'\s-]{2,}$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Reject digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject special symbols (anything not a letter, mark, apostrophe, hyphen, or space)
  const invalidChars = /[^\p{L}\p{M}'\s-]/u;
  if (invalidChars.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/\p{L}/u.test(value)) {
    return false;
  }
  
  // Reject names with only special characters or spaces
  if (/^[\s'-]+$/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check that it's all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length: Visa/Mastercard are 16 digits, AmEx is 15 digits
  if (cleaned.length !== 15 && cleaned.length !== 16) {
    return false;
  }
  
  // Check prefixes and lengths
  const visaPattern = /^4\d{15}$/; // 16 digits starting with 4
  const mastercardPattern = /^5[1-5]\d{14}$/; // 16 digits starting with 51-55
  const amexPattern = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  const isValidFormat = visaPattern.test(cleaned) || 
                       mastercardPattern.test(cleaned) || 
                       amexPattern.test(cleaned);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
