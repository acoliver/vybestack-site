import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }

  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  onPageChange 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  onPageChange: (page: number) => void;
}): JSX.Element {
  const isPrevDisabled = currentPage <= 1;
  const isNextDisabled = !hasNext;
  
  return (
    <div style={{ marginTop: '1rem', display: 'flex', gap: '1rem', alignItems: 'center' }}>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={isPrevDisabled}
        style={{ 
          padding: '0.5rem 1rem',
          cursor: isPrevDisabled ? 'not-allowed' : 'pointer',
          opacity: isPrevDisabled ? 0.5 : 1
        }}
      >
        Previous
      </button>
      
      <span>Page {currentPage}</span>
      
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={isNextDisabled}
        style={{ 
          padding: '0.5rem 1rem',
          cursor: isNextDisabled ? 'not-allowed' : 'pointer',
          opacity: isNextDisabled ? 0.5 : 1
        }}
      >
        Next
      </button>
    </div>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return (
      <section>
        <h1>Inventory</h1>
        <p>Loading inventory…</p>
      </section>
    );
  }

  if (status === 'error' || !data) {
    return (
      <section>
        <h1>Inventory</h1>
        <p role="alert" style={{ color: 'red' }}>
          {error ?? 'Unable to load inventory.'}
        </p>
      </section>
    );
  }

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      
      <PaginationControls 
        currentPage={currentPage}
        hasNext={data.hasNext}
        onPageChange={setCurrentPage}
      />
      
      <div style={{ marginTop: '0.5rem', fontSize: '0.9rem', color: '#666' }}>
        Total: {data.total} items • Limit: {data.limit} per page
      </div>
    </section>
  );
}
