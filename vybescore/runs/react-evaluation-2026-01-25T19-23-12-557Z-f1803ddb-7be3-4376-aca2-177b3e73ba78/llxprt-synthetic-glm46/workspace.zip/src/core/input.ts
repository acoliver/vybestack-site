/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  registerDependency,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Initialize with both regular and dependent observers sets
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    observers: new Set(),
    dependentObservers: new Set(),
  }

  const read: GetterFn<T> = () => {
    // Register this input as a dependency for the current observer
    registerDependency(s)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // Notify all observers when value changes
    notifyObservers(s)
    
    return s.value
  }

  return [read, write]
}
