/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  updateObserver,
  registerDependency,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Store dependent observers that depend on this computed value
  const dependentObservers = new Set<ObserverR>()
  
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create a subject to track this computed value's observers
  const computedSubject = {
    observers: new Set<ObserverR>(),
    dependentObservers,
  }
  
  // Initial computation
  updateObserver(observer)
  
  const getter: GetterFn<T> = () => {
    // Register this computed as a dependency when accessed
    registerDependency(computedSubject)
    
    return observer.value!
  }
  
  // Store the observer reference on the getter for direct access
  ;(getter as unknown as { _observer: Observer<T> })._observer = observer
  ;(getter as unknown as { _subject: { observers: Set<ObserverR>; dependentObservers: Set<ObserverR> } })._subject = computedSubject
  
  // Override the observer's update function to notify dependents
  const originalUpdateFn = observer.updateFn
  observer.updateFn = (prevValue?: T) => {
    const result = originalUpdateFn(prevValue)
    
    // Notify all dependent observers
    notifyObservers(computedSubject)
    
    return result
  }
  
  return getter
}
