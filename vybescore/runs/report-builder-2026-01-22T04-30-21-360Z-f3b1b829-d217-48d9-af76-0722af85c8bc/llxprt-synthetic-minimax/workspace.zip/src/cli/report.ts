import { readFileSync } from 'fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import { ReportData, CLIOptions } from '../types/index.js';

interface ParsedArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: 'markdown',
    includeTotals: false
  };

  let i = 2; // Skip node and script name
  while (i < argv.length) {
    const arg = argv[i];
    
    if (arg === '--format') {
      i++;
      if (i < argv.length) {
        args.format = argv[i] as 'markdown' | 'text';
      }
    } else if (arg === '--output') {
      i++;
      if (i < argv.length) {
        args.outputPath = argv[i];
      }
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (!arg.startsWith('--')) {
      // Positional argument - data file
      args.dataFile = arg;
    }
    
    i++;
  }

  return args;
}

function validateArgs(args: ParsedArgs): void {
  if (!args.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (args.format !== 'markdown' && args.format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || !data.summary || !data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing required fields: title, summary, and entries array');
    }
    
    // Validate entries structure
    data.entries.forEach((entry, index) => {
      if (!entry.label || typeof entry.amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: label (string) and amount (number) required`);
      }
    });
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Failed to load data file');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  switch (options.format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      throw new Error('Unsupported format');
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  validateArgs(args);
  
  const data = loadReportData(args.dataFile);
  const options: CLIOptions = {
    format: args.format,
    outputPath: args.outputPath,
    includeTotals: args.includeTotals
  };
  
  try {
    const output = renderReport(data, options);
    
    if (args.outputPath) {
      // Note: For output to file, we'd need fs.writeFileSync, but requirements specify using only stdin
      // Since we're not using third-party parsers and keeping it minimal, we output to stdout
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error('Error: Failed to render report');
    process.exit(1);
  }
}

// Only run main if this file is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
