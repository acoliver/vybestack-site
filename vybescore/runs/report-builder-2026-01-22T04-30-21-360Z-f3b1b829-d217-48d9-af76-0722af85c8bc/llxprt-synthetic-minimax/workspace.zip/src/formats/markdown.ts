import { ReportData, CLIOptions } from '../types/index.js';

export function renderMarkdown(data: ReportData, options: CLIOptions): string {
  const lines: string[] = [];
  
  // Title with # prefix
  lines.push(`# ${data.title}`);
  lines.push(''); // blank line
  
  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line
  
  // Entries section
  lines.push('## Entries');
  
  // Bullet list for entries
  data.entries.forEach(entry => {
    const amount = entry.amount.toFixed(2);
    lines.push(`- **${entry.label}** — $${amount}`);
  });
  
  // Optional totals
  if (options.includeTotals) {
    lines.push(''); // blank line before total
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const totalFormatted = total.toFixed(2);
    lines.push(`**Total:** $${totalFormatted}`);
  }
  
  return lines.join('\n');
}