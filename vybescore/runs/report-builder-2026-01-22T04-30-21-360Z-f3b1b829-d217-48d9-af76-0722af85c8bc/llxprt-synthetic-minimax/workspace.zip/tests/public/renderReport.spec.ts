import { describe, expect, it } from 'vitest';
import { execSync } from 'node:child_process';
import { existsSync } from 'node:fs';

describe('report CLI (public smoke)', () => {
  const cliPath = 'dist/cli/report.js';
  
  it('renders markdown format with totals', () => {
    const output = execSync(
      `node ${cliPath} fixtures/data.json --format markdown --includeTotals`,
      { encoding: 'utf-8' }
    );
    
    expect(output).toContain('# Quarterly Financial Summary');
    expect(output).toContain('## Entries');
    expect(output).toContain('**North Region** — $12345.67');
    expect(output).toContain('**South Region** — $23456.78');
    expect(output).toContain('**West Region** — $34567.89');
    expect(output).toContain('**Total:** $70370.34');
  });

  it('renders text format with totals', () => {
    const output = execSync(
      `node ${cliPath} fixtures/data.json --format text --includeTotals`,
      { encoding: 'utf-8' }
    );
    
    expect(output).toContain('Quarterly Financial Summary');
    expect(output).toContain('Entries:');
    expect(output).toContain('North Region: $12345.67');
    expect(output).toContain('South Region: $23456.78');
    expect(output).toContain('West Region: $34567.89');
    expect(output).toContain('Total: $70370.34');
  });

  it('renders markdown format without totals', () => {
    const output = execSync(
      `node ${cliPath} fixtures/data.json --format markdown`,
      { encoding: 'utf-8' }
    );
    
    expect(output).toContain('# Quarterly Financial Summary');
    expect(output).toContain('## Entries');
    expect(output).toContain('**North Region** — $12345.67');
    expect(output).not.toContain('**Total:**');
  });

  it('renders text format without totals', () => {
    const output = execSync(
      `node ${cliPath} fixtures/data.json --format text`,
      { encoding: 'utf-8' }
    );
    
    expect(output).toContain('Quarterly Financial Summary');
    expect(output).toContain('Entries:');
    expect(output).toContain('North Region: $12345.67');
    expect(output).not.toContain('Total:');
  });

  it('handles malformed JSON file', () => {
    try {
      execSync(
        `node ${cliPath} fixtures/malformed.json --format markdown`,
        { encoding: 'utf-8', stdio: 'pipe' }
      );
      fail('Expected process to exit with error');
    } catch (error) {
      const stderr = String(error).toLowerCase();
      expect(stderr).toMatch(/error/);
    }
  });

  it('handles JSON syntax error', () => {
    try {
      execSync(
        `node ${cliPath} fixtures/syntax-error.json --format markdown`,
        { encoding: 'utf-8', stdio: 'pipe' }
      );
      fail('Expected process to exit with error');
    } catch (error) {
      const stderr = String(error).toLowerCase();
      expect(stderr).toMatch(/invalid json|error/);
    }
  });

  it('rejects unknown format', () => {
    try {
      execSync(
        `node ${cliPath} fixtures/data.json --format unknown`,
        { encoding: 'utf-8', stdio: 'pipe' }
      );
      fail('Expected process to exit with error');
    } catch (error) {
      const stderr = String(error).toLowerCase();
      expect(stderr).toMatch(/unsupported format/);
    }
  });

  it('handles missing data file', () => {
    try {
      execSync(
        `node ${cliPath} missing-file.json --format markdown`,
        { encoding: 'utf-8', stdio: 'pipe' }
      );
      fail('Expected process to exit with error');
    } catch (error) {
      const stderr = String(error).toLowerCase();
      expect(stderr).toMatch(/missing|unable|enoent|not found/);
    }
  });

  it('compiles to dist directory', () => {
    expect(existsSync(cliPath)).toBe(true);
  });
});
