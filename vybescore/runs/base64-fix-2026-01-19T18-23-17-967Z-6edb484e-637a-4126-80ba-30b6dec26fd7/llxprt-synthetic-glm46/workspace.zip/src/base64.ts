const VALID_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const DECODING_FAILED_ERROR = 'Invalid Base64 input: decoding failed';
const EMPTY_INPUT_ERROR = 'Invalid Base64 input: empty string';
const INVALID_CHARACTERS_ERROR = 'Invalid Base64 input: contains invalid characters';
const INCORRECT_LENGTH_ERROR = 'Invalid Base64 input: incorrect length';
const PADDING_REGEX = /=+$/;

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Rejects clearly invalid payloads by throwing an error.
 */
export function decode(input: string): string {
  if (!input.trim()) {
    throw new Error(EMPTY_INPUT_ERROR);
  }

  // Check if input contains only valid Base64 characters
  if (!VALID_BASE64_REGEX.test(input)) {
    throw new Error(INVALID_CHARACTERS_ERROR);
  }

  // Validate padding structure
  validatePadding(input);

  try {
    const result = Buffer.from(input, 'base64').toString('utf8');
    // Verify the decode was successful by encoding back and comparing
    // This catches cases where Node.js might silently accept malformed input
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    // Normalize both strings for comparison (remove padding from our input)
    const normalizedInput = input.replace(PADDING_REGEX, '');
    const normalizedReencoded = reencoded.replace(PADDING_REGEX, '');
    if (normalizedInput !== normalizedReencoded) {
      throw new Error(DECODING_FAILED_ERROR);
    }
    return result;
  } catch (error) {
    if (error instanceof Error && error.message === DECODING_FAILED_ERROR) {
      throw error;
    }
    throw new Error(DECODING_FAILED_ERROR);
  }
}

/**
 * Validates Base64 padding structure.
 * If there are padding characters, checks that padding is valid.
 */
function validatePadding(input: string): void {
  const paddingMatch = input.match(PADDING_REGEX);
  if (paddingMatch && paddingMatch.index !== undefined) {
    const paddingIndex = paddingMatch.index;
    // Padding can only appear at the end
    if (paddingIndex + paddingMatch[0].length !== input.length) {
      throw new Error(INCORRECT_LENGTH_ERROR);
    }
    // Check that padding length is valid (1 or 2 characters)
    if (paddingMatch[0].length > 2) {
      throw new Error(INCORRECT_LENGTH_ERROR);
    }
  }
}
