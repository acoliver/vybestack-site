export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like user@example.co.uk, name@tag.example.com
 * Rejects: double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Trim whitespace
  const email = value.trim();

  // Basic email regex with constraints:
  // - No double dots anywhere
  // - No trailing dot in local or domain part
  // - No underscores in domain
  // - Valid characters in local part
  // - At least one dot in domain for TLD
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)+$/;

  if (!emailRegex.test(email)) return false;

  // Check for double dots (..) anywhere
  if (email.includes('..')) return false;

  // Check for trailing dot
  if (email.endsWith('.')) return false;

  // Check domain part doesn't start or end with hyphen or dot
  const [, domain] = email.split('@');
  if (!domain) return false;

  // No underscores in domain
  if (domain.includes('_')) return false;

  // Domain labels can't start or end with hyphen
  const labels = domain.split('.');
  for (const label of labels) {
    if (label.startsWith('-') || label.endsWith('-')) return false;
    if (label.length === 0) return false;
  }

  // Check for consecutive dots in domain
  if (domain.includes('..') || domain.startsWith('.') || domain.endsWith('.')) return false;

  // Local part can't start or end with dot
  const [local] = email.split('@');
  if (local.startsWith('.') || local.endsWith('.')) return false;

  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats like:
 * - (212) 555-7890
 * - 212-555-7890
 * - 2125557890
 * - +1 212-555-7890 (optional country code)
 *
 * Disallows: impossible area codes (leading 0 or 1), too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all whitespace and common separators to extract digits
  const digitsOnly = value.replace(/[\s\-().]/g, '');

  // Extract digits for validation
  const digitMatch = digitsOnly.match(/\d+/g);
  if (!digitMatch) return false;

  const digits = digitMatch.join('');

  // With optional +1 country code, we should have 11 or 10 digits
  // Without +1, we expect exactly 10 digits
  // With +1, we expect exactly 11 digits (starting with 1)
  const hasCountryCode = digits.startsWith('1');
  const expectedLength = hasCountryCode ? 11 : 10;

  if (digits.length !== expectedLength) return false;

  // Extract the actual phone number (without country code if present)
  const phoneNumber = hasCountryCode ? digits.slice(1) : digits;

  if (phoneNumber.length !== 10) return false;

  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.slice(0, 3);

  // Area code can't start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;

  // Exchange code (next 3 digits) also can't start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;

  // If extensions not allowed, check for 'ext' or similar
  if (options?.allowExtensions !== true) {
    const lowerValue = value.toLowerCase();
    if (/\b(ext|x|#)\s*\d+/.test(lowerValue)) {
      // This could be valid if extensions are allowed, but we need to check the base number
      // For now, we'll consider it valid if the base number passes
    }
  }

  return true;
}

/**
 * Validate Argentine phone numbers.
 * Supports landlines and mobiles:
 * - +54 9 11 1234 5678 (mobile with country code, mobile indicator)
 * - 011 1234 5678 (Buenos Aires, no country code)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline without country code, with trunk prefix)
 *
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code (required if no country code)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit must be 1-9
 * - Subscriber number: 6-8 digits total after area code
 * - Separators: single spaces or hyphens allowed
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove all separators (spaces, hyphens) for validation
  const normalized = value.replace(/[\s-]/g, '');

  // Comprehensive regex for Argentine phone numbers
  // Group 1: Optional +54 country code
  // Group 2: Trunk prefix 0 (required if no country code)
  // Group 3: Optional mobile indicator 9
  // Group 4: Area code (2-4 digits, leading 1-9)
  // Group 5: Subscriber number (6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;

  const match = normalized.match(argentinePhoneRegex);
  if (!match) return false;

  const [, trunkPrefix, , areaCode, subscriberNumber] = match;

  // If no country code, trunk prefix must be present
  const hasCountryCode = normalized.startsWith('+54');
  if (!hasCountryCode && !trunkPrefix) {
    return false;
  }

  // Validate area code length (2-4 digits)
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }

  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }

  return true;
}

/**
 * Validate personal names.
 * Allows: unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects: digits, symbols, and invalid names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  const trimmed = value.trim();

  if (trimmed.length === 0) return false;

  // Regex for valid names:
  // - Unicode letters (\p{L}) including accented characters
  // - Apostrophes for names like O'Connor
  // - Hyphens for hyphenated names
  // - Spaces for multiple names
  // - Must have at least one letter
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;

  if (!nameRegex.test(trimmed)) return false;

  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(trimmed);
  if (!hasLetter) return false;

  // Reject names with digits
  if (/\d/.test(trimmed)) return false;

  // Reject common invalid patterns
  // - Multiple consecutive special characters
  if (/'{2,}|-{2,}/.test(trimmed)) return false;

  // - Starting or ending with apostrophe/hyphen
  if (/^['\-\s]|['\-\s]$/.test(trimmed)) return false;

  return true;
}

/**
 * Luhn algorithm helper for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);

  let sum = 0;
  let shouldDouble = false;

  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];

    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }

    sum += digit;
    shouldDouble = !shouldDouble;
  }

  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa, Mastercard, AmEx formats.
 * Validates:
 * - Correct prefixes for each card type
 * - Correct lengths
 * - Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');

  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;

  // Check length (13-19 digits typically)
  if (cleaned.length < 13 || cleaned.length > 19) return false;

  // Card type patterns
  const patterns = {
    visa: /^4\d{12}(\d{3})?$/, // 13 or 16 digits, starts with 4
    mastercard: /^5[1-5]\d{14}$/, // 16 digits, starts with 51-55
    amex: /^3[47]\d{13}$/, // 15 digits, starts with 34 or 37
  };

  // Check if matches any valid pattern
  const matchesPattern =
    patterns.visa.test(cleaned) ||
    patterns.mastercard.test(cleaned) ||
    patterns.amex.test(cleaned);

  if (!matchesPattern) return false;

  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
