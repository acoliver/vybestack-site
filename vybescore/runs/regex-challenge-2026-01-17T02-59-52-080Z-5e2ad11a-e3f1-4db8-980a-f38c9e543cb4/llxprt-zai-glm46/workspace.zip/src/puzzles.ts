/**
 * Find words starting with a prefix, excluding specified exceptions.
 * Returns array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  if (!Array.isArray(exceptions)) return [];

  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Pattern to match words starting with prefix (using word boundaries)
  // Word boundary \b matches at the transition between word and non-word characters
  const pattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');

  const matches = text.match(pattern) || [];

  // Filter out exceptions and deduplicate
  const exceptionSet = new Set(exceptions);

  return matches
    .filter((word) => !exceptionSet.has(word))
    .filter((word, index, arr) => arr.indexOf(word) === index);
}

/**
 * Find occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookahead/lookbehind to ensure proper positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];

  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Use positive lookbehind to ensure token is preceded by a digit
  // This ensures the token is embedded (not at the start)
  // Use \b to ensure we match the full token including the digit
  const pattern = new RegExp(`\\d${escapedToken}\\b`, 'g');

  const matches = text.match(pattern) || [];

  return matches;
}

/**
 * Validate password strength.
 * Requirements:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // Minimum length
  if (value.length < 10) return false;

  // Check for whitespace
  if (/\s/.test(value)) return false;

  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) return false;

  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) return false;

  // Check for at least one digit
  if (!/\d/.test(value)) return false;

  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;

  // Check for repeated sequences (like abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  for (let len = 2; len <= 4; len++) {
    const pattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (pattern.test(value)) {
      return false;
    }
  }

  return true;
}

/**
 * Detect IPv6 addresses.
 * Handles:
 * - Full IPv6 addresses (8 groups of 4 hex digits)
 * - Shorthand with :: (zero compression)
 * - Leading zeros can be omitted
 * Excludes:
 * - IPv4 addresses (even if they might match partially)
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;

  // First, check for obvious IPv4 addresses to exclude them
  // IPv4 pattern: 4 groups of 1-3 digits, separated by dots
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }

  // IPv6 patterns
  // Full form: 8 groups of 1-4 hex digits, separated by colons
  const fullIpv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;

  // Compressed form with ::
  // Can appear at start, end, or middle
  const compressedIpv6Pattern = /^(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}$/;

  // Check for IPv6 pattern anywhere in the string (not just whole string)
  // Use word boundaries or look for patterns in isolation

  // Try exact match first
  if (fullIpv6Pattern.test(value.trim()) || compressedIpv6Pattern.test(value.trim())) {
    return true;
  }

  // Check for IPv6 pattern within the string
  // Look for patterns like xxxx:xxxx or with ::
  const embeddedFullPattern = /[0-9a-fA-F]{1,4}:[0-9a-fA-F]{1,4}/;
  const embeddedCompressedPattern = /[0-9a-fA-F]{1,4}:*::[0-9a-fA-F:]*/;

  if (embeddedFullPattern.test(value) || embeddedCompressedPattern.test(value)) {
    // Make sure it's not actually just an IPv4 address
    if (ipv4Pattern.test(value.trim())) {
      return false;
    }
    return true;
  }

  // Also check for common IPv6 formats with brackets (used in URLs)
  const bracketPattern = /\[([0-9a-fA-F:]+)\]/;
  const bracketMatch = value.match(bracketPattern);
  if (bracketMatch) {
    const ipv6Part = bracketMatch[1];
    if (fullIpv6Pattern.test(ipv6Part) || compressedIpv6Pattern.test(ipv6Part)) {
      return true;
    }
  }

  return false;
}
