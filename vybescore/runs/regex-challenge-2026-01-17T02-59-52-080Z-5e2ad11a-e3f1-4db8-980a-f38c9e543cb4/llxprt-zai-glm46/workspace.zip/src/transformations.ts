/**
 * Capitalize the first character of each sentence.
 * Rules:
 * - Capitalize after sentence-ending punctuation (.!?)
 * - Insert exactly one space between sentences if missing
 * - Collapse multiple spaces into single spaces
 * - Preserve abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';

  let result = text;

  // First, normalize spacing around punctuation
  // Insert a space after sentence endings if there isn't one (but not before closing quotes/brackets)
  result = result.replace(/([.!?])([a-zA-Z])/g, '$1 $2');

  // Collapse multiple spaces into single spaces
  result = result.replace(/ +/g, ' ');

  // Capitalize first character of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);

  // Capitalize after sentence-ending punctuation
  // Look for .!? followed by optional quote and then a letter
  result = result.replace(/([.!?])\s*(["']?)([a-z])/g, (_match, punct, quote, letter) => {
    return punct + ' ' + quote + letter.toUpperCase();
  });

  return result;
}

/**
 * Extract all URLs from the text.
 * Returns URLs without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];

  // URL pattern matching http, https, and www
  // Excludes trailing punctuation like .,;:?!()
  const urlPattern = /(?:https?:\/\/|www\.)[a-zA-Z0-9\-._~:/?#[\]@!$&'()*+,;=%]+[a-zA-Z0-9\-_~:/?#[\]@!$&'()*+,;=%]/gi;

  const matches = text.match(urlPattern) || [];

  // Clean up trailing punctuation
  return matches.map((url) => {
    // Remove trailing punctuation that's not part of URL
    return url.replace(/[.,;:!?()[\]{}"']+$/, '');
  }).filter((url) => url.length > 0);
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite documentation URLs.
 * Rules:
 * - Always upgrade scheme to https://
 * - For URLs with path starting with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for:
 *   - URLs containing cgi-bin
 *   - URLs with query strings (?, &, =)
 *   - URLs with legacy extensions (.jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';

  // Pattern to match http://example.com URLs
  // Captures: scheme, domain, and path
  const urlPattern = /(http:\/\/)(example\.com)(\/[^\s]*)?/gi;

  const result = text.replace(urlPattern, (_match, scheme, domain, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';

    // Check if we should skip host rewrite
    const shouldSkipHostRewrite = shouldSkipRewrite(path);

    if (shouldSkipHostRewrite) {
      // Just upgrade the scheme
      return newScheme + domain + path;
    }

    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.example.com' + path;
    }

    // Just upgrade the scheme
    return newScheme + domain + path;
  });

  return result;
}

/**
 * Helper to determine if a URL path should skip host rewrite.
 */
function shouldSkipRewrite(path: string): boolean {
  // Skip if contains cgi-bin
  if (path.includes('/cgi-bin/')) return true;

  // Skip if has query string
  if (/[?&=]/.test(path)) return true;

  // Skip if has legacy extension
  const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
  for (const ext of legacyExtensions) {
    if (path.includes(ext)) return true;
  }

  return false;
}

/**
 * Extract the year from mm/dd/yyyy format.
 * Returns 'N/A' if format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';

  // Match mm/dd/yyyy format
  const dateMatch = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);

  if (!dateMatch) return 'N/A';

  const [, monthStr, dayStr, year] = dateMatch;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDays = daysInMonth[month - 1];

  if (day < 1 || day > maxDays) return 'N/A';

  return year;
}
