import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CLIOptions {
  format: 'markdown' | 'text';
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): { dataFile: string; options: CLIOptions } {
  if (argv.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataFile = argv[2];
  const options: CLIOptions = {
    format: 'markdown',
    includeTotals: false
  };

  for (let i = 3; i < argv.length; i++) {
    const arg = argv[i];
    
    if (arg === '--format') {
      if (i + 1 >= argv.length) {
        throw new Error('--format requires a value');
      }
      const format = argv[i + 1];
      if (format !== 'markdown' && format !== 'text') {
        throw new Error(`Unsupported format: ${format}`);
      }
      options.format = format as 'markdown' | 'text';
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= argv.length) {
        throw new Error('--output requires a value');
      }
      options.output = argv[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  return { dataFile, options };
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const report = data as Record<string, unknown>;

  if (typeof report.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (expected string)');
  }

  if (typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < report.entries.length; i++) {
    const entry = report.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${i}] is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${i}] is missing "label" field (expected string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${i}] is missing "amount" field (expected number)`);
    }
  }
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    validateReportData(data);
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('Invalid JSON:')) {
        throw error;
      }
      throw new Error(`Failed to read JSON file: ${error.message}`);
    }
    throw new Error('Failed to read JSON file: unknown error');
  }
}

function renderReport(data: ReportData, options: CLIOptions): string {
  const formatter = options.format === 'markdown' ? renderMarkdown : renderText;
  return formatter.render(data, { includeTotals: options.includeTotals });
}

function main(): void {
  try {
    const { dataFile, options } = parseArgs(process.argv);
    const reportData = loadReportData(dataFile);
    const output = renderReport(reportData, options);

    if (options.output) {
      writeFileSync(options.output, output);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
    } else {
      console.error('An unknown error occurred');
    }
    process.exit(1);
  }
}

main();