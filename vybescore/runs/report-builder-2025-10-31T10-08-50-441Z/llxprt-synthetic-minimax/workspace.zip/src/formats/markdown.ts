import { ReportData, RenderOptions, Formatter } from '../types.js';

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

const calculateTotal = (entries: ReportData['entries']): number => {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
};

export const renderMarkdown: Formatter = {
  render: (data: ReportData, options: RenderOptions): string => {
    const lines: string[] = [];
    
    // Title
    lines.push(`# ${data.title}`);
    lines.push('');
    
    // Summary
    lines.push(data.summary);
    lines.push('');
    
    // Entries section
    lines.push('## Entries');
    
    // Entry bullets
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push('');
      lines.push(`**Total:** ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  }
};