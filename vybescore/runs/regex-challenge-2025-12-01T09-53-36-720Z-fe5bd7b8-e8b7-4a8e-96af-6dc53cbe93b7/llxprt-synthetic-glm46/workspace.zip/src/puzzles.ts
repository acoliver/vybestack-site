/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 * Returns words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape the prefix for regex
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create regex pattern to match words with the prefix
  const wordRegex = new RegExp(`\\b${escapedPrefix}\\w*\\b`, 'g');
  
  // Find all matches
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => 
    !exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    )
  );
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds as specified.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape the token for regex
  const escapedToken = token.replace(/[.*+?^${}()|[\\]\\]/g, '\\$&');
  
  // Create regex pattern to match token only when preceded by a digit and not at string start
  // The pattern should capture the digit as well to ensure the full match is returned
  const tokenRegex = new RegExp(`(?<!^)(\\d)${escapedToken}`, 'g');
  
  // Find all matches
  const matches = [];
  let match;
  while ((match = tokenRegex.exec(text)) !== null) {
    matches.push(match[0]);
  }
  
  return matches;
}

/**
 * Validates a password for strength based on specific criteria:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (!value || value.length < 10) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (special character)
  if (!/[!@#$%^&*()_+-=[\]{};'"/|,.<>/?]/.test(value)) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abcabc)
  // Check if any substring of length 2 or more is immediately repeated
  for (let i = 1; i <= Math.floor(value.length / 2); i++) {
    for (let j = 0; j <= value.length - 2 * i; j++) {
      const substring = value.substring(j, j + i);
      if (value.substring(j + i, j + 2 * i) === substring) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses in the given text.
 * Does not flag IPv4 addresses as IPv6.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that covers:
  // - Full IPv6 with all 8 groups of hex digits
  // - Shortened IPv6 with :: for zero groups
  // - IPv6 with embedded IPv4 addresses
  
  // First check for an exact IPv4 address to avoid false positives
  const ipv4Pattern = /^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
  if (ipv4Pattern.test(value)) return false;
  
  // Now check for IPv6 pattern
  const ipv6Pattern = /[0-9a-fA-F]{1,4}(:[0-9a-fA-F]{1,4}){7}|::|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{1}[0-9])[0-9])\.){3}(25[0-5]|(2[0-4]|1{1}[0-9])[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{1}[0-9])[0-9])\.){3}(25[0-5]|(2[0-4]|1{1}[0-9])[0-9])\b/;
  
  return ipv6Pattern.test(value);
}