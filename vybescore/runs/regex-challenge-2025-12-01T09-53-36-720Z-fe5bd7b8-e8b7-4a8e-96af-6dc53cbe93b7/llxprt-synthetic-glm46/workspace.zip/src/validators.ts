export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regex patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex that covers most valid cases while rejecting obvious invalid ones
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Reject empty strings
  if (!value || value.trim() === '') return false;
  
  // Reject leading or trailing whitespace
  if (value !== value.trim()) return false;
  
  // Reject domains with underscores
  if (value.includes('_')) return false;
  
  // Reject consecutive dots
  if (value.includes('..')) return false;
  
  // Reject leading or trailing dots
  if (value.startsWith('.') || value.endsWith('.')) return false;
  
  // Check if it matches the email regex
  if (!emailRegex.test(value)) return false;
  
  // Validate each label in the domain
  const [, domain] = value.split('@');
  const domainLabels = domain.split('.');
  
  // Each label must be 1-63 characters and start/end with alphanumeric
  for (const label of domainLabels) {
    if (label.length === 0 || label.length > 63) return false;
    if (!/^[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/.test(label)) return false;
  }
  
  return true;
}

/**
 * Validates a US phone number using regex patterns.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || value.trim() === '') return false;
  
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check if it contains a country code (+1)
  const hasCountryCode = value.startsWith('+1') || (digitsOnly.length === 11 && digitsOnly.startsWith('1'));
  
  // Extract the main 10-digit number
  const phoneNumber = hasCountryCode ? digitsOnly.slice(1) : digitsOnly;
  
  // Must be exactly 10 digits after removing country code
  if (phoneNumber.length !== 10) return false;
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate format based on what was provided
  if (options?.allowExtensions) {
    // If extensions are allowed, we need a more flexible pattern
    const phonePattern = /^(?:\+?1[\s-]?)?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[\s-]?(\d{4})(?:\s*(?:ext\.?|extension|x|#)\s*\d+)?$/i;
    return phonePattern.test(value.trim());
  } else {
    // Standard phone validation patterns
    const patterns = [
      // (212) 555-7890 or (212)555-7890
      /^\(\s*([2-9]\d{2})\s*\)\s*([2-9]\d{2})[-\s]?(\d{4})$/,
      // 212-555-7890
      /^([2-9]\d{2})[-\s]?([2-9]\d{2})[-\s]?(\d{4})$/,
      // 2125557890
      /^\d{10}$/,
      // +1 212-555-7890 or +12125557890
      /^\+?1[\s-]?\(?([2-9]\d{2})\)?[\s-]?([2-9]\d{2})[-\s]?(\d{4})$/
    ];
    
    return patterns.some(pattern => pattern.test(value.trim()));
  }
}

/**
 * Validates an Argentine phone number.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || value.trim() === '') return false;
  
  // Remove all separators (spaces, hyphens, etc.) for validation
  const cleanedValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex pattern
  // ^(?:\+54)?: optional country code +54
  // \s*(?:0)?: optional trunk prefix 0
  // \s*(?:9)?: optional mobile indicator 9
  // \s*([1-9]\d{1,3}): area code (2-4 digits, starts with 1-9)
  // \s*(\d{6,8}): subscriber number (6-8 digits)
  
  // Try the more permissive pattern that handles all cases
  const generalPattern = /^\+54\s*(?:0)?\s*(?:9)?\s*([1-9]\d{1,3})\s*(\d{6,8})$|^0\s*([1-9]\d{1,3})\s*(\d{6,8})$/;
  
  // Check if it matches the pattern
  const match = generalPattern.exec(cleanedValue);
  if (!match) return false;
  
  // Extract area code and subscriber number
  const areaCode = match[1] || match[3];
  const subscriberNumber = match[2] || match[4];
  
  // Validate area code (2-4 digits, doesn't start with 0)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) return false;
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriberNumber)) return false;
  
  return true;
}

/**
 * Validates a name using regex patterns.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Reject empty strings or strings with only whitespace
  if (!value || value.trim() === '') return false;
  
  // Check for digits
  if (/\d/.test(value)) return false;
  
  // Check for disallowed symbols (excluding apostrophe, hyphen, and whitespace)
  const disallowedSymbols = /[!"#$%&()*+,./:;<=>?@[]^_`{|}~]/;
  if (disallowedSymbols.test(value)) return false;
  
  // Name validation regex:
  // - Allows Unicode letters (including accented characters)
  // - Allows apostrophes, hyphens, and spaces
  // - Requires at least one letter
  // - Disallows consecutive spaces, apostrophes, or hyphens at the beginning or end
  const nameRegex = /^[a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]+(?:[ '-][a-zA-Z\u00C0-\u024F\u1E00-\u1EFF]+)*$/;
  
  // Check for invalid patterns at the beginning or end
  if (value.startsWith(" ") || value.startsWith("-") || value.startsWith("'")) return false;
  if (value.endsWith(" ") || value.endsWith("-") || value.endsWith("'")) return false;
  
  // Disallow consecutive spaces, hyphens, or apostrophes
  if (value.includes("  ") || value.includes("--") || value.includes("''")) return false;
  
  // Check against the validation regex
  if (!nameRegex.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let shouldDouble = false;
  
  // Iterate from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates a credit card number using regex patterns and Luhn checksum.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Basic length check (most cards are 13-19 digits)
  if (cardNumber.length < 13 || cardNumber.length > 19) return false;
  
  // Major credit card patterns
  const cardPatterns = [
    // Visa: 4 followed by 12-15 digits (13-16 digits total)
    /^4(\d{12}|\d{15})$/,
    // Mastercard: 2221-2720 or 51-55 followed by 14 digits (16 digits total)
    /^(2221|2720|[3-6]\d{2})\d{12}$/,
    // American Express: 34 or 37 followed by 13 digits (15 digits total)
    /^(34|37)\d{13}$/,
    // Discover: 6011, 622126-622925, 644-649, or 65 followed by 16 digits
    /^(6011|622126|622925|6[44-9]|65)\d{14}$/,
    // Diners Club: 300-305, 36, or 38-39 followed by 12-14 digits
    /^(3(0[0-5]|6|8[0-9])\d{11,12})$/,
    // JCB: 3528-3589 followed by 13-16 digits
    /^(352[8-9]|35[3-8][0-9]|359[0-9])\d{12,15}$/
  ];
  
  // Check if it matches any card pattern
  const isValidPattern = cardPatterns.some(pattern => pattern.test(cardNumber));
  if (!isValidPattern) return false;
  
  // Run Luhn checksum validation
  return runLuhnCheck(cardNumber);
}