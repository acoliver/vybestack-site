/**
 * Capitalizes the first character of each sentence.
 * After punctuation marks (.?!), inserts exactly one space between sentences even if the input omitted it,
 * and collapses extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty or whitespace-only strings
  if (!text || text.trim() === '') return text;
  
  // Common abbreviations that might be mistaken for sentence ends
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'St', 'Mt', 'etc', 'e.g', 'i.e', 'vs', 'al', 'ca', 'cf', 'ed', 'est', 'etc', 'No', 'pp', 'ref', 'vol', 'v', 'vs', 'w/i'];
  const abbreviationsPattern = new RegExp(`\\b(${abbreviations.join('|')})\\.`, 'g');
  
  // Replace punctuation with a marker for abbreviations to avoid splitting
  const markedText = text.replace(abbreviationsPattern, (match) => match.replace('.', '__ABBREV_DOT__'));
  
  // Split by sentence delimiters (. ? !) followed by any number of whitespace
  const sentences = markedText.split(/([.?!])/);
  
  // Process each sentence
  const processedSentences: string[] = [];
  let currentSentence = '';
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part && /[.?!]/.test(part)) {
      // This is ending punctuation
      currentSentence += part;
      
      // Capitalize and add to result
      if (currentSentence.trim()) {
        // Replace abbreviation marker back to dot
        let sentence = currentSentence.replace(/__ABBREV_DOT__/g, '.');
        
        // Collapse extra spaces
        sentence = sentence.replace(/\s+/g, ' ').trim();
        
        // Capitalize first character
        sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
        
        processedSentences.push(sentence);
        currentSentence = '';
      }
    } else {
      // This is sentence content
      if (i === sentences.length - 1) {
        // This is the last part without punctuation
        currentSentence += part;
        
        if (currentSentence.trim()) {
          // Replace abbreviation marker back to dot
          let sentence = currentSentence.replace(/__ABBREV_DOT__/g, '.');
          
          // Collapse extra spaces
          sentence = sentence.replace(/\s+/g, ' ').trim();
          
          // Capitalize first character
          sentence = sentence.charAt(0).toUpperCase() + sentence.slice(1);
          
          processedSentences.push(sentence);
        }
      } else {
        currentSentence += part;
      }
    }
  }
  
  // Join sentences with a single space
  let result = processedSentences.join(' ');
  
  // Final cleanup of any remaining markers
  result = result.replace(/__ABBREV_DOT__/g, '.');
  
  return result;
}

/**
 * Finds URLs in the text and returns them as an array.
 * Returns all URLs detected in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs
  // - Starts with http:// or https:// or www.
  // - Includes domain with optional subdomains
  // - Includes optional port
  // - Includes path and query
  const urlRegex = /\b(?:https?:\/\/|www\.)[^\s/$.?#].[^\s]*\b/gi;
  
  // Find all matches
  const matches = text.match(urlRegex) || [];
  
  // Clean up each URL by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation characters that are not part of the URL
    return url.replace(/[.,;:?)[\]}>]+$/g, '');
  });
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to specific rules:
 * - Always upgrades the scheme to https://.
 * - When the path begins with /docs/, rewrites the host to docs.example.com
 * - Skips the host rewrite when the path contains dynamic hints such as cgi-bin,
 *   query strings, or legacy extensions like .jsp, .php, etc.
 * - Preserves nested paths.
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com/... URLs
  const urlRegex = /(\bhttp:\/\/)([a-zA-Z0-9.-]+)(\/[a-zA-Z0-9/._?&=%-]*)?/g;
  
  return text.replace(urlRegex, (match, scheme, host, path = '') => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Pattern to check if we should skip the host rewrite
    const skipRewritePattern = /\/(cgi-bin|.*\?.*|.*&.*|.*=.*|.*\.(jsp|php|asp|aspx|do|cgi|pl|py))/i;
    
    if (path.startsWith('/docs/') && !skipRewritePattern.test(path)) {
      // Rewrite host to docs.example.com
      const docsHost = host.split('.').length > 2 ? 
        // If it's a subdomain (e.g., api.example.com), convert to docs.api.example.com
        'docs.' + host :
        // If it's just example.com, convert to docs.example.com
        'docs.' + host;
      
      return newScheme + docsHost + path;
    } else {
      // Just upgrade the scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Extracts the year from mm/dd/yyyy formatted dates.
 * Returns the four-digit year for mm/dd/yyyy.
 * If the string doesn't match that format or month/day are invalid, returns 'N/A'.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Check for invalid day-month combinations
  // April, June, September, November have 30 days
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  // February has 28 days (or 29 in leap years - but we'll use 28 for simplicity)
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  // If date is valid, return the year
  return year;
}