import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, initializeDatabase, closeDatabase } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await initializeDatabase();
});

afterAll(() => {
  closeDatabase();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);

    // Check all form fields exist with proper labels
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('label[for="firstName"]').text().trim()).toBe('First name');

    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('label[for="lastName"]').text().trim()).toBe('Last name');

    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('label[for="streetAddress"]').text().trim()).toBe('Street address');

    expect($('input[name="city"]')).toHaveLength(1);
    expect($('label[for="city"]').text().trim()).toBe('City');

    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('label[for="stateProvince"]').text().trim()).toBe('State / Province / Region');

    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('label[for="postalCode"]').text().trim()).toBe('Postal / Zip code');

    expect($('input[name="country"]')).toHaveLength(1);
    expect($('label[for="country"]').text().trim()).toBe('Country');

    expect($('input[name="email"]')).toHaveLength(1);
    expect($('label[for="email"]').text().trim()).toBe('Email');

    expect($('input[name="phone"]')).toHaveLength(1);
    expect($('label[for="phone"]').text().trim()).toBe('Phone number');

    // Check form submits to /submit
    expect($('form[action="/submit"]')).toHaveLength(1);
    expect($('form[method="post"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clear database if exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '123 Baker Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.smith@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(formData);

    // Should redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('displays validation errors for invalid submission', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'not-an-email',
      phone: 'invalid-phone!',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Please enter a valid email address');
    expect(response.text).toContain('Phone number can only contain');
  });

  it('renders thank-you page', async () => {
    const response = await request(app).get('/thank-you');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Thank you');
    expect(response.text).toContain('friend');
  });

  it('handles international phone formats', async () => {
    const formData = {
      firstName: 'Carlos',
      lastName: 'Garcia',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('handles alphanumeric postal codes', async () => {
    const formData = {
      firstName: 'Marie',
      lastName: 'Dupont',
      streetAddress: '42 Rue de la Paix',
      city: 'Paris',
      stateProvince: 'Île-de-France',
      postalCode: '75002',
      country: 'France',
      email: 'marie@example.com',
      phone: '+33 1 42 86 83 42',
    };

    const response = await request(app).post('/submit').send(formData);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });
});
