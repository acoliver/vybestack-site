import express, { Request, Response } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;

// Ensure data directory exists
if (!fs.existsSync(DB_DIR)) {
  fs.mkdirSync(DB_DIR, { recursive: true });
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs();

  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }

  // Run schema to ensure tables exist
  const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
  db.run(schema);
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Close database
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Validation function
function validateSubmission(values: FormValues): ValidationResult {
  const errors: string[] = [];

  // Required field validation
  if (!values.firstName || values.firstName.trim() === '') {
    errors.push('First name is required.');
  }
  if (!values.lastName || values.lastName.trim() === '') {
    errors.push('Last name is required.');
  }
  if (!values.streetAddress || values.streetAddress.trim() === '') {
    errors.push('Street address is required.');
  }
  if (!values.city || values.city.trim() === '') {
    errors.push('City is required.');
  }
  if (!values.stateProvince || values.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required.');
  }
  if (!values.postalCode || values.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required.');
  }
  if (!values.country || values.country.trim() === '') {
    errors.push('Country is required.');
  }
  if (!values.email || values.email.trim() === '') {
    errors.push('Email is required.');
  }
  if (!values.phone || values.phone.trim() === '') {
    errors.push('Phone number is required.');
  }

  // Email validation (simple regex)
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (values.email && !emailRegex.test(values.email.trim())) {
    errors.push('Please enter a valid email address.');
  }

  // Phone validation: allows digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[\d\s()-]+$/;
  if (values.phone && !phoneRegex.test(values.phone.trim())) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +.');
  }

  // Postal code validation: alphanumeric with spaces allowed
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  if (values.postalCode && !postalRegex.test(values.postalCode.trim())) {
    errors.push('Postal / Zip code must contain only letters and numbers.');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req: Request, res: Response) => {
  const values: FormValues = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateSubmission(values);

  if (!validation.valid) {
    res.status(400);
    res.render('form', { errors: validation.errors, values });
    return;
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions 
       (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        values.firstName.trim(),
        values.lastName.trim(),
        values.streetAddress.trim(),
        values.city.trim(),
        values.stateProvince.trim(),
        values.postalCode.trim(),
        values.country.trim(),
        values.email.trim(),
        values.phone.trim(),
      ]
    );

    // Save database to disk
    saveDatabase();
  }

  res.redirect(302, '/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Use firstName from query if available, otherwise use a default
  const firstName = typeof req.query.firstName === 'string' ? req.query.firstName : 'friend';
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, _req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
  const server = app.listen(port, () => {
    console.log(`Server listening on port ${port}`);
  });

  // Graceful shutdown
  const shutdown = () => {
    console.log('Shutting down server...');
    server.close(() => {
      console.log('Server closed.');
      closeDatabase();
      process.exit(0);
    });

    // Force close after 10 seconds
    setTimeout(() => {
      console.error('Forced shutdown after timeout.');
      closeDatabase();
      process.exit(1);
    }, 10000);
  };

  process.on('SIGTERM', shutdown);
  process.on('SIGINT', shutdown);
}

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((err) => {
    console.error('Failed to start server:', err);
    process.exit(1);
  });
}

// Export for testing
export { app, initializeDatabase, closeDatabase };
