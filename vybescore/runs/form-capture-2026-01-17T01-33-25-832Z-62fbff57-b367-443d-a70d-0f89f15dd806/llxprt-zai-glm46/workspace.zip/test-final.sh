#!/bin/bash

# Final comprehensive test script

echo "=== Testing comprehensive form submission ==="

# Start server
PORT=3535 node dist/server.js &
SERVER_PID=$!

# Wait for server
sleep 2

echo -e "\n=== Test 1: Form renders correctly ==="
HTML=$(curl -s http://localhost:3535/)
if echo "$HTML" | grep -q "Tell us who you are"; then
    echo "[OK] Form page loads"
else
    echo " Form page failed to load"
fi

echo -e "\n=== Test 2: UK submission ==="
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Jane&lastName=Smith&streetAddress=123+Baker+Street&city=London&stateProvince=England&postalCode=SW1A+1AA&country=UK&email=jane@example.com&phone=%2B44+20+7946+0958" \
  -w "\nStatus: %{http_code}\n" | grep -E "(Status:|Found)"

echo -e "\n=== Test 3: Argentina submission ==="
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Carlos&lastName=Garcia&streetAddress=Av.+Corrientes+1234&city=Buenos+Aires&stateProvince=Buenos+Aires&postalCode=C1000&country=Argentina&email=carlos@example.com&phone=%2B54+9+11+1234-5678" \
  -w "\nStatus: %{http_code}\n" | grep -E "(Status:|Found)"

echo -e "\n=== Test 4: US submission ==="
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=John&lastName=Doe&streetAddress=456+Main+St&city=New+York&stateProvince=NY&postalCode=10001&country=USA&email=john@example.com&phone=%2B1+555-123-4567" \
  -w "\nStatus: %{http_code}\n" | grep -E "(Status:|Found)"

echo -e "\n=== Test 5: Thank you page ==="
THANKS=$(curl -s http://localhost:3535/thank-you)
if echo "$THANKS" | grep -q "Thank you"; then
    echo "[OK] Thank you page loads"
else
    echo " Thank you page failed"
fi

echo -e "\n=== Test 6: Validation errors ==="
ERR_HTML=$(curl -s -X POST http://localhost:3535/submit \
  -d "firstName=&email=bad&phone=bad!" \
  -w "\n%{http_code}")

if echo "$ERR_HTML" | grep -q "First name is required"; then
    echo "[OK] Validation errors displayed"
else
    echo " Validation errors missing"
fi

echo -e "\n=== Test 7: Database persistence ==="
if [ -f "data/submissions.sqlite" ]; then
    echo "[OK] Database file created"
    SIZE=$(stat -c%s "data/submissions.sqlite" 2>/dev/null || stat -f%z "data/submissions.sqlite" 2>/dev/null)
    echo "  Database size: $SIZE bytes"
else
    echo " Database file not created"
fi

# Cleanup
kill $SERVER_PID 2>/dev/null
wait $SERVER_PID 2>/dev/null

echo -e "\n=== All tests completed ==="
