#!/bin/bash

# Manual test script for form-capture application

# Start server in background
PORT=3535 node dist/server.js &
SERVER_PID=$!

# Wait for server to start
sleep 2

echo "=== Testing root endpoint ==="
curl -s http://localhost:3535/ | head -10

echo -e "\n=== Testing form submission (UK) ==="
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Jane&lastName=Smith&streetAddress=123+Baker+Street&city=London&stateProvince=England&postalCode=SW1A+1AA&country=UK&email=jane@example.com&phone=%2B44+20+7946+0958" \
  -w "\nStatus: %{http_code}\n" \
  -D -

echo -e "\n=== Testing form submission (Argentina) ==="
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=Carlos&lastName=Garcia&streetAddress=Av.+Corrientes+1234&city=Buenos+Aires&stateProvince=Buenos+Aires&postalCode=C1000&country=Argentina&email=carlos@example.com&phone=%2B54+9+11+1234-5678" \
  -w "\nStatus: %{http_code}\n" \
  -D -

echo -e "\n=== Testing thank-you page ==="
curl -s http://localhost:3535/thank-you | grep -o "Thank you"

echo -e "\n=== Testing validation errors ==="
curl -s -X POST http://localhost:3535/submit \
  -d "firstName=&lastName=&email=invalid-email&phone=invalid!" \
  -w "\nStatus: %{http_code}\n"

# Kill server
kill $SERVER_PID 2>/dev/null
wait $SERVER_PID 2>/dev/null
echo -e "\n=== Server stopped ==="
