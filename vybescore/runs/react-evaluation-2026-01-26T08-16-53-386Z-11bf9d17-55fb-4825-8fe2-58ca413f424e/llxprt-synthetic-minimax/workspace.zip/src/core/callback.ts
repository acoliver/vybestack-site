/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  getActiveObserver,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    name: 'callback'
  }
  
  let isActive = true
  
  const triggerCallback = () => {
    if (!isActive) return
    
    // Execute the callback function to capture dependencies and perform side effects
    const previous = getActiveObserver()
    try {
      // Set this observer as active during callback execution
      setActiveObserver(observer)
      // Execute user's callback which will access reactive dependencies
      // This allows dependency tracking to work properly
      const result = updateFn(value)
      if (result !== undefined) {
        value = result
      }
    } finally {
      // Restore previous observer context
      setActiveObserver(previous)
    }
  }
  
  // Execute callback to establish initial dependencies
  triggerCallback()
  
  // Return unsubscribe function
  return () => {
    isActive = false
  }
}
