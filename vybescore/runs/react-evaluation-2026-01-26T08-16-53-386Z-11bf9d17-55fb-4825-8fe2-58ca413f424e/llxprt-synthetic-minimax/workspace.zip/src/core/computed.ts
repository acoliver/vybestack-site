/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Create the getter that evaluates the computed value
  const read: GetterFn<T> = () => {
    // Evaluate with proper dependency tracking
    try {
      const result = updateObserver(o)
      return result as T
    } finally {
      // Observer context is automatically restored by updateObserver
    }
  }
  
  return read
}
