import { readFileSync } from 'fs';
import { ReportData, ReportOptions } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): { 
  dataFile: string; 
  format: string; 
  outputFile?: string;
  includeTotals: boolean;
} {
  const args = process.argv.slice(2);
  let dataFile: string | undefined;
  let format: string | undefined;
  let outputFile: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    if (!args[i].startsWith('--')) {
      if (!dataFile) {
        dataFile = args[i];
      }
    } else if (args[i] === '--format') {
      format = args[++i];
    } else if (args[i] === '--output') {
      outputFile = args[++i];
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }

  if (!dataFile) {
    console.error('Error: Data file not provided');
    process.exit(1);
  }

  if (!format) {
    console.error('Error: Format not specified');
    process.exit(1);
  }

  return { dataFile, format, outputFile, includeTotals };
}

function validateData(data: any): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }

  if (typeof data.title !== 'string') {
    console.error('Error: Invalid or missing title');
    return false;
  }

  if (typeof data.summary !== 'string') {
    console.error('Error: Invalid or missing summary');
    return false;
  }

  if (!Array.isArray(data.entries)) {
    console.error('Error: Invalid or missing entries array');
    return false;
  }

  for (const entry of data.entries) {
    if (typeof entry !== 'object' || entry === null) {
      console.error('Error: Invalid entry in entries array');
      return false;
    }

    if (typeof entry.label !== 'string') {
      console.error('Error: Invalid or missing label in entry');
      return false;
    }

    if (typeof entry.amount !== 'number') {
      console.error('Error: Invalid or missing amount in entry');
      return false;
    }
  }

  return true;
}

const formatters = {
  markdown: renderMarkdown,
  text: renderText,
};

function main() {
  const { dataFile, format, outputFile, includeTotals } = parseArgs();
  const options: ReportOptions = { includeTotals };

  if (!formatters[format as keyof typeof formatters]) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }

  try {
    const dataContent = readFileSync(dataFile, 'utf8');
    const data = JSON.parse(dataContent);

    if (!validateData(data)) {
      process.exit(1);
    }

    const output = formatters[format as keyof typeof formatters](data, options);

    if (outputFile) {
      // In a real implementation we would write to the file
      // For this exercise, we'll just print to stdout as requested
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error(`Error: An unknown error occurred`);
    }
    process.exit(1);
  }
}

main();