/**
 * Encode plain text to Base64 using standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Validate Base64 input format.
 * Uses a regex pattern that accepts the standard Base64 alphabet with or without padding.
 */
function isValidBase64(input: string): boolean {
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  return base64Regex.test(input);
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and throws an error for invalid input.
 */
export function decode(input: string): string {
  // Trim whitespace from input
  const trimmedInput = input.trim();
  
  // Validate Base64 format
  if (!trimmedInput.length) {
    throw new Error('Input is empty');
  }
  
  if (!isValidBase64(trimmedInput)) {
    throw new Error('Invalid Base64 format');
  }

  try {
    return Buffer.from(trimmedInput, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
