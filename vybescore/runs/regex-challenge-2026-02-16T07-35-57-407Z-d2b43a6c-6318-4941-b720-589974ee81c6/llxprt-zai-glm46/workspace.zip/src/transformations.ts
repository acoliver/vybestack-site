/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences and collapse extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spacing around sentence boundaries
  // Replace multiple spaces with single space
  let result = text.replace(/\s+/g, ' ');
  
  // Ensure exactly one space after sentence endings if followed by lowercase
  result = result.replace(/([.!?])\s*([a-z])/g, '$1 $2');
  
  // Now capitalize first letter after sentence boundaries
  result = result.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
  
  // Capitalize first character of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  return result;
}

/**
 * Find URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL pattern matching
  // Matches http://, https://, and www. prefixes
  // Excludes trailing punctuation like .,;:?!
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>[\](){}"']+(?<![,.;:!?()[\]{}"'])/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up any trailing punctuation that might have been captured
  return matches.map(url => url.replace(/[,.;:!?()[\]{}"']+$/, ''));
}

/**
 * Force all http URLs to https.
 * Leaves already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not https://
  return text.replace(/http:\/\/(?!https:\/\/)/gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic paths (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com/* URLs
  return text.replace(/http:\/\/example\.com(\/[^\s]*)?/gi, (match, path = '') => {
    // Always upgrade to https
    let result = 'https://example.com' + path;
    
    // Check if we should rewrite host to docs.example.com
    // Only do this if path starts with /docs/ and doesn't contain dynamic indicators
    if (path && path.startsWith('/docs/')) {
      // Check for excluded patterns
      const exclusions = [
        /cgi-bin/,
        /[?&=]/,  // Query strings
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)/i  // Legacy extensions
      ];
      
      const shouldRewriteHost = !exclusions.some(pattern => pattern.test(path));
      
      if (shouldRewriteHost) {
        result = 'https://docs.example.com' + path;
      }
    }
    
    return result;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  const match = value.match(/^(\d{2})\/(\d{2})\/(\d{4})$/);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  return year;
}
