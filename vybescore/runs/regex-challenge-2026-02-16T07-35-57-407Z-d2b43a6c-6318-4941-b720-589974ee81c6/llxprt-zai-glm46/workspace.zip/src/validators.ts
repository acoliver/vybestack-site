export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical formats like user@example.co.uk, name+tag@example.com
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email regex that rejects:
  // - Double dots (..) anywhere
  // - Leading/trailing dots in local or domain parts
  // - Underscores in domain
  // - Invalid TLD formats
  const emailRegex = /^[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?!.*\.\.)(?!.*\.$)[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Additional checks for specific rejection criteria
  if (!emailRegex.test(value)) return false;
  
  // Reject domains with underscores
  const domainPart = value.split('@')[1];
  if (domainPart.includes('_')) return false;
  
  // Reject double dots in local part or domain
  if (value.includes('..')) return false;
  
  // Reject trailing dot
  if (value.endsWith('.')) return false;
  
  // Reject leading dot in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.')) return false;
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports formats: (212) 555-7890, 212-555-7890, 2125557890
 * Allows optional +1 prefix
 * Disallows area codes starting with 0 or 1
 */
// eslint-disable-next-line @typescript-eslint/no-unused-vars
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, 11 with country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // If 11 digits, must start with 1 (country code)
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // Extract area code (first 3 digits after optional country code)
  const areaCodeStart = digitsOnly.length === 11 ? 1 : 0;
  const areaCode = digitsOnly.substring(areaCodeStart, areaCodeStart + 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check that the overall format matches expected patterns
  const patterns = [
    /^\+?1?\s*(?:\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/,  // With separators, optional parentheses
    /^\+?1?\d{10}$/,  // Plain digits
  ];
  
  return patterns.some(pattern => pattern.test(value));
}

/**
 * Validate Argentine phone numbers.
 * Supports landlines and mobiles with optional country code +54
 * Area codes: 2-4 digits, must not start with 0
 * Subscriber numbers: 6-8 digits
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens, dots) for validation
  const cleaned = value.replace(/[\s.-]/g, '');
  
  // Pattern breakdown:
  // ^(?:\+?54)? - Optional +54 country code (entire group is optional)
  // 0? - Optional trunk prefix 0 (required when country code omitted)
  // 9? - Optional mobile indicator 9
  // [1-9]\d{1,3} - Area code (2-4 digits, must start with 1-9)
  // \d{6,8}$ - Subscriber number (6-8 digits)
  const pattern = /^(?:\+?54)?0?9?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!pattern.test(cleaned)) return false;
  
  // Extract digits without country code for further validation
  let digits = cleaned.replace(/^\+?54/, '');
  
  // Check trunk prefix rule: if no country code, must have trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54') || cleaned.startsWith('54');
  if (!hasCountryCode && !digits.startsWith('0')) return false;
  
  // Remove trunk prefix and mobile indicator if present
  digits = digits.replace(/^0/, '').replace(/^9/, '');
  
  // Extract area code (first 2-4 digits, must start with 1-9)
  const areaCodeMatch = digits.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) return false;
  
  const areaCode = areaCodeMatch[1];
  const remaining = digits.substring(areaCode.length);
  
  // Subscriber number must be 6-8 digits
  if (remaining.length < 6 || remaining.length > 8) return false;
  
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and obviously invalid names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Must have at least one character
  if (!value || value.trim().length === 0) return false;
  
  // Pattern allows:
  // - Unicode letters (\p{L})
  // - Apostrophes and hyphens between letters
  // - Spaces between name parts
  // - Marks/accents (\p{M})
  const namePattern = /^[\p{L}\p{M}]+(?:['-][\p{L}\p{M}]+)*(?:\s[\p{L}\p{M}]+(?:['-][\p{L}\p{M}]+)*)*$/u;
  
  if (!namePattern.test(value)) return false;
  
  // Additional check: reject names with digits
  if (/\d/.test(value)) return false;
  
  // Reject obviously problematic patterns (mix of too many special chars)
  const specialCharCount = (value.match(/['-]/g) || []).length;
  const totalChars = value.replace(/\s/g, '').length;
  if (specialCharCount > totalChars / 2) return false;
  
  return true;
}

/**
 * Validate credit card numbers.
 * Checks Visa/Mastercard/AmEx prefixes and lengths, plus Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be 13-19 digits
  if (!/^\d{13,19}$/.test(cleaned)) return false;
  
  // Check prefix and length for known card types
  const cardPatterns = [
    { prefix: /^4/, length: [13, 16] },  // Visa: starts with 4, 13 or 16 digits
    { prefix: /^5[1-5]/, length: [16] },  // Mastercard: starts with 51-55, 16 digits
    { prefix: /^2[2-7]/, length: [16] },  // Mastercard: starts with 2221-2720, 16 digits
    { prefix: /^3[47]/, length: [15] },   // AmEx: starts with 34 or 37, 15 digits
  ];
  
  const isValidFormat = cardPatterns.some(card => 
    card.prefix.test(cleaned) && card.length.includes(cleaned.length)
  );
  
  if (!isValidFormat) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}
