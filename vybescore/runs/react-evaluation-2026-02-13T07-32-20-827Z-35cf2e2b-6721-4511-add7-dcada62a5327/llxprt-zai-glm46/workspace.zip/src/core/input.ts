/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Use an array to track multiple observers
  const observers: Array<Observer<T>> = []
  
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Store the full observer (with updateFn) for later notification
      const fullObserver = observer as Observer<T>
      if (!observers.includes(fullObserver)) {
        observers.push(fullObserver)
      }
      // Still set the single observer for backward compatibility
      s.observer = observer
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Notify ALL observers
    observers.forEach(obs => updateObserver(obs))
    // Also notify the single observer for backward compatibility
    if (s.observer) {
      const singleObs = s.observer as Observer<T>
      if (!observers.includes(singleObs)) {
        updateObserver(singleObs)
      }
    }
    return s.value
  }

  return [read, write]
}
