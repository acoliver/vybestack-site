/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  getActiveObserver,
  EqualFn,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track multiple observers for this computed value
  const observers: Array<Observer<T>> = []
  
  // Create a subject-like structure for this computed value
  // so it can be observed by other computed values
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value as T,
    equalFn: undefined,
  }
  
  // Override the observer's updateFn to also notify our observers
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue?: T) => {
    // Compute new value
    const newValue = originalUpdateFn(prevValue)
    s.value = newValue
    // Notify ALL observers that depend on this computed value
    observers.forEach(obs => updateObserver(obs))
    // Also notify single observer for backward compatibility
    if (s.observer) {
      const singleObs = s.observer as Observer<T>
      if (!observers.includes(singleObs)) {
        updateObserver(singleObs)
      }
    }
    return newValue
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  s.value = o.value as T
  
  // The getter function
  const getter: GetterFn<T> = () => {
    // When accessed within another observer context, register as dependency
    const activeObs = getActiveObserver()
    if (activeObs && activeObs !== o) {
      const fullObserver = activeObs as Observer<T>
      if (!observers.includes(fullObserver)) {
        observers.push(fullObserver)
      }
      // Also set the single observer for backward compatibility
      s.observer = activeObs
    }
    return s.value
  }
  
  return getter
}
