import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination', () => {
  it('returns paginated inventory with default parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    
    expect(response.status).toBe(200);
    expect(response.body.items).toBeDefined();
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5); // default limit
    expect(response.body.total).toBeGreaterThan(0);
    expect(typeof response.body.hasNext).toBe('boolean');
    expect(Array.isArray(response.body.items)).toBe(true);
  });

  it('returns correct items for page 1 with limit 3', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(3);
    expect(response.body.items).toHaveLength(3);
    expect(response.body.items[0].id).toBe(1); // First item should have id 1
    expect(response.body.hasNext).toBe(true);
  });

  it('returns correct items for page 2 with limit 3', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=3');
    
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items).toHaveLength(3);
    expect(response.body.items[0].id).toBe(4); // First item on page 2 should have id 4
  });

  it('validates invalid page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=invalid');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates negative page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates excessive limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=101');
    
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('maximum allowed value is 100');
  });

  it('returns hasNext=false on last page', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=100&limit=5'); // Very high page number
    
    expect(response.status).toBe(200);
    expect(response.body.hasNext).toBe(false);
    expect(response.body.items).toHaveLength(0); // Should be empty on beyond-last page
  });
});