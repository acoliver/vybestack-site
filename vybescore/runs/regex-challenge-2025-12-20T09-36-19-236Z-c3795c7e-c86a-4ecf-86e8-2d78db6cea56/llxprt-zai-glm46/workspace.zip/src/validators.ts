export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to run Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates email addresses with comprehensive regex patterns.
 * Accepts typical formats like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and invalid patterns.
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }

  const [localPart, domain] = value.split('@');
  
  if (!localPart || !domain) {
    return false;
  }

  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }

  if (localPart.includes('..')) {
    return false;
  }

  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }

  if (domain.includes('..')) {
    return false;
  }

  if (domain.includes('_')) {
    return false;
  }

  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }

  const tld = domainParts[domainParts.length - 1];
  if (!/^[a-zA-Z]{2,}$/.test(tld)) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers supporting various formats:
 * - (212) 555-7890
 * - 212-555-7890  
 * - 2125557890
 * - +1 212 555 7890
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  const cleanedValue = value.replace(/[^\d+]/g, '');
  
  if (cleanedValue.length < 10) {
    return false;
  }

  const hasCountryCode = cleanedValue.startsWith('+1');
  const digits = hasCountryCode ? cleanedValue.substring(2) : cleanedValue;

  if (digits.length !== 10) {
    return false;
  }

  if (digits[0] === '0' || digits[0] === '1') {
    return false;
  }

  if (digits[3] === '0' || digits[3] === '1') {
    return false;
  }

  const phoneRegex = /^\+?1?\s*\(?(\d{3})\)?[\s-]*(\d{3})[\s-]*(\d{4})$/;
  return phoneRegex.test(value) && digits[0] !== '0' && digits[0] !== '1';
}

/**
 * Validates Argentine phone numbers supporting landlines and mobiles:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (landline with trunk prefix)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline with trunk prefix)
 */
export function isValidArgentinePhone(value: string): boolean {
  const cleanedValue = value.replace(/[^\d+]/g, '');
  
  if (!cleanedValue) {
    return false;
  }

  let hasCountryCode = false;
  let hasTrunkPrefix = false;
  let digits = cleanedValue;

  if (cleanedValue.startsWith('+54')) {
    hasCountryCode = true;
    digits = cleanedValue.substring(3);
  }

  if (digits.startsWith('0')) {
    hasTrunkPrefix = true;
    digits = digits.substring(1);
  }

  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }

  // Must have either country code or trunk prefix
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }

  // Check total length after removing country code and mobile indicator
  const remainingLength = digits.length;
  
  // Must have area code (2-4 digits) + subscriber number (6-8 digits)
  if (remainingLength < 8 || remainingLength > 12) {
    return false;
  }

  const areaCodeMatch = digits.match(/^(\d{2,4})/);
  if (!areaCodeMatch) {
    return false;
  }

  const areaCode = areaCodeMatch[1];
  const areaCodeFirstDigit = areaCode[0];

  // Area code must start with 1-9, not 0
  if (areaCodeFirstDigit === '0') {
    return false;
  }

  const subscriberNumber = digits.substring(areaCode.length);
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }

  // Additional validation: ensure total length makes sense
  const totalDigits = areaCode.length + subscriberNumber.length;
  if (totalDigits < 8 || totalDigits > 12) {
    return false;
  }

  return true;
}

/**
 * Validates personal names allowing:
 * - Unicode letters and accented characters
 * - Apostrophes (')
 * - Hyphens (-)
 * - Spaces
 * Rejects digits, symbols, and invalid patterns like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }

  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }

  if (/^\s+$/.test(value)) {
    return false;
  }

  if (value.includes('  ')) {
    return false;
  }

  if (value.startsWith("'") || value.startsWith("-") || value.startsWith(" ")) {
    return false;
  }

  if (value.endsWith("'") || value.endsWith("-") || value.endsWith(" ")) {
    return false;
  }

  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }

  return true;
}

/**
 * Validates credit card numbers for Visa, Mastercard, and American Express:
 * - Visa: 13 or 16 digits, starts with 4
 * - Mastercard: 16 digits, starts with 51-55 or 2221-2720
 * - American Express: 15 digits, starts with 34 or 37
 * Runs Luhn checksum validation
 */
export function isValidCreditCard(value: string): boolean {
  const cleanedValue = value.replace(/\D/g, '');
  
  if (!cleanedValue) {
    return false;
  }

  if (cleanedValue.startsWith('4')) {
    if (cleanedValue.length === 13 || cleanedValue.length === 16) {
      return runLuhnCheck(cleanedValue);
    }
  }
  
  if (cleanedValue.startsWith('34') || cleanedValue.startsWith('37')) {
    if (cleanedValue.length === 15) {
      return runLuhnCheck(cleanedValue);
    }
  }
  
  if (/^5[1-5]/.test(cleanedValue)) {
    if (cleanedValue.length === 16) {
      return runLuhnCheck(cleanedValue);
    }
  }
  
  if (/^2(2[2-9]|[3-6]\d|7([01]\d|20))/.test(cleanedValue)) {
    if (cleanedValue.length === 16) {
      return runLuhnCheck(cleanedValue);
    }
  }

  return false;
}
