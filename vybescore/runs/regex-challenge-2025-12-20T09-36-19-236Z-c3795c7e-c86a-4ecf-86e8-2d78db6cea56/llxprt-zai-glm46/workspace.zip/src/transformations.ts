/**
 * Capitalizes the first character of each sentence while preserving spacing rules:
 * - Capitalizes after sentence-ending punctuation (., ?, !)
 * - Inserts exactly one space between sentences if missing
 * - Collapses extra spaces while preserving abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  let result = text;
  
  // Normalize whitespace first
  result = result.replace(/\s+/g, ' ');
  
  // Ensure proper spacing around punctuation
  result = result.replace(/\s*([.!?])\s*/g, '$1 ');
  
  result = result.trim();
  
  // Split by punctuation while preserving it
  const segments = result.split(/([.!?]\s*)/);
  
  const commonAbbreviations = /\b(?:Mr|Mrs|Ms|Dr|Prof|Sr|Jr|St|Ave|Blvd|Rd|Ln|etc|e\.g|i\.e|vs|approx|No|vol|Fig|et al)\.?$/i;
  
  let capitalizeNext = true;
  const resultSegments = [];
  
  for (let i = 0; i < segments.length; i++) {
    const segment = segments[i];
    
    if (!segment) continue;
    
    // If this is punctuation, add it and set flag to capitalize next
    if (/[.!?]\s*/.test(segment)) {
      resultSegments.push(segment);
      capitalizeNext = true;
      continue;
    }
    
    // If this is text and we should capitalize
    if (capitalizeNext && segment.trim().length > 0) {
      const trimmedSegment = segment.trim();
      
      // Check if this segment ends with an abbreviation
      if (commonAbbreviations.test(trimmedSegment)) {
        // Don't capitalize after abbreviation, preserve original
        resultSegments.push(segment);
        capitalizeNext = false;
        continue;
      }
      
      // Capitalize first letter
      const capitalizedSegment = segment.replace(/^(\s*)([a-zA-Z])/, (match, spaces, letter) => {
        return spaces + letter.toUpperCase();
      });
      
      resultSegments.push(capitalizedSegment);
      capitalizeNext = false;
    } else {
      // Add segment as-is
      resultSegments.push(segment);
    }
  }
  
  result = resultSegments.join('');
  
  // Clean up extra spaces around punctuation
  result = result.replace(/\s+([.!?])/g, '$1');
  result = result.replace(/([.!?])\s+/g, '$1 ');
  result = result.replace(/([.!?])\s+([.!?])/g, '$1$2');
  
  return result.trim();
}

/**
 * Extracts URLs from text without trailing punctuation.
 * Supports http, https, www protocols, and domain-only URLs with various formats.
 */
export function extractUrls(text: string): string[] {
  // Enhanced regex pattern to catch domain-only URLs too
  const urlRegex = /\b((?:https?:\/\/|www\.)[^\s<>"']+(?:\.[a-zA-Z]{2,})?|[a-zA-Z0-9-]+\.[a-zA-Z]{2,}(?:\/[^\s<>"']*)?)(?=[\s<>"']|$)/gi;
  
  const urls: string[] = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    let url = match[0];
    
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?()[\]{}"']+$/, '');
    
    // Skip if it looks like just a word (no dot or only one character)
    if (!url.includes('.') || url.length < 4) {
      continue;
    }
    
    // Ensure URL has a proper domain extension
    if (!url.match(/\.[a-zA-Z]{2,}/)) {
      continue;
    }
    
    // Add http:// if no protocol is present
    if (!url.match(/^https?:\/\//) && !url.match(/^www\./)) {
      url = 'http://' + url;
    } else if (url.match(/^www\./)) {
      url = 'http://' + url;
    }
    
    urls.push(url);
  }
  
  // Remove duplicates while preserving order
  return [...new Set(urls)];
}

/**
 * Replaces http:// schemes with https:// while leaving existing secure URLs untouched.
 * This function only upgrades insecure URLs to secure ones.
 */
export function enforceHttps(text: string): string {
  const httpToHttpsRegex = /\bhttp:\/\//gi;
  
  return text.replace(httpToHttpsRegex, 'https://');
}

/**
 * Rewrites http://example.com/... URLs according to specific rules:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  const urlRegex = /\bhttp:\/\/([a-zA-Z0-9.-]+)(\/[^\s<>"']*)/gi;
  
  return text.replace(urlRegex, (match, domain, path) => {
    const lowerPath = path.toLowerCase();
    
    const hasDynamicHints = lowerPath.includes('cgi-bin') ||
      lowerPath.includes('?') ||
      lowerPath.includes('&') ||
      lowerPath.includes('=') ||
      /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/.test(lowerPath);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      const domainParts = domain.split('.');
      if (domainParts.length >= 2 && domainParts[0] === 'example' && domainParts[1] === 'com') {
        return `https://docs.example.com${path}`;
      } else {
        // For other domains, preserve the original domain structure but add docs subdomain
        const newDomain = `docs.${domain}`;
        return `https://${newDomain}${path}`;
      }
    }
    
    return `https://${domain}${path}`;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when the format is invalid or month/day values are out of range.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  if (month === 2) {
    const isLeapYear = (year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0);
    if (day < 1 || day > (isLeapYear ? 29 : 28)) {
      return 'N/A';
    }
  } else {
    if (day < 1 || day > daysInMonth[month - 1]) {
      return 'N/A';
    }
  }
  
  return year.toString();
}
