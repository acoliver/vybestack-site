/**
 * Finds words beginning with the specified prefix but excludes words from the exceptions list.
 * Uses regex word boundaries and negative lookahead to exclude exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create exceptions pattern to exclude exact matches
  const exceptionsPattern = exceptions.length > 0 
    ? `(?!\\b(?:${exceptions.map(ex => ex.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|')})\\b)`
    : '';
  
  // Pattern matches words that start with prefix (including exact prefix matches)
  const wordPattern = new RegExp(`\\b${exceptionsPattern}${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern);
  
  return matches ? [...new Set(matches)] : [];
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookbehind and lookahead assertions for precise positioning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern matches token that immediately follows a digit
  const tokenPattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(tokenPattern);
  
  return matches ? [...new Set(matches)] : [];
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter  
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab, 1212)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || value.length < 10) {
    return false;
  }

  if (/\s/.test(value)) {
    return false;
  }

  if (!/[A-Z]/.test(value)) {
    return false;
  }

  if (!/[a-z]/.test(value)) {
    return false;
  }

  if (!/\d/.test(value)) {
    return false;
  }

  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?~`]/.test(value)) {
    return false;
  }

  // Check for immediate repeated sequences (2-character patterns)
  for (let i = 0; i < value.length - 3; i++) {
    const pattern1 = value[i] + value[i + 1];
    const pattern2 = value[i + 2] + value[i + 3];
    
    if (pattern1 === pattern2) {
      return false;
    }
  }

  // Check for 3-character repeated sequences
  for (let i = 0; i < value.length - 5; i++) {
    const pattern1 = value[i] + value[i + 1] + value[i + 2];
    const pattern2 = value[i + 3] + value[i + 4] + value[i + 5];
    
    if (pattern1 === pattern2) {
      return false;
    }
  }

  // Check for longer repeated patterns (4+ characters) that appear more than once
  for (let len = 4; len <= Math.floor(value.length / 3); len++) {
    const patternCount: Record<string, number> = {};
    
    for (let i = 0; i <= value.length - len; i++) {
      const pattern = value.substring(i, i + len);
      patternCount[pattern] = (patternCount[pattern] || 0) + 1;
      
      if (patternCount[pattern] >= 2) {
        return false;
      }
    }
  }

  // Check for immediate repeated characters (3+ times)
  if (/(.)\1{2,}/.test(value)) {
    return false;
  }

  return true;
}

/**
 * Detects IPv6 addresses including shorthand notation (::) while excluding IPv4 addresses.
 * Matches various IPv6 formats: full, shortened, mixed with embedded IPv4.
 */
export function containsIPv6(value: string): boolean {
  // First check if this looks like pure IPv4 - if so and no colons, it's not IPv6
  const pureIpv4Pattern = /^\b(?:\d{1,3}\.){3}\d{1,3}\b$/;
  if (pureIpv4Pattern.test(value)) {
    return false;
  }

  const ipv6Patterns = [
    // Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
    /\b([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    // Leading zeros omitted: 2001:db8:85a3:0:0:8a2e:370:7334
    /\b([0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{1,4}\b/,
    // Two or more consecutive groups of zeros replaced with ::
    /\b([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}\b/,
    /\b([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}\b/,
    // Ends with :: (1 to 7 groups of zeros)
    /\b[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})\b/,
    // Starts with :: (more than 7 groups of zeros)
    /\b:((:[0-9a-fA-F]{1,4}){1,7}|:)\b/,
    // :: alone
    /\b::\b/,
    // Link-local IPv6 with zone identifier
    /\bfe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}\b/,
    // IPv4-mapped IPv6 addresses
    /\b::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\b/,
    /\b([0-9a-fA-F]{1,4}:){1,4}:[0-9a-fA-F]{1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\b/
  ];

  return ipv6Patterns.some(pattern => pattern.test(value));
}
