/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Observer
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : undefined
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn,
  }

  const dependents = new Set<Observer<unknown>>()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this observer as a dependent of this input
      dependents.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldNotify = !s.equalFn || !s.equalFn(s.value, nextValue)
    s.value = nextValue
    
    // Notify all dependents that this value changed
    if (shouldNotify && dependents.size > 0) {
      // Create a copy to avoid modification during iteration
      const dependentsCopy = Array.from(dependents)
      dependentsCopy.forEach(observer => {
        observer.isDirty = true
      })
    }
    
    return s.value
  }

  return [read, write]
}
