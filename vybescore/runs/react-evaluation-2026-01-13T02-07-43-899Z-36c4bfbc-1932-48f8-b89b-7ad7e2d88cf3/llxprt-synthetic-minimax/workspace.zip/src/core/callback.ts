/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  let disposed = false
  
  // This function executes the callback and tracks dependencies
  const execute = () => {
    if (disposed) return
    // Set this observer as active to track dependencies during execution
    const previous = getActiveObserver()
    setActiveObserver(observer as Observer<unknown>)
    try {
      // Execute the callback, which will track dependencies
      const result = observer.updateFn(observer.value)
      observer.value = result
      return result
    } finally {
      // Restore previous observer
      setActiveObserver(previous)
    }
  }
  
  // Execute the callback immediately to establish initial dependencies
  execute()
  
  // Track this callback as a dependent in any input it's observing
  const activeObserver = getActiveObserver()
  if (activeObserver) {
    // This creates a reactive dependency - when observed values change, this callback should fire
    // Note: The dependency will be established when inputs read during callback execution
  }
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    // In a proper implementation, we would remove this observer from dependency sets
  }
  
  return unsubscribe
}
