/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  EqualFn,
  getActiveObserver,
  setActiveObserver,
  Options
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    isDirty: true // Start as dirty to force initial evaluation
  }
  
  let cachedValue = value
  
  // Create the getter that evaluates the updateFn when called
  const getter: GetterFn<T> = () => {
    // Always evaluate when dirty or first access
    if (o.isDirty || cachedValue === undefined) {
      // Set this observer as active to track dependencies during evaluation
      const previous = getActiveObserver()
      setActiveObserver(o)
      try {
        // Evaluate the computed value - this will call input getters which register dependencies
        cachedValue = updateFn(o.value)
        o.value = cachedValue
        o.isDirty = false
      } finally {
        // Restore the previous active observer
        setActiveObserver(previous)
      }
    } else {
      // Even when cached, we need to track this as a dependency for inputs
      const previous = getActiveObserver()
      setActiveObserver(o)
      try {
        updateFn(o.value)
      } finally {
        setActiveObserver(previous)
      }
    }
    
    return cachedValue as T
  }
  
  return getter
}
