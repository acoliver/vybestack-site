/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize extra spaces between sentences
  // Replace any sequence of whitespace after .?! with exactly one space
  const normalizedText = text.replace(/([.!?])\s+/g, "$1 ");
  
  // Handle capitalization
  // Split into sentences, capitalize each, then join
  const sentences = normalizedText.split(/(?<=[.!?])\s+/);
  const capitalizedSentences = sentences.map(sentence => {
    if (sentence.length === 0) return sentence;
    
    // Capitalize first alphabetic character in the sentence
    return sentence.replace(/^[^a-zA-Z]*([a-zA-Z])/, (match, firstLetter) => {
      return match.substring(0, match.length - 1) + firstLetter.toUpperCase();
    });
  });
  
  // Join back with single spaces
  return capitalizedSentences.join(" ");
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern: http/https scheme, optional www, domain with port, optional path
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation like .,?!:;)] etc.
  return matches.map(url => url.replace(/[.,?!:;)\]]+$/, ""));
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using word boundary to avoid matching https://
  return text.replace(/\bhttp:\/\//g, "https://");
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // First upgrade all http:// to https://
  let result = text.replace(/\bhttp:\/\//g, "https://");
  
  // Then rewrite docs paths for example.com
  // Pattern: https://example.com/docs/... -> https://docs.example.com/...
  // But exclude paths with dynamic indicators: cgi-bin, ?, &, =, .jsp, .php, etc.
  const docsUrlRegex = /https:\/\/(example\.com)(\/docs\/[^\s]*?)(?=[^a-zA-Z0-9]|$)/g;
  
  result = result.replace(docsUrlRegex, (match, domain, path) => {
    // Check for dynamic indicators in the path
    const hasDynamicIndicators = /[?&=]|(?:cgi-bin|(?:\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py))(?:[?#]|$)/i.test(path);
    
    if (hasDynamicIndicators) {
      // Don't modify domain, just keep the https upgrade
      return match;
    }
    
    // No dynamic indicators, rewrite to docs subdomain
    return `https://docs.${domain}${path}`;
  });
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return "N/A";
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Additional validation for specific month/day combinations
  const isValidDate = () => {
    // April, June, September, November have 30 days
    if ([4, 6, 9, 11].includes(month) && day > 30) {
      return false;
    }
    
    // February has 28 days (29 in leap years)
    if (month === 2) {
      const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || parseInt(year, 10) % 400 === 0;
      return isLeapYear ? day <= 29 : day <= 28;
    }
    
    // All other months have 31 days
    return day <= 31;
  };
  
  return isValidDate() ? year : "N/A";
}
