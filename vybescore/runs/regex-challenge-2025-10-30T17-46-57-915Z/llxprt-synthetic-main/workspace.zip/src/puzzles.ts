/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create pattern to match words starting with prefix but excluding exceptions
  // Using word boundaries to ensure we match whole words
  const prefixRegex = new RegExp(`\\b(${prefix}[a-zA-Z]*)\\b`, "g");
  
  // Find all matches
  const matches = [];
  let match;
  
  while ((match = prefixRegex.exec(text)) !== null) {
    const word = match[1];
    
    // Skip if word is in exceptions list
    if (!exceptions.includes(word)) {
      matches.push(word);
    }
  }
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
  
  // Pattern to match token when preceded by a digit, but not at the beginning of the string
  // Using lookahead to capture the digit before the token
  const tokenPattern = new RegExp(`(\\d${escapedToken})`, "g");
  
  const matches = text.match(tokenPattern) || [];
  
  // Return unique matches
  return [...new Set(matches)];
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol
  if (!/[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // No immediate repeated sequences (e.g., abab)
  // Check for repeated sequences of length 2 or more
  for (let length = 2; length <= value.length / 2; length++) {
    for (let i = 0; i <= value.length - 2 * length; i++) {
      const seq = value.substr(i, length);
      const nextSeq = value.substr(i + length, length);
      if (seq === nextSeq) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern including shorthand :: notation
  // Match basic IPv6 patterns including those with ::
  const ipv6Pattern = /(([0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(:[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9]){0,1}[0-9]))/;
  
  // Test if IPv6 pattern matches
  return ipv6Pattern.test(value);
}