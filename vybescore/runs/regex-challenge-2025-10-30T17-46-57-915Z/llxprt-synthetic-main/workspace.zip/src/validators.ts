export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Local part: alphanumeric characters and special chars like +._%-
  // Domain: no underscores, no double dots, no trailing dots
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick check for obvious invalid patterns first
  if (!value || value.includes("..") || value.startsWith(".") || value.endsWith(".")) {
    return false;
  }
  
  // Domain shouldn't contain underscores
  const [localPart, domain] = value.split("@");
  if (!localPart || !domain || domain.includes("_")) {
    return false;
  }
  
  // Final check with comprehensive regex
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove common separators and whitespace first
  const cleanValue = value.replace(/[\s()-]/g, "");
  
  // Check for optional country code +1
  const hasCountryCode = cleanValue.startsWith("+1");
  const phoneNumber = hasCountryCode ? cleanValue.substring(2) : cleanValue;
  
  // Phone number should be exactly 10 digits (after removing country code)
  if (phoneNumber.length !== 10 || !/^\d+$/.test(phoneNumber)) {
    return false;
  }
  
  // Area code shouldn't start with 0 or 1
  const areaCode = phoneNumber.substring(0, 3);
  if (areaCode.startsWith("0") || areaCode.startsWith("1")) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens but keep other structure
  const cleanValue = value.replace(/[\s-]/g, "");
  
  // Pattern for Argentine phone numbers
  // Optional +54 country code
  // Optional 0 trunk prefix
  // Optional 9 mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  const match = cleanValue.match(argentinePhoneRegex);
  
  if (!match) {
    return false;
  }
  
  const [, countryCode, trunkPrefix, , areaCode, subscriberNumber] = match;
  
  // If country code is omitted, trunk prefix must be present
  if (!countryCode && !trunkPrefix) {
    return false;
  }
  
  // Check that area code is 2-4 digits and starts with 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Check that subscriber number is 6-8 digits
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow Unicode letters, accents, apostrophes, hyphens, and spaces
  // Reject digits, special symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!value || value.trim().length < 1) {
    return false;
  }
  
  // Should not contain digits or special symbols
  if (/\d/.test(value) || /[^\p{L}'\-\s]/u.test(value)) {
    return false;
  }
  
  return nameRegex.test(value) && value.trim().length > 0;
}

// Helper function for Luhn checksum
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = value.length - 1; i >= 0; i--) {
    let digit = parseInt(value.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove any spaces or hyphens
  const cleanValue = value.replace(/[\s-]/g, "");
  
  // Should be all digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Validate based on card type
  const visaRegex = /^4\d{12}(\d{3})?$/; // 13 or 16 digits, starts with 4
  const mastercardRegex = /^5[1-5]\d{14}$/; // 16 digits, starts with 51-55
  const amexRegex = /^3[47]\d{13}$/; // 15 digits, starts with 34 or 37
  
  // Check if any card type pattern matches
  if (!visaRegex.test(cleanValue) && !mastercardRegex.test(cleanValue) && !amexRegex.test(cleanValue)) {
    return false;
  }
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanValue);
}
