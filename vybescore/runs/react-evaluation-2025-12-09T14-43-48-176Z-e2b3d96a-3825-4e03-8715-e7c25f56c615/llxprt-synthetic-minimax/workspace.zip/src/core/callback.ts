/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    dependencies: new Set()
  }
  
  // Immediately run the update function to establish dependencies
  updateObserver(observer)

  return () => {
    // Clean up dependencies
    if (observer.dependencies) {
      for (const subject of observer.dependencies) {
        subject.observers?.delete(observer as Observer<unknown>)
      }
      observer.dependencies.clear()
    }
    // Set a no-op update function to prevent further execution
    observer.updateFn = () => observer.value as T
  }
}
