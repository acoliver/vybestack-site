/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Subject,
  notifySubject
} from '../types/reactive.js'

// Access activeObserver from the module scope
let activeObserver: Observer<unknown> | undefined

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create a subject to represent this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    value: value as T, // Cast since value is guaranteed to be set when used
    equalFn: typeof _equal === 'function' ? _equal : undefined,
  }

  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    dependencies: new Set()
  }

  const getValue: GetterFn<T> = () => {
    // Set this computed value as the active observer for dependency tracking
    const previous = activeObserver
    activeObserver = observer as Observer<unknown>
    
    try {
      // Always run update to track dependencies and compute current value
      const oldValue = observer.value
      updateObserver(observer)
      
      // Update the subject value with the computed result
      if (observer.value !== undefined) {
        computedSubject.value = observer.value
      }
      
      // Notify observers if the value changed
      if (oldValue !== observer.value) {
        notifySubject(computedSubject)
      }
      
      return observer.value as T
    } finally {
      // Restore the previous active observer
      activeObserver = previous
    }
  }

  return getValue
}
