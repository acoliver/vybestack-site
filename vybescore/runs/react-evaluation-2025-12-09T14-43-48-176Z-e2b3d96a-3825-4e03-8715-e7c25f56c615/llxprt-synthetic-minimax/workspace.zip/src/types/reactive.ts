/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<Subject<unknown>> // Subjects this observer depends on
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<Observer<unknown>> // Observers that depend on this subject
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addDependency<T, U>(observer: Observer<T>, subject: Subject<U>): void {
  // Add subject to observer's dependencies
  if (!observer.dependencies) {
    observer.dependencies = new Set()
  }
  observer.dependencies.add(subject as Subject<unknown>)
  
  // Add observer to subject's observers
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer as Observer<unknown>)
}

export function notifySubject<T>(subject: Subject<T>): void {
  if (subject.observers) {
    // Create a copy to avoid issues during iteration
    const observers = Array.from(subject.observers)
    for (const observer of observers) {
      // Always update observers when notified
      console.log('Notifying observer:', observer)
      updateObserver(observer as Observer<unknown>)
    }
  }
}
