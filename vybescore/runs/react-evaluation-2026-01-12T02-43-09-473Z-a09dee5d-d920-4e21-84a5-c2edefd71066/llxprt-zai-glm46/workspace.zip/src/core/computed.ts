/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  ObserverR,
  flushUpdates,
  queueUpdate
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Track observers that depend on this computed value
  const observers: Set<ObserverR> = new Set()
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    observers,
    updateFn: (prevValue?: T) => {
      // Re-compute by calling the original updateFn
      // This will run while this observer is active, re-tracking dependencies
      const result = updateFn(prevValue)
      
      // Notify all observers that depend on this computed value
      // Queue them for update - they'll be processed after this update cycle
      for (const observer of observers) {
        if (observer !== getActiveObserver()) {
          queueUpdate(observer)
        }
      }
      
      return result
    },
  }
  
  // Initial computation - this will track dependencies
  updateObserver(o)
  
  // Flush any queued updates from the initial computation
  flushUpdates()
  
  const getter = (): T => {
    // When this computed is read, track the active observer
    const active = getActiveObserver()
    if (active) {
      observers.add(active)
    }
    
    return o.value!
  }
  
  return getter
}
