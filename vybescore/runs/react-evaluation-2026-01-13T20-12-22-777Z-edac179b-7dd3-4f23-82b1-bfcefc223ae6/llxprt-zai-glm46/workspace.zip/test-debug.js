// Debug test for reactive system
const { createInput, createComputed, createCallback } = require('./src/index.ts')

console.log('=== Test 1: Compute cells can depend on other compute cells ===')
const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => input() * 2)
console.log('timesTwo:', timesTwo())

const timesThirty = createComputed(() => input() * 30)
console.log('timesThirty:', timesThirty())

const sum = createComputed(() => timesTwo() + timesThirty())
console.log('sum:', sum())

console.log('Setting input to 3')
setInput(3)
console.log('After update - input:', input())
console.log('After update - timesTwo:', timesTwo())
console.log('After update - timesThirty:', timesThirty())
console.log('After update - sum:', sum())
console.log('Expected: 96, Got:', sum())
