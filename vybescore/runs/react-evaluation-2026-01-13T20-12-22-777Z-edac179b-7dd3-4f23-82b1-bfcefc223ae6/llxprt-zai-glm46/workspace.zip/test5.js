// Test to understand the problem better
import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

console.log('Creating timesTwo...')
const timesTwo = createComputed(() => {
  console.log('  timesTwo updateFn called, reading input')
  const val = input()
  console.log('  timesTwo got:', val)
  return val * 2
})

console.log('\nCreating timesThirty...')
const timesThirty = createComputed(() => {
  console.log('  timesThirty updateFn called, reading input')
  const val = input()
  console.log('  timesThirty got:', val)
  return val * 30
})

console.log('\nCreating sum...')
const sum = createComputed(() => {
  console.log('  sum updateFn called, reading timesTwo and timesThirty')
  const t2 = timesTwo()
  console.log('  sum got timesTwo:', t2)
  const t30 = timesThirty()
  console.log('  sum got timesThirty:', t30)
  return t2 + t30
})

console.log('\n=== Initial state ===')
console.log('sum():', sum())
console.log('Expected: 32')

console.log('\n=== Calling setInput(3) ===')
setInput(3)

console.log('\n=== After setInput ===')
console.log('sum():', sum())
console.log('Expected: 96')
