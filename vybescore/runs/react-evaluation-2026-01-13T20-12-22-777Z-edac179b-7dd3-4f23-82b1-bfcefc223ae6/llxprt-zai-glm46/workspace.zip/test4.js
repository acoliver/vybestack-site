// Test to check if sum is being tracked as dependent on timesTwo and timesThirty
import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => {
  console.log('  timesTwo updateFn called')
  return input() * 2
})

const timesThirty = createComputed(() => {
  console.log('  timesThirty updateFn called')
  return input() * 30
})

const sum = createComputed(() => {
  console.log('  sum updateFn called')
  return timesTwo() + timesThirty()
})

// Check what subjects input has
const inputFn = input as any
const inputSubject = inputFn.toString().match(/Subject/) ? null : null

console.log('\nInitial sum():', sum())
console.log('Expected: 32')

console.log('\nCalling setInput(3)...')
setInput(3)

console.log('\nAfter setInput, sum():', sum())
console.log('Expected: 96')
