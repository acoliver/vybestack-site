// Minimal test to understand the issue
import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

console.log('Creating timesTwo...')
const timesTwo = createComputed(() => {
  console.log('  timesTwo updateFn called, input() =', input())
  return input() * 2
})

console.log('Creating timesThirty...')
const timesThirty = createComputed(() => {
  console.log('  timesThirty updateFn called, input() =', input())
  return input() * 30
})

console.log('Creating sum...')
const sum = createComputed(() => {
  const t2 = timesTwo()
  const t30 = timesThirty()
  console.log('  sum updateFn called, timesTwo() =', t2, 'timesThirty() =', t30)
  return t2 + t30
})

console.log('\nInitial sum():', sum())
console.log('Expected: 32')

console.log('\nCalling setInput(3)...')
setInput(3)

console.log('\nAfter setInput, sum():', sum())
console.log('Expected: 96')
