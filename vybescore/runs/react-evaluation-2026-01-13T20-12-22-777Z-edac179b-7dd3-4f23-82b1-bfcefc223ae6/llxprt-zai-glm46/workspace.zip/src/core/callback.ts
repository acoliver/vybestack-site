/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, observerToSubjects } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Initial execution to track dependencies and run the callback
  updateObserver(observer as Observer<unknown>)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this observer from all subjects that reference it
    const subjects = observerToSubjects.get(observer as Observer<unknown>)
    if (subjects) {
      for (const subject of subjects) {
        subject.observers.delete(observer as Observer<unknown>)
      }
      subjects.clear()
    }
  }
}
