/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  observerToSubjects,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<Observer<unknown>>(),
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.observers.add(observer)
      // Track this subject for the observer
      let subjects = observerToSubjects.get(observer)
      if (!subjects) {
        subjects = new Set()
        observerToSubjects.set(observer, subjects as Set<Subject<unknown>>)
      }
      (subjects as Set<Subject<unknown>>).add(s as Subject<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !s.equalFn || !s.equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      
      // Notify all observers using notifyObservers
      notifyObservers(s as Subject<T>)
    }
    return s.value
  }

  return [read, write]
}
