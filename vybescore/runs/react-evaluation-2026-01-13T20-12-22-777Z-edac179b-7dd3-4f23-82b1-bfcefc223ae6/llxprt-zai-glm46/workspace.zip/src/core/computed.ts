/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  getActiveObserver,
  EqualFn,
  observerToSubjects,
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // The observer that tracks our dependencies
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // The subject that other observers can track
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<Observer<unknown>>(),
    value: value as T,
    equalFn: undefined,
  }
  
  // Track subjects we depend on for cleanup
  const subjects = new Set<Subject<unknown>>()
  observerToSubjects.set(o as Observer<unknown>, subjects)
  
  // Compute initial value once at creation (with tracking to establish dependencies)
  const initialPrev = getActiveObserver()
  try {
    setActiveObserver(o as Observer<unknown>)
    o.value = o.updateFn(o.value)
    if (o.value !== undefined) {
      s.value = o.value as T
    }
  } finally {
    setActiveObserver(initialPrev)
  }
  
  // Now register this computed observer with all the subjects it accessed during initialization
  // This ensures the subjects will notify this computed when they change
  const initialSubjects = observerToSubjects.get(o as Observer<unknown>)
  if (initialSubjects) {
    for (const subj of initialSubjects) {
      subj.observers.add(o as Observer<unknown>)
    }
  }
  
  // Return getter function
  const getter: GetterFn<T> = (): T => {
    const activeObserver = getActiveObserver()
    
    if (activeObserver) {
      // Register this computed as a subject dependency for the active observer
      s.observers.add(activeObserver)
      
      // Track this subject for the observer
      let obsSubjects = observerToSubjects.get(activeObserver)
      if (!obsSubjects) {
        obsSubjects = new Set()
        observerToSubjects.set(activeObserver, obsSubjects)
      }
      obsSubjects.add(s as Subject<unknown>)
    }
    
    return s.value
  }
  
  return getter
}
