/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<unknown>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<unknown> | undefined

export function getActiveObserver(): Observer<unknown> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<unknown> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer as Observer<unknown>
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Simple notification: just notify direct observers
  const observers = Array.from(subject.observers)
  
  for (const observer of observers) {
    // Get the set of subjects this observer was previously registered with
    const previousSubjects = observerToSubjects.get(observer)
    
    // Clear previous registrations from subject.observer sets
    if (previousSubjects) {
      for (const prevSubject of previousSubjects) {
        prevSubject.observers.delete(observer)
      }
      previousSubjects.clear()
    }
    
    // Create new set for this update
    const currentSubjects = new Set<Subject<unknown>>()
    observerToSubjects.set(observer, currentSubjects)
    
    // Update the observer (this will track dependencies in currentSubjects)
    updateObserver(observer)
    
    // Now re-register this observer with all subjects it accessed
    for (const s of currentSubjects) {
      s.observers.add(observer)
    }
  }
}

// Track which subjects each observer is registered with for cleanup
export const observerToSubjects = new WeakMap<Observer<unknown>, Set<Subject<unknown>>>()
