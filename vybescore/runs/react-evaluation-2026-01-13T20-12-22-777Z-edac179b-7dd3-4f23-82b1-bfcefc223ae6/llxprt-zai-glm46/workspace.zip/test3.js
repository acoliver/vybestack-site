// Test to check subject.observers
import { createInput, createComputed } from './src/index.ts'

const [input, setInput] = createInput(1)

const timesTwo = createComputed(() => input() * 2)
const timesThirty = createComputed(() => input() * 30)
const sum = createComputed(() => timesTwo() + timesThirty())

// Add some debugging to input.ts
console.log('Initial sum():', sum())
console.log('Expected: 32, Got:', sum())

// Check if input has observers
const subjects = (input as any).toString()
console.log('input function:', typeof input)

console.log('\nCalling setInput(3)...')
setInput(3)

console.log('After setInput, sum():', sum())
console.log('Expected: 96, Got:', sum())
