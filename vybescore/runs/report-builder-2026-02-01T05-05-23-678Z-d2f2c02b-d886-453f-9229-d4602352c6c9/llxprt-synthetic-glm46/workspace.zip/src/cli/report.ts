#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { exit } from 'process';

import type { ReportData, ReportOptions, RenderFunction } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

const FORMATTERS: Record<string, RenderFunction> = {
  markdown: renderMarkdown,
  text: renderText,
};

interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    exit(1);
  }

  const dataPath = args[0];
  
  // Parse command line arguments manually
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          exit(1);
        }
        format = args[i + 1];
        i++;
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path');
          exit(1);
        }
        outputPath = args[i + 1];
        i++;
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        console.error(`Error: Unknown argument: ${args[i]}`);
        exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    exit(1);
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): asserts data is ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }
  
  for (const entry of obj.entries) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error('Invalid data: each entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: each entry must have a string label');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: each entry must have a number amount');
    }
  }
}

function main(): void {
  try {
    const { dataPath, format, outputPath, includeTotals } = parseArgs();
    
    // Load and parse JSON
    let data: unknown;
    try {
      const fileContent = readFileSync(dataPath, 'utf-8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof SyntaxError) {
        console.error(`Error: Invalid JSON in file ${dataPath}: ${error.message}`);
      } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
        console.error(`Error: File not found: ${dataPath}`);
      } else {
        console.error(`Error reading file ${dataPath}: ${error instanceof Error ? error.message : String(error)}`);
      }
      exit(1);
    }
    
    // Validate data structure
    validateReportData(data);
    
    // Check format
    const formatter = FORMATTERS[format];
    if (!formatter) {
      console.error(`Error: Unsupported format: ${format}`);
      exit(1);
    }
    
    // Render report
    const options: ReportOptions = { includeTotals };
    const output = formatter(data, options);
    
    // Output
    if (outputPath) {
      writeFileSync(outputPath, output, 'utf-8');
      console.error(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
