import { ReportData, ReportOptions } from '../types/report.js';

export function renderText(
  data: ReportData,
  options: ReportOptions
): string {
  const { title, summary, entries } = data;
  
  let output = `${title}\n`;
  output += `${summary}\n`;
  output += `Entries:\n`;
  
  for (const entry of entries) {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }
  
  if (options.includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `Total: $${total.toFixed(2)}`;
  }
  
  return output;
}