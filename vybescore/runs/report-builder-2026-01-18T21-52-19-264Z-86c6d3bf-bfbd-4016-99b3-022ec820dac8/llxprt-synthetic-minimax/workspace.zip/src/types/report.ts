export interface ReportEntry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface ReportOptions {
  includeTotals: boolean;
  format: 'markdown' | 'text';
}

export interface CliOptions {
  dataPath: string;
  output?: string;
  includeTotals: boolean;
  format: 'markdown' | 'text';
}