#!/usr/bin/env node

import { readFileSync } from 'node:fs';
import { writeFileSync } from 'node:fs';
import { ReportData, CliOptions } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(args: string[]): CliOptions {
  if (args.length < 3) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  // Skip first two args (node and script path)
  const cliArgs = args.slice(2);
  
  let dataPath = '';
  let format: 'markdown' | 'text' = 'markdown';
  let output: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < cliArgs.length; i++) {
    const arg = cliArgs[i];
    
    if (arg === '--format') {
      i++;
      if (i >= cliArgs.length) {
        throw new Error('--format requires a value');
      }
      format = cliArgs[i] as 'markdown' | 'text';
    } else if (arg === '--output') {
      i++;
      if (i >= cliArgs.length) {
        throw new Error('--output requires a value');
      }
      output = cliArgs[i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('--')) {
      dataPath = arg;
    }
  }

  if (!dataPath) {
    throw new Error('Missing required data.json path');
  }

  if (format !== 'markdown' && format !== 'text') {
    throw new Error('Unsupported format');
  }

  return {
    dataPath,
    format,
    output,
    includeTotals
  };
}

function validateData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;
  
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }
  
  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  const entries = reportData.entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: missing or invalid "label" in entries[${index}]`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: missing or invalid "amount" in entries[${index}]`);
    }
    
    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries
  };
}

function renderReport(
  data: ReportData,
  options: { includeTotals: boolean; format: 'markdown' | 'text' }
): string {
  if (options.format === 'markdown') {
    return renderMarkdown(data, options);
  } else {
    return renderText(data, options);
  }
}

function main(args: string[]): void {
  try {
    const cliOptions = parseArgs(args);
    
    // Read and parse JSON file
    const rawData = readFileSync(cliOptions.dataPath, 'utf-8');
    const parsedData = JSON.parse(rawData);
    const reportData = validateData(parsedData);
    
    // Render report
    const report = renderReport(reportData, {
      includeTotals: cliOptions.includeTotals,
      format: cliOptions.format
    });
    
    // Write output
    if (cliOptions.output) {
      writeFileSync(cliOptions.output, report, 'utf-8');
    } else {
      process.stdout.write(report);
    }
    
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: An unexpected error occurred');
    }
    process.exit(1);
  }
}

// Only run main if this script is executed directly
if (import.meta.url === `file://${process.argv[1]}`) {
  main(process.argv);
}
