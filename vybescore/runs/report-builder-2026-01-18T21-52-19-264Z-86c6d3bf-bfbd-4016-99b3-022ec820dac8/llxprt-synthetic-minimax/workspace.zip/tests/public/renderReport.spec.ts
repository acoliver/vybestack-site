import { describe, expect, it } from 'vitest';
import { spawn } from 'node:child_process';
import { join } from 'node:path';

describe('report CLI (public smoke)', () => {
  it('should render markdown format with totals', async () => {
    const result = spawn('node', [
      'dist/cli/report.js',
      'fixtures/data.json',
      '--format',
      'markdown',
      '--includeTotals'
    ], { cwd: process.cwd() });

    let stdout = '';
    let stderr = '';

    result.stdout!.on('data', (data) => {
      stdout += data.toString();
    });

    result.stderr!.on('data', (data) => {
      stderr += data.toString();
    });

    await new Promise((resolve, reject) => {
      result.on('close', (code) => {
        if (code !== 0) {
          reject(new Error(`Process exited with code ${code}: ${stderr}`));
        } else {
          resolve(null);
        }
      });
    });

    expect(stdout).toContain('# Quarterly Financial Summary');
    expect(stdout).toContain('**Total:** $70370.34');
    expect(stdout).toContain('**North Region** — $12345.67');
  });

  it('should render text format without totals', async () => {
    const result = spawn('node', [
      'dist/cli/report.js',
      'fixtures/data.json',
      '--format',
      'text'
    ], { cwd: process.cwd() });

    let stdout = '';
    let stderr = '';

    result.stdout!.on('data', (data) => {
      stdout += data.toString();
    });

    result.stderr!.on('data', (data) => {
      stderr += data.toString();
    });

    await new Promise((resolve, reject) => {
      result.on('close', (code) => {
        if (code !== 0) {
          reject(new Error(`Process exited with code ${code}: ${stderr}`));
        } else {
          resolve(null);
        }
      });
    });

    expect(stdout).toContain('Quarterly Financial Summary');
    expect(stdout).toContain('- North Region: $12345.67');
    expect(stdout).not.toContain('Total:');
  });

  it('should handle malformed JSON gracefully', async () => {
    // Create a temporary malformed JSON file
    const tempFile = join(process.cwd(), 'temp-malformed.json');
    const fs = await import('node:fs');
    fs.writeFileSync(tempFile, '{ "title": "test", "invalid": }');

    try {
      const result = spawn('node', [
        'dist/cli/report.js',
        'temp-malformed.json',
        '--format',
        'markdown'
      ], { cwd: process.cwd() });

      let stderr = '';
      result.stderr!.on('data', (data) => {
        stderr += data.toString();
      });

      await new Promise((resolve) => {
        result.on('close', resolve);
      });

      expect(stderr.toLowerCase()).toMatch(/missing|unable|enoent|not found|error|invalid/);
    } finally {
      fs.unlinkSync(tempFile);
    }
  });

  it('should reject unsupported format with error', async () => {
    const result = spawn('node', [
      'dist/cli/report.js',
      'fixtures/data.json',
      '--format',
      'xml'
    ], { cwd: process.cwd() });

    let stderr = '';
    result.stderr!.on('data', (data) => {
      stderr += data.toString();
    });

    await new Promise((resolve) => {
      result.on('close', resolve);
    });

    expect(stderr).toContain('Unsupported format');
  });
});
