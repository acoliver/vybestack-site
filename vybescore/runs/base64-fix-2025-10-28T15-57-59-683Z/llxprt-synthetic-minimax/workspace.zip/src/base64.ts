/**
 * Encode plain text to Base64 using canonical RFC 4648 Base64.
 * Returns Base64 with proper padding ('=' characters) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input (with or without padding) and recovers the original Unicode string.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate that input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
