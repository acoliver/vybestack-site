/**
 * Find words starting with the prefix, excluding specified exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match word boundaries and words starting with prefix
  const wordRegex = new RegExp(`\\b(${escapedPrefix}\\w+)`, 'gi');
  
  const matches = text.match(wordRegex) || [];
  
  // Filter out exceptions (case-insensitive)
  const lowerExceptions = exceptions.map(e => e.toLowerCase());
  
  return matches
    .map(word => word)
    .filter(word => !lowerExceptions.includes(word.toLowerCase()))
    .filter((word, index, self) => self.indexOf(word) === index); // unique
}

/**
 * Find occurrences of token only when it appears after a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match digit followed by token, ensuring token is not at start
  // Use word boundaries to ensure we're matching complete tokens
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate password strength:
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // Check for digit
  if (!/\d/.test(value)) return false;
  
  // Check for symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) return false;
  
  // Check for repeated sequences (abab, 1212, etc.)
  // Look for patterns of 2-4 characters that repeat
  for (let len = 2; len <= 4; len++) {
    const repeatPattern = new RegExp(`(.{${len}})\\1`, 'g');
    if (repeatPattern.test(value)) return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) while excluding IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern that supports shorthand (::)
  // This pattern matches valid IPv6 addresses but not IPv4
  const ipv6Pattern = /(?:^|[^0-9.])([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}(?:$|[^0-9a-fA-F.:])/;
  
  // Pattern with :: shorthand
  const ipv6ShorthandPattern = /(?:^|[^0-9.])([0-9a-fA-F]{1,4}:*::[0-9a-fA-F]{0,4}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4})(?:$|[^0-9a-fA-F.:])/;
  
  // Check for IPv4-like patterns to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // If it contains IPv4, it's not a pure IPv6 match
  if (ipv4Pattern.test(value)) return false;
  
  return ipv6Pattern.test(value) || ipv6ShorthandPattern.test(value);
}
