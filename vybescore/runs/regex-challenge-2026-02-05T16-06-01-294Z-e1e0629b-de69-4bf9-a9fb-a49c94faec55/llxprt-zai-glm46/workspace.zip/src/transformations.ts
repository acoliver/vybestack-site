/**
 * Capitalize the first character of each sentence.
 * - Insert exactly one space between sentences
 * - Collapse extra spaces sensibly
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace: collapse multiple spaces into one
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Insert space after sentence endings if missing
  const withSpaces = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Use a regex to find sentence boundaries and capitalize
  // Split by sentence endings followed by space
  return withSpaces.replace(/(^|[.!?]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * Find all URLs in the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, and www URLs
  const urlRegex = /(https?:\/\/[^\s<>"{}|\\^`[\]]+|www\.[^\s<>"{}|\\^`[\]]+)/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?]+$/, ''));
}

/**
 * Convert all http:// URLs to https:// while leaving existing https URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs (case-insensitive)
  return text.replace(/(https?:\/\/)(example\.com)(\/[^\s]*)/gi, (match, protocol, host, path) => {
    // Always upgrade to https
    const secureProtocol = 'https://';
    
    // Check if path contains dynamic hints
    // Query strings anywhere in the path
    const hasQueryString = /[?&=]/.test(path);
    
    // Check for legacy extensions or cgi-bin in the path (before query string)
    const pathOnly = path.split('?')[0];
    const hasLegacyHints = /\/(cgi-bin)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))$/i.test(pathOnly);
    
    // If path starts with /docs/ and has NO dynamic hints, rewrite host
    if (path.startsWith('/docs/') && !hasQueryString && !hasLegacyHints) {
      return secureProtocol + 'docs.example.com' + path;
    }
    
    // Otherwise just upgrade the scheme
    return secureProtocol + host + path;
  });
}

/**
 * Extract the year from mm/dd/yyyy format.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Validate month and day
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  if (dayNum < 1 || dayNum > 31) return 'N/A';
  
  return year;
}
