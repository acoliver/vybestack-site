export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with robust regex.
 * - Accepts typical addresses like name@tag@example.co.uk
 * - Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Check for double dots anywhere in the email
  if (value.includes('..')) return false;
  
  // Check for trailing dot
  if (value.endsWith('.')) return false;
  
  // Check for leading dot
  if (value.startsWith('.')) return false;
  
  // Check for underscore in domain
  const atIndex = value.lastIndexOf('@');
  if (atIndex !== -1) {
    const domain = value.substring(atIndex + 1);
    if (domain.includes('_')) return false;
    
    // Check for leading or trailing dot in local part
    const localPart = value.substring(0, atIndex);
    if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  }
  
  // More permissive email validation that allows tags and multiple @ signs
  const emailRegex = /^[a-zA-Z0-9._%+-]+(?:@[a-zA-Z0-9._%+-]+)*@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers supporting common formats and optional +1 prefix.
 * - Accepts: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallows area codes starting with 0 or 1
 * - Rejects too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Strip all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Must have at least 10 digits (standard US number)
  if (digitsOnly.length < 10) return false;
  
  // Handle +1 country code (11 digits)
  const areaCodeStart = (digitsOnly.length === 11 && digitsOnly[0] === '1') ? 1 : 0;
  if (digitsOnly.length !== 10 && digitsOnly.length !== 11) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digitsOnly[areaCodeStart];
  if (areaCode === '0' || areaCode === '1') return false;
  
  // Validate format with proper separators
  const phoneRegex = /^(\+1\s?)?(\(\d{3}\)|\d{3})[-.\s]?\d{3}[-.\s]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Full pattern with optional country code, trunk prefix, and mobile indicator
  const argentinePhoneRegex = /^(\+54)?0?9?\d{2,4}\d{6,8}$/;
  if (!argentinePhoneRegex.test(cleaned)) return false;
  
  // Extract the area code part (after country code, trunk prefix, and mobile indicator)
  const withoutCountry = cleaned.replace(/^\+54/, '');
  const withoutTrunk = withoutCountry.replace(/^0/, '');
  const withoutMobile = withoutTrunk.replace(/^9/, '');
  
  // Find where area code ends (first 2-4 digits)
  const areaCodeLength = 2;
  const remaining = withoutMobile.slice(areaCodeLength);
  
  // Area code must start with 1-9
  const firstDigit = withoutMobile[0];
  if (firstDigit < '1' || firstDigit > '9') return false;
  
  // Validate total length after area code is 6-8 digits
  if (remaining.length < 6 || remaining.length > 8) return false;
  
  // If no country code, must have trunk prefix 0
  if (!value.includes('+54') && !withoutCountry.startsWith('0')) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * - Rejects digits, symbols, and obviously fake names like "X Æ A-12"
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits and special symbols
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Additional check to reject patterns like "X Æ A-12" (contains digits)
  if (/\d/.test(value)) return false;
  
  // Must have at least 2 characters
  if (value.length < 2) return false;
  
  return nameRegex.test(value) && !/^[\s\-']+$/.test(value);
}

/**
 * Luhn algorithm for credit card checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(d => parseInt(d, 10));
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers (Visa/Mastercard/AmEx).
 * - Checks prefix and length
 * - Runs Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7]\d{14})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  const validFormat = visaRegex.test(cleaned) || 
                      mastercardRegex.test(cleaned) || 
                      amexRegex.test(cleaned);
  
  if (!validFormat) return false;
  
  return runLuhnCheck(cleaned);
}
