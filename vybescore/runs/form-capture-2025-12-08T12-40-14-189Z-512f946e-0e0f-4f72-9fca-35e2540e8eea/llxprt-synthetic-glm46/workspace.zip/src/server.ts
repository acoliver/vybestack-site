import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';

const PORT = process.env.PORT || 3535;
const DATA_DIR = path.resolve('data');
const DB_PATH = path.join(DATA_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.join('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Ensure data directory exists
if (!fs.existsSync(DATA_DIR)) {
  fs.mkdirSync(DATA_DIR, { recursive: true });
}

import type { Database as DBType } from 'sql.js';
import initSqlJs from 'sql.js';

let db: DBType | null = null;

// Initialize SQLite database
async function initializeDatabase(): Promise<void> {
  if (db) return;
  
  try {
    // Initialize sql.js
    const SQL = await initSqlJs();

    // Check if database file exists
    if (fs.existsSync(DB_PATH)) {
      // Load existing database
      const dbData = fs.readFileSync(DB_PATH);
      db = new SQL.Database(dbData);
    } else {
      // Create new database
      db = new SQL.Database();
      const schemaData = fs.readFileSync(SCHEMA_PATH);
      db.exec(schemaData.toString());
      saveDatabase();
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(DB_PATH, data);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validate form data
function validateFormData(data: Partial<FormData>): ValidationError[] {
  const errors: ValidationError[] = [];

  // First name validation
  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  // Last name validation
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  // Street address validation
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  // City validation
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  // State/Province validation
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  }

  // Postal code validation (alphanumeric)
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  } else if (!/^[a-zA-Z0-9\s]+$/.test(data.postalCode.trim())) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters and numbers' });
  }

  // Country validation
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  // Email validation
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email.trim())) {
    errors.push({ field: 'email', message: 'Email is not valid' });
  }

  // Phone validation (international formats)
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[0-9\s()\\-]+$/.test(data.phone.trim())) {
    errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +' });
  }

  return errors;
}

// Insert form submission into database
function insertSubmission(data: FormData): void {
  if (!db) throw new Error('Database not initialized');

  const stmt = db.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);

  stmt.run([
    data.firstName,
    data.lastName,
    data.streetAddress,
    data.city,
    data.stateProvince,
    data.postalCode,
    data.country,
    data.email,
    data.phone
  ]);

  stmt.free();
  saveDatabase();
}

// Close database connection
function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

// Setup Express app
const app = express();

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static('public'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (errors.length > 0) {
    const errorMessages = errors.map(error => error.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData
    });
    return;
  }

  try {
    insertSubmission(formData);
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Failed to insert submission:', error);
    res.status(500).render('form', {
      errors: ['Failed to save your information. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // For simplicity, we'll use "Friend" as a fallback name
  res.render('thank-you', { firstName: 'Friend' });
});

// Setup EJS engine
app.set('view engine', 'ejs');
app.set('views', path.join('src', 'templates'));

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  closeDatabase();
  process.exit(0);
}

// Register shutdown handlers
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();
  
  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
