/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /)
 * with proper padding (=) when required.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Validate that input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the standard Base64 alphabet');
  }

  // Check that the input length is valid (must be multiple of 4 after padding)
  const cleanInput = input.replace(/=/g, '');
  if (cleanInput.length % 4 !== 0 && cleanInput.length % 4 !== 2 && cleanInput.length % 4 !== 3) {
    throw new Error('Invalid Base64 input: length must be valid for Base64 encoding');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
