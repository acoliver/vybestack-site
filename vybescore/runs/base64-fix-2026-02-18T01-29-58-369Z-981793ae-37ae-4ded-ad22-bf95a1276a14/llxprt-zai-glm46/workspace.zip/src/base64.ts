/**
 * Validate that a string is valid Base64 input.
 * Throws an error if the input contains characters outside the Base64 alphabet.
 */
function validateBase64(input: string): void {
  if (!/^[A-Za-z0-9+/=]+$/.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside Base64 alphabet');
  }

  // Check that padding is only at the end and properly formatted
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Ensure all padding characters are at the end
    const paddingMatch = input.match(/=+$/);
    if (!paddingMatch || paddingMatch.index !== paddingIndex) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
    // Ensure no more than 2 padding characters
    if (paddingMatch[0].length > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
  }
}

/**
 * Encode plain text to Base64 using the standard Base64 alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and throws an error
 * for clearly invalid payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();

  // Validate the input before attempting to decode
  validateBase64(trimmed);

  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if the buffer is empty (invalid input)
    if (buffer.length === 0 && trimmed.length > 0) {
      throw new Error('Invalid Base64 input: could not decode');
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
