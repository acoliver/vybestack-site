/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  updateObserver,
  EqualFn,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Wrap the update function to handle notifying our dependencies
  const originalUpdateFn = o.updateFn
  o.updateFn = (currentVal?: T) => {
    const newVal = originalUpdateFn(currentVal)
    
    // Update our cached value
    const oldVal = o.value
    o.value = newVal
    
    // Always notify depending observers if they exist and value changed
    if (dependingObserver && (!equalFn || !equalFn(oldVal!, newVal!))) {
      updateObserver(dependingObserver)
    }
    
    return newVal
  }
  
  // Store the observer that depends on this computed value
  let dependingObserver: Observer<unknown> | undefined
  
  // Store observer for when this computed is used as a dependency
  const getter: GetterFn<T> = () => {
    // If this computed is being accessed from within another observer,
    // we need to store the active observer so we can notify it
    const activeObserver = getActiveObserver()
    if (activeObserver && activeObserver !== o) {
      // This computed is being accessed as a dependency by another observer
      dependingObserver = activeObserver as Observer<unknown>
    }
    
    // Compute initial value if not yet computed
    if (o.value === undefined) {
      updateObserver(o)
    }
    
    return o.value!
  }

  return getter
}