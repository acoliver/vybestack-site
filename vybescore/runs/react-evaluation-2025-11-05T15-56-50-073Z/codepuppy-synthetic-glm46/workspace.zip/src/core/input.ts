/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }
  
  // Store multiple observers since multiple computed values can depend on this input
  const observers: Set<Observer<T>> = new Set()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      observers.add(observer as Observer<T>)
      s.observer = observer  // Keep for backwards compatibility
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed based on equality function
    if (s.equalFn) {
      if (s.equalFn(s.value, nextValue)) {
        return s.value
      }
    } else if (s.value === nextValue) {
      return s.value
    }
    
    s.value = nextValue
    
    // Notify all observers
    for (const observer of observers) {
      updateObserver(observer)
    }
    
    return s.value
  }

  return [read, write]
}
