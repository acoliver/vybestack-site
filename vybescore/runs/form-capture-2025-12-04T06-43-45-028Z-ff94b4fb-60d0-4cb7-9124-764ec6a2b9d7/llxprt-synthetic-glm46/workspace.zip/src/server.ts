import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';


// eslint-disable-next-line @typescript-eslint/no-explicit-any
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

type FormData = {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
};

type ValidationError = {
  field: string;
  message: string;
};

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any = null;
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs();
    
    let data: Uint8Array | null = null;
    if (fs.existsSync(DB_PATH)) {
      data = fs.readFileSync(DB_PATH);
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      db = new (SQL as any).Database(data);
      console.log('Database loaded from file');
    } else {
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      db = new (SQL as any).Database();
      console.log('New database created');
    }
    
    const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (db as any).run(schema);
    console.log('Database schema initialized');
    
    saveDatabase();
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) return;
  
  try {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    const data = (db as any).export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateForm(formData: FormData): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!formData.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!formData.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!formData.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!formData.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!formData.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State/Province/Region is required' });
  }
  
  if (!formData.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal/Zip code is required' });
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code contains invalid characters' });
  }
  
  if (!formData.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!formData.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!formData.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[0-9\s()/-]+$/.test(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number contains invalid characters' });
  }
  
  return errors;
}

function saveSubmission(formData: FormData): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const stmt = (db as any).prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
  } finally {
    stmt.free();
  }
  
  saveDatabase();
}

function gracefulShutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    (db as any).close();
    console.log('Database connection closed');
  }
  process.exit(0);
}

async function startServer(): Promise<void> {
  const app = express();
  const port = process.env.PORT || 3535;
  
  await initializeDatabase();
  
  app.use(express.urlencoded({ extended: true }));
  app.use('/public', express.static(path.join(__dirname, '../public')));
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: [], 
      values: {} 
    });
  });
  
  app.post('/submit', (req: Request, res: Response) => {
    const formData: FormData = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone
    };
    
    const errors = validateForm(formData);
    
    if (errors.length > 0) {
      return res.status(400).render('form', { 
        errors: errors.map(e => e.message), 
        values: formData 
      });
    }
    
    saveSubmission(formData);
    res.redirect(302, '/thank-you');
  });
  
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you');
  });
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
  
  // Only process gracefulShutdown when the server actually closes
  // Don't attach it to the server's close event
}

startServer().catch(console.error);
