/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  interface GlobalObserver {
    __activeObserver?: Observer<T>
  }
  const observer: Observer<T> = {
    value,
    updateFn,
  }

  // Execute the callback once to establish dependencies and perform initial side effect
  const globalObserver = globalThis as GlobalObserver
  const previousObserver = globalObserver.__activeObserver
  globalObserver.__activeObserver = observer
  try {
    observer.value = updateFn(observer.value)
  } finally {
    globalObserver.__activeObserver = previousObserver
  }

  // Register observer to track dependencies at the end to track initial dependencies
  updateObserver(observer)

  let disposed = false

  return () => {
    if (disposed) return
    disposed = true

    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
