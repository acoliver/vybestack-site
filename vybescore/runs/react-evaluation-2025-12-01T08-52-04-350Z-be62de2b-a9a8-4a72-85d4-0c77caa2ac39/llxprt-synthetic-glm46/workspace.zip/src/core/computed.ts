/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  interface GlobalObserver {
    __activeObserver?: Observer<T>
  }
  const equalFn: EqualFn<T> | undefined = 
    _equal === true ? ((a: T, b: T) => a === b) :
    _equal === false ? undefined :
    _equal

  let initialized = false
  const o: Observer<T> = {
    name: options?.name,
    // Don't set initial value - compute will set it using updateFn and the provided parameter
    value: undefined,
    updateFn,
  }

  const compute = (): T => {
    const globalObserver = globalThis as GlobalObserver
    const previousObserver = globalObserver.__activeObserver

    // Set this computed as the active observer to track dependencies
    globalObserver.__activeObserver = o
    try {
      // If we haven't initialized yet, use the provided value parameter
      if (!initialized) {
        o.value = updateFn(value)
        initialized = true
      } else {
        // Otherwise, use the current value for recomputation
        const newValue = updateFn(o.value)
        
        // If we have an equalFn and value hasn't changed, return current value
        if (equalFn && equalFn(o.value!, newValue)) {
          return o.value!
        }
        
        o.value = newValue
      }
      return o.value!
    } finally {
      globalObserver.__activeObserver = previousObserver
    }
  }

  // Register this computed so it can be updated by dependencies
  updateObserver(o)
  
  // Return a getter that recomputes when dependencies change
  return compute
}