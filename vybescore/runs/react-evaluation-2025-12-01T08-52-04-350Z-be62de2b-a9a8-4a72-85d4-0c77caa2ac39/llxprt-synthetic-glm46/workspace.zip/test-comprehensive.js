// Comprehensive test matching the reactive-comprehensive.spec.ts test cases
import { createInput, createComputed, createCallback } from './dist/src/index.js';

console.log('Testing compute cells can depend on other compute cells...');
const [input, setInput] = createInput(1);
const timesTwo = createComputed(() => input() * 2);
const timesThirty = createComputed(() => input() * 30);
const sum = createComputed(() => timesTwo() + timesThirty());
console.log('Sum initial:', sum()); // should be 32
setInput(3);
console.log('Sum after setInput(3):', sum()); // should be 96
console.log('[OK] compute cells can depend on other compute cells');

console.log('\nTesting compute cells fire callbacks...');
const [input2, setInput2] = createInput(1);
const output = createComputed(() => input2() + 1);
let value = 0;
createCallback(() => (value = output()));
console.log('Initial callback value:', value); // should be 2
setInput2(3);
console.log('Callback value after setInput2(3):', value); // should be 4
console.log('[OK] compute cells fire callbacks');

console.log('\nTesting callbacks can be added and removed...');
const [input3, setInput3] = createInput(11);
const output3 = createComputed(() => input3() + 1);
const values1 = [];
const unsubscribe1 = createCallback(() => values1.push(output3()));
const values2 = [];
createCallback(() => values2.push(output3()));

setInput3(31);
console.log('Values1 length after first change:', values1.length); // should be 1
console.log('Values2 length after first change:', values2.length); // should be 1

unsubscribe1();
setInput3(41);

console.log('Values1 length after unsubscribe and change:', values1.length); // should be 1
console.log('Values2 length after unsubscribe and change:', values2.length); // should be 2
console.log('Values1 content:', values1);
console.log('Values2 content:', values2);
console.log('[OK] callbacks can be added and removed');

console.log('\n All comprehensive tests passed!');