// Simple Node.js test to verify functionality
import { createInput, createComputed, createCallback } from './dist/src/index.js';

console.log('Testing createInput...');
const [getter, setter] = createInput(42);
console.log('Initial value:', getter());
console.log('Updating value...');
setter(100);
console.log('Updated value:', getter());

console.log('\nTesting createComputed...');
const [inputGetter, inputSetter] = createInput(5);
const double = createComputed(() => inputGetter() * 2);
console.log('Computed initial value:', double());
inputSetter(10);
console.log('Computed updated value:', double());

console.log('\nTesting createComputed with initial value...');
const computedWithInitial = createComputed((x = 3) => x * 2);
console.log('Computed with initial value:', computedWithInitial());

console.log('\nTesting createCallback...');
let callbackValue = 0;
const unsubscribe = createCallback(() => {
  callbackValue = double();
});
console.log('Callback should have been called initially, value:', callbackValue);
inputSetter(20);
console.log('After input change, callback value:', callbackValue);

console.log('\nAll basic tests passed!');