import { defineConfig } from 'vitest/config'

export default defineConfig({
  test: {
    include: ['tests/public/**/*.spec.ts'],
    environment: 'node',
    alias: {
      '@': '/home/runner/work/vybestack-site/vybestack-site/evals/outputs/react-evaluation-2025-12-01T08-52-04-350Z-be62de2b-a9a8-4a72-85d4-0c77caa2ac39/src'
    }
  }
})