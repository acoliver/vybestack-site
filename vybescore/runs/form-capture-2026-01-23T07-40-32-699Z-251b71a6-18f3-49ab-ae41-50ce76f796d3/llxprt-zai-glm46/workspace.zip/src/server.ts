import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs from 'sql.js';
import type { Database } from 'sql.js';

const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;
const DB_DIR = path.resolve('data');
const DB_PATH = path.join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormValues {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();
  
  let database: Database;
  
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    database = new SQL.Database(buffer);
  } else {
    if (!fs.existsSync(DB_DIR)) {
      fs.mkdirSync(DB_DIR, { recursive: true });
    }
    database = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    database.run(schema);
    saveDatabase(database);
  }
  
  return database;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^@?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(code: string): boolean {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  return postalRegex.test(code) && code.trim().length > 0;
}

function validateForm(values: FormValues): ValidationError[] {
  const errors: ValidationError[] = [];
  
  if (!values.firstName.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!values.lastName.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!values.streetAddress.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!values.city.trim()) {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!values.stateProvince.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }
  
  if (!values.postalCode.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!validatePostalCode(values.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code must contain only letters, digits, spaces, and hyphens' });
  }
  
  if (!values.country.trim()) {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!values.email.trim()) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(values.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!values.phone.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(values.phone)) {
    errors.push({ field: 'phone', message: 'Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading @' });
  }
  
  return errors;
}

async function main(): Promise<void> {
  const app = express();
  
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  
  db = await initializeDatabase();
  
  app.set('view engine', 'ejs');
  app.set('views', path.resolve('src', 'templates'));
  
  app.use(express.static(path.resolve('public')));
  
  app.get('/', (req: Request, res: Response) => {
    res.render('form.ejs', { errors: [], values: {} });
  });
  
  app.post('/submit', (req: Request, res: Response) => {
    const values: FormValues = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || '',
    };
    
    const errors = validateForm(values);
    
    if (errors.length > 0) {
      const errorMessages = errors.map(e => e.message);
      res.status(400).render('form.ejs', { errors: errorMessages, values });
      return;
    }
    
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        values.firstName,
        values.lastName,
        values.streetAddress,
        values.city,
        values.stateProvince,
        values.postalCode,
        values.country,
        values.email,
        values.phone,
      ]
    );
    
    saveDatabase(db);
    
    res.redirect(302, `/thank-you?firstName=${encodeURIComponent(values.firstName)}`);
  });
  
  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName as string || 'friend';
    res.render('thank-you.ejs', { firstName });
  });
  
  const server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
  
  setupGracefulShutdown(server, db);
}

function setupGracefulShutdown(server: { close: (callback?: () => void) => void }, database: Database | null): void {
  const shutdown = (signal: string) => {
    console.log(`Received ${signal}, closing server gracefully...`);
    server.close(() => {
      console.log('Server closed');
      if (database) {
        database.close();
        console.log('Database closed');
      }
      process.exit(0);
    });
    
    setTimeout(() => {
      console.error('Forced shutdown after timeout');
      process.exit(1);
    }, 10000);
  };
  
  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});

export {};
