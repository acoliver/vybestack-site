-- Create submissions table
CREATE TABLE IF NOT EXISTS submissions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  firstName TEXT NOT NULL,
  lastName TEXT NOT NULL,
  streetAddress TEXT NOT NULL,
  city TEXT NOT NULL,
  stateProvince TEXT NOT NULL,
  postalCode TEXT NOT NULL,
  country TEXT NOT NULL,
  email TEXT NOT NULL,
  phone TEXT NOT NULL,
  submittedAt DATETIME DEFAULT CURRENT_TIMESTAMP
);
