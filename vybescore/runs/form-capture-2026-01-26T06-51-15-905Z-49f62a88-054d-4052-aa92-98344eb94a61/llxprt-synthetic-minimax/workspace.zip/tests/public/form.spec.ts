import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load as cheerioLoad } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: import('http').Server;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import the server module
  const { default: app } = await import('../../dist/server.js');
  server = app.listen(3536);
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    
    const $ = cheerioLoad(response.text);
    expect($('form').length).toBe(1);
    
    // Check for all required form fields
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city',
      'stateProvince', 'postalCode', 'country', 'email', 'phone'
    ];
    
    requiredFields.forEach(field => {
      expect($(`[name="${field}"]`).length).toBe(1);
    });
  });

  it('persists submission and redirects', async () => {
    // Clean database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };

    const response = await request(server)
      .post('/submit')
      .type('application/x-www-form-urlencoded')
      .send(formData);

    expect(response.status).toBe(302);
    expect(response.header.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
