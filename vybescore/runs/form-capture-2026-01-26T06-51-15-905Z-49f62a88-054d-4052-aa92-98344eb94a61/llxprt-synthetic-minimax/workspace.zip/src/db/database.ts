import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = import.meta.url;
const __dirname = path.dirname(fileURLToPath(__filename));

const DB_PATH = path.join(__dirname, '../../data/submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '../../db/schema.sql');

let db: Database | null = null;

export interface ContactSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export const database = {
  async initialize(): Promise<void> {
    await initDatabase();
  },

  async insertSubmission(submission: Omit<ContactSubmission, keyof ContactSubmission> & ContactSubmission): Promise<number> {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        firstName, lastName, streetAddress, city, 
        stateProvince, postalCode, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();
    saveDatabase();
    return 1; // Return insert ID if needed
  },

  async close(): Promise<void> {
    closeDatabase();
  },

  async getAllSubmissions(): Promise<ContactSubmission[]> {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const result = db.exec('SELECT * FROM submissions ORDER BY submittedAt DESC');
    if (result.length === 0) return [];

    const submissions: ContactSubmission[] = [];

    for (const row of result[0].values) {
      const submission: ContactSubmission = {
        firstName: row[1] as string,
        lastName: row[2] as string,
        streetAddress: row[3] as string,
        city: row[4] as string,
        stateProvince: row[5] as string,
        postalCode: row[6] as string,
        country: row[7] as string,
        email: row[8] as string,
        phone: row[9] as string
      };
      submissions.push(submission);
    }

    return submissions;
  }
};

async function initDatabase(): Promise<void> {
  try {
    const SQL = await initSqlJs({
      locateFile: (file: string) => {
        // Use the sql.js package location for WASM file
        return path.join(process.cwd(), 'node_modules/sql.js/dist', file);
      }
    });

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const fileBuffer = fs.readFileSync(DB_PATH);
      db = new SQL.Database(fileBuffer);
      console.log('Loaded existing database');
    } else {
      db = new SQL.Database();
      
      // Read and execute schema
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf8');
      db.exec(schema);
      console.log('Created new database with schema');
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  const data = db.export();
  fs.writeFileSync(DB_PATH, data);
}

function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
    console.log('Database closed');
  }
}

// Handle graceful shutdown
process.on('SIGTERM', () => {
  console.log('Received SIGTERM, closing database...');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('Received SIGINT, closing database...');
  closeDatabase();
  process.exit(0);
});