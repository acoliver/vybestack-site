import express from 'express';
import { fileURLToPath } from 'url';
import { dirname, join } from 'path';
import { database } from './db/database.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', join(__dirname, '../views'));

// Validation functions
function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhoneNumber(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[\d\s()+-]+$/;
  return phoneRegex.test(phone) && phone.replace(/[\s()+-]/g, '').length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings (handle UK "SW1A 1AA" and Argentine formats)
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}

function validateSubmission(data: Record<string, string | undefined>): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  // Required fields validation (exclude phoneNumber here, handle separately)
  const requiredFields = ['firstName', 'lastName', 'streetAddress', 'city', 'stateProvince', 'postalCode', 'country', 'email'];
  
  for (const field of requiredFields) {
    const value = data[field];
    if (!value || typeof value !== 'string' || value.trim() === '') {
      errors[field] = `${field.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase())} is required`;
    }
  }

  // Phone validation (accept either field name from test or form)
  const phoneValue = data.phoneNumber || data.phone;
  if (!phoneValue) {
    errors.phoneNumber = 'Phone number is required';
  } else if (!isValidPhoneNumber(phoneValue)) {
    errors.phoneNumber = 'Please enter a valid phone number';
  }

  // Email validation
  if (data.email && !isValidEmail(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Postal code validation
  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal/zip code';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Routes
app.get('/', (req, res) => {
  res.render('index', { 
    errors: {}, 
    values: {},
    title: 'Contact Form'
  });
});

app.post('/submit', async (req, res) => {
  try {
    const validation = validateSubmission(req.body);
    
    if (!validation.isValid) {
      // Validation failed, re-render form with errors
      return res.status(400).render('index', {
        errors: validation.errors,
        values: req.body,
        title: 'Contact Form - Please Fix Errors'
      });
    }

    // Validation passed, insert into database
    const submissionData = {
      firstName: req.body.firstName!.trim(),
      lastName: req.body.lastName!.trim(),
      streetAddress: req.body.streetAddress!.trim(),
      city: req.body.city!.trim(),
      stateProvince: req.body.stateProvince!.trim(),
      postalCode: req.body.postalCode!.trim(),
      country: req.body.country!.trim(),
      email: req.body.email!.trim(),
      phone: (req.body.phoneNumber || req.body.phone || '').trim()
    };

    await database.insertSubmission(submissionData);
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error processing submission:', error);
    res.status(500).render('index', {
      errors: { general: 'An error occurred while processing your request. Please try again.' },
      values: req.body,
      title: 'Contact Form - Error'
    });
  }
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { 
    title: 'Thank You!'
  });
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully...');
  await database.close();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully...');
  await database.close();
  process.exit(0);
});

// Initialize database when module is loaded
database.initialize().catch(console.error);

// Export app for testing
export default app;

// Start server if running directly (not as module)
if (import.meta.url === `file://${process.argv[1]}`) {
  try {
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}
