const INVALID_BASE64_PREFIX = 'Invalid Base64 input:';

/**
 * Encode plain text to Base64 using the canonical alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8, accepting standard Base64 input with or without padding.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Empty input is invalid
  if (trimmed.length === 0) {
    throw new Error(`${INVALID_BASE64_PREFIX} empty input`);
  }
  
  // Basic validation: Base64 should only contain A-Z, a-z, 0-9, +, /, and optional padding =
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(trimmed)) {
    throw new Error(`${INVALID_BASE64_PREFIX} contains illegal characters`);
  }

  validatePaddingStructure(trimmed);
  
  return decodeWithVerification(trimmed);
}

function validatePaddingStructure(trimmed: string): void {
  const paddingIndex = trimmed.indexOf('=');
  
  if (paddingIndex !== -1) {
    validatePaddingCharacters(trimmed, paddingIndex);
    validatePaddingLength(trimmed);
    validatePaddingPosition(trimmed, paddingIndex);
  }
}

function validatePaddingCharacters(trimmed: string, paddingIndex: number): void {
  const padding = trimmed.substring(paddingIndex);
  
  if (!/^[=]+$/.test(padding)) {
    throw new Error(`${INVALID_BASE64_PREFIX} padding characters appear before non-padding characters`);
  }
}

function validatePaddingLength(trimmed: string): void {
  const paddingMatch = trimmed.match(/(=*)$/);
  const padding = paddingMatch ? paddingMatch[1] : '';
  const paddingLength = padding.length;
  
  if (paddingLength > 2) {
    throw new Error(`${INVALID_BASE64_PREFIX} too many padding characters`);
  }
}

function validatePaddingPosition(trimmed: string, paddingIndex: number): void {
  const padding = trimmed.substring(paddingIndex);
  const lastBlock = trimmed.slice(-4);
  const nonPaddingLength = lastBlock.replace(/=/g, '').length;
  
  if (padding === '=' && nonPaddingLength !== 3) {
    throw new Error(`${INVALID_BASE64_PREFIX} incorrect padding for length`);
  }
  if (padding === '==' && nonPaddingLength !== 2) {
    throw new Error(`${INVALID_BASE64_PREFIX} incorrect padding for length`);
  }
  
  // Check that any padding is at the end of the string
  if (trimmed.includes('=') && !trimmed.endsWith('=')) {
    throw new Error(`${INVALID_BASE64_PREFIX} padding not at end`);
  }
  
  // Special case: validate padding by actually trying to decode and re-encode
  // If the encoding result differs from the input in padding, it's invalid
  if (padding.length > 0) {
    const buffer = Buffer.from(trimmed, 'base64');
    const reencoded = buffer.toString('base64');
    
    // If the re-encoded version has different padding than input,
    // the input had incorrect padding
    if (reencoded !== trimmed) {
      // Check if the only difference is padding amount
      const inputWithoutPadding = trimmed.replace(/=+$/, '');
      const reencodedWithoutPadding = reencoded.replace(/=+$/, '');
      
      if (inputWithoutPadding === reencodedWithoutPadding) {
        throw new Error(`${INVALID_BASE64_PREFIX} incorrect padding for length`);
      }
    }
  }
}

function decodeWithVerification(trimmed: string): string {
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if Buffer.from actually consumed data
    if (buffer.length === 0 && trimmed.length > 0) {
      // This can happen with malformed input like single '='
      throw new Error(`${INVALID_BASE64_PREFIX} malformed data`);
    }
    
    const reencoded = buffer.toString('base64');
    
    // For comparison, normalize both by removing padding
    const normalizedOriginal = trimmed.replace(/=+$/, '');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    
    if (normalizedOriginal !== normalizedReencoded) {
      throw new Error(`${INVALID_BASE64_PREFIX} malformed data`);
    }
    
    return buffer.toString('utf8');
  } catch (error) {
    if (error instanceof Error && error.message.includes(INVALID_BASE64_PREFIX)) {
      throw error;
    }
    throw new Error(`${INVALID_BASE64_PREFIX} malformed data`);
  }
}