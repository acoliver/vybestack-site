/**
 * Find words starting with a prefix, excluding listed exceptions.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive comparison)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  
  return matches.filter(word => 
    !exceptionsLower.includes(word.toLowerCase())
  );
}

/**
 * Find occurrences of a token only when:
 * - It appears after a digit
 * - It is NOT at the start of the string
 * Uses lookbehind to ensure the token follows a digit.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // We want to find the token when it follows a digit
  // The lookbehind (?<=\d) ensures the token is preceded by a digit
  // This matches only the token, not including the digit

  // The problem is we need to return the full match including the digit
  // So let's use a different approach - capture the digit + token
  const fullMatchPattern = new RegExp(`\\d${escapedToken}`, 'g');
  const fullMatches = text.match(fullMatchPattern) || [];

  return fullMatches;
}

/**
 * Validate password strength:
 * - At least 10 characters
 * - At least one uppercase letter
 * - At least one lowercase letter
 * - At least one digit
 * - At least one symbol (non-alphanumeric)
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab, abcabc)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-whitespace)
  if (!/[^A-Za-z0-9\s]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences
  // A sequence is a pattern of 2-4 characters that repeats immediately
  // Examples: abab, abcabc, 123123, xyxyxy
  
  for (let seqLen = 2; seqLen <= 4; seqLen++) {
    for (let i = 0; i <= value.length - (seqLen * 2); i++) {
      const seq = value.slice(i, i + seqLen);
      const nextSeq = value.slice(i + seqLen, i + seqLen * 2);
      
      if (seq === nextSeq) {
        return false;
      }
    }
  }
  
  // Check for character repetition (same character repeated)
  // We allow some repetition but not excessive (more than 2 same chars in a row)
  if (/(.)\1\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detect IPv6 addresses including shorthand notation.
 * Should NOT detect IPv4 addresses.
 * Returns true if IPv6 is detected.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns to detect:
  // - Full format: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed zeros: 2001:db8:85a3::8a2e:370:7334
  // - Leading zeros omitted: 2001:db8:85a3:0:0:8a2e:370:7334
  // - Loopback: ::1
  // - All zeros: ::
  // - Mixed with IPv4 (should still count as IPv6): ::ffff:192.0.2.1
  
  // This regex matches IPv6 addresses in their various forms
  // It does NOT match pure IPv4 addresses (which are dots and decimals)
  const ipv6Pattern = /(?:^|(?<=[\s[\]"']))([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}/;
  
  // Also need to handle edge cases like single ::, ::1, etc.
  const edgeCases = /::[0-9a-fA-F]{0,4}|[0-9a-fA-F]{1,4}::/;
  
  // Also handle IPv6 with embedded IPv4 (like ::ffff:192.168.1.1)
  const ipv6WithIPv4 = /(?:[0-9a-fA-F]{1,4}:){1,4}:\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}|::(?:ffff:)?\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/i;
  
  // Pure IPv4 pattern - we need to make sure we don't match these
  const ipv4Pattern = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  
  // First, check if the entire value is just an IPv4 address
  if (ipv4Pattern.test(value.trim())) {
    return false;
  }
  
  // Check for IPv6 patterns
  if (ipv6Pattern.test(value) || edgeCases.test(value) || ipv6WithIPv4.test(value)) {
    return true;
  }
  
  return false;
}
