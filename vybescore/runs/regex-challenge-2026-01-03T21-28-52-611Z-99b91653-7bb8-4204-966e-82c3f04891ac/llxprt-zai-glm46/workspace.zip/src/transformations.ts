/**
 * Capitalize the first character of each sentence.
 * - Capitalize after ., ?, ! sentence endings
 * - Insert exactly one space between sentences
 * - Collapse extra spaces while preserving reasonable spacing
 * - Leave abbreviations intact when possible
 */
export function capitalizeSentences(text: string): string {
  // Step 1: Normalize whitespace - collapse multiple spaces into one, but preserve sentence boundaries
  let result = text.replace(/[ \t]+/g, ' ');
  
  // Step 2: Ensure proper spacing after sentence endings (., ?, !)
  // Add space after sentence endings if not present
  result = result.replace(/([.!?])([A-Za-z])/g, '$1 $2');
  
  // Step 3: Capitalize first character of the string
  result = result.charAt(0).toUpperCase() + result.slice(1);
  
  // Step 4: Capitalize after sentence endings, but be careful with abbreviations
  // Common abbreviations that should NOT trigger capitalization
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'vs', 'etc', 'i.e', 'e.g', 'St', 'Ave', 'Blvd', 'Rd', 'Lt', 'Col', 'Gen', 'Sen', 'Rep', 'Pres', 'Capt', 'Sgt', 'Adm', 'Rev'];
  const abbrPattern = abbreviations.join('|');
  
  // First, mark abbreviations to protect them
  const tempMarker = '__ABBR__';
  const protectedResult = result.replace(new RegExp(`\\b(${abbrPattern})\\.`,'gi'), (match) => match.replace('.', tempMarker));
  
  // Now capitalize after sentence endings
  const capitalized = protectedResult.replace(/([.!?])\s+([a-z])/g, (match, punctuation, letter) => {
    return punctuation + ' ' + letter.toUpperCase();
  });
  
  // Restore abbreviations
  result = capitalized.replace(new RegExp(tempMarker, 'g'), '.');
  
  // Step 5: Clean up any double spaces that might have been created
  result = result.replace(/  +/g, ' ');
  
  // Trim leading/trailing whitespace
  result = result.trim();
  
  return result;
}

/**
 * Extract URLs from text, excluding trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http, https, and common URL formats
  // Excludes trailing punctuation like ., ,, !, ?, etc.
  const urlPattern = /https?:\/\/(?:www\.)?[^\s<>"']+(?<![.,;!?:])/g;
  
  const matches = text.match(urlPattern) || [];
  
  return matches;
}

/**
 * Convert all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// globally
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match example.com URLs
  const urlRegex = /(https?:\/\/)([^/]+)(\/[^\s]*)/g;
  
  return text.replace(urlRegex, (match, scheme, host, path) => {
    // Only process example.com and its subdomains
    if (!host.includes('example.com')) {
      return match;
    }
    
    // Always upgrade scheme to https
    const newScheme = 'https://';
    
    // Check if path contains dynamic hints or legacy extensions
    const dynamicHints = ['cgi-bin', '?', '&', '='];
    const legacyExtensions = ['.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
    
    const hasDynamicHint = dynamicHints.some(hint => path.includes(hint));
    const hasLegacyExtension = legacyExtensions.some(ext => path.toLowerCase().includes(ext));
    
    // Check if path starts with /docs/
    const isDocsPath = path.startsWith('/docs/');
    
    if (isDocsPath && !hasDynamicHint && !hasLegacyExtension) {
      // Rewrite to docs.example.com
      return newScheme + 'docs.example.com' + path;
    } else {
      // Just upgrade the scheme
      return newScheme + host + path;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy formatted strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  const year = parseInt(yearStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Assume leap year for Feb
  
  if (day < 1 || day > daysInMonth[month]) {
    return 'N/A';
  }
  
  // Year should be reasonable (e.g., between 1000 and 9999)
  if (year < 1000 || year > 9999) {
    return 'N/A';
  }
  
  return yearStr;
}
