export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses according to common rules.
 * Accepts: name+tag@example.co.uk style addresses
 * Rejects: double dots, trailing dots, domains with underscores, other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Local part: alphanumerics, dots, hyphens, underscores, plus signs
  // Domain: alphanumerics, hyphens, dots (but no underscores, no consecutive dots, no trailing dot)
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,})$/;
  
  // Additional checks for invalid patterns
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Check for consecutive dots in local or domain part
  if (value.includes('..')) {
    return false;
  }
  
  // Check for trailing dot before @ or at end
  const parts = value.split('@');
  if (parts.length !== 2) {
    return false;
  }
  
  const [local, domain] = parts;
  
  // Local part cannot start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Domain cannot have underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain cannot start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Domain parts cannot start or end with hyphen
  const domainParts = domain.split('.');
  for (const part of domainParts) {
    if (part.startsWith('-') || part.endsWith('-')) {
      return false;
    }
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows: area codes starting with 0/1, too short inputs
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Strip all spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Handle optional +1 prefix
  const hasPlusOne = cleaned.startsWith('+1');
  const withoutPrefix = hasPlusOne ? cleaned.slice(2) : cleaned;
  
  // Remove parentheses for validation
  const withoutParens = withoutPrefix.replace(/[()]/g, '');
  
  // Must be exactly 10 digits (or with optional extension)
  const digitsOnly = withoutParens.replace(/\D/g, '');
  
  if (digitsOnly.length < 10) {
    return false;
  }
  
  const first10 = digitsOnly.slice(0, 10);
  
  // Area code cannot start with 0 or 1
  const areaCode = first10.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (middle 3 digits) cannot start with 0 or 1
  const exchangeCode = first10.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Check if we have an extension
  const rest = digitsOnly.slice(10);
  if (rest.length > 0) {
    if (!options?.allowExtensions) {
      return false;
    }
    // Extension is any number of digits
  }
  
  // Validate the format matches common patterns
  // Valid patterns: (XXX) XXX-XXXX, XXX-XXX-XXXX, XXXXXXXXX, +1...
  const phoneRegex = /^\+?1?\s*(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}(\s*(ext|x|#)\s*\d+)?$/i;
  
  return phoneRegex.test(value.trim());
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * Supports: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code (required when country code omitted)
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - Single spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for digit extraction
  const digitsOnly = value.replace(/[\s-]/g, '');
  
  // Extract all digits
  const digits = digitsOnly.replace(/\D/g, '');
  
  // Check minimum/maximum length
  // Minimum: 2-digit area code + 6-digit subscriber = 8 digits
  // Maximum: 4-digit area code + 8-digit subscriber = 12 digits
  // Plus optional country code (54) and mobile indicator (9)
  if (digits.length < 8 || digits.length > 14) {
    return false;
  }
  
  let hasCountryCode = false;
  let areaCodeStart = 0;
  
  // Check for country code +54
  if (digits.startsWith('54')) {
    hasCountryCode = true;
    areaCodeStart = 2;
  }
  
  // Check for mobile indicator 9 (after country code or at start)
  if (digits.length > areaCodeStart && digits[areaCodeStart] === '9') {
    areaCodeStart++;
  }
  
  // If no country code, must have trunk prefix 0 before area code
  let remainingDigits = digits.slice(areaCodeStart);
  if (!hasCountryCode) {
    if (remainingDigits.length > 0 && remainingDigits[0] === '0') {
      // Trunk prefix found, skip it for area code extraction
      remainingDigits = remainingDigits.slice(1);
    } else {
      // No trunk prefix without country code - invalid
      return false;
    }
  }
  
  // Extract area code (2-4 digits, leading digit 1-9)
  let areaCode = '';
  let subscriberDigits = '';
  
  // Try 4-digit area code first
  if (remainingDigits.length >= 10) {
    areaCode = remainingDigits.slice(0, 4);
    subscriberDigits = remainingDigits.slice(4);
  } else if (remainingDigits.length >= 9) {
    // Try 3-digit area code
    areaCode = remainingDigits.slice(0, 3);
    subscriberDigits = remainingDigits.slice(3);
  } else if (remainingDigits.length >= 8) {
    // Try 2-digit area code
    areaCode = remainingDigits.slice(0, 2);
    subscriberDigits = remainingDigits.slice(2);
  } else {
    return false;
  }
  
  // Validate area code: 2-4 digits, leading digit 1-9
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    // Try other lengths
    let valid = false;
    for (const len of [2, 3, 4]) {
      if (remainingDigits.length >= len + 6) {
        const testArea = remainingDigits.slice(0, len);
        const testSub = remainingDigits.slice(len);
        if (/^[1-9]\d{1,3}$/.test(testArea) && testSub.length >= 6 && testSub.length <= 8) {
          areaCode = testArea;
          subscriberDigits = testSub;
          valid = true;
          break;
        }
      }
    }
    if (!valid) {
      return false;
    }
  }
  
  // Validate subscriber number: 6-8 digits
  if (subscriberDigits.length < 6 || subscriberDigits.length > 8) {
    return false;
  }
  
  // Validate format with separators (spaces or hyphens)
  // Allow formats like: +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567
  const relaxedFormatRegex = /^\+?54[\s-]?9?[\s-]?\d{2,4}[\s-]?\d{4,8}$/;
  
  if (!relaxedFormatRegex.test(value.trim())) {
    // Try to match more complex formats with multiple separators
    const parts = value.trim().split(/[\s-]+/);
    const joined = parts.join('');
    
    // Must match pattern of digits
    if (!/^\+?549?\d{8,12}$/.test(joined) && !/^0\d{8,11}$/.test(joined)) {
      // Still fail if format is completely wrong
      // But we've already validated the digits, so let's be lenient on separators
    }
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects: digits, symbols, X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Unicode letters including accented characters
  // Allow: letters, apostrophes, hyphens, spaces
  // Reject: digits, special symbols
  
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Cannot be just spaces, hyphens, or apostrophes
  const trimmed = value.trim();
  if (trimmed.length === 0) {
    return false;
  }
  
  // Check for invalid patterns like consecutive apostrophes or weird spacing
  if (/''/.test(value) || /--/.test(value) || /  +/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let shouldDouble = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers for Visa, Mastercard, and AmEx.
 * Checks: prefixes, lengths, and Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  if (!visaRegex.test(cleaned) && !mastercardRegex.test(cleaned) && !amexRegex.test(cleaned)) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
