/**
 * Encode plain text to Base64 using the standard Base64 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check if input is valid Base64
  // Allow only standard Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Check for padding length validity
  const padding = input.match(/=+$/);
  const paddingCount = padding ? padding[0].length : 0;
  
  // Check if padding is at the end and doesn't exceed 2 characters
  if (paddingCount > 0 && input.indexOf('=') !== input.length - paddingCount) {
    throw new Error('Invalid Base64 input: padding not at the end');
  }
  
  // Check if total length is valid (must be divisible by 4 for proper Base64)
  // But we need to be flexible here - let Buffer handle the actual validation
  // since Node.js Buffer can handle various lengths

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
