import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
// @ts-expect-error - No type definitions available for sql.js
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.join(__dirname, '..');
const dbPath = path.join(projectRoot, 'data', 'submissions.sqlite');

// Interface for our form submission
interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Validation errors interface
interface ValidationError {
  field: string;
  message: string;
}

// Initialize database
let db: unknown;
async function initializeDatabase(): Promise<unknown> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.join(projectRoot, 'data');
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const SQL = await initSqlJs();
    
    // Load existing database or create a new one
    let dbBuffer: Uint8Array | undefined;
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      dbBuffer = new Uint8Array(fileBuffer);
    }
    
    const database = new SQL.Database(dbBuffer);
    
    // Create table if it doesn't exist
    const schemaSql = fs.readFileSync(path.join(projectRoot, 'db', 'schema.sql'), 'utf8');
    database.run(schemaSql);
    
    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    // Cast db to unknown to access export method
    const database = db as unknown as { export(): Uint8Array };
    const data = database.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return { field: fieldName, message: `${fieldName} is required` };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  if (!email || email.trim() === '') {
    return { field: 'email', message: 'Email is required' };
  }
  
  // Simple email validation regex
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  if (!phone || phone.trim() === '') {
    return { field: 'phone', message: 'Phone number is required' };
  }
  
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return { field: 'phone', message: 'Please enter a valid phone number' };
  }
  
  return null;
}

function validatePostalCode(postal: string): ValidationError | null {
  if (!postal || postal.trim() === '') {
    return { field: 'postal_code', message: 'Postal/Zip code is required' };
  }
  
  // Allow alphanumeric characters and spaces
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  if (!postalRegex.test(postal)) {
    return { field: 'postal_code', message: 'Postal/Zip code can only contain letters and numbers' };
  }
  
  return null;
}

function validateSubmission(values: Submission): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Validate required fields
  let error = validateRequired(values.first_name, 'First name');
  if (error) errors.push(error);
  
  error = validateRequired(values.last_name, 'Last name');
  if (error) errors.push(error);
  
  error = validateRequired(values.street_address, 'Street address');
  if (error) errors.push(error);
  
  error = validateRequired(values.city, 'City');
  if (error) errors.push(error);
  
  error = validateRequired(values.state_province, 'State/Province/Region');
  if (error) errors.push(error);
  
  error = validateRequired(values.country, 'Country');
  if (error) errors.push(error);
  
  // Validate specific formats
  error = validateEmail(values.email);
  if (error) errors.push(error);
  
  error = validatePhone(values.phone);
  if (error) errors.push(error);
  
  error = validatePostalCode(values.postal_code);
  if (error) errors.push(error);
  
  return errors;
}

async function startServer() {
  // Initialize database
  db = await initializeDatabase();
  
  // Create Express app
  const app = express();
  const port = process.env.PORT || 3535;
  
  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  app.use(express.static(path.join(projectRoot, 'public')));
  
  // Set EJS as the view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(projectRoot, 'src', 'templates'));
  
  // GET / - Show the form
  app.get('/', (req: Request, res: Response) => {
    res.render('form', { 
      errors: null, 
      values: {} 
    });
  });
  
  // POST /submit - Process form submission
  app.post('/submit', (req: Request, res: Response) => {
    const submission: Submission = {
      first_name: req.body.firstName || '',
      last_name: req.body.lastName || '',
      street_address: req.body.streetAddress || '',
      city: req.body.city || '',
      state_province: req.body.stateProvince || '',
      postal_code: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const errors = validateSubmission(submission);
    
    if (errors.length > 0) {
      // Return to form with errors and values
      return res.status(400).render('form', { 
        errors: errors.map(e => e.message), 
        values: {
          firstName: req.body.firstName,
          lastName: req.body.lastName,
          streetAddress: req.body.streetAddress,
          city: req.body.city,
          stateProvince: req.body.stateProvince,
          postalCode: req.body.postalCode,
          country: req.body.country,
          email: req.body.email,
          phone: req.body.phone
        }
      });
    }
    
    try {
      // Insert into database - cast database to unknown type for proper type access
      const database = db as unknown as {
        prepare(sql: string): {
          run(...values: unknown[]): unknown;
          free(): void;
        }
      };
      
      const stmt = database.prepare(`
        INSERT INTO submissions (
          first_name, 
          last_name, 
          street_address, 
          city, 
          state_province, 
          postal_code, 
          country, 
          email, 
          phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run(
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone
      );
      
      stmt.free();
      
      // Save the database
      saveDatabase();
      
      // Redirect to thank you page
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      return res.status(500).render('form', { 
        errors: ['Server error: Please try again later'], 
        values: req.body 
      });
    }
  });
  
  // GET /thank-you - Show thank you page
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', { 
      firstName: req.query.firstName || 'Friend' 
    });
  });
  
  // Start server
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Handle graceful shutdown
  const gracefulShutdown = () => {
    console.log('Received SIGTERM, shutting down gracefully');
    
    if (server) {
      server.close(() => {
        console.log('Express server closed');
        
        if (db) {
          // Cast to unknown to access close method
          const database = db as unknown as { close(): void };
          database.close();
          console.log('Database connection closed');
        }
        
        process.exit(0);
      });
    }
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown); // Handle Ctrl+C
  
  return server;
}

// Start the server
startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
