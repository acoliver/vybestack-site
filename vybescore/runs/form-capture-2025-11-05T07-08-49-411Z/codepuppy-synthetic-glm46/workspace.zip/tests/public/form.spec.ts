import { describe, expect, it } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    // Clean up any existing database file
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    // Create and start server dynamically for testing
    const serverModule = await import('../../dist/server.js');
    const FormCaptureApp = serverModule.default;
    const testApp = new FormCaptureApp(0); // Use random port
    await testApp.start();
    
    try {
      const response = await request(testApp.getApp())
        .get('/')
        .expect(200);
      
      const $ = cheerio.load(response.text);
      
      // Check that all required form fields are present
      expect($('input[name="firstName"]')).toHaveLength(1);
      expect($('input[name="lastName"]')).toHaveLength(1);
      expect($('input[name="streetAddress"]')).toHaveLength(1);
      expect($('input[name="city"]')).toHaveLength(1);
      expect($('input[name="stateProvince"]')).toHaveLength(1);
      expect($('input[name="postalCode"]')).toHaveLength(1);
      expect($('input[name="country"]')).toHaveLength(1);
      expect($('input[name="email"]')).toHaveLength(1);
      expect($('input[name="phone"]')).toHaveLength(1);
      expect($('form[action="/submit"]')).toHaveLength(1);
    } finally {
      await testApp.shutdown(true);
    }
  });
});