import express, { Request, Response } from 'express';
import * as http from 'node:http';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs from 'sql.js';

// Local type definitions for sql.js
interface Database {
  exec(sql: string): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

interface Statement {
  run(...params: unknown[]): void;
  free(): void;
}

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class FormCaptureApp {
  private app: express.Application;
  private server: http.Server | null = null;
  private db: Database | null = null;
  private SQL: { Database: new(data?: Uint8Array) => Database } | null = null;
  private dbPath: string;
  private port: number;

  constructor(port?: number) {
    this.app = express();
    this.port = port || 0; // 0 means random port
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    this.app.use(express.urlencoded({ extended: true }));
    this.app.use(express.json());
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    
    // Set up EJS - ensure it's imported correctly
    try {
      this.app.set('view engine', 'ejs');
      // When running from compiled JS, templates are still in src/
      const viewsPath = path.resolve(__dirname, '..', 'src', 'templates');
      this.app.set('views', viewsPath);
    } catch (error) {
      console.error('Error setting up EJS:', error);
      throw error;
    }
  }

  private async initializeDatabase(): Promise<void> {
    const SqlJs = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`,
    });
    
    this.SQL = SqlJs;

    let dbData: Uint8Array | null = null;
    
    // Ensure data directory exists
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(this.dbPath)) {
      const dbFile = fs.readFileSync(this.dbPath);
      dbData = new Uint8Array(dbFile);
    } else {
      // Create empty database
      dbData = new Uint8Array(0);
    }

    this.db = new SqlJs.Database(dbData);

    // Initialize schema if database is new
    if (dbData.length === 0) {
      const schema = fs.readFileSync(path.resolve(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      this.db.exec(schema);
      this.saveDatabase();
    }
  }

  private saveDatabase(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  private validateForm(data: Partial<FormData>): { isValid: boolean; errors: string[] } {
    const errors: string[] = [];

    // Required fields
    const requiredFields: (keyof FormData)[] = [
      'firstName', 'lastName', 'streetAddress', 'city', 'stateProvince',
      'postalCode', 'country', 'email', 'phone'
    ];

    for (const field of requiredFields) {
      if (!data[field] || data[field]!.trim() === '') {
        errors.push(`${this.getFieldLabel(field)} is required`);
      }
    }

    // Email validation
    if (data.email && data.email!.trim() !== '') {
      const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailRegex.test(data.email!)) {
        errors.push('Please enter a valid email address');
      }
    }

    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    if (data.phone && data.phone!.trim() !== '') {
      const phoneRegex = /^\+?[\d\s()-]+$/;
      if (!phoneRegex.test(data.phone!)) {
        errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and a leading +');
      }
    }

    // Postal code validation - alphanumeric characters and spaces
    if (data.postalCode && data.postalCode!.trim() !== '') {
      const postalRegex = /^[\da-zA-Z\s-]+$/;
      if (!postalRegex.test(data.postalCode!)) {
        errors.push('Postal code can only contain letters, digits, spaces, and dashes');
      }
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private getFieldLabel(field: keyof FormData): string {
    const labels: Record<keyof FormData, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      city: 'City',
      stateProvince: 'State / Province / Region',
      postalCode: 'Postal / Zip code',
      country: 'Country',
      email: 'Email',
      phone: 'Phone number'
    };
    return labels[field];
  }

  private setupRoutes(): void {
    // GET / - Render the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        values: {},
        errors: []
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', (req: Request, res: Response) => {
      const formData: Partial<FormData> = {
        firstName: req.body.firstName,
        lastName: req.body.lastName,
        streetAddress: req.body.streetAddress,
        city: req.body.city,
        stateProvince: req.body.stateProvince,
        postalCode: req.body.postalCode,
        country: req.body.country,
        email: req.body.email,
        phone: req.body.phone
      };

      const validation = this.validateForm(formData);
      
      if (!validation.isValid) {
        return res.status(400).render('form', {
          values: formData,
          errors: validation.errors
        });
      }

      // Insert into database
      try {
        if (!this.db) {
          throw new Error('Database not initialized');
        }
        
        const stmt = this.db.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, state_province,
            postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);
        
        stmt.free();
        this.saveDatabase();
        
        // Redirect to thank you page
        res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName!)}`);
      } catch (error) {
        console.error('Database error:', error);
        return res.status(500).render('form', {
          values: formData,
          errors: ['An error occurred while saving your submission. Please try again.']
        });
      }
    });

    // GET /thank-you - Render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', { firstName });
    });
  }

  public async start(): Promise<number> {
    await this.initializeDatabase();
    
    const port = this.port || 0;
    this.server = this.app.listen(port, () => {
      const address = this.server?.address();
      const actualPort = typeof address === 'string' ? address : address?.port || port;
      console.log(`Server running on port ${actualPort}`);
    });

    // Graceful shutdown
    process.on('SIGTERM', () => this.shutdown());
    process.on('SIGINT', () => this.shutdown());
    
    // Return the actual port being used
    return new Promise((resolve) => {
      this.server!.once('listening', () => {
        const address = this.server!.address();
        const actualPort = typeof address === 'string' ? parseInt(address, 10) : address?.port || port;
        resolve(actualPort as number);
      });
    });
  }

  public shutdown(skipExit = false): Promise<void> {
    return new Promise((resolve) => {
      console.log('Shutting down server...');
      
      if (this.server) {
        this.server.close(() => {
          console.log('Server closed');
          if (this.db) {
            this.db.close();
            console.log('Database closed');
          }
          if (!skipExit) {
            process.exit(0);
          }
          resolve();
        });
      } else {
        if (this.db) {
          this.db.close();
          console.log('Database closed');
        }
        if (!skipExit) {
          process.exit(0);
        }
        resolve();
      }
    });
  }

  public getApp(): express.Application {
    return this.app;
  }

  public getServer(): http.Server | null {
    return this.server;
  }
}

// Don't auto-start if this is imported
if (import.meta.url === `file://${process.argv[1]}`) {
  const app = new FormCaptureApp();
  app.start().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export default FormCaptureApp;