export interface CliArgs {
  dataPath: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArguments(args: string[]): CliArgs {
  // Skip node and script paths, start from actual CLI args
  const cliArgs = args.slice(2);

  if (cliArgs.length === 0) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const result: CliArgs = {
    dataPath: '',
    format: '',
    outputPath: undefined,
    includeTotals: false,
  };

  let i = 0;
  while (i < cliArgs.length) {
    const arg = cliArgs[i];
    
    if (arg === '--format') {
      if (i + 1 >= cliArgs.length) {
        throw new Error('--format requires a value');
      }
      result.format = cliArgs[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= cliArgs.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = cliArgs[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
      i += 1;
    } else if (!result.dataPath) {
      result.dataPath = arg;
      i += 1;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!result.dataPath) {
    throw new Error('Data file path is required');
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}