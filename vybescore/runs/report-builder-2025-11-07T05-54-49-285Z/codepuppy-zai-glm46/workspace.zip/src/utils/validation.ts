import { ReportData, ReportEntry } from '../types.js';

export function validateReportEntry(obj: unknown): obj is ReportEntry {
  if (
    typeof obj === 'object' &&
    obj !== null &&
    'label' in obj &&
    'amount' in obj
  ) {
    const record = obj as Record<string, unknown>;
    return (
      typeof record.label === 'string' &&
      typeof record.amount === 'number' &&
      !isNaN(record.amount)
    );
  }
  return false;
}

export function validateReportData(obj: unknown): obj is ReportData {
  if (
    typeof obj === 'object' &&
    obj !== null &&
    'title' in obj &&
    'summary' in obj &&
    'entries' in obj
  ) {
    const record = obj as Record<string, unknown>;
    return (
      typeof record.title === 'string' &&
      typeof record.summary === 'string' &&
      Array.isArray(record.entries) &&
      record.entries.every(validateReportEntry)
    );
  }
  return false;
}

export class ValidationError extends Error {
  constructor(message: string) {
    super(message);
    this.name = 'ValidationError';
  }
}

export function parseAndValidate(jsonContent: string): ReportData {
  let parsed: unknown;
  try {
    parsed = JSON.parse(jsonContent);
  } catch (error) {
    throw new ValidationError('Invalid JSON: ' + (error instanceof Error ? error.message : 'Unknown error'));
  }

  if (!validateReportData(parsed)) {
    throw new ValidationError('Invalid report data: must contain title (string), summary (string), and entries (array of objects with label and amount)');
  }

  return parsed as ReportData;
}