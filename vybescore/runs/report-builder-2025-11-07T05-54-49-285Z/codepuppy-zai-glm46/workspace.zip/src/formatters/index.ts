import { Formatter } from '../types.js';
import { MarkdownFormatter } from '../formats/markdown.js';
import { TextFormatter } from '../formats/text.js';

export const formatters: Record<string, () => Formatter> = {
  markdown: () => new MarkdownFormatter(),
  text: () => new TextFormatter(),
};

export const supportedFormats = Object.keys(formatters);