Format implementations for the Report Builder CLI.

This directory contains modular formatters that implement the `Formatter` interface:
- `markdown.ts` - Renders reports in Markdown format
- `text.ts` - Renders reports in plain text format

Each formatter exports:
- A class implementing the `Formatter` interface
- A convenience function (e.g., `renderMarkdown`) for direct usage

Formatters are registered in `../formatters/index.ts` and can be easily extended by adding new format implementations here.