#!/usr/bin/env node

import { readFile, writeFile } from 'fs/promises';
import { parseArguments, CliArgs } from '../utils/args.js';
import { parseAndValidate, ValidationError } from '../utils/validation.js';
import { formatters, supportedFormats } from '../formatters/index.js';
import { FormatOptions } from '../types.js';

async function main(): Promise<void> {
  try {
    // Parse command line arguments
    const args: CliArgs = parseArguments(process.argv);

    // Validate format
    if (!supportedFormats.includes(args.format)) {
      console.error(`Unsupported format: ${args.format}. Supported formats: ${supportedFormats.join(', ')}`);
      process.exit(1);
    }

    // Read and parse JSON file
    const jsonContent = await readFile(args.dataPath, 'utf-8');
    const reportData = parseAndValidate(jsonContent);

    // Prepare format options
    const options: FormatOptions = {
      includeTotals: args.includeTotals,
    };

    // Render report
    const formatter = formatters[args.format]();
    const output = formatter.render(reportData, options);

    // Write output
    if (args.outputPath) {
      await writeFile(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof ValidationError) {
      console.error(`Validation error: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Unknown error occurred');
    }
    process.exit(1);
  }
}

// Run the CLI
main();