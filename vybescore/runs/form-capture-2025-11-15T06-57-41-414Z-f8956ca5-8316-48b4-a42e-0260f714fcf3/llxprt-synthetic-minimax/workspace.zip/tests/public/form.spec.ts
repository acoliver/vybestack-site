import { describe, expect, it, beforeAll, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import type { Server } from 'http';
import { startServer } from '../../src/server';

let server: Server | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

beforeEach(async () => {
  // Start server for each test
  server = await startServer();
  
  // Wait a bit for server to be ready
  await new Promise(resolve => setTimeout(resolve, 500));
});

afterEach(async () => {
  // Close server after each test
  if (server && server.close) {
    await new Promise<void>((resolve) => {
      server!.close(() => {
        resolve();
      });
    });
  }
  
  // Clean up database after each test
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request('http://localhost:3535')
      .get('/')
      .expect(200);
    
    const html = response.text;
    
    // Check for all form fields
    expect(html).toContain('firstName');
    expect(html).toContain('lastName');
    expect(html).toContain('streetAddress');
    expect(html).toContain('city');
    expect(html).toContain('stateProvince');
    expect(html).toContain('postalCode');
    expect(html).toContain('country');
    expect(html).toContain('email');
    expect(html).toContain('phone');
    
    // Check for form structure
    expect(html).toContain('method="post"');
    expect(html).toContain('action="/submit"');
  });

  it('persists submission and redirects', async () => {
    // Clean up database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send(formData)
      .expect(302); // Should redirect
    
    expect(response.headers.location).toBe('/thank-you?firstName=John');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
  
  it('validates required fields', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({})
      .expect(400);
    
    const html = response.text;
    expect(html).toContain('is required');
  });
  
  it('validates email format', async () => {
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Springfield',
      stateProvince: 'IL',
      postalCode: '62701',
      country: 'United States',
      email: 'invalid-email',
      phone: '+1 555-123-4567'
    };
    
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send(formData)
      .expect(400);
    
    const html = response.text;
    expect(html).toContain('valid email address');
  });
});
