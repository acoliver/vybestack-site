/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  Subject,
  addObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  // Default strict equality if no equality function provided
  const equalFn: EqualFn<T> = equal === true || equal === undefined
    ? (a, b) => a === b
    : equal as EqualFn<T>
  
  // Create a subject to hold the reactive state  
  const subject: Subject<T> = {
    value,
    equalFn,
    observers: []
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Register this subject as a dependency for the current observer
      addObserver(subject, observer)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if the value has actually changed (using the equality function)
    if (!equalFn(subject.value, nextValue)) {
      subject.value = nextValue
      // Notify all observers that depend on this subject
      notifyObservers(subject)
    }
    
    return subject.value
  }

  return [read, write]
}
