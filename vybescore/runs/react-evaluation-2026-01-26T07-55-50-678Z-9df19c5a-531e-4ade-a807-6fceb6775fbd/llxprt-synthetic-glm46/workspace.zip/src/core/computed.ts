/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn,
  EqualFn,
  Observer,
  ObserverR,
  Subject,
  getActiveObserver,
  setActiveObserver,
  addObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  // Default strict equality if no equality function provided
  const equalFn: EqualFn<T> = equal === true || equal === undefined
    ? (a, b) => a === b
    : equal as EqualFn<T>
  
  // Internal state to track the computed value
  let currentValue: T | undefined = value
  
  // Create observer that will be triggered when dependencies change
  const observer: Observer<T> = {
    value: currentValue,
    updateFn: (prevValue) => {
      // Compute the new value
      const newValue = updateFn(prevValue)
      
      // Only update if the value has actually changed
      if (currentValue === undefined || !equalFn(currentValue, newValue)) {
        currentValue = newValue
        // Update the computed subject's value as well to keep them in sync
        computedAsSubject.value = currentValue
        
        // Notify our own observers that the computed value has changed
        notifyObservers(computedAsSubject)
      }
      
      return currentValue!
    }
  }
  
  // Make this computed value also reactive so inputs can notify it
  const computedAsSubject: Subject<T> & { get: () => T } = {
    value: currentValue!,
    observers: [] as ObserverR[],
    get: (): T => {
      // Set this observer as the active one to track dependencies
      const previous = getActiveObserver()
      setActiveObserver(observer)
      
      try {
        // Execute the update function to compute and track dependencies
        const newValue = updateFn(currentValue)
        
        // Only update if the value has actually changed
        if (currentValue === undefined || !equalFn(currentValue, newValue)) {
          const oldValue = currentValue
          currentValue = newValue
          observer.value = currentValue
          computedAsSubject.value = currentValue
          
          // If this is a recomputation (not first computation), notify our observers
          if (oldValue !== undefined) {
            notifyObservers(computedAsSubject)
          }
        }
        
        return currentValue!
      } finally {
        // Restore the previous active observer
        setActiveObserver(previous)
      }
    }
  }
  
  // Intercept accesses to track dependencies
  const wrappedComputed = (): T => {
    // First check if we need to track dependencies
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Add the active observer to this computed's observer list
      addObserver(computedAsSubject, activeObserver)
    }
    
    return computedAsSubject.get()
  }
  
  // Export the observers for cleanup
  ;(wrappedComputed as unknown as { __subject: typeof computedAsSubject }).__subject = computedAsSubject
  
  return wrappedComputed
}
