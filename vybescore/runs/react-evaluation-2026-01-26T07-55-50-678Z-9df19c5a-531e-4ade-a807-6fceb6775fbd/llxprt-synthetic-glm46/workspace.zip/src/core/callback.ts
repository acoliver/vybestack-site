/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  ObserverR, 
  UpdateFn, 
  setActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  let lastValue: T | undefined = value
  
  // Track the computed subjects for notification
  const computedSubjects = new Set<{ observers?: ObserverR[] }>()
  
  // Create our observer
  const observer: Observer<T> = {
    value: lastValue,
    updateFn: (prevValue) => {
      if (disposed) return lastValue as T
      const result = updateFn(prevValue)
      lastValue = result
      observer.value = result
      return result
    }
  }
  
  // Execute callback function to establish dependencies
  const executeCallback = () => {
    if (disposed) return
    
    try {
      setActiveObserver(observer)
      
      // Intercept global addObserver to track dependencies and directly add ourselves
      const originalAddObserver = (globalThis as unknown as { __addObserver?: unknown }).__addObserver
      ;(globalThis as unknown as { __addObserver?: unknown }).__addObserver = function(subject: { observers?: ObserverR[] }, obs: ObserverR) {
        if (obs === observer) {
          // Track this subject and add ourselves directly
          computedSubjects.add(subject)
          
          // Add to observers list
          if (!subject.observers) {
            subject.observers = []
          }
          if (!subject.observers.includes(observer)) {
            subject.observers.push(observer)
          }
        } else if (originalAddObserver) {
          return (originalAddObserver as (subject: { observers?: ObserverR[] }, obs: ObserverR) => unknown)(subject, obs)
        }
      }
      
      // Execute the callback function
      lastValue = updateFn(lastValue)
      observer.value = lastValue
      
      // Restore original
      ;(globalThis as unknown as { __addObserver?: unknown }).__addObserver = originalAddObserver
    } finally {
      setActiveObserver(undefined)
    }
  }
  
  // Execute initially
  executeCallback()
  
  // Ensure we're registered with all computed subjects
  computedSubjects.forEach(subject => {
    if (!subject.observers) {
      subject.observers = []
    }
    if (!subject.observers.includes(observer)) {
      subject.observers.push(observer)
    }
  })
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove ourselves from all subjects
    computedSubjects.forEach(subject => {
      if (subject.observers) {
        const index = subject.observers.indexOf(observer)
        if (index > -1) {
          subject.observers.splice(index, 1)
        }
      }
    })
    computedSubjects.clear()
    
    // Clear the observer
    observer.updateFn = () => lastValue as T
  }
  
  return unsubscribe
}
