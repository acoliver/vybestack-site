/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: ObserverR[] | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let updateDepth = 0

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (updateDepth > 10) {
    throw new Error('Maximum reactive update depth exceeded - possible circular dependency')
  }
  
  const previous = activeObserver
  activeObserver = observer
  updateDepth++
  
  try {
    const newValue = observer.updateFn(observer.value)
    observer.value = newValue
  } finally {
    activeObserver = previous
    updateDepth--
  }
}

export function addObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  // Add observer to the list of observers
  if (!subject.observers) {
    subject.observers = []
  }
  subject.observers.push(observer)
  
  // Call the global tracking function if it exists
  const globalAddObserver = (globalThis as unknown as { __addObserver?: unknown }).__addObserver
  if (globalAddObserver && globalAddObserver !== addObserver) {
    (globalAddObserver as (subject: Subject<T>, observer: ObserverR) => void)(subject, observer)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observers) {
    subject.observers.forEach(observer => {
      updateObserver(observer as Observer<T>)
    })
  }
}
