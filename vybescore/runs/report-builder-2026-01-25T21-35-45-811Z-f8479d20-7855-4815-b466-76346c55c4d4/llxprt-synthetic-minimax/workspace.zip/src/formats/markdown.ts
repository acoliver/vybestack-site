import { ReportData, CLIOptions, Formatter } from '../types/report.js';

export const renderMarkdown: Formatter = {
  format: (data: ReportData, options: CLIOptions): string => {
    let output = '';

    // Title
    output += `# ${data.title}\n\n`;

    // Summary
    output += `${data.summary}\n\n`;

    // Entries section
    output += `## Entries\n\n`;

    // Entries list
    for (const entry of data.entries) {
      const amountFormatted = formatAmount(entry.amount);
      output += `- **${entry.label}** — $${amountFormatted}\n`;
    }

    // Total if requested
    if (options.includeTotals) {
      const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
      const totalFormatted = formatAmount(total);
      output += `\n**Total:** $${totalFormatted}`;
    }

    return output;
  }
};

function formatAmount(amount: number): string {
  return amount.toFixed(2);
}