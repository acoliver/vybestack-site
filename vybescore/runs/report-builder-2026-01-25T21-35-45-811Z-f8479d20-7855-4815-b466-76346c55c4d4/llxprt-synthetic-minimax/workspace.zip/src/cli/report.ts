#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions, Formatter } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Formatter registry
const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText
};

function parseArgs(args: string[]): { dataPath: string; options: CLIOptions } {
  // Expected format: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]
  if (args.length < 4) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const dataPath = args[2];
  let format = '';
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse arguments starting from index 3 (skip command, script path, and data file)
  for (let i = 3; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return {
    dataPath,
    options: {
      format: format as 'markdown' | 'text',
      output: outputPath,
      includeTotals
    }
  };
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: root must be an object');
  }

  const reportData = data as Record<string, unknown>;

  // Validate required fields
  if (typeof reportData.title !== 'string') {
    throw new Error('Invalid JSON: "title" must be a string');
  }

  if (typeof reportData.summary !== 'string') {
    throw new Error('Invalid JSON: "summary" must be a string');
  }

  if (typeof reportData.entries !== 'object' || !Array.isArray(reportData.entries)) {
    throw new Error('Invalid JSON: "entries" must be an array');
  }

  const entries = reportData.entries as unknown[];
  const validatedEntries = entries.map((entry, index) => {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}].label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entries[${index}].amount must be a number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: reportData.title,
    summary: reportData.summary,
    entries: validatedEntries
  };
}

function main(): void {
  try {
    // Parse command line arguments
    const { dataPath, options } = parseArgs(process.argv);

    // Check if format is supported
    if (!formatters[options.format]) {
      console.error(`Unsupported format: ${options.format}`);
      process.exit(1);
    }

    // Read and parse JSON data
    let rawData: unknown;
    try {
      const fileContent = readFileSync(dataPath, 'utf8');
      rawData = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof Error && error.message.includes('ENOENT')) {
        throw new Error(`File not found: ${dataPath}`);
      }
      throw new Error(`Invalid JSON: ${error instanceof Error ? error.message : 'Parse error'}`);
    }

    // Validate and load report data
    const reportData = validateReportData(rawData);

    // Render the report
    const formatter = formatters[options.format];
    const output = formatter.format(reportData, options);

    // Output the result
    if (options.output) {
      writeFileSync(options.output, output);
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
