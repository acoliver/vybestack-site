import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';
import cheerio from 'cheerio';
import express from 'express';

// Set test environment
process.env.NODE_ENV = 'test';

let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import server after setting NODE_ENV
  const serverModule = await import('../../src/server.js');
  app = serverModule.app;
  
  // Wait a moment for initialization
  await new Promise(resolve => setTimeout(resolve, 100));
});

afterAll(async () => {
  // Clean up database after tests
  if (fs.existsSync(dbPath)) {
    try {
      fs.unlinkSync(dbPath);
    } catch (error) {
      // Ignore cleanup errors
    }
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app)
      .get('/')
      .expect(200);
    
    expect(response.text).toBeDefined();
    const html = typeof response.text === 'string' ? response.text : '';
    const $ = cheerio.load(html);
    
    // Check that all form fields are present
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);
    
    // Check form attributes
    expect($('form[method="post"][action="/submit"]')).toHaveLength(1);
    
    // Check labels are properly associated
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="lastName"]')).toHaveLength(1);
    
    // Check CSS is linked
    expect($('link[href="/public/styles.css"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const submissionData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: '90210',
      country: 'United States',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };

    // Submit the form
    const response = await request(app)
      .post('/submit')
      .send(submissionData)
      .expect(302);
    
    // Check redirect to thank-you page
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=John/);
    
    // Verify thank-you page renders
    const thankYouResponse = await request(app)
      .get('/thank-you?firstName=John')
      .expect(200);
    
    expect(thankYouResponse.text).toBeDefined();
    const html = typeof thankYouResponse.text === 'string' ? thankYouResponse.text : '';
    const $ = cheerio.load(html);
    expect($('h1').text()).toContain('Thank you, John!');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles validation errors', async () => {
    const invalidData = {
      firstName: '',
      lastName: '',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: '90210',
      country: 'United States',
      email: 'invalid-email',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidData)
      .expect(400);
    
    expect(response.text).toBeDefined();
    const html = typeof response.text === 'string' ? response.text : '';
    const $ = cheerio.load(html);
    
    // Check that error messages are displayed
    expect($('.error-list')).toHaveLength(1);
    expect($('.error-list li').length).toBeGreaterThan(0);
    
    // Check that form values are preserved
    expect($('input[name="streetAddress"]').val()).toBe('123 Main St');
    expect($('input[name="city"]').val()).toBe('Anytown');
  });

  it('accepts international postal codes and phone numbers', async () => {
    const internationalData = {
      firstName: 'Maria',
      lastName: 'González',
      streetAddress: 'Calle Falsa 123',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000', // Argentine postal code
      country: 'Argentina',
      email: 'maria@example.com',
      phone: '+54 9 11 1234-5678' // Argentine phone format
    };

    const response = await request(app)
      .post('/submit')
      .send(internationalData)
      .expect(302);
    
    // Check redirect to thank-you page
    expect(response.headers.location).toMatch(/\/thank-you\?firstName=Maria/);
  });

  it('rejects invalid emails', async () => {
    const invalidEmailData = {
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'not-a-valid-email',
      phone: '+1 555-123-4567'
    };

    const response = await request(app)
      .post('/submit')
      .send(invalidEmailData)
      .expect(400);
    
    expect(response.text).toBeDefined();
    const html = typeof response.text === 'string' ? response.text : '';
    const $ = cheerio.load(html);
    
    // Check that email error is displayed
    const errorText = $('.error-list').text();
    expect(errorText).toContain('valid email');
  });
});