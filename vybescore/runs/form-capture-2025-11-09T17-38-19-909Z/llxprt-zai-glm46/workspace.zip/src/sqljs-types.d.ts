declare module 'sql.js' {
  interface Database {
    exec(sql: string): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  interface Statement {
    run(...params: unknown[]): void;
    free(): void;
  }

  interface SqlJsStatic {
    Database: {
      new(data?: Uint8Array): Database;
    };
  }

  function initSqlJs(): Promise<SqlJsStatic>;
  
  export default initSqlJs;
  export { Database };
}