/// <reference path="./sqljs-types.d.ts" />
import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// Types for form submission
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Setup ES module directory constants
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Create Express app
const app = express();

// Database variables
let db: import('sql.js').Database | null = null;
const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');

// Initialize database immediately
let dbInitialized = false;
const initializeDatabaseSync = async (): Promise<void> => {
  if (dbInitialized) return;
  
  try {
    // Import sql.js dynamically
    const sqlModule = await import('sql.js');
    const initSqlJs = sqlModule.default || sqlModule;
    
    // Initialize SQL.js
    const SQL = await initSqlJs();

    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load or create database
    let dbData: Uint8Array | null = null;
    if (fs.existsSync(dbPath)) {
      dbData = fs.readFileSync(dbPath);
    }

    db = new SQL.Database(dbData || undefined);

    // Read and execute schema
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    db.exec(schema);

    dbInitialized = true;
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
};

// Initialize database at module load
initializeDatabaseSync().catch(error => {
  console.error('Failed to initialize database on startup:', error);
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Validation functions
const validateEmail = (email: string): boolean => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
};

const validatePhone = (phone: string): boolean => {
  // Allow digits, spaces, parentheses, dashes, and leading +
  const phoneRegex = /^[+]?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
};

const validatePostalCode = (postalCode: string): boolean => {
  // Allow alphanumeric strings with spaces
  const postalRegex = /^[a-zA-Z0-9\s]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
};

const validateRequired = (value: string): boolean => {
  return value.trim().length > 0;
};

const validateForm = (formData: FormData): ValidationError[] => {
  const errors: ValidationError[] = [];

  if (!validateRequired(formData.firstName)) {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }

  if (!validateRequired(formData.lastName)) {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }

  if (!validateRequired(formData.streetAddress)) {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }

  if (!validateRequired(formData.city)) {
    errors.push({ field: 'city', message: 'City is required' });
  }

  if (!validateRequired(formData.stateProvince)) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
  }

  if (!validateRequired(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
  } else if (!validatePostalCode(formData.postalCode)) {
    errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, and spaces' });
  }

  if (!validateRequired(formData.country)) {
    errors.push({ field: 'country', message: 'Country is required' });
  }

  if (!validateRequired(formData.email)) {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!validateEmail(formData.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }

  if (!validateRequired(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!validatePhone(formData.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }

  return errors;
};

// Save database to disk
const saveDatabase = (): void => {
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to', dbPath);
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
};

// Middleware to ensure database is initialized
const ensureDbInitialized = async (req: Request, res: Response, next: () => void) => {
  if (!dbInitialized) {
    try {
      await initializeDatabaseSync();
    } catch (error) {
      console.error('Database initialization error:', error);
      return res.status(500).send('Database initialization failed');
    }
  }
  next();
};

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', ensureDbInitialized, (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Validation failed, re-render form with errors
    res.status(400).render('form', {
      errors: errors.map(e => e.message),
      values: formData
    });
    return;
  }

  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    
    // Save database to disk
    saveDatabase();

    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', {
    firstName: firstName
  });
});

// Graceful shutdown
const gracefulShutdown = () => {
  console.log('Shutting down gracefully...');
  
  if (db) {
    try {
      db.close();
      console.log('Database closed');
    } catch (error) {
      console.error('Error closing database:', error);
    }
  }
  
  if (process.env.NODE_ENV !== 'test') {
    process.exit(0);
  }
};

// Handle termination signals
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
const startServer = async () => {
  try {
    // Ensure database is initialized
    await initializeDatabaseSync();
    
    const port = process.env.PORT || 3000;
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Export server for testing
    if (process.env.NODE_ENV !== 'production') {
      (global as typeof globalThis & { __server?: import('http').Server }).__server = server;
    }

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    if (process.env.NODE_ENV !== 'test') {
      process.exit(1);
    }
  }
};

// Only start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, startServer, gracefulShutdown };