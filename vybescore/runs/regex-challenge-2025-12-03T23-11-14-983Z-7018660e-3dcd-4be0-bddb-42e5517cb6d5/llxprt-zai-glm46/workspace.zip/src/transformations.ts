/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle empty string
  if (!text.trim()) {
    return text;
  }
  
  // Add a space after sentence-ending punctuation if there isn't one
  let normalizedText = text.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Split text into sentences using sentence-ending punctuation (.?!)
  // Keep the delimiters in the result
  const sentences = normalizedText.split(/([.?!])/);
  
  let result = '';
  let sentenceStart = true;
  
  for (let i = 0; i < sentences.length; i++) {
    const part = sentences[i];
    
    if (part === '.' || part === '?' || part === '!') {
      // This is punctuation - add it and set next sentence start
      result += part;
      sentenceStart = true;
    } else {
      // This is text content
      const trimmedPart = part.trim();
      if (trimmedPart) {
        // Capitalize first letter if this is the start of a sentence
        if (sentenceStart) {
          if (result.length > 0) {
            result += ' ';
          }
          result += trimmedPart.charAt(0).toUpperCase() + trimmedPart.slice(1);
        } else {
          result += part;
        }
      } else if (!sentenceStart) {
        // Preserve spacing within sentences
        result += part;
      }
      sentenceStart = false;
    }
  }
  
  // Clean up extra spaces and normalize spacing around punctuation
  return result
    .replace(/\s+([.?!])/g, '$1')  // Remove space before punctuation
    .replace(/([.?!])\s+/g, '$1 ') // Ensure single space after punctuation
    .replace(/\s+/g, ' ')          // Collapse multiple spaces
    .trim();
}

/**
 * TODO: Extract all URLs from the given text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex to match http(s) and www URLs
  const urlRegex = /https?:\/\/[^\s/$.?#].[^\s]*|www\.[^\s/$.?#].[^\s]*/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation
  return matches.map(url => url.replace(/[.,;:!?)]+$/g, ''));
}

/**
 * TODO: Replace http:// schemes with https://, leaving existing secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but don't double-upgrade https://
  return text.replace(/https?:\/\//g, 'https://');
}

/**
 * TODO: Rewrite documentation URLs according to the rules in problem.md.
 */
export function rewriteDocsUrls(text: string): string {
  // First, upgrade all http:// to https://
  let result = text.replace(/http:\/\//g, 'https://');
  
// Then process URLs that need host rewriting for docs
  result = result.replace(
    /https:\/\/([^/]+)(\/docs\/(?:[^?]*|[^.]*\.(?!jsp|php|asp|aspx|do|cgi|pl|py)[^?]*)(?:\?[^?#]*)?)/g,
    'https://docs.$1$2'
  );
  
  return result;
}

/**
 * TODO: Extract the year from mm/dd/yyyy format, return N/A if invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Days in each month (ignoring leap years for simplicity)
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  
  if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return yearStr;
}