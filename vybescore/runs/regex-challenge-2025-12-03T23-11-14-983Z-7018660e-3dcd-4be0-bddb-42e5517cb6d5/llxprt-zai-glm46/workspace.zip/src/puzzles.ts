/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a Set of exceptions for O(1) lookup
  const exceptionSet = new Set(exceptions.map(word => word.toLowerCase()));
  
  // Word boundary pattern to find words starting with the prefix
  // \b ensures we match whole words only
  // Case-insensitive matching with the i flag
  const wordPattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(wordPattern);
  
  if (!matches) {
    return [];
  }
  
  // Filter out exceptions and return unique words
  const filteredWords = matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptionSet.has(word));
  
  // Return unique words (remove duplicates)
  return [...new Set(filteredWords)];
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Use lookbehind to match token only when preceded by a digit
  // But exclude cases where token is at the beginning
  // We need to find digit followed by token, but return the digit+token combination
  const tokenPattern = new RegExp(`\\d+${token}`, 'g');
  
  const matches = text.match(tokenPattern);
  
  return matches || [];
}

/**
 * TODO: Validate strong password according to the criteria in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like "abab", "1212", etc.)
  // This pattern looks for any 2-4 character sequence that repeats immediately
  const repeatedPattern = /(..|...|....)\1/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses while avoiding false positives from IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's a pure IPv4 address and exclude it
  const ipv4Pattern = /^(?:\d{1,3}\.){3}\d{1,3}$/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern that matches:
  // - Full IPv6: 8 groups of 1-4 hex digits separated by colons
  // - Compressed IPv6: with :: shorthand (2 or more colons)
  // - Mixed notation: IPv6 with embedded IPv4 at the end
  // - Must contain at least one colon to distinguish from regular text
  const ipv6Pattern = /(?:[0-9a-fA-F]{1,4}:){7,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)|fe80:(?::[0-9a-fA-F]{0,4}){0,4}%[0-9a-zA-Z]{1,}|::(ffff(:0{1,4}){0,1}:){0,1}((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])|([0-9a-fA-F]{1,4}:){1,4}:((25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])\.){3,3}(25[0-5]|(2[0-4]|1{0,1}[0-9])?[0-9])/;
  
  return ipv6Pattern.test(value);
}