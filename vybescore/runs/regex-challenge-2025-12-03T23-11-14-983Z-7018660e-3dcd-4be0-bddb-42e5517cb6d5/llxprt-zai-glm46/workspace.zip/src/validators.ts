export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function for Luhn checksum validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email validation regex
  // - Local part: letters, digits, +, ., -, _, but no consecutive dots or leading/trailing dots
  // - @ symbol
  // - Domain: letters, digits, hyphens, but no underscores, no leading/trailing hyphens
  // - TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9]+[a-zA-Z0-9._%+-]*[a-zA-Z0-9]+@[a-zA-Z0-9][a-zA-Z0-9-]*[a-zA-Z0-9]?\.[a-zA-Z]{2,}$/;
  
  // Check for consecutive dots in the entire email
  if (value.includes('..')) {
    return false;
  }
  
  // Check for leading/trailing dots in local part
  const localPart = value.split('@')[0];
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Check for underscores in domain
  const domain = value.substring(value.indexOf('@') + 1);
  if (domain.includes('_')) {
    return false;
  }
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation.
 * Requirements are described in problem.md.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for optional +1 prefix
  const withCountryCode = cleaned.startsWith('+1') ? cleaned.substring(2) : cleaned;
  
  // Must be exactly 10 digits after removing country code
  if (withCountryCode.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = withCountryCode.substring(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement Argentine phone number validation.
 * Requirements are described in problem.md.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex with all components
  // Optional +54 country code
  // Optional 0 trunk prefix before area code
  // Optional 9 mobile indicator between country/trunk and area code
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, , areaCode] = match;
  
  // If country code is omitted, must have trunk prefix (0 before area code)
  if (!countryCode && !areaCode.startsWith('0')) {
    return false;
  }
  
  // Area code validation (excluding trunk prefix if present)
  const actualAreaCode = areaCode.startsWith('0') ? areaCode.substring(1) : areaCode;
  if (actualAreaCode.length < 2 || actualAreaCode.length > 4) {
    return false;
  }
  
  // Area code must start with 1-9
  if (!/^[1-9]/.test(actualAreaCode)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement name validation.
 * Requirements are described in problem.md.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and X Æ A-12 style names
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Must not contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Must not be empty or just whitespace
  if (!value.trim()) {
    return false;
  }
  
  return nameRegex.test(value);
}

/**
 * TODO: Implement credit card validation.
 * Requirements are described in problem.md.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be digits only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check Visa (starts with 4, 13 or 16 digits)
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Check Mastercard (starts with 51-55 or 2221-2720, 16 digits)
  const mastercardRegex = /^((5[1-5]\d{14})|(2(2[2-9][1-9]|[3-6]\d{2}|7([01]\d|20))\d{12}))$/;
  
  // Check AmEx (starts with 34 or 37, 15 digits)
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any card type
  const isValidCardType = visaRegex.test(cleaned) || 
                         mastercardRegex.test(cleaned) || 
                         amexRegex.test(cleaned);
  
  if (!isValidCardType) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}