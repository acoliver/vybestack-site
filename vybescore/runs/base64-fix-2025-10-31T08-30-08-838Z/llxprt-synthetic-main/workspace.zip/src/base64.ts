/**
 * Encode plain text to Base64 using canonical RFC 4648 alphabet (A-Z, a-z, 0-9, +, /) with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode canonical Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate Base64 input format - only allow characters from the canonical Base64 alphabet
  // and optional padding at the end
  const validBase64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!validBase64Regex.test(input)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
