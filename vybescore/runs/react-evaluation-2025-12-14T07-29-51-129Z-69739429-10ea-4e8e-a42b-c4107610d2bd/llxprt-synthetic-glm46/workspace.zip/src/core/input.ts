/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: [],
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !s.observers.includes(observer as Observer<unknown>)) {
      s.observers.push(observer as Observer<unknown>)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    // Create a copy to avoid issues with observers being removed during iteration
    const observersToNotify = [...s.observers]
    observersToNotify.forEach(observer => {
      try {
        updateObserver(observer as Observer<unknown>)
      } catch {
        // Ignore errors from disposed observers
      }
    })
    return s.value
  }

  return [read, write]
}
