/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, getActiveObserver, setActiveObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Execute update function initially to track dependencies
  const previousActive = getActiveObserver()
  setActiveObserver(observer)
  
  try {
    const initialValue = updateFn(value)
    if (initialValue !== undefined) {
      observer.value = initialValue
    }
  } finally {
    setActiveObserver(previousActive)
  }
  
  let disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from all subjects by clearing dependencies
    observer.value = undefined
    observer.updateFn = () => value!
  }
  
  return unsubscribe
}
