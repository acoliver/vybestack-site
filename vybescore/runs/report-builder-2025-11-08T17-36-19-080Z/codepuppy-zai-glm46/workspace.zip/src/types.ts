export interface Entry {
  label: string;
  amount: number;
}

export interface ReportData {
  title: string;
  summary: string;
  entries: Entry[];
}

export interface FormatOptions {
  includeTotals: boolean;
}

export interface Formatter {
  render(data: ReportData, options: FormatOptions): string;
}
