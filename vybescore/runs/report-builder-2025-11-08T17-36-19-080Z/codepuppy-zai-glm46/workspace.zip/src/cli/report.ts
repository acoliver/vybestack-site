#!/usr/bin/env node

import { readFile, writeFile } from 'fs/promises';
import type { ReportData, FormatOptions } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

interface ParsedData {
  title: unknown;
  summary: unknown;
  entries: unknown;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const dataFile = args[0];
  
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  // Parse arguments
  for (let i = 1; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[i + 1] as 'markdown' | 'text';
        i++; // Skip next argument
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a path');
          process.exit(1);
        }
        outputPath = args[i + 1];
        i++; // Skip next argument
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (args[i].startsWith('--')) {
          console.error(`Error: Unknown option ${args[i]}`);
          process.exit(1);
        }
    }
  }
  
  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }
  
  return {
    dataFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: ParsedData): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  if (typeof data.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }
  
  if (typeof data.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }
  
  if (!Array.isArray(data.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }
  
  for (let i = 0; i < data.entries.length; i++) {
    const entry = data.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid report data: entry at index ${i} must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry at index ${i} must have a string label`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry at index ${i} must have a number amount`);
    }
  }
  
  return data as ReportData;
}

async function main(): Promise<void> {
  try {
    const args = parseArgs();
    
    // Read JSON data
    const jsonData = await readFile(args.dataFile, 'utf-8');
    let data: ParsedData;
    
    try {
      data = JSON.parse(jsonData);
    } catch (error) {
      throw new Error(`Failed to parse JSON: ${error instanceof Error ? error.message : 'Unknown error'}`);
    }
    
    const reportData = validateReportData(data);
    
    const options: FormatOptions = {
      includeTotals: args.includeTotals,
    };
    
    // Select formatter
    const formatter = args.format === 'markdown' ? markdownFormatter : textFormatter;
    
    // Render report
    const output = formatter.render(reportData, options);
    
    // Output result
    if (args.outputPath) {
      await writeFile(args.outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();