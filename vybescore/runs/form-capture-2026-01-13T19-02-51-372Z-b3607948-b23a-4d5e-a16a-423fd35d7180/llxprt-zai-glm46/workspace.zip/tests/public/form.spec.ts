import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

let server: { close: () => void } | null = null;
let app: ReturnType<typeof import('express').default> | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Import the app and ensure database is initialized
  const { app: expressApp, ensureDatabaseInitialized } = await import('../../src/server.js');
  
  // Ensure database is initialized before tests
  await ensureDatabaseInitialized();
  
  app = expressApp;

  server = {
    close: () => {
      // Database cleanup is handled by the module
    },
  };
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');

    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);

    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    expect($('label[for="firstName"]').text()).toBe('First name');
    expect($('label[for="email"]').text()).toBe('Email');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const submission = {
      firstName: 'Jane',
      lastName: 'Doe',
      streetAddress: '123 Main Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app).post('/submit').send(submission);

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');

    expect(fs.existsSync(dbPath)).toBe(true);

    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you');
    expect(thankYouResponse.text).toContain('identity');
  });

  it('validates required fields and shows errors', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      email: 'not-an-email',
      phone: 'invalid-phone!',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Last name is required');
    expect(response.text).toContain('Please enter a valid email address');
    expect(response.text).toContain('Phone number may only contain');
  });

  it('accepts international phone formats', async () => {
    const testPhones = [
      '+44 20 7946 0958',
      '+54 9 11 1234-5678',
      '+1 (555) 123-4567',
      '123 456 7890',
    ];

    for (const phone of testPhones) {
      const response = await request(app).post('/submit').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Test Country',
        email: 'test@example.com',
        phone,
      });

      expect([200, 302]).toContain(response.status);
    }
  });

  it('accepts various postal code formats', async () => {
    const testPostalCodes = ['SW1A 1AA', 'C1000', 'B1675', '12345', 'A1B 2C3'];

    for (const postalCode of testPostalCodes) {
      const response = await request(app).post('/submit').send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode,
        country: 'Test Country',
        email: 'test@example.com',
        phone: '+1 555 123 4567',
      });

      if (response.status !== 302) {
        console.log('Unexpected response for postal code:', postalCode, response.status);
      }
      expect([200, 302]).toContain(response.status);
    }
  });
});
