import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const PORT = process.env.PORT ?? '3535';
const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

const app = express();
let db: Database | null = null;
let server: ReturnType<typeof app.listen> | null = null;

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode.trim()) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push('First name is required');
  }

  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.push('City is required');
  }

  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal / Zip code must contain only letters, numbers, spaces, and hyphens');
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.push('Country is required');
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number may only contain digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }

  let dbInstance: Database;

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Initialize database when module is imported
let dbInitPromise: Promise<Database> | null = null;

function ensureDatabaseInitialized(): Promise<Database> {
  if (db) {
    return Promise.resolve(db);
  }
  if (!dbInitPromise) {
    dbInitPromise = initializeDatabase().then((database) => {
      db = database;
      return database;
    });
  }
  return dbInitPromise;
}

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

app.set('view engine', 'ejs');
// In production (dist), views are in src/templates relative to project root
const templatesPath = path.resolve(process.cwd(), 'src', 'templates');
app.set('views', templatesPath);

app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {},
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName ?? '',
    lastName: req.body.lastName ?? '',
    streetAddress: req.body.streetAddress ?? '',
    city: req.body.city ?? '',
    stateProvince: req.body.stateProvince ?? '',
    postalCode: req.body.postalCode ?? '',
    country: req.body.country ?? '',
    email: req.body.email ?? '',
    phone: req.body.phone ?? '',
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    res.status(400);
    return res.render('form', {
      errors: validation.errors,
      values: formData,
    });
  }

  try {
    const database = await ensureDatabaseInitialized();

    database.run(
      `INSERT INTO submissions 
        (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );

    saveDatabase(database);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500);
    return res.render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    firstName: 'Friend',
  });
});

function setupGracefulShutdown(): void {
  const shutdown = (signal: string): void => {
    console.log(`Received ${signal}, shutting down gracefully...`);

    if (server) {
      server.close(() => {
        console.log('HTTP server closed');
      });
    }

    if (db) {
      db.close();
      console.log('Database connection closed');
    }

    process.exit(0);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

async function startServer(): Promise<void> {
  try {
    await ensureDatabaseInitialized();
    console.log('Database initialized');

    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    setupGracefulShutdown();
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, startServer, ensureDatabaseInitialized };
export default app;
