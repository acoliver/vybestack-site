#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, ReportRenderer } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 4) {
    throw new Error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]',
    );
  }

  const dataFile = args[2];
  let format = '';
  let outputPath: string | undefined = undefined;
  let includeTotals = false;

  for (let i = 3; i < args.length; i++) {
    switch (args[i]) {
      case '--format':
        format = args[++i];
        break;
      case '--output':
        outputPath = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        throw new Error(`Unknown option: ${args[i]}`);
    }
  }

  if (!format) {
    throw new Error('--format is required');
  }

  return { dataFile, format, outputPath, includeTotals };
}

function loadData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent) as unknown;

    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON data');
    }

    const reportData = data as Record<string, unknown>;

    if (
      typeof reportData.title !== 'string' ||
      typeof reportData.summary !== 'string' ||
      !Array.isArray(reportData.entries)
    ) {
      throw new Error('Invalid JSON structure');
    }

    for (const entry of reportData.entries) {
      if (
        !entry ||
        typeof entry !== 'object' ||
        typeof (entry as Record<string, unknown>).label !== 'string' ||
        typeof (entry as Record<string, unknown>).amount !== 'number'
      ) {
        throw new Error('Invalid entry structure');
      }
    }

    return reportData as unknown as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Malformed JSON');
    }
    throw error;
  }
}

function getRenderer(format: string): ReportRenderer {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content, 'utf8');
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const { dataFile, format, outputPath, includeTotals } = parseArguments(
      process.argv,
    );
    const data = loadData(dataFile);
    const renderer = getRenderer(format);
    const options: ReportOptions = { includeTotals };
    const output = renderer(data, options);
    writeOutput(output, outputPath);
  } catch (error) {
    console.error(error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

main();
