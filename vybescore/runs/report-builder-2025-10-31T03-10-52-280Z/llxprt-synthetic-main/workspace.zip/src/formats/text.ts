import type { ReportData, ReportOptions } from '../types.js';

export function renderText(data: ReportData, options: ReportOptions): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let result = `${title}\n${summary}\nEntries:\n`;

  for (const entry of entries) {
    const amount = renderAmount(entry.amount);
    result += `- ${entry.label}: ${amount}\n`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `Total: ${renderAmount(total)}\n`;
  }

  return result;
}

function renderAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}