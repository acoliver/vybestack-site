import type { ReportData, ReportOptions } from '../types.js';

export function renderMarkdown(
  data: ReportData,
  options: ReportOptions,
): string {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let result = `# ${title}\n\n${summary}\n\n## Entries\n`;

  for (const entry of entries) {
    const amount = renderAmount(entry.amount);
    result += `- **${entry.label}** — ${amount}\n`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    result += `\n**Total:** ${renderAmount(total)}\n`;
  }

  return result;
}

function renderAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}