/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  UpdateFn,
  GetterFn
} from '../types/reactive.js'
import { registerComputedCallback, unregisterComputedCallback } from './computed.js'

// Global callback tracking for dependency management
const callbackToComputed = new Map<() => void, Set<GetterFn<unknown>>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, _value?: T): UnsubscribeFn {
  let disposed = false
  
  // Create a callback function that will be called when dependencies change
  const callback = () => {
    if (disposed) return
    updateFn(_value)
  }
  
  // Execute the callback immediately to establish initial state
  // This will establish dependencies by reading computed getters
  callback()
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove this callback from all computed dependencies
    const dependencies = callbackToComputed.get(callback)
    if (dependencies) {
      dependencies.forEach(computedGetter => {
        unregisterComputedCallback(computedGetter, callback)
      })
      dependencies.clear()
    }
  }
}
