/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Global dependency tracking: input -> dependent computed getters and callbacks
const inputDependencies = new Map<GetterFn<unknown>, Set<GetterFn<unknown>>>()

function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return Object.is(lhs, rhs)
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  _options?: Options
): InputPair<T> {
  let currentValue = value
  const equalFn = _equal && typeof _equal === 'function' ? _equal : defaultEqual<T>
  
  const read: GetterFn<T> = () => {
    return currentValue
  }

  const write: SetterFn<T> = (nextValue: T) => {
    if (!equalFn(currentValue, nextValue)) {
      currentValue = nextValue
      
      // Force recomputation of all dependent computed values
      const dependents = inputDependencies.get(read)
      if (dependents) {
        dependents.forEach(computedGetter => {
          // Force recomputation by calling the getter
          computedGetter()
        })
      }
    }
    return nextValue
  }

  return [read, write]
}

// Register that a computed getter depends on this input
export function registerInputDependency(inputGetter: GetterFn<unknown>, computedGetter: GetterFn<unknown>): void {
  if (!inputDependencies.has(inputGetter)) {
    inputDependencies.set(inputGetter, new Set())
  }
  inputDependencies.get(inputGetter)!.add(computedGetter)
}

// Unregister dependency
export function unregisterInputDependency(inputGetter: GetterFn<unknown>, computedGetter: GetterFn<unknown>): void {
  const dependents = inputDependencies.get(inputGetter)
  if (dependents) {
    dependents.delete(computedGetter)
  }
}
