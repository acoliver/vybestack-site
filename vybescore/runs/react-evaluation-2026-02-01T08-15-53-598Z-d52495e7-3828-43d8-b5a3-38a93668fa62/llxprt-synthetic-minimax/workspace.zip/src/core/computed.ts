/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  EqualFn,
  UpdateFn
} from '../types/reactive.js'

// Global tracking for computed callbacks
const computedCallbacks = new Map<GetterFn<unknown>, Set<() => void>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  _options?: { name?: string }
): GetterFn<T> {
  let computedValue = value
  
  const read: GetterFn<T> = () => {
    // Execute the update function to get the current value
    const oldValue = computedValue
    computedValue = updateFn(computedValue)
    
    // If the value changed, notify all dependent callbacks
    if (oldValue !== computedValue) {
      const callbacks = computedCallbacks.get(read)
      if (callbacks) {
        callbacks.forEach(callback => callback())
      }
    }
    
    return computedValue
  }

  return read
}

// Register a callback for a computed getter
export function registerComputedCallback(computedGetter: GetterFn<unknown>, callback: () => void): void {
  if (!computedCallbacks.has(computedGetter)) {
    computedCallbacks.set(computedGetter, new Set())
  }
  computedCallbacks.get(computedGetter)!.add(callback)
}

// Unregister a callback for a computed getter
export function unregisterComputedCallback(computedGetter: GetterFn<unknown>, callback: () => void): void {
  const callbacks = computedCallbacks.get(computedGetter)
  if (callbacks) {
    callbacks.delete(callback)
  }
}
