/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

// Observer pattern for reactive dependencies
export interface ReactiveSubject<T> {
  value: T
  observers: Set<ReactiveObserver>
  read(): T
  write(value: T): T
  notify(): void
  addObserver(observer: ReactiveObserver): void
  removeObserver(observer: ReactiveObserver): void
}

export interface ReactiveObserver {
  value?: unknown
  updateFn?: UpdateFn<unknown>
  subjects: Set<ReactiveSubject<unknown>>
  listeners: Set<() => void>
  read(): unknown
  update(): void
  notify(): void
  addSubject(subject: ReactiveSubject<unknown>): void
  removeSubject(subject: ReactiveSubject<unknown>): void
  addListener(listener: () => void): void
  removeListener(listener: () => void): void
}

// Type aliases for backward compatibility and convenience
export type Subject<T> = ReactiveSubject<T>
export type SubjectR = ReactiveSubject<unknown>
export type SubjectV = ReactiveSubject<unknown>

export type Observer = ReactiveObserver
export type ObserverR = ReactiveObserver
export type ObserverV = ReactiveObserver

// Global reactive computation tracking
export let currentObserver: ReactiveObserver | null = null
export let currentContext: 'computation' | 'callback' | null = null
const subjects = new Set<ReactiveSubject<unknown>>()
const observers = new Set<ReactiveObserver>()

export function getCurrentObserver(): ReactiveObserver | null {
  return currentObserver
}

export function setCurrentObserver(observer: ReactiveObserver | null): void {
  currentObserver = observer
}

export function getCurrentContext(): 'computation' | 'callback' | null {
  return currentContext
}

export function setCurrentContext(context: 'computation' | 'callback' | null): void {
  currentContext = context
}

export function trackSubject<T>(subject: ReactiveSubject<T>): void {
  subjects.add(subject)
}

export function trackObserver(observer: ReactiveObserver): void {
  observers.add(observer)
}

export function untrackSubject<T>(subject: ReactiveSubject<T>): void {
  subjects.delete(subject)
}

export function untrackObserver(observer: ReactiveObserver): void {
  observers.delete(observer)
}
