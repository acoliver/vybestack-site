declare module 'sql.js' {
  export class Database {
    constructor(data?: ArrayBuffer);
    run(sql: string, ...params: unknown[]): unknown[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  export class Statement {
    run(...params: unknown[]): unknown;
    free(): void;
  }
  
  export default function initSqlJs(): Promise<{
    Database: typeof Database;
  }>;
}