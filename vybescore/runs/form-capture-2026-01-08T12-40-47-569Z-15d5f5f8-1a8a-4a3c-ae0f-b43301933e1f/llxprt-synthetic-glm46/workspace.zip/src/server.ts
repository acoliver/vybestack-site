import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const rootDir = path.dirname(__dirname);

// Initialize the database
let db: import('sql.js').Database | null = null;

// Define submission interface
interface Submission {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

// Define validation error interface
interface ValidationError {
  field: string;
  message: string;
}

// Database initialization
async function initDatabase(): Promise<import('sql.js').Database> {
  try {
    const SQL = await initSqlJs();
    
    // Path to the database file
    const dbPath = path.join(rootDir, 'data', 'submissions.sqlite');
    
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }
    
    // Try to load existing database or create a new one
    let database: import('sql.js').Database;
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      database = new SQL.Database(dbBuffer.buffer);
      console.log('Loaded existing database from', dbPath);
    } else {
      database = new SQL.Database();
      console.log('Created new in-memory database');
    }
    
    // Apply schema to ensure table exists
    const schemaPath = path.join(rootDir, 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    database.run(schema);
    console.log('Applied database schema');
    
    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Save database to disk
function saveDatabase(): void {
  if (!db) return;
  
  try {
    const dbPath = path.join(rootDir, 'data', 'submissions.sqlite');
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to', dbPath);
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

// Validation functions
function validateSubmission(data: Submission): ValidationError[] {
  const errors: ValidationError[] = [];
  
  // Required fields validation
  if (!data.first_name || data.first_name.trim() === '') {
    errors.push({ field: 'firstName', message: 'First name is required' });
  }
  
  if (!data.last_name || data.last_name.trim() === '') {
    errors.push({ field: 'lastName', message: 'Last name is required' });
  }
  
  if (!data.street_address || data.street_address.trim() === '') {
    errors.push({ field: 'streetAddress', message: 'Street address is required' });
  }
  
  if (!data.city || data.city.trim() === '') {
    errors.push({ field: 'city', message: 'City is required' });
  }
  
  if (!data.state_province || data.state_province.trim() === '') {
    errors.push({ field: 'stateProvince', message: 'State/Province is required' });
  }
  
  if (!data.postal_code || data.postal_code.trim() === '') {
    errors.push({ field: 'postalCode', message: 'Postal code is required' });
  }
  
  if (!data.country || data.country.trim() === '') {
    errors.push({ field: 'country', message: 'Country is required' });
  }
  
  if (!data.email || data.email.trim() === '') {
    errors.push({ field: 'email', message: 'Email is required' });
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address' });
  }
  
  if (!data.phone || data.phone.trim() === '') {
    errors.push({ field: 'phone', message: 'Phone number is required' });
  } else if (!/^\+?[0-9\s\-()]+$/.test(data.phone)) {
    errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, parentheses, dashes, and a leading +' });
  }
  
  return errors;
}

// Express app setup
async function startServer(): Promise<void> {
  // Initialize database
  db = await initDatabase();
  
  const port = process.env.PORT || 3535;
  
  // Create Express app
  const app = express();
  
  // Middleware
  app.use(express.json());
  app.use(express.urlencoded({ extended: true }));
  
  // Set up EJS
  app.set('views', path.join(__dirname, 'templates'));
  app.set('view engine', 'ejs');
  
  // Serve static files
  app.use('/public', express.static(path.join(rootDir, 'public')));
  
  // GET / - Render the form
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: [],
      values: {}
    });
  });
  
  // GET /thank-you - Render thank you page
  app.get('/thank-you', (req: Request, res: Response) => {
    const firstName = req.query.firstName ? String(req.query.firstName) : 'Friend';
    res.render('thank-you', { firstName });
  });
  
  // POST /submit - Handle form submission
  app.post('/submit', (req: Request, res: Response) => {
    const submission: Submission = {
      first_name: req.body.firstName || '',
      last_name: req.body.lastName || '',
      street_address: req.body.streetAddress || '',
      city: req.body.city || '',
      state_province: req.body.stateProvince || '',
      postal_code: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };
    
    const errors = validateSubmission(submission);
    const errorMessages = errors.map(err => err.message);
    
    if (errors.length > 0) {
      // Render form with errors and entered values
      return res.status(400).render('form', {
        errors: errorMessages,
        values: req.body
      });
    }
    
    try {
      // Insert into database
      if (!db) {
        throw new Error('Database not initialized');
      }
      
      const stmt = db.prepare(`
        INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
      
      stmt.run([
        submission.first_name,
        submission.last_name,
        submission.street_address,
        submission.city,
        submission.state_province,
        submission.postal_code,
        submission.country,
        submission.email,
        submission.phone
      ]);
      
      stmt.free();
      
      // Save database to disk
      saveDatabase();
      
      // Redirect to thank you page with first name
      res.redirect(`/thank-you?firstName=${encodeURIComponent(submission.first_name)}`);
    } catch (error) {
      console.error('Error saving submission:', error);
      return res.status(500).render('form', {
        errors: ['An error occurred while saving your submission. Please try again.'],
        values: req.body
      });
    }
  });
  
  // Start the server
  const server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
  
  // Set up graceful shutdown
  const gracefulShutdown = () => {
    console.log('Received signal to shut down server');
    
    server.close(() => {
      console.log('HTTP server closed');
      
      if (db) {
        db.close();
        console.log('Database closed');
      }
      
      process.exit(0);
    });
  };
  
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);
}

// Export a simple test server
export function createTestServer() {
  // Import the main app logic and configure for testing
  
  // Helper to initialize the test server
  function initTestServer(): express.Application {
    const testApp = express();
    
    // Middleware
    testApp.use(express.json());
    testApp.use(express.urlencoded({ extended: true }));
    
    // Set up EJS and static files
    testApp.set('views', path.join(__dirname, 'templates'));
    testApp.set('view engine', 'ejs');
    testApp.use('/public', express.static(path.join(rootDir, 'public')));
    
    // GET / - Render the form
    testApp.get('/', (req: Request, res: Response) => {
      try {
        res.render('form', {
          errors: [],
          values: {}
        });
      } catch (error) {
        console.error('Error rendering form:', error);
        return res.status(500).json({ error: 'Failed to render form' });
      }
    });
    
    // GET /thank-you - Render thank you page
    testApp.get('/thank-you', (req: Request, res: Response) => {
      const firstName = req.query.firstName ? String(req.query.firstName) : 'Friend';
      res.render('thank-you', { firstName });
    });
    
    // POST /submit - Handle form submission with database
    testApp.post('/submit', async (req: Request, res: Response) => {
      try {
        // Initialize database for this request
        const SQL = await initSqlJs();
        const db = new SQL.Database();
        
        // Apply schema to create tables
        const schemaPath = path.join(rootDir, 'db', 'schema.sql');
        const schema = fs.readFileSync(schemaPath, 'utf8');
        db.run(schema);
        
        const submission: Submission = {
          first_name: req.body.firstName || '',
          last_name: req.body.lastName || '',
          street_address: req.body.streetAddress || '',
          city: req.body.city || '',
          state_province: req.body.stateProvince || '',
          postal_code: req.body.postalCode || '',
          country: req.body.country || '',
          email: req.body.email || '',
          phone: req.body.phone || ''
        };
        
        const errors = validateSubmission(submission);
        const errorMessages = errors.map(err => err.message);
        
        if (errors.length > 0) {
          // Render form with errors and entered values
          return res.status(400).render('form', {
            errors: errorMessages,
            values: req.body
          });
        }
        
        // Insert into database
        const stmt = db.prepare(`
          INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        stmt.run([
          submission.first_name,
          submission.last_name,
          submission.street_address,
          submission.city,
          submission.state_province,
          submission.postal_code,
          submission.country,
          submission.email,
          submission.phone
        ]);
        
        stmt.free();
        
        // Save to disk to match real behavior
        const dbPath = path.join(rootDir, 'data', 'submissions.sqlite');
        if (!fs.existsSync(path.dirname(dbPath))) {
          fs.mkdirSync(path.dirname(dbPath), { recursive: true });
        }
        const data = db.export();
        fs.writeFileSync(dbPath, Buffer.from(data));
        
        // Redirect to thank you page with first name
        res.redirect(`/thank-you?firstName=${encodeURIComponent(submission.first_name)}`);
      } catch (error) {
        console.error('Error in test submission:', error);
        return res.status(500).render('form', {
          errors: ['An error occurred while saving your submission. Please try again.'],
          values: req.body
        });
      }
    });
    
    return testApp;
  }
// Export the startServer function for testing
export { startServer };
return initTestServer();
}