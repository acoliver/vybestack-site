const express = require('express');
const path = require('path');

// Try to directly check if the EJS templates are accessible
const viewsPath = path.join(__dirname, 'src', 'templates');
console.log('Views path exists:', require('fs').existsSync(viewsPath));

const app = express();
app.set('views', viewsPath);
app.set('view engine', 'ejs');

app.use('/public', express.static(path.join(__dirname, 'public')));

app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { firstName: 'Test' });
});

app.listen(3535, () => {
  console.log('Server running on port 3535');
});