/**
 * Encode plain text to Base64 using standard Base64 encoding with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 */
export function decode(input: string): string {
  // Remove whitespace from input
  const cleaned = input.replace(/\s/g, '');

  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(cleaned)) {
    throw new Error('Invalid Base64 input');
  }

  // Add padding if needed (Base64 strings should be multiple of 4 characters)
  const padding = cleaned.length % 4;
  const normalized = padding === 0 ? cleaned : cleaned + '='.repeat(4 - padding);

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Invalid Base64 input');
  }
}
