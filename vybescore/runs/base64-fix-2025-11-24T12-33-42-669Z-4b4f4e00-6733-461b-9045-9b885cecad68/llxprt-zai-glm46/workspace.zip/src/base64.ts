const INVALID_BASE64_ERROR = 'Invalid Base64 input';
const BASE64_ALPHABET = 'A-Za-z0-9+/';
const BASE64_REGEX = new RegExp(`^[${BASE64_ALPHABET}]*={0,2}$`);
const INVALID_CHARS_REGEX = new RegExp(`[^${BASE64_ALPHABET}=]`);

/**
 * Encode plain text to standard Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  // Check for invalid characters first
  if (INVALID_CHARS_REGEX.test(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  // Check for malformed padding - must be at the end
  if (input.includes('=')) {
    const paddingIndex = input.indexOf('=');
    const afterPadding = input.slice(paddingIndex + 1);
    
    // All characters after the first '=' must also be '='
    if (afterPadding && !/^=*$/.test(afterPadding)) {
      throw new Error(INVALID_BASE64_ERROR);
    }
  }
  
  // Validate overall structure
  if (!BASE64_REGEX.test(input)) {
    throw new Error(INVALID_BASE64_ERROR);
  }
  
  try {
    const decoded = Buffer.from(input, 'base64').toString('utf8');
    
    // Check for invalid UTF-8 sequences (replacement character)
    if (decoded.includes('\ufffd')) {
      throw new Error(INVALID_BASE64_ERROR);
    }
    
    return decoded;
  } catch (error) {
    throw new Error(INVALID_BASE64_ERROR);
  }
}
