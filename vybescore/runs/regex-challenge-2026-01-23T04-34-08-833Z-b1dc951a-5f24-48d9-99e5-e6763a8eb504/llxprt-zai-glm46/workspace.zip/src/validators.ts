export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses using regex.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation regex
  // Local part: letters, digits, and special characters like . _ % + - but not consecutive dots or leading/trailing dots
  // Domain: letters, digits, hyphens, and dots (but not leading/trailing/consecutive dots or underscores)
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional check: no double dots in sequence
  if (/\.\./.test(value)) return false;
  
  // Check for leading/trailing dots in local part
  const [localPart, ...domainParts] = value.split('@');
  if (localPart.startsWith('.') || localPart.endsWith('.')) return false;
  
  // Check for trailing dot in entire email
  if (value.endsWith('.')) return false;
  
  // Check for double dots or leading/trailing dots in domain
  const domain = domainParts.join('@');
  if (domain && (domain.startsWith('.') || domain.endsWith('.') || /\.\./.test(domain))) return false;
  
  // Check for underscores in domain
  if (domain && domain.includes('_')) return false;
  
  // Must have exactly one @ symbol
  const atCount = (value.match(/@/g) || []).length;
  if (atCount !== 1) return false;
  
  return emailRegex.test(value);
}

/**
 * Validate US phone numbers.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, optionally +1 makes it 11)
  if (digitsOnly.length < 10) return false;
  
  // If more than 10 digits, must start with 1 (country code) and be exactly 11
  if (digitsOnly.length > 11) return false;
  if (digitsOnly.length === 11 && !digitsOnly.startsWith('1')) return false;
  
  // Extract the 10-digit number (with or without country code)
  const tenDigitNumber = digitsOnly.length === 11 ? digitsOnly.slice(1) : digitsOnly;
  
  // Area code (first 3 digits) cannot start with 0 or 1
  const areaCode = tenDigitNumber.slice(0, 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = tenDigitNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') return false;
  
  // Validate format with regex for common patterns
  // Patterns: (212) 555-7890, 212-555-7890, 212.555.7890, 2125557890, +1-212-555-7890
  const phoneRegex = /^\+?1?\s*\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep structure for parsing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if country code is present
  const hasCountryCode = cleaned.startsWith('+54');
  
  // Remove +54 if present for pattern matching
  const withoutCountry = hasCountryCode ? cleaned.slice(3) : cleaned;
  
  // Check for trunk prefix 0 (required if country code is omitted)
  const hasTrunkPrefix = withoutCountry.startsWith('0');
  
  // Remove trunk prefix if present
  const withoutTrunk = hasTrunkPrefix ? withoutCountry.slice(1) : withoutCountry;
  
  // Check for mobile indicator 9 (comes after country code/trunk prefix)
  let afterMobile = withoutTrunk;
  if (withoutTrunk.startsWith('9')) {
    afterMobile = withoutTrunk.slice(1);
  }
  
  // At this point, afterMobile should be: area code (2-4 digits) + subscriber (6-8 digits)
  // Total should be 8-12 digits
  if (afterMobile.length < 8 || afterMobile.length > 12) return false;
  
  // Area code must be 2-4 digits and start with 1-9
  let areaCode = '';
  let subscriber = '';
  
  // Try to extract area code (2-4 digits)
  for (let len = 4; len >= 2; len--) {
    if (afterMobile.length >= len + 6) { // At least 6 digits for subscriber
      const potentialAreaCode = afterMobile.slice(0, len);
      const potentialSubscriber = afterMobile.slice(len);
      
      // Check if area code starts with 1-9 and subscriber is 6-8 digits
      if (/^[1-9]\d{1,3}$/.test(potentialAreaCode) && 
          potentialSubscriber.length >= 6 && 
          potentialSubscriber.length <= 8) {
        areaCode = potentialAreaCode;
        subscriber = potentialSubscriber;
        break;
      }
    }
  }
  
  if (!areaCode || !subscriber) return false;
  
  // If country code is omitted, trunk prefix must be present
  if (!hasCountryCode && !hasTrunkPrefix) return false;
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Must have at least one letter, no digits, no special symbols except ' and -
  const nameRegex = /^[a-zA-Z\u00C0-\u017F\u0400-\u04FF]+(?:['\s-][a-zA-Z\u00C0-\u017F\u0400-\u04FF]+)*$/;
  
  // Must not contain digits
  if (/\d/.test(value)) return false;
  
  // Must not be empty
  if (value.trim().length === 0) return false;
  
  // Check for valid name pattern (allows hyphens and apostrophes but not consecutive or at edges)
  if (value.startsWith('-') || value.startsWith("'") || 
      value.endsWith('-') || value.endsWith("'")) return false;
  
  // Check for consecutive hyphens or apostrophes
  if (/--|''/.test(value)) return false;
  
  // Must contain at least one letter
  if (!/[a-zA-Z\u00C0-\u017F\u0400-\u04FF]/.test(value)) return false;
  
  return nameRegex.test(value);
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths. Runs Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Visa: starts with 4, length 13, 15, or 16
  const visaRegex = /^4\d{12}(\d{2})?(\d{1})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Discover: starts with 6011, 622126-622925, 644-649, or 65, length 16
  const discoverRegex = /^6(?:011\d{12}|5\d{14}|22[1-9]\d{12}|4[4-9]\d{13}|2[2-8]\d{13})$/;
  
  const validPrefix = visaRegex.test(cleaned) || 
                     mastercardRegex.test(cleaned) || 
                     amexRegex.test(cleaned) || 
                     discoverRegex.test(cleaned);
  
  if (!validPrefix) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
