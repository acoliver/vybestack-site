/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences, collapse extra spaces.
 * Preserve abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || text.trim().length === 0) return '';
  
  // First, normalize whitespace between words (but preserve sentence boundaries)
  let normalized = text.replace(/[ \t]+/g, ' ').trim();
  
  // Ensure exactly one space after sentence-ending punctuation
  // This handles cases like "word1.Word2" -> "word1. Word2"
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first character of text
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Find sentence boundaries: . ? ! followed by optional quote and then space and lowercase letter
  // Use regex to capitalize after sentence endings while preserving abbreviations
  // Common abbreviations to watch for: Mr., Mrs., Ms., Dr., Prof., etc., vs., i.e., e.g.
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'Gen', 'Rep', 'Sen', 'St', 'etc', 'vs', 'ie', 'eg'];
  
  // Capitalize after sentence endings, but not after abbreviations
  const sentences = normalized.split(/([.!?]+\s+)/);
  
  for (let i = 0; i < sentences.length; i++) {
    if (i % 2 === 0) {
      // This is a sentence (even index)
      // Check if previous sentence ended with an abbreviation
      const prevSentenceEnd = i > 0 ? sentences[i - 1] : '';
      const lastWord = prevSentenceEnd.trim().split(/\s+/).pop() || '';
      
      // Check if last word (without punctuation) is an abbreviation
      const lastWordBase = lastWord.replace(/[.!?]+$/, '').toLowerCase();
      const isAbbr = abbreviations.some(abbr => lastWordBase === abbr.toLowerCase());
      
      // If not after abbreviation, capitalize
      if (!isAbbr) {
        sentences[i] = sentences[i].charAt(0).toUpperCase() + sentences[i].slice(1);
      }
    }
  }
  
  return sentences.join('');
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * URLs are returned without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  // Matches http://, https://, and www. URLs
  // Does not include trailing punctuation like .,;:?!
  const urlRegex = /https?:\/\/[^\s<]+[^.,;:!?\s]|www\.[^\s<]+[^.,;:!?\s]/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Trim any trailing whitespace
  return matches.map(url => url.trim());
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... to https://...
 * Moves docs paths to https://docs.example.com/ where applicable.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern for example.com URLs
  const exampleUrlRegex = /(https?:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  return text.replace(exampleUrlRegex, (match, scheme, host, path) => {
    // Always upgrade to https
    const newScheme = 'https://';
    
    // Check if path starts with /docs/
    const startsWithDocs = /^\/docs\//i.test(path);
    
    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHints = /\/cgi-bin|[?&=]|(\.(jsp|php|asp|aspx|do|cgi|pl|py))($|\/|\?)/i.test(path);
    
    // If path starts with /docs/ and doesn't have dynamic hints, rewrite host
    if (startsWithDocs && !hasDynamicHints) {
      return `${newScheme}docs.${host}${path}`;
    }
    
    // Otherwise just upgrade the scheme
    return `${newScheme}${host}${path}`;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, monthStr, dayStr, yearStr] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Allow Feb 29 for leap years
  if (day < 1 || day > daysInMonth[month - 1]) return 'N/A';
  
  // Return year
  return yearStr;
}
