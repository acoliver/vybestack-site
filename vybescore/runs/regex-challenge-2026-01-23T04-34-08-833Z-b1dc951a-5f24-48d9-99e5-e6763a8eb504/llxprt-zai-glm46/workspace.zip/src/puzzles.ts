/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  // Word boundary at start, then prefix, then word characters
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exception => lowerWord === exception.toLowerCase());
  });
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: match digit + token, where token is not at the start of string
  // We want to return the full match including the digit
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  // Find all matches
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to the policy.
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol.
 * No whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length 10
  if (value.length < 10) return false;
  
  // No whitespace
  if (/\s/.test(value)) return false;
  
  // At least one uppercase
  if (!/[A-Z]/.test(value)) return false;
  
  // At least one lowercase
  if (!/[a-z]/.test(value)) return false;
  
  // At least one digit
  if (!/\d/.test(value)) return false;
  
  // At least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // No immediate repeated sequences (e.g., abab, abcabc)
  // Check for repeated patterns of length 2-4
  for (let patternLength = 2; patternLength <= 4; patternLength++) {
    for (let i = 0; i <= value.length - patternLength * 2; i++) {
      const pattern = value.slice(i, i + patternLength);
      const nextChunk = value.slice(i + patternLength, i + patternLength * 2);
      if (pattern === nextChunk) return false;
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 address patterns
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can replace one or more consecutive groups of zeros
  
  // Full IPv6 pattern (8 groups of 1-4 hex digits)
  const fullIpv6Pattern = /^(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with :: shorthand (compressed)
  // Matches formats like: 2001:db8::1, ::1, 2001::, fe80::1, etc.
  // Pattern: optional groups before :: (last one without colon), optional groups after ::
  const compressedIpv6Pattern = /^(?:(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{0,4}|::(?:[0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|::$)$/;
  
  // Check if any word in the string is an IPv6 address
  const words = value.split(/\s+/);
  for (const word of words) {
    if (fullIpv6Pattern.test(word) || compressedIpv6Pattern.test(word)) {
      return true;
    }
  }
  
  return false;
}
