/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  updateObserver,
  getActiveObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn = typeof equal === 'function' ? equal : 
                  equal === false ? (a: T, b: T) => a === b : 
                  (a: T, b: T) => Object.is(a, b);

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    if (!s.equalFn!(s.value, nextValue)) {
      s.value = nextValue
      // Create a copy of the reference before updating
      // to avoid issues with the observer being modified during update
      const observer = s.observer
      if (observer) {
        // For callback observers, call their update function directly
        if (typeof (observer as { updateFn?: Function }).updateFn === 'function') {
          (observer as { updateFn?: Function }).updateFn!()
        } else {
          // For other observers (like computed), create a temporary observer for notification
          const tempObserver: Observer<T> = {
            name: observer.name,
            value: undefined,
            updateFn: () => s.value
          }
          updateObserver(tempObserver)
        }
      }
    }
    return s.value
  }

  return [read, write]
}
