/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR,
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Create the observer that computes the new value
  const observer = {
    name: options?.name,
    updateFn,
    value
  } as Observer<T>
  
  return (): T => {
    // If an observer is currently active (someone is reading this computed value)
    const activeObserver = getActiveObserver()
    
    // Set this computed as the active observer to track its dependencies
    // when we evaluate the update function
    updateObserver(observer)
    
    // Store the computed value locally before returning to ensure consistency
    const currentValue = observer.value
    
    // After computing the value, establish relationship with any active observer
    // so that when inputs change, they will trigger re-evaluation and notification
    if (activeObserver && activeObserver !== observer) {
      // Set the computed's value as a dependency of the active observer
      // This ensures that when the computed's dependencies change,
      // the active observer will be notified
      // Using type assertion to bypass type system limitations in observer chain
      (observer as Observer<T> & { observer?: ObserverR }).observer = activeObserver
    }
    
    // Return the current value
    return currentValue!
  }
}