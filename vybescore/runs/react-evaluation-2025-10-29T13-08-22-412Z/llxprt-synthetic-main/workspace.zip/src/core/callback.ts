/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer = {
    value,
    updateFn,
  } as Observer<T>
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let _disposed = false
  
  return () => {
    // Dispose the callback to prevent further updates
    _disposed = true
    
    // Clear the observer to stop further updates
    // We need to remove this observer from any subjects that reference it
    // Since we don't have direct access to the subjects, we'll set a flag
    // to prevent further execution
    observer.updateFn = () => value as T
  }
}