/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  observer?: ObserverR
  // For callbacks, we need to store the update function
  updateFn?: UpdateFn<unknown>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let updateStack: ObserverR[] = []

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Check if we're already updating this observer to prevent infinite recursion
  if (updateStack.includes(observer)) {
    return
  }
  
  updateStack.push(observer)
  try {
    const previous = activeObserver
    activeObserver = observer
    try {
      observer.value = (observer.updateFn as any)(observer.value)
    } finally {
      activeObserver = previous
    }
    
    // After updating, notify any observer that depends on this one
    const nextObserver = (observer as Observer<T> & { observer?: ObserverR }).observer
    if (nextObserver && !updateStack.includes(nextObserver)) {
      // For callback observers, we need to call their update function directly
      // For computed observers, we need to trigger their re-evaluation
      if (typeof nextObserver.updateFn === 'function') {
        // This is a callback observer
        (nextObserver.updateFn as any)(undefined)
      } else {
        // This is a computed observer (without an updateFn)
        // Find and update any computed that depends on this observer
        // This is a simplified approach - in a full reactive system,
        // we'd have a dependency graph to traverse
      }
    }
  } finally {
    updateStack = updateStack.filter(o => o !== observer)
  }
}
