/**
 * Encode plain text to standard Base64.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding and rejects invalid payloads.
 */
export function decode(input: string): string {
  // Validate that the input is valid Base64
  if (!isValidBase64(input)) {
    throw new Error('Invalid Base64 input');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Check if a string is valid Base64.
 * This function allows for missing padding but ensures the string only contains
 * valid Base64 characters.
 */
function isValidBase64(input: string): boolean {
  // Base64 alphabet: A-Z, a-z, 0-9, +, /, and optional padding =
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Check if the string contains only valid Base64 characters
  // and has valid length (not modulo 4 === 1, which is invalid)
  if (!base64Regex.test(input) || input.length % 4 === 1) {
    return false;
  }
  
  // Further validate by attempting to decode
  // This catches edge cases like characters that pass the regex 
  // but produce invalid Unicode
  try {
    const tempBuffer = Buffer.from(input, 'base64');
    
    // Verify that the buffer content is valid UTF-8
    const utf8String = tempBuffer.toString('utf8');
    
    // Check that we can round-trip the data
    const roundTripBuffer = Buffer.from(utf8String, 'utf8');
    return tempBuffer.equals(roundTripBuffer);
  } catch (_) {
    return false;
  }
}
