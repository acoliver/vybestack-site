import request from 'supertest';
import { createApp } from './src/server/app.ts';

async function runTests() {
  console.log('Testing API endpoints...');
  
  let app;
  try {
    app = await createApp();
    console.log('[OK] App created successfully');
  } catch (error) {
    console.error(' Failed to create app:', error.message);
    process.exit(1);
  }

  // Test 1: Default values (should work)
  try {
    console.log('\n1. Testing default values...');
    const response = await request(app).get('/inventory');
    console.log('[OK] Default endpoint works');
    console.log('Response:', JSON.stringify(response.body, null, 2));
    
    if (!response.body.page || !response.body.limit || !response.body.total || !response.body.items) {
      console.log(' Missing required fields in response');
    } else {
      console.log('[OK] Response has all pagination fields');
    }
  } catch (error) {
    console.error(' Default test failed:', error.response?.body || error.message);
  }

  // Test 2: Page 1, limit 3
  try {
    console.log('\n2. Testing page=1&limit=3...');
    const response = await request(app).get('/inventory?page=1&limit=3');
    console.log('[OK] Pagination parameters work');
    console.log('Response:', JSON.stringify(response.body, null, 2));
    
    if (response.body.items.length !== 3) {
      console.log(` Expected 3 items, got ${response.body.items.length}`);
    } else {
      console.log('[OK] Correct number of items returned');
    }
    
    if (response.body.page !== 1 || response.body.limit !== 3) {
      console.log(` Wrong pagination metadata: page=${response.body.page}, limit=${response.body.limit}`);
    } else {
      console.log('[OK] Correct pagination metadata');
    }
  } catch (error) {
    console.error(' Pagination test failed:', error.response?.body || error.message);
  }

  // Test 3: Page 2, limit 3
  try {
    console.log('\n3. Testing page=2&limit=3...');
    const response = await request(app).get('/inventory?page=2&limit=3');
    console.log('[OK] Second page works');
    console.log('Response:', JSON.stringify(response.body, null, 2));
    
    if (response.body.page !== 2) {
      console.log(` Wrong page number: expected 2, got ${response.body.page}`);
    } else {
      console.log('[OK] Correct page number');
    }
  } catch (error) {
    console.error(' Second page test failed:', error.response?.body || error.message);
  }

  // Test 4: Invalid parameters
  try {
    console.log('\n4. Testing invalid parameters (page=0)...');
    const response = await request(app).get('/inventory?page=0');
    console.log('[OK] Invalid page parameter is rejected');
    console.log('Error response:', JSON.stringify(response.body, null, 2));
  } catch (error) {
    if (error.response?.status === 400) {
      console.log('[OK] Invalid parameter correctly rejected with 400 status');
    } else {
      console.error(' Invalid parameter test failed:', error.response?.body || error.message);
    }
  }

  try {
    console.log('\n5. Testing invalid parameters (limit=abc)...');
    const response = await request(app).get('/inventory?limit=abc');
    console.log('[OK] Invalid limit parameter is rejected');
    console.log('Error response:', JSON.stringify(response.body, null, 2));
  } catch (error) {
    if (error.response?.status === 400) {
      console.log('[OK] Invalid limit parameter correctly rejected with 400 status');
    } else {
      console.error(' Invalid limit test failed:', error.response?.body || error.message);
    }
  }

  console.log('\nAll tests completed!');
  process.exit(0);
}

runTests();