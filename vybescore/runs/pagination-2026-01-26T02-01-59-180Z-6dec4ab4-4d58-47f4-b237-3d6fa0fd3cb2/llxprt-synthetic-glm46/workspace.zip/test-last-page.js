import request from 'supertest';
import { createApp } from './src/server/app.ts';

async function testLastPage() {
  console.log('Testing last page behavior...');
  
  let app;
  try {
    app = await createApp();
    console.log('[OK] App created successfully');
  } catch (error) {
    console.error(' Failed to create app:', error.message);
    process.exit(1);
  }

  // Test page 5, limit 3 (should be the last page)
  try {
    console.log('\nTesting page=5&limit=3 (should be last page)...');
    const response = await request(app).get('/inventory?page=5&limit=3');
    console.log('Response:', JSON.stringify(response.body, null, 2));
    
    if (response.body.page !== 5 || response.body.limit !== 3) {
      console.log(' Wrong pagination metadata');
    } else {
      console.log('[OK] Correct pagination metadata');
    }
    
    if (response.body.hasNext) {
      console.log(' Last page incorrectly reports hasNext=true');
    } else {
      console.log('[OK] Last page correctly reports hasNext=false');
    }
    
    // Check that we get less than full items on last page
    if (response.body.items.length !== 3) {
      console.log(`[OK] Last page has ${response.body.items.length} items (less than limit=3)`);
    } else {
      console.log('? Last page has exactly limit items, might still be correct if multiple of limit');
    }
  } catch (error) {
    console.error(' Last page test failed:', error.response?.body || error.message);
  }

  // Test page 6, limit 3 (should return no items)
  try {
    console.log('\nTesting page=6&limit=3 (should return no items)...');
    const response = await request(app).get('/inventory?page=6&limit=3');
    console.log('Response:', JSON.stringify(response.body, null, 2));
    
    if (response.body.items.length !== 0) {
      console.log(` Expected empty result for page 6, got ${response.body.items.length} items`);
    } else {
      console.log('[OK] Page 6 correctly returns empty result');
    }
    
    if (response.body.hasNext) {
      console.log(' Empty page incorrectly reports hasNext=true');
    } else {
      console.log('[OK] Empty page correctly reports hasNext=false');
    }
  } catch (error) {
    console.error(' Empty page test failed:', error.response?.body || error.message);
  }

  console.log('\nLast page tests completed!');
  process.exit(0);
}

testLastPage();