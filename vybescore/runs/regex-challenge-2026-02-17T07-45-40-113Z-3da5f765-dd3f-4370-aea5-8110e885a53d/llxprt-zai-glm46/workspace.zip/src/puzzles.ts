/**
 * Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern to match words starting with prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]*\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptions.includes(word.toLowerCase()));
}

/**
 * Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 * Uses lookaheads/lookbehinds.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: digit followed by token, but not at the start of the string
  // We want to return the entire match including the digit
  const pattern = new RegExp(`(?<=.)\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * Validate passwords according to strong password policy.
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric, non-space)
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (e.g., abab, 123123)
  // Look for any 2+ character pattern that repeats immediately
  for (let len = 2; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - len * 2; i++) {
      const substr = value.slice(i, i + len);
      const nextSubstr = value.slice(i + len, i + len * 2);
      if (substr === nextSubstr) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (simplified but comprehensive)
  // Supports shorthand ::
  // Does not match IPv4 addresses
  
  // More comprehensive IPv6 pattern
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Shorthand: :: can replace one or more consecutive groups of zeros
  
  // Pattern to match IPv6 with :: shorthand
  const ipv6WithShorthand = /(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/;
  
  // Pattern to match full IPv6 (8 groups)
  const ipv6Full = /(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}/;
  
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  
  // First check if it matches IPv6 patterns
  const hasIPv6Shorthand = ipv6WithShorthand.test(value);
  const hasIPv6Full = ipv6Full.test(value);
  
  if (!hasIPv6Shorthand && !hasIPv6Full) {
    return false;
  }
  
  // Make sure it's not just an IPv4 address
  // Extract potential IPv6 addresses and verify they're not IPv4
  const lines = value.split(/\s+/);
  
  for (const line of lines) {
    // Try to match IPv6 pattern
    if (ipv6WithShorthand.test(line) || ipv6Full.test(line)) {
      // Verify this isn't just an IPv4
      if (!ipv4Pattern.test(line)) {
        return true;
      }
    }
  }
  
  return false;
}
