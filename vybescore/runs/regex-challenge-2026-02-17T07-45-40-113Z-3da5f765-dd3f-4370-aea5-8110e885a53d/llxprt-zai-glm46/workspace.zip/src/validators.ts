export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 * - Accepts typical addresses like name@tag@example.co.uk
 * - Rejects double dots, trailing dots, domains with underscores, and other invalid forms
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  // Local part: letters, digits, dots, hyphens, underscores, plus signs
  // But no double dots, no leading/trailing dots
  // Domain: letters, digits, hyphens (no underscores), proper TLD
  
  const emailRegex = /^(?!.*\.\.)[a-zA-Z0-9][a-zA-Z0-9._%+-]*[a-zA-Z0-9]@(?!.*\.\.)[a-zA-Z0-9][a-zA-Z0-9.-]*[a-zA-Z0-9]\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks
  const [local, domain] = value.split('@');
  
  // Local part should not start or end with dot
  if (local.startsWith('.') || local.endsWith('.')) {
    return false;
  }
  
  // Local part should not have consecutive dots
  if (local.includes('..')) {
    return false;
  }
  
  // Domain should not contain underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain should not start or end with dot or hyphen
  if (domain.startsWith('.') || domain.endsWith('.') || domain.startsWith('-') || domain.endsWith('-')) {
    return false;
  }
  
  // Domain should have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) {
    return false;
  }
  
  // TLD should be at least 2 chars
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers supporting common formats.
 * - Supports: (212) 555-7890, 212-555-7890, 2125557890
 * - Optional +1 prefix
 * - Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check minimum length (10 digits for US number)
  const digits = cleaned.replace(/\+/g, '');
  if (digits.length < 10) {
    return false;
  }
  
  // Match patterns with optional +1 country code
  // Area code cannot start with 0 or 1
  const usPhoneRegex = /^(?:\+1)?(\d{10})$/;
  
  if (!usPhoneRegex.test(cleaned)) {
    return false;
  }
  
  // Extract the 10-digit number (without country code)
  const phoneNumber = digits.length === 10 ? digits : digits.slice(1);
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = parseInt(phoneNumber.slice(0, 3), 10);
  if (areaCode < 200) {
    return false;
  }
  
  // Check exchange code (next 3 digits) - cannot start with 0 or 1
  const exchangeCode = parseInt(phoneNumber.slice(3, 6), 10);
  if (exchangeCode < 200) {
    return false;
  }
  
  return true;
}

/**
 * Validate Argentine phone numbers covering mobile and landline formats.
 * - Optional country code +54
 * - Optional trunk prefix 0 immediately before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits
 * - When country code omitted, must have trunk prefix 0
 * - Allows spaces or hyphens as separators
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex
  // Optional +54, optional 0 trunk prefix, optional 9 mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber: 6-8 digits
  const argPhoneRegex = /^(?:\+54)?(?:0)?9?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argPhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, areaCode, subscriber] = match;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  // If no country code, must have trunk prefix 0
  const hasCountryCode = cleaned.startsWith('+54');
  const hasTrunkPrefix = cleaned.startsWith('0') || (cleaned.startsWith('+540'));
  
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * - Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least one letter
  // Cannot contain digits or symbols (except allowed ones)
  const nameRegex = /^[\p{L}'-]+(?:[\s][\p{L}'-]+)*$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for invalid symbols (anything not a letter, space, apostrophe, or hyphen)
  const invalidChars = /[^\p{L}\s'-]/u;
  if (invalidChars.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * - Accepts Visa (starts with 4, 13-16 digits)
 * - Accepts Mastercard (starts with 51-55 or 2221-2720, 16 digits)
 * - Accepts AmEx (starts with 34 or 37, 15 digits)
 * - Runs Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be only digits
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Check length and prefix for each card type
  const isVisa = /^4\d{12,15}$/.test(cleaned);
  const isMastercard = /^(?:5[1-5]\d{14}|2[2-7][0-9]{13})$/.test(cleaned);
  const isAmEx = /^3[47]\d{13}$/.test(cleaned);
  
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
