/**
 * Capitalize the first character of each sentence.
 * - Capitalizes after .!?
 * - Inserts exactly one space between sentences if input omitted it
 * - Collapses extra spaces while leaving abbreviations intact
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces: collapse multiple spaces into one
  let normalized = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence endings if missing (before any letter)
  // Look for .!? followed immediately by a letter (not space)
  normalized = normalized.replace(/([.!?])([a-zA-Z])/g, '$1 $2');
  
  // Capitalize first letter of text
  normalized = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence endings (.!?)
  // Need to handle common abbreviations like Dr., Mr., Ms., Mrs., etc.
  // We'll use a negative lookbehind for common abbreviations
  const abbreviationPattern = /\b(?:Dr|Mr|Ms|Mrs|Prof|Sr|Jr|St|Ave|Blvd|Rd|etc|e\.g|i\.e)\.$/;
  
  let result = '';
  let i = 0;
  
  while (i < normalized.length) {
    const char = normalized[i];
    
    if (char === '.' || char === '!' || char === '?') {
      result += char;
      i++;
      
      // Skip whitespace (but keep exactly one space)
      if (i < normalized.length && normalized[i] === ' ') {
        result += ' ';
        i++;
        // Skip any additional spaces
        while (i < normalized.length && normalized[i] === ' ') {
          i++;
        }
      } else if (i < normalized.length) {
        // No space after punctuation, add one
        result += ' ';
      }
      
      // Check if this is the end of an abbreviation
      const beforePeriod = result.slice(0, -2).split(/[\s.!?]+/).pop() || '';
      
      // If not an abbreviation, capitalize next letter
      if (i < normalized.length && !abbreviationPattern.test(beforePeriod + '.')) {
        result += normalized[i].toUpperCase();
        i++;
      }
    } else {
      result += char;
      i++;
    }
  }
  
  return result;
}

/**
 * Find URLs in the text. Return an array of matched URL strings.
 * - Returns URLs without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  // Matches http://, https://, or www.
  // Captures the full URL
  // Stops at punctuation or whitespace
  const urlPattern = /(?:https?:\/\/|www\.)[^\s<>"{}|^`[\]]+(?<![.,!?;:])/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation that might be attached
  return matches.map(url => url.trim());
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// globally
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /http:\/\/example\.com(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, path = '') => {
    // Always upgrade to https
    let result = 'https://example.com' + path;
    
    // Check if we should rewrite to docs.example.com
    // Only if path starts with /docs/
    // And no dynamic hints or legacy extensions
    if (path && path.startsWith('/docs/')) {
      // Check for excluded patterns
      const hasQueryString = /[?&=]/.test(path);
      const hasCgiBin = /\/cgi-bin\//i.test(path);
      const hasLegacyExt = /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\/|\?|$)/i.test(path);
      
      if (!hasQueryString && !hasCgiBin && !hasLegacyExt) {
        // Rewrite host to docs.example.com
        result = 'https://docs.example.com' + path;
      }
    }
    
    return result;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  return year;
}
