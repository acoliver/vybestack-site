#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { parseReportData } from '../utils/validation.js';
import { getRenderer } from '../formats/index.js';
import type { RenderOptions } from '../types.js';

/**
 * Parses CLI arguments from process.argv.
 * Returns an object with the parsed values.
 */
function parseArgs(argv: string[]): {
  inputPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
} {
  const args = argv.slice(2);

  if (args.length === 0) {
    console.error('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputPath = args[0];

  let format = '';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[++i];
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: unknown option: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { inputPath, format, outputPath, includeTotals };
}

/**
 * Main CLI entry point.
 */
function main(): void {
  const { inputPath, format, outputPath, includeTotals } = parseArgs(process.argv);

  // Read and parse input file
  let inputContent: string;
  try {
    inputContent = readFileSync(inputPath, 'utf-8');
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading file: ${error.message}`);
    } else {
      console.error('Error reading file');
    }
    process.exit(1);
  }

  // Parse and validate JSON
  const data = parseReportData(inputContent);

  // Get renderer and render report
  const options: RenderOptions = { includeTotals };
  const render = getRenderer(format);
  const output = render(data, options);

  // Write output
  if (outputPath) {
    try {
      writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error writing output file: ${error.message}`);
      } else {
        console.error('Error writing output file');
      }
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
