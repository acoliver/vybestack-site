/**
 * Represents a single entry in the report.
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Represents the full report data structure.
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Options for rendering the report.
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Format string type.
 */
export type Format = 'markdown' | 'text';

/**
 * Renderer function type.
 */
export type Renderer = (data: ReportData, options: RenderOptions) => string;
