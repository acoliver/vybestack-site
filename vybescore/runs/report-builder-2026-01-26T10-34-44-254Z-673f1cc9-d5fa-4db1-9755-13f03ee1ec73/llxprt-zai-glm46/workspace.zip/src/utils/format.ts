/**
 * Formats an amount as a dollar string with exactly 2 decimal places.
 */
export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

/**
 * Calculates the total amount from an array of entries.
 */
export function calculateTotal(
  entries: Array<{ amount: number }>
): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}
