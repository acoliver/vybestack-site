import { ReportData } from '../types.js';

/**
 * Validates that the data is a valid ReportData object.
 * Throws an error with a helpful message if validation fails.
 */
export function validateReportData(data: unknown): asserts data is ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid input: data must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid input: missing or invalid "title" field (expected string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid input: missing or invalid "summary" field (expected string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid input: missing or invalid "entries" field (expected array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid input: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(
        `Invalid input: entry at index ${i} is missing or invalid "label" field (expected string)`
      );
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(
        `Invalid input: entry at index ${i} is missing or invalid "amount" field (expected number)`
      );
    }
  }
}

/**
 * Parses and validates JSON string into ReportData.
 */
export function parseReportData(jsonString: string): ReportData {
  try {
    const data = JSON.parse(jsonString);
    validateReportData(data);
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON: ${error.message}`);
    }
    throw error;
  }
}
