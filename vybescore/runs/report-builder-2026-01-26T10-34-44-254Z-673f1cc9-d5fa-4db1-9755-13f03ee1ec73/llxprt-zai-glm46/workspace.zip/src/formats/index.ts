import { Format, Renderer } from '../types.js';
import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';

/**
 * Registry of available format renderers.
 */
export const FORMAT_RENDERERS: Record<Format, Renderer> = {
  markdown: renderMarkdown,
  text: renderText,
};

/**
 * Returns a renderer function for the given format.
 * Throws an error if the format is unsupported.
 */
export function getRenderer(format: string): Renderer {
  if (format in FORMAT_RENDERERS) {
    return FORMAT_RENDERERS[format as Format];
  }
  throw new Error(`Unsupported format: ${format}`);
}
