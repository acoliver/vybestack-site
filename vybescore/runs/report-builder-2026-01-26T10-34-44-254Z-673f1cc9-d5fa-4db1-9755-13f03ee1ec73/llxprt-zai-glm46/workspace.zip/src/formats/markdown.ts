import { ReportData, RenderOptions, Renderer } from '../types.js';
import { formatAmount, calculateTotal } from '../utils/format.js';

/**
 * Renders report data in Markdown format.
 */
export const renderMarkdown: Renderer = (
  data: ReportData,
  options: RenderOptions
): string => {
  const lines: string[] = [];

  // Title as H1
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries section
  lines.push('## Entries');

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Optional total
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
};
