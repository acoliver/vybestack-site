/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const results: string[] = [];
  
  // Create a regex that matches words starting with prefix
  // Word boundary to ensure we match complete words
  const prefixRegex = new RegExp(`\\b${prefix}[a-zA-Z0-9]*\\b`, 'g');
  
  const matches = text.matchAll(prefixRegex);
  
  for (const match of matches) {
    const word = match[0];
    // Only add if not in exceptions
    if (!exceptions.includes(word)) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const results: string[] = [];
  
  // Pattern to match token:
  // (?<!^) - not at the start of string (negative lookbehind)
  // (?<=\d) - preceded by a digit (positive lookbehind)
  const embeddedTokenRegex = new RegExp(`(?<!^)(?<=\\d)${token}`, 'g');
  
  const matches = text.matchAll(embeddedTokenRegex);
  
  for (const match of matches) {
    results.push(token);
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab)
  // Look for any 4-character sequence that repeats immediately
  const hasRepeatedSequence = /(..)\1/.test(value);
  if (hasRepeatedSequence) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First check if it contains colons (required for IPv6)
  if (!value.includes(':')) {
    return false;
  }
  
  // Check for pure IPv4 pattern (dotted decimal with 4 octets)
  // If it's purely IPv4, reject
  if (/^\d{1,3}(\.\d{1,3}){3}$/.test(value.trim())) {
    return false;
  }
  
  // Multiple patterns to catch various IPv6 formats
  const patterns = [
    // Full 8-group format: 2001:0db8:0000:0000:0000:0000:0000:0001
    /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/,
    
    // Compressed with :: at various positions
    /^::1$/,  // loopback
    /^::$/,   // all zeros
    /^::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{0,4}$/,  // :: at start
    /^([0-9a-fA-F]{1,4}:){0,5}::$/,  // :: at end
    /^([0-9a-fA-F]{1,4}:){1,7}$/,   // ends with :
    /^([0-9a-fA-F]{1,4}:){1,7}::([0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{0,4}$/,  // :: in middle
    /^([0-9a-fA-F]{1,4}:){1,7}([0-9a-fA-F]{1,4})?$/,  // :: with trailing groups
    
    // IPv4-mapped/compat IPv6
    /^::ffff:([0-9]{1,3}\.){3}[0-9]{1,3}$/,
    /^::([0-9]{1,3}\.){3}[0-9]{1,3}$/,
  ];
  
  const trimmedValue = value.trim();
  
  return patterns.some(pattern => pattern.test(trimmedValue));
}
