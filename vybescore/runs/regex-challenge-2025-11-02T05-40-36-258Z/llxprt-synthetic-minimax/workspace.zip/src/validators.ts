export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(number: string): boolean {
  const digits = number.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  let sum = 0;
  let shouldDouble = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (shouldDouble) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    shouldDouble = !shouldDouble;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Email pattern that validates:
  // - Local part: letters, numbers, dots, plus, hyphens, underscores
  // - No double dots in local part
  // - No trailing dot in local part
  // - At least one dot in domain
  // - No underscores in domain
  // - Domain: letters, numbers, dots, hyphens
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._+\-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.\-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks: no double dots anywhere, no trailing dots
  if (value.includes('..') || value.includes('.@') || value.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Check if extension is allowed and present
  if (options?.allowExtensions) {
    // Format could be +1XXXXXXXXXXEXXXXX or digits with extension
    // We need at least 11 digits (including +1) or 10 without
    const match = value.match(/(\+?1)?\s*\(?([2-9]\d{2})\)?[\s\-.]*([2-9]\d{2})[\s\-.]*(\d{4})(?:\s*(?:ext|x|extension)\s*\.?:?\s*(\d{1,5}))?/i);
    if (!match) return false;
    
    const areaCode = match[2];
    const centralOfficeCode = match[3];
    
    // Area codes cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
    // Central office codes cannot start with 0 or 1
    if (centralOfficeCode[0] === '0' || centralOfficeCode[0] === '1') return false;
    
    return true;
  } else {
    // Without extension, we need exactly 10 digits (or 11 with +1)
    if (digits.length !== 10 && digits.length !== 11) return false;
    
    // If 11 digits, first should be 1 (for +1)
    if (digits.length === 11 && !digits.startsWith('1')) return false;
    
    // Extract area code (first 3 digits, or digits 2-4 if 11 digits with +1)
    const areaCode = digits.length === 11 ? digits.substring(1, 4) : digits.substring(0, 3);
    // Central office code (next 3 digits)
    const centralOfficeCode = digits.length === 11 ? digits.substring(4, 7) : digits.substring(3, 6);
    
    // Area codes cannot start with 0 or 1
    if (areaCode[0] === '0' || areaCode[0] === '1') return false;
    // Central office codes cannot start with 0 or 1
    if (centralOfficeCode[0] === '0' || centralOfficeCode[0] === '1') return false;
    
    return true;
  }
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-digit characters to work with pure digits
  const digits = value.replace(/\D/g, '');
  
  // Total digits must be between 8 and 13 (country + area + subscriber)
  if (digits.length < 8 || digits.length > 13) {
    return false;
  }
  
  // Check if it starts with +54 (country code)
  const hasCountryCode = digits.startsWith('54');
  const digitsWithoutCountry = hasCountryCode ? digits.substring(2) : digits;
  
  // Must start with 0 if no country code (trunk prefix requirement)
  if (!hasCountryCode && !digitsWithoutCountry.startsWith('0')) {
    return false;
  }
  
  // Remove leading 0 (trunk prefix)
  const digitsWithoutTrunk = digitsWithoutCountry.startsWith('0') 
    ? digitsWithoutCountry.substring(1) 
    : digitsWithoutCountry;
  
  // Check for mobile indicator '9'
  const hasMobileIndicator = digitsWithoutTrunk.startsWith('9');
  const digitsAfterMobileIndicator = hasMobileIndicator 
    ? digitsWithoutTrunk.substring(1) 
    : digitsWithoutTrunk;
  
  // Extract area code (2-4 digits, first digit 1-9)
  if (digitsAfterMobileIndicator.length < 2) return false;
  
  const areaCodeLength = Math.min(4, digitsAfterMobileIndicator.length - 6);
  if (areaCodeLength < 2) return false;
  
  // Area code first digit must be 1-9
  if (digitsAfterMobileIndicator[0] < '1' || digitsAfterMobileIndicator[0] > '9') {
    return false;
  }
  
  const areaCode = digitsAfterMobileIndicator.substring(0, areaCodeLength);
  const subscriber = digitsAfterMobileIndicator.substring(areaCodeLength);
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Name can contain:
  // - Unicode letters (including accents)
  // - Spaces
  // - Apostrophes
  // - Hyphens
  // But not digits or other symbols
  
  // Pattern explanation:
  // ^ - start of string
  // [^\d\s'’-]* - zero or more characters that are NOT digits, spaces, apostrophes, or hyphens
  // ([’'\s-][^\d\s'’-]*)* - zero or more groups of separator + letters
  // $ - end of string
  
  // The pattern allows:
  // - Letters (unicode) in the main part
  // - Spaces, apostrophes, or hyphens followed by more letters
  // This rejects:
  // - Any digits
  // - Any other symbols
  
  const nameRegex = /^[^\d\s'’-]+(?:[’'\s-][^\d\s'’-]+)*$/u;
  
  // Must not be empty
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Must match the pattern
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Must contain at least one letter (not just separators)
  const hasLetter = /[^\s'’-]/u.test(value);
  if (!hasLetter) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  if (digits.length === 0) {
    return false;
  }
  
  // Check for valid card types and lengths
  // Visa: starts with 4, length 13, 16, or 19
  const isVisa = /^4/.test(digits) && (digits.length === 13 || digits.length === 16 || digits.length === 19);
  
  // MasterCard: starts with 51-55 or 2221-2720, length 16
  const isMasterCard = /^5[1-5]/.test(digits) || /^(222[1-9]|22[3-9]\d|2[3-6]\d{2}|27[01]\d|2720)/.test(digits);
  
  // AmEx: starts with 34 or 37, length 15
  const isAmEx = /^3[47]/.test(digits) && digits.length === 15;
  
  // If it doesn't match any known card type, reject
  if (!isVisa && !isMasterCard && !isAmEx) {
    return false;
  }
  
  // Must pass Luhn checksum
  return runLuhnCheck(digits);
}
