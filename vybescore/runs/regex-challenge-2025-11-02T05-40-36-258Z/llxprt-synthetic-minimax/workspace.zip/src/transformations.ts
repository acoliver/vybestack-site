/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to find the start of sentences: after .?! followed by whitespace
  // Also handles the beginning of the text
  return text.replace(/(^|[.?!]\s+)([a-z])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urls: string[] = [];
  
  // Pattern to match URLs
  // Matches:
  // - http:// or https://
  // - www. (without protocol)
  // - Domain with TLD (letters, numbers, dots, hyphens)
  // - Optional paths, queries, etc.
  const urlPattern = /https?:\/\/[^\s"')]+|(?:^|\s)www\.[^\s"')]+/gi;
  
  const matches = text.matchAll(urlPattern);
  
  for (const match of matches) {
    let url = match[0];
    
    // Remove leading space if present (from www. pattern)
    url = url.replace(/^\s/, '');
    
    // Remove trailing punctuation that shouldn't be part of URL
    url = url.replace(/[.,;:!?)+]+$/, '');
    
    // If it starts with www., we should check if it should have http://
    if (url.startsWith('www.')) {
      url = 'http://' + url;
    }
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Negative lookbehind to ensure we don't replace https://
  return text.replace(/(?<!https:)http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com(\/[^\s"']*)/gi, (match, path) => {
    const hasDynamicHints = /(\?|&|=|\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path) || /cgi-bin/i.test(path);
    
    if (path.startsWith('/docs/') && !hasDynamicHints) {
      // Extract the path after /docs/
      const docsPath = path.substring('/docs/'.length);
      return `https://docs.example.com/${docsPath}`;
    }
    
    // Otherwise, just upgrade the scheme
    return `https://example.com${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const match = value.match(/^(\d{1,2})\/(\d{1,2})\/(\d{4})$/);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, with basic range check)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Basic year validation (must be 4 digits, which it is from the regex)
  return year;
}
