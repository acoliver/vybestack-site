#!/usr/bin/env node
import * as fs from 'node:fs';
import { RENDERERS, type Format } from '../formats/index.js';
import { validateReportData } from '../validator.js';
import type { ReportData, RenderOptions } from '../types.js';

interface CliArgs {
  inputFile: string;
  format: Format;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CliArgs {
  if (args.length < 2) {
    printUsage();
    process.exit(1);
  }

  const inputFile = args[0];
  let format: Format = 'markdown';
  let outputPath: string | null = null;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatArg = args[i + 1];
      if (!formatArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      if (formatArg !== 'markdown' && formatArg !== 'text') {
        console.error(`Error: Unsupported format "${formatArg}"`);
        console.error('Supported formats: markdown, text');
        process.exit(1);
      }
      format = formatArg as Format;
      i++;
    } else if (arg === '--output') {
      const outputArg = args[i + 1];
      if (!outputArg) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputPath = outputArg;
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument "${arg}"`);
      printUsage();
      process.exit(1);
    }
  }

  return { inputFile, format, outputPath, includeTotals };
}

function printUsage(): void {
  console.log('Usage: report <data.json> --format <format> [--output <path>] [--includeTotals]');
  console.log('');
  console.log('Arguments:');
  console.log('  data.json      Path to the JSON file containing report data');
  console.log('');
  console.log('Options:');
  console.log('  --format       Output format (markdown or text)');
  console.log('  --output       Write output to file instead of stdout');
  console.log('  --includeTotals Include total amount in the report');
}

function readJsonFile(filePath: string): unknown {
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    return JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Failed to parse JSON in ${filePath}: ${error.message}`);
    }
    throw new Error(`Failed to read file ${filePath}: ${(error as Error).message}`);
  }
}

function main(): void {
  const args = process.argv.slice(2);
  const { inputFile, format, outputPath, includeTotals } = parseArguments(args);

  let rawData: unknown;
  try {
    rawData = readJsonFile(inputFile);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }

  let reportData: ReportData;
  try {
    reportData = validateReportData(rawData);
  } catch (error) {
    console.error(`Error: ${(error as Error).message}`);
    process.exit(1);
  }

  const renderer = RENDERERS[format];
  const options: RenderOptions = { includeTotals };
  const output = renderer(reportData, options);

  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to ${outputPath}: ${(error as Error).message}`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
