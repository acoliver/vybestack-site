#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData, CLIOptions, Formatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(argv: string[]): CLIOptions & { dataPath: string } {
  const args = argv.slice(2); // Remove node and script path
  
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;

  // Parse remaining arguments
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    switch (arg) {
      case '--format':
        if (i + 1 >= args.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        format = args[++i] as 'markdown' | 'text';
        break;
      case '--output':
        if (i + 1 >= args.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        outputPath = args[++i];
        break;
      case '--includeTotals':
        includeTotals = true;
        break;
      default:
        if (arg.startsWith('--')) {
          console.error(`Error: Unknown option ${arg}`);
          process.exit(1);
        }
        break;
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  if (format !== 'markdown' && format !== 'text') {
    console.error('Error: Unsupported format');
    process.exit(1);
  }

  return {
    dataPath,
    format,
    outputPath,
    includeTotals
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    if (!data.entries || !Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }

    // Validate entries structure
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i + 1}: Missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number') {
        throw new Error(`Entry ${i + 1}: Missing or invalid "amount" field`);
      }
    }

    return data as ReportData;
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error reading JSON file: ${error.message}`);
    } else {
      console.error('Error reading JSON file: Invalid JSON format');
    }
    process.exit(1);
  }
}

function getFormatter(format: 'markdown' | 'text'): Formatter {
  switch (format) {
    case 'markdown':
      return renderMarkdown;
    case 'text':
      return renderText;
    default:
      console.error('Error: Unsupported format');
      process.exit(1);
  }
}

function main(): void {
  const options = parseArgs(process.argv);
  const data = loadReportData(options.dataPath);
  const formatter = getFormatter(options.format);
  
  const output = formatter.render(data, options);
  
  if (options.outputPath) {
    try {
      writeFileSync(options.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error writing output file: ${error instanceof Error ? error.message : 'Unknown error'}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();
