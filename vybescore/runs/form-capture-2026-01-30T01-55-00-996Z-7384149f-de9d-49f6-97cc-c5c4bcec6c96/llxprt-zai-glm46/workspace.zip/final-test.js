#!/usr/bin/env node
/**
 * Final comprehensive test of the form capture application
 */

import { startServer, stopServer } from './dist/server.js';

async function runTests() {
  console.log('=== Final Comprehensive Test ===\n');
  
  // Clean database
  const fs = await import('node:fs');
  const path = await import('node:path');
  const dbPath = path.resolve('data', 'submissions.sqlite');
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
    console.log('[OK] Cleaned database');
  }
  
  // Start server
  console.log('\n1. Starting server...');
  await startServer();
  console.log('[OK] Server started');
  
  // Test 1: Homepage loads
  console.log('\n2. Testing homepage...');
  const homeRes = await fetch('http://localhost:3535/');
  const homeHtml = await homeRes.text();
  console.log('   Status:', homeRes.status, homeRes.status === 200 ? '[OK]' : '');
  console.log('   Form title:', homeHtml.includes('Tell us who you are') ? '[OK]' : '');
  console.log('   CSS linked:', homeHtml.includes('/public/styles.css') ? '[OK]' : '');
  console.log('   All form fields present:', 
    homeHtml.includes('name="firstName"') &&
    homeHtml.includes('name="email"') &&
    homeHtml.includes('name="phone"') ? '[OK]' : ''
  );
  
  // Test 2: Valid submission with international data
  console.log('\n3. Testing valid international submission...');
  const submitRes = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      firstName: 'François',
      lastName: 'Dubois',
      streetAddress: '15 Rue de la Paix',
      city: 'Paris',
      stateProvince: 'Île-de-France',
      postalCode: '75002',
      country: 'France',
      email: 'francois.dubois@example.com',
      phone: '+33 1 42 86 83 00',
    }),
    redirect: 'manual',
  });
  console.log('   Status:', submitRes.status, submitRes.status === 302 ? '[OK]' : '');
  console.log('   Redirect:', submitRes.headers.get('location') || 'none', 
    submitRes.headers.get('location')?.includes('/thank-you') ? '[OK]' : '');
  
  // Test 3: Thank you page
  console.log('\n4. Testing thank-you page...');
  const tyRes = await fetch('http://localhost:3535/thank-you?firstName=François');
  const tyHtml = await tyRes.text();
  console.log('   Status:', tyRes.status, tyRes.status === 200 ? '[OK]' : '');
  console.log('   Personalized greeting:', tyHtml.includes('Thank you,') ? '[OK]' : '');
  console.log('   Scam warning:', tyHtml.includes('stranger on the internet') ? '[OK]' : '');
  console.log('   Back link:', tyHtml.includes('href="/"') ? '[OK]' : '');
  
  // Test 4: Validation errors
  console.log('\n5. Testing validation errors...');
  const errorRes = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      firstName: '',
      lastName: 'Test',
      streetAddress: '123 St',
      city: 'City',
      stateProvince: 'State',
      postalCode: 'ABC123',
      country: 'Country',
      email: 'not-an-email',
      phone: 'invalid phone!@#',
    }),
  });
  const errorHtml = await errorRes.text();
  console.log('   Status:', errorRes.status, errorRes.status === 400 ? '[OK]' : '');
  console.log('   First name error:', errorHtml.includes('First name is required') ? '[OK]' : '');
  console.log('   Email error:', errorHtml.includes('valid email') || errorHtml.includes('Email is required') ? '[OK]' : '');
  console.log('   Phone error:', errorHtml.includes('Phone number must contain') ? '[OK]' : '');
  console.log('   Values preserved:', errorHtml.includes('not-an-email') ? '[OK]' : '');
  
  // Test 5: Database persistence
  console.log('\n6. Testing database persistence...');
  console.log('   Database file exists:', fs.existsSync(dbPath) ? '[OK]' : '');
  
  // Count submissions
  const { execSync } = await import('node:child_process');
  try {
    const count = execSync(`sqlite3 ${dbPath} "SELECT COUNT(*) FROM submissions;"`, { encoding: 'utf-8' });
    console.log('   Submissions saved:', count.trim(), count.trim() === '1' ? '[OK]' : '');
  } catch (e) {
    console.log('   Database query: ');
  }
  
  // Test 6: Multiple international formats
  console.log('\n7. Testing multiple international formats...');
  const tests = [
    {
      name: 'UK postal code',
      data: {
        firstName: 'Emma',
        lastName: 'Watson',
        streetAddress: 'Baker Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'SW1A 1AA',
        country: 'UK',
        email: 'emma@example.com',
        phone: '+44 20 7946 0958',
      },
    },
    {
      name: 'Argentine postal code',
      data: {
        firstName: 'Luis',
        lastName: 'Martinez',
        streetAddress: 'Av. Corrientes',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'luis@example.com',
        phone: '+54 9 11 1234-5678',
      },
    },
    {
      name: 'US phone with parentheses',
      data: {
        firstName: 'Sarah',
        lastName: 'Johnson',
        streetAddress: 'Main St',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001-1234',
        country: 'USA',
        email: 'sarah@example.com',
        phone: '+1 (212) 555-1234',
      },
    },
  ];
  
  for (const test of tests) {
    const res = await fetch('http://localhost:3535/submit', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: new URLSearchParams(test.data),
      redirect: 'manual',
    });
    console.log(`   ${test.name}:`, res.status === 302 ? '[OK]' : ` (${res.status})`);
  }
  
  // Final check
  try {
    const finalCount = execSync(`sqlite3 ${dbPath} "SELECT COUNT(*) FROM submissions;"`, { encoding: 'utf-8' });
    console.log('\n8. Final database check:');
    console.log('   Total submissions:', finalCount.trim(), finalCount.trim() === '4' ? '[OK]' : '');
  } catch (e) {
    console.log('   Final database count: ');
  }
  
  console.log('\n=== All Tests Complete ===\n');
  
  // Stop server
  console.log('Stopping server...');
  stopServer();
  await new Promise(resolve => setTimeout(resolve, 500));
  
  console.log('[OK] Test suite completed successfully!\n');
}

runTests().catch(err => {
  console.error('Test failed:', err);
  process.exit(1);
});
