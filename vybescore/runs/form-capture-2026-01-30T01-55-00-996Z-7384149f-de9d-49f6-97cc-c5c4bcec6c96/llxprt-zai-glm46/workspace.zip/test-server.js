import { startServer, stopServer, app } from './dist/server.js';

async function testServer() {
  console.log('Starting server...');
  await startServer();
  
  // Wait a bit
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Test with curl equivalent using fetch
  const response = await fetch('http://localhost:3535/');
  const html = await response.text();
  
  console.log('Homepage status:', response.status);
  console.log('Form present:', html.includes('Tell us who you are'));
  console.log('CSS linked:', html.includes('/public/styles.css'));
  
  // Test form submission
  const submitResponse = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Test St',
      city: 'Tokyo',
      stateProvince: 'Tokyo',
      postalCode: '100-0001',
      country: 'Japan',
      email: 'test@example.com',
      phone: '+81 3 1234-5678',
    }),
    redirect: 'manual',
  });
  
  console.log('Submit status:', submitResponse.status);
  console.log('Redirect location:', submitResponse.headers.get('location'));
  console.log('Redirect status correct:', submitResponse.status === 302);
  
  // Test thank you page
  const thankYouResponse = await fetch('http://localhost:3535/thank-you?firstName=Test');
  const thankYouHtml = await thankYouResponse.text();
  console.log('Thank you page status:', thankYouResponse.status);
  console.log('Thank you message:', thankYouHtml.includes('Thank you, Test!'));
  console.log('Scam warning:', thankYouHtml.includes('stranger on the internet'));
  
  // Test validation error
  const errorResponse = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: 'invalid-email',
      phone: '',
    }),
  });
  
  console.log('Validation error status:', errorResponse.status);
  const errorHtml = await errorResponse.text();
  console.log('First name error shown:', errorHtml.includes('First name is required'));
  console.log('Email validation error shown:', errorHtml.includes('valid email address') || errorHtml.includes('Email is required'));
  console.log('Form values preserved:', errorHtml.includes('invalid-email'));
  
  // Test international phone numbers
  console.log('\n--- Testing International Formats ---');
  
  // UK format
  const ukResponse = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      firstName: 'Emma',
      lastName: 'Thompson',
      streetAddress: '221B Baker Street',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'NW1 6XE',
      country: 'United Kingdom',
      email: 'emma@example.com',
      phone: '+44 20 7946 0958',
    }),
    redirect: 'manual',
  });
  console.log('UK submission status:', ukResponse.status === 302 ? '[OK] Redirect' : ukResponse.status);
  
  // Argentina format
  const arResponse = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      firstName: 'Carlos',
      lastName: 'Garcia',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'carlos@example.com',
      phone: '+54 9 11 1234-5678',
    }),
    redirect: 'manual',
  });
  console.log('Argentina submission status:', arResponse.status === 302 ? '[OK] Redirect' : arResponse.status);
  
  // US format
  const usResponse = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      firstName: 'John',
      lastName: 'Smith',
      streetAddress: '123 Main Street',
      city: 'New York',
      stateProvince: 'NY',
      postalCode: '10001',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 (212) 555-1234',
    }),
    redirect: 'manual',
  });
  console.log('US submission status:', usResponse.status === 302 ? '[OK] Redirect' : usResponse.status);
  
  // Test with phone starting with @ (as mentioned in requirements)
  const atPhoneResponse = await fetch('http://localhost:3535/submit', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      firstName: 'Test',
      lastName: 'User2',
      streetAddress: '456 Test Ave',
      city: 'Berlin',
      stateProvince: 'Berlin',
      postalCode: '10115',
      country: 'Germany',
      email: 'test2@example.com',
      phone: '+49 30 12345678',
    }),
    redirect: 'manual',
  });
  console.log('Germany submission status:', atPhoneResponse.status === 302 ? '[OK] Redirect' : atPhoneResponse.status);
  
  console.log('\nAll manual tests completed!');
  console.log('Stopping server...');
  
  stopServer();
  await new Promise(resolve => setTimeout(resolve, 1000));
  process.exit(0);
}

testServer().catch(err => {
  console.error('Test failed:', err);
  process.exit(1);
});
