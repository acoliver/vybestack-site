import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, startServer, stopServer } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  await startServer();
});

afterAll(() => {
  stopServer();
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');

    const $ = cheerio.load(response.text);

    // Check for all required fields
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('input[name="phone"]')).toHaveLength(1);

    // Check labels are associated with inputs
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="email"]')).toHaveLength(1);
    expect($('label[for="phone"]')).toHaveLength(1);
  });

  it('shows validation errors for empty submission', async () => {
    const response = await request(app).post('/submit').send({
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('First name is required');
    expect(response.text).toContain('Email is required');
  });

  it('shows validation error for invalid email', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'UK',
      email: 'not-an-email',
      phone: '+44 20 7946 0958',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('valid email address');
  });

  it('accepts international phone formats', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'Maria',
      lastName: 'Gonzalez',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria@example.com',
      phone: '+54 9 11 1234-5678',
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
  });

  it('accepts alphanumeric postal codes', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '10 Downing Street',
      city: 'Westminster',
      stateProvince: 'London',
      postalCode: 'SW1A 2AA',
      country: 'United Kingdom',
      email: 'jane@example.com',
      phone: '+44 20 7946 0958',
    });

    expect(response.status).toBe(302);
  });

  it('persists submission and redirects to thank-you page', async () => {
    // Clear database before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(app).post('/submit').send({
      firstName: 'Alice',
      lastName: 'Johnson',
      streetAddress: '456 Oak Avenue',
      city: 'Sydney',
      stateProvince: 'NSW',
      postalCode: '2000',
      country: 'Australia',
      email: 'alice@example.com',
      phone: '+61 2 9876 5432',
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toContain('/thank-you');
    expect(response.headers.location).toContain('firstName=Alice');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);

    // Follow redirect to thank-you page
    const thankYouResponse = await request(app).get(response.headers.location);
    expect(thankYouResponse.status).toBe(200);
    expect(thankYouResponse.text).toContain('Thank you, Alice!');
    expect(thankYouResponse.text).toContain('stranger on the internet');
  });

  it('preserves form values on validation error', async () => {
    const response = await request(app).post('/submit').send({
      firstName: 'Bob',
      lastName: 'Brown',
      streetAddress: '789 Pine Rd',
      city: 'Toronto',
      stateProvince: 'Ontario',
      postalCode: 'M5V 1A1',
      country: 'Canada',
      email: 'invalid-email',
      phone: '+1 416-555-0123',
    });

    expect(response.status).toBe(400);
    expect(response.text).toContain('Bob');
    expect(response.text).toContain('invalid-email');
  });

  it('thank-you page links back to form', async () => {
    const response = await request(app).get('/thank-you?firstName=Test');
    expect(response.status).toBe(200);
    expect(response.text).toContain('href="/"');
  });
});
