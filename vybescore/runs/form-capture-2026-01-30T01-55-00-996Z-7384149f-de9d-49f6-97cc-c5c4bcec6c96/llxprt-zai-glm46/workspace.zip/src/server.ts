import express, { type Request, type Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { type Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Configure EJS views directory
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));
app.set('view engine', 'ejs');

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and optional leading +
  const phoneRegex = /^[+]?[\d\s()/-]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings with spaces and dashes
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim().length === 0) {
    errors.push('First name is required');
  }

  if (!data.lastName || data.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }

  if (!data.streetAddress || data.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }

  if (!data.city || data.city.trim().length === 0) {
    errors.push('City is required');
  }

  if (!data.stateProvince || data.stateProvince.trim().length === 0) {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode || data.postalCode.trim().length === 0) {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal code must contain only letters, digits, and spaces');
  }

  if (!data.country || data.country.trim().length === 0) {
    errors.push('Country is required');
  }

  if (!data.email || data.email.trim().length === 0) {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }

  if (!data.phone || data.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and optional leading +');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}

// Initialize database
async function initializeDatabase(): Promise<Database> {
  try {
    const SQL = await initSqlJs();
    let database: Database;

    // Create data directory if it doesn't exist
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create new one
    if (fs.existsSync(DB_PATH)) {
      const buffer = fs.readFileSync(DB_PATH);
      database = new SQL.Database(buffer);
    } else {
      database = new SQL.Database();
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      database.run(schema);
      saveDatabase(database);
    }

    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(database: Database): void {
  const data = database.export();
  const buffer = Buffer.from(data);
  fs.writeFileSync(DB_PATH, buffer);
}

// Routes
app.get('/', (_req: Request, res: Response) => {
  res.render('form.ejs', {
    errors: [],
    values: {},
  });
})

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form.ejs', {
      errors: validation.errors,
      values: formData,
    });
  }

  // Insert into database
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();
    saveDatabase(db);

    // Redirect to thank-you page with first name
    return res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Database error:', error);
    return res.status(500).render('form.ejs', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData,
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you.ejs', { firstName });
});

// Error handling
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).render('form.ejs', {
    errors: ['An unexpected error occurred. Please try again.'],
    values: {},
  });
});

// Server lifecycle
let server: ReturnType<typeof app.listen> | null = null;

export async function startServer(): Promise<void> {
  db = await initializeDatabase();
  console.log('Database initialized successfully');

  return new Promise((resolve) => {
    server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
      resolve();
    });
  });
}

export function stopServer(): void {
  if (server) {
    server.close(() => {
      if (db) {
        db.close();
        db = null;
      }
      console.log('Server stopped gracefully');
    });
  }
}

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  stopServer();
  process.exit(0);
});

process.on('SIGINT', () => {
  console.log('SIGINT received, shutting down gracefully...');
  stopServer();
  process.exit(0);
});

// Start server if run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch((error) => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, db };
export default startServer;
