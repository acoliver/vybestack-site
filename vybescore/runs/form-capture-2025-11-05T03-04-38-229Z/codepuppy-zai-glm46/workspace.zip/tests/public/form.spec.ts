import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import FormServer from '../../src/server.js';
import express from 'express';

let server: FormServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Set test port to avoid conflicts
  process.env.PORT = '0'; // Let OS assign random port
  
  // Create and start the server
  server = new FormServer();
  await server.start();
  
  // Get the Express app for testing
  app = server.expressApp;
});

afterAll(async () => {
  if (server) {
    await server.stop();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toMatch(/text\/html/);
    
    const $ = cheerio.load(response.text || '');
    
    // Check that all required fields are present
    expect($('input#firstName')).toHaveLength(1);
    expect($('input#lastName')).toHaveLength(1);
    expect($('input#streetAddress')).toHaveLength(1);
    expect($('input#city')).toHaveLength(1);
    expect($('input#stateProvince')).toHaveLength(1);
    expect($('input#postalCode')).toHaveLength(1);
    expect($('input#country')).toHaveLength(1);
    expect($('input#email')).toHaveLength(1);
    expect($('input#phone')).toHaveLength(1);
    
    // Check form attributes
    expect($('form[method="post"][action="/submit"]')).toHaveLength(1);
    
    // Check that labels are properly associated
    expect($('label[for="firstName"]')).toHaveLength(1);
    expect($('label[for="lastName"]')).toHaveLength(1);
    
    // Check names are correct
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('input[name="lastName"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Make sure database doesn't exist before test
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Check that database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Query the database to verify data was inserted
    // Since we're using sql.js, we need to read it the same way
    const initSqlJs = async () => {
      const sql = await import('sql.js');
      return sql;
    };
    
    const SQL = await initSqlJs();
    const fileBuffer = fs.readFileSync(dbPath);
    const db = new SQL.Database(fileBuffer);
    
    const stmt = db.prepare('SELECT * FROM submissions');
    const results = [];
    while (stmt.step()) {
      results.push(stmt.getAsObject());
    }
    stmt.free();
    db.close();
    
    expect(results).toBeDefined();
    expect(results.length).toBeGreaterThan(0);
    expect(results[0].first_name).toBe('John');
    expect(results[0].last_name).toBe('Doe');
    expect(results[0].email).toBe('john.doe@example.com');
  });
});
