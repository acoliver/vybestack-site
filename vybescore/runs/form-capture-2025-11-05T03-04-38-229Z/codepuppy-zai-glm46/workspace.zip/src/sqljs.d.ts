declare module 'sql.js' {
  class Database {
    constructor(data?: ArrayBuffer);
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }
  
  class Statement {
    run(...params: unknown[]): void;
    step(): boolean;
    getAsObject(): Record<string, unknown>;
    free(): void;
  }
  
  interface SqlJsStatic {
    Database: typeof Database;
    Statement: typeof Statement;
  }
  
  function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<SqlJsStatic>;
  
  export default initSqlJs;
  export { Database, Statement };
}