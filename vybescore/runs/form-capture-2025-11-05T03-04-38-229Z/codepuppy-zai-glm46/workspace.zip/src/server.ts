import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
/// <reference path="./sqljs.d.ts" /> // Reference type declarations

// Import sql.js as ESM module
import initSqlJs from 'sql.js';

type SqlJsModule = {
  Database: new (data?: ArrayBuffer) => {
    run(sql: string, ...params: unknown[]): void;
    prepare(sql: string): {
      run(...params: unknown[]): void;
      step(): boolean;
      getAsObject(): Record<string, unknown>;
      free(): void;
    };
    export(): Uint8Array;
    close(): void;
  };
};

// Type definitions for form data
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

type Database = InstanceType<SqlJsModule['Database']>;

class FormServer {
  private app: express.Application;
  private server: ReturnType<express.Application['listen']> | undefined;
  private db: Database | undefined;
  private SQL: SqlJsModule | undefined;
  private dbPath: string;

  constructor() {
    this.app = express();
    this.dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
  }

  private setupMiddleware(): void {
    // Parse URL-encoded bodies (as sent by HTML forms)
    this.app.use(express.urlencoded({ extended: true }));
    
    // Serve static files from public directory
    this.app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));
    
    // Set EJS as the view engine
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.resolve(__dirname, 'templates'));
  }

  private validateFormData(data: FormData): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    if (!data.firstName?.trim()) {
      errors.push({ field: 'firstName', message: 'First name is required' });
    }
    if (!data.lastName?.trim()) {
      errors.push({ field: 'lastName', message: 'Last name is required' });
    }
    if (!data.streetAddress?.trim()) {
      errors.push({ field: 'streetAddress', message: 'Street address is required' });
    }
    if (!data.city?.trim()) {
      errors.push({ field: 'city', message: 'City is required' });
    }
    if (!data.stateProvince?.trim()) {
      errors.push({ field: 'stateProvince', message: 'State / Province / Region is required' });
    }
    if (!data.postalCode?.trim()) {
      errors.push({ field: 'postalCode', message: 'Postal / Zip code is required' });
    }
    if (!data.country?.trim()) {
      errors.push({ field: 'country', message: 'Country is required' });
    }
    if (!data.email?.trim()) {
      errors.push({ field: 'email', message: 'Email is required' });
    }
    if (!data.phone?.trim()) {
      errors.push({ field: 'phone', message: 'Phone number is required' });
    }

    // Email validation (simple regex)
    if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
      errors.push({ field: 'email', message: 'Please enter a valid email address' });
    }

    // Phone number validation (international formats allowed)
    if (data.phone && !/^[+]?[\d\s\-()]+$/.test(data.phone)) {
      errors.push({ field: 'phone', message: 'Phone number can only contain digits, spaces, dashes, parentheses, and a leading +' });
    }

    // Postal code validation (alphanumeric)
    if (data.postalCode && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
      errors.push({ field: 'postalCode', message: 'Postal code can only contain letters, numbers, spaces, and dashes' });
    }

    return errors;
  }

  private async initializeDatabase(): Promise<void> {
    const sqlModule = await initSqlJs();
    this.SQL = sqlModule;
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load database file if it exists, otherwise create new database
    if (fs.existsSync(this.dbPath)) {
      const fileBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.SQL!.Database(fileBuffer.buffer);
    } else {
      this.db = new this.SQL!.Database();
      // Create schema from the provided SQL file
      const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf8');
      this.db!.run(schemaSql);
      this.saveDatabase();
    }
  }

  private saveDatabase(): void {
    const data = this.db!.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(this.dbPath, buffer);
  }

  public get expressApp(): express.Application {
    return this.app;
  }

  private setupRoutes(): void {
    // GET / - Render the form
    this.app.get('/', (req: Request, res: Response) => {
      res.render('form', {
        errors: [],
        values: {}
      });
    });

    // POST /submit - Handle form submission
    this.app.post('/submit', async (req: Request, res: Response) => {
      console.log('Received body:', req.body);
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };
      console.log('Form data:', formData);

      const errors = this.validateFormData(formData);

      if (errors.length > 0) {
        // Validation failed, re-render form with errors and existing values
        res.status(400);
        const errorMessages = errors.map(error => error.message);
        return res.render('form', {
          errors: errorMessages,
          values: formData
        });
      }

      try {
        // Insert into database
        const stmt = this.db!.prepare(`
          INSERT INTO submissions (
            first_name, last_name, street_address, city, 
            state_province, postal_code, country, email, phone
          ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `);
        
        console.log('About to insert with data:', formData);
        stmt.run(
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        );
        stmt.free();
        console.log('Database insert successful');

        // Save database to disk
        this.saveDatabase();

        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Database error:', error);
        res.status(500);
        return res.render('form', {
          errors: ['Something went wrong. Please try again.'],
          values: formData
        });
      }
    });

    // GET /thank-you - Render thank you page
    this.app.get('/thank-you', (req: Request, res: Response) => {
      // For simplicity, we'll use a generic greeting since we don't have session data
      // In a real app, you might use sessions or query parameters
      res.render('thank-you', {
        firstName: 'Friend' // Default greeting
      });
    });
  }

  public async start(): Promise<void> {
    await this.initializeDatabase();
    
    const port = process.env.PORT || 3000;
    this.server = this.app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  }

  public async stop(): Promise<void> {
    if (this.server) {
      this.server.close();
    }
    if (this.db) {
      this.db.close();
    }
  }
}

// Start the server
const formServer = new FormServer();
formServer.start().catch(console.error);

// Handle graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  await formServer.stop();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  await formServer.stop();
  process.exit(0);
});

// Export for testing
export default FormServer;