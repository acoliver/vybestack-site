import type { Formatter, ReportData, RenderOptions } from '../types.js';

export const renderMarkdown: Formatter['render'] = (
  data: ReportData,
  options: RenderOptions,
) => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;
  
  const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
  
  let output = '';
  
  // Title
  output += `# ${title}\n\n`;
  
  // Summary
  output += `${summary}\n\n`;
  
  // Entries
  output += `## Entries\n`;
  
  for (const entry of entries) {
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  }
  
  // Optional total
  if (includeTotals) {
    output += `\n**Total:** $${total.toFixed(2)}`;
  }
  
  return output;
};