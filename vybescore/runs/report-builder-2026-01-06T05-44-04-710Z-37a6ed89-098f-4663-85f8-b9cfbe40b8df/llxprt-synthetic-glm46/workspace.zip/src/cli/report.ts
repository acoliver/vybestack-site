#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const inputFile = args[0];
  
  let format: 'markdown' | 'text' | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 1; i < args.length; i++) {
    if (args[i] === '--format' && i + 1 < args.length) {
      format = args[i + 1] as 'markdown' | 'text';
      i++; // Skip the next argument
    } else if (args[i] === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (args[i] === '--includeTotals') {
      includeTotals = true;
    }
  }
  
  if (!format) {
    console.error('Error: --format is required and must be "markdown" or "text"');
    process.exit(1);
  }
  
  if (format !== 'markdown' && format !== 'text') {
    console.error(`Error: Unsupported format: ${format}`);
    process.exit(1);
  }
  
  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: Expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: "title" is required and must be a string');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: "summary" is required and must be a string');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: "entries" is required and must be an array');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: "label" is required and must be a string`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: "amount" is required and must be a number`);
    }
  }
  
  return obj as unknown as ReportData;
}

function loadData(filePath: string): ReportData {
  try {
    const fileContent = readFileSync(filePath, 'utf8');
    const data = JSON.parse(fileContent);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON in file "${filePath}": ${error.message}`);
      process.exit(1);
    } else if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      console.error(`Error: File not found: "${filePath}"`);
      process.exit(1);
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
      process.exit(1);
    } else {
      console.error(`Unknown error: ${error}`);
      process.exit(1);
    }
  }
}

function renderReport(data: ReportData, format: 'markdown' | 'text', includeTotals: boolean): string {
  if (format === 'markdown') {
    return renderMarkdown(data, { includeTotals });
  } else {
    return renderText(data, { includeTotals });
  }
}

function outputReport(content: string, outputPath?: string): void {
  if (outputPath) {
    writeFileSync(outputPath, content);
    console.log(`Report written to: ${outputPath}`);
  } else {
    console.log(content);
  }
}

function main(): void {
  try {
    const { inputFile, format, outputPath, includeTotals } = parseArgs();
    
    const data = loadData(inputFile);
    const report = renderReport(data, format, includeTotals);
    
    outputReport(report, outputPath);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
