module.exports = {
  root: true,
  env: {
    es2022: true,
    node: true
  },
  extends: [
    'eslint:recommended'
  ],
  parser: '@typescript-eslint/parser',
  parserOptions: {
    ecmaVersion: 2022,
    sourceType: 'module'
  },
  plugins: ['@typescript-eslint'],
  rules: {
    'prefer-const': 'error',
    'no-var': 'error'
  },
  ignorePatterns: ['dist/**/*', 'node_modules/**/*']
};