import express, { Request, Response, NextFunction } from 'express';
import * as path from 'path';
import DatabaseManager from './database';
import { validateContactForm, ContactFormData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Database manager instance
let dbManager: DatabaseManager;

// Initialize database
async function initializeDatabase(): Promise<void> {
  dbManager = new DatabaseManager();
  await dbManager.initialize();
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.status(200).render('contact-form', {
    title: 'Contact Us',
    errors: [],
    data: {}
  });
});

app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: Partial<ContactFormData> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvinceRegion: req.body.stateProvinceRegion,
      postalZipCode: req.body.postalZipCode,
      country: req.body.country,
      email: req.body.email,
      phoneNumber: req.body.phoneNumber
    };

    const validation = validateContactForm(formData);

    if (!validation.isValid) {
      return res.status(400).render('contact-form', {
        title: 'Contact Us - Please Fix Errors',
        errors: validation.errors,
        data: validation.data
      });
    }

    // Valid submission - save to database
    const submissionData: ContactFormData = validation.data as ContactFormData;
    await dbManager.insertSubmission(submissionData);

    // Redirect to thank-you page
    res.redirect(302, '/thank-you');

  } catch (error) {
    next(error);
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.status(200).render('thank-you', {
    title: 'Thank You!'
  });
});

// Error handler
app.use((err: Error, req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Something went wrong!');
});

// Graceful shutdown
async function gracefulShutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  
  if (dbManager) {
    await dbManager.close();
  }
  
  process.exit(0);
}

// Setup signal handlers for graceful shutdown
process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer(): Promise<void> {
  try {
    await initializeDatabase();
    
    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    // Handle server shutdown
    process.on('SIGTERM', () => {
      console.log('Received SIGTERM, shutting down gracefully...');
      server.close(gracefulShutdown);
    });

    process.on('SIGINT', () => {
      console.log('Received SIGINT, shutting down gracefully...');
      server.close(gracefulShutdown);
    });

  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
