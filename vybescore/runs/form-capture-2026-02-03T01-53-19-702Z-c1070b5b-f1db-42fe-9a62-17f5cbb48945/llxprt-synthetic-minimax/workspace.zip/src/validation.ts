export interface ContactFormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  data: Partial<ContactFormData>;
}

export function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

export function validatePhoneNumber(phone: string): boolean {
  // Accept international formats with +, digits, spaces, parentheses, dashes
  const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
  return phoneRegex.test(phone);
}

export function validatePostalCode(postalCode: string): boolean {
  // Accept alphanumeric strings of reasonable length
  const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
  return postalRegex.test(postalCode);
}

export function validateContactForm(data: Partial<ContactFormData>): ValidationResult {
  const errors: ValidationError[] = [];
  const result: ValidationResult = {
    isValid: true,
    errors: [],
    data: {}
  };

  // Required field validation
  const requiredFields: (keyof ContactFormData)[] = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvinceRegion', 'postalZipCode', 'country', 'email', 'phoneNumber'
  ];

  requiredFields.forEach(field => {
    const value = data[field];
    if (!value || value.trim() === '') {
      errors.push({
        field: field,
        message: `${field.replace(/([A-Z])/g, ' $1').toLowerCase()} is required`
      });
    } else {
      result.data[field] = value.trim();
    }
  });

  // Email validation
  if (data.email) {
    if (!validateEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone validation
  if (data.phoneNumber) {
    if (!validatePhoneNumber(data.phoneNumber)) {
      errors.push({
        field: 'phoneNumber',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation
  if (data.postalZipCode) {
    if (!validatePostalCode(data.postalZipCode)) {
      errors.push({
        field: 'postalZipCode',
        message: 'Please enter a valid postal code'
      });
    }
  }

  result.isValid = errors.length === 0;
  result.errors = errors;

  return result;
}