/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  notifyObservers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Wrap the updateFn to notify observers after update
  const wrappedUpdateFn: UpdateFn<T> = (prevValue?: T) => {
    const newValue = updateFn(prevValue)
    // Only notify if value actually changed
    if (newValue !== o.value) {
      notifyObservers(o.observers)
    }
    return newValue
  }
  o.updateFn = wrappedUpdateFn
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      o.observers.add(observer)
    }
    return o.value as T
  }
  
  return read
}
