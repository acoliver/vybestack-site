#!/usr/bin/env node

import fs from 'fs';
import { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

function parseArgs(): { dataFile: string; format: string; output?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1];

  const outputIndex = args.indexOf('--output');
  const output = outputIndex !== -1 && outputIndex !== args.length - 1 ? args[outputIndex + 1] : undefined;

  const includeTotals = args.includes('--includeTotals');

  return { dataFile, format, output, includeTotals };
}

function validateData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field`);
    }

    if (typeof entryObj.amount !== 'number' || isNaN(entryObj.amount)) {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field`);
    }
  }

  return data as ReportData;
}

function main() {
  try {
    const { dataFile, format, output, includeTotals } = parseArgs();

    // Read and parse JSON
    let data;
    try {
      const fileContent = fs.readFileSync(dataFile, 'utf8');
      data = JSON.parse(fileContent);
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error reading file ${dataFile}: ${error.message}`);
      } else {
        console.error(`Error reading file ${dataFile}: Unknown error`);
      }
      process.exit(1);
    }

    // Validate data
    const reportData = validateData(data);

    // Generate report based on format
    let result: string;
    if (format === 'markdown') {
      result = renderMarkdown(reportData, includeTotals);
    } else if (format === 'text') {
      result = renderText(reportData, includeTotals);
    } else {
      console.error(`Unsupported format: ${format}`);
      process.exit(1);
    }

    // Output result
    if (output) {
      try {
        fs.writeFileSync(output, result, 'utf8');
      } catch (error) {
        if (error instanceof Error) {
          console.error(`Error writing to file ${output}: ${error.message}`);
        } else {
          console.error(`Error writing to file ${output}: Unknown error`);
        }
        process.exit(1);
      }
    } else {
      console.log(result);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Unknown error occurred');
    }
    process.exit(1);
  }
}

main();