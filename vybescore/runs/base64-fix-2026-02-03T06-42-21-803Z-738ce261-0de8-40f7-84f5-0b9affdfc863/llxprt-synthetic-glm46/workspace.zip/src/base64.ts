/**
 * Encode plain text to Base64.
 * Uses the standard Base64 alphabet with padding as required by the specification.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Handles standard Base64 input with or without padding and validates input.
 */
export function decode(input: string): string {
  // Check for invalid Base64 characters (only A-Z, a-z, 0-9, +, /, = are allowed)
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains illegal characters');
  }

  // Check for incorrect padding (padding can only appear at the end)
  if (input.includes('=') && !/={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }

  try {
    return Buffer.from(input, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
