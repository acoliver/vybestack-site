/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern for words starting with the prefix
  const pattern = new RegExp(`\\b${prefix}\\w*\\b`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  return matches.filter(match => 
    !exceptionsLower.includes(match.toLowerCase())
  );
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find all occurrences of the token with their positions
  const results: string[] = [];
  const regex = new RegExp(token, 'gi');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    const startPos = match.index;
    
    // Must not be at start of string
    if (startPos === 0) continue;
    
    // Must be preceded by a digit
    if (startPos > 0 && /\d/.test(text[startPos - 1])) {
      // Include the digit and the token in the result
      const fullMatch = text[startPos - 1] + token;
      results.push(fullMatch);
    }
  }
  
  return results;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check no whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Check for at least one symbol
  if (!/[!@#$%^&*()_+\-={}[\]|:;"'<>,.?/]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  if (/(..).*\1/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, exclude IPv4 addresses (they should not trigger IPv6 detection)
  const ipv4Regex = /\b(\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Use a comprehensive IPv6 pattern that looks for hex digits and colons
  const ipv6Pattern = /\b(?:[a-f0-9]{0,4}:){2,7}[a-f0-9]{0,4}\b/i;
  
  // Also check for double colon compression
  const doubleColonPattern = /\b[a-f0-9]*::[a-f0-9]*\b/i;
  
  // Check if the string contains any IPv6-like patterns
  return ipv6Pattern.test(value) || doubleColonPattern.test(value);
}
