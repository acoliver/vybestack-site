/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Handle basic sentence ending patterns: ., !, ?
  // Use regex to find sentence boundaries and capitalize following characters
  return text.replace(
    /([.!?]\s*)(\w)/g,
    (match, separator, firstChar) => {
      return separator + firstChar.toUpperCase();
    }
  ).replace(
    /(^|\.\s+)(\w)/g,
    (match, start, firstChar) => {
      return start + firstChar.toUpperCase();
    }
  );
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Pattern for matching URLs with common schemes
  const urlRegex = /\bhttps?:\/\/[^\s<>"]+|www\.[^\s<>"]+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs
  const urlRegex = /http:\/\/([^/\s]+)(\/[^\s]*)/gi;
  
  return text.replace(urlRegex, (match, domain, path) => {
    // Check if path begins with /docs/
    const beginsWithDocs = path.startsWith('/docs/');
    
    // Check for dynamic hints that should prevent host rewrite
    const hasDynamicHints = /(\?|&|=|cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py))/.test(path);
    
    let newDomain = domain;
    
    // Only rewrite host if it's a docs path without dynamic hints
    if (beginsWithDocs && !hasDynamicHints) {
      newDomain = `docs.${domain}`;
    }
    
    // Always upgrade to https
    return `https://${newDomain}${path}`;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  
  const match = value.match(dateRegex);
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day (1-31, simple validation)
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}