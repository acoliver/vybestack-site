export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation pattern
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Reject double dots anywhere
  if (value.includes('..')) {
    return false;
  }
  
  // Reject trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // Check domain parts don't have underscores
  const parts = value.split('@');
  if (parts.length !== 2) return false;
  
  const domainParts = parts[1].split('.');
  for (const part of domainParts) {
    if (part.includes('_')) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digits except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Basic length check - should be 10-11 digits
  const digits = cleaned.replace(/\D/g, '');
  
  // Too short
  if (digits.length < 10 || digits.length > 11) {
    return false;
  }
  
  // Handle country code
  let number = digits;
  if (cleaned.startsWith('+1') && digits.length === 11) {
    number = digits.substring(1); // Remove country code
  } else if (digits.length === 11 && !cleaned.startsWith('+1')) {
    return false; // 11 digits without +1 prefix
  }
  
  // Check area code (first 3 digits) - cannot start with 0 or 1
  const areaCode = number.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate format using regex
  const phoneRegex = /^\+?1?[\s.-]?\(?([2-9]\d{2})\)?[\s.-]?([2-9]\d{2})[\s.-]?(\d{4})$/;
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all non-alphanumeric characters except +, 0-9
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Pattern explanation:
  // ^\+54?: optional country code +54
  // 9?: optional mobile indicator
  // 0?: optional trunk prefix (when no country code)
  // [1-9]\d{1,3}: area code (2-4 digits, first digit 1-9)
  // \d{6,8}: subscriber number (6-8 digits total)
  const argentinePhoneRegex = /^(\+54)?(9)?(0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const hasCountryCode = !!match[1];
  const hasMobileIndicator = !!match[2];
  const hasTrunkPrefix = !!match[3];
  const areaCode = match[4];
  const subscriberNumber = match[5];
  
  // Validation rules:
  // 1. If country code is present, mobile indicator can be present or not (both valid)
  // 2. If country code is absent, trunk prefix must be present
  // 3. Mobile indicator should only appear with country code
  if (!hasCountryCode && !hasTrunkPrefix) {
    return false;
  }
  
  if (hasMobileIndicator && !hasCountryCode) {
    return false;
  }
  
  // Area code validation: 2-4 digits, first digit 1-9
  if (areaCode.length < 2 || areaCode.length > 4) {
    return false;
  }
  
  // Subscriber number should be 6-8 digits total (not counting area code)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  if (!value || value.trim().length === 0) {
    return false;
  }
  
  // Allow unicode letters, spaces, apostrophes, hyphens, and accents
  // Reject digits, symbols, and special characters like X Æ A-12
  // Pattern explanation:
  // ^[^\d]+$ - starts with non-digit and entire string must be non-digit
  // [^\d] allows: unicode letters, spaces, apostrophes, hyphens, accents
  const nameRegex = /^[^\d]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check for obviously fake names (like "X Æ A-12")
  const fakePatterns = /[^a-zA-ZÀ-ÿ\s'-]/;
  if (fakePatterns.test(value)) {
    return false;
  }
  
  // Must have at least one letter
  if (!/[a-zA-ZÀ-ÿ]/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function for Luhn algorithm
 */
function runLuhnCheck(number: string): boolean {
  const digits = number.replace(/\D/g, '').split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  // Process from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digits
  const digits = value.replace(/\D/g, '');
  
  // Check length (13-19 digits typical range)
  if (digits.length < 13 || digits.length > 19) {
    return false;
  }
  
  // Check for common credit card prefixes
  // Visa: starts with 4, length 13, 16, or 19
  const isVisa = /^4/.test(digits) && (digits.length === 13 || digits.length === 16 || digits.length === 19);
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const isMastercard = /^(5[1-5]|2[2-7])/.test(digits) && digits.length === 16;
  
  // American Express: starts with 34 or 37, length 15
  const isAmEx = /^(34|37)/.test(digits) && digits.length === 15;
  
  // Discover: starts with 6011, 622126-622925, 644-649, or 65, length 16-19
  const isDiscover = /^(6011|622[1-9][2-9][0-9]|622[3-9][0-9]{2}|622[4-9][0-9]{3}|64[4-9][0-9]{2}|65)/.test(digits) && 
                     (digits.length === 16 || digits.length === 19);
  
  // If none of the common patterns match, reject
  if (!isVisa && !isMastercard && !isAmEx && !isDiscover) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
