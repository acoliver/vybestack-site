import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

let server: {
  close: () => void;
} | null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // placeholder - tests will be updated once server is stable
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});
