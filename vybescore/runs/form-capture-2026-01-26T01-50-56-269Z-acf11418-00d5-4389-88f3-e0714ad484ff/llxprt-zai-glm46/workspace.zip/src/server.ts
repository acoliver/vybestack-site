import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const DB_PATH = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

let db: Database | null = null;
const app = express();
const PORT = process.env.PORT || 3535;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

app.set('view engine', 'ejs');
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  return phoneRegex.test(phone) && phone.trim().length > 0;
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length > 0;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  if (!data.firstName?.trim()) {
    errors.push({ field: 'firstName', message: 'First name is required.' });
  }
  if (!data.lastName?.trim()) {
    errors.push({ field: 'lastName', message: 'Last name is required.' });
  }
  if (!data.streetAddress?.trim()) {
    errors.push({ field: 'streetAddress', message: 'Street address is required.' });
  }
  if (!data.city?.trim()) {
    errors.push({ field: 'city', message: 'City is required.' });
  }
  if (!data.stateProvince?.trim()) {
    errors.push({ field: 'stateProvince', message: 'State / Province / Region is required.' });
  }
  if (!data.postalCode?.trim()) {
    errors.push({ field: 'postalCode', message: 'Postal / Zip code is required.' });
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Postal code must contain only letters, numbers, spaces, and hyphens.',
    });
  }
  if (!data.country?.trim()) {
    errors.push({ field: 'country', message: 'Country is required.' });
  }
  if (!data.email?.trim()) {
    errors.push({ field: 'email', message: 'Email is required.' });
  } else if (!validateEmail(data.email)) {
    errors.push({ field: 'email', message: 'Please enter a valid email address.' });
  }
  if (!data.phone?.trim()) {
    errors.push({ field: 'phone', message: 'Phone number is required.' });
  } else if (!validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Phone number may contain digits, spaces, parentheses, dashes, and a leading +.',
    });
  }

  return errors;
}

async function initializeDatabase(): Promise<Database> {
  const SQL = await initSqlJs();

  let dbInstance: Database;
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    dbInstance = new SQL.Database(buffer);
  } else {
    dbInstance = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    dbInstance.run(schema);
    saveDatabase(dbInstance);
  }

  return dbInstance;
}

function saveDatabase(dbInstance: Database): void {
  const data = dbInstance.export();
  const buffer = Buffer.from(data);
  const dir = path.dirname(DB_PATH);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }
  fs.writeFileSync(DB_PATH, buffer);
}

app.get('/', (_req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {
      firstName: '',
      lastName: '',
      streetAddress: '',
      city: '',
      stateProvince: '',
      postalCode: '',
      country: '',
      email: '',
      phone: '',
    },
  });
})

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    const errorMessages = errors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
    return;
  }

  if (!db) {
    res.status(500).send('Database not initialized');
    return;
  }

  try {
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );

    saveDatabase(db);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('An error occurred while saving your submission.');
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  res.render('thank-you', {
    firstName: 'Friend',
  });
});

app.use((_req: Request, _res: Response, next: NextFunction) => {
  next();
});

async function startServer(): Promise<void> {
  try {
    db = await initializeDatabase();
    console.log('Database initialized');

    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });

    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully...');
      server.close(() => {
        if (db) {
          db.close();
          console.log('Database closed');
        }
        process.exit(0);
      });
    });

    process.on('SIGINT', () => {
      console.log('SIGINT received, shutting down gracefully...');
      server.close(() => {
        if (db) {
          db.close();
          console.log('Database closed');
        }
        process.exit(0);
      });
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export { app, db };
