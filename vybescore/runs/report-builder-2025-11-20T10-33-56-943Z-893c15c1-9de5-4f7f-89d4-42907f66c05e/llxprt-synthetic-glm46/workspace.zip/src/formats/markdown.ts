import type { ReportData, ReportRenderer, FormatOptions } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderMarkdown: ReportRenderer = (
  data: ReportData,
  options: FormatOptions
): string => {
  let result = '';

  result += `# ${data.title}\n\n`;
  result += `${data.summary}\n\n`;

  result += '## Entries\n';
  for (const entry of data.entries) {
    result += `- **${entry.label}** — ${formatAmount(entry.amount)}\n`;
  }

  if (options.includeTotals) {
    result += `**Total:** ${formatAmount(calculateTotal(data.entries))}\n`;
  }

  return result;
};