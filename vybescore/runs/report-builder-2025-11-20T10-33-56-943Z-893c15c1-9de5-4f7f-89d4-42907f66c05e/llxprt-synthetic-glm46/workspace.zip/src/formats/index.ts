import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import type { ReportRenderer } from '../types.js';

export const formatters = new Map<string, ReportRenderer>([
  ['markdown', renderMarkdown],
  ['text', renderText],
]);

export type SupportedFormat = 'markdown' | 'text';