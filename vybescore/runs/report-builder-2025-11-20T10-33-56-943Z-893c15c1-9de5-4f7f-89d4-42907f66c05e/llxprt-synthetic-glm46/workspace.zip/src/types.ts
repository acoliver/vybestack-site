export type ReportEntry = {
  label: string;
  amount: number;
};

export type ReportData = {
  title: string;
  summary: string;
  entries: ReportEntry[];
};

export type FormatOptions = {
  includeTotals: boolean;
};

export type ReportRenderer = (
  data: ReportData,
  options: FormatOptions
) => string;