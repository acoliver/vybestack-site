#!/usr/bin/env node

import { readFile, writeFile } from 'node:fs';
import { resolve } from 'node:path';
import type { ReportData, FormatOptions } from '../types.js';
import { formatters, SupportedFormat } from '../formats/index.js';

function parseArgs(): {
  inputFile: string;
  format: SupportedFormat;
  outputPath: string | undefined;
  options: FormatOptions;
} {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error(
      'Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]'
    );
    process.exit(1);
  }

  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');

  if (formatIndex === -1 || formatIndex + 1 >= args.length) {
    console.error('Missing required --format argument');
    process.exit(1);
  }

  const format = args[formatIndex + 1] as SupportedFormat;

  if (!formatters.has(format)) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  const outputIndex = args.indexOf('--output');
  const outputPath =
    outputIndex !== -1 && outputIndex + 1 < args.length
      ? args[outputIndex + 1]
      : undefined;

  const includeTotals = args.includes('--includeTotals');

  return {
    inputFile,
    format,
    outputPath,
    options: { includeTotals },
  };
}

function validateData(data: unknown): data is ReportData {
  if (
    typeof data !== 'object' ||
    data === null ||
    !('title' in data) ||
    !('summary' in data) ||
    !('entries' in data) ||
    typeof (data as { title: unknown }).title !== 'string' ||
    typeof (data as { summary: unknown }).summary !== 'string' ||
    !Array.isArray((data as { entries: unknown }).entries)
  ) {
    return false;
  }

  const entries = (data as { entries: Array<unknown> }).entries;

  for (const entry of entries) {
    if (
      typeof entry !== 'object' ||
      entry === null ||
      !('label' in entry) ||
      !('amount' in entry) ||
      typeof (entry as { label: unknown }).label !== 'string' ||
      typeof (entry as { amount: unknown }).amount !== 'number'
    ) {
      return false;
    }
  }

  return true;
}

function main(): void {
  try {
    const { inputFile, format, outputPath, options } = parseArgs();

    const filePath = resolve(inputFile);

    readFile(filePath, 'utf8', (readErr, data) => {
      if (readErr) {
        console.error(`Error reading file: ${readErr.message}`);
        process.exit(1);
      }

      try {
        const jsonData = JSON.parse(data);
        
        if (!validateData(jsonData)) {
          console.error(
            'Invalid data format. Expected JSON with title, summary, and entries fields.'
          );
          process.exit(1);
        }

        const reportData = jsonData as ReportData;
        const formatter = formatters.get(format);

        if (!formatter) {
          console.error(`Unknown format: ${format}`);
          process.exit(1);
        }

        const output = formatter(reportData, options);

        if (outputPath) {
          writeFile(outputPath, output, 'utf8', (writeErr) => {
            if (writeErr) {
              console.error(`Error writing to file: ${writeErr.message}`);
              process.exit(1);
            }
          });
        } else {
          console.log(output);
        }
      } catch (parseErr) {
        console.error(
          `Error parsing JSON: ${
            parseErr instanceof Error ? parseErr.message : 'Unknown error'
          }`
        );
        process.exit(1);
      }
    });
  } catch (err) {
    console.error(`Error: ${err instanceof Error ? err.message : 'Unknown error'}`);
    process.exit(1);
  }
}

main();