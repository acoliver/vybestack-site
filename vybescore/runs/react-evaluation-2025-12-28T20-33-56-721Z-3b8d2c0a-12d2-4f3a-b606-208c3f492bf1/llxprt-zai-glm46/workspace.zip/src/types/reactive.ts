/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  disposed?: boolean
  __subjects?: Set<SubjectLike>
}

export type SubjectLike = {
  observers: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    // Clear previous subjects
    if (observer.__subjects) {
      observer.__subjects.forEach((subject) => {
        subject.observers.delete(observer)
      })
      observer.__subjects.clear()
    }
    
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

/**
 * Notify all observers of a subject that they need to update.
 */
export function notifyObservers(subject: SubjectLike): void {
  const observersToUpdate = Array.from(subject.observers).filter(
    (o) => !o.disposed
  )
  observersToUpdate.forEach((observer) => {
    // Observer must have updateFn to be updated
    if ('updateFn' in observer) {
      updateObserver(observer as Observer<unknown>)
    }
  })
}
