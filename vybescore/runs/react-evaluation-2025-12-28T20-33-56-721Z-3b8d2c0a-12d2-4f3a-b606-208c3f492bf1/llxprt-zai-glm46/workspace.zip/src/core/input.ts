/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ObserverR,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Default equality function using Object.is.
 */
function defaultEqual<T>(lhs: T, rhs: T): boolean {
  return Object.is(lhs, rhs)
}

/**
 * Check if an observer is disposed (has a disposed flag).
 */
function isDisposed(observer: ObserverR): boolean {
  return observer.disposed === true
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined =
    equal === true ? defaultEqual : equal === false ? undefined : equal

  const s: Subject<T> = {
    name: options?.name,
    observers: new Set<ObserverR>(),
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !isDisposed(observer)) {
      s.observers.add(observer)
      // Register this subject with the observer
      if (!observer.__subjects) {
        observer.__subjects = new Set()
      }
      observer.__subjects.add(s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const hasChanged = !equalFn || !equalFn(s.value, nextValue)
    if (hasChanged) {
      s.value = nextValue
      // Notify all observers
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
