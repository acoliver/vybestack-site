/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  ObserverR,
  updateObserver,
  Options,
  getActiveObserver,
  SubjectLike
} from '../types/reactive.js'

/**
 * Check if an observer is disposed.
 */
function isDisposed(observer: ObserverR): boolean {
  return observer.disposed === true
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | ((lhs: T, rhs: T) => boolean),
  options?: Options
): GetterFn<T> {
  // Create a subject-like wrapper for this computed value
  const computedSubject: SubjectLike = {
    observers: new Set<ObserverR>(),
  }

  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    __subjects: new Set(),
  }
  
  // Override updateFn to notify observers after updating
  const originalUpdateFn = updateFn
  o.updateFn = (prevValue?: T) => {
    const newValue = originalUpdateFn(prevValue)
    o.value = newValue
    // Notify all observers of this computed value
    const observersToUpdate = Array.from(computedSubject.observers).filter(
      (obs) => !obs.disposed
    )
    observersToUpdate.forEach((observer) => {
      if ('updateFn' in observer) {
        updateObserver(observer as Observer<unknown>)
      }
    })
    return newValue
  }
  
  // Initial computation
  updateObserver(o)
  
  return (): T => {
    // Register this computed as a dependency of the active observer
    const active = getActiveObserver()
    if (active && !isDisposed(active) && active !== o) {
      // Add this computed to active observer's subjects
      if (!active.__subjects) {
        active.__subjects = new Set()
      }
      active.__subjects.add(computedSubject)
      
      // Register the active observer as an observer of this computed
      computedSubject.observers.add(active)
    }
    return o.value!
  }
}
