/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, ObserverR, updateObserver, UpdateFn, SubjectLike } from '../types/reactive.js'

/**
 * Check if an observer is disposed.
 */
function isDisposed(observer: ObserverR): boolean {
  return observer.disposed === true
}

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    __subjects: new Set(),
  }
  
  // Register observer to track dependencies and execute initial callback
  updateObserver(observer)
  
  return () => {
    if (isDisposed(observer)) return
    observer.disposed = true
    
    // Clear subjects to prevent memory leaks
    if (observer.__subjects) {
      observer.__subjects.forEach((subject: SubjectLike) => {
        subject.observers.delete(observer)
      })
      observer.__subjects.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}
