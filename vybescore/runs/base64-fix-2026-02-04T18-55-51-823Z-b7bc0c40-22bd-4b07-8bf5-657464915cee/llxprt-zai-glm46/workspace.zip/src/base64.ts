const STANDARD_BASE64_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;

/**
 * Validate whether a string is valid Base64.
 * 
 * This function performs several checks:
 * 1. Must match the standard Base64 alphabet
 * 2. Padding must be correct (only at the end, 1-2 chars)
 * 3. When decoded and re-encoded, must produce the same string (after normalizing padding)
 * 
 * Note: We accept unpadded base64 as valid since padding is optional in many contexts.
 */
function isValidBase64(input: string): boolean {
  // Must match the standard Base64 alphabet
  if (!STANDARD_BASE64_REGEX.test(input)) {
    return false;
  }
  
  // Padding validation
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingEnd = input.slice(paddingIndex);
    // Padding must be 1 or 2 '=' characters at the end
    if (!/^={1,2}$/.test(paddingEnd)) {
      return false;
    }
    // If there's padding, the length must be a multiple of 4
    if (input.length % 4 !== 0) {
      return false;
    }
  }
  
  // Additional validation: decode and re-encode to check if the input is truly valid
  // Node.js silently ignores invalid characters, so we need to verify the round-trip
  const decoded = Buffer.from(input, 'base64');
  const reencoded = decoded.toString('base64');
  
  // Remove padding from both for comparison (padding is optional in some contexts)
  const normalizedInput = input.replace(/=+$/, '');
  const normalizedReencoded = reencoded.replace(/=+$/, '');
  
  return normalizedInput === normalizedReencoded;
}

/**
 * Encode plain text to Base64 using the standard alphabet.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Throws an error if the input is not valid Base64.
 */
export function decode(input: string): string {
  const trimmed = input.trim();
  
  // Validate the input before attempting to decode
  if (!isValidBase64(trimmed)) {
    throw new Error('Invalid Base64 input');
  }
  
  try {
    const buffer = Buffer.from(trimmed, 'base64');
    
    // Check if decoding produced valid UTF-8
    return buffer.toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
