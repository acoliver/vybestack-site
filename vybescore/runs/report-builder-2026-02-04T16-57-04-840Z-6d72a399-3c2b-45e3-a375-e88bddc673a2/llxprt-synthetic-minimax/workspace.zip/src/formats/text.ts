import { ReportData, CliOptions } from '../types.js';

export function formatText(data: ReportData, options: CliOptions): string {
  let output = `${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `Entries:\n\n`;
  
  data.entries.forEach(entry => {
    const formattedAmount = formatAmount(entry.amount);
    output += `- ${entry.label}: ${formattedAmount}\n`;
  });
  
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    const formattedTotal = formatAmount(total);
    output += `\nTotal: ${formattedTotal}\n`;
  }
  
  return output;
}

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: { amount: number }[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}