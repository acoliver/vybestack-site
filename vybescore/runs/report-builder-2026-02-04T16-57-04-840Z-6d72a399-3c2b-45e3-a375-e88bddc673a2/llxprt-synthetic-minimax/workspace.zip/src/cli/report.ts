#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, CliOptions } from '../types.js';
import { formatMarkdown } from '../formats/markdown.js';
import { formatText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script name
  const argsArray = argv.slice(2);
  
  let i = 0;
  while (i < argsArray.length) {
    const arg = argsArray[i];
    
    if (arg === '--format' && i + 1 < argsArray.length) {
      args.format = argsArray[i + 1];
      i += 2;
    } else if (arg === '--output' && i + 1 < argsArray.length) {
      args.output = argsArray[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
      i += 1;
    } else if (!arg.startsWith('--')) {
      // This should be the data file
      if (!args.dataFile) {
        args.dataFile = arg;
      }
      i += 1;
    } else {
      i += 1;
    }
  }

  return args;
}

function loadAndValidateData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content);
    
    // Validate required fields
    if (typeof data.title !== 'string' || typeof data.summary !== 'string' || !Array.isArray(data.entries)) {
      throw new Error('Invalid data structure: missing required fields (title, summary, entries)');
    }
    
    // Validate entries
    data.entries.forEach((entry: unknown, index: number) => {
      if (typeof entry !== 'object' || entry === null || 
          typeof (entry as Record<string, unknown>).label !== 'string' || typeof (entry as Record<string, unknown>).amount !== 'number') {
        throw new Error(`Invalid entry at index ${index}: missing required fields (label, amount)`);
      }
    });
    
    return data as ReportData;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON file: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    throw error;
  }
}

function render(data: ReportData, options: CliOptions): string {
  switch (options.format) {
    case 'markdown':
      return formatMarkdown(data, options);
    case 'text':
      return formatText(data, options);
    default:
      throw new Error(`Unsupported format: ${options.format}`);
  }
}

function main(): void {
  try {
    const args = parseArgs(process.argv);
    
    // Validate required arguments
    if (!args.dataFile) {
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
    
    if (!args.format) {
      console.error('Error: --format parameter is required');
      process.exit(1);
    }

    // Load and validate data
    const data = loadAndValidateData(args.dataFile);
    
    // Render report
    const options: CliOptions = {
      format: args.format as 'markdown' | 'text',
      output: args.output,
      includeTotals: args.includeTotals
    };
    
    const output = render(data, options);
    
    // Output to file or stdout
    if (args.output) {
      writeFileSync(args.output, output, 'utf-8');
    } else {
      process.stdout.write(output);
    }
    
  } catch (error) {
    console.error(error instanceof Error ? error.message : 'Unknown error');
    process.exit(1);
  }
}

main();
