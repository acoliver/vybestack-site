/**
 * Encode plain text to Base64 following RFC 4648 standard.
 * Uses the canonical Base64 alphabet (A-Z, a-z, 0-9, +, /) with required '=' padding.
 */
export function encode(input: string): string {
  // Convert UTF-8 string to bytes and encode using standard Base64
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 following RFC 4648 standard.
 * Accepts both padded and unpadded valid Base64 input.
 * Throws an error for clearly invalid Base64 payloads.
 */
export function decode(input: string): string {
  // Validate input contains only Base64 characters
  if (!/^[A-Za-z0-9+/]*={0,2}$/.test(input)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Normalize input: ensure proper padding for Node.js Buffer
  const paddingLength = input.length % 4;
  let normalizedInput = input;
  
  if (paddingLength > 0) {
    normalizedInput = input + '='.repeat(4 - paddingLength);
  }

  try {
    // Verify the decoded result is valid UTF-8
    const decodedBytes = Buffer.from(normalizedInput, 'base64');
    const result = decodedBytes.toString('utf8');
    
    // Check if all bytes were successfully decoded
    if (decodedBytes.length === 0 && normalizedInput.length > 0) {
      throw new Error('Invalid Base64 input: failed to decode');
    }
    
    // Additional validation: re-encode to verify round-trip
    // This catches malformed Base64 that Buffer might silently handle
    const reencoded = Buffer.from(result, 'utf8').toString('base64').replace(/=+$/, '');
    const originalPadless = normalizedInput.replace(/=+$/, '');
    
    if (reencoded !== originalPadless) {
      throw new Error('Invalid Base64 input: malformed data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error && error.message.includes('Invalid Base64 input')) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
