/**
 * Encode plain text to Base64 using standard RFC 4648 Base64 encoding.
 * Includes required padding characters for compatibility with standard Base64 consumers.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts both standard Base64 and URL-safe Base64 variants.
 * Throws error for clearly invalid Base64 input.
 */
export function decode(input: string): string {
  // Support both standard Base64 and URL-safe Base64 variants
  const normalized = input.replace(/-/g, '+').replace(/_/g, '/');

  try {
    return Buffer.from(normalized, 'base64').toString('utf8');
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
