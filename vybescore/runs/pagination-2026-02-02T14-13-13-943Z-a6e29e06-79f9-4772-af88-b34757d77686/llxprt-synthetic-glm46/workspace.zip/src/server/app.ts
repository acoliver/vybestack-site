import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  function validateNumericParam(param: string | undefined, paramName: string, required: boolean = false): number | undefined {
    if (!param) {
        if (required) {
            throw new Error(`${paramName} is required`);
        }
        return undefined;
    }

    const value = Number(param);
    
    // Check if it's not a number or is NaN after conversion
    if (isNaN(value) || !isFinite(value)) {
        throw new Error(`${paramName} must be a valid number`);
    }
    
    // Check for negative or zero values
    if (value <= 0) {
        throw new Error(`${paramName} must be a positive number`);
    }
    
    // Set an upper limit to prevent excessive resource usage
    if (value > 100) {
        throw new Error(`${paramName} cannot exceed 100`);
    }
    
    return Math.floor(value);
  }

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    try {
        // Validate page parameter
        const page = validateNumericParam(pageParam, 'page');
        // Validate limit parameter
        const limit = validateNumericParam(limitParam, 'limit');
        
        const payload = listInventory(db, { page, limit });
        res.json(payload);
    } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Invalid parameters';
        res.status(400).json({ error: errorMessage });
    }
  });

  return app;
}
