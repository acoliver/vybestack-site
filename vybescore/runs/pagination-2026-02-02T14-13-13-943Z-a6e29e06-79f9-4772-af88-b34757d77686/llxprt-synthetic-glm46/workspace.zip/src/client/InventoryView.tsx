import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading' || status === 'idle') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const hasPreviousPage = currentPage > 1;
  const hasNextPage = data.hasNext || false;

  const handlePrevious = (): void => {
    if (hasPreviousPage) {
      setCurrentPage(currentPage - 1);
    }
  };

  const handleNext = (): void => {
    if (hasNextPage) {
      setCurrentPage(currentPage + 1);
    }
  };

  return (
    <section>
      <h1>Inventory {data.items.length === 0 && <small>No items found</small>}</h1>
      {data.items.length === 0 ? (
        <p>No inventory items available.</p>
      ) : (
        <InventoryList items={data.items} />
      )}
      
      <nav aria-label="Pagination navigation">
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center', margin: '1rem 0' }}>
          <button
            onClick={handlePrevious}
            disabled={!hasPreviousPage}
            aria-label="Go to previous page"
            aria-disabled={!hasPreviousPage}
          >
            Previous
          </button>
          
          <span>
            Page {currentPage} of {/* Calculate total pages */}{Math.ceil(data.total / data.limit)}
          </span>
          
          <button
            onClick={handleNext}
            disabled={!hasNextPage}
            aria-label="Go to next page"
            aria-disabled={!hasNextPage}
          >
            Next
          </button>
        </div>
        
        <p aria-live="polite" style={{ fontSize: '0.875rem' }}>
          Showing {data.items.length} of {data.total} items
        </p>
      </nav>
    </section>
  );
}
