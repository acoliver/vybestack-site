import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';



const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

import type { Database } from './types.d.ts';

let db: Database | null = null;

export async function initDatabase(): Promise<Database> {
  if (db) return db;

  const dataPath = path.join(__dirname, '..', 'data');
  const dbPath = path.join(dataPath, 'submissions.sqlite');
  const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

  // Ensure data directory exists
  if (!fs.existsSync(dataPath)) {
    fs.mkdirSync(dataPath, { recursive: true });
  }

  // Read schema
  const schema = fs.readFileSync(schemaPath, 'utf8');

  // Initialize SQL.js
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const initSqlJs = await import('sql.js');
  const SQL = initSqlJs.default;

  // sql.js is a factory function that needs to be called
  const initSqlJsFactory = await SQL();

  // Load existing database or create new one
  let dbBuffer: Uint8Array | null = null;
  if (fs.existsSync(dbPath)) {
    dbBuffer = fs.readFileSync(dbPath);
  }

  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  const newDb = new initSqlJsFactory.Database(dbBuffer || undefined);
  db = newDb;

  // Initialize schema
  try {
    newDb.run(schema);
  } catch (error: unknown) {
    // If schema already exists, ignore the error
    if (error instanceof Error && !error.toString().includes('table "submissions" already exists')) {
      throw error;
    }
  }

  return newDb;
}

export function saveDatabase(): void {
  if (!db) throw new Error('Database not initialized');
  
  const dataPath = path.join(__dirname, '..', 'data');
  const dbPath = path.join(dataPath, 'submissions.sqlite');
  
  const data = db.export();
  fs.writeFileSync(dbPath, Buffer.from(data));
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
  }
}

export function getDatabase(): Database | null {
  return db;
}