export interface Database {
  run(sql: string, ...params: unknown[]): void;
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

export interface Statement {
  run(...params: unknown[]): unknown;
  free(): void;
}

declare module 'sql.js' {
  export default function initSqlJs(): Promise<typeof Database>;
}