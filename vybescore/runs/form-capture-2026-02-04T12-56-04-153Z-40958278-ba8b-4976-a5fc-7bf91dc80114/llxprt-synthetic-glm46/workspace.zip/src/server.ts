import express from 'express';
import { initDatabase, saveDatabase, closeDatabase } from './db.js';
import { validateForm } from './validation.js';

const app = express();
const port = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Routes
app.get('/', async (req, res) => {
  try {
    res.render('form', {
      errors: {},
      formData: {}
    });
  } catch (error) {
    console.error('Error rendering form:', error);
    res.status(500).send('Internal server error');
  }
});

app.post('/submit', async (req, res) => {
  try {
    const formData = {
      firstName: req.body.firstName || '',
      lastName: req.body.lastName || '',
      streetAddress: req.body.streetAddress || '',
      city: req.body.city || '',
      stateProvince: req.body.stateProvince || '',
      postalCode: req.body.postalCode || '',
      country: req.body.country || '',
      email: req.body.email || '',
      phone: req.body.phone || ''
    };

    const validation = validateForm(formData);
    
    if (!validation.isValid) {
      return res.status(400).render('form', {
        errors: validation.errors,
        formData
      });
    }

    // Save to database
    const db = await initDatabase();
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    
    stmt.free();
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req, res) => {
  try {
    res.render('thank-you');
  } catch (error) {
    console.error('Error rendering thank-you page:', error);
    res.status(500).send('Internal server error');
  }
});

// Graceful shutdown
process.on('SIGTERM', async () => {
  console.log('Received SIGTERM, shutting down gracefully');
  closeDatabase();
  process.exit(0);
});

process.on('SIGINT', async () => {
  console.log('Received SIGINT, shutting down gracefully');
  closeDatabase();
  process.exit(0);
});

// Start server
const startServer = async () => {
  try {
    await initDatabase();
    console.log('Database initialized');
    
    app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

startServer();
