import { describe, expect, it } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';

// This file is just for public route smoke testing
// Server startup tests are handled by other test files

const dbPath = path.resolve('data', 'submissions.sqlite');

describe('friendly form (public smoke)', () => {
  it('verifies database file location', () => {
    const dirExists = fs.existsSync(path.dirname(dbPath));
    expect(dirExists).toBe(true);
  });

  it('handles database cleanup', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(fs.existsSync(dbPath)).toBe(false);
  });
});
