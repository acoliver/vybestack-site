import * as fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, RenderOptions } from '../types.js';

function parseArgs(args: string[]): {
  dataPath: string;
  format: string;
  outputPath: string | undefined;
  includeTotals: boolean;
} {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataPath = args[0];
  const format = args[args.indexOf('--format') + 1];
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');

  if (!format || args.indexOf('--format') === -1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }

  return { dataPath, format, outputPath, includeTotals };
}

function validateData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: data must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field (must be a string)');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field (must be a string)');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field (must be an array)');
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${i} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "label" field (must be a string)`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${i} missing or invalid "amount" field (must be a number)`);
    }
  }

  return data as ReportData;
}

function main(): void {
  const args = process.argv.slice(2);
  const { dataPath, format, outputPath, includeTotals } = parseArgs(args);

  const formatters: Record<string, (data: ReportData, options: RenderOptions) => string> = {
    markdown: renderMarkdown,
    text: renderText,
  };

  if (!formatters[format]) {
    console.error(`Unsupported format: ${format}`);
    process.exit(1);
  }

  let jsonData: unknown;
  try {
    const content = fs.readFileSync(dataPath, 'utf-8');
    jsonData = JSON.parse(content);
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error(`Error: Failed to parse JSON file: ${error.message}`);
    } else if (error instanceof Error) {
      console.error(`Error: Failed to read file: ${error.message}`);
    } else {
      console.error('Error: Failed to read file');
    }
    process.exit(1);
  }

  let data: ReportData;
  try {
    data = validateData(jsonData);
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Invalid data format');
    }
    process.exit(1);
  }

  const options: RenderOptions = { includeTotals };
  const formatter = formatters[format];
  const output = formatter(data, options);

  if (outputPath) {
    try {
      fs.writeFileSync(outputPath, output, 'utf-8');
      console.log(`Report written to ${outputPath}`);
    } catch (error) {
      if (error instanceof Error) {
        console.error(`Error: Failed to write output file: ${error.message}`);
      } else {
        console.error('Error: Failed to write output file');
      }
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();
