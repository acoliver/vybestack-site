import express from 'express';
import path from 'path';
import fs from 'fs';
import initSqlJs, { Database } from 'sql.js';

interface FormData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  first_name?: string;
  last_name?: string;
  street_address?: string;
  city?: string;
  state_province?: string;
  postal_code?: string;
  country?: string;
  email?: string;
  phone?: string;
  general?: string;
}

const app = express();
const port = process.env.PORT || 3535;

// Set up EJS
app.set('views', path.join(__dirname, 'templates'));
app.set('view engine', 'ejs');

// Serve static files
app.use(express.static(path.join(__dirname, '../public')));
app.use(express.urlencoded({ extended: true }));

// Initialize SQLite database
let db: Database | null = null;
const dbPath = path.join(__dirname, '../data/submissions.sqlite');

async function initializeDatabase(): Promise<void> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const SQL = await initSqlJs();
    
    // Check if database file exists
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(fileBuffer);
    } else {
      db = new SQL.Database();
      // Create schema
      const schema = fs.readFileSync(path.join(__dirname, '../db/schema.sql'), 'utf8');
      db.exec(schema);
      saveDatabase();
    }
    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
  } catch (error) {
    console.error('Failed to save database:', error);
  }
}

function validateForm(formData: FormData): { isValid: boolean; errors: FormErrors } {
  const errors: FormErrors = {};

  // Required fields validation
  if (!formData.first_name.trim()) {
    errors.first_name = 'First name is required';
  }
  
  if (!formData.last_name.trim()) {
    errors.last_name = 'Last name is required';
  }
  
  if (!formData.street_address.trim()) {
    errors.street_address = 'Street address is required';
  }
  
  if (!formData.city.trim()) {
    errors.city = 'City is required';
  }
  
  if (!formData.state_province.trim()) {
    errors.state_province = 'State/Province/Region is required';
  }
  
  if (!formData.postal_code.trim()) {
    errors.postal_code = 'Postal code is required';
  }
  
  if (!formData.country.trim()) {
    errors.country = 'Country is required';
  }
  
  if (!formData.email.trim()) {
    errors.email = 'Email is required';
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.email = 'Please enter a valid email address';
  }
  
  if (!formData.phone.trim()) {
    errors.phone = 'Phone number is required';
  } else if (!/^[+\d\s()--]+$/g.test(formData.phone)) {
    errors.phone = 'Phone number can contain digits, spaces, parentheses, dashes, and a leading +';
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

async function saveSubmission(formData: FormData): Promise<void> {
  if (!db) {
    throw new Error('Database not initialized');
  }
  
  const stmt = db.prepare(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, state_province, 
      postal_code, country, email, phone
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.first_name,
    formData.last_name,
    formData.street_address,
    formData.city,
    formData.state_province,
    formData.postal_code,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();
  saveDatabase();
}

// Routes
app.get('/', (_req, res) => {
  res.render('form', { 
    errors: {}, 
    formData: {
      first_name: '',
      last_name: '',
      street_address: '',
      city: '',
      state_province: '',
      postal_code: '',
      country: '',
      email: '',
      phone: ''
    }
  });
});

app.post('/submit', async (req, res) => {
  const formData = req.body as FormData;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', { 
      errors: validation.errors, 
      formData 
    });
  }
  
  try {
    await saveSubmission(formData);
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    const errors: FormErrors = { general: 'Failed to save submission. Please try again.' };
    res.status(500).render('form', { errors, formData });
  }
});

app.get('/thank-you', (_req, res) => {
  res.render('thank-you');
});

// Graceful shutdown
async function shutdown() {
  console.log('Shutting down gracefully...');
  
  if (db) {
    saveDatabase();
    db.close();
  }
  
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Initialize and start server
async function startServer() {
  await initializeDatabase();
  
  app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });
}

startServer().catch(console.error);
