import express, { Request, Response } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore - sql.js doesn't provide type definitions but works at runtime
import initSqlJs from 'sql.js';

// Convert __dirname for ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Database configuration
const DB_FILE_PATH = path.join(__dirname, '..', 'data', 'submissions.sqlite');

// Initialize database
async function initializeDatabase(): Promise<any> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(DB_FILE_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load SQL.js
    const SQL = await initSqlJs({
      locateFile: (file: string) => path.join(__dirname, '..', 'node_modules', 'sql.js', 'dist', file)
    });

    // Create or load database using the Database class from SQL
    const DatabaseClass = SQL.Database;
    // eslint-disable-next-line @typescript-eslint/no-explicit-any
    let database: any;
    if (fs.existsSync(DB_FILE_PATH)) {
      // Load existing database
      const filebuffer = fs.readFileSync(DB_FILE_PATH);
      database = new SQL.Database(filebuffer);
      console.log('Loaded existing database from', DB_FILE_PATH);
    } else {
      // Create new database
      database = new SQL.Database();
      console.log('Created new database');
    }

    // Read schema
    const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');
    
    // Apply schema
    database.run(schema);
    console.log('Applied database schema');
    
    return database;
  } catch (error) {
    console.error('Error initializing database:', error);
    throw error;
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  try {
    const data = db.export();
    fs.writeFileSync(DB_FILE_PATH, Buffer.from(data));
    console.log('Saved database to disk');
  } catch (error) {
    console.error('Error saving database:', error);
    throw error;
  }
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Accept international phone formats with digits, spaces, parentheses, dashes, and optional leading +
  const phoneRegex = /^\+?[0-9\s\-()]+$/;
  return phoneRegex.test(phone);
}

function validatePostalCode(code: string): boolean {
  // Accept alphanumeric postal codes
  return /^[A-Za-z0-9\s-]+$/.test(code);
}

function validateNotEmpty(value?: string): boolean {
  return Boolean(value && value.trim().length > 0);
}

// Form validation
function validateForm(req: Request): { isValid: boolean; errors: string[] } {
  const { firstName, lastName, streetAddress, city, stateProvince, postalCode, country, email, phone } = req.body || {};
  const errors: string[] = [];

  // Required fields
  if (!validateNotEmpty(firstName)) errors.push('First name is required');
  if (!validateNotEmpty(lastName)) errors.push('Last name is required');
  if (!validateNotEmpty(streetAddress)) errors.push('Street address is required');
  if (!validateNotEmpty(city)) errors.push('City is required');
  if (!validateNotEmpty(stateProvince)) errors.push('State / Province / Region is required');
  if (!validateNotEmpty(postalCode)) errors.push('Postal / Zip code is required');
  if (!validateNotEmpty(country)) errors.push('Country is required');
  if (!validateNotEmpty(email)) errors.push('Email is required');
  if (!validateNotEmpty(phone)) errors.push('Phone number is required');

  // Email format
  if (email && !validateEmail(email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone format
  if (phone && !validatePhone(phone)) {
    errors.push('Phone number can only contain digits, spaces, parentheses, dashes, and an optional leading +');
  }

  // Postal code format
  if (postalCode && !validatePostalCode(postalCode)) {
    errors.push('Postal code can only contain letters, numbers, spaces, and dashes');
  }

  return {
    isValid: errors.length === 0,
    errors: errors
  };
}

// eslint-disable-next-line @typescript-eslint/no-explicit-any
let db: any = null;

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Set up EJS rendering
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '..', 'src', 'templates'));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const validation = validateForm(req);
  
  if (!validation.isValid) {
    // Form has errors, re-render with error messages and entered values
    return res.render('form', {
      errors: validation.errors,
      values: req.body
    });
  }
  
  try {
    if (!db) {
      throw new Error('Database not initialized');
    }

    // Insert submission into database
    const sql = `
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;
    
    const stmt = db.prepare(sql);
    stmt.run([
      req.body.firstName,
      req.body.lastName,
      req.body.streetAddress,
      req.body.city,
      req.body.stateProvince,
      req.body.postalCode,
      req.body.country,
      req.body.email,
      req.body.phone
    ]);
    stmt.free();
    
    // Save database to disk
    saveDatabase();
    
    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Error submitting form:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: req.body
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  // Get the most recent submission to display the first name
  let firstName = 'friend';
  
  if (db) {
    try {
      const stmt = db.prepare('SELECT first_name FROM submissions ORDER BY id DESC LIMIT 1');
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      const result: any = stmt.getAsObject();
      stmt.free();
      
      if (result.first_name) {
        firstName = result.first_name;
      }
    } catch (error) {
      console.error('Error retrieving first name:', error);
      // Fall back to 'friend' if there's an error
    }
  }
  
  res.render('thank-you', { firstName });
});

// Error handling middleware
app.use((err: Error, req: Request, res: Response) => {
  console.error('Unhandled error:', err);
  res.status(500).render('form', {
    errors: ['An error occurred. Please try again later.'],
    values: req.body || {}
  });
});

// Start server and initialize database
async function startServer(): Promise<void> {
  try {
    db = await initializeDatabase();
    const server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
    
    // Handle graceful shutdown
    const gracefulShutdown = (signal: string) => {
      console.log(`Received ${signal}, shutting down gracefully`);
      server.close(() => {
        console.log('HTTP server closed');
        if (db) {
          db.close();
          console.log('Database connection closed');
        }
        process.exit(0);
      });
    };
    
    process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
    process.on('SIGINT', () => gracefulShutdown('SIGINT'));
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Export the app, startServer function, and db for testing
export { app, startServer, db };

// Helper function to initialize database without starting server
// eslint-disable-next-line @typescript-eslint/no-explicit-any
export async function initializeDatabaseOnly(): Promise<any> {
  if (!db) {
    db = await initializeDatabase();
  }
  return db;
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}