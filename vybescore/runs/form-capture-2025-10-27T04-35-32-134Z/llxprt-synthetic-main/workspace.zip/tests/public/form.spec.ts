import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';

// We'll need a dynamic import since our server uses ES modules
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let server: any;
// eslint-disable-next-line @typescript-eslint/no-explicit-any
let app: any;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Initialize database without starting the full server
  process.env.PORT = '3001'; // Use a different port for testing
  const { app: serverApp, initializeDatabaseOnly } = await import('../../src/server');
  await initializeDatabaseOnly();
  app = serverApp;
  
  // Start server on a different port for testing
  server = app.listen(3001);
  console.log('Test server started on port 3001');
});

afterAll(async () => {
  // Clean up and close server
  if (server && server.close) {
    await new Promise(resolve => server.close(resolve));
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for form elements
    expect($('form[action="/submit"]').length).toBe(1);
    
    // Check for all input fields
    const expectedFields = [
      'firstName',
      'lastName',
      'streetAddress',
      'city',
      'stateProvince',
      'postalCode',
      'country',
      'email',
      'phone'
    ];
    
    expectedFields.forEach(field => {
      expect($(`input[name="${field}"]`).length).toBe(1);
      expect($(`label[for="${field}"]`).length).toBe(1);
    });
    
    // Check form submit button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Remove existing database file if it exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Test form submission
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'Test State',
      postalCode: '12345',
      country: 'Test Country',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app).post('/submit').send(formData);
    
    // Check redirect to thank-you page
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    // Follow the redirect
    const thankYouResponse = await request(app).get('/thank-you');
    expect(thankYouResponse.status).toBe(200);
    
    // Verify data was saved in the database
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('handles validation errors correctly', async () => {
    // Test with invalid email
    const invalidFormData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak St',
      city: 'Otherville',
      stateProvince: 'Another State',
      postalCode: 'ABCDE',
      country: 'Another Country',
      email: 'invalid-email', // Invalid email format
      phone: '+2 555-987-6543'
    };
    
    const response = await request(app).post('/submit').send(invalidFormData);
    
    // Check that form is re-rendered with error messages
    expect(response.status).toBe(200);
    expect(response.text).toContain('Please enter a valid email address');
  });

  it('handles international phone and postal formats', async () => {
    // Test with international formats
    const internationalFormData = {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Calle Principal 123',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000', // Argentine postal code
      country: 'Argentina',
      email: 'maria.garcia@example.com.ar',
      phone: '+54 9 11 1234-5678' // Argentine phone format
    };
    
    const response = await request(app).post('/submit').send(internationalFormData);
    
    // Check redirect to thank-you page (successful submission)
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
  });

  it('displays thank-you page with humor content', async () => {
    const response = await request(app).get('/thank-you');
    
    expect(response.status).toBe(200);
    expect(response.headers['content-type']).toContain('text/html');
    
    const $ = cheerio.load(response.text);
    
    // Check for humorous content
    expect($('body').text()).toContain('identity');
    expect($('a[href="/"]').length).toBe(1);
    expect($('h1').text()).toContain('Thank you');
  });
});