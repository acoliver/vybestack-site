/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  disposed?: boolean
  // Track subscriptions for cleanup
  subscribers?: Set<Subject<unknown>>
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface Observer<T> extends ObserverR, ObserverV<T> {}

export interface SubjectR {
  name?: string
  // Track observers that depend on this subject
  observers: Set<ObserverR>
}

export interface SubjectV<T> {
  value: T
  equalFn?: EqualFn<T>
}

export interface Subject<T> extends SubjectR, SubjectV<T> {}

// Global reactive context
let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  if (observer.disposed) return
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // Create a copy to avoid modification during iteration
  const observers = new Set(subject.observers)
  
  // Process all dependent observers
  for (const observer of observers) {
    if (!observer.disposed) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}

export function addObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.add(observer)
  
  // Track subscription for cleanup
  if (!observer.subscribers) {
    observer.subscribers = new Set()
  }
  observer.subscribers.add(subject as Subject<unknown>)
}

export function removeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  subject.observers.delete(observer)
  
  // Remove subscription tracking
  if (observer.subscribers) {
    observer.subscribers.delete(subject as Subject<unknown>)
  }
}

export function addDependency<T>(observer: ObserverR, subject: Subject<T>): void {
  // Track the dependency relationship for memory management
  if (!observer.subscribers) {
    observer.subscribers = new Set()
  }
  observer.subscribers.add(subject as Subject<unknown>)
}
