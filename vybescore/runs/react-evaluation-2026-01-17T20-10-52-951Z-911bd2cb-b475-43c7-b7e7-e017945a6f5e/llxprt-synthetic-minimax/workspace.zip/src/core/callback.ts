/**
 * Callback closure implementation for reactive side effects.
 */

import { 
  UnsubscribeFn, 
  Observer, 
  UpdateFn, 
  updateObserver,
  setActiveObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  let disposed = false
  
  const observer: Observer<T> = {
    value,
    updateFn: () => {
      if (disposed) return observer.value!
      
      // Clear existing subscriptions to track fresh dependencies
      if (observer.subscribers) {
        for (const subject of observer.subscribers) {
          subject.observers.delete(observer)
        }
        observer.subscribers.clear()
      }
      
      // Re-establish fresh dependencies by executing callback in active observer context
      const previous = getActiveObserver()
      setActiveObserver(observer)
      try {
        updateFn(observer.value)
      } finally {
        setActiveObserver(previous)
      }
      
      return observer.value!
    },
  }
  
  // Establish initial dependencies by evaluating in observer context
  // This will track which subjects this callback depends on and trigger the callback
  setActiveObserver(observer)
  try {
    updateObserver(observer)
  } finally {
    setActiveObserver(undefined)
  }
  
  return () => {
    if (disposed) return
    disposed = true
    observer.disposed = true
    
    // Clean up all subscriptions from each subject this observer depends on
    if (observer.subscribers) {
      for (const subject of observer.subscribers) {
        subject.observers.delete(observer)
      }
      observer.subscribers.clear()
    }
  }
}
