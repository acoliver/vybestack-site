/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  addObserver,
  addDependency,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    value,
    equalFn: undefined,
    observers: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      addObserver(s, observer)
      addDependency(observer, s)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    const shouldNotify = s.value !== nextValue
    s.value = nextValue
    if (shouldNotify) {
      notifyObservers(s)
    }
    return s.value
  }

  return [read, write]
}
