/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  Subject,
  updateObserver,
  EqualFn,
  setActiveObserver,
  getActiveObserver,
  notifyObservers,
  addObserver,
  addDependency
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const subject: Subject<T> = {
    name: options?.name,
    value: value!,
    observers: new Set(),
  }
  
  const read: GetterFn<T> = () => {
    // Always recompute to get current value and track dependencies
    const previous = getActiveObserver()
    setActiveObserver(o)
    
    try {
      const newValue = o.updateFn(o.value)
      const oldValue = o.value
      o.value = newValue
      
      // Always notify observers of computed values when they're accessed
      // This ensures callbacks and other dependent computations get updated
      notifyObservers(subject)
      
      return newValue
    } finally {
      setActiveObserver(previous)
    }
  }

  return read
}
