/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getActiveObserver,
  updateObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  // Determine the actual equal function to use
  const equalFn: EqualFn<T> = 
    typeof equal === 'function' ? equal : 
    equal === false ? () => false : 
    Object.is
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Set up tracking for dependencies
  const _previous = getActiveObserver()
  updateObserver(o)
  
  // Return a getter function for the computed value
  return (): T => {
    const currentObserver = getActiveObserver()
    if (currentObserver) {
      // Type assertion to match the Observer<T> type
      o.observer = currentObserver as Observer<T>
    }
    return o.value!
  }
}