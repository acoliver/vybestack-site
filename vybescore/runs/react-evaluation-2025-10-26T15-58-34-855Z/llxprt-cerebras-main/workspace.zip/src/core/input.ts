/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part of an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  // Determine the actual equal function to use
  const equalFn: EqualFn<T> = 
    typeof equal === 'function' ? equal : 
    equal === false ? () => false : 
    Object.is

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) s.observer = observer
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Only update if the new value is different from current value
    if (!s.equalFn!(s.value, nextValue)) {
      s.value = nextValue
      
      // Notify the observer of the change
      if (s.observer) {
        // Create a temporary observer to trigger update
        const tempObserver: Observer<T> = {
          value: s.value,
          updateFn: s.observer.updateFn
        }
        updateObserver(tempObserver)
      }
    }
    return s.value
  }

  return [read, write]
}