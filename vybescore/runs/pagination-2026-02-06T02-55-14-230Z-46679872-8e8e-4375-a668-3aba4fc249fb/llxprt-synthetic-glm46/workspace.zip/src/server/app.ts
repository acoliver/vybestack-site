import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function validatePaginationParams(page?: unknown, limit?: unknown): { page: number; limit: number } | null {
  const DEFAULT_PAGE = 1;
  const DEFAULT_LIMIT = 5;
  const MAX_LIMIT = 100;

  let parsedPage = DEFAULT_PAGE;
  let parsedLimit = DEFAULT_LIMIT;

  if (page !== undefined) {
    const pageStr = Array.isArray(page) ? page[0] : page;
    if (pageStr === undefined || pageStr === '') return null;
    
    const pageNum = Number(pageStr);
    if (!Number.isInteger(pageNum) || pageNum <= 0 || pageNum > 10000) {
      return null;
    }
    parsedPage = pageNum;
  }

  if (limit !== undefined) {
    const limitStr = Array.isArray(limit) ? limit[0] : limit;
    if (limitStr === undefined || limitStr === '') return null;
    
    const limitNum = Number(limitStr);
    if (!Number.isInteger(limitNum) || limitNum <= 0 || limitNum > MAX_LIMIT) {
      return null;
    }
    parsedLimit = limitNum;
  }

  return { page: parsedPage, limit: parsedLimit };
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const params = validatePaginationParams(req.query.page, req.query.limit);
    
    if (!params) {
      return res.status(400).json({ 
        error: 'Invalid pagination parameters' 
      });
    }

    const payload = listInventory(db, { page: params.page, limit: params.limit });
    res.json(payload);
  });

  return app;
}
