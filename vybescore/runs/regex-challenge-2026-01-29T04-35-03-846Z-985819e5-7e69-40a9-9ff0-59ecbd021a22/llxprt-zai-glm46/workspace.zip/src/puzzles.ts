/**
 * Find words starting with the prefix, excluding listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match word boundaries and prefix
  const pattern = new RegExp(`\\b${escapedPrefix}\\w+`, 'gi');
  
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  const uniqueMatches = new Set(matches.map(m => m.toLowerCase()));
  
  return Array.from(uniqueMatches).filter(word => 
    !exceptionsLower.includes(word.toLowerCase())
  );
}

/**
 * Find occurrences of a token that appear after a digit and not at the start.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Look for token preceded by a digit but not at the start
  // Return the full match including the digit
  const pattern = new RegExp(`\\d${escapedToken}`, 'g');
  
  const matches = text.match(pattern) || [];
  
  // Remove duplicates
  return [...new Set(matches)];
}

/**
 * Validate password strength.
 * - At least 10 characters
 * - One uppercase, one lowercase, one digit, one symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab)
 */
export function isStrongPassword(value: string): boolean {
  // Minimum length check
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab)
  // A sequence that repeats immediately
  for (let i = 0; i < value.length - 3; i++) {
    const seq1 = value.substring(i, i + 2);
    const seq2 = value.substring(i + 2, i + 4);
    if (seq1 === seq2) {
      return false;
    }
  }
  
  // Check for longer repeated patterns (3+ chars)
  for (let len = 3; len <= value.length / 2; len++) {
    for (let i = 0; i <= value.length - 2 * len; i++) {
      const seq1 = value.substring(i, i + len);
      const seq2 = value.substring(i + len, i + 2 * len);
      if (seq1 === seq2) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detect IPv6 addresses (including shorthand ::) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern (including shorthand with ::)
  // Full format: 8 groups of 1-4 hex digits separated by colons
  // Can use :: to replace one or more consecutive groups of zeros
  
  // IPv6 regex patterns
  // Full IPv6 without compression: 8 groups of 1-4 hex digits
  const ipv6Full = /(?:^|[\s[(])(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}(?:$|[\s\])])/;
  
  // IPv6 with :: compression (can be at start, middle, or end)
  const ipv6Compressed = /(?:^|[\s[(])[0-9a-fA-F]{0,4}::[0-9a-fA-F:]+(?:$|[\s\])])/;
  const ipv6CompressedStart = /(?:^|[\s[(])::[0-9a-fA-F:]+(?:$|[\s\])])/;
  const ipv6CompressedEnd = /(?:^|[\s[(])[0-9a-fA-F:]+::(?:$|[\s\])])/;
  const ipv6CompressedMiddle = /(?:^|[\s[(])[0-9a-fA-F:]+::[0-9a-fA-F:]+(?:$|[\s\])])/;
  
  // Check for IPv6 patterns
  if (ipv6Full.test(value) || ipv6Compressed.test(value) || 
      ipv6CompressedStart.test(value) || ipv6CompressedEnd.test(value) ||
      ipv6CompressedMiddle.test(value)) {
    return true;
  }
  
  return false;
}

