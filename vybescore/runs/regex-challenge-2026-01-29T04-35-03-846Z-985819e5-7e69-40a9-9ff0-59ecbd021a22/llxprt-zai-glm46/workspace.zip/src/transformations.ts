/**
 * Capitalize the first character of each sentence.
 * Insert exactly one space between sentences if needed.
 * Collapse extra spaces while preserving abbreviations.
 */
export function capitalizeSentences(text: string): string {
  // Common abbreviations that shouldn't trigger sentence breaks
  const abbreviations = ['Mr', 'Mrs', 'Ms', 'Dr', 'Prof', 'Sr', 'Jr', 'etc', 'e.g', 'i.e', 'vs', 'Capt', 'Lt', 'Gen', 'Sen', 'Rep', 'Gov', 'Pres', 'Rev', 'Fr', 'St', 'Ave', 'Blvd', 'Rd', 'Dept', 'Univ', 'Assn', 'Ave', 'Co', 'Corp', 'Inc', 'Ltd', 'No', 'PhD', 'MD', 'DD', 'DDS', 'Est', 'GMT', 'UTC'];
  
  // First, collapse multiple spaces into single spaces (but not newlines)
  let result = text.replace(/[ \t]+/g, ' ');
  
  // Ensure space after sentence endings if missing
  result = result.replace(/([.!?])([A-Z])/g, '$1 $2');
  
  // Capitalize first character of each sentence
  // Look for sentence boundaries preceded by .?! and followed by a letter
  // But skip abbreviations
  const sentences = result.split(/(?<=[.!?])\s+/);
  
  const capitalize = (str: string): string => {
    if (str.length === 0) return str;
    return str.charAt(0).toUpperCase() + str.slice(1).toLowerCase();
  };
  
  result = sentences.map((sentence, index) => {
    if (index === 0) {
      // First sentence - capitalize first letter
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    
    // Check if this follows an abbreviation
    const prevSentence = sentences[index - 1];
    const lastWord = prevSentence?.trim().split(/\s+/).pop()?.toLowerCase() || '';
    const isAbbreviation = abbreviations.some(abbr => 
      lastWord === abbr.toLowerCase() || lastWord.startsWith(abbr.toLowerCase() + '.')
    );
    
    if (isAbbreviation) {
      return sentence; // Don't capitalize after abbreviations
    }
    
    return capitalize(sentence);
  }).join(' ');
  
  return result;
}

/**
 * Extract all URLs from the text without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching http/https protocols
  // Match domain, optional port, path, query, fragment
  // Stop at whitespace or certain punctuation
  const urlPattern = /https?:\/\/(?:www\.)?[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)+(?::\d+)?(?:\/[^\s]*)?(?:\?[^\s]*)?(?:#[^\s]*)?/gi;
  
  const matches = text.match(urlPattern) || [];
  
  // Clean up trailing punctuation from each URL
  return matches.map(url => url.replace(/[,.;!?)]+$/, ''));
}

/**
 * Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// (but not https://)
  return text.replace(/http:\/\/(?!https:\/\/)/g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs.
 * - Always upgrade scheme to https://
 * - When path begins with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  const urlPattern = /http:\/\/example\.com(\/[^\s]*)?/gi;
  
  return text.replace(urlPattern, (match, path) => {
    if (!path) {
      return 'https://example.com';
    }
    
    // Check for dynamic hints that should prevent host rewrite
    const dynamicHints = [
      /cgi-bin/,
      /[?&=]/,
      /\.jsp$/i,
      /\.php$/i,
      /\.asp$/i,
      /\.aspx$/i,
      /\.do$/i,
      /\.cgi$/i,
      /\.pl$/i,
      /\.py$/i
    ];
    
    const hasDynamicHint = dynamicHints.some(hint => hint.test(path));
    
    // Check if path starts with /docs/
    const isDocsPath = /^\/docs\//.test(path);
    
    if (isDocsPath && !hasDynamicHint) {
      // Rewrite to docs.example.com with https
      return `https://docs.example.com${path}`;
    } else {
      // Just upgrade scheme to https
      return `https://example.com${path}`;
    }
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Return 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // For February, check if leap year
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (!isLeapYear) {
      return 'N/A';
    }
  }
  
  return year;
}
