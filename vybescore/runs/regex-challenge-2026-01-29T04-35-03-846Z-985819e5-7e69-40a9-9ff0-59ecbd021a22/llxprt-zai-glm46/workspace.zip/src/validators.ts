export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // RFC 5322 compliant email validation (simplified but robust)
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for invalid patterns
  const [localPart, domain] = value.split('@');
  
  // No double dots in local or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // No trailing dots
  if (localPart.endsWith('.') || localPart.startsWith('.') || domain.endsWith('.') || domain.startsWith('.')) {
    return false;
  }
  
  // No underscores in domain
  if (domain.includes('_')) {
    return false;
  }
  
  // Domain must have at least one dot
  if (!domain.includes('.')) {
    return false;
  }
  
  // TLD must be at least 2 chars
  const tld = domain.split('.').pop();
  if (!tld || tld.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check for optional +1 country code
  let phoneNumber = digitsOnly;
  if (phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.slice(1);
  }
  
  // US phone numbers must be exactly 10 digits
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Exchange code (next 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  // Validate the format with regex
  const phoneRegex = /^(?:\+1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}(?:\s*(ext|extension|x)\s*\d+)?$/i;
  
  if (options?.allowExtensions) {
    return phoneRegex.test(value);
  }
  
  const phoneRegexNoExt = /^(?:\+1[\s-]?)?(?:\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegexNoExt.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles with various formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[\s-]/g, '');
  
  // Full pattern with country code +54
  // Optional +54, optional trunk 0, optional mobile 9, area code (2-4 digits starting 1-9), subscriber (6-8 digits)
  const withCountryCode = /^\+54(?:0)?9?\d{2,4}\d{6,8}$/;
  
  // Pattern without country code (must have trunk prefix 0)
  const withoutCountryCode = /^09?\d{2,4}\d{6,8}$/;
  
  if (!withCountryCode.test(normalized) && !withoutCountryCode.test(normalized)) {
    return false;
  }
  
  // Extract and validate area code
  let areaCodePart = '';
  let subscriberPart = '';
  
  if (normalized.startsWith('+54')) {
    const afterCountry = normalized.slice(3);
    // Remove optional trunk prefix 0 and mobile indicator 9
    const cleaned = afterCountry.replace(/^0/, '').replace(/^9/, '');
    
    // Area code is 2-4 digits
    for (let len = 4; len >= 2; len--) {
      const potentialArea = cleaned.slice(0, len);
      const potentialSubscriber = cleaned.slice(len);
      if (potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
        areaCodePart = potentialArea;
        subscriberPart = potentialSubscriber;
        break;
      }
    }
  } else {
    const withoutTrunk = normalized.slice(1); // Remove leading 0
    const cleaned = withoutTrunk.replace(/^9/, '');
    
    // Area code is 2-4 digits
    for (let len = 4; len >= 2; len--) {
      const potentialArea = cleaned.slice(0, len);
      const potentialSubscriber = cleaned.slice(len);
      if (potentialSubscriber.length >= 6 && potentialSubscriber.length <= 8) {
        areaCodePart = potentialArea;
        subscriberPart = potentialSubscriber;
        break;
      }
    }
  }
  
  if (!areaCodePart || !subscriberPart) {
    return false;
  }
  
  // Area code must start with 1-9
  if (!/^[1-9]/.test(areaCodePart)) {
    return false;
  }
  
  // Subscriber must be 6-8 digits
  if (subscriberPart.length < 6 || subscriberPart.length > 8) {
    return false;
  }
  
  return true;
}

/**
 * Validate personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Must have at least 2 characters, start and end with a letter
  const nameRegex = /^[\p{L}][\p{L}'\-\s]*[\p{L}]$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Check for digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbols (other than allowed apostrophes, hyphens, spaces)
  const symbolRegex = /[^\p{L}'\-\s]/u;
  if (symbolRegex.test(value)) {
    return false;
  }
  
  // Must have at least 2 characters
  if (value.length < 2) {
    return false;
  }
  
  return true;
}

/**
 * Luhn checksum algorithm for credit card validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths with Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be numeric only
  if (!/^\d+$/.test(cleaned)) {
    return false;
  }
  
  // Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(5[1-5]\d{14}|2[2-7][0-9]{14})$/;
  
  // AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if matches any card type
  const validFormat = visaRegex.test(cleaned) || mastercardRegex.test(cleaned) || amexRegex.test(cleaned);
  
  if (!validFormat) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleaned);
}
