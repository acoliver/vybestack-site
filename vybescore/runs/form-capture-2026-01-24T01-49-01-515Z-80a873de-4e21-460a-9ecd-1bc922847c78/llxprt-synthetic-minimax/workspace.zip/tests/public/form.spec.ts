import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import { load } from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import type { Express } from 'express';
import type { DatabaseManager } from '../../src/database.js';

// Global type declarations for test globals
declare global {
  let __testApp: Express | undefined;
  let __testDbManager: DatabaseManager | undefined;
}

let server: Express;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database file before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Import the main app and database for testing
  const { default: app } = await import('../../src/server.js');
  const { DatabaseManager } = await import('../../src/database.js');
  
  // Initialize a fresh database for tests
  const dbManager = new DatabaseManager();
  await dbManager.initialize();
  
  // Store app globally for tests
  global.__testApp = app;
  
  // Store dbManager globally for cleanup
  global.__testDbManager = dbManager;
  
  // Start test server
  server = app.listen(0);
});

afterAll(async () => {
  // Clean up database file after tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  if (server && server.close) {
    server.close();
  }
  
  // Close test database
  const dbManager = global.__testDbManager;
  if (dbManager) {
    await dbManager.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const app = global.__testApp;
    
    const response = await request(app)
      .get('/')
      .expect(200);

    const html = response.text;
    const $ = load(html);

    // Check for all required form fields
    expect($('#firstName').length).toBe(1);
    expect($('#lastName').length).toBe(1);
    expect($('#streetAddress').length).toBe(1);
    expect($('#city').length).toBe(1);
    expect($('#stateProvince').length).toBe(1);
    expect($('#postalCode').length).toBe(1);
    expect($('#country').length).toBe(1);
    expect($('#email').length).toBe(1);
    expect($('#phone').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    const app = global.__testApp;
    
    // Ensure database is clean
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'CA',
      postalCode: '90210',
      country: 'United States',
      email: 'john@example.com',
      phone: '@1 555-123-4567'
    };

    await request(app)
      .post('/submit')
      .send(formData)
      .expect(302); // Should redirect

    // Check that submission was persisted
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for missing required fields', async () => {
    const app = global.__testApp;
    
    await request(app)
      .post('/submit')
      .send({}) // Empty form
      .expect(400);

    // The 400 response renders the form, so we just need to verify the status
    expect(true).toBe(true);
  });

  it('redirects to thank-you page after successful submission', async () => {
    const app = global.__testApp;
    
    const formData = {
      firstName: 'Jane',
      lastName: 'Smith',
      streetAddress: '456 Oak Ave',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'jane@example.com',
      phone: '@44 20 7946 0958'
    };

    await request(app)
      .post('/submit')
      .send(formData)
      .expect('Location', '/thank-you')
      .expect(302);

    // Follow redirect and check thank-you page
    const thankYouResponse = await request(app)
      .get('/thank-you')
      .expect(200);

    const html = thankYouResponse.text;
    const $ = load(html);

    expect($('h1').text()).toContain('Thank You');
    expect($('.scam-warning').length).toBe(1);
  });
});
