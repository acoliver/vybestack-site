import express, { Request, Response } from 'express';
import path from 'path';
import { DatabaseManager, ContactForm } from './database.js';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database
const dbManager = new DatabaseManager();

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));
app.use(express.static(path.join(process.cwd(), 'public')));
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Initialize database when module loads
dbManager.initialize().catch(console.error);

// Validation interface
interface ValidationError {
  field: string;
  message: string;
}

interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
  formData: Partial<ContactForm>;
}

// Validation functions
function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePhone(phone: string): boolean {
  // Allow digits, spaces, parentheses, dashes, and leading + or @
  const phoneRegex = /^[+]?@?[0-9\s\-()]+$/;
  return phoneRegex.test(phone) && phone.length >= 7;
}

function validatePostalCode(postalCode: string): boolean {
  // Allow alphanumeric strings for international formats
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.length >= 3;
}

function validateFormData(data: Record<string, unknown>): ValidationResult {
  const errors: ValidationError[] = [];
  const formData: Partial<ContactForm> = {};

  // Required field validation
  const requiredFields = [
    { field: 'firstName', label: 'First Name' },
    { field: 'lastName', label: 'Last Name' },
    { field: 'streetAddress', label: 'Street Address' },
    { field: 'city', label: 'City' },
    { field: 'stateProvince', label: 'State/Province/Region' },
    { field: 'postalCode', label: 'Postal/Zip Code' },
    { field: 'country', label: 'Country' },
    { field: 'email', label: 'Email' },
    { field: 'phone', label: 'Phone Number' }
  ];

  requiredFields.forEach(({ field, label }) => {
    const value = data[field];
    const stringValue = String(value || '');

    formData[field as keyof ContactForm] = stringValue;

    if (!value || stringValue.trim() === '') {
      errors.push({
        field,
        message: `${label} is required`
      });
    }
  });

  // Email validation
  if (typeof data.email === 'string' && !validateEmail(data.email)) {
    errors.push({
      field: 'email',
      message: 'Please enter a valid email address'
    });
  }

  // Phone validation
  if (typeof data.phone === 'string' && !validatePhone(data.phone)) {
    errors.push({
      field: 'phone',
      message: 'Please enter a valid phone number'
    });
  }

  // Postal code validation
  if (typeof data.postalCode === 'string' && !validatePostalCode(data.postalCode)) {
    errors.push({
      field: 'postalCode',
      message: 'Please enter a valid postal/zip code'
    });
  }

  return {
    isValid: errors.length === 0,
    errors,
    formData
  };
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('contact', {
    title: 'Contact Us',
    errors: [],
    formData: {}
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  try {
    const validation = validateFormData(req.body);

    if (!validation.isValid) {
      return res.status(400).render('contact', {
        title: 'Contact Us',
        errors: validation.errors,
        formData: validation.formData
      });
    }

    // Insert submission into database
    await dbManager.insertSubmission(req.body as ContactForm);
    await dbManager.save();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Server error:', error);
    res.status(500).send('Internal server error');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You!'
  });
});

// Error handling middleware
app.use((error: Error, req: Request, res: Response) => {
  console.error('Server error:', error);
  res.status(500).send('Internal server error');
});

// Graceful shutdown
async function gracefulShutdown(signal: NodeJS.Signals) {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  
  try {
    await dbManager.close();
    console.log('Database connection closed.');
    process.exit(0);
  } catch (error) {
    console.error('Error during shutdown:', error);
    process.exit(1);
  }
}

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
process.on('SIGINT', () => gracefulShutdown('SIGINT'));

// Initialize server
async function startServer() {
  try {
    await dbManager.initialize();
    console.log('Database initialized successfully.');

    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
      console.log(`Visit http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export default app;

// Export validation functions for testing
export { validateFormData, validateEmail, validatePhone, validatePostalCode };
