import initSqlJs, { Database } from 'sql.js';
import { readFileSync, writeFileSync, existsSync, mkdirSync } from 'fs';
import { join } from 'path';

export interface ContactForm {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface SubmissionRecord {
  id: number;
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
  created_at: string;
}

// Interface for the SQL.js module
interface SqlJsModule {
  Database: new (buffer?: Uint8Array) => Database;
}

export class DatabaseManager {
  private db: Database | null = null;
  private sqlJs: SqlJsModule | null = null;
  private dbPath: string;
  private initialized: boolean = false;

  constructor(dbPath: string = 'data/submissions.sqlite') {
    this.dbPath = dbPath;
  }

  isInitialized(): boolean {
    return this.initialized;
  }

  async initialize(): Promise<void> {
    try {
      // Initialize SQL.js
      const sqlModule: SqlJsModule = await initSqlJs();
      this.sqlJs = sqlModule;

      // Ensure data directory exists
      const dataDir = join(process.cwd(), 'data');
      if (!existsSync(dataDir)) {
        mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (existsSync(this.dbPath)) {
        const dbBuffer = readFileSync(this.dbPath);
        this.db = new sqlModule.Database(dbBuffer);
      } else {
        this.db = new sqlModule.Database();
        await this.createTables();
      }

      this.initialized = true;
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private async createTables(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    const schema = `
      CREATE TABLE IF NOT EXISTS submissions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        first_name TEXT NOT NULL,
        last_name TEXT NOT NULL,
        street_address TEXT NOT NULL,
        city TEXT NOT NULL,
        state_province TEXT NOT NULL,
        postal_code TEXT NOT NULL,
        country TEXT NOT NULL,
        email TEXT NOT NULL,
        phone TEXT NOT NULL,
        created_at TEXT NOT NULL DEFAULT (datetime('now'))
      );
    `;

    this.db.run(schema);
  }

  async insertSubmission(form: ContactForm): Promise<number> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      form.firstName,
      form.lastName,
      form.streetAddress,
      form.city,
      form.stateProvince,
      form.postalCode,
      form.country,
      form.email,
      form.phone
    ]);

    stmt.free();
    // sql.js doesn't have getInsertRowId, so we get the last inserted row
    const resultStmt = this.db.prepare('SELECT last_insert_rowid() as id');
    resultStmt.step();
    const result = resultStmt.getAsObject() as { id: number };
    resultStmt.free();
    return result.id;
  }

  async getAllSubmissions(): Promise<SubmissionRecord[]> {
    if (!this.db) throw new Error('Database not initialized');

    const stmt = this.db.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
    const submissions: SubmissionRecord[] = [];

    while (stmt.step()) {
      const row = stmt.getAsObject() as Record<string, unknown>;
      submissions.push({
        id: Number(row.id),
        first_name: String(row.first_name),
        last_name: String(row.last_name),
        street_address: String(row.street_address),
        city: String(row.city),
        state_province: String(row.state_province),
        postal_code: String(row.postal_code),
        country: String(row.country),
        email: String(row.email),
        phone: String(row.phone),
        created_at: String(row.created_at)
      });
    }

    stmt.free();
    return submissions;
  }

  async save(): Promise<void> {
    if (!this.db) throw new Error('Database not initialized');

    try {
      const binaryDb = this.db.export();
      writeFileSync(this.dbPath, binaryDb);
    } catch (error) {
      console.error('Failed to save database:', error);
      throw error;
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}