import express, { ErrorRequestHandler } from 'express';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';

// Import sql.js for WASM SQLite
// @ts-expect-error sql.js does not have complete TypeScript definitions
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface FormErrors {
  [key: string]: string;
}

// Simple in-memory session storage
const sessions: Map<string, { firstName: string }> = new Map();

class FormCaptureServer {
  public app: express.Application;
  private db: Database | null = null;
  private server: any;
  private dbPath: string;
  private sqlJsReady: boolean = false;

  constructor() {
    this.app = express();
    this.dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
    this.setupMiddleware();
    this.setupRoutes();
    this.setupErrorHandling();
  }

  private async initializeDatabase(): Promise<void> {
    try {
      // Initialize sql.js
      const SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Initialize database
      const sqlAsText = fs.readFileSync(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf8');
      
      let dbBuffer: Uint8Array;
      if (fs.existsSync(this.dbPath)) {
        dbBuffer = fs.readFileSync(this.dbPath);
      } else {
        dbBuffer = new Uint8Array(0);
      }

      this.db = new SQL.Database(dbBuffer);
      this.db.run(sqlAsText);
      this.sqlJsReady = true;
      
      console.log('Database initialized successfully');
    } catch (error) {
      console.error('Failed to initialize database:', error);
      throw error;
    }
  }

  private saveDatabase(): void {
    if (this.db) {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    }
  }

  private setupMiddleware(): void {
    // Parse request bodies
    this.app.use(express.urlencoded({ extended: false }));
    
    // Serve static files from public directory
    this.app.use('/public', express.static(path.join(__dirname, '..', 'public')));
    
    // Set view engine to EJS
    this.app.set('view engine', 'ejs');
    this.app.set('views', path.join(__dirname, 'templates'));

    // Extended request interface for session data
    interface SessionRequest extends express.Request {
      sessionId?: string;
      session?: { firstName: string };
      __sessionId?: string;
    }

    // Simple session middleware using cookies and session headers
    this.app.use((req: SessionRequest, res: express.Response, next: express.NextFunction) => {
      // First check for session ID from cookie or header
      const cookie = req.headers.cookie || '';
      const sessionHeader = (req.headers['x-session'] as string) || ''; // For testing
      let sessionId = '';
      
      // Parse session ID from cookie
      const cookies = cookie.split(';').map((c: string) => c.trim());
      for (const c of cookies) {
        const [name, value] = c.split('=');
        if (name === 'sessionId') {
          sessionId = value || '';
          break;
        }
      }
      
      // Check session header if no cookie session ID (for testing)
      if (!sessionId && sessionHeader) {
        sessionId = sessionHeader;
      }
      
      // If still no session ID, provide a way to pass it directly in the test
      if (!sessionId && req.__sessionId) {
        sessionId = req.__sessionId;
      }
      
      // Create new session if needed
      if (!sessionId || !sessions.has(sessionId)) {
        sessionId = Math.random().toString(36).substring(2, 15);
        sessions.set(sessionId, { firstName: '' });
        res.cookie('sessionId', String(sessionId));
        
        // Store session ID in request object for test retrieval
        req.__sessionId = sessionId;
      }
      
      // Add session to request
      req.sessionId = sessionId;
      req.session = sessions.get(sessionId);
      
      next();
    });
  }

  private validateForm(formData: FormData): FormErrors {
    const errors: FormErrors = {};

    // Required fields validation
    if (!formData.firstName.trim()) {
      errors.firstName = 'First name is required';
    }
    
    if (!formData.lastName.trim()) {
      errors.lastName = 'Last name is required';
    }
    
    if (!formData.streetAddress.trim()) {
      errors.streetAddress = 'Street address is required';
    }
    
    if (!formData.city.trim()) {
      errors.city = 'City is required';
    }
    
    if (!formData.stateProvince.trim()) {
      errors.stateProvince = 'State / Province / Region is required';
    }
    
    if (!formData.postalCode.trim()) {
      errors.postalCode = 'Postal / Zip code is required';
    }
    
    if (!formData.country.trim()) {
      errors.country = 'Country is required';
    }
    
    if (!formData.email.trim()) {
      errors.email = 'Email is required';
    }
    
    if (!formData.phone.trim()) {
      errors.phone = 'Phone number is required';
    }

    // Email validation with simple regex
    if (formData.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      errors.email = 'Please enter a valid email address';
    }

    // Phone validation - allow digits, spaces, parentheses, dashes, and leading +
    if (formData.phone && !/^[+]?[0-9()\s-]+$/.test(formData.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }

    // Postal code validation - alphanumeric strings
    if (formData.postalCode && !/^[a-zA-Z0-9\s]+$/.test(formData.postalCode)) {
      errors.postalCode = 'Postal code must contain only letters and numbers';
    }

    return errors;
  }

  private setupRoutes(): void {
    // GET home route - render the form
    this.app.get('/', (req: any, res: express.Response) => {
      res.render('form', {
        errors: {},
        values: {}
      });
    });

    // POST submit route - handle form submission
    this.app.post('/submit', express.urlencoded({ extended: false }), (req: any, res: express.Response) => {
      // Log the request body for debugging
      console.log('Received form data:', req.body);
      
      const formData: FormData = {
        firstName: req.body.firstName || '',
        lastName: req.body.lastName || '',
        streetAddress: req.body.streetAddress || '',
        city: req.body.city || '',
        stateProvince: req.body.stateProvince || '',
        postalCode: req.body.postalCode || '',
        country: req.body.country || '',
        email: req.body.email || '',
        phone: req.body.phone || ''
      };

      console.log('Parsed form data:', formData);
      const errors = this.validateForm(formData);
      console.log('Validation errors:', errors);

      if (Object.keys(errors).length > 0) {
        // Render form with errors
        res.status(400).render('form', {
          errors,
          values: formData
        });
        return;
      }

      // Insert data into database
      try {
        if (!this.db) {
          throw new Error('Database not initialized');
        }

        this.db.run(`
          INSERT INTO submissions 
          (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `, [
          formData.firstName,
          formData.lastName,
          formData.streetAddress,
          formData.city,
          formData.stateProvince,
          formData.postalCode,
          formData.country,
          formData.email,
          formData.phone
        ]);

        // Save database changes to file
        this.saveDatabase();

        // Store first name in session for thank you page
        const sessionId = req.sessionId;
        if (sessionId) {
          const session = sessions.get(sessionId);
          if (session) {
            session.firstName = formData.firstName;
          }
        }

        // Redirect to thank you page
        res.redirect(302, '/thank-you');
      } catch (error) {
        console.error('Error saving form data:', error);
        res.status(500).render('form', {
          errors: { general: 'An error occurred while saving your data. Please try again.' },
          values: formData
        });
      }
    });

    // GET thank you route
    this.app.get('/thank-you', (req: any, res: express.Response) => {
      const sessionId = req.sessionId;
      let firstName = 'Friend';
      
      console.log('Thank you page session ID:', sessionId);
      if (sessionId) {
        const session = sessions.get(sessionId);
        console.log('Session data:', session);
        if (session && session.firstName) {
          firstName = session.firstName;
        }
      }
      
      console.log('Rendering thank-you with firstName:', firstName);
      res.render('thank-you', { firstName });
    });
  }

  private setupErrorHandling(): void {
    const errorHandler: ErrorRequestHandler = (err: Error, req: express.Request, res: express.Response) => {
      console.error('Unhandled error:', err);
      res.status(500).send('Something went wrong!');
    };

    this.app.use(errorHandler);
  }

  public async start(port: number = 3000): Promise<void> {
    // Initialize database before starting server
    await this.initializeDatabase();
    
    return new Promise((resolve) => {
      this.server = this.app.listen(port, () => {
        console.log(`Server running at http://localhost:${port}`);
        resolve();
      });
    });
  }

  public async stop(): Promise<void> {
    return new Promise((resolve) => {
      if (this.server) {
        this.server.close(() => {
          console.log('Server stopped');
          this.db?.close();
          resolve();
        });
      } else {
        this.db?.close();
        resolve();
      }
    });
  }
}

// Start server if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  const port = process.env.PORT ? parseInt(process.env.PORT, 10) : 3000;
  const server = new FormCaptureServer();

  // Graceful shutdown handling
  const handleShutdown = (): void => {
    console.log('Shutting down gracefully...');
    server.stop().then(() => {
      process.exit(0);
    });
  };

  process.on('SIGTERM', handleShutdown);
  process.on('SIGINT', handleShutdown);

  server.start(port).catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

// Export for testing
export default FormCaptureServer;