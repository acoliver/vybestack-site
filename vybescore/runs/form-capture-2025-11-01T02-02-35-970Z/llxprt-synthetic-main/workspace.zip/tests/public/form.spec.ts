import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import express from 'express';
import FormCaptureServer from '../../src/server.js';

let server: FormCaptureServer;
let app: express.Application;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start server for testing
  server = new FormCaptureServer();
  await server.start(0); // Use port 0 to get a random port for testing
  
  // Get the Express app from server
  app = server.app;
});

afterAll(async () => {
  if (server) {
    await server.stop();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app)
      .get('/')
      .expect(200);
      
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('label[for="firstName"]').length).toBe(1);
    expect($('input[name="firstName"]').length).toBe(1);
    expect($('label[for="lastName"]').length).toBe(1);
    expect($('input[name="lastName"]').length).toBe(1);
    expect($('label[for="streetAddress"]').length).toBe(1);
    expect($('input[name="streetAddress"]').length).toBe(1);
    expect($('label[for="city"]').length).toBe(1);
    expect($('input[name="city"]').length).toBe(1);
    expect($('label[for="stateProvince"]').length).toBe(1);
    expect($('input[name="stateProvince"]').length).toBe(1);
    expect($('label[for="postalCode"]').length).toBe(1);
    expect($('input[name="postalCode"]').length).toBe(1);
    expect($('label[for="country"]').length).toBe(1);
    expect($('input[name="country"]').length).toBe(1);
    expect($('label[for="email"]').length).toBe(1);
    expect($('input[name="email"]').length).toBe(1);
    expect($('label[for="phone"]').length).toBe(1);
    expect($('input[name="phone"]').length).toBe(1);
    
    // Check for form submission button
    expect($('button[type="submit"]').length).toBe(1);
  });

  it('persists submission and redirects', async () => {
    // Ensure database doesn't exist
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'California',
      postalCode: '90210',
      country: 'USA',
      email: 'john.doe@example.com',
      phone: '+1 555-123-4567'
    };
    
    // Submit form data with proper session
    const agent = request.agent(app);
    
    // First get the form page to establish session
    await agent.get('/').expect(200);
    
    const response = await agent
      .post('/submit')
      .type('form')
      .send(formData)
      .expect(302);
    
    // Check for redirect to thank you page
    expect(response.headers.location).toBe('/thank-you');
    
    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
    
    // Verify thank you page loads and contains the first name
    const thankYouResponse = await agent
      .get('/thank-you')
      .expect(200);
      
    const $ = cheerio.load(thankYouResponse.text);
    expect($('body').text()).toContain('John');
  });
});
