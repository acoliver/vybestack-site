export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation using regex
  // Allow typical patterns like name+tag@example.co.uk
  // Reject double dots, trailing dots, domains with underscores
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Must match the pattern
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for obvious invalid forms
  if (value.includes('..') || // Reject double dots
      value.endsWith('.') || // Reject trailing dots
      value.includes('@.') || // Reject domain starting with dot
      value.includes('.@') || // Reject domain ending with dot
      value.includes('_@') || // Reject underscore before domain
      value.includes('__') || // Reject double underscores
      value.startsWith('@') || // Reject missing local part
      value.endsWith('@')) {  // Reject missing domain
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleaned = value.replace(/\D/g, '');
  
  // US phone numbers should be 10-11 digits (if includes country code +1)
  // Check for optional +1 prefix and validate
  if (cleaned.length === 11 && cleaned.startsWith('1')) {
    // 11 digits with leading 1
    if (cleaned.startsWith('10') || cleaned.startsWith('11')) {
      return false; // Area codes cannot start with 0 or 1
    }
    return true;
  } else if (cleaned.length === 10) {
    // 10 digits for domestic format
    if (cleaned.startsWith('0') || cleaned.startsWith('1')) {
      return false; // Area codes cannot start with 0 or 1
    }
    // Validate the number format properly
    if (/^[2-9][0-9]{2}[2-9][0-9]{6}$/.test(cleaned)) {
      return true;
    }
  }
  
  // Too short - not a valid phone number
  if (cleaned.length < 10) {
    return false;
  }
  
  // If we have more than 11 digits, reject
  if (cleaned.length > 11) {
    return false;
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators and whitespace, keep only digits and +
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check for country code
  if (cleaned.startsWith('+54')) {
    // Remove country code for further validation
    const rest = cleaned.slice(3);
    
    // Check for optional mobile indicator 9
    let remaining = rest;
    if (remaining.startsWith('9')) {
      remaining = remaining.slice(1);
    }
    
    // Extract area code (2-4 digits starting with 1-9)
    if (remaining.length < 3) return false; // Need at least area code
    const areaCodeMatch = remaining.match(/^([1-9]\d{0,2})/);
    if (!areaCodeMatch) return false;
    
    const actualAreaCode = areaCodeMatch[1];
    if (actualAreaCode.length < 2 || actualAreaCode.length > 4) return false;
    
    // Remaining digits are subscriber number
    const subscriberLength = remaining.length - actualAreaCode.length;
    if (subscriberLength < 6 || subscriberLength > 8) return false;
    
    return true;
  } else {
    // No country code - must start with trunk prefix 0
    if (!cleaned.startsWith('0')) return false;
    
    const remaining = cleaned.slice(1);
    
    // Extract area code (2-4 digits starting with 1-9)
    if (remaining.length < 3) return false;
    const areaCodeMatch = remaining.match(/^([1-9]\d{0,2})/);
    if (!areaCodeMatch) return false;
    
    const actualAreaCode = areaCodeMatch[1];
    if (actualAreaCode.length < 2 || actualAreaCode.length > 4) return false;
    
    // Remaining digits are subscriber number
    const subscriberLength = remaining.length - actualAreaCode.length;
    if (subscriberLength < 6 || subscriberLength > 8) return false;
    
    return true;
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, spaces
  // Reject digits, symbols, and names like "X Æ A-12"
  if (value.length === 0) return false;
  
  // Check for digits - should not have any
  if (/\d/.test(value)) {
    return false;
  }
  
  // Check for symbols that are clearly not part of names
  if (/[^\p{L}\p{M}\s'-]/u.test(value)) {
    return false;
  }
  
  // Must contain at least one letter or accented character
  if (!/[\p{L}\p{M}]/u.test(value)) {
    return false;
  }
  
  // Pattern allows unicode letters, accents, apostrophes, hyphens, spaces
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  return nameRegex.test(value);
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').reverse().map(Number);
  let sum = 0;
  
  for (let i = 0; i < digits.length; i++) {
    let digit = digits[i];
    
    // Double every second digit (starting from i=1, the second digit from right)
    if (i % 2 === 1) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    sum += digit;
  }
  
  return sum % 10 === 0;
}

export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check minimum and maximum lengths for credit cards
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Check for valid card prefixes and lengths
  const isVisa = /^4\d{12}(\d{3})?(\d{3})?$/.test(cleaned); // 4 followed by 12, 15, or 18 digits
  const isMastercard = /^(5[1-5]\d{14}|2(2[2-9]\d{2}|[3-6]\d{3}|7[01]\d{2}|720\d{2})\d{12})$/.test(cleaned); // 51-55 or 2221-2720 followed by 12 digits
  const isAmEx = /^3[47]\d{13}$/.test(cleaned); // 34 or 37 followed by 13 digits
  
  // Must match one of the card types
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cleaned);
}
