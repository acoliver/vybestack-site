/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Find words beginning with the prefix but excluding the listed exceptions
  // Pattern to match words starting with the prefix (case-insensitive)
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions
  const exceptionsSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  const filteredMatches = matches.filter(word => 
    !exceptionsSet.has(word.toLowerCase())
  );
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Find occurrences where token appears after a digit
  // Pattern to match digit followed by token, followed by whitespace or end of string
  const pattern = new RegExp(`\\b\\d${token}\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase, one lowercase, one digit, one symbol
  if (!/[A-Z]/.test(value)) return false;
  if (!/[a-z]/.test(value)) return false;
  if (!/[0-9]/.test(value)) return false;
  if (!/[!@#$%^&*()_+\-=[\]{};':"|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab)
  for (let i = 0; i < value.length - 3; i++) {
    const seq = value.slice(i, i + 4);
    if (seq[0] === seq[2] && seq[1] === seq[3]) {
      return false; // Found repeating pattern like abab
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 patterns:
  // 1. Full notation with 8 groups: 2001:0db8:0000:0000:0000:ff00:0042:8329
  // 2. Shorthand with ::: 2001:db8::8a2e:370:7334
  // 3. Shorthand patterns with leading/trailing :: or mixed notation
  
  // Check for IPv6 addresses (including shorthand) and ensure IPv4 addresses do not trigger
  // Pattern for IPv6 shorthand detection within text
  const ipv6ShorthandPattern = /[0-9a-fA-F]{1,4}::[0-9a-fA-F]{1,4}/;
  
  // Full IPv6 pattern (exact match)
  const fullPattern = /^([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}$/;
  
  // IPv6 with :: patterns
  const shorthandPattern = /^[0-9a-fA-F]{1,4}:[0-9a-fA-F:]*::[0-9a-fA-F:]*$/;
  
  // Check exact matches first
  const trimmed = value.trim();
  if (fullPattern.test(trimmed) || shorthandPattern.test(trimmed)) {
    return true;
  }
  
  // Check for shorthand patterns within text (but not IPv4)
  // IPv4 addresses have dots, not colons with double colons
  if (ipv6ShorthandPattern.test(trimmed) && !value.includes('.')) {
    return true;
  }
  
  // Check for more complex IPv6 patterns
  const complexPattern = /([0-9a-fA-F]{1,4}:)+[0-9a-fA-F]{1,4}::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/;
  if (complexPattern.test(trimmed)) {
    return true;
  }
  
  return false;
}
