/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence endings followed by potential whitespace
  // Then capitalize the first letter of each sentence
  return text
    .split(/([.!?]+)\s*/)  // Split by sentence endings while keeping punctuation
    .map((segment, index) => {
      // Every odd segment contains punctuation, even segments contain text
      if (index % 2 === 1) return segment; // Return punctuation as-is
      
      // Skip empty segments
      if (!segment) return segment;
      
      // Capitalize first letter of sentence text
      return segment.charAt(0).toUpperCase() + segment.slice(1);
    })
    .join('')
    .replace(/([.!?]+)([A-Z])/g, '$1 $2'); // Ensure space after sentence ending
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Match common URL patterns more comprehensively
  const urlPattern = /\b(?:https?:\/\/|www\.)[^\s"<>]+/gi;
  const matches = text.match(urlPattern) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation
    return url.replace(/[.,!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// while leaving secure URLs untouched
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs with paths
  const urlPattern = /\b(http:\/\/)[^\s"<>]+/gi;
  
  return text.replace(urlPattern, (match) => {
    // Parse the URL to check conditions
    // Always upgrade scheme to https
    let upgradedUrl = match.replace(/^http:\/\//, 'https://');
    
    // Check if path contains dynamic hints or legacy extensions that should skip host rewrite
    const hasDynamicHints = /(\?|&|=)|cgi-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/i.test(upgradedUrl);
    
    // Only rewrite host for /docs/ paths that don't have dynamic hints
    if (!hasDynamicHints && upgradedUrl.includes('/docs/')) {
      // Extract the path starting from /docs/
      const docsMatch = upgradedUrl.match(/\/docs\/.+/);
      if (docsMatch) {
        // Extract everything after the domain/port part
        const pathPart = docsMatch[0];
        // Rewrite to docs.example.com with the path
        upgradedUrl = 'https://docs.example.com' + pathPart;
      }
    }
    
    return upgradedUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Pattern to match mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Basic validation for month/day ranges
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Return the year as string
  return year;
}
