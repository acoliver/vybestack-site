import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(3);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
    expect(response.body.items.length).toBe(3);
  });

  it('paginates correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response1 = await request(app).get('/inventory?page=1&limit=3');
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    
    const firstPageItems = response1.body.items.map((item: { id: number }) => item.id);
    const secondPageItems = response2.body.items.map((item: { id: number }) => item.id);
    
    // Ensure different items are returned on different pages
    expect(firstPageItems).toEqual([1, 2, 3]);
    expect(secondPageItems).toEqual([4, 5, 6]);
    
    // Ensure no overlapping items
    expect(firstPageItems.some((id: number) => secondPageItems.includes(id))).toBe(false);
  });

  it('validates page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const invalidPageTests = [
      { page: '0', expectedError: 'Page must be a positive integer' },
      { page: '-1', expectedError: 'Page must be a positive integer' },
      { page: 'abc', expectedError: 'Page must be a positive integer' },
      { page: '1.5', expectedError: 'Page must be a positive integer' }
    ];
    
    for (const test of invalidPageTests) {
      const response = await request(app).get(`/inventory?page=${test.page}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe(test.expectedError);
    }
  });

  it('validates limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const invalidLimitTests = [
      { limit: '0', expectedError: 'Limit must be a positive integer' },
      { limit: '-1', expectedError: 'Limit must be a positive integer' },
      { limit: 'abc', expectedError: 'Limit must be a positive integer' },
      { limit: '1.5', expectedError: 'Limit must be a positive integer' },
      { limit: '101', expectedError: 'Limit cannot exceed 100' }
    ];
    
    for (const test of invalidLimitTests) {
      const response = await request(app).get(`/inventory?limit=${test.limit}`);
      expect(response.status).toBe(400);
      expect(response.body.error).toBe(test.expectedError);
    }
  });

  it('detects last page correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Last page with 3 items per page (total 15 items, so page 5 is last)
    const lastPageResponse = await request(app).get('/inventory?page=5&limit=3');
    expect(lastPageResponse.status).toBe(200);
    expect(lastPageResponse.body.hasNext).toBe(false);
    
    // Page beyond last should return empty or appropriate handling
    const beyondLastResponse = await request(app).get('/inventory?page=6&limit=3');
    expect(beyondLastResponse.status).toBe(200);
    expect(beyondLastResponse.body.items.length).toBe(0);
    expect(beyondLastResponse.body.hasNext).toBe(false);
  });
});