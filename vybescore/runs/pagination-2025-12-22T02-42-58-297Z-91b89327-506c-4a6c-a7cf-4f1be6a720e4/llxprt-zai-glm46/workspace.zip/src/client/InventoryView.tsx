import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }): JSX.Element {
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  totalItems, 
  limit,
  onPageChange 
}: { 
  currentPage: number; 
  hasNext: boolean; 
  totalItems: number; 
  limit: number;
  onPageChange: (page: number) => void;
}): JSX.Element {
  const hasPrevious = currentPage > 1;
  
  return (
    <nav aria-label="Pagination controls" style={{ marginTop: '1rem', display: 'flex', gap: '0.5rem', alignItems: 'center' }}>
      <button 
        onClick={() => onPageChange(currentPage - 1)}
        disabled={!hasPrevious}
        aria-label="Previous page"
      >
        Previous
      </button>
      <span style={{ margin: '0 0.5rem' }}>
        Page {currentPage} of {Math.max(1, Math.ceil(totalItems / limit))} ({totalItems} items total)
      </span>
      <button 
        onClick={() => onPageChange(currentPage + 1)}
        disabled={!hasNext}
        aria-label="Next page"
      >
        Next
      </button>
    </nav>
  );
}

export function InventoryView(): JSX.Element {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  const handlePageChange = (newPage: number): void => {
    if (newPage >= 1 && (!data || newPage <= Math.ceil(data.total / PAGE_LIMIT))) {
      setCurrentPage(newPage);
    }
  };

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error') {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  if (status === 'ready' && data) {
    const hasItems = data.items.length > 0;
    
    return (
      <section>
        <h1>Inventory</h1>
        {hasItems ? (
          <>
            <InventoryList items={data.items} />
            <PaginationControls 
              currentPage={data.page}
              hasNext={data.hasNext}
              totalItems={data.total}
              limit={data.limit}
              onPageChange={handlePageChange}
            />
          </>
        ) : (
          <p>No inventory items found.</p>
        )}
      </section>
    );
  }

  return <p>Unable to load inventory.</p>;
}
