import type { Database } from 'sql.js';
import type { InventoryItem, InventoryPage } from '../shared/types';

const DEFAULT_LIMIT = 5;
const MAX_LIMIT = 100;

function mapRow(row: Record<string, unknown>): InventoryItem {
  return {
    id: Number(row.id),
    name: String(row.name),
    sku: String(row.sku),
    priceCents: Number(row.priceCents),
    createdAt: String(row.createdAt)
  };
}

function validatePaginationParams(options: { page?: number; limit?: number }): { page: number; limit: number; error?: string } {
  let page = options.page;
  let limit = options.limit;

  // Validate page parameter
  if (page !== undefined) {
    if (!Number.isInteger(page) || page <= 0) {
      return { page: 1, limit: DEFAULT_LIMIT, error: 'Page must be a positive integer' };
    }
    if (page > 10000) {
      return { page: 1, limit: DEFAULT_LIMIT, error: 'Page number too large' };
    }
  } else {
    page = 1;
  }

  // Validate limit parameter
  if (limit !== undefined) {
    if (!Number.isInteger(limit) || limit <= 0) {
      return { page: 1, limit: DEFAULT_LIMIT, error: 'Limit must be a positive integer' };
    }
    if (limit > MAX_LIMIT) {
      return { page: 1, limit: DEFAULT_LIMIT, error: `Limit cannot exceed ${MAX_LIMIT}` };
    }
  } else {
    limit = DEFAULT_LIMIT;
  }

  return { page, limit };
}

export function listInventory(
  db: Database,
  options: { page?: number; limit?: number }
): InventoryPage | { error: string } {
  // Validate pagination parameters
  const validation = validatePaginationParams(options);
  if (validation.error) {
    return { error: validation.error };
  }

  const { page, limit } = validation;

  // Get total count
  const countStmt = db.prepare('SELECT COUNT(*) as count FROM inventory');
  countStmt.step();
  const total = Number(countStmt.getAsObject().count ?? 0);
  countStmt.free();

  // Fixed offset calculation: (page - 1) * limit
  const offset = (page - 1) * limit;

  const stmt = db.prepare(
    `SELECT id, name, sku, price_cents AS priceCents, created_at AS createdAt
     FROM inventory
     ORDER BY id
     LIMIT $limit OFFSET $offset`
  );
  stmt.bind({ $limit: limit, $offset: offset });

  const rows: InventoryItem[] = [];
  while (stmt.step()) {
    rows.push(mapRow(stmt.getAsObject()));
  }
  stmt.free();

  const hasNext = offset + limit < total;

  return {
    items: rows,
    page,
    limit,
    total,
    hasNext
  };
}
