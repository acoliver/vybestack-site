import express, { type Express } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req, res) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    // Validate that page and limit are numeric strings if provided
    if (pageParam !== undefined && !/^\d+$/.test(pageParam.trim())) {
      res.status(400).json({ error: 'Page must be a positive integer' });
      return;
    }

    if (limitParam !== undefined && !/^\d+$/.test(limitParam.trim())) {
      res.status(400).json({ error: 'Limit must be a positive integer' });
      return;
    }

    const page = pageParam ? Number(pageParam.trim()) : undefined;
    const limit = limitParam ? Number(limitParam.trim()) : undefined;

    const payload = listInventory(db, { page, limit });
    
    // Check if payload is an error response
    if ('error' in payload) {
      res.status(400).json(payload);
    } else {
      res.json(payload);
    }
  });

  return app;
}
