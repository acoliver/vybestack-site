// Simple test script to debug the reactive system behavior
import { createInput, createComputed, createCallback } from './src/index.js'

console.log('=== Testing Reactive System ===')

// Test 1: Basic input
console.log('\n1. Testing basic input:')
const [input, setInput] = createInput(1)
console.log('Initial value:', input())
setInput(3)
console.log('After setInput(3):', input())

// Test 2: Computed values
console.log('\n2. Testing computed values:')
const [a, setA] = createInput(1)
const double = createComputed(() => a() * 2)
console.log('Initial double:', double())
setA(5)
console.log('After setA(5):', double())

// Test 3: Callbacks
console.log('\n3. Testing callbacks:')
const [b, setB] = createInput(1)
let callbackValue = 0
const unsubscribe = createCallback(() => {
  console.log('Callback called, b is:', b())
  callbackValue = b()
})

console.log('Initial callback value:', callbackValue)
setB(3)
console.log('After setB(3), callback value:', callbackValue)

// Test 4: The failing test case
console.log('\n4. Testing failing scenario:')
const [input1, setInput1] = createInput(1)
const output1 = createComputed(() => input1() + 1)
let value1 = 0

console.log('Before callback, output1 is:', output1())
createCallback(() => {
  console.log('Callback called, output1 is:', output1(), 'setting value1 to', output1())
  value1 = output1()
})

console.log('Before setInput1, value1 is:', value1)
setInput1(3)
console.log('After setInput1(3), value1 should be 4, actually is:', value1)

// Test 5: The unsubscribe test
console.log('\n5. Testing unsubscribe:')
const [input2, setInput2] = createInput(11)
const output2 = createComputed(() => input2() + 1)

const values1 = []
const unsubscribe1 = createCallback(() => values1.push(output2()))
const values2 = []
createCallback(() => values2.push(output2()))

console.log('Before changes, values1 length:', values1.length, 'values2 length:', values2.length)
setInput2(31)
console.log('After setInput2(31), values1:', values1, 'values2:', values2)
unsubscribe1()
setInput2(41)
console.log('After unsubscribe1 and setInput2(41), values1:', values1, 'values2:', values2)
console.log('values2 length should be greater than values1 length:', values2.length, '>', values1.length)