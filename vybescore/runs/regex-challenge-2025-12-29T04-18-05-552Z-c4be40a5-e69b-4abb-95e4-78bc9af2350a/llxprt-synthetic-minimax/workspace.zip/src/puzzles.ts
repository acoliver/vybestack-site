/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  const pattern = new RegExp(`\\b${prefix}\\w*`, 'gi');
  const matches = text.match(pattern) || [];
  
  const filteredMatches = matches.filter(match => {
    const lowerMatch = match.toLowerCase();
    return !exceptions.some(exception => 
      exception.toLowerCase() === lowerMatch.toLowerCase()
    );
  });
  
  return filteredMatches;
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  const matches: string[] = [];
  const regex = new RegExp(`(?<!^)(?<=\\d)${token}`, 'gi');
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    const beforeIndex = match.index - 1;
    if (beforeIndex >= 0 && /\d/.test(text[beforeIndex])) {
      matches.push(text[beforeIndex] + token);
    }
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // At least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain one uppercase, one lowercase, one digit, one symbol
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=[\]{};':"\\|,.<>?]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // No immediate repeated sequences (like abab)
  // Check for repeating patterns of length 2, 3, 4
  const patterns = [
    /(..)\1/, // Two characters repeated: abab
    /(...)\1/, // Three characters repeated: abcabc
    /(....)\1/ // Four characters repeated: abcdabcd
  ];
  
  for (const pattern of patterns) {
    if (pattern.test(value)) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 pattern including shorthand notation (::)
  // Must not match IPv4 addresses
  const ipv6Regex = /\b(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{1,4}\b|\b(?:[a-fA-F0-9]{1,4}:){0,7}::(?:\b(?:[a-fA-F0-9]{1,4}:){0,7}[a-fA-F0-9]{1,4}\b)?|\b(?:[a-fA-F0-9]{1,4}:){1,7}::\b/;
  
  // Quick check to exclude obvious IPv4 addresses first
  const ipv4Regex = /\b(?:\d{1,3}\.){3}\d{1,3}\b/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  // Check for IPv6
  return ipv6Regex.test(value);
}