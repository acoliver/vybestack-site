export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Pattern for typical email addresses with validation
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Check basic format
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Additional checks for specific issues
  // No double dots
  if (value.includes('..')) {
    return false;
  }
  
  // No trailing dots
  if (value.endsWith('.')) {
    return false;
  }
  
  // No domain with underscores
  const domain = value.split('@')[1];
  if (domain && domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters for validation
  const cleaned = value.replace(/\D/g, '');
  
  // Check length - must be 10 digits (11 with country code +1)
  if (cleaned.length < 10 || cleaned.length > 11) {
    return false;
  }
  
  // If 11 digits, must start with +1 (country code)
  if (cleaned.length === 11 && !cleaned.startsWith('1')) {
    return false;
  }
  
  // Extract area code (first 3 digits of 10-digit number)
  const areaCode = cleaned.length === 11 ? cleaned.substring(1, 4) : cleaned.substring(0, 3);
  
  // Area code cannot start with 0 or 1 (NANP rules)
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Validate format with original string
  const phoneRegex = /^(?:\+?1[\s.-]?)?(?:\(\d{3}\)|\d{3})[\s.-]?\d{3}[\s.-]?\d{4}$/;
  
  return phoneRegex.test(value);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces, hyphens, and parentheses for processing
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Check if number has country code
  if (cleaned.startsWith('+54')) {
    // Remove country code
    const numberWithoutCC = cleaned.substring(3);
    
    // Optional mobile indicator
    if (numberWithoutCC.startsWith('9')) {
      const mobileNumber = numberWithoutCC.substring(1);
      // Check if it's a valid mobile format (2-4 digit area + 6-8 total digits)
      const areaCodeMatch = mobileNumber.match(/^([1-9]\d{1,3})(\d{6,8})$/);
      return areaCodeMatch !== null;
    } else {
      // Landline with country code
      const areaCodeMatch = numberWithoutCC.match(/^([1-9]\d{1,3})(\d{6,8})$/);
      return areaCodeMatch !== null;
    }
  } else {
    // No country code - must start with trunk prefix 0
    if (!cleaned.startsWith('0')) {
      return false;
    }
    
    // Remove trunk prefix
    const numberWithoutTrunk = cleaned.substring(1);
    
    // Optional mobile indicator
    if (numberWithoutTrunk.startsWith('9')) {
      const mobileNumber = numberWithoutTrunk.substring(1);
      // Check if it's a valid mobile format
      const areaCodeMatch = mobileNumber.match(/^([1-9]\d{1,3})(\d{6,8})$/);
      return areaCodeMatch !== null;
    } else {
      // Landline without country code
      const areaCodeMatch = numberWithoutTrunk.match(/^([1-9]\d{1,3})(\d{6,8})$/);
      return areaCodeMatch !== null;
    }
  }
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Must not be empty or only whitespace
  if (!value.trim()) {
    return false;
  }
  
  // Reject if it contains digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Reject symbols like Æ or numbers in the name
  if (/[ÆØÅæøå]/.test(value)) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Pattern: starts with letter, followed by allowed characters
  const nameRegex = /^[\p{L}](?:[\p{L}\p{M}'\-\s])*[\p{L}\p{M}]?$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Additional check: must contain at least one letter
  if (!/[\p{L}]/u.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check length and prefix for card types
  let isValid = false;
  
  // Visa: starts with 4, 13-19 digits
  if (cleaned.startsWith('4') && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    isValid = true;
  }
  // Mastercard: starts with 51-55 or 2221-2720, 16 digits
  else if ((cleaned.startsWith('51') || cleaned.startsWith('52') || cleaned.startsWith('53') || 
            cleaned.startsWith('54') || cleaned.startsWith('55')) && cleaned.length === 16) {
    isValid = true;
  }
  else if (cleaned.startsWith('2221') && cleaned.length === 16) {
    // Check if between 2221-2720
    const prefix = parseInt(cleaned.substring(0, 4));
    if (prefix >= 2221 && prefix <= 2720) {
      isValid = true;
    }
  }
  // AmEx: starts with 34 or 37, 15 digits
  else if ((cleaned.startsWith('34') || cleaned.startsWith('37')) && cleaned.length === 15) {
    isValid = true;
  }
  
  if (!isValid) {
    return false;
  }
  
  // Run Luhn checksum algorithm
  const sum = cleaned.split('').reverse().map((digit, index) => {
    let num = parseInt(digit);
    // Double every second digit starting from position 1 (0-indexed)
    if (index % 2 === 1) {
      num *= 2;
      if (num > 9) {
        num -= 9;
      }
    }
    return num;
  }).reduce((total, num) => total + num, 0);
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
