/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  return text.replace(/(^|[.!?]\s+)([a-z\u00C0-\u00FF])/g, (match, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  const urlRegex = /\bhttps?:\/\/[^\s<>"{}|\\^`[\]]+/gi;
  
  return text.match(urlRegex) || [];
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/([^/\s]+)(\/[^\s]*)/gi, (match, host, path) => {
    // Always upgrade to https
    let result = 'https://' + host + path;
    
    // Check if path starts with /docs/
    if (path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions that should skip host rewrite
      const hasDynamicHints = /(\?|&|=|;|cgi-bin)|(\.(jsp|php|asp|aspx|do|cgi|pl|py))/i.test(path);
      
      if (!hasDynamicHints) {
        // Rewrite host to docs.hostname.com
        const docsHost = 'docs.' + host;
        // Preserve the /docs/ path
        result = 'https://' + docsHost + path;
      }
    }
    
    return result;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // 29 for February (we'll check leap year later)
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Special case for February
  if (month === 2) {
    const yearNum = parseInt(year, 10);
    // Check leap year
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    
    if (!isLeapYear && day > 28) {
      return 'N/A';
    } else if (!isLeapYear && day === 29) {
      return 'N/A';
    }
  }
  
  return year;
}
