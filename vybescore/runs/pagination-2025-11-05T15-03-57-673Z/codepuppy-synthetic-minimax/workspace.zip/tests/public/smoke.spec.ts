import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(response.body.total).toBe(15);
    expect(response.body.hasNext).toBe(true);
  });

  it('accepts custom page and limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=2&limit=3');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(2);
    expect(response.body.limit).toBe(3);
    expect(response.body.items.length).toBe(3);
    expect(response.body.hasNext).toBe(true);
  });

  it('returns correct pagination for last page', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=3&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(3);
    expect(response.body.limit).toBe(5);
    expect(response.body.items.length).toBe(5);
    expect(response.body.hasNext).toBe(false);
  });

  it('validates page parameter - rejects negative values', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page must be a positive integer');
  });

  it('validates page parameter - rejects zero', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page must be a positive integer');
  });

  it('validates page parameter - rejects non-numeric', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Page must be a positive integer');
  });

  it('validates limit parameter - rejects negative values', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit must be a positive integer not exceeding 100');
  });

  it('validates limit parameter - rejects zero', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit must be a positive integer not exceeding 100');
  });

  it('validates limit parameter - rejects excessive values', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=101');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit must be a positive integer not exceeding 100');
  });

  it('validates limit parameter - rejects non-numeric', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toBe('Limit must be a positive integer not exceeding 100');
  });

  it('does not skip or duplicate rows across pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get first page
    const page1Response = await request(app).get('/inventory?page=1&limit=5');
    expect(page1Response.status).toBe(200);
    
    // Get second page
    const page2Response = await request(app).get('/inventory?page=2&limit=5');
    expect(page2Response.status).toBe(200);
    
    // Extract item IDs
    const page1Ids = page1Response.body.items.map((item: { id: number }) => item.id);
    const page2Ids = page2Response.body.items.map((item: { id: number }) => item.id);
    
    // Check no overlap
    const overlappingIds = page1Ids.filter((id: number) => page2Ids.includes(id));
    expect(overlappingIds).toEqual([]);
    
    // Check correct IDs (should be 1-5 for page 1, 6-10 for page 2)
    expect(page1Ids).toEqual([1, 2, 3, 4, 5]);
    expect(page2Ids).toEqual([6, 7, 8, 9, 10]);
  });
});
