import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import type { Express } from 'express';

let server: { close: () => void } | null = null;
let app: Express | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  const { app: appInstance } = await import('../../dist/server.js');
  app = appInstance as Express;
  server = app.listen(3000, () => {
    // Server started
  }) as unknown as { close: () => void };
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    expect(true).toBe(true);
  });
});