import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs/promises';
import SqlJs from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

// Database setup
type Database = import('sql.js').Database;
let db: Database | null = null;

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

// Initialize database
async function initDatabase(): Promise<void> {
  const dataDir = path.join(__dirname, '..', 'data');
  const dbPath = path.join(dataDir, 'submissions.sqlite');

  try {
    await fs.access(dbPath);
    const fileBuffer = await fs.readFile(dbPath);
    db = new SqlJs(new Uint8Array(fileBuffer));
  } catch {
    db = new SqlJs();
    const schema = await fs.readFile(path.join(__dirname, '..', 'db', 'schema.sql'), 'utf-8');
    db.exec(schema);
    await saveDatabase();
  }
}

// Save database to disk
async function saveDatabase(): Promise<void> {
  if (!db) return;
  
  const dataDir = path.join(__dirname, '..', 'data');
  const dbPath = path.join(dataDir, 'submissions.sqlite');
  
  await fs.mkdir(dataDir, { recursive: true });
  const data = db.export();
  await fs.writeFile(dbPath, Buffer.from(data));
}

// Validate form data
function validateFormData(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Required field checks
  if (!data.firstName.trim()) errors.firstName = 'First name is required';
  if (!data.lastName.trim()) errors.lastName = 'Last name is required';
  if (!data.streetAddress.trim()) errors.streetAddress = 'Street address is required';
  if (!data.city.trim()) errors.city = 'City is required';
  if (!data.stateProvince.trim()) errors.stateProvince = 'State/Province is required';
  if (!data.postalCode.trim()) errors.postalCode = 'Postal code is required';
  if (!data.country.trim()) errors.country = 'Country is required';
  if (!data.email.trim()) errors.email = 'Email is required';
  if (!data.phone.trim()) errors.phone = 'Phone number is required';

  // Email validation
  if (data.email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.email = 'Please enter a valid email address';
  }

  // Phone validation (digits, spaces, parentheses, dashes, and leading +)
  if (data.phone && !/^\+?[\d\s\-()]+$/.test(data.phone)) {
    errors.phone = 'Please enter a valid phone number';
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && !/^[a-zA-Z0-9\s-]+$/.test(data.postalCode)) {
    errors.postalCode = 'Please enter a valid postal code';
  }

  return errors;
}

// Middleware
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, '..', 'public')));

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', { 
    errors: {}, 
    data: {},
    pageTitle: 'Contact Us'
  });
});

app.post('/submit', async (req: Request, res: Response) => {
  if (!db) {
    return res.status(500).send('Database not initialized');
  }

  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateFormData(formData);

  if (Object.keys(errors).length > 0) {
    return res.status(400).render('form', {
      errors,
      data: formData,
      pageTitle: 'Contact Us'
    });
  }

  try {
    db.run(
      `INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]
    );
    
    await saveDatabase();
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('Error saving submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', { pageTitle: 'Thank You' });
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);

// Initialize database and start server
initDatabase()
  .then(() => {
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  })
  .catch((error) => {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  });