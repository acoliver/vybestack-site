declare module 'sql.js' {
  interface Database {
    exec(sql: string): void;
    run(sql: string, params?: unknown[]): void;
    export(): Uint8Array;
    close(): void;
  }

  type SqlJsStatic = {
    new (buffer?: Uint8Array): Database;
    locateFile: (file: string) => string;
  };

  const SqlJs: SqlJsStatic;
  export default SqlJs;
  export { Database };
}