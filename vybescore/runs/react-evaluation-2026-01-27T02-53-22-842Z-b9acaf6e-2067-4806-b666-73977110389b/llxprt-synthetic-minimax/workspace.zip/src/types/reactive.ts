/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  _deps?: Set<Observer<unknown>>
  _subs?: Set<Observer<unknown>>
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let currentObserver: ObserverR | undefined

export function getCurrentObserver(): ObserverR | undefined {
  return currentObserver
}

export function setCurrentObserver(obs: ObserverR | undefined): ObserverR | undefined {
  const prev = currentObserver
  currentObserver = obs
  return prev
}

export function updateObserver<T>(observer: Observer<T>): void {
  const prev = currentObserver
  currentObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    currentObserver = prev
  }
}

export function registerDependency(dep: ObserverR | Observer<unknown>) {
  const active = getCurrentObserver()
  if (active && active !== dep) {
    active._deps = active._deps || new Set()
    active._deps.add(dep as Observer<unknown>)
    
    const depObserver = dep as Observer<unknown>
    if (!depObserver._subs) {
      depObserver._subs = new Set()
    }
    depObserver._subs.add(active as Observer<unknown>)
  }
}

export function notifySubscribers(observer: Observer<unknown>) {
  if (observer._subs) {
    observer._subs.forEach(sub => {
      if (typeof sub.updateFn === 'function') {
        updateObserver(sub as Observer<unknown>)
      }
    })
  }
}

export function notifyAll(observers: Set<Observer<unknown>>) {
  observers.forEach(obs => {
    if (typeof obs.updateFn === 'function') {
      updateObserver(obs as Observer<unknown>)
    }
  })
}
