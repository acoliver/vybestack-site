/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  getCurrentObserver,
  EqualFn,
  registerDependency,
  notifySubscribers
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const observer: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    _subs: new Set()
  }

  const getter: GetterFn<T> = () => {
    // When computed value is accessed, establish dependency
    const active = getCurrentObserver()
    if (active && active !== observer) {
      registerDependency(observer)
    }
    
    // Evaluate the computed value
    const newValue = updateFn(observer.value)
    const hasChanged = observer.value !== newValue
    
    // Update stored value
    observer.value = newValue
    
    // Notify subscribers if value changed
    if (hasChanged && observer._subs) {
      notifySubscribers(observer as Observer<unknown>)
    }
    
    return observer.value!
  }

  return getter
}
