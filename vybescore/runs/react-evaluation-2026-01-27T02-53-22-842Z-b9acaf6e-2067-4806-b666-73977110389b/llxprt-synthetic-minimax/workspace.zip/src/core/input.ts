/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getCurrentObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options,
  registerDependency,
  updateObserver
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const subject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
  }

  const read: GetterFn<T> = () => {
    const active = getCurrentObserver()
    if (active) {
      subject.observer = active
      registerDependency(active)
    }
    return subject.value
  }

  const write: SetterFn<T> = (nextValue) => {
    subject.value = nextValue
    // Notify all dependents when value changes
    if (subject.observer) {
      updateObserver(subject.observer as Observer<unknown>)
    }
    return subject.value
  }

  return [read, write]
}
