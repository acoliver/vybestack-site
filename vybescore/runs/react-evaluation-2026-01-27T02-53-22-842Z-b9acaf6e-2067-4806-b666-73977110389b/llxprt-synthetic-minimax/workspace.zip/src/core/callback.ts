/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setCurrentObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
    _subs: new Set()
  }

  // Execute callback to establish dependencies
  const prev = setCurrentObserver(observer)
  try {
    observer.value = updateFn(observer.value)
  } finally {
    setCurrentObserver(prev)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear subscriptions
    observer._subs?.clear()
    observer.updateFn = () => observer.value!
  }
}
