import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { app, server } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Wait for server to be ready
  await new Promise(resolve => setTimeout(resolve, 1000));
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/');
    expect(response.status).toBe(200);
    
    expect(response.text).toBeDefined();
    
    const $ = cheerio.load(response.text);
    
    // Check for all required form fields
    expect($('#firstName')).toHaveLength(1);
    expect($('#lastName')).toHaveLength(1);
    expect($('#streetAddress')).toHaveLength(1);
    expect($('#city')).toHaveLength(1);
    expect($('#stateProvince')).toHaveLength(1);
    expect($('#postalCode')).toHaveLength(1);
    expect($('#country')).toHaveLength(1);
    expect($('#email')).toHaveLength(1);
    expect($('#phone')).toHaveLength(1);
    
    // Check form action
    expect($('form').attr('action')).toBe('/submit');
    expect($('form').attr('method')).toBe('post');
  });

  it('persists submission and redirects', async () => {
    // Clean up database if exists
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Test City',
      stateProvince: 'Test State',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958'
    };
    
    // Submit form
    const response = await request(app)
      .post('/submit')
      .type('form')
      .send(formData)
      .expect(302);
      
    // Check redirect
    expect(response.headers.location).toBe('/thank-you');
    
    // Check database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
