declare module 'sql.js' {
  export interface Database {
    run(sql: string, ...params: unknown[]): unknown;
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
    exec(sql: string): unknown[];
    create_function(name: string, fn: (...args: unknown[]) => unknown): void;
    create_aggregate(name: string, config: Record<string, unknown>): void;
  }

  export interface Statement {
    run(...params: unknown[]): unknown;
    free(): void;
    step(): boolean;
    get(): unknown[];
    getAsObject(params: Record<string, unknown>): Record<string, unknown>;
    bind(params: unknown[]): void;
  }

  export interface SqlJsStatic {
    Database: new (data?: Uint8Array) => Database;
  }

  function initSqlJs(config?: {
    locateFile?: (file: string) => string;
  }): Promise<SqlJsStatic>;

  export = initSqlJs;
}