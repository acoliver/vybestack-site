#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, ReportOptions, ReportFormatter } from '../types.js';
import { markdownFormatter } from '../formats/markdown.js';
import { textFormatter } from '../formats/text.js';

interface CLIParseResult {
  dataPath: string;
  format: string;
  outputPath: string | null;
  includeTotals: boolean;
}

function parseArguments(args: string[]): CLIParseResult {
  if (args.length < 2) {
    throw new Error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
  }

  const result: CLIParseResult = {
    dataPath: args[0],
    format: '',
    outputPath: null,
    includeTotals: false,
  };

  let i = 1;
  while (i < args.length) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        throw new Error('--format requires a value');
      }
      result.format = args[i + 1];
      i += 2;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        throw new Error('--output requires a value');
      }
      result.outputPath = args[i + 1];
      i += 2;
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
      i += 1;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!result.format) {
    throw new Error('--format is required');
  }

  return result;
}

function validateReportData(data: unknown): ReportData {
  if (typeof data !== 'object' || data === null) {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid report data: title must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid report data: summary must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report data: entries must be an array');
  }

  for (const [index, entry] of obj.entries.entries()) {
    if (typeof entry !== 'object' || entry === null) {
      throw new Error(`Invalid report data: entry ${index} must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid report data: entry ${index} label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid report data: entry ${index} amount must be a number`);
    }
  }

  return data as ReportData;
}

function loadReportData(path: string): ReportData {
  try {
    const content = readFileSync(path, 'utf-8');
    const data = JSON.parse(content);
    return validateReportData(data);
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error(`Invalid JSON in ${path}: ${error.message}`);
    }
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${path}`);
    }
    throw error;
  }
}

function getFormatter(format: string): ReportFormatter {
  switch (format.toLowerCase()) {
    case 'markdown':
      return markdownFormatter;
    case 'text':
      return textFormatter;
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main(): void {
  try {
    const args = process.argv.slice(2);
    const { dataPath, format, outputPath, includeTotals } = parseArguments(args);

    const data = loadReportData(dataPath);
    const formatter = getFormatter(format);

    const options: ReportOptions = { includeTotals };
    const output = formatter.render(data, options);

    if (outputPath) {
      writeFileSync(outputPath, output, 'utf-8');
    } else {
      console.log(output);
    }
  } catch (error) {
    if (error instanceof Error) {
      console.error(error.message);
      process.exit(1);
    } else {
      console.error('Unknown error occurred');
      process.exit(1);
    }
  }
}

main();