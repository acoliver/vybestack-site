import type { ReportRenderer, ReportData, RenderOptions } from '../types.js';
import { calculateTotal, formatAmount } from '../utils.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push(''); // blank line

  // Summary
  lines.push(data.summary);
  lines.push(''); // blank line

  // Entries section
  lines.push('## Entries');

  // Entry list
  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
  }

  // Total if requested
  if (options.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push('');
    lines.push(`**Total:** ${formatAmount(total)}`);
  }

  return lines.join('\n');
}

export const markdownRenderer: ReportRenderer = {
  render: renderMarkdown,
};