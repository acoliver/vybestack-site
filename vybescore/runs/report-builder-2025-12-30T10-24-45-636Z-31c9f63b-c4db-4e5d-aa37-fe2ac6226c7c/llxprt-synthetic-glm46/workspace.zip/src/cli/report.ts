#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { validateReportData } from '../utils.js';
import { formatters } from '../formatters.js';
import type { FormatType, CliOptions, RenderOptions } from '../types.js';

function parseArguments(): { dataFile: string; options: CliOptions } {
  const args = process.argv.slice(2);

  if (args.length < 1) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const options: CliOptions = { format: 'markdown' }; // default will be overwritten

  // Parse arguments manually
  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    if (arg === '--format') {
      if (!nextArg) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      options.format = nextArg as FormatType;
      i++; // skip next arg
    } else if (arg === '--output') {
      if (!nextArg) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      options.output = nextArg;
      i++; // skip next arg
    } else if (arg === '--includeTotals') {
      options.includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  return { dataFile, options };
}

function validateFormat(format: string): format is FormatType {
  return format === 'markdown' || format === 'text';
}

function main(): void {
  try {
    const { dataFile, options } = parseArguments();

    // Validate format
    if (!validateFormat(options.format)) {
      console.error(`Error: Unsupported format: ${options.format}`);
      process.exit(1);
    }

    // Read and parse JSON data
    let dataJson: unknown;
    try {
      const fileContent = readFileSync(dataFile, 'utf8');
      dataJson = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error reading file ${dataFile}:`, error instanceof Error ? error.message : String(error));
      process.exit(1);
    }

    // Validate data structure
    const reportData: ReportData = validateReportData(dataJson);

    // Get appropriate renderer
    const renderer = formatters[options.format];

    // Render the report
    const renderOptions: RenderOptions = { includeTotals: !!options.includeTotals };
    const output = renderer.render(reportData, renderOptions);

    // Output to file or stdout
    if (options.output) {
      try {
        writeFileSync(options.output, output);
        console.log(`Report written to ${options.output}`);
      } catch (error) {
        console.error(`Error writing to file ${options.output}:`, error instanceof Error ? error.message : String(error));
        process.exit(1);
      }
    } else {
      console.log(output);
    }

  } catch (error) {
    console.error('Error:', error instanceof Error ? error.message : String(error));
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
