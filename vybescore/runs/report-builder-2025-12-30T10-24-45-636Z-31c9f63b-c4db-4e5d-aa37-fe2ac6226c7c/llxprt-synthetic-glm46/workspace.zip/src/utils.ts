import type { ReportData, ReportEntry } from './types.js';

export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title field');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary field');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries field');
  }

  const entries = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entry at index ${index} is not an object`);
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid label`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid JSON: entry at index ${index} has invalid amount`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}