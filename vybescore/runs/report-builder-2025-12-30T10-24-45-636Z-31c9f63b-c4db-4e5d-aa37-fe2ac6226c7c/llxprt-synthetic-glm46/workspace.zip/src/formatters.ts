import type { ReportRenderer, FormatType } from './types.js';
import { markdownRenderer } from './formats/markdown.js';
import { textRenderer } from './formats/text.js';

export const formatters: Record<FormatType, ReportRenderer> = {
  markdown: markdownRenderer,
  text: textRenderer,
};