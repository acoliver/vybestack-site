import { readFileSync } from 'node:fs';
import { createWriteStream } from 'node:fs';
import { resolve, basename } from 'node:path';
import { formatters } from '../formats/index.js';
import type { ReportData } from '../types/report.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  const parsed: ParsedArgs = {
    dataFile,
    format: '',
    includeTotals: false
  };

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      parsed.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      parsed.outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      parsed.includeTotals = true;
    } else {
      console.error(`Unknown argument: ${arg}`);
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
  }

  if (!parsed.format) {
    console.error('Error: --format is required');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  return parsed;
}

function validateAndParseData(jsonContent: string): ReportData {
  try {
    const data = JSON.parse(jsonContent) as ReportData;
    
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid or missing "title" field');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid or missing "summary" field');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid or missing "entries" array');
    }
    
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Entry at index ${i} is invalid`);
      }
      
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry at index ${i} is missing "label" field`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry at index ${i} has invalid "amount" field`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
      process.exit(1);
    }
    throw error;
  }
}

function main(): void {
  const args = process.argv.slice(2);
  const { dataFile, format, outputPath, includeTotals } = parseArgs(args);
  
  try {
    // Read and validate JSON data
    const resolvedPath = resolve(dataFile);
    const jsonContent = readFileSync(resolvedPath, 'utf8');
    const data = validateAndParseData(jsonContent);
    
    // Check if format is supported
    const formatter = formatters[format];
    if (!formatter) {
      console.error(`Error: Unsupported format: ${format}`);
      process.exit(1);
    }
    
    // Generate report
    const report = formatter.format(data, { includeTotals });
    
    // Write output
    if (outputPath) {
      const outputStream = createWriteStream(resolve(outputPath));
      outputStream.write(report);
      outputStream.end();
    } else {
      process.stdout.write(report);
    }
    
  } catch (error) {
    if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('An unexpected error occurred');
    }
    process.exit(1);
  }
}

main();