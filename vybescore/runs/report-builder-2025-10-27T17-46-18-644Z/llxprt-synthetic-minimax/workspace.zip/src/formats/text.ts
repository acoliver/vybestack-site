import { ReportData, FormatOptions, Formatter } from '../types/report.js';

export const renderText: Formatter = {
  format(data: ReportData, options: FormatOptions): string {
    const { title, summary, entries } = data;
    const amounts = entries.map(entry => entry.amount);
    const total = amounts.reduce((sum, amount) => sum + amount, 0);
    const formattedTotal = total.toFixed(2);

    let output = `${title}\n`;
    output += `${summary}\n\n`;
    output += `Entries:\n\n`;

    for (const entry of entries) {
      const formattedAmount = entry.amount.toFixed(2);
      output += `- ${entry.label}: $${formattedAmount}\n`;
    }

    if (options.includeTotals) {
      output += `\nTotal: $${formattedTotal}\n`;
    }

    return output;
  }
};