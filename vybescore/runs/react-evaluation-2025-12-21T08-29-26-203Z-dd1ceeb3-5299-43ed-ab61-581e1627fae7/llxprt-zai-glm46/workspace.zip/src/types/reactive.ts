/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  onInvalidate?: () => void
  dependencies?: Set<ObserverR>
  observers?: Set<ObserverR>
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<ObserverR>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined
let trackingDependencies = false

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  trackingDependencies = true
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
    trackingDependencies = false
  }
}

export function trackDependency(observer: ObserverR): void {
  if (trackingDependencies && activeObserver && activeObserver !== observer) {
    if (!activeObserver.dependencies) {
      activeObserver.dependencies = new Set()
    }
    activeObserver.dependencies.add(observer)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  // First, notify direct observers
  const toNotify = new Set<ObserverR>()
  
  for (const observer of subject.observers) {
    toNotify.add(observer)
  }
  
  // Then, add any observers that depend on these observers
  const workList = [...toNotify]
  while (workList.length > 0) {
    const observer = workList.shift()!
    if (observer.dependencies) {
      for (const dep of observer.dependencies) {
        if (!toNotify.has(dep)) {
          toNotify.add(dep)
          workList.push(dep)
        }
      }
    }
    if (observer.observers) {
      for (const obs of observer.observers) {
        if (!toNotify.has(obs)) {
          toNotify.add(obs)
          workList.push(obs)
        }
      }
    }
  }
  
  // Finally, notify all observers
  for (const observer of toNotify) {
    if (observer.onInvalidate) {
      observer.onInvalidate()
    }
  }
}
