/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      // Track this computed as a dependency of the current observer
      if (!observer.dependencies) {
        observer.dependencies = new Set()
      }
      observer.dependencies.add(o)
      
      // Add the current observer to this computed's observers set
      o.observers = o.observers || new Set()
      o.observers.add(observer)
    }
    return o.value!
  }
  
  // Set up onInvalidate to recompute when dependencies change
  o.onInvalidate = () => {
    updateObserver(o)
  }
  
  // Initialize observers set
  o.observers = new Set()
  
  // Initial computation
  updateObserver(o)
  
  return getter
}
