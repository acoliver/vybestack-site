/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver, ObserverR } from '../types/reactive.js'

// Store subjects for cleanup
const callbackSubjects = new Set<ObserverR>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  callbackSubjects.add(observer)
  
  // Set up onInvalidate to re-run the effect
  observer.onInvalidate = () => {
    if (callbackSubjects.has(observer)) {
      updateObserver(observer)
    }
  }
  
  // Run the initial effect
  updateObserver(observer)
  
  return () => {
    callbackSubjects.delete(observer)
    observer.onInvalidate = undefined
    observer.updateFn = () => value!
  }
}
