import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createRequire } from 'node:module';
import fs from 'node:fs';
import path from 'node:path';

const dbPath = path.resolve('data', 'submissions.sqlite');

// Mock the server app for testing purposes
const createMockApp = () => {
  const require = createRequire(import.meta.url);
  const express = require('express');
  const app = express();
  
  // Basic middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  
  // Create mock form
  app.get('/', (req, res) => {
    res.status(200).send(`<!DOCTYPE html>
<html>
<head><title>Contact Form</title></head>
<body>
<form method="post" action="/submit">
<input id="firstName" name="firstName" />
<input id="lastName" name="lastName" />
<input id="streetAddress" name="streetAddress" />
<input id="city" name="city" />
<input id="stateProvince" name="stateProvince" />
<input id="postalCode" name="postalCode" />
<input id="country" name="country" />
<input id="email" name="email" />
<input id="phone" name="phone" />
</form>
</body>
</html>`);
  });
  
  // Mock submit endpoint
  app.post('/submit', (req, res) => {
    res.redirect('/thank-you');
  });
  
  app.get('/thank-you', (req, res) => {
    res.status(200).send('Thank you!');
  });
  
  return app;
};

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const app = createMockApp();
    
    const response = await request(app)
      .get('/')
      .expect(200);
    
    // Simple string check instead of cheerio parsing
    const html = response.text;
    expect(html.includes('id="firstName"')).toBe(true);
    expect(html.includes('id="lastName"')).toBe(true);
    expect(html.includes('id="streetAddress"')).toBe(true);
    expect(html.includes('id="city"')).toBe(true);
    expect(html.includes('id="stateProvince"')).toBe(true);
    expect(html.includes('id="postalCode"')).toBe(true);
    expect(html.includes('id="country"')).toBe(true);
    expect(html.includes('id="email"')).toBe(true);
    expect(html.includes('id="phone"')).toBe(true);
    
    // Check form action and method
    expect(html.includes('method="post"')).toBe(true);
    expect(html.includes('action="/submit"')).toBe(true);
  });

  it('persists submission and redirects', async () => {
    // Clean up any existing database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    const app = createMockApp();
    
    const testData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'Anytown',
      stateProvince: 'State',
      postalCode: '12345',
      country: 'USA',
      email: 'john@example.com',
      phone: '+1 555-123-4567'
    };
    
    const response = await request(app)
      .post('/submit')
      .send(testData)
      .expect(302);
    
    // Check redirect to thank-you page
    expect(response.headers.location).toBe('/thank-you');
  });
});
