import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { Database } from 'sql.js';

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// In-memory database
let db: Database | null = null;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.resolve(process.cwd(), 'public')));

// Configure EJS
app.set('view engine', 'ejs');
// Use absolute path to templates for compatibility with tsx
app.set('views', path.resolve(process.cwd(), 'src', 'templates'));

// Validation functions
function validateForm(data: Record<string, string>): { isValid: boolean; errors: Record<string, string> } {
  const errors: Record<string, string> = {};

  // Required field validation
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  requiredFields.forEach(field => {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  });

  // Email validation
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Phone validation (international formats allowed)
  if (data.phone && data.phone.trim() !== '') {
    const phoneRegex = /^\+?[\d\s\-()]{7,}$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Postal code validation (alphanumeric)
  if (data.postalCode && data.postalCode.trim() !== '') {
    const postalRegex = /^[A-Za-z0-9\s-]{3,10}$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors
  };
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    const { default: initSqlJs } = await import('sql.js');
    
    // Use absolute path to the wasm file directly
    const wasmPath = path.resolve(process.cwd(), 'node_modules/sql.js/dist/sql-wasm.wasm');
    
    const SQL = await initSqlJs({
      locateFile: () => wasmPath
    });

    // Check if database file exists
    const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    
    if (fs.existsSync(dbPath)) {
      const dbBuffer = fs.readFileSync(dbPath);
      const SQLClass = SQL.Database;
      db = new SQLClass(new Uint8Array(dbBuffer));
    } else {
      const SQLClass = SQL.Database;
      db = new SQLClass();
      
      // Create table from schema
      const schemaPath = path.resolve(process.cwd(), 'db', 'schema.sql');
      const schema = fs.readFileSync(schemaPath, 'utf8');
      db.exec(schema);
    }
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const dbPath = path.resolve(process.cwd(), 'data', 'submissions.sqlite');
    const dbBuffer = db.export();
    fs.writeFileSync(dbPath, Buffer.from(dbBuffer));
  }
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('contact', {
    errors: {},
    values: {},
    title: 'Contact Form - Definitely Not A Scam'
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData = req.body;
  const validation = validateForm(formData);

  if (!validation.isValid) {
    // Return with errors
    res.status(400).render('contact', {
      errors: validation.errors,
      values: formData,
      title: 'Contact Form - Please Fix Errors'
    });
    return;
  }

  // Insert into database
  if (db) {
    try {
      const stmt = db.prepare(`
        INSERT INTO submissions (
          first_name, last_name, street_address, city, 
          state_province, postal_code, country, email, phone
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);

      stmt.run([
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone
      ]);

      stmt.free();
      saveDatabase();
      
      res.redirect('/thank-you');
    } catch (error) {
      console.error('Database error:', error);
      res.status(500).render('contact', {
        errors: { general: 'Server error. Please try again.' },
        values: formData,
        title: 'Contact Form - Server Error'
      });
    }
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you', {
    title: 'Thank You - Why Did You Give Your Info?',
    firstName: 'Friend' // Default friendly greeting
  });
});

// Graceful shutdown
function gracefulShutdown(): void {
  console.log("\nShutting down gracefully...");
  
  if (db) {
    try {
      saveDatabase();
      console.log("Database saved.");
      db.close();
      console.log("Database connection closed.");
    } catch (error) {
      console.error("Error during shutdown:", error);
    }
  }

  process.exit(0);
}

// Start server
async function startServer(): Promise<void> {
  await initializeDatabase();

  app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
    console.log('Press Ctrl+C to shut down gracefully');
  });

  // Handle graceful shutdown
  process.on('SIGTERM', gracefulShutdown);
  process.on('SIGINT', gracefulShutdown);

  // For testing purposes, export server instance
  if (typeof module !== 'undefined') {
    module.exports = app;
  }
}

startServer().catch(error => {
  console.error('Failed to start server:', error);
  process.exit(1);
});
