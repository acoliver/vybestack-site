declare module 'sql.js' {
  export class Database {
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
    exec(sql: string): void;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): void;
    get(params?: unknown[]): unknown[] | undefined;
    free(): void;
  }

  export interface SQLJsStatic {
    Database: new (buffer?: Uint8Array) => Database;
  }

  export interface SQLJsConfig {
    locateFile?: (file: string) => string;
  }

  interface InitConfig {
    locateFile?: (file: string) => string;
  }

  const initSqlJs: (config?: InitConfig) => Promise<SQLJsStatic>;
  export default initSqlJs;
}