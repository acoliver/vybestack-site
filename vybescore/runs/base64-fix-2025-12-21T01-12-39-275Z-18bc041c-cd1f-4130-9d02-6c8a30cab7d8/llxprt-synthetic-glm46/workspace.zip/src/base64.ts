const BASE64_ALPHABET_REGEX = /^[A-Za-z0-9+/]*={0,2}$/;
const INVALID_CHAR_REGEX = /[^A-Za-z0-9+/=]/;

/**
 * Encode plain text to Base64 using the standard alphabet with padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using the standard alphabet.
 * Validates input and throws an error for invalid Base64.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: empty or not a string');
  }

  // Remove whitespace for validation
  const sanitizedInput = input.replace(/\s/g, '');
  
  // Check for invalid characters
  if (INVALID_CHAR_REGEX.test(sanitizedInput)) {
    throw new Error('Invalid Base64 input: contains characters outside the Base64 alphabet');
  }

  // Check if it's at least a plausible Base64 format
  if (!BASE64_ALPHABET_REGEX.test(sanitizedInput)) {
    throw new Error('Invalid Base64 input: malformed structure');
  }

  // Validate padding rules
  validatePadding(sanitizedInput);
  validateLength(sanitizedInput);

  try {
    const result = Buffer.from(sanitizedInput, 'base64').toString('utf8');
    
    // Validate the result is valid UTF-8
    // If the decoded buffer contains invalid UTF-8 sequences,
    // Buffer.from(...).toString('utf8') will replace them with replacement characters
    if (result.includes('\uFFFD')) {
      throw new Error('Invalid Base64 input: contains invalid UTF-8 sequences');
    }
    
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}

/**
 * Validates Base64 padding characters and position.
 */
function validatePadding(input: string): void {
  const paddingMatch = input.match(/=/g);
  if (paddingMatch && paddingMatch.length > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }

  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1 && input.substring(paddingIndex).replace(/=/g, '') !== '') {
    // Verify padding is only at the end
    throw new Error('Invalid Base64 input: padding not at the end');
  }
}

/**
 * Validates Base64 string length.
 */
function validateLength(input: string): void {
  // Check if string has padding
  const hasPadding = input.includes('=');
  
  // If no padding, the string length is valid or can be made valid
  // by adding implicit padding (up to 2 '=' characters)
  if (!hasPadding && input.length % 4 !== 0) {
    // Calculate the required padding
    const requiredPadding = 4 - (input.length % 4);
    if (requiredPadding > 2) {
      throw new Error('Invalid Base64 input: incorrect length');
    }
  } else if (hasPadding && input.length % 4 !== 0) {
    // With padding, the string must be a multiple of 4
    throw new Error('Invalid Base64 input: incorrect length');
  }
}
