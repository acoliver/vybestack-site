import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import initSqlJs from 'sql.js';

let app: unknown;
let db: import('sql.js').Database | null = null;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Ensure data directory exists
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }
  
  // Initialize SQL.js and create database
  const SQL = await initSqlJs();
  db = new SQL.Database();
  
  // Import the app after database is ready
  const module = await import('../../src/server.js');
  app = module.default;
});

afterAll(() => {
  if (db) {
    db.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app as string)
      .get('/')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    // Check for all form fields with proper labels and attributes
    expect($('input[name="firstName"]')).toHaveLength(1);
    expect($('label[for="firstName"]').text()).toBe('First name');
    
    expect($('input[name="lastName"]')).toHaveLength(1);
    expect($('label[for="lastName"]').text()).toBe('Last name');
    
    expect($('input[name="streetAddress"]')).toHaveLength(1);
    expect($('label[for="streetAddress"]').text()).toBe('Street address');
    
    expect($('input[name="city"]')).toHaveLength(1);
    expect($('label[for="city"]').text()).toBe('City');
    
    expect($('input[name="stateProvince"]')).toHaveLength(1);
    expect($('label[for="stateProvince"]').text()).toBe('State / Province / Region');
    
    expect($('input[name="postalCode"]')).toHaveLength(1);
    expect($('label[for="postalCode"]').text()).toBe('Postal / Zip code');
    
    expect($('input[name="country"]')).toHaveLength(1);
    expect($('label[for="country"]').text()).toBe('Country');
    
    expect($('input[name="email"]')).toHaveLength(1);
    expect($('label[for="email"]').text()).toBe('Email');
    
    expect($('input[name="phone"]')).toHaveLength(1);
    expect($('label[for="phone"]').text()).toBe('Phone number');
    
    // Check for submit button
    expect($('button[type="submit"]')).toHaveLength(1);
    
    // Check that form posts to /submit
    expect($('form[action="/submit"]')).toHaveLength(1);
  });

  it('persists submission and redirects', async () => {
    // Clean database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'John',
      lastName: 'Doe',
      streetAddress: '123 Main St',
      city: 'London',
      stateProvince: 'England',
      postalCode: 'SW1A 1AA',
      country: 'United Kingdom',
      email: 'john.doe@example.com',
      phone: '+44 20 7946 0958',
    };

    const response = await request(app as string)
      .post('/submit')
      .send(formData)
      .expect(302);

    // Verify redirect to thank-you page
    expect(response.headers.location).toContain('/thank-you');
    expect(response.headers.location).toContain('firstName=John');

    // Verify database file was created
    expect(fs.existsSync(dbPath)).toBe(true);
  });

  it('shows validation errors for invalid input', async () => {
    const response = await request(app as string)
      .post('/submit')
      .send({
        firstName: '',
        lastName: '',
        email: 'not-an-email',
        phone: 'invalid-phone!@#',
      })
      .expect(400);

    const $ = cheerio.load(response.text);
    
    // Check for error messages
    expect($('.error-list').length).toBeGreaterThan(0);
    const errorText = $('.error-list').text();
    expect(errorText).toMatch(/required|email|phone/i);
  });

  it('renders thank-you page with user name', async () => {
    const response = await request(app as string)
      .get('/thank-you?firstName=Alice')
      .expect(200);

    const $ = cheerio.load(response.text);
    
    expect($('.thankyou-card h1').text()).toContain('Alice');
    expect($('.thankyou-card').text()).toMatch(/stranger|internet|identity/i);
  });

  it('handles international phone and postal formats', async () => {
    // Clean database
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const formData = {
      firstName: 'María',
      lastName: 'García',
      streetAddress: 'Av. Corrientes 1234',
      city: 'Buenos Aires',
      stateProvince: 'Buenos Aires',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'maria.garcia@example.com',
      phone: '+54 9 11 1234-5678',
    };

    const response = await request(app as string)
      .post('/submit')
      .send(formData)
      .expect(302);

    expect(response.headers.location).toContain('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
