import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import initSqlJs, { Database } from 'sql.js';
import fs from 'node:fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT ? parseInt(process.env.PORT, 10) : 3535;

// Types for form submission
interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

// Database configuration
const DB_DIR = path.resolve(process.cwd(), 'data');
const DB_PATH = path.join(DB_DIR, 'submissions.sqlite');
const SCHEMA_PATH = path.resolve(process.cwd(), 'db', 'schema.sql');

let db: Database | null = null;

// Ensure data directory exists
function ensureDataDirectory(): void {
  if (!fs.existsSync(DB_DIR)) {
    fs.mkdirSync(DB_DIR, { recursive: true });
  }
}

// Initialize database
async function initializeDatabase(): Promise<void> {
  ensureDataDirectory();

  const SQL = await initSqlJs();
  
  // Load existing database or create new one
  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    
    // Read and execute schema
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    
    // Save the new database
    await saveDatabase();
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db) {
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }
}

// Validation functions
function validateRequired(value: string, fieldName: string): ValidationError | null {
  if (!value || value.trim().length === 0) {
    return { field: fieldName, message: `${fieldName} is required.` };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return { field: 'email', message: 'Please enter a valid email address.' };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!phoneRegex.test(phone)) {
    return { field: 'phone', message: 'Please enter a valid phone number.' };
  }
  return null;
}

function validatePostalCode(code: string): ValidationError | null {
  const postalRegex = /^[\d\sA-Za-z-]+$/;
  if (!postalRegex.test(code)) {
    return { field: 'postalCode', message: 'Please enter a valid postal code.' };
  }
  return null;
}

function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  const requiredError = validateRequired(data.firstName, 'First name');
  if (requiredError) errors.push(requiredError);

  const lastNameError = validateRequired(data.lastName, 'Last name');
  if (lastNameError) errors.push(lastNameError);

  const streetError = validateRequired(data.streetAddress, 'Street address');
  if (streetError) errors.push(streetError);

  const cityError = validateRequired(data.city, 'City');
  if (cityError) errors.push(cityError);

  const stateError = validateRequired(data.stateProvince, 'State / Province / Region');
  if (stateError) errors.push(stateError);

  const postalError = validateRequired(data.postalCode, 'Postal code');
  if (postalError) errors.push(postalError);

  const countryError = validateRequired(data.country, 'Country');
  if (countryError) errors.push(countryError);

  const emailRequiredError = validateRequired(data.email, 'Email');
  if (emailRequiredError) {
    errors.push(emailRequiredError);
  } else {
    const emailError = validateEmail(data.email);
    if (emailError) errors.push(emailError);
  }

  const phoneRequiredError = validateRequired(data.phone, 'Phone number');
  if (phoneRequiredError) {
    errors.push(phoneRequiredError);
  } else {
    const phoneError = validatePhone(data.phone);
    if (phoneError) errors.push(phoneError);
  }

  if (data.postalCode) {
    const postalFormatError = validatePostalCode(data.postalCode);
    if (postalFormatError) errors.push(postalFormatError);
  }

  return errors;
}

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve static files
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Routes
app.get('/', (_req, res) => {
  res.render('form', { errors: [], values: {} });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || '',
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    const errorMessages = errors.map((e) => e.message);
    res.status(400).render('form', {
      errors: errorMessages,
      values: formData,
    });
    return;
  }

  // Insert into database
  if (db) {
    db.run(
      `INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province,
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        formData.firstName,
        formData.lastName,
        formData.streetAddress,
        formData.city,
        formData.stateProvince,
        formData.postalCode,
        formData.country,
        formData.email,
        formData.phone,
      ]
    );
    saveDatabase();
  }

  // Redirect to thank you page
  res.redirect(302, `/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function shutdown(): void {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
    db = null;
  }
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function start(): Promise<void> {
  try {
    await initializeDatabase();
    console.log('Database initialized successfully.');

    // Set up EJS - look in src/templates for both dev and compiled builds
    const templatesDir = path.join(process.cwd(), 'src', 'templates');
    app.set('views', templatesDir);
    app.set('view engine', 'ejs');

    const server = app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });

    // Export for testing
    if (process.env.NODE_ENV !== 'production') {
      (globalThis as unknown as { __TEST_SERVER__: { server: unknown; app: unknown; db: Database | null } }).__TEST_SERVER__ = { server, app, db };
    }
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

// Start the server
start();

// Export app for testing
export default app;
