#!/usr/bin/env node

import fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { ReportData, ReportOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  const result: Partial<CliArgs> = {};
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (i === 0) {
      result.dataFile = arg;
    } else if (arg === '--format' && i + 1 < args.length) {
      result.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      result.output = args[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    }
  }
  
  if (!result.dataFile || !result.format) {
    console.error('Error: Missing required arguments');
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }
  
  return {
    dataFile: result.dataFile!,
    format: result.format!,
    output: result.output,
    includeTotals: result.includeTotals || false
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }
  
  const obj = data as Record<string, unknown>;
  
  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: missing or invalid "title" field');
  }
  
  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: missing or invalid "summary" field');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: missing or invalid "entries" field');
  }
  
  for (const entry of obj.entries) {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid data: entry must be an object');
    }
    
    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error('Invalid data: entry missing or invalid "label" field');
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error('Invalid data: entry missing or invalid "amount" field');
    }
  }
  
  return data as ReportData;
}

function main(): void {
  try {
    const args = parseArgs();
    
    if (!fs.existsSync(args.dataFile)) {
      console.error(`Error: File not found: ${args.dataFile}`);
      process.exit(1);
    }
    
    const fileContent = fs.readFileSync(args.dataFile, 'utf-8');
    let rawData: unknown;
    
    try {
      rawData = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file: ${args.dataFile}`);
      console.error((error as Error).message);
      process.exit(1);
    }
    
    const data = validateReportData(rawData);
    const options: ReportOptions = { includeTotals: args.includeTotals };
    
    let output: string;
    
    switch (args.format) {
      case 'markdown':
        output = renderMarkdown.render(data, options);
        break;
      case 'text':
        output = renderText.render(data, options);
        break;
      default:
        console.error(`Error: Unsupported format: ${args.format}`);
        process.exit(1);
    }
    
    if (args.output) {
      fs.writeFileSync(args.output, output, 'utf-8');
      console.log(`Report written to: ${args.output}`);
    } else {
      console.log(output);
    }
    
  } catch (error) {
    console.error('Error:', (error as Error).message);
    process.exit(1);
  }
}

main();
