/**
 * Encode plain text to Base64 using standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws error for invalid Base64 input.
 */
export function decode(input: string): string {
  const trimmedInput = input.trim();
  
  // Validate that the input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(trimmedInput)) {
    throw new Error('Invalid Base64 input: contains non-Base64 characters');
  }

  // Check for invalid padding positions (padding must be at the end)
  if (trimmedInput.includes('=') && !trimmedInput.match(/={1,2}$/)) {
    throw new Error('Invalid Base64 input: padding not at end');
  }

  try {
    // Check if this would result in an empty buffer (which means invalid Base64)
    const buffer = Buffer.from(trimmedInput, 'base64');
    if (buffer.length === 0 && trimmedInput.length > 0) {
      throw new Error('Invalid Base64 input: invalid encoding');
    }
    
    // Let Node.js handle the heavy lifting for validation
    // Node.js will throw an error if the input is not valid Base64
    return buffer.toString('utf8');
  } catch (error) {
    // If Node.js throws due to invalid Base64, provide our error message
    throw new Error('Failed to decode Base64 input');
  }
}
