import { describe, expect, it } from 'vitest';
import { decode, encode } from '../../src/base64.js';

describe('Base64 helpers (public)', () => {
  const HELLO_WORLD = 'aGVsbG8gd29ybGQ=';
  const INVALID_BASE64_ERROR = 'Invalid Base64 input';

  it('encodes plain ASCII text with padding', () => {
    const result = encode('hello');
    expect(result).toBe('aGVsbG8=');
  });

  it('decodes standard Base64 text', () => {
    const result = decode('aGVsbG8=');
    expect(result).toBe('hello');
  });

  it('encodes text without padding when not needed', () => {
    const result = encode('hello world');
    expect(result).toBe(HELLO_WORLD);
  });

  it('decodes Base64 text without padding', () => {
    const result = decode('aGVsbG8gd29ybGQ');
    expect(result).toBe('hello world');
  });

  it('handles empty strings', () => {
    expect(encode('')).toBe('');
    expect(decode('')).toBe('');
  });

  it('handles non-ASCII characters', () => {
    const result = encode('héllo wörld');
    expect(decode(result)).toBe('héllo wörld');
  });

  it('handles padding edge cases', () => {
    expect(encode('A')).toBe('QQ==');
    expect(encode('AB')).toBe('QUI=');
    expect(encode('ABC')).toBe('QUJD');
  });

  it('rejects invalid Base64 characters', () => {
    expect(() => decode('!!!')).toThrow(INVALID_BASE64_ERROR);
    expect(() => decode('aGVsbG8!')).toThrow(INVALID_BASE64_ERROR);
  });

  it('rejects malformed Base64 input', () => {
    expect(() => decode('=')).toThrow();
    expect(() => decode('===')).toThrow(INVALID_BASE64_ERROR);
  });

  it('handles Unicode text correctly', () => {
    const unicode = '\ud83c\udf0d';
    const encoded = encode(unicode);
    const decoded = decode(encoded);
    expect(decoded).toBe(unicode);
  });
});
