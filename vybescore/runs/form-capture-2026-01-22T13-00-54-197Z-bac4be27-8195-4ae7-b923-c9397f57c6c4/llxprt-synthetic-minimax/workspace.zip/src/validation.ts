export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export interface ContactData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
}

export class ContactValidator {
  static validateEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
  }

  static validatePhone(phone: string): boolean {
    // Remove common formatting characters
    const cleaned = phone.replace(/[\s\-()@]/g, '');
    // Should contain mostly digits, allow leading + for international
    const phoneRegex = /^[+]?[0-9\s\-()@]{7,20}$/;
    return phoneRegex.test(phone) && cleaned.replace(/@/g, '').length >= 7;
  }

  static validatePostalCode(postalCode: string): boolean {
    // Accept alphanumeric strings, allow spaces for UK format
    const cleaned = postalCode.replace(/\s/g, '');
    return /^[A-Za-z0-9]{3,10}$/.test(cleaned);
  }

  static validateContact(data: ContactData): ValidationResult {
    const errors: ValidationError[] = [];

    // Required field validation
    const requiredFields = [
      'firstName', 'lastName', 'streetAddress', 'city',
      'stateProvinceRegion', 'postalZipCode', 'country', 'email', 'phoneNumber'
    ];

    requiredFields.forEach(field => {
      const fieldKey = field as keyof ContactData;
      const value = data[fieldKey]?.toString().trim();
      if (!value) {
        errors.push({
          field,
          message: `${this.getFieldDisplayName(field)} is required`
        });
      }
    });

    // Specific field validation
    if (data.email && !this.validateEmail(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    if (data.phoneNumber && !this.validatePhone(data.phoneNumber)) {
      errors.push({
        field: 'phoneNumber',
        message: 'Please enter a valid phone number'
      });
    }

    if (data.postalZipCode && !this.validatePostalCode(data.postalZipCode)) {
      errors.push({
        field: 'postalZipCode',
        message: 'Please enter a valid postal/zip code'
      });
    }

    return {
      isValid: errors.length === 0,
      errors
    };
  }

  private static getFieldDisplayName(field: string): string {
    const displayNames: Record<string, string> = {
      firstName: 'First name',
      lastName: 'Last name',
      streetAddress: 'Street address',
      stateProvinceRegion: 'State/Province/Region',
      postalZipCode: 'Postal/Zip code',
      country: 'Country'
    };
    
    return displayNames[field] || field;
  }
}