import initSqlJs from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalZipCode: string;
  country: string;
  email: string;
  phoneNumber: string;
  createdAt?: string;
}

interface SqlModule {
  Database: new (sqlBuffer?: Buffer) => SqlDatabase;
}

interface SqlDatabase {
  run(sql: string, params?: string[]): void;
  exec(sql: string): SqlResult[];
  export(): Uint8Array;
  close(): void;
}

interface SqlResult {
  columns: string[];
  values: unknown[][];
}

let db: SqlDatabase | null = null;
let dbPath: string;
let Sql: SqlModule | null = null;

export async function initializeDatabase(): Promise<void> {
  dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  
  // Create data directory if it doesn't exist
  const dataDir = path.dirname(dbPath);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  let sqlBuffer: Buffer | undefined;
  if (fs.existsSync(dbPath)) {
    sqlBuffer = fs.readFileSync(dbPath);
  }
  const SqlModule = await initSqlJs();
  Sql = SqlModule as SqlModule;
  db = new Sql.Database(sqlBuffer);
  
  // Initialize schema
  await runSchema();
}

async function runSchema(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  
  db.run(schema);
}

export async function insertSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Promise<number> {
  if (!db) throw new Error('Database not initialized');
  
  db.run(`
    INSERT INTO submissions (
      first_name, last_name, street_address, city, 
      state_province_region, postal_zip_code, country, 
      email, phone_number
    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `, [
    submission.firstName,
    submission.lastName,
    submission.streetAddress,
    submission.city,
    submission.stateProvinceRegion,
    submission.postalZipCode,
    submission.country,
    submission.email,
    submission.phoneNumber
  ]);
  
  const result = db.exec(`SELECT last_insert_rowid() as id`);
  if (!result || result.length === 0 || !result[0]?.values || result[0].values.length === 0 || !result[0].values[0]) {
    throw new Error('Failed to get inserted ID');
  }
  const idResult = result[0].values[0];
  if (!idResult || idResult.length === 0) {
    throw new Error('Failed to get inserted ID');
  }
  const id = idResult[0] as number;
  
  await saveDatabase();
  
  return id;
}

export async function saveDatabase(): Promise<void> {
  if (!db) throw new Error('Database not initialized');
  
  const binary = db.export();
  fs.writeFileSync(dbPath, Buffer.from(binary));
}

export async function closeDatabase(): Promise<void> {
  if (db) {
    db.close();
    db = null;
  }
}