import express from 'express';
import * as path from 'path';
import { insertSubmission, initializeDatabase, closeDatabase } from './database';
import { ContactValidator, ContactData } from './validation';

const app = express();
const PORT = process.env.PORT || 3535;

// Initialize database on startup
initializeDatabase().catch(error => {
  console.error('Failed to initialize database:', error);
  process.exit(1);
});

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use('/public', express.static(path.join(__dirname, '../public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, '../views'));

// GET / - Render contact form
app.get('/', (req: express.Request, res: express.Response) => {
  res.render('index', {
    title: 'Friendly Contact Form',
    errors: [],
    data: {} as ContactData
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req: express.Request, res: express.Response) => {
  const contactData: ContactData = {
    firstName: req.body.firstName?.trim() || '',
    lastName: req.body.lastName?.trim() || '',
    streetAddress: req.body.streetAddress?.trim() || '',
    city: req.body.city?.trim() || '',
    stateProvinceRegion: req.body.stateProvinceRegion?.trim() || '',
    postalZipCode: req.body.postalZipCode?.trim() || '',
    country: req.body.country?.trim() || '',
    email: req.body.email?.trim() || '',
    phoneNumber: req.body.phoneNumber?.trim() || ''
  };

  // Validate form data
  const validation = ContactValidator.validateContact(contactData);
  
  if (!validation.isValid) {
    // Return form with errors and previously entered data
    return res.status(400).render('index', {
      title: 'Friendly Contact Form',
      errors: validation.errors,
      data: contactData
    });
  }

  try {
    // Insert submission into database
    await insertSubmission(contactData);
    
    // Redirect to thank-you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('index', {
      title: 'Friendly Contact Form',
      errors: [{ field: 'general', message: 'Server error. Please try again later.' }],
      data: contactData
    });
  }
});

// GET /thank-you - Thank you page
app.get('/thank-you', (req: express.Request, res: express.Response) => {
  res.render('thank-you', {
    title: 'Thanks for Your Submission!'
  });
});

// Graceful shutdown
const gracefulShutdown = async () => {
  console.log('\nShutting down gracefully...');
  await closeDatabase().catch(error => {
    console.error('Error closing database:', error);
  });
  process.exit(0);
};

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

export { app };

// Start server only if this file is run directly
if (require.main === module) {
  app.listen(PORT, () => {
    console.log(`Friendly Form Capture server running on port ${PORT}`);
    console.log(`Visit http://localhost:${PORT} to try it out!`);
  });
}
