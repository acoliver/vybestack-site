#!/usr/bin/env node

import * as fs from 'node:fs/promises';
import type { ReportData, RenderOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * Map of supported formats to their render functions
 */
const RENDERERS = {
  markdown: renderMarkdown,
  text: renderText,
} as const;

type SupportedFormat = keyof typeof RENDERERS;

/**
 * Parse CLI arguments
 */
function parseArgs(args: string[]): {
  dataFile: string;
  format: SupportedFormat;
  outputPath?: string;
  includeTotals: boolean;
} {
  if (args.length < 2) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = args[0];
  let format: SupportedFormat = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];

    if (arg === '--format') {
      const formatValue = args[++i];
      if (!formatValue) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }

      if (!(formatValue in RENDERERS)) {
        console.error(`Error: Unsupported format "${formatValue}"`);
        process.exit(1);
      }

      format = formatValue as SupportedFormat;
    } else if (arg === '--output') {
      outputPath = args[++i];
      if (!outputPath) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument "${arg}"`);
      process.exit(1);
    }
  }

  return { dataFile, format, outputPath, includeTotals };
}

/**
 * Validate report data structure
 */
function validateReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    console.error('Error: Invalid JSON - root must be an object');
    return false;
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    console.error('Error: Invalid or missing "title" field (must be a string)');
    return false;
  }

  if (typeof obj.summary !== 'string') {
    console.error('Error: Invalid or missing "summary" field (must be a string)');
    return false;
  }

  if (!Array.isArray(obj.entries)) {
    console.error('Error: Invalid or missing "entries" field (must be an array)');
    return false;
  }

  for (let i = 0; i < obj.entries.length; i++) {
    const entry = obj.entries[i];
    if (typeof entry !== 'object' || entry === null) {
      console.error(`Error: Entry at index ${i} must be an object`);
      return false;
    }

    const entryObj = entry as Record<string, unknown>;

    if (typeof entryObj.label !== 'string') {
      console.error(`Error: Entry at index ${i} has invalid or missing "label" field (must be a string)`);
      return false;
    }

    if (typeof entryObj.amount !== 'number') {
      console.error(`Error: Entry at index ${i} has invalid or missing "amount" field (must be a number)`);
      return false;
    }
  }

  return true;
}

/**
 * Main CLI entry point
 */
async function main(): Promise<void> {
  const args = parseArgs(process.argv.slice(2));

  // Read and parse JSON file
  let jsonData: unknown;
  try {
    const content = await fs.readFile(args.dataFile, 'utf-8');
    jsonData = JSON.parse(content);
  } catch (error) {
    if ((error as NodeJS.ErrnoException).code === 'ENOENT') {
      console.error(`Error: File not found: "${args.dataFile}"`);
    } else if ((error as SyntaxError) instanceof SyntaxError) {
      console.error(`Error: Malformed JSON in file "${args.dataFile}"`);
    } else {
      console.error(`Error: Failed to read file "${args.dataFile}"`);
    }
    process.exit(1);
  }

  // Validate data structure
  if (!validateReportData(jsonData)) {
    process.exit(1);
  }

  const data: ReportData = jsonData;

  // Render report
  const options: RenderOptions = { includeTotals: args.includeTotals };
  const render = RENDERERS[args.format];
  const output = render(data, options);

  // Write output
  if (args.outputPath) {
    try {
      await fs.writeFile(args.outputPath, output, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to "${args.outputPath}"`);
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main().catch((error) => {
  console.error('Unexpected error:', error);
  process.exit(1);
});
