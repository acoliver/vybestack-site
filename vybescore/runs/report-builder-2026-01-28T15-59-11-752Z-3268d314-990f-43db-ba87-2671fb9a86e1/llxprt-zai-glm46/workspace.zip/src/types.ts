/**
 * Report data structure matching the JSON schema
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: Array<{
    label: string;
    amount: number;
  }>;
}

/**
 * Options for rendering reports
 */
export interface RenderOptions {
  includeTotals: boolean;
}
