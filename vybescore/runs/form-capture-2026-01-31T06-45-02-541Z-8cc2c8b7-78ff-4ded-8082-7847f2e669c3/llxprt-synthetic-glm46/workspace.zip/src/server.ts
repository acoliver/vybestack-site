import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import sqlite3InitModule, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.resolve('data', 'submissions.sqlite');

// Initialize Express app
const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// Set EJS as the view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Database initialization
async function initializeDatabase(): Promise<Database> {
  try {
    // Ensure data directory exists
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load SQL.js module
    const SQL = await sqlite3InitModule();
    
    // Try to load existing database or create new one
    let database: Database;
    if (fs.existsSync(dbPath)) {
      const data = fs.readFileSync(dbPath);
      database = new SQL.Database(data);
      console.log('Loaded existing database');
    } else {
      database = new SQL.Database();
      console.log('Created new database');
      
      // Initialize schema
      const schema = fs.readFileSync('db/schema.sql', 'utf8');
      database.run(schema);
      console.log('Database schema initialized');
    }

    return database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

// Function to export database to disk
function exportDatabase(db: Database): void {
  try {
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database exported to disk');
  } catch (error) {
    console.error('Failed to export database:', error);
  }
}

// Database connection placeholder
// This will be replaced with actual SQLite integration
let db: Database | null = null;

// Form validation function
function validateForm(formData: Record<string, string>): { isValid: boolean; errors: string[] } {
  const errors: string[] = [];
  
  // Required fields validation
  if (!formData.firstName || formData.firstName.trim() === '') {
    errors.push('First name is required');
  }
  
  if (!formData.lastName || formData.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  
  if (!formData.streetAddress || formData.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  
  if (!formData.city || formData.city.trim() === '') {
    errors.push('City is required');
  }
  
  if (!formData.stateProvince || formData.stateProvince.trim() === '') {
    errors.push('State/Province/Region is required');
  }
  
  if (!formData.postalCode || formData.postalCode.trim() === '') {
    errors.push('Postal/Zip code is required');
  }
  
  if (!formData.country || formData.country.trim() === '') {
    errors.push('Country is required');
  }
  
  if (!formData.email || formData.email.trim() === '') {
    errors.push('Email is required');
  } else if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) {
    errors.push('Email format is invalid');
  }
  
  if (!formData.phone || formData.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!formData.phone.match(/^@?[\d\s\-+()]+$/)) {
    errors.push('Phone number can only contain digits, spaces, hyphens, plus signs, parentheses and optionally start with @');
  }
  
  return {
    isValid: errors.length === 0,
    errors
  };
}

// Function to insert form data into database
function saveSubmission(db: Database, formData: Record<string, string>): void {
  const stmt = db.prepare(`
    INSERT INTO submissions 
    (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  stmt.run([
    formData.firstName,
    formData.lastName,
    formData.streetAddress,
    formData.city,
    formData.stateProvince,
    formData.postalCode,
    formData.country,
    formData.email,
    formData.phone
  ]);
  
  stmt.free();
}

// Routes
app.get('/', (req, res) => {
  res.render('form', { 
    errors: [], 
    formData: {},
    title: 'International Contact Form'
  });
});

app.get('/thank-you', (req, res) => {
  res.render('thank-you', { 
    title: 'Thank You For Your Submission!'
  });
});

// POST /submit route
app.post('/submit', (req, res) => {
  const formData = req.body;
  const validation = validateForm(formData);
  
  if (!validation.isValid) {
    return res.status(400).render('form', {
      errors: validation.errors,
      formData,
      title: 'International Contact Form'
    });
  }
  
  // Save to database
  if (db) {
    saveSubmission(db, formData);
    exportDatabase(db);
  }
  
  res.redirect('/thank-you');
});

// Graceful shutdown
function gracefulShutdown() {
  console.log('Shutting down gracefully');
  if (db) {
    exportDatabase(db);
    db.close();
    console.log('Database connection closed');
  }
  process.exit(0);
}

process.on('SIGTERM', gracefulShutdown);
process.on('SIGINT', gracefulShutdown);

// Start server
async function startServer() {
  try {
    // Initialize database
    db = await initializeDatabase();
    
    // Start server
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
