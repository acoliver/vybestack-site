import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import * as cheerio from 'cheerio';
import fs from 'node:fs';
import path from 'node:path';
import { spawn } from 'node:child_process';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const projectRoot = path.resolve(__dirname, '..', '..');

let serverProcess: import('node:child_process').ChildProcess | null = null;
const dbPath = path.resolve(projectRoot, 'data', 'submissions.sqlite');

beforeAll(async () => {
  // Clean up any existing database file
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start the server as a child process
  const serverPath = path.resolve(projectRoot, 'dist', 'server.js');
  serverProcess = spawn('node', [serverPath], {
    stdio: 'pipe',
    env: { ...process.env, PORT: '3535' }
  });
  
  // Wait for server to start
  await new Promise((resolve, reject) => {
    const timeout = setTimeout(() => {
      reject(new Error('Server failed to start'));
    }, 10000);
    
    serverProcess.stdout.on('data', (data: Buffer) => {
      const output = data.toString();
      if (output.includes('Server listening')) {
        clearTimeout(timeout);
        // Give it a moment to fully start
        setTimeout(resolve, 100);
      }
    });
    
    serverProcess.stderr.on('data', (data: Buffer) => {
      console.error('Server error:', data.toString());
    });
    
    serverProcess.on('error', (error: Error) => {
      clearTimeout(timeout);
      reject(error);
    });
  });
}, 15000);

afterAll(async () => {
  if (serverProcess) {
    serverProcess.kill('SIGTERM');
    // Wait for graceful shutdown
    await new Promise((resolve) => {
      setTimeout(resolve, 1000);
    });
  }
});

describe('friendly form (public smoke)', () => {
it('renders the form with all fields', async () => {
    try {
      const response = await request('http://localhost:3535').get('/').timeout(5000);
      expect(response.status).toBe(200);
      
      // Check response details
      console.log('Response type:', typeof response);
      console.log('Response text exists:', !!response.text);
      console.log('Response text length:', response.text ? response.text.length : 'no text');
      
      // Only try cheerio if we have text
      if (!response.text) {
        throw new Error('Response has no text content');
      }
      
      console.log('Cheerio module:', typeof cheerio);
      console.log('Cheerio keys:', Object.keys(cheerio));
      console.log('Cheerio default:', typeof cheerio.default);
      console.log('Cheerio load method:', typeof cheerio.load);
      
      const cheerioLoad = cheerio.load || cheerio.default?.load;
      if (!cheerioLoad) {
        throw new Error('Cannot find cheerio.load method');
      }
      
      const $ = cheerioLoad(response.text);
      expect($('form[action="/submit"]')).toHaveLength(1);
      expect($('input[name="firstName"]')).toHaveLength(1);
      expect($('input[name="lastName"]')).toHaveLength(1);
      expect($('input[name="streetAddress"]')).toHaveLength(1);
      expect($('input[name="city"]')).toHaveLength(1);
      expect($('input[name="stateProvince"]')).toHaveLength(1);
      expect($('input[name="postalCode"]')).toHaveLength(1);
      expect($('input[name="country"]')).toHaveLength(1);
      expect($('input[name="email"]')).toHaveLength(1);
      expect($('input[name="phone"]')).toHaveLength(1);
    } catch (error) {
      console.log('Test failed with error:', error);
      throw error;
    }
  });

  it('validates required fields and shows errors', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({})
      .timeout(5000);
    
    expect(response.status).toBe(400);
    const cheerioLoad = cheerio.load || cheerio.default?.load;
    const $ = cheerioLoad(response.text);
    expect($('.error-list li')).toHaveLength(9);
  });

it('validates email format', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'invalid-email',
        phone: '+1 555-123-4567'
      })
      .timeout(5000);
    
    expect(response.status).toBe(400);
    const cheerioLoad = cheerio.load || cheerio.default?.load;
    const $ = cheerioLoad(response.text);
    expect($('.error-list li')).toHaveLength(1);
    expect($('.error-list li').text()).toContain('valid email');
  });

it('validates phone format', async () => {
    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'John',
        lastName: 'Doe',
        streetAddress: '123 Main St',
        city: 'Anytown',
        stateProvince: 'State',
        postalCode: '12345',
        country: 'Country',
        email: 'john@example.com',
        phone: 'invalid-phone-@#$'
      })
      .timeout(5000);
    
    expect(response.status).toBe(400);
    const cheerioLoad = cheerio.load || cheerio.default?.load;
    const $ = cheerioLoad(response.text);
    expect($('.error-list li')).toHaveLength(1);
    expect($('.error-list li').text()).toContain('valid phone');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request('http://localhost:3535')
      .post('/submit')
      .send({
        firstName: 'Jane',
        lastName: 'Smith',
        streetAddress: '456 Oak Ave',
        city: 'Testville',
        stateProvince: 'Test State',
        postalCode: 'SW1A 1AA',
        country: 'United Kingdom',
        email: 'jane@example.com',
        phone: '+44 20 7946 0958'
      })
      .timeout(5000);
    
    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    
    expect(fs.existsSync(dbPath)).toBe(true);
  });

it('renders thank you page', async () => {
    const response = await request('http://localhost:3535').get('/thank-you').timeout(5000);
    expect(response.status).toBe(200);
    
    const cheerioLoad = cheerio.load || cheerio.default?.load;
    const $ = cheerioLoad(response.text);
    expect($('h1, h2').text()).toMatch(/thank|spam|scam/i);
  });
});
