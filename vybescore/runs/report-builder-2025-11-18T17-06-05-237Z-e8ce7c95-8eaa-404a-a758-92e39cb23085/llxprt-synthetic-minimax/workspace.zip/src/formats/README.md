This directory contains format implementations for the report builder CLI.

Each formatter must export an object with a `render` function that implements the `Formatter` interface from `../types.js`.

Implemented formatters:
- `markdown.ts` - Renders reports in Markdown format
- `text.ts` - Renders reports in plain text format

To add a new format:
1. Create a new file (e.g., `html.ts`)
2. Export a formatter object implementing the `Formatter` interface
3. Add the new format to the CLI's format map