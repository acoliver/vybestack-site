import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, FormatOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  output?: string;
  includeTotals: boolean;
}

function parseArgs(args: string[]): ParsedArgs {
  const result: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };

  // Skip node and script path
  const flags = args.slice(2);

  for (let i = 0; i < flags.length; i++) {
    const flag = flags[i];

    switch (flag) {
      case '--format':
        if (i + 1 >= flags.length) {
          console.error('Error: --format requires a value');
          process.exit(1);
        }
        result.format = flags[i + 1];
        i++;
        break;

      case '--output':
        if (i + 1 >= flags.length) {
          console.error('Error: --output requires a value');
          process.exit(1);
        }
        result.output = flags[i + 1];
        i++;
        break;

      case '--includeTotals':
        result.includeTotals = true;
        break;

      default:
        // Assume it's the data file if it doesn't start with --
        if (!result.dataFile) {
          result.dataFile = flag;
        } else {
          console.error(`Error: Unknown argument '${flag}'`);
          process.exit(1);
        }
        break;
    }
  }

  // Validate required arguments
  if (!result.dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }

  if (!result.format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  // Validate format
  if (result.format !== 'markdown' && result.format !== 'text') {
    console.error(`Error: Unsupported format '${result.format}'`);
    process.exit(1);
  }

  return result;
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as ReportData;

    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }

    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }

    if (!Array.isArray(data.entries)) {
      throw new Error('Missing or invalid "entries" field (must be an array)');
    }

    // Validate each entry
    for (let i = 0; i < data.entries.length; i++) {
      const entry = data.entries[i];
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Entry ${i}: Missing or invalid "label" field`);
      }
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Entry ${i}: Missing or invalid "amount" field (must be a number)`);
      }
    }

    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.includes('ENOENT')) {
        console.error(`Error: File '${filePath}' not found`);
      } else if (error.message.includes('JSON.parse')) {
        console.error(`Error: Invalid JSON in '${filePath}'`);
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error(`Error: Failed to load data from '${filePath}'`);
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: string, options: FormatOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
    default:
      console.error(`Error: Unsupported format '${format}'`);
      process.exit(1);
  }
}

function writeOutput(content: string, outputPath?: string): void {
  if (outputPath) {
    try {
      writeFileSync(outputPath, content, 'utf-8');
    } catch (error) {
      console.error(`Error: Failed to write to '${outputPath}'`);
      process.exit(1);
    }
  } else {
    // Output to stdout
    process.stdout.write(content);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  const data = loadReportData(args.dataFile);
  const options: FormatOptions = { includeTotals: args.includeTotals };
  const report = renderReport(data, args.format, options);
  writeOutput(report, args.output);
}

main();