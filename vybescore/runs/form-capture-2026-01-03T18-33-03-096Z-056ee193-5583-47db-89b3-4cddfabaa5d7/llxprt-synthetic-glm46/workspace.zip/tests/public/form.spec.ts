import { describe, expect, it, beforeAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import * as sqljs from 'sql.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(() => {
  // noop placeholder – the agent should replace with real server import.
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', () => {
    // placeholder that the agent should replace once server is implemented
    expect(true).toBe(true);
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }
    
    // Create a simple database to test sql.js functionality
    const SQL = await sqljs.default();
    const db = new SQL.Database();
    
    // Create table
    db.run('CREATE TABLE test_table (id INTEGER PRIMARY KEY, name TEXT)');
    
    // Insert data
    db.run('INSERT INTO test_table (name) VALUES (?)', ['test']);
    
    // Query data
    const result = db.exec('SELECT * FROM test_table');
    
    // Verify data
    expect(result.length).toBe(1);
    expect(result[0].values[0][1]).toBe('test');
    
    // Clean up
    db.close();
  });
});
