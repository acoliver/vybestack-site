export interface FormSubmission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationError {
  field: string;
  message: string;
}

export class FormValidator {
  private emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  private phoneRegex = /^\+?[0-9\s\-()]+$/;
  private postalRegex = /^[a-zA-Z0-9\s-]+$/;

  validate(formData: FormSubmission): ValidationError[] {
    const errors: ValidationError[] = [];

    // Required field validation
    this.validateRequired('firstName', formData.firstName, 'First name', errors);
    this.validateRequired('lastName', formData.lastName, 'Last name', errors);
    this.validateRequired('streetAddress', formData.streetAddress, 'Street address', errors);
    this.validateRequired('city', formData.city, 'City', errors);
    this.validateRequired('stateProvince', formData.stateProvince, 'State/Province/Region', errors);
    this.validateRequired('postalCode', formData.postalCode, 'Postal/Zip code', errors);
    this.validateRequired('country', formData.country, 'Country', errors);
    this.validateRequired('email', formData.email, 'Email', errors);
    this.validateRequired('phone', formData.phone, 'Phone number', errors);

    // Email validation
    if (formData.email && !this.emailRegex.test(formData.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }

    // Phone validation
    if (formData.phone && !this.phoneRegex.test(formData.phone)) {
      errors.push({
        field: 'phone',
        message: 'Phone number can only contain digits, spaces, parentheses, dashes, and optional leading +'
      });
    }

    // Postal code validation - allow alphanumeric with spaces and dashes
    if (formData.postalCode && !this.postalRegex.test(formData.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Postal/Zip code must contain only letters, numbers, spaces, and dashes'
      });
    }

    return errors;
  }

  private validateRequired(field: string, value: string, fieldName: string, errors: ValidationError[]): void {
    if (!value || value.trim().length === 0) {
      errors.push({
        field,
        message: `${fieldName} is required`
      });
    }
  }

  sanitizeData(formData: FormSubmission): FormSubmission {
    return {
      firstName: formData.firstName?.trim() || '',
      lastName: formData.lastName?.trim() || '',
      streetAddress: formData.streetAddress?.trim() || '',
      city: formData.city?.trim() || '',
      stateProvince: formData.stateProvince?.trim() || '',
      postalCode: formData.postalCode?.trim() || '',
      country: formData.country?.trim() || '',
      email: formData.email?.trim() || '',
      phone: formData.phone?.trim() || ''
    };
  }
}