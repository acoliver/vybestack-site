import fs from 'fs';
import path from 'path';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import sqlWrapper from './database-wrapper.js';



export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
  createdAt?: string;
}

export interface QueryResult {
  values: unknown[][];
  columns: string[];
}

export interface SqlJsStatic {
  Database: new (data?: Uint8Array) => Database;
}

export interface Database {
  exec(sql: string): QueryResult[];
  prepare(sql: string): Statement;
  export(): Uint8Array;
  close(): void;
}

export interface Statement {
  run(params: unknown[]): void;
  free(): void;
}

export class DatabaseManager {
  private sql: { Database: { new (data?: Uint8Array): Database } } | null = null;
  private db: Database | null = null;
  private dbPath: string;
  private schemaPath: string;
  private DbClass!: { new (data?: Uint8Array): Database };

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
    this.schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
  }

  get database(): Database {
    if (!this.db) {
      throw new Error('Database not initialized');
    }
    return this.db;
  }

  async init(): Promise<void> {
    // Initialize the sql.js library and store it
    const SQL = await sqlWrapper.init();
    this.sql = SQL;
    
    if (!this.sql || !this.sql.Database) {
      throw new Error('Failed to initialize SQL database library');
    }
    
    this.DbClass = this.sql.Database;
    
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(this.dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Load existing database or create a new one
    if (fs.existsSync(this.dbPath)) {
      const dbFile = fs.readFileSync(this.dbPath);
      this.db = new this.DbClass(dbFile);
    } else {
      this.db = new this.DbClass();
    }

    // Execute schema if database is new or if we want to ensure tables exist
    const schema = fs.readFileSync(this.schemaPath, 'utf8');
    try {
      if (this.db) {
        this.db.exec(schema);
      }
    } catch (error) {
      console.error('Error executing schema:', error);
      throw error;
    }
  }

  save(): void {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }

  insertSubmission(submission: Omit<Submission, 'id'>): number {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province, 
        postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvince,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phone
    ]);

    stmt.free();

    // Get the ID of the inserted row
    const result = this.db.exec('SELECT last_insert_rowid() as id') as QueryResult[];
    const insertedId = result[0].values[0][0] as number;

    // Save changes to disk
    this.save();

    return insertedId;
  }

  getAllSubmissions(): Submission[] {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const result = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC') as QueryResult[];
    
    if (result.length === 0) {
      return [];
    }

    const columns = result[0].columns;
    const values = result[0].values;

    return values.map((row: unknown[]) => {
      const submission = {} as Record<string, unknown>;
      columns.forEach((col: string, index: number) => {
        // Convert snake_case to camelCase for property names
        const camelCaseCol = col.replace(/_([a-z])/g, ((_: string, letter: string) => letter.toUpperCase()));
        submission[camelCaseCol] = row[index];
      });
      return submission as unknown as Submission;
    });
  }
}