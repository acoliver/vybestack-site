import express, { Request, Response } from 'express';
import path from 'path';
import { DatabaseManager } from './database.js';
import { FormValidator, FormSubmission } from './validation.js';

const app = express();
const port = process.env.PORT || 3535;
const dbManager = new DatabaseManager();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(process.cwd(), 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'src', 'views'));

// Types
interface FormRequest extends Request {
  body: FormSubmission;
}

interface FormErrors {
  [key: string]: string[];
}

// Helper functions
function flattenErrors(errors: { field: string; message: string }[]): FormErrors {
  const flattened: FormErrors = {};
  errors.forEach(error => {
    if (!flattened[error.field]) {
      flattened[error.field] = [];
    }
    flattened[error.field].push(error.message);
  });
  return flattened;
}

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('index', {
    formData: {},
    errors: {},
    submitted: false
  });
});

app.post('/submit', (req: FormRequest, res: Response) => {
  const validator = new FormValidator();
  const sanitizedData = validator.sanitizeData(req.body);
  const validationErrors = validator.validate(sanitizedData);

  if (validationErrors.length > 0) {
    const flattenedErrors = flattenErrors(validationErrors);
    return res.status(400).render('index', {
      formData: sanitizedData,
      errors: flattenedErrors,
      submitted: true
    });
  }

  const submissionId = dbManager.insertSubmission({
    firstName: sanitizedData.firstName,
    lastName: sanitizedData.lastName,
    streetAddress: sanitizedData.streetAddress,
    city: sanitizedData.city,
    stateProvince: sanitizedData.stateProvince,
    postalCode: sanitizedData.postalCode,
    country: sanitizedData.country,
    email: sanitizedData.email,
    phone: sanitizedData.phone
  });

  console.log(`Submission ${submissionId} saved successfully`);
  res.redirect('/thank-you');
});

app.get('/thank-you', (req: Request, res: Response) => {
  res.render('thank-you');
});

// Graceful shutdown
async function shutdown(): Promise<void> {
  console.log('Closing database connections...');
  try {
    dbManager.close();
    console.log('Database closed successfully');
  } catch (error) {
    console.error('Error closing database:', error);
  }

  console.log('Server shutting down...');
  process.exit(0);
}

process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);

// Start server
async function startServer(): Promise<void> {
  try {
    console.log('Initializing database...');
    await dbManager.init();
    console.log('Database initialized successfully');

    app.listen(port, () => {
      console.log(`Server running at http://localhost:${port}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer().catch(error => {
  console.error('Unhandled error during server startup:', error);
  process.exit(1);
});
