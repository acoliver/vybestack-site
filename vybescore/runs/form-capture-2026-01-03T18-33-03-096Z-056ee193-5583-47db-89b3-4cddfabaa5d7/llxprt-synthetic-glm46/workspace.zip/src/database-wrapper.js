const sqljs = require('sql.js');

export default { 
  init: async function() {
    return await sqljs();
  }
};