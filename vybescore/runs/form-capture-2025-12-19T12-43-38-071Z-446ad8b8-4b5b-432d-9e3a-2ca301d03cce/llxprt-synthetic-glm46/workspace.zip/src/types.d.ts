declare module 'sql.js' {
  export default function initSqlJs(options?: { locateFile?: (file: string) => string }): Promise<{
    Database: new (data?: Uint8Array) => Database;
  }>;
  
  export class Database {
    constructor(data?: Uint8Array);
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): Database.QueryResults[];
    export(): Uint8Array;
    close(): void;
    prepare(sql: string): Statement;
  }

  export namespace Database {
    export interface QueryResults {
      columns: string[];
      values: unknown[][];
    }
  }

  export abstract class Statement {
    abstract run(params?: unknown[]): void;
    abstract get(params?: unknown[]): unknown[];
    abstract all(params?: unknown[]): unknown[];
    abstract free(): void;
  }
}