export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  errors: string[];
  isValid: boolean;
}

export function validateForm(data: FormData): ValidationResult {
  const errors: string[] = [];

  // Required field validation
  if (!data.firstName.trim()) {
    errors.push('First name is required');
  }

  if (!data.lastName.trim()) {
    errors.push('Last name is required');
  }

  if (!data.streetAddress.trim()) {
    errors.push('Street address is required');
  }

  if (!data.city.trim()) {
    errors.push('City is required');
  }

  if (!data.stateProvince.trim()) {
    errors.push('State / Province / Region is required');
  }

  if (!data.postalCode.trim()) {
    errors.push('Postal / Zip code is required');
  }

  if (!data.country.trim()) {
    errors.push('Country is required');
  }

  if (!data.email.trim()) {
    errors.push('Email is required');
  }

  if (!data.phone.trim()) {
    errors.push('Phone number is required');
  }

  // Email validation (simple regex)
  if (data.email.trim() && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(data.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation (international formats)
  if (data.phone.trim() && !/^[+]?\d[\d\s\-()]*$/.test(data.phone)) {
    errors.push('Please enter a valid phone number');
  }

// Postal code validation (alphanumeric)
  if (data.postalCode.trim() && !/^[A-Za-z0-9\s-]+$/.test(data.postalCode)) {
    errors.push('Please enter a valid postal/zip code');
  }

  return {
    errors,
    isValid: errors.length === 0
  };
}