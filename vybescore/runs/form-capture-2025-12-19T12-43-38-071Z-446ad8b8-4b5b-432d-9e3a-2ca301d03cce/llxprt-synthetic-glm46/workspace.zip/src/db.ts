import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');
const SCHEMA_PATH = path.join(__dirname, '../db/schema.sql');

let db: Database | null = null;

export async function initializeDatabase(): Promise<Database> {
  try {
    // Load SQL.js
    const SQLFactory = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });
    const SQL = SQLFactory;

    // Check if database file exists
    let fileBuffer: Uint8Array | null = null;
    if (fs.existsSync(DB_PATH)) {
      fileBuffer = fs.readFileSync(DB_PATH);
    }

    // Create or open database
    db = new SQL.Database(fileBuffer || undefined);

    // If it's a new database, run the schema
    if (!fileBuffer) {
      const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
      db.run(schema);
      console.log('Database initialized with schema');
    } else {
      console.log('Database loaded from file');
    }

    return db as Database;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

export function saveDatabase(): void {
  if (!db) {
    throw new Error('Database not initialized');
  }

  try {
    // Ensure data directory exists
    const dataDir = path.dirname(DB_PATH);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    // Save database to file
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
    console.log('Database saved to file');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

export function closeDatabase(): void {
  if (db) {
    db.close();
    db = null;
    console.log('Database closed');
  }
}

export function getDatabase(): Database {
  if (!db) {
    throw new Error('Database not initialized. Call initializeDatabase() first.');
  }
  return db as Database;
}

export interface SubmissionData {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}

export function insertSubmission(data: SubmissionData): void {
  const db = getDatabase();
  
  const stmt = db.prepare(`
    INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `);
  
  try {
    stmt.run([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);
  } finally {
    stmt.free();
  }
}