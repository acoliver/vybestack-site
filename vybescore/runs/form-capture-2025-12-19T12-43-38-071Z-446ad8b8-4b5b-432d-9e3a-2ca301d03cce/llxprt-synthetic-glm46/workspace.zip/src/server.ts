import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import { initializeDatabase, saveDatabase, closeDatabase, insertSubmission } from './db.js';
import { validateForm, FormData } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Static files
app.use(express.static(path.join(__dirname, '../public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Initialize database
initializeDatabase().catch((err: Error) => {
  console.error('Failed to initialize database:', err);
  process.exit(1);
});

// Routes
app.get('/', (req: Request, res: Response) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req: Request, res: Response) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const { errors, isValid } = validateForm(formData);

  if (!isValid) {
    return res.status(400).render('form', {
      errors,
      values: formData
    });
  }

  try {
    // Insert into database
    insertSubmission({
      first_name: formData.firstName,
      last_name: formData.lastName,
      street_address: formData.streetAddress,
      city: formData.city,
      state_province: formData.stateProvince,
      postal_code: formData.postalCode,
      country: formData.country,
      email: formData.email,
      phone: formData.phone
    });

    // Save database to disk
    saveDatabase();

    // Redirect to thank you page with first name
    res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
  } catch (error) {
    console.error('Error saving submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const { firstName } = req.query;
  res.render('thank-you', { firstName: firstName || 'Friend' });
});

// Start server
const server = app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  server.close(() => {
    console.log('Server closed');
    closeDatabase();
    process.exit(0);
  });
});

export default app;
