import { readFileSync } from 'node:fs';
import { ReportData } from './types.js';

export function parseReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, { encoding: 'utf8' });
    const data = JSON.parse(content) as unknown;
    
    if (!isValidReportData(data)) {
      throw new Error('Invalid report data structure');
    }
    
    return data;
  } catch (error) {
    if (error instanceof SyntaxError) {
      throw new Error('Malformed JSON file: Invalid JSON syntax');
    }
    
    // Add specific error message for missing files
    if (error instanceof Error && 'code' in error && error.code === 'ENOENT') {
      throw new Error(`File not found: ${filePath}`);
    }
    
    throw error;
  }
}

function isValidReportData(data: unknown): data is ReportData {
  if (typeof data !== 'object' || data === null) {
    return false;
  }
  
  const report = data as Record<string, unknown>;
  
  if (typeof report.title !== 'string') {
    return false;
  }
  
  if (typeof report.summary !== 'string') {
    return false;
  }
  
  if (!Array.isArray(report.entries)) {
    return false;
  }
  
  for (const entry of report.entries) {
    if (typeof entry !== 'object' || entry === null) {
      return false;
    }
    
    const entryRecord = entry as Record<string, unknown>;
    
    if (typeof entryRecord.label !== 'string') {
      return false;
    }
    
    if (typeof entryRecord.amount !== 'number') {
      return false;
    }
  }
  
  return true;
}

export function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

export function calculateTotal(entries: Array<{ amount: number }>): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}