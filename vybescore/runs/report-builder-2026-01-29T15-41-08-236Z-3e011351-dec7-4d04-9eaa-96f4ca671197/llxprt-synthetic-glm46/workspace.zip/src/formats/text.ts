import { ReportData, ReportFormatter, RenderOptions } from '../types.js';
import { formatAmount, calculateTotal } from '../utils.js';

export const renderText: ReportFormatter['render'] = (
  data: ReportData,
  options?: RenderOptions,
): string => {
  const lines: string[] = [];
  
  lines.push(data.title);
  lines.push('');
  lines.push(data.summary);
  lines.push('');
  lines.push('Entries:');
  
  for (const entry of data.entries) {
    lines.push(`- ${entry.label}: ${formatAmount(entry.amount)}`);
  }
  
  if (options?.includeTotals) {
    const total = calculateTotal(data.entries);
    lines.push(`Total: ${formatAmount(total)}`);
  }
  
  return lines.join('\n');
};