#!/usr/bin/env node

import { writeFileSync } from 'node:fs';
import { parseArguments, toRenderOptions } from './args.js';
import { parseReportData } from '../utils.js';
import { formatters } from '../formatters/index.js';

function main(): void {
  try {
    const args = parseArguments(process.argv);
    const data = parseReportData(args.dataFile);
    
    const formatter = formatters[args.format];
    if (!formatter) {
      console.error(`Error: Unsupported format: ${args.format}`);
      process.exit(1);
    }
    
    const options = toRenderOptions(args);
    const output = formatter(data, options);
    
    if (args.outputPath) {
      writeFileSync(args.outputPath, output, { encoding: 'utf8' });
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main();
}
