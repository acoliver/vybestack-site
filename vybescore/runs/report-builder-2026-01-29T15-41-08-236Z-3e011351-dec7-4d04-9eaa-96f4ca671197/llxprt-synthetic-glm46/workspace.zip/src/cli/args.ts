import { RenderOptions } from '../types.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

export function parseArguments(argv: string[]): CliArgs {
  const args: CliArgs = {
    dataFile: '',
    format: '',
    includeTotals: false,
  };
  
  let i = 2;
  while (i < argv.length) {
    const arg = argv[i];
    
    if (arg === '--format') {
      i++;
      if (i >= argv.length) {
        throw new Error('--format requires a value');
      }
      args.format = argv[i];
    } else if (arg === '--output') {
      i++;
      if (i >= argv.length) {
        throw new Error('--output requires a value');
      }
      args.outputPath = argv[i];
    } else if (arg === '--includeTotals') {
      args.includeTotals = true;
    } else if (arg.startsWith('-')) {
      throw new Error(`Unsupported option: ${arg}`);
    } else if (args.dataFile === '') {
      args.dataFile = arg;
    } else {
      throw new Error(`Unexpected argument: ${arg}`);
    }
    
    i++;
  }
  
  if (args.dataFile === '') {
    throw new Error('Missing required argument: data file path');
  }
  
  if (args.format === '') {
    throw new Error('Missing required option: --format');
  }
  
  return args;
}

export function toRenderOptions(args: Pick<CliArgs, 'includeTotals'>): RenderOptions {
  return {
    includeTotals: args.includeTotals,
  };
}