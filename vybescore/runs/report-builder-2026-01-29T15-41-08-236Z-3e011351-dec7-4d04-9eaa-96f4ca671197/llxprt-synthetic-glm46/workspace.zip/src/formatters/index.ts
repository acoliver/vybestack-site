import { ReportFormatter } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

export const formatters: Record<string, ReportFormatter['render']> = {
  markdown: renderMarkdown,
  text: renderText,
};