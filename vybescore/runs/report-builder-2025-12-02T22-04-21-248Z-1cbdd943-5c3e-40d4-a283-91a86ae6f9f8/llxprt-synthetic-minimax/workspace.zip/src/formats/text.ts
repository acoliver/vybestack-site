import { ReportData, RenderOptions, Formatter } from '../types.js';

const formatAmount = (amount: number): string => {
  return `$${amount.toFixed(2)}`;
};

const calculateTotal = (data: ReportData): number => {
  return data.entries.reduce((sum, entry) => sum + entry.amount, 0);
};

export const renderText = (data: ReportData, options: RenderOptions): string => {
  let output = `${data.title}\n\n`;
  output += `${data.summary}\n\n`;
  output += `Entries:\n\n`;

  for (const entry of data.entries) {
    output += `- ${entry.label}: ${formatAmount(entry.amount)}\n`;
  }

  if (options.includeTotals) {
    output += `\nTotal: ${formatAmount(calculateTotal(data))}`;
  }

  return output;
};

export const textFormatter: Formatter = {
  format: 'text',
  render: renderText,
};