import { readFileSync, writeFileSync } from 'node:fs';
import { markdownFormatter, textFormatter, Formatter } from '../formats/index.js';
import { ReportData } from '../types.js';

const formatters: Record<string, Formatter> = {
  markdown: markdownFormatter,
  text: textFormatter,
};

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  if (argv.length < 4) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFile = argv[2];
  const args = argv.slice(3);
  
  let format = '';
  let outputFile: string | undefined;
  let includeTotals = false;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format') {
      if (i + 1 >= args.length) {
        console.error('Error: --format requires a value');
        process.exit(1);
      }
      format = args[i + 1];
      i++;
    } else if (arg === '--output') {
      if (i + 1 >= args.length) {
        console.error('Error: --output requires a value');
        process.exit(1);
      }
      outputFile = args[i + 1];
      i++;
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else {
      console.error(`Error: Unknown argument: ${arg}`);
      process.exit(1);
    }
  }

  if (!format) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  return { dataFile, format, outputFile, includeTotals };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf8');
    const data = JSON.parse(content) as ReportData;
    
    // Validate required fields
    if (!data.title || typeof data.title !== 'string') {
      throw new Error('Invalid data: title is required and must be a string');
    }
    
    if (!data.summary || typeof data.summary !== 'string') {
      throw new Error('Invalid data: summary is required and must be a string');
    }
    
    if (!Array.isArray(data.entries)) {
      throw new Error('Invalid data: entries is required and must be an array');
    }
    
    // Validate entries
    for (const [index, entry] of data.entries.entries()) {
      if (!entry.label || typeof entry.label !== 'string') {
        throw new Error(`Invalid data: entries[${index}].label is required and must be a string`);
      }
      
      if (typeof entry.amount !== 'number' || isNaN(entry.amount)) {
        throw new Error(`Invalid data: entries[${index}].amount is required and must be a number`);
      }
    }
    
    return data;
  } catch (error) {
    if (error instanceof Error) {
      if (error.message.startsWith('ENOENT:')) {
        console.error(`Error: File not found: ${filePath}`);
      } else if (error.message.startsWith('Unexpected token')) {
        console.error('Error: Invalid JSON format');
      } else {
        console.error(`Error: ${error.message}`);
      }
    } else {
      console.error('Error: Failed to read or parse data file');
    }
    process.exit(1);
  }
}

function main(): void {
  const args = parseArgs(process.argv);
  const data = loadReportData(args.dataFile);
  
  const formatter = formatters[args.format];
  if (!formatter) {
    console.error(`Error: Unsupported format: ${args.format}`);
    process.exit(1);
  }
  
  const output = formatter.render(data, { includeTotals: args.includeTotals });
  
  if (args.outputFile) {
    try {
      writeFileSync(args.outputFile, output, 'utf8');
    } catch (error) {
      console.error(`Error: Failed to write output file: ${args.outputFile}`);
      process.exit(1);
    }
  } else {
    process.stdout.write(output);
  }
}

main();