/**
 * Finds words beginning with the prefix but excluding the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a set of exceptions for faster lookup
  const exceptionSet = new Set(exceptions);
  
  // Create regex to find words starting with the prefix
  const regex = new RegExp(`\\b${prefix}[a-zA-Z0-9_-]*\\b`, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions
  return matches.filter(word => !exceptionSet.has(word));
}

/**
 * Returns occurrences where the token appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Create regex to find the digit and token together
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const regex = new RegExp(`(\\d${escapedToken})\\b`, 'g');
  
  const matches = [];
  let match;
  
  while ((match = regex.exec(text)) !== null) {
    matches.push(match[1]);
  }
  
  return matches;
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase
 * - One lowercase
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for uppercase
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Check for lowercase
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Check for digit
  if (!/[0-9]/.test(value)) {
    return false;
  }
  
  // Check for symbol
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>\/?]/.test(value)) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  for (let i = 0; i < value.length - 3; i++) {
    // Check for patterns of length 2 repeated immediately (abab)
    const pattern2 = value.substring(i, i + 2);
    if (value.substring(i + 2, i + 4) === pattern2) {
      return false;
    }
    
    // Check for patterns of length 3 repeated immediately (abcabc)
    if (i + 5 < value.length) {
      const pattern3 = value.substring(i, i + 3);
      if (value.substring(i + 3, i + 6) === pattern3) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  // Check for IPv6 addresses first (including those with :: shorthand)
  const ipv6Regex = /([0-9a-fA-F]{1,4}:){2,7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:)*::([0-9a-fA-F]{1,4}:)*[0-9a-fA-F]{1,4}/g;
  
  const matches = value.match(ipv6Regex);
  
  if (!matches || matches.length === 0) {
    return false;
  }
  
  // Ensure we're not matching an IPv4 address
  for (const match of matches) {
    if (!/^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/.test(match)) {
      return true;
    }
  }
  
  return false;
}