/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if the input omitted it.
 * Collapses extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, collapse multiple spaces to a single space
  let result = text.replace(/\s+/g, ' ');
  
  // Then, ensure there's exactly one space after sentence endings (. ? !)
  result = result.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Finally, capitalize the first letter after sentence boundaries or at the start
  result = result.replace(/(^|[.?!]\s+)([a-z])/g, (match, boundary, letter) => {
    return boundary + letter.toUpperCase();
  });
  
  // Trim leading/trailing whitespace
  return result.trim();
}

/**
 * Extracts URLs from the provided text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern
  const urlRegex = /https?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)/gi;
  
  const urls = [];
  let match;
  
  while ((match = urlRegex.exec(text)) !== null) {
    // Extract the matched URL
    let url = match[0];
    
    // Remove trailing punctuation like .,?!:; but keep path/query params
    url = url.replace(/[.,?!:;]+$/g, '');
    
    urls.push(url);
  }
  
  return urls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// using a simple pattern
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... URLs to https://...
 * When the path begins with /docs/, rewrites the host to docs.example.com
 * Skips host rewrite for dynamic paths with cgi-bin, query strings?, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  // First, convert http to https
  let result = enforceHttps(text);
  
  // Regex to match URLs from example.com
  const urlRegex = /(https:\/\/)(example\.com)(\/[^\s]*)/gi;
  
  result = result.replace(urlRegex, (match, scheme, domain, path) => {
    // Always use https scheme
    const httpsScheme = 'https://';
    
    // Check if we should rewrite the host
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !path.includes('cgi-bin') && 
      !path.includes('?') && 
      !path.includes('&') && 
      !path.includes('=') && 
      !/\.(jsp|php|asp|aspx|do|cgi|pl|py)(?=[\/\?#]|$)/i.test(path);
    
    const newDomain = shouldRewriteHost ? 'docs.example.com' : domain;
    
    return httpsScheme + newDomain + path;
  });
  
  return result;
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Regex to match mm/dd/yyyy format
  const dateRegex = /(?<month>0[1-9]|1[0-2])\/(?<day>0[1-9]|[12][0-9]|3[01])\/(?<year>\d{4})/;
  
  const match = value.match(dateRegex);
  
  if (!match || !match.groups) {
    return 'N/A';
  }
  
  const { month, day, year } = match.groups;
  
  // Validate month and day values
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Additional validation for day based on month
  if (dayNum > daysInMonth(monthNum)) {
    return 'N/A';
  }
  
  return year;
}

/**
 * Helper function to get the number of days in a month
 */
function daysInMonth(month: number): number {
  switch (month) {
    case 1: case 3: case 5: case 7: case 8: case 10: case 12:
      return 31;
    case 4: case 6: case 9: case 11:
      return 30;
    case 2:
      // February has 28 days (we don't need to handle leap years for this simple case)
      return 28;
    default:
      return 0;
  }
}
