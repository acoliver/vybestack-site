export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates an email address using regular expression patterns.
 * Accepts typical addresses such as name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other obviously invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic email validation regex
  // Local part: letters, digits, +, . (but not consecutive), -, _
  // Domain: letters, digits, -, . (but not starting/ending with .)
  // TLD: at least 2 letters
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Quick rejection of invalid formats
  if (!emailRegex.test(value)) {
    return false;
  }
  
  // Extract local part and domain for additional validation
  const [localPart, domain] = value.split('@');
  
  // Reject double dots in local part or domain
  if (localPart.includes('..') || domain.includes('..')) {
    return false;
  }
  
  // Reject trailing or leading dots in local part
  if (localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Reject domain with underscores
  if (domain.includes('_')) {
    return false;
  }
  
  // Reject domain starting or ending with a dot
  if (domain.startsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  return true;
}

/**
 * Validates a US phone number supporting common separators and optional +1.
 * Supports formats like (212) 555-7890, 212-555-7890, 2125557890, with optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Clean the input by removing common separators
  const cleanedValue = value.replace(/[\s\-\(\)]/g, '');
  
  // Check if it has optional +1 country code
  let phoneNumber = cleanedValue;
  if (phoneNumber.startsWith('+1')) {
    phoneNumber = phoneNumber.substring(2);
  } else if (phoneNumber.startsWith('1') && phoneNumber.length > 10) {
    phoneNumber = phoneNumber.substring(1);
  }
  
  // Handle extension if allowed
  if (options?.allowExtensions) {
    const parts = phoneNumber.split(/[xX#]/);
    phoneNumber = parts[0];
  }
  
  // Check if the phone number is exactly 10 digits
  if (!/^\d{10}$/.test(phoneNumber)) {
    return false;
  }
  
  // Extract area code (first 3 digits)
  const areaCode = phoneNumber.substring(0, 3);
  
  // Disallow area codes starting with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') {
    return false;
  }
  
  // Check exchange code (next 3 digits)
  const exchangeCode = phoneNumber.substring(3, 6);
  
  // Disallow exchange codes starting with 0 or 1
  if (exchangeCode[0] === '0' || exchangeCode[0] === '1') {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Accepts formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Clean the input by removing spaces and hyphens
  const cleanedValue = value.replace(/[\s\-]/g, '');
  
  // Regex pattern for Argentine phone numbers
  // Optional +54 country code
  // Optional trunk prefix 0
  // Optional mobile indicator 9
  // Area code: 2-4 digits, not starting with 0
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(\+54)?(?:0?9?)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanedValue.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const [, countryCode, areaCode, subscriberNumber] = match;
  
  // If country code is omitted, the number must start with trunk prefix 0
  if (!countryCode && !value.startsWith('0')) {
    return false;
  }
  
  // Validate area code (2-4 digits, not starting with 0)
  if (!/^[1-9]\d{1,3}$/.test(areaCode)) {
    return false;
  }
  
  // Validate subscriber number (6-8 digits)
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Trim whitespace at the beginning and end
  const trimmedValue = value.trim();
  
  // Name should not be empty
  if (!trimmedValue) {
    return false;
  }
  
  // Regex for names with unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any kind of letter from any language
  // \p{M} matches combining marks (accents)
  const nameRegex = /^[\p{L}\p{M}'\-]+(?:\s[\p{L}\p{M}'\-]+)*$/u;
  
  return nameRegex.test(trimmedValue);
}

/**
 * Helper function to perform Luhn algorithm checksum for credit card validation.
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '').split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum to validate the card number.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanedValue = value.replace(/\D/g, '');
  
  // Check if the cleaned value contains only digits and is not empty
  if (!/^\d+$/.test(cleanedValue)) {
    return false;
  }
  
  // Check card length based on type
  const isVisa = /^4[0-9]{12}(?:[0-9]{3})?$/.test(cleanedValue);
  const isMastercard = /^5[1-5][0-9]{14}$/.test(cleanedValue);
  const isAmEx = /^3[47][0-9]{13}$/.test(cleanedValue);
  
  // Check if the card matches any of the supported types
  if (!isVisa && !isMastercard && !isAmEx) {
    return false;
  }
  
  // Run Luhn checksum
  return runLuhnCheck(cleanedValue);
}
