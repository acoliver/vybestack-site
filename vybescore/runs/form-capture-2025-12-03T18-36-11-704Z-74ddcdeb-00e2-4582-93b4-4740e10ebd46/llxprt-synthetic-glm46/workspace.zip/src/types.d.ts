export interface SqlJsDatabase {
  run: (sql: string, params?: unknown[]) => void;
  export: () => Uint8Array;
  exec: (sql: string) => unknown[];
  prepare: (sql: string) => SqlJsStatement;
  getSql: (sql: string) => SqlJsResult;
  close: () => void;
}

export interface SqlJsStatement {
  bind: (params: unknown[]) => void;
  step: () => number;
  get: () => unknown;
  free: () => void;
}

export interface SqlJsResult {
  get: (index: number) => SqlJsRow;
}

export interface SqlJsRow {
  id?: number;
}

export interface InitSqlJsStatic {
  (options?: { locateFile: (file: string) => string }): Promise<SqlJsDatabase & { Database: { new(data?: ArrayBuffer): SqlJsDatabase } }>;
}

declare module 'sql.js' {
  const sqlJs: InitSqlJsStatic;
  export default sqlJs;
}