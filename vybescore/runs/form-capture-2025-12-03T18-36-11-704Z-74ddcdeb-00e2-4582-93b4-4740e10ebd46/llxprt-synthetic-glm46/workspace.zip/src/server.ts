import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initDatabase, { insertSubmission } from './database.js';
import { validateForm, parseFormData, FormData, ValidationResult } from './validation.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = process.env.PORT || process.env.TEST_PORT || 3535;

// Configure EJS view engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'templates'));

// Serve static files from public directory
app.use('/public', express.static(path.join(__dirname, '..', 'public')));

// Parse URL-encoded bodies (as sent by HTML forms)
app.use(express.urlencoded({ extended: true }));

// Initialize database
let db: unknown;

async function startServer() {
  try {
    db = await initDatabase();
    
    // GET / - render the form
    app.get('/', (req, res) => {
      const values: FormData = {
        firstName: '',
        lastName: '',
        streetAddress: '',
        city: '',
        stateProvince: '',
        postalCode: '',
        country: '',
        email: '',
        phone: ''
      };
      
      res.render('form', {
        values,
        errors: []
      });
    });
    
    // POST /submit - handle form submission
    app.post('/submit', (req, res) => {
      const formData = parseFormData(req.body);
      const validationResult: ValidationResult = validateForm(formData);
      
      if (!validationResult.isValid) {
        // Validation failed, re-render form with errors
        res.render('form', {
          values: formData,
          errors: validationResult.errors
        });
        return;
      }
      
      try {
        // Insert into database
        const submissionId = insertSubmission({
          first_name: formData.firstName,
          last_name: formData.lastName,
          street_address: formData.streetAddress,
          city: formData.city,
          state_province: formData.stateProvince,
          postal_code: formData.postalCode,
          country: formData.country,
          email: formData.email,
          phone: formData.phone
        });
        
        console.log(`Submission inserted with ID: ${submissionId}`);
        
        // Redirect to thank you page with first name in session
        res.redirect(`/thank-you?firstName=${encodeURIComponent(formData.firstName)}`);
      } catch (error) {
        console.error('Error inserting submission:', error);
        res.render('form', {
          values: formData,
          errors: ['An error occurred while saving your submission. Please try again.']
        });
      }
    });
    
    // GET /thank-you - render thank you page
    app.get('/thank-you', (req, res) => {
      const firstName = req.query.firstName as string || 'Friend';
      res.render('thank-you', {
        firstName
      });
    });
    
    // Other routes will be implemented in the next steps
    
    const server = app.listen(port, () => {
      console.log(`Server running on port ${port}`);
    });

    // Graceful shutdown on SIGTERM
    process.on('SIGTERM', () => {
      console.log('SIGTERM received, shutting down gracefully');
      server.close(() => {
        if (db) {
          // Database is already managed by the database module
          console.log('Server closed');
        }
        process.exit(0);
      });
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();
