export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: string[];
}

export function validateForm(formData: FormData): ValidationResult {
  const errors: string[] = [];

  // First name validation
  if (!formData.firstName || formData.firstName.trim().length === 0) {
    errors.push('First name is required');
  }

  // Last name validation
  if (!formData.lastName || formData.lastName.trim().length === 0) {
    errors.push('Last name is required');
  }

  // Street address validation
  if (!formData.streetAddress || formData.streetAddress.trim().length === 0) {
    errors.push('Street address is required');
  }

  // City validation
  if (!formData.city || formData.city.trim().length === 0) {
    errors.push('City is required');
  }

  // State/Province validation
  if (!formData.stateProvince || formData.stateProvince.trim().length === 0) {
    errors.push('State/Province/Region is required');
  }

  // Postal code validation - must accept alphanumeric strings
  if (!formData.postalCode || formData.postalCode.trim().length === 0) {
    errors.push('Postal/Zip code is required');
  } else if (!/^[a-zA-Z0-9\s-]+$/.test(formData.postalCode)) {
    errors.push('Postal/Zip code must contain only letters, numbers, spaces, and hyphens');
  }

  // Country validation
  if (!formData.country || formData.country.trim().length === 0) {
    errors.push('Country is required');
  }

  // Email validation
  if (!formData.email || formData.email.trim().length === 0) {
    errors.push('Email is required');
  } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
    errors.push('Please enter a valid email address');
  }

  // Phone validation - can contain digits, spaces, parentheses, dashes, and leading +
  if (!formData.phone || formData.phone.trim().length === 0) {
    errors.push('Phone number is required');
  } else if (!/^\+?[0-9\s()-]+$/.test(formData.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, hyphens, and may start with +');
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}

export function parseFormData(body: Record<string, unknown>): FormData {
  return {
    firstName: (body.firstName as string) || '',
    lastName: (body.lastName as string) || '',
    streetAddress: (body.streetAddress as string) || '',
    city: (body.city as string) || '',
    stateProvince: (body.stateProvince as string) || '',
    postalCode: (body.postalCode as string) || '',
    country: (body.country as string) || '',
    email: (body.email as string) || '',
    phone: (body.phone as string) || ''
  };
}