import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
// eslint-disable-next-line @typescript-eslint/ban-ts-comment
// @ts-ignore
import initSqlJs, { Database } from 'sql.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const dbPath = path.join(__dirname, '..', 'data', 'submissions.sqlite');
const schemaPath = path.join(__dirname, '..', 'db', 'schema.sql');

let db: Database | null = null;
let dbInitialized = false;

async function initDatabase(): Promise<Database> {
  if (dbInitialized && db) {
    return db;
  }

  try {
    // Import sql.js dynamically (needed for WASM support)
    const SQL = await initSqlJs({
      locateFile: (file: string) => `node_modules/sql.js/dist/${file}`
    });

    // Check if database file exists
    const databaseExists = fs.existsSync(dbPath);

    if (databaseExists) {
      // Load existing database
      const filebuffer = fs.readFileSync(dbPath);
      db = new SQL.Database(new Uint8Array(filebuffer));
      console.log('Database loaded from file');
    } else {
      // Create new database
      db = new SQL.Database();
      console.log('New database created');
      
      // Read and execute schema
      const schema = fs.readFileSync(schemaPath, 'utf8');
      if (db) {
        db.run(schema);
      }
      
      // Ensure data directory exists
      const dataDir = path.dirname(dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }
      
      // Save new database to file
      saveDatabase();
    }

    dbInitialized = true;
    if (!db) {
      throw new Error('Database initialization failed');
    }
    return db;
  } catch (error) {
    console.error('Failed to initialize database:', error);
    throw error;
  }
}

function saveDatabase(): void {
  try {
    if (!db) return;
    const data = db.export();
    fs.writeFileSync(dbPath, Buffer.from(data));
    console.log('Database saved to file');
  } catch (error) {
    console.error('Failed to save database:', error);
    throw error;
  }
}

function insertSubmission(data: {
  first_name: string;
  last_name: string;
  street_address: string;
  city: string;
  state_province: string;
  postal_code: string;
  country: string;
  email: string;
  phone: string;
}): number {
  if (!dbInitialized || !db) {
    throw new Error('Database not initialized');
  }

  try {
    const stmt = db.prepare(`
      INSERT INTO submissions 
      (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    
    stmt.bind([
      data.first_name,
      data.last_name,
      data.street_address,
      data.city,
      data.state_province,
      data.postal_code,
      data.country,
      data.email,
      data.phone
    ]);
    
    const stepResult = stmt.step();
    stmt.free();
    
    // Since we can't easily access constants from sql.js, use -1 as our identifier for success
    if (stepResult !== -1 && stepResult !== 0) { // Both -1 (SQLITE_DONE) and 0 (SQLITE_ROW) indicate success
      throw new Error('Failed to insert submission');
    }
    
    // Save database after each insert
    saveDatabase();
    
    // Get the ID of the last inserted row
    const idResult = db.exec('SELECT last_insert_rowid() as id');
    return idResult[0].values[0][0] as number;
  } catch (error) {
    console.error('Failed to insert submission:', error);
    throw error;
  }
}

function getSubmissions(): Record<string, unknown>[] {
  if (!dbInitialized || !db) {
    throw new Error('Database not initialized');
  }

  try {
    const stmt = db.prepare('SELECT * FROM submissions ORDER BY created_at DESC');
    const result: Record<string, unknown>[] = [];
    while (stmt.step() !== 0) { // 0 means SQLITE_ROW
      result.push(stmt.get() as Record<string, unknown>);
    }
    stmt.free();
    return result;
  } catch (error) {
    console.error('Failed to get submissions:', error);
    throw error;
  }
}

function closeDatabase(): void {
  if (db) {
    try {
      db.close();
      console.log('Database connection closed');
    } catch (error) {
      console.error('Failed to close database:', error);
    }
  }
}

export default initDatabase;
export { insertSubmission, getSubmissions, closeDatabase };