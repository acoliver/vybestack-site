import { createInput, createComputed, createCallback } from './src/index.ts'

const [input, setInput] = createInput(11)
const output = createComputed(() => {
  console.log('computing output, input=', input())
  return input() + 1
})

const values1: number[] = []
console.log('creating callback1')
const unsubscribe1 = createCallback(() => {
  console.log('callback1 called, output=', output())
  values1.push(output())
})

const values2: number[] = []
console.log('creating callback2')
createCallback(() => {
  console.log('callback2 called, output=', output())
  values2.push(output())
})

console.log('setting input to 31')
setInput(31)
console.log('after setInput(31), values1=', values1, 'values2=', values2)

console.log('unsubscribing callback1')
unsubscribe1()
console.log('after unsubscribe')

console.log('setting input to 41')
setInput(41)
console.log('after setInput(41), values1=', values1, 'values2=', values2)

console.log('FINAL: values1.length=', values1.length, 'values2.length=', values2.length)
