/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create the callback observer
  const callbackObserver: Observer<T> = {
    value,
    updateFn: (prevValue?: T) => {
      return updateFn(prevValue)
    },
  }
  
  // Perform initial execution - this will track dependencies via the getter mechanism
  // in both inputs and computed values
  updateObserver(callbackObserver)
  
  let disposed = false
  ;(callbackObserver as Observer<T> & { disposed: boolean }).disposed = false
  
  const unsubscribe = () => {
    if (disposed) return
    disposed = true
    ;(callbackObserver as Observer<T> & { disposed: boolean }).disposed = true
    // The disposed flag will prevent updateObserver from executing this callback
  }
  
  return unsubscribe
}
