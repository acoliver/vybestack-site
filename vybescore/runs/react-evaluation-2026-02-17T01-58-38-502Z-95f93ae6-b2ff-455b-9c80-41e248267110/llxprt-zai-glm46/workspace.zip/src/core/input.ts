/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Observer,
  getActiveObserver,
  updateObserver,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | unknown,
  _options?: Options
): InputPair<T> {
  const observers: Observer<unknown>[] = []
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && !observers.includes(observer as Observer<unknown>)) {
      observers.push(observer as Observer<unknown>)
    }
    return value
  }

  const write: SetterFn<T> = (nextValue) => {
    value = nextValue
    // Notify all observers
    for (const obs of [...observers]) {
      updateObserver(obs)
    }
    return value
  }

  return [read, write]
}

// Export function to notify callbacks when inputs change
export function notifyAllCallbacks(): void {
  // This will be imported by callback.ts
}
