/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  userUpdateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | unknown,
  options?: { name?: string }
): GetterFn<T> {
  const dependentObservers: Observer<unknown>[] = []
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn: userUpdateFn,  // Store the user's function
  }
  
  const getter = (): T => {
    const observer = getActiveObserver()
    if (observer && !dependentObservers.includes(observer as Observer<unknown>)) {
      dependentObservers.push(observer as Observer<unknown>)
    }
    return o.value!
  }
  
  // Override the updateFn to add notification logic
  o.updateFn = (prevValue?: T) => {
    // Call the user's function to compute the new value
    const result = userUpdateFn(prevValue)
    o.value = result
    
    // Notify all observers that depend on this computed value
    for (const obs of [...dependentObservers]) {
      updateObserver(obs)
    }
    
    return result
  }
  
  // Perform initial computation
  updateObserver(o)
  
  return getter
}
