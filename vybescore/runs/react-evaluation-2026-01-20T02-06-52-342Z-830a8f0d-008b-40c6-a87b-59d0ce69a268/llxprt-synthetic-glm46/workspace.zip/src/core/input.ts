/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

// Import triggerCallbacks from callback.ts and updateComputedObservers from computed.ts
import { triggerCallbacks } from './callback.js'
import { updateComputedObservers } from './computed.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn: undefined,
    listeners: new Set(),
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      s.listeners.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    s.value = nextValue
    
    // First update direct listeners
    notifyObservers(s)
    
    // Then update all computed observers that may transitively depend on this
    updateComputedObservers()
    
    // Finally trigger all callbacks
    triggerCallbacks()
    
    return s.value
  }

  return [read, write]
}
