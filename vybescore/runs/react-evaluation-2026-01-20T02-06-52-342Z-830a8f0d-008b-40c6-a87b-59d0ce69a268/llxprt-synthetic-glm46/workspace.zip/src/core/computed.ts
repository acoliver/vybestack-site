/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn
} from '../types/reactive.js'

// Store all computed observers for dependency tracking
const computedObservers = new Set<Observer<unknown>>()

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    __dependencies: new Set(),
  }
  
  // Store computed observer for dependency management
  computedObservers.add(o as Observer<unknown>)
  
  // Initial calculation
  updateObserver(o)
  
  return (): T => {
    const currentObserver = (globalThis as { __currentObserver?: { __dependencies?: Set<Observer<unknown>> } }).__currentObserver
    if (currentObserver) {
      // When this computed value is accessed inside another observer,
      // we need to track this dependency
      currentObserver.__dependencies = currentObserver.__dependencies || new Set()
      currentObserver.__dependencies.add(o as Observer<unknown>)
    }
    return o.value!
  }
}

// Helper to update all computed observers when dependencies change
export function updateComputedObservers(): void {
  computedObservers.forEach(observer => {
    updateObserver(observer)
  })
}
