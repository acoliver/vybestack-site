/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn } from '../types/reactive.js'

// Track all callback observers for notifications
const callbackObservers = new Set<Observer<unknown>>()

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    updateFn,
  }
  
  // Register callback
  callbackObservers.add(observer as Observer<unknown>)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove from callbacks set
    callbackObservers.delete(observer as Observer<unknown>)
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}

// Helper function to trigger all callbacks
export function triggerCallbacks(): void {
  const observersToDelete: Observer<unknown>[] = []
  
  callbackObservers.forEach(observer => {
    try {
      observer.value = observer.updateFn(observer.value)
    } catch (e) {
      // Handle case where observer has been disposed
      observersToDelete.push(observer)
    }
  })
  
  // Clean up disposed observers
  observersToDelete.forEach(observer => {
    callbackObservers.delete(observer)
  })
}
