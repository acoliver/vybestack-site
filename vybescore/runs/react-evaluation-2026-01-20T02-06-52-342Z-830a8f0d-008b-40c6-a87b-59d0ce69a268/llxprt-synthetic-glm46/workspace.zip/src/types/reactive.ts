/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export interface ObserverR {
  name?: string
  __dependencies?: Set<Observer<unknown>>
}

export interface ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface Observer<T> extends ObserverR, ObserverV<T> {
  value?: T
  updateFn: UpdateFn<T>
}

export interface SubjectR {
  name?: string
  observer: ObserverR | undefined
  listeners: Set<ObserverR>
}

export interface SubjectV<T> {
  value: T
  equalFn?: EqualFn<T>
}

export interface Subject<T> extends SubjectR, SubjectV<T> {}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  ;(globalThis as { __currentObserver?: ObserverR }).__currentObserver = activeObserver
  try {
    observer.value = observer.updateFn(observer.value)
    // After updating, also update all dependencies
    updateDependencies(observer as Observer<unknown>)
  } finally {
    activeObserver = previous
    ;(globalThis as { __currentObserver?: ObserverR }).__currentObserver = activeObserver
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  subject.listeners.forEach(observer => {
    updateObserver(observer as Observer<unknown>)
  })
}

export function updateDependencies(observer: Observer<unknown>): void {
  const dependencies = observer.__dependencies
  if (dependencies) {
    dependencies.forEach((dep: Observer<unknown>) => {
      updateObserver(dep)
    })
  }
}
