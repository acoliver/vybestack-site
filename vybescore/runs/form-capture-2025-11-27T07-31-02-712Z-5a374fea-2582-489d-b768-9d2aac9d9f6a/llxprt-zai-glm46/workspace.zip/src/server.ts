import express from 'express';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Import sql.js
import initSqlJs from 'sql.js';

// Type for sql.js Database
interface SqlJsDatabase {
  prepare(sql: string): SqlJsStatement;
  run(sql?: string, ...params: unknown[]): void;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsStatement {
  run(...params: unknown[]): void;
  step(): unknown;
  get(): unknown[];
  free(): void;
}

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationError {
  field: string;
  message: string;
}

const app = express();
const port = process.env.PORT || 3535;
const dbPath = path.resolve(__dirname, '..', 'data', 'submissions.sqlite');

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.resolve(__dirname, '..', 'public')));

// Set EJS as view engine
app.set('view engine', 'ejs');
app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));

let db: SqlJsDatabase | null = null;
let isShuttingDown = false;

// Initialize database
async function initializeDatabase(): Promise<void> {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.dirname(dbPath);
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true });
    }

    const SQL = await initSqlJs();
    let data = null;

    // Load existing database or create new one
    if (fs.existsSync(dbPath)) {
      const fileBuffer = fs.readFileSync(dbPath);
      data = new Uint8Array(fileBuffer);
      db = new SQL.Database(data);
    } else {
      db = new SQL.Database();
      
      // Create schema from the provided SQL file
      const schemaPath = path.resolve(__dirname, '..', 'db', 'schema.sql');
      const schemaSql = fs.readFileSync(schemaPath, 'utf-8');
      db.run(schemaSql);
    }

    console.log('Database initialized successfully');
  } catch (error) {
    console.error('Failed to initialize database:', error);
    process.exit(1);
  }
}

// Save database to disk
function saveDatabase(): void {
  if (db && !isShuttingDown) {
    try {
      const data = db.export();
      fs.writeFileSync(dbPath, Buffer.from(data));
      console.log('Database saved to disk');
    } catch (error) {
      console.error('Failed to save database:', error);
    }
  }
}

// Validation functions
function validateRequired(value: string): ValidationError | null {
  if (!value || value.trim() === '') {
    return { field: 'required', message: 'This field is required' };
  }
  return null;
}

function validateEmail(email: string): ValidationError | null {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email.trim())) {
    return { field: 'email', message: 'Please enter a valid email address' };
  }
  return null;
}

function validatePhone(phone: string): ValidationError | null {
  const phoneRegex = /^\+?[\d\s\-()]+$/;
  if (!phoneRegex.test(phone.trim())) {
    return { field: 'phone', message: 'Please enter a valid phone number' };
  }
  return null;
}

function validatePostalCode(postalCode: string): ValidationError | null {
  const postalRegex = /^[\w\s-]+$/;
  if (!postalRegex.test(postalCode.trim())) {
    return { field: 'postalCode', message: 'Please enter a valid postal code' };
  }
  return null;
}

// Validate form data
function validateForm(data: FormData): ValidationError[] {
  const errors: ValidationError[] = [];

  // Required fields
  const requiredFields = [
    'firstName', 'lastName', 'streetAddress', 'city', 
    'stateProvince', 'postalCode', 'country', 'email', 'phone'
  ];

  for (const field of requiredFields) {
    const error = validateRequired(data[field as keyof FormData]);
    if (error) {
      errors.push({ ...error, field });
    }
  }

  // Specific validations
  if (data.email) {
    const emailError = validateEmail(data.email);
    if (emailError) errors.push(emailError);
  }

  if (data.phone) {
    const phoneError = validatePhone(data.phone);
    if (phoneError) errors.push(phoneError);
  }

  if (data.postalCode) {
    const postalError = validatePostalCode(data.postalCode);
    if (postalError) errors.push(postalError);
  }

  return errors;
}

// Routes
app.get('/', (req, res) => {
  res.render('form', {
    errors: [],
    values: {}
  });
});

app.post('/submit', (req, res) => {
  const formData: FormData = {
    firstName: req.body.firstName || '',
    lastName: req.body.lastName || '',
    streetAddress: req.body.streetAddress || '',
    city: req.body.city || '',
    stateProvince: req.body.stateProvince || '',
    postalCode: req.body.postalCode || '',
    country: req.body.country || '',
    email: req.body.email || '',
    phone: req.body.phone || ''
  };

  const errors = validateForm(formData);

  if (errors.length > 0) {
    // Return form with errors
    return res.status(400).render('form', {
      errors: errors.map(error => error.message),
      values: formData
    });
  }

  try {
    // Insert into database
    if (!db) {
      throw new Error('Database not initialized');
    }
    
    const stmt = db.prepare(`
      INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName.trim(),
      formData.lastName.trim(),
      formData.streetAddress.trim(),
      formData.city.trim(),
      formData.stateProvince.trim(),
      formData.postalCode.trim(),
      formData.country.trim(),
      formData.email.trim(),
      formData.phone.trim()
    ]);

    stmt.free();

    // Save database to disk
    saveDatabase();

    // Redirect to thank you page
    res.redirect('/thank-you');
  } catch (error) {
    console.error('Failed to save submission:', error);
    res.status(500).render('form', {
      errors: ['An error occurred while saving your submission. Please try again.'],
      values: formData
    });
  }
});

app.get('/thank-you', (req, res) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you', { firstName });
});

// Graceful shutdown
function gracefulShutdown(signal: string): void {
  console.log(`Received ${signal}. Starting graceful shutdown...`);
  isShuttingDown = true;

  if (db) {
    saveDatabase();
    db.close();
  }

  if (server) {
    server.close(() => {
      console.log('Server closed successfully');
      process.exit(0);
    });
  } else {
    process.exit(0);
  }

  // Force shutdown after 10 seconds
  setTimeout(() => {
    console.log('Forcing shutdown...');
    process.exit(1);
  }, 10000);
}

// Start server
let server: ReturnType<typeof app.listen> | null = null;

async function startServer(): Promise<void> {
  await initializeDatabase();

  server = app.listen(port, () => {
    console.log(`Server running on port ${port}`);
  });

  // Handle graceful shutdown
  process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));
  process.on('SIGINT', () => gracefulShutdown('SIGINT'));
}

// Start the server only if this file is run directly
if (import.meta.url === `file://${process.argv[1]}`) {
  startServer().catch(error => {
    console.error('Failed to start server:', error);
    process.exit(1);
  });
}

export { app, server };