import { ReportData, RenderOptions } from './types.js';

export function renderText(data: ReportData, options: RenderOptions = {}): string {
  // Validate input data
  if (!data.title) {
    throw new Error('Missing required field: title');
  }
  if (!data.summary) {
    throw new Error('Missing required field: summary');
  }
  if (!Array.isArray(data.entries)) {
    throw new Error('Missing required field: entries');
  }

  // Build the text output
  let output = `${data.title}\n\n${data.summary}\n\nEntries:\n`;
  
  data.entries.forEach(entry => {
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  });
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\nTotal: $${total.toFixed(2)}\n`;
  }
  
  return output;
}