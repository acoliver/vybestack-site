import { ReportData, RenderOptions } from './types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions = {}): string {
  // Validate input data
  if (!data.title) {
    throw new Error('Missing required field: title');
  }
  if (!data.summary) {
    throw new Error('Missing required field: summary');
  }
  if (!Array.isArray(data.entries)) {
    throw new Error('Missing required field: entries');
  }

  // Build the markdown output
  let output = `# ${data.title}\n\n${data.summary}\n\n## Entries\n`;
  
  data.entries.forEach(entry => {
    output += `- **${entry.label}** — $${entry.amount.toFixed(2)}\n`;
  });
  
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\n**Total:** $${total.toFixed(2)}\n`;
  }
  
  return output;
}