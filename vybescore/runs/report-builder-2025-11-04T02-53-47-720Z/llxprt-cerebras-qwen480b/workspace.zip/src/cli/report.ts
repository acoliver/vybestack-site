#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'fs';
import { ReportData } from '../formats/types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

// Parse command line arguments
const args = process.argv.slice(2);
const filePath = args[0];
let format: string | undefined;
let outputPath: string | undefined;
let includeTotals = false;

for (let i = 1; i < args.length; i++) {
  if (args[i] === '--format' && i + 1 < args.length) {
    format = args[i + 1];
    i++;
  } else if (args[i] === '--output' && i + 1 < args.length) {
    outputPath = args[i + 1];
    i++;
  } else if (args[i] === '--includeTotals') {
    includeTotals = true;
  }
}

// Validate arguments
if (!filePath) {
  console.error('Error: Missing data file path');
  process.exit(1);
}

if (!format) {
  console.error('Error: Missing format option');
  process.exit(1);
}

if (format !== 'markdown' && format !== 'text') {
  console.error(`Error: Unsupported format '${format}'`);
  process.exit(1);
}

// Read and parse JSON data
let data: ReportData;
try {
  const fileContent = readFileSync(filePath, 'utf-8');
  data = JSON.parse(fileContent);
} catch (err: unknown) {
  console.error(`Error: Failed to read or parse JSON file '${filePath}'`);
  process.exit(1);
}

// Render report based on format
let output: string;
try {
  if (format === 'markdown') {
    output = renderMarkdown(data, { includeTotals });
  } else {
    output = renderText(data, { includeTotals });
  }
} catch (err: unknown) {
  if (err instanceof Error) {
    console.error(`Error: ${err.message}`);
  } else {
    console.error(`Error: Unknown error occurred during rendering`);
  }
  process.exit(1);
}

// Output to stdout or file
if (outputPath) {
  try {
    writeFileSync(outputPath, output);
  } catch (err: unknown) {
    console.error(`Error: Failed to write to output file '${outputPath}'`);
    process.exit(1);
  }
} else {
  console.log(output);
}