export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses using comprehensive regex patterns.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Basic structure check - should have exactly one @
  const atIndex = value.indexOf('@');
  if (atIndex === -1 || value.lastIndexOf('@') !== atIndex) {
    return false;
  }

  const localPart = value.slice(0, atIndex);
  const domainPart = value.slice(atIndex + 1);

  // Local part validation
  // Cannot start or end with dot, no consecutive dots
  if (localPart.startsWith('.') || localPart.endsWith('.') || localPart.includes('..')) {
    return false;
  }

  // Local part regex: allow letters, digits, dots, hyphens, plus, underscores
  // But cannot have consecutive dots or start/end with dot
  const localRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+$/;
  if (!localRegex.test(localPart)) {
    return false;
  }

  // Domain part validation
  // Cannot have underscores
  if (domainPart.includes('_')) {
    return false;
  }

  // Cannot start or end with dot or hyphen, no consecutive dots
  if (domainPart.startsWith('.') || domainPart.endsWith('.') || 
      domainPart.startsWith('-') || domainPart.endsWith('-') || 
      domainPart.includes('..')) {
    return false;
  }

  // Domain regex: letters, digits, hyphens, dots
  // Must have at least one dot separating domain and TLD
  const domainRegex = /^[a-zA-Z0-9.-]+$/;
  if (!domainRegex.test(domainPart) || !domainPart.includes('.')) {
    return false;
  }

  // Validate each domain label cannot be empty or start/end with hyphen
  const labels = domainPart.split('.');
  for (const label of labels) {
    if (label.length === 0 || label.startsWith('-') || label.endsWith('-')) {
      return false;
    }
  }

  // TLD should be at least 2 characters
  const tld = labels[labels.length - 1];
  if (tld.length < 2) {
    return false;
  }

  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Rejects impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Minimum length should be 10 digits (without country code)
  if (digits.length < 10) {
    return false;
  }
  
  // Maximum reasonable length (with country code and maybe extension)
  if (digits.length > 15) {
    return false;
  }
  
  // Handle optional +1 country code
  let phoneNumber = digits;
  if (phoneNumber.length > 10 && phoneNumber.startsWith('1')) {
    phoneNumber = phoneNumber.slice(1); // Remove the 1
  } else if (phoneNumber.length > 10) {
    // If longer than 10 but doesn't start with 1, invalid
    return false;
  }
  
  // Now should be exactly 10 digits for the main number
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  // Exchange code (middle 3 digits) cannot start with 0 or 1
  const exchangeCode = phoneNumber.slice(3, 6);
  if (exchangeCode.startsWith('0') || exchangeCode.startsWith('1')) {
    return false;
  }
  
  // Validate the format matches one of the accepted patterns
  // This regex handles: (212) 555-7890, 212-555-7890, 212.555.7890, 2125557890, +1-212-555-7890, etc.
  const phoneRegex = /^\+?1?[\s.-]*\(?([2-9]\d{2})\)?[\s.-]*([2-9]\d{2})[\s.-]*(\d{4})$/;
  
  return phoneRegex.test(value.trim());
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 * Rules: optional +54, optional trunk prefix 0, optional mobile indicator 9,
 * area code 2-4 digits, subscriber number 6-8 digits.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation, but keep them for regex pattern matching
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Main regex pattern for Argentine phone numbers
  // Pattern explanation:
  // ^ optionally starts with +54 (country code)
  // optionally followed by 9 (mobile indicator)
  // optionally followed by 0 (trunk prefix) when no country code
  // then area code (2-4 digits, not starting with 0)
  // then subscriber number (6-8 digits)
  // $
  const argentinePhoneRegex = /^(?:\+54)?(?:9)?(0?[1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleaned.match(argentinePhoneRegex);
  if (!match) {
    return false;
  }
  
  const areaCodeWithOptionalZero = match[1];
  const subscriberNumber = match[2];
  
  // Extract area code without trunk prefix
  const areaCode = areaCodeWithOptionalZero.startsWith('0') 
    ? areaCodeWithOptionalZero.slice(1) 
    : areaCodeWithOptionalZero;
  
  // Area code must be 2-4 digits and cannot start with 0
  if (areaCode.length < 2 || areaCode.length > 4 || !/^[1-9]/.test(areaCode)) {
    return false;
  }
  
  // Subscriber number must be 6-8 digits
  if (!/^\d{6,8}$/.test(subscriberNumber)) {
    return false;
  
  }
  
  // Check if country code is omitted, must start with trunk prefix 0
  if (!cleaned.startsWith('+54') && !areaCodeWithOptionalZero.startsWith('0')) {
    return false;
  }
  
  // Return true since the cleaned version validated successfully
  // and the basic structure requirements are met
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and unusual names like 'X Æ A-12'.
 */
export function isValidName(value: string): boolean {
  // Check for empty or whitespace-only names
  if (!value || !value.trim()) {
    return false;
  }
  
  // Should not contain digits
  if (/\d/.test(value)) {
    return false;
  }
  
  // Should not contain certain symbols that are uncommon in names
  // This excludes common allowed characters: letters, accents, apostrophes, hyphens, spaces
  const forbiddenChars = /[!@#$%^&*()_+=\[\]{}|\:;"<>?,./`~]/;
  if (forbiddenChars.test(value)) {
    return false;
  }
  
  // Allow unicode letters (including accented characters), apostrophes, hyphens, spaces
  // Use Unicode property escape for letters
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) {
    return false;
  }
  
  // Should not have consecutive apostrophes or hyphens that look unusual
  if (/[']{2,}|[-]{2,}/.test(value)) {
    return false;
  }
  
  // Should not start or end with apostrophe, hyphen, or space
  if (/^[ '\-]|[ '\-]$/.test(value)) {
    return false;
  }
  
  // Reject obviously unusual patterns like multiple special characters in a row
  // or patterns that suggest non-traditional names
  if (/(?:['\-\s]{3,})/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx with proper prefixes and lengths.
 * Runs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cardNumber = value.replace(/\D/g, '');
  
  // Check if it's all digits after cleaning
  if (!/^\d+$/.test(cardNumber)) {
    return false;
  }
  
  // Check length for different card types
  // Visa: 13 or 16 digits, starts with 4
  const visaRegex = /^4(\d{12}|\d{15})$/;
  
  // Mastercard: 16 digits, starts with 51-55 or 2221-2720
  const mastercardRegex = /^(5[1-5]\d{14}|2(2[2-9]\d{12}|[3-6]\d{13}|7([01]\d|20)\d{12}))$/;
  
  // American Express: 15 digits, starts with 34 or 37
  const amexRegex = /^3[47]\d{13}$/;
  
  // Check if it matches any of the supported card patterns
  const isValidFormat = visaRegex.test(cardNumber) || 
                       mastercardRegex.test(cardNumber) || 
                       amexRegex.test(cardNumber);
  
  if (!isValidFormat) {
    return false;
  }
  
  // Run Luhn checksum validation
  return runLuhnCheck(cardNumber);
}
