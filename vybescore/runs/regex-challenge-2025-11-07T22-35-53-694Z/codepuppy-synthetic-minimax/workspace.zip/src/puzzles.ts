/**
 * Finds words starting with the prefix but excluding the listed exceptions.
 * Returns an array of matching words in order of appearance.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || !prefix) return [];
  
  // Split text into words
  const words = text.split(/\s+/);
  
  // Filter words that start with the prefix and are not in exceptions
  const filteredWords = words.filter(word => {
    // Check if word starts with the prefix (case-sensitive)
    if (!word.startsWith(prefix)) {
      return false;
    }
    
    // Check if word is not in exceptions
    const lowerWord = word.toLowerCase();
    const hasException = exceptions.some(exception => {
      const lowerException = exception.toLowerCase();
      return lowerWord === lowerException;
    });
    
    return !hasException;
  });
  
  // Remove duplicates while preserving order
  const uniqueWords: string[] = [];
  const seen = new Set<string>();
  
  for (const word of filteredWords) {
    if (!seen.has(word)) {
      seen.add(word);
      uniqueWords.push(word);
    }
  }
  
  return uniqueWords;
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 * Returns the digit + token combination (e.g., '1foo').
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || !token) return [];
  
  // Simple approach: split by spaces and check each word
  const words = text.split(/\s+/);
  const results: string[] = [];
  
  for (const word of words) {
    // Check if word contains digit followed by token at the end
    const match = word.match(/\d+/);
    if (match && word.endsWith(token)) {
      results.push(word);
    }
  }
  
  return results;
}

/**
 * Validates passwords according to strong security policy.
 * Requirements: at least 10 characters, one uppercase, one lowercase, 
 * one digit, one symbol, no whitespace, no immediate repeated sequences.
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // Minimum length requirement
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // At least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // At least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // At least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // At least one symbol (non-alphanumeric)
  if (!/[^A-Za-z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, 123123)
  // This pattern looks for repeated sequences of 2-4 characters
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) {
    return false;
  }
  
  // Additional check for patterns like 'ababa' (where a longer sequence contains repeated sub-patterns)
  // Check for any character repeated 3 or more times in sequence
  if (/(.)\1\1+/.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger a positive result.
 * Returns true if a valid IPv6 address is found in the text.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') {
    return false;
  }
  
  // First, ensure we don't mistakenly identify IPv4 as IPv6
  // IPv4 pattern to exclude
  const ipv4Pattern = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it's clearly IPv4, it's not IPv6
  if (ipv4Pattern.test(value)) {
    // But check if there are also IPv6 patterns in the same string
    // Remove the IPv4 address and check if anything looks like IPv6 left
    const withoutIpv4 = value.replace(ipv4Pattern, ' ').trim();
    if (!withoutIpv4) return false; // Only IPv4 present
  }
  
  // IPv6 patterns covering various formats:
  // 1. Full format: xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx:xxxx
  // 2. With :: shorthand
  // 3. With embedded IPv4
  // 4. Various valid characters (0-9, a-f, A-F)
  
  const ipv6Patterns = [
    // Full 8 groups of 1-4 hex digits
    /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b/,
    
    // With :: replacing one or more groups of zeros
    /\b(?:[0-9a-fA-F]{1,4}:){1,7}:[0-9a-fA-F]{0,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,2}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,5}:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,3}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,4}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,3}:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,5}\b/,
    /\b(?:[0-9a-fA-F]{1,4}:){1,2}:[0-9a-fA-F]{1,4}(?::[0-9a-fA-F]{1,4}){0,6}\b/,
    /\b[0-9a-fA-F]{1,4}:(?::[0-9a-fA-F]{1,4}){0,7}\b/,
    
    // Special case: ::
    /\b::[0-9a-fA-F]{0,4}(?::[0-9a-fA-F]{0,4}){0,7}\b/,
    /\b[0-9a-fA-F]{0,4}::(?::[0-9a-fA-F]{0,4}){0,7}\b/,
    
    // IPv6 with embedded IPv4 (like ::ffff:192.168.1.1)
    /\b(?:[0-9a-fA-F]{1,4}:){1,4}:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/,
    
    // Compressed IPv6 with IPv4
    /\b::(?:ffff:)?(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/
  ];
  
  // Test each IPv6 pattern
  for (const pattern of ipv6Patterns) {
    if (pattern.test(value)) {
      return true;
    }
  }
  
  return false;
}
