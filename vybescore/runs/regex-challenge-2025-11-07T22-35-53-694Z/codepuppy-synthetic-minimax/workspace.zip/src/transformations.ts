/**
 * Capitalizes the first character of each sentence after .?!,
 * inserts exactly one space between sentences, collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text) return text;
  
  // Normalize multiple spaces to single spaces
  let normalized = text.replace(/\s+/g, ' ');
  
  // Trim leading and trailing spaces
  normalized = normalized.trim();
  
  // Capitalize first character of string
  let result = normalized.charAt(0).toUpperCase() + normalized.slice(1);
  
  // Capitalize after sentence punctuation
  result = result.replace(/([.!?]\s*)([a-z])/g, (match, punctuation, letter) => {
    return punctuation + letter.toUpperCase();
  });
  
  // Ensure single space after punctuation
  result = result.replace(/([.!?])\s+/g, '$1 ');
  
  return result;
}

/**
 * Extracts URLs from the text, returning them without trailing punctuation.
 * Handles http://, https://, and other URL formats.
 */
export function extractUrls(text: string): string[] {
  if (!text) return [];
  
  // Simple but effective URL regex pattern
  // Matches http://, https:// followed by domain and optional path
  const urlRegex = /https?:\/\/[^\s\n"'<>]+/gi;
  
  // Find all URLs
  const matches = text.match(urlRegex) || [];
  
  // Clean each URL by removing trailing punctuation
  const cleanedUrls = matches.map(url => {
    // Remove trailing punctuation that's not part of the URL
    return url.replace(/[.,;:!?)\]\}]+$/, '');
  });
  
  // Remove duplicates while preserving order
  const uniqueUrls = [...new Set(cleanedUrls)];
  
  return uniqueUrls;
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 * Replaces http:// with https:// throughout the text.
 */
export function enforceHttps(text: string): string {
  if (!text) return text;
  
  // Replace http:// with https://, but only when it's not already https://
  // Use word boundary to avoid partial matches
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic hints: cgi-bin, query strings, or legacy extensions
 * - Preserves nested paths like /docs/api/v1
 */
export function rewriteDocsUrls(text: string): string {
  if (!text) return text;
  
  // First upgrade all http:// to https://
  let result = text.replace(/\bhttp:\/\//g, 'https://');
  
  // Pattern to match URLs we need to potentially rewrite
  // Looking for https://example.com/... where example.com could be any domain
  const urlPattern = /(https:\/\/[^\s\n]+\.[^\s\n]+(\/[^\s\n]*)?)/gi;
  
  result = result.replace(urlPattern, (url) => {
    try {
      // Parse the URL to extract components
      const urlMatch = url.match(/^(https:\/\/)([^\/]+)(\/[^\s\n]*)?$/i);
      if (!urlMatch) return url;
      
      const [, scheme, hostname, path = ''] = urlMatch;
      
      // Check if path starts with /docs/
      if (path.startsWith('/docs/')) {
        // Check if we should skip the host rewrite due to dynamic hints
        const dynamicHints = [
          'cgi-bin',
          '\.jsp$',
          '\.php$',
          '\.asp$',
          '\.aspx$',
          '\.do$',
          '\.cgi$',
          '\.pl$',
          '\.py$'
        ];
        
        // Check for query strings
        if (path.includes('?') || path.includes('&') || path.includes('=')) {
          return url; // Skip host rewrite but keep https upgrade
        }
        
        // Check for legacy extensions
        const hasDynamicHint = dynamicHints.some(hint => {
          const regex = new RegExp(hint, 'i');
          return regex.test(path);
        });
        
        if (hasDynamicHint) {
          return url; // Skip host rewrite but keep https upgrade
        }
        
        // Rewrite host to docs.example.com
        return scheme + 'docs.' + hostname + path;
      }
      
      return url; // No rewrite needed, but https was already applied
    } catch (error) {
      // If parsing fails, return original URL (but with https upgrade)
      return url;
    }
  });
  
  return result;
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') {
    return 'N/A';
  }
  
  // Regex to match mm/dd/yyyy format exactly
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const [, month, day, year] = match;
  
  // Convert to numbers for validation
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  const yearNum = parseInt(year, 10);
  
  // Validate day based on month (basic validation, not handling leap years etc.)
  const maxDays = {
    1: 31, 2: 29, 3: 31, 4: 30, 5: 31, 6: 30,
    7: 31, 8: 31, 9: 30, 10: 31, 11: 30, 12: 31
  };
  
  if (dayNum > maxDays[monthNum as keyof typeof maxDays]) {
    return 'N/A';
  }
  
  // Basic year validation - no ridiculous years
  if (yearNum < 1900 || yearNum > 2100) {
    return 'N/A';
  }
  
  return year;
}
