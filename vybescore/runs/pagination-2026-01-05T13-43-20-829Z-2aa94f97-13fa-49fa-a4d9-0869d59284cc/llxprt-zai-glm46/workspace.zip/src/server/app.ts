import express, { type Express, type Request, type Response } from 'express';
import cors from 'cors';
import type { Database } from 'sql.js';
import { createDatabase } from './db';
import { listInventory } from './inventoryRepository';

function parsePositiveInteger(value: string | undefined): number | null | undefined {
  if (value === undefined) return undefined;
  if (value.trim() === '') return null;
  const num = Number(value);
  if (Number.isNaN(num)) return null;
  if (!Number.isInteger(num)) return null;
  if (!Number.isFinite(num)) return null;
  return num;
}

export async function createApp(existingDb?: Database): Promise<Express> {
  const db = existingDb ?? (await createDatabase());
  const app = express();

  app.use(cors());

  app.get('/inventory', (req: Request, res: Response) => {
    const pageParam = req.query.page as string | undefined;
    const limitParam = req.query.limit as string | undefined;

    const page = parsePositiveInteger(pageParam);
    const limit = parsePositiveInteger(limitParam);

    try {
      const payload = listInventory(db, { page: page ?? undefined, limit: limit ?? undefined });
      res.json(payload);
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Invalid request parameters';
      res.status(400).json({ error: message });
    }
  });

  return app;
}
