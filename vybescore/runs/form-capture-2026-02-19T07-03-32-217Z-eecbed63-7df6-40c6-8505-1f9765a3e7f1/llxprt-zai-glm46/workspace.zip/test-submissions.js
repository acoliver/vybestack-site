#!/usr/bin/env node
// Simple test script to verify the form submissions

const http = require('http');

const PORT = 3535;
const HOST = 'localhost';

function testSubmission(data) {
  return new Promise((resolve, reject) => {
    const postData = JSON.stringify(data);

    const options = {
      hostname: HOST,
      port: PORT,
      path: '/submit',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Content-Length': Buffer.byteLength(postData)
      }
    };

    const req = http.request(options, (res) => {
      let data = '';

      res.on('data', (chunk) => {
        data += chunk;
      });

      res.on('end', () => {
        resolve({ statusCode: res.statusCode, headers: res.headers });
      });
    });

    req.on('error', (e) => {
      reject(e);
    });

    req.write(postData);
    req.end();
  });
}

async function runTests() {
  console.log('Testing form submissions...\n');

  const testCases = [
    {
      name: 'UK submission',
      data: {
        firstName: 'John',
        lastName: 'Smith',
        streetAddress: '221B Baker Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'NW1 6XE',
        country: 'United Kingdom',
        email: 'john.smith@example.co.uk',
        phone: '+44 20 7946 0958'
      }
    },
    {
      name: 'Argentina submission',
      data: {
        firstName: 'María',
        lastName: 'González',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria.gonzalez@example.com.ar',
        phone: '+54 9 11 1234-5678'
      }
    },
    {
      name: 'Invalid email (should fail)',
      data: {
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'Test State',
        postalCode: '12345',
        country: 'Test Country',
        email: 'not-a-valid-email',
        phone: '+1 555-123-4567'
      }
    }
  ];

  for (const testCase of testCases) {
    console.log(`Testing: ${testCase.name}`);
    try {
      const result = await testSubmission(testCase.data);
      console.log(`  Status: ${result.statusCode}`);
      console.log(`  Location: ${result.headers.location || 'N/A'}`);
      console.log('');
    } catch (error) {
      console.log(`  Error: ${error.message}`);
      console.log('');
    }
  }

  console.log('Tests completed!');
}

runTests().catch(console.error);
