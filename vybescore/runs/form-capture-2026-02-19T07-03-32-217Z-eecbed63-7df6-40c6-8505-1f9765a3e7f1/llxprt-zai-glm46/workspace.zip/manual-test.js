#!/usr/bin/env node
// Manual integration test script
import request from 'supertest';
import { app, ensureDatabase } from './dist/server.js';

async function runTests() {
  console.log('Starting manual integration tests...\n');

  await ensureDatabase();

  const testCases = [
    {
      name: 'UK submission',
      data: {
        firstName: 'John',
        lastName: 'Smith',
        streetAddress: '221B Baker Street',
        city: 'London',
        stateProvince: 'England',
        postalCode: 'NW1 6XE',
        country: 'United Kingdom',
        email: 'john.smith@example.co.uk',
        phone: '+44 20 7946 0958'
      }
    },
    {
      name: 'Argentina submission',
      data: {
        firstName: 'María',
        lastName: 'González',
        streetAddress: 'Av. Corrientes 1234',
        city: 'Buenos Aires',
        stateProvince: 'CABA',
        postalCode: 'C1000',
        country: 'Argentina',
        email: 'maria.gonzalez@example.com.ar',
        phone: '+54 9 11 1234-5678'
      }
    },
    {
      name: 'US submission',
      data: {
        firstName: 'Jane',
        lastName: 'Doe',
        streetAddress: '456 Main Street',
        city: 'New York',
        stateProvince: 'NY',
        postalCode: '10001',
        country: 'United States',
        email: 'jane.doe@example.com',
        phone: '+1 (555) 123-4567'
      }
    }
  ];

  console.log('Testing GET / route...\n');
  const getResponse = await request(app).get('/');
  console.log(`[OK] GET / returned status ${getResponse.status}`);
  console.log(`[OK] Form contains "Tell us who you are": ${getResponse.text.includes('Tell us who you are')}\n`);

  for (const testCase of testCases) {
    console.log(`Testing: ${testCase.name}`);
    const response = await request(app)
      .post('/submit')
      .send(testCase.data);

    if (response.status === 302) {
      console.log(`  [OK] Redirected to: ${response.headers.location}`);
    } else {
      console.log(`   Unexpected status: ${response.status}`);
    }
    console.log('');
  }

  console.log('Testing validation errors...\n');
  const invalidData = {
    firstName: '',
    lastName: '',
    streetAddress: '',
    city: '',
    stateProvince: '',
    postalCode: '',
    country: '',
    email: 'invalid-email',
    phone: ''
  };

  const errorResponse = await request(app)
    .post('/submit')
    .send(invalidData);

  console.log(`[OK] Validation returned status ${errorResponse.status} (expected 400)`);
  console.log(`[OK] Contains "First name is required": ${errorResponse.text.includes('First name is required')}`);
  console.log(`[OK] Contains "Email must be valid": ${errorResponse.text.includes('Email must be valid')}\n`);

  console.log('Testing thank-you page...\n');
  const thankYouResponse = await request(app).get('/thank-you');
  console.log(`[OK] GET /thank-you returned status ${thankYouResponse.status}`);
  console.log(`[OK] Contains "Thank you": ${thankYouResponse.text.includes('Thank you')}`);
  console.log(`[OK] Contains spam warning: ${thankYouResponse.text.includes('stranger on the internet')}\n`);

  console.log('All manual integration tests completed! [OK]');
}

runTests().catch(console.error);
