import express, { Request, Response, NextFunction } from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { getDatabase, closeDatabase, type Submission } from './database.js';
import {
  validateSubmission,
  type FormData as ValidationFormData,
} from './validators.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = process.env.PORT || '3535';

const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use('/public', express.static(path.resolve(__dirname, '..', 'public')));

app.set('views', path.resolve(__dirname, '..', 'src', 'templates'));
app.set('view engine', 'ejs');

interface FormRenderData {
  errors?: string[];
  values: ValidationFormData;
}

app.get('/', (_req: Request, res: Response) => {
  const data: FormRenderData = {
    errors: undefined,
    values: {},
  };
  res.render('form.ejs', data);
});

app.post('/submit', async (req: Request, res: Response, next: NextFunction) => {
  try {
    const formData: ValidationFormData = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvince: req.body.stateProvince,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phone: req.body.phone,
    };

    const validation = validateSubmission(formData);

    if (!validation.valid) {
      const data: FormRenderData = {
        errors: validation.errors,
        values: formData,
      };
      return res.status(400).render('form.ejs', data);
    }

    const db = await getDatabase();
    const submission: Submission = {
      first_name: formData.firstName!,
      last_name: formData.lastName!,
      street_address: formData.streetAddress!,
      city: formData.city!,
      state_province: formData.stateProvince!,
      postal_code: formData.postalCode!,
      country: formData.country!,
      email: formData.email!,
      phone: formData.phone!,
    };

    db.insertSubmission(submission);
    db.save();

    res.redirect(302, '/thank-you');
  } catch (error) {
    next(error);
  }
});

app.get('/thank-you', (_req: Request, res: Response) => {
  const firstName = 'Friend';
  res.render('thank-you.ejs', { firstName });
});

app.use((err: Error, _req: Request, res: Response) => {
  console.error('Server error:', err);
  res.status(500).send('Internal server error');
});

let server: ReturnType<typeof app.listen> | null = null;
let cleanupPromise: Promise<void> | null = null;

export function startServer(): ReturnType<typeof app.listen> {
  if (server) {
    console.log(`Server already running on port ${PORT}`);
    return server;
  }
  
  // Wait for any pending cleanup
  if (cleanupPromise) {
    throw new Error('Server is cleaning up, please wait');
  }
  
  server = app.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
  });
  return server;
}

export function stopServer(callback?: () => void): void {
  if (!server) {
    closeDatabase();
    if (callback) callback();
    return;
  }
  
  cleanupPromise = new Promise<void>((resolve) => {
    server!.close(() => {
      closeDatabase();
      console.log('Server closed gracefully');
      server = null;
      cleanupPromise = null;
      if (callback) {
        callback();
      }
      resolve();
    });
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();

  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    stopServer();
    process.exit(0);
  });
}
