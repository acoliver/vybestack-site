declare module 'sql.js' {
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  export interface SqlJsStatic {
    Database: DatabaseConstructor;
    Buffer: (buffer: Buffer) => void;
  }

  export interface DatabaseConstructor {
    new (): Database;
    new (buffer: Buffer): Database;
  }

  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    prepare(sql: string): Statement;
    export(): Uint8Array;
    close(): void;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface Statement {
    bind(values: unknown[]): void;
    step(): boolean | void;
    free(): void;
    getColumnNames(): string[];
    getAsObject(params?: unknown): unknown;
  }

  interface SqlJsConfig {
    locateFile?: (filename: string) => string;
  }

  export default function initSqlJs(config?: SqlJsConfig): Promise<SqlJsStatic>;
}
