export interface ValidationResult {
  valid: boolean;
  errors: string[];
}

export interface FormData {
  firstName?: string;
  lastName?: string;
  streetAddress?: string;
  city?: string;
  stateProvince?: string;
  postalCode?: string;
  country?: string;
  email?: string;
  phone?: string;
}

const EMAIL_REGEX = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
const PHONE_REGEX = /^\+?[\d\s\-()]+$/;
const POSTAL_CODE_REGEX = /^[\d\sA-Za-z-]+$/;

export function validateEmail(email: string): boolean {
  return EMAIL_REGEX.test(email.trim());
}

export function validatePhone(phone: string): boolean {
  const trimmed = phone.trim();
  if (trimmed.length === 0) {
    return false;
  }
  return PHONE_REGEX.test(trimmed);
}

export function validatePostalCode(code: string): boolean {
  const trimmed = code.trim();
  if (trimmed.length === 0) {
    return false;
  }
  return POSTAL_CODE_REGEX.test(trimmed);
}

export function validateRequired(value: string): boolean {
  return value.trim().length > 0;
}

export function validateSubmission(data: FormData): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || !validateRequired(data.firstName)) {
    errors.push('First name is required.');
  }

  if (!data.lastName || !validateRequired(data.lastName)) {
    errors.push('Last name is required.');
  }

  if (!data.streetAddress || !validateRequired(data.streetAddress)) {
    errors.push('Street address is required.');
  }

  if (!data.city || !validateRequired(data.city)) {
    errors.push('City is required.');
  }

  if (!data.stateProvince || !validateRequired(data.stateProvince)) {
    errors.push('State / Province / Region is required.');
  }

  if (!data.postalCode || !validateRequired(data.postalCode)) {
    errors.push('Postal / Zip code is required.');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal code must contain only letters, digits, spaces, and hyphens.');
  }

  if (!data.country || !validateRequired(data.country)) {
    errors.push('Country is required.');
  }

  if (!data.email || !validateRequired(data.email)) {
    errors.push('Email is required.');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address.');
  }

  if (!data.phone || !validateRequired(data.phone)) {
    errors.push('Phone number is required.');
  } else if (!validatePhone(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +.');
  }

  return {
    valid: errors.length === 0,
    errors,
  };
}
