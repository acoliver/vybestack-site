import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import fs from 'node:fs';
import path from 'node:path';
import request from 'supertest';
import { startServer, stopServer } from '../../src/server.js';

const dbPath = path.resolve('data', 'submissions.sqlite');

let app: ReturnType<typeof startServer>;

beforeAll(async () => {
  // Clean up database before tests
  if (fs.existsSync(dbPath)) {
    fs.unlinkSync(dbPath);
  }
  
  // Start server with a small delay to ensure clean state
  await new Promise(resolve => setTimeout(resolve, 100));
  app = startServer();
  
  // Give server time to start
  await new Promise(resolve => setTimeout(resolve, 1000));
});

afterAll(async () => {
  // Wait a bit before cleanup to ensure all requests complete
  await new Promise(resolve => setTimeout(resolve, 500));
  
  await new Promise<void>((resolve) => {
    stopServer(() => {
      resolve();
    });
  });
  
  // Extra wait to ensure port is released
  await new Promise(resolve => setTimeout(resolve, 500));
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(app).get('/').expect(200);
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('firstName');
    expect(response.text).toContain('lastName');
    expect(response.text).toContain('streetAddress');
    expect(response.text).toContain('email');
    expect(response.text).toContain('phone');
  });

  it('persists submission and redirects', async () => {
    const response = await request(app)
      .post('/submit')
      .send({
        firstName: 'Test',
        lastName: 'User',
        streetAddress: '123 Test St',
        city: 'Test City',
        stateProvince: 'TS',
        postalCode: '12345',
        country: 'Testland',
        email: 'test@example.com',
        phone: '+1 555-123-4567'
      })
      .expect(302);

    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
