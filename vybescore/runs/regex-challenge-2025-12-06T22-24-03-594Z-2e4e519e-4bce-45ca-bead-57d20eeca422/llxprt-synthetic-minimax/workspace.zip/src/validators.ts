export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Comprehensive email validation regex
  // - Local part: letters, digits, special chars !#$%&'*+/=?^_`{|}~- and dots (but not starting/ending with dot, no consecutive dots)
  // - Domain: letters, digits, hyphens (but not starting/ending with hyphen), dots
  const emailRegex = /^[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9!#$%&'*+/=?^_`{|}~-]+)*@(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?$/;
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters except optional leading +
  const cleanPhone = value.replace(/[^\d+]/g, '');
  
  // Must have 11 digits if starts with +1, or 10 digits if not
  if (/^\+1\d{10}$/.test(cleanPhone)) {
    // Extract area code (digits 2-4)
    const areaCode = cleanPhone.substring(2, 5);
    // Area codes cannot start with 0 or 1
    return !areaCode.startsWith('0') && !areaCode.startsWith('1');
  } else if (/^\d{10}$/.test(cleanPhone)) {
    // Extract area code (digits 1-3) 
    const areaCode = cleanPhone.substring(0, 3);
    // Area codes cannot start with 0 or 1
    return !areaCode.startsWith('0') && !areaCode.startsWith('1');
  }
  
  return false;
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all separators (spaces, hyphens) for validation
  const cleanPhone = value.replace(/[\s-]/g, '');
  
  // Pattern components:
  // Optional +54, optional 9 (mobile), optional 0 (trunk), area code (2-4 digits, first digit 1-9), subscriber (remaining 6-8 digits)
  const argentinePhoneRegex = /^(?:\+54)?(?:\d)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanPhone.match(argentinePhoneRegex);
  if (!match) return false;
  
  const subscriber = match[2];
  
  // When country code is omitted, must start with trunk prefix 0
  if (!cleanPhone.startsWith('+54') && !cleanPhone.startsWith('0')) {
    return false;
  }
  
  // Total subscriber number length should be 6-8 digits
  return subscriber.length >= 6 && subscriber.length <= 8;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Pattern: Allow unicode letters, spaces, apostrophes, and hyphens
  // Must start with a letter, can contain allowed punctuation, no digits or other symbols
  const nameRegex = /^[\p{L}](?:[\p{L}\s'-]*[\p{L}])?$/u;
  
  // Additional check to reject names with obvious patterns like "X Æ A-12"
  if (/[0-9]/.test(value)) return false;
  if (value.includes('Æ')) return false;
  
  return nameRegex.test(value.trim());
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleanCard = value.replace(/\s|-/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanCard)) return false;
  
  // Credit card patterns
  // Visa: starts with 4, 13 or 16 digits
  const visaPattern = /^4\d{12}(\d{3})?$/;
  // Mastercard: 51-55 or 2221-2720, 16 digits
  const mastercardPattern = /^(5[1-5]\d{14}|2(2[2-9]\d{2}|[3-6]\d{3}|7[01]\d{2}|720)\d{12})$/;
  // AmEx: 34 or 37, 15 digits
  const amexPattern = /^3[47]\d{13}$/;
  
  const isValidPattern = visaPattern.test(cleanCard) || 
                         mastercardPattern.test(cleanCard) || 
                         amexPattern.test(cleanCard);
  
  if (!isValidPattern) return false;
  
  // Apply Luhn checksum
  return runLuhnCheck(cleanCard);
}

// Helper function for Luhn checksum validation
function runLuhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber[i]);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}