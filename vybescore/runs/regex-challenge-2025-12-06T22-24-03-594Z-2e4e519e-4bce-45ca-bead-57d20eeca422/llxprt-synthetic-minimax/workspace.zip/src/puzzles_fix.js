const fs = require('fs');

// Read the file
let content = fs.readFileSync('src/puzzles.ts', 'utf8');

// Replace the problematic line with the correct version
content = content.replace(
  /const hasSymbol = \/\[\!@#\$%\^&\*\(\)_\+=\\\[\\\{\];':"\\\\\|\,\.<>\\\/\?\]/g\.test\(value\);/,
  'const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};':"\\|,.<>\\/?]/.test(value);'
);

// Write the file back
fs.writeFileSync('src/puzzles.ts', content);
console.log('Fixed symbol regex in puzzles.ts');