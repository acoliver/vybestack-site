/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize spaces and handle sentence boundaries
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Pattern to find sentence boundaries followed by spaces and lowercase letters
  // This captures the punctuation and following text
  const sentencePattern = /([.!?])(\s+)([a-záéíóúñüç])/gi;
  
  // Capitalize the first letter after sentence punctuation
  result = result.replace(sentencePattern, (match, punct, spaces, letter) => {
    return punct + spaces + letter.toUpperCase();
  });
  
  // Capitalize the first character of the entire text if it's a letter
  if (result.length > 0 && /[a-záéíóúñüç]/i.test(result[0])) {
    result = result[0].toUpperCase() + result.slice(1);
  }
  
  return result;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex pattern
  // Matches: http://, https://, www., ftp://, and domain names with TLDs
  const urlRegex = /\b(?:(?:https?:\/\/)|(?:ftp:\/\/)|(?:www\.))?(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?\.)+[a-zA-Z]{2,}(?:\/[^\s]*)?/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Clean up URLs by removing trailing punctuation
  return matches.map(url => {
    // Remove trailing punctuation that commonly follows URLs in text
    return url.replace(/[.,!?;:]+$/, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// but don't affect https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http:// URLs and capture domain and path
const urlPattern = new RegExp('http://([^/\\s]+)(\\/[^\\s]*)?', 'gi');
  
  return text.replace(urlPattern, (match, domain, path) => {
    // Always upgrade to https
    let newUrl = `https://${domain}`;
    
    // Check if there's a path and it starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints or legacy extensions
      const hasDynamicHints = /cgi-bin|\?|&|=/.test(path);
      const hasLegacyExtensions = /\.(jsp|php|asp|aspx|do|cgi|pl|py)$/i.test(path);
      
      // Only rewrite host if no dynamic hints or legacy extensions
      if (!hasDynamicHints && !hasLegacyExtensions) {
        // Extract domain and prepend 'docs.'
        const docsDomain = `docs.${domain}`;
        newUrl = `https://${docsDomain}${path}`;
      } else {
        // Keep original domain but upgrade to https
        newUrl = `https://${domain}${path}`;
      }
    } else if (path) {
      // Non-docs paths, just upgrade to https
      newUrl = `https://${domain}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy pattern
  const datePattern = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = parseInt(match[3], 10);
  
  // Validate month (01-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [
    31, // January
    28, // February (not checking for leap year for simplicity)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }
  
  // Return the year
  return year.toString();
}