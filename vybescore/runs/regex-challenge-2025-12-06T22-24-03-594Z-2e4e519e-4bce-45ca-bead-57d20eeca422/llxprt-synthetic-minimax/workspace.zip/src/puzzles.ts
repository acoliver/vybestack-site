/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for the prefix (escape special characters)
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Create word boundary regex with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}\\w*`, 'gi');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  return matches.filter(word => {
    const lowercaseWord = word.toLowerCase();
    return !exceptions.some(exception => 
      lowercaseWord === exception.toLowerCase()
    );
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Pattern: not at the start of string, digit immediately before, then the token
  // This captures the digit and token together
  
  const matches = [];
  let match;
  
  // We need to find the position and capture the digit + token
  // Let's use a different approach - find digit followed by token, not at string start
  const digitTokenPattern = new RegExp(`(?!^)\\d${escapedToken}`, 'gi');
  
  while ((match = digitTokenPattern.exec(text)) !== null) {
    matches.push(match[0]); // This includes the digit and token
  }
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check length (at least 10 characters)
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
const hasSymbol = /[!@#$%^&*()_+={};:'" |,.>/]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for repeated sequences like "abab", "cdcd", etc.
  // Pattern: two characters followed by the same two characters
  const repeatedSequencePattern = /(..)\1/;
  if (repeatedSequencePattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if it's an IPv4 address - if so, return false
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 pattern: looks for sequences of hex digits separated by colons
  // Must contain at least two colons (IPv4 has only dots)
  if ((value.match(/:/g) || []).length < 2) {
    return false;
  }
  
  // Check if the string contains valid IPv6-like patterns
  // Pattern: sequences of hex digits and colons, allowing :: compression
  
  // More flexible pattern that looks for hex digits and colons
  const flexibleIpv6Pattern = /[a-fA-F0-9]*:[a-fA-F0-9]*:[a-fA-F0-9]*/;
  
  // Split by spaces and check each part for IPv6-like content
  const parts = value.split(/\s+/);
  
  for (const part of parts) {
    if (flexibleIpv6Pattern.test(part) && part.includes(':')) {
      // Additional check: ensure it doesn't look like a port number
      if (!/^\d+:\d+$/.test(part) && !/:\d+$/.test(part)) {
        return true;
      }
    }
  }
  
  // Also check the whole string for IPv6 patterns
  return flexibleIpv6Pattern.test(value);
}