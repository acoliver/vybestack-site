#!/usr/bin/env python3

# Fix the symbol regex in puzzles.ts - remove all unnecessary escapes
with open('src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Fix line 60 - remove unnecessary escapes:
# " doesn't need to be escaped as \" inside [] 
# / doesn't need to be escaped as \/ inside []
lines[59] = "const hasSymbol = /[!@#$%^&*()_+={};:'\\\" |,.>/]/.test(value);\n"

with open('src/puzzles.ts', 'w') as f:
    f.writelines(lines)

# Fix transformations.ts line 55 - fix the forward slash escaping
with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Use a different regex literal approach or properly escape
lines[54] = "const urlPattern = /http:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)?/gi;\n"

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Final fix: removed all unnecessary escape characters")