#!/usr/bin/env python3

# Fix the symbol regex in puzzles.ts to avoid escape character issues
with open('src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Fix line 60 - use a simpler symbol regex without unnecessary escapes
# The issue is that [ and ] don't need to be escaped inside character classes
# and - doesn't need to be escaped when at the end
lines[59] = "const hasSymbol = /[!@#$%^&*()_+=[\]{};:'\\\"|,.>\\/]/.test(value);\n"

with open('src/puzzles.ts', 'w') as f:
    f.writelines(lines)

# Fix transformations.ts line 55 - the URL regex
with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Fix line 55 - use single backslash for forward slash
lines[54] = "const urlPattern = /http:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)?/gi;\n"

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed escape character issues with simpler regex patterns")