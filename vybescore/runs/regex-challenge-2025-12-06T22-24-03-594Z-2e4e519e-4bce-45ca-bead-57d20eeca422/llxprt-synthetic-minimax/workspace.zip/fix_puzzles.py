#!/usr/bin/env python3

import re

# Read the file
with open('src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Find and fix line 60 (index 59)
for i, line in enumerate(lines):
    if i == 59:  # Line 60 in 1-based indexing
        # Replace the problematic line with the correct version
        lines[i] = "const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};':\"\\\\|,.<>\\/?]/.test(value);\n"
        print(f"Fixed line {i+1}")
        break

# Write the file back
with open('src/puzzles.ts', 'w') as f:
    f.writelines(lines)

print("Fixed symbol regex in puzzles.ts")