#!/usr/bin/env python3

# Fix puzzles.ts line 60
with open('src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Fix line 60 - symbol regex
lines[59] = "const hasSymbol = /[!@#$%^&*()_+=\\[\\]{};:'\\\"|,.>\\/?]/.test(value);\n"

with open('src/puzzles.ts', 'w') as f:
    f.writelines(lines)

# Fix transformations.ts line 55
with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Fix line 55 - URL regex
lines[54] = "const urlPattern = /http:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)?/gi;\n"

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed all escape character issues")