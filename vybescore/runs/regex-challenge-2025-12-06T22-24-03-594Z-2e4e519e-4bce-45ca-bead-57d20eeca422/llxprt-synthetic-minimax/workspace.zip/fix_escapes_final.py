#!/usr/bin/env python3

# Fix the symbol regex in puzzles.ts to avoid all escape character issues
with open('src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Fix line 60 - use a simpler symbol regex without ANY unnecessary escapes
# Inside [] character classes: [ ] don't need to be escaped, " doesn't need to be escaped, / doesn't need to be escaped
lines[59] = "const hasSymbol = /[!@#$%^&*()_+={};:'\"|,.>\\/]/.test(value);\n"

with open('src/puzzles.ts', 'w') as f:
    f.writelines(lines)

# Fix transformations.ts line 55 - use a regex literal with a different delimiter or escape properly
with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# For the URL regex, we need to escape the forward slashes properly
lines[54] = "const urlPattern = /http:\\/\\/([^\\/\\s]+)(\\/[^\\s]*)?/gi;\n"

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed escape character issues - removed all unnecessary escapes")