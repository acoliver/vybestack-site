#!/usr/bin/env python3

# Fix the remaining escape character issues
with open('src/puzzles.ts', 'r') as f:
    lines = f.readlines()

# Fix line 60 - remove escape from double quote inside character class
lines[59] = "const hasSymbol = /[!@#$%^&*()_+={};:'\" |,.>/]/.test(value);\n"

with open('src/puzzles.ts', 'w') as f:
    f.writelines(lines)

# Fix transformations.ts line 55 - try escaping forward slashes differently
with open('src/transformations.ts', 'r') as f:
    lines = f.readlines()

# Use regex constructor instead of literal to avoid forward slash escaping issues
lines[54] = "const urlPattern = new RegExp('http://([^/\\\\s]+)(\\\\/[^\\\\s]*)?', 'gi');\n"

with open('src/transformations.ts', 'w') as f:
    f.writelines(lines)

print("Fixed remaining escape character issues")