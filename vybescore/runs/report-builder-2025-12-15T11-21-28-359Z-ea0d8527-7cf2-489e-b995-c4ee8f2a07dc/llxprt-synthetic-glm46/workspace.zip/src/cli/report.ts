#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData, RenderOptions, OutputFormat } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  inputFile: string;
  format: OutputFormat;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  
  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  const formatIndex = args.indexOf('--format');
  
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format is required');
    process.exit(1);
  }

  const formatValue = args[formatIndex + 1];
  if (formatValue !== 'markdown' && formatValue !== 'text') {
    console.error('Unsupported format');
    process.exit(1);
  }

  const format = formatValue as OutputFormat;
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;
  const includeTotals = args.includes('--includeTotals');

  return {
    inputFile,
    format,
    outputPath,
    includeTotals,
  };
}

function loadReportData(filePath: string): ReportData {
  try {
    const content = readFileSync(filePath, 'utf-8');
    const data = JSON.parse(content) as unknown;
    
    if (!data || typeof data !== 'object') {
      throw new Error('Invalid JSON data');
    }

    const reportData = data as Record<string, unknown>;
    
    if (typeof reportData.title !== 'string') {
      throw new Error('Missing or invalid "title" field');
    }
    
    if (typeof reportData.summary !== 'string') {
      throw new Error('Missing or invalid "summary" field');
    }
    
    if (!Array.isArray(reportData.entries)) {
      throw new Error('Missing or invalid "entries" field');
    }

    for (let i = 0; i < reportData.entries.length; i++) {
      const entry = reportData.entries[i];
      if (!entry || typeof entry !== 'object') {
        throw new Error(`Invalid entry at index ${i}`);
      }
      
      const entryObj = entry as Record<string, unknown>;
      
      if (typeof entryObj.label !== 'string') {
        throw new Error(`Missing or invalid "label" field in entry at index ${i}`);
      }
      
      if (typeof entryObj.amount !== 'number') {
        throw new Error(`Missing or invalid "amount" field in entry at index ${i}`);
      }
    }

    return {
      title: reportData.title,
      summary: reportData.summary,
      entries: reportData.entries as ReportData['entries'],
    };
  } catch (error) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON file');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Unknown error occurred');
    }
    process.exit(1);
  }
}

function renderReport(data: ReportData, format: OutputFormat, options: RenderOptions): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, options);
    case 'text':
      return renderText(data, options);
  }
}

function main(): void {
  const { inputFile, format, outputPath, includeTotals } = parseArgs();
  const data = loadReportData(inputFile);
  const options: RenderOptions = { includeTotals };
  const output = renderReport(data, format, options);

  if (outputPath) {
    try {
      writeFileSync(outputPath, output, 'utf-8');
    } catch (error) {
      console.error('Error: Could not write to output file');
      process.exit(1);
    }
  } else {
    console.log(output);
  }
}

main();