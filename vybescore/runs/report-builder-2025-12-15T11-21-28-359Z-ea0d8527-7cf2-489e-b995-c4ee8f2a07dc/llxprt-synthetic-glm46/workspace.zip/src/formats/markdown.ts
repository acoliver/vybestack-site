import type { ReportData, RenderOptions } from '../types.js';

export function renderMarkdown(data: ReportData, options: RenderOptions): string {
  const lines: string[] = [];

  // Title
  lines.push(`# ${data.title}`);
  lines.push('');

  // Summary
  lines.push(data.summary);
  lines.push('');

  // Entries
  lines.push('## Entries');
  lines.push('');

  for (const entry of data.entries) {
    lines.push(`- **${entry.label}** — $${entry.amount.toFixed(2)}`);
  }

  // Optional totals
  if (options.includeTotals) {
    lines.push('');
    lines.push(`**Total:** $${calculateTotal(data.entries).toFixed(2)}`);
  }

  return lines.join('\n');
}

function calculateTotal(entries: ReportData['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}