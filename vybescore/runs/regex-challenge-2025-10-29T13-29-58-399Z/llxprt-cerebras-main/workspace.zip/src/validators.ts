export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses per common standards.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores, etc.
 */
export function isValidEmail(value: string): boolean {
  // Clean the input
  const email = value.trim();
  
  // Basic email pattern with Unicode support for local part
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  
  // Check basic structure
  if (!emailRegex.test(email)) {
    return false;
  }
  
  // Check for double dots
  if (email.includes('..')) {
    return false;
  }
  
  // Check for trailing dots in local part or domain
  const [localPart, domain] = email.split('@');
  if (localPart.endsWith('.') || domain.endsWith('.')) {
    return false;
  }
  
  // Check domain for underscores
  if (domain.includes('_')) {
    return false;
  }
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports: (212) 555-7890, 212-555-7890, 2125557890
 * Optional +1 prefix. Disallows impossible area codes.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters for validation
  const digits = value.replace(/\D/g, '');
  
  // Check if it starts with +1 and remove it for length checking
  let numDigits = digits;
  if (value.trim().startsWith('+1') && digits.startsWith('1')) {
    numDigits = digits.substring(1);
  }
  
  // Validate length
  if (numDigits.length !== 10) {
    return false;
  }
  
  // Validate area code (can't start with 0 or 1)
  const areaCode = numDigits.substring(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) {
    return false;
  }
  
  return true;
}

/**
 * Validates Argentine phone numbers for landlines and mobiles.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, etc.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Parse different formats
  let digits = cleanValue;
  
  // Handle country code
  if (cleanValue.startsWith('+54')) {
    digits = cleanValue.substring(3);
  } else if (cleanValue.startsWith('0')) {
    // Trunk prefix is required when no country code
    // Continue with validation
  } else {
    // No country code and no trunk prefix - invalid
    return false;
  }
  
  // Handle mobile indicator
  if (digits.startsWith('9')) {
    digits = digits.substring(1);
  }
  
  // Handle cases with trunk prefix after country code removal
  if (digits.startsWith('0')) {
    digits = digits.substring(1);
  }
  
  // Extract area code (2-4 digits, starting with 1-9)
  const areaCodeMatch = digits.match(/^([1-9]\d{1,3})/);
  if (!areaCodeMatch) {
    return false;
  }
  
  const areaCode = areaCodeMatch[1];
  const subscriberNumber = digits.substring(areaCode.length);
  
  // Validate subscriber number (6-8 digits total)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8 || !/^\d+$/.test(subscriberNumber)) {
    return false;
  }
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, and hyphens.
 * Rejects digits and symbols.
 */
export function isValidName(value: string): boolean {
  const name = value.trim();
  
  // Empty names are invalid
  if (!name) {
    return false;
  }
  
  // Names must not contain digits or symbols (except allowed ones)
  // Allow unicode letters, spaces, hyphens, apostrophes
  const nameRegex = /^[^\d\p{S}]+$/u;
  
  if (!nameRegex.test(name)) {
    return false;
  }
  
  // Reject X Æ A-12 like names (contains digits)
  if (/\d/.test(name)) {
    return false;
  }
  
  return true;
}

/**
 * Validates credit card numbers using Luhn algorithm.
 * Accept Visa/Mastercard/AmEx based on prefixes and lengths.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and dashes
  const cleanValue = value.replace(/[\s\-]/g, '');
  
  // Check if only digits
  if (!/^\d+$/.test(cleanValue)) {
    return false;
  }
  
  // Visa: 4xxx, 16 digits
  // Mastercard: 5xxx or 2xxx, 16 digits
  // AmEx: 34xx or 37xx, 15 digits
  const visaRegex = /^4\d{15}$/;
  const mastercardRegex = /^(5\d{15}|2\d{15})$/;
  const amexRegex = /^(34\d{13}|37\d{13})$/;
  
  if (!(visaRegex.test(cleanValue) || mastercardRegex.test(cleanValue) || amexRegex.test(cleanValue))) {
    return false;
  }
  
  // Luhn algorithm implementation
  return runLuhnCheck(cleanValue);
}

/**
 * Helper function to run Luhn algorithm check
 */
function runLuhnCheck(value: string): boolean {
  let sum = 0;
  const isEven = value.length % 2 === 0;
  
  for (let i = 0; i < value.length; i++) {
    let digit = parseInt(value.charAt(i), 10);
    
    // Double every second digit from right to left
    if ((i % 2 === 0) === isEven) {
      digit *= 2;
      if (digit > 9) digit -= 9;
    }
    
    sum += digit;
  }
  
  return sum % 10 === 0;
}