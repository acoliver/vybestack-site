/**
 * Capitalizes the first character of each sentence.
 * Preserves spacing and handles abbreviations properly.
 */
export function capitalizeSentences(text: string): string {
  // Replace multiple spaces with single space, but preserve sentence boundaries
  return text
    // Add space after sentence-ending punctuation if missing
    .replace(/([.?!])([a-zA-Z])/g, '$1 $2')
    // Capitalize first letter of each sentence
    .replace(/(^|[.?!]\s+)([a-z])/g, (match, p1, p2) => p1 + p2.toUpperCase())
    // Collapse extra spaces but keep single spaces
    .replace(/\s+/g, ' ')
    .trim();
}

/**
 * Extracts URLs from text, excluding trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // Regex to match URLs (http/https) and exclude trailing punctuation
  const urlRegex = /https?:\/\/(?:[-\w.])+(?:[:\d]+)?(?:\/(?:[\w\/_.])*)?(?:\?(?:[\w&=%.])*)?(?:#(?:[\w.])*)?(?=[\s\]!),.?;]|$)/gi;
  const matches = text.match(urlRegex);
  return matches ? matches.map(url => url.replace(/[.,;!?]+$/, '')) : [];
}

/**
 * Forces all HTTP URLs to HTTPS, leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites URLs with /docs/ paths to docs.example.com.
 * Upgrades all http to https.
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(
    /http:\/\/([\w\-\.]+)(\/docs\/[\w\-\/.]*)(?:\?[^\s]*)?/gi,
    (match, host, path, query) => {
      // Check if path contains dynamic elements
      if (path.match(/cgi\-bin|\.jsp|\.php|\.asp|\.aspx|\.do|\.cgi|\.pl|\.py/)) {
        // Just upgrade scheme, don't rewrite host
        return `https://${host}${path}${query || ''}`;
      }
      
      // Rewrite host to docs.example.com for /docs/ paths
      return `https://docs.${host}${path}${query || ''}`;
    }
  );
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month and day
  if (month < 1 || month > 12 || day < 1 || day > 31) {
    return 'N/A';
  }
  
  return year;
}