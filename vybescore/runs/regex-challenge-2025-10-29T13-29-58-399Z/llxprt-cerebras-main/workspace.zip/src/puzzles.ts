/**
 * Finds words in text that start with a prefix but excludes exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create a regex pattern that matches words starting with prefix but not in exceptions
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  const escapedExceptions = exceptions.map(word => word.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')).join('|');
  
  // Regex to match words beginning with prefix and not matching exceptions
  const regex = new RegExp(`\\b(?!(${escapedExceptions})\\b)${escapedPrefix}\\w*\\b`, 'gi');
  
  const matches = text.match(regex);
  return matches ? Array.from(new Set(matches.map(word => word.toLowerCase()))) : [];
}

/**
 * Finds occurrences of a token that appear after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape token for regex use
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match token that follows a digit but is not at the start of the string
  const regex = new RegExp(`(?<=\\d)${escapedToken}`, 'g');
  
  const matches = text.match(regex);
  return matches ? matches : [];
}

/**
 * Validates password strength according to specified rules.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for repeated sequences (like abab)
  if (/(\w{2,})\1/.test(value)) {
    return false;
  }
  
  // Check required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[!@#$%^&*()_+\-=\[\]{};':"\\|,.<>\/?]/.test(value);
  
  return hasUppercase && hasLowercase && hasDigit && hasSymbol;
}

/**
 * Detects IPv6 addresses while excluding IPv4.
 */
export function containsIPv6(value: string): boolean {
  // IPv6 regex pattern (simplified but functional)
  // Covers standard full format, compressed :: format, and mixed formats
  const ipv6Regex = /(?:::[\dA-Fa-f]{1,4}|[\dA-Fa-f]{1,4}(?::[\dA-Fa-f]{1,4}){7}|[\dA-Fa-f]{1,4}(?::[\dA-Fa-f]{1,4}){0,6}::[\dA-Fa-f]{1,4}(?::[\dA-Fa-f]{1,4}){0,6}|::)/;
  
  // Check if the string contains an IPv6 address
  if (!ipv6Regex.test(value)) {
    return false;
  }
  
  // Ensure it's not an IPv4 address
  const ipv4Regex = /^\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}$/;
  if (ipv4Regex.test(value)) {
    return false;
  }
  
  return true;
}