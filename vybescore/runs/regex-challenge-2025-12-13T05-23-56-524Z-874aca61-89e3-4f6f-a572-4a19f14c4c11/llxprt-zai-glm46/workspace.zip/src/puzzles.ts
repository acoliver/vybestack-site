/**
 * Finds words beginning with the specified prefix, excluding listed exceptions.
 * Returns an array of matching words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!prefix || typeof prefix !== 'string') return [];
  if (!Array.isArray(exceptions)) return [];
  
  // Create regex pattern to find words starting with the prefix
  // \b ensures word boundary, [a-zA-Z]+ matches word characters
  // Use word character pattern that includes letters and possibly apostrophes/hyphens
  const pattern = `\\b${escapeRegExp(prefix)}[a-zA-Z]*\\b`;
  const regex = new RegExp(pattern, 'g');
  
  const matches = text.match(regex) || [];
  
  // Filter out exceptions and duplicates
  const exceptionSet = new Set(exceptions.map(ex => ex.toLowerCase()));
  
  return matches
    .map(word => word.toLowerCase())
    .filter(word => !exceptionSet.has(word))
    .filter((word, index, arr) => arr.indexOf(word) === index); // Remove duplicates
}

/**
 * Helper function to escape special regex characters in the prefix.
 */
function escapeRegExp(string: string): string {
  return string.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
}

/**
 * Finds occurrences of a token that appear after a digit and not at the start of the string.
 * Uses lookaheads to find token preceded by digit and not at string beginning.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string') return [];
  if (!token || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Find all occurrences of the token in the text first
  const allOccurrences = text.split(escapedToken);
  if (allOccurrences.length <= 1) return [];
  
  const results: string[] = [];
  let currentIndex = 0;
  
  for (let i = 0; i < allOccurrences.length - 1; i++) {
    const beforeToken = allOccurrences[i];
    const tokenStartIndex = currentIndex + beforeToken.length;
    
    // Check if there's a digit immediately before this token and it's not at the start
    if (tokenStartIndex > 0 && /\d/.test(text[tokenStartIndex - 1])) {
      results.push(text[tokenStartIndex - 1] + token);
    }
    
    currentIndex = tokenStartIndex + token.length;
  }
  
  // Remove duplicates while preserving order
  return [...new Set(results)];
}

/**
 * Validates passwords according to strong password policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // No whitespace allowed
  if (/\s/.test(value)) return false;
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Must contain at least one digit
  if (!/\d/.test(value)) return false;
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[!@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/.test(value)) return false;
  
  // Check for immediate repeated sequences (e.g., abab, abcabc)
  // Look for patterns of 2-4 characters that repeat immediately
  const repeatedPattern = /(.{2,4})\1+/;
  if (repeatedPattern.test(value)) return false;
  
  // Additional check for character sequences like abab pattern
  // This catches cases where characters alternate in a predictable way
  for (let i = 2; i < value.length - 1; i++) {
    const current = value[i];
    const prev = value[i - 1];
    const prevPrev = value[i - 2];
    
    // Check for alternating patterns like abab, abcabc
    if (current === prevPrev && i >= 3) {
      const prevPrevPrev = value[i - 3];
      if (prev === prevPrevPrev) {
        return false;
      }
    }
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and ensures IPv4 addresses do not trigger false positives.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 pattern that matches all valid IPv6 formats including shorthand
  // This regex matches:
  // - Full IPv6: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed: 2001:db8::1
  // - Loopback: ::1
  // - All zeros: ::
  // - With embedded IPv4: ::ffff:192.0.2.128
  const ipv6Regex = /(?:^|(?<!\d))(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,7}:|(?:[0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:){1,5}(?::[0-9a-fA-F]{1,4}){1,2}|(?:[0-9a-fA-F]{1,4}:){1,4}(?::[0-9a-fA-F]{1,4}){1,3}|(?:[0-9a-fA-F]{1,4}:){1,3}(?::[0-9a-fA-F]{1,4}){1,4}|(?:[0-9a-fA-F]{1,4}:){1,2}(?::[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:(?:(?::[0-9a-fA-F]{1,4}){1,6})|:(?:(?::[0-9a-fA-F]{1,4}){1,7}|:)/;
  
  // First check if we have an IPv6 match
  const hasIPv6 = ipv6Regex.test(value);
  if (!hasIPv6) return false;
  
  // Now check if it's actually an IPv4 address (which should return false)
  // IPv4 pattern: 0-255.0-255.0-255.0-255
  const ipv4Regex = /\b(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\b/;
  
  // If it looks like IPv4, it's not IPv6
  if (ipv4Regex.test(value)) return false;
  
  // Additional check: ensure we don't have mixed patterns that could be confused
  // Look for typical IPv6 characteristics that IPv4 doesn't have
  const hasIPv6Characteristics = /::|^[0-9a-fA-F]*:[0-9a-fA-F:]*/.test(value);
  
  return hasIPv6Characteristics;
}
