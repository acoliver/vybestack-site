export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses with comprehensive regex.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email format regex
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$/;
  
  // Additional checks for invalid patterns
  if (/\\.\\./.test(value)) return false; // double dots
  if (value.startsWith('.') || value.endsWith('.')) return false; // leading/trailing dots
  if (value.includes('@.') || value.includes('.@')) return false; // dots around @
  if (value.includes('_')) return false; // underscores not allowed per requirements
  
  if (!emailRegex.test(value)) return false;
  
  // Additional validation: domain cannot have underscores
  const [local, domain] = value.split('@');
  if (domain.includes('_')) return false;
  
  // Domain cannot end with dot
  if (domain.endsWith('.')) return false;
  
  // Local part cannot be empty
  if (local.length === 0) return false;
  
  return true;
}

/**
 * Validates US phone numbers supporting common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all non-digit characters first
  const digitsOnly = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, plus optional country code)
  if (digitsOnly.length < 10 || digitsOnly.length > 11) return false;
  
  // Handle optional country code
  let phoneNumber = digitsOnly;
  if (digitsOnly.length === 11) {
    // If 11 digits, must start with 1 (US country code)
    if (!digitsOnly.startsWith('1')) return false;
    phoneNumber = digitsOnly.slice(1); // Remove country code for validation
  }
  
  // Must be exactly 10 digits now
  if (phoneNumber.length !== 10) return false;
  
  // Area code cannot start with 0 or 1
  const areaCode = phoneNumber.slice(0, 3);
  if (areaCode.startsWith('0') || areaCode.startsWith('1')) return false;
  
  // Validate format with regex (supports various separators)
  const phoneRegex = /^(\+?1[\s-]?)?(\(\d{3}\)|\d{3})[\s-]?\d{3}[\s-]?\d{4}$/;
  return phoneRegex.test(value);
}

/**
 * Validates Argentine phone numbers covering mobile and landline formats.
 * Handles formats like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Pattern breakdown:
  // ^\+54 - Optional country code +54
  // (?:9)? - Optional mobile indicator 9
  // (?:0)? - Optional trunk prefix 0
  // ([1-9]\d{1,3}) - Area code (2-4 digits, cannot start with 0)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const withCountryRegex = /^\+54(?:9)?(?:0)?([1-9]\d{1,3})(\d{6,8})$/;
  
  // Pattern without country code:
  // ^0 - Must start with trunk prefix 0
  // ([1-9]\d{1,3}) - Area code (2-4 digits, cannot start with 0)
  // (\d{6,8})$ - Subscriber number (6-8 digits)
  const withoutCountryRegex = /^0([1-9]\d{1,3})(\d{6,8})$/;
  
  // Try with country code first
  let match = cleanValue.match(withCountryRegex);
  if (match) {
    const [, areaCode, subscriberNumber] = match;
    // Validate area code length (2-4 digits)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    // Validate subscriber number length (6-8 digits)
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    return true;
  }
  
  // Try without country code
  match = cleanValue.match(withoutCountryRegex);
  if (match) {
    const [, areaCode, subscriberNumber] = match;
    // Validate area code length (2-4 digits)
    if (areaCode.length < 2 || areaCode.length > 4) return false;
    // Validate subscriber number length (6-8 digits)
    if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
    return true;
  }
  
  return false;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  if (value.trim().length === 0) return false;
  
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // \p{L} matches any kind of letter from any language
  // \p{M} matches combining marks (accents, diacritics)
  // Also allow apostrophe, hyphen, and space
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Reject names that contain digits
  if (/\d/.test(value)) return false;
  
  // Reject names that look like "X Æ A-12" (have numbers mixed with letters/symbols)
  // This specifically rejects patterns like letter space letter space letter-digit combo
  const problematicPattern = /\p{L}[\s\u00A0]+\p{L}[\s\u00A0]+\p{L}[-]\d/u;
  if (problematicPattern.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation for credit cards.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers for Visa/Mastercard/AmEx using regex and Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove spaces and hyphens
  const cleanCard = value.replace(/[\s-]/g, '');
  
  // Check if it contains only digits
  if (!/^\d+$/.test(cleanCard)) return false;
  
  // Visa: 13 or 16 digits starting with 4
  // Mastercard: 16 digits starting with 51-55 or 2221-2720
  // AmEx: 15 digits starting with 34 or 37
  const creditCardRegex = /^(?:4\d{12}(?:\d{3})?|5[1-5]\d{14}|3[47]\d{13}|2(?:2(?:2[1-9]|[3-9]\d)|[3-6]\d{2}|7(?:[01]\d|20))\d{12})$/;
  
  if (!creditCardRegex.test(cleanCard)) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanCard);
}
