/**
 * Capitalizes the first character of each sentence.
 * Handles proper spacing after sentence-ending punctuation (.?!).
 * Preserves abbreviations when possible and collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, collapse multiple spaces into single spaces and trim
  const normalized = text.replace(/\s+/g, ' ').trim();
  
  // Handle sentence boundaries: split on sentence-ending punctuation
  // Use regex to split on . ? ! followed by optional spaces
  const sentences = normalized.split(/([.?!]\s*)/);
  
  let result = '';
  let capitalizeNext = true; // First character should be capitalized
  
  for (let i = 0; i < sentences.length; i++) {
    const segment = sentences[i];
    
    if (segment.match(/[.?!]\s*/)) {
      // This is sentence-ending punctuation + spaces
      result += segment;
      capitalizeNext = true;
    } else if (segment.length > 0) {
      // This is a sentence content
      if (capitalizeNext) {
        // Capitalize first character and keep the rest as-is
        result += segment.charAt(0).toUpperCase() + segment.slice(1);
        capitalizeNext = false;
      } else {
        result += segment;
      }
    }
  }
  
  // Ensure single space after punctuation if needed
  result = result.replace(/([.?!])(?=\S)/g, '$1 ');
  
  return result.trim();
}

/**
 * Extracts URLs from text, removing trailing punctuation.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Regex to match URLs
  const urlRegex = /\b((?:https?:\/\/|www\.)[^\s<>"]+)(?=[,.!?;:]?(?:\s|$))/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each URL using a simpler approach
  return matches.map(url => {
    // Remove trailing punctuation characters one by one
    let cleaned = url;
    const punctuationChars = '.,!?;:)}]';
    while (cleaned && punctuationChars.includes(cleaned[cleaned.length - 1])) {
      cleaned = cleaned.slice(0, -1);
    }
    return cleaned;
  });
}

/**
 * Converts all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Replace http:// with https:// (not affecting https://)
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites documentation URLs according to specific rules:
 * - Always upgrade scheme from http:// to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic content (cgi-bin, query strings, legacy extensions)
 * - Preserve nested paths
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Regex to match http://example.com URLs with optional paths
  const urlRegex = /http:\/\/example\.com(\/[^\s<>"]*)?/gi;
  
  return text.replace(urlRegex, (match, path = '') => {
    // Always upgrade to HTTPS
    let newUrl = 'https://example.com' + path;
    
    // Check if we should rewrite the host to docs.example.com
    if (path.startsWith('/docs/')) {
      // Check for dynamic content that should skip host rewrite
      const dynamicPatterns = [
        /\/cgi-bin\//,
        /[?&=]/, // query string indicators
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(?:[?#]|$)/i // legacy extensions
      ];
      
      const shouldSkipHostRewrite = dynamicPatterns.some(pattern => pattern.test(path));
      
      if (!shouldSkipHostRewrite) {
        // Rewrite host to docs.example.com
        newUrl = 'https://docs.example.com' + path;
      }
    }
    
    return newUrl;
  });
}

/**
 * Extracts the year from mm/dd/yyyy format strings.
 * Returns the four-digit year if valid, or 'N/A' for invalid formats.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regex to match mm/dd/yyyy format exactly
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  
  // Validate month (01-12)
  const monthNum = parseInt(month, 10);
  if (monthNum < 1 || monthNum > 12) return 'N/A';
  
  // Validate day based on month
  const dayNum = parseInt(day, 10);
  const daysInMonth = [
    31, // January
    28, // February (non-leap year)
    31, // March
    30, // April
    31, // May
    30, // June
    31, // July
    31, // August
    30, // September
    31, // October
    30, // November
    31  // December
  ];
  
  let maxDay = daysInMonth[monthNum - 1];
  
  // Handle leap year for February
  if (monthNum === 2) {
    const yearNum = parseInt(year, 10);
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || yearNum % 400 === 0;
    if (isLeapYear) maxDay = 29;
  }
  
  if (dayNum < 1 || dayNum > maxDay) return 'N/A';
  
  return year;
}