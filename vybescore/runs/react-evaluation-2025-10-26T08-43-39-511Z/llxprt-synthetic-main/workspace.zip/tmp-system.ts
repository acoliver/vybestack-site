/**
 * Simpler reactive implementation based on Solid.js principles
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

// Track current computation context
let currentObserver: (() => void) | undefined

// Global signal store for dependency tracking
const signals = new Set<Signal<any>>()

// Simple signal class
class Signal<T> {
  value: T
  observers: Set<() => void> = new Set()

  constructor(value: T) {
    this.value = value
  }

  get() {
    if (currentObserver) {
      this.observers.add(currentObserver)
    }
    return this.value
  }

  set(value: T) {
    if (this.value !== value) {
      this.value = value
      // Notify all observers
      this.observers.forEach(observer => observer())
    }
  }
}

// Simple computed function
function createComputed<T>(fn: () => T): () => T {
  let cachedValue: T
  let dirty = true
  
  const compute = () => {
    // First, remove this computation from all signals
    signals.forEach(signal => {
      signal.observers.delete(compute)
    })
    
    const prevObserver = currentObserver
    currentObserver = compute
    try {
      cachedValue = fn()
      dirty = false
    } finally {
      currentObserver = prevObserver
    }
  }
  
  const getter = () => {
    if (dirty) {
      compute()
    }
    return cachedValue
  }
  
  // Initial computation
  compute()
  
  return getter
}

// Simple callback function
function createCallback(fn: () => void): () => void {
  let disposed = false
  
  const callback = () => {
    if (disposed) return
    fn()
  }
  
  // Setup dependency tracking
  const prevObserver = currentObserver
  currentObserver = callback
  try {
    fn() // Initial run to track dependencies
  } finally {
    currentObserver = prevObserver
  }
  
  return () => {
    disposed = true
    // Clean up observers
    signals.forEach(signal => {
      signal.observers.delete(callback)
    })
  }
}