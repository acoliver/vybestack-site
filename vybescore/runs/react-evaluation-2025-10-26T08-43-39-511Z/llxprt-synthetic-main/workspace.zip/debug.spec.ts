import { describe, it, expect } from 'vitest'
import { createInput, createComputed } from './src/index.js'

// Test to understand dependencies
describe('Debug', () => {
  it('test dependencies in final implementation', () => {
    const [input, setInput] = createInput(1)
    
    // First computed depends directly on input
    const timesTwo = createComputed(() => {
      const v = input() * 2
      console.log('timesTwo recomputing with input value:', input(), 'result:', v)
      return v
    })
    
    // Second computed also depends directly on input
    const timesThirty = createComputed(() => {
      const v = input() * 30
      console.log('timesThirty recomputing with input value:', input(), 'result:', v)  
      return v
    })
    
    // Third computed depends on the first two
    const sum = createComputed(() => {
      const v = timesTwo() + timesThirty()
      console.log('sum recomputing with timesTwo:', timesTwo(), 'timesThirty:', timesThirty(), 'result:', v)
      return v
    })
    
    console.log('Initial sum:', sum())
    
    setInput(3)
    
    console.log('After setInput, sum:', sum())
    expect(sum()).toEqual(96)
  })
})