/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

// Observer tracking - this is the key to making dependency work
let activeObserver: Observer<any> | undefined

// Map to track which subjects an observer depends on
const observerDependencies = new WeakMap<Observer<any>, Set<Subject<any>>>()

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  
  try {
    // Clear previous dependencies for this observer
    const deps = observerDependencies.get(observer)
    if (deps) {
      deps.forEach(subject => subject.observers.delete(observer))
      deps.clear()
    } else {
      observerDependencies.set(observer, new Set())
    }
    
    // Run computation to establish new dependencies and update value
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

// This gets called when an observer accesses a subject
export function trackDependency(subject: Subject<any>) {
  if (!activeObserver) return
  
  // Add this subject to the observer's current dependencies
  const deps = observerDependencies.get(activeObserver)
  if (deps) {
    deps.add(subject)
  }
  
  // Add observer to the subject's observer list  
  subject.observers.add(activeObserver)
}

// This gets called when a subject's value changes
export function notifyObservers(subject: Subject<any>) {
  // Create a copy of observers to avoid issues with modifications during iteration
  const observers = Array.from(subject.observers)
  observers.forEach(observer => updateObserver(observer))
}