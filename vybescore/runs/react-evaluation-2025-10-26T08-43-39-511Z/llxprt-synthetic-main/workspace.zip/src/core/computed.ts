/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  EqualFn,
  Options,
  getActiveObserver,
  updateObserver,
  trackDependency,
  notifyObservers
} from '../types/reactive.js'

function createDefaultEqualFn<T>(): EqualFn<T> {
  return (lhs: T, rhs: T) => lhs === rhs
}

function _processEqualParam<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') return equal ? createDefaultEqualFn<T>() : undefined
  return equal
}

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Treat this computed as a subject that others can observe
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value!,
    equalFn: _processEqualParam(equal)
  }
  
  // Run initial computation to establish dependencies
  updateObserver(o)
  computedSubject.value = o.value!
  
  // Track if we're currently updating to prevent infinite loops
  let isUpdating = false
  
  // Modify the observer's update function to notify computedSubject's observers when it updates
  const originalUpdateFn = o.updateFn
  // @ts-ignore Extend Observer with wrapper functionality 
  o.updateFn = (prevValue?: T) => {
    if (isUpdating) return originalUpdateFn(prevValue)
    
    isUpdating = true
    try {
      const result = originalUpdateFn(prevValue)
      o.value = result
      computedSubject.value = result
      
      // Notify observers of this computed when value changes
      notifyObservers(computedSubject)
      
      return result
    } finally {
      isUpdating = false
    }
  }
  
  // Return getter that establishes dependencies on demand
  const getter: GetterFn<T> = () => {
    const activeObserver = getActiveObserver()
    
    // If this computed value is being accessed from another observer
    if (activeObserver) {
      // Track the dependency of the active observer on this computed value
      trackDependency(computedSubject)
      
      // Recalculate to get the latest value and re-establish its dependencies
      updateObserver(o)
      computedSubject.value = o.value!
    }
    
    return computedSubject.value!
  }
  
  return getter
}