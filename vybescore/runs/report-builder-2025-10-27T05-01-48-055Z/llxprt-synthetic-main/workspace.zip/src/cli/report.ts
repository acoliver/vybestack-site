#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import type { ReportData } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliOptions {
  format: 'markdown' | 'text';
  outputPath?: string;
  includeTotals: boolean;
}

interface ParsedArgs extends CliOptions {
  dataFilePath: string;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args = argv.slice(2); // Remove node path and script path

  if (args.length === 0) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const dataFilePath = args[0];
  let format: 'markdown' | 'text' = 'markdown';
  let outputPath: string | undefined;
  let includeTotals = false;

  for (let i = 1; i < args.length; i++) {
    const arg = args[i];
    const nextArg = args[i + 1];

    if (arg === '--format') {
      if (!nextArg || !['markdown', 'text'].includes(nextArg)) {
        console.error('Error: Unsupported format');
        process.exit(1);
      }
      format = nextArg as 'markdown' | 'text';
      i++; // Skip next argument
    } else if (arg === '--output') {
      if (!nextArg) {
        console.error('Error: --output requires a path');
        process.exit(1);
      }
      outputPath = nextArg;
      i++; // Skip next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    }
  }

  return {
    dataFilePath,
    format,
    outputPath,
    includeTotals,
  };
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: expected an object');
  }

  const obj = data as Record<string, unknown>;

  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid title');
  }

  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid summary');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid JSON: missing or invalid entries array');
  }

  const entries = obj.entries.map((entry) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error('Invalid JSON: invalid entry object');
    }

    const entryObj = entry as Record<string, unknown>;

    if (
      !entryObj.label ||
      typeof entryObj.label !== 'string'
    ) {
      throw new Error('Invalid JSON: missing or invalid entry label');
    }

    if (
      typeof entryObj.amount !== 'number' ||
      isNaN(entryObj.amount)
    ) {
      throw new Error('Invalid JSON: missing or invalid entry amount');
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount,
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries,
  };
}

async function main() {
  try {
    const args = parseArgs(process.argv);

    // Read and parse JSON data
    let rawData: string;
    try {
      rawData = readFileSync(args.dataFilePath, 'utf8');
    } catch (error) {
      console.error(`Error: Could not read file ${args.dataFilePath}`);
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(rawData);
    } catch (error) {
      console.error(`Error: Invalid JSON in ${args.dataFilePath}`);
      process.exit(1);
    }

    // Validate and transform data
    const reportData = validateReportData(jsonData);

    // Render report
    let output: string;
    if (args.format === 'markdown') {
      output = renderMarkdown(reportData, { includeTotals: args.includeTotals });
    } else if (args.format === 'text') {
      output = renderText(reportData, { includeTotals: args.includeTotals });
    } else {
      console.error('Error: Unsupported format');
      process.exit(1);
    }

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output);
      } catch (error) {
        console.error(`Error: Could not write to ${args.outputPath}`);
        process.exit(1);
      }
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
