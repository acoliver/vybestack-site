import type { ReportData, ReportOptions, FormatRenderer } from '../types.js';

export const renderText: FormatRenderer = (
  data: ReportData,
  options: ReportOptions,
): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let output = `${title}\n${summary}\nEntries:\n`;

  for (const entry of entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    output += `- ${entry.label}: ${formattedAmount}\n`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    output += `Total: ${formattedTotal}`;
  }

  return output;
};