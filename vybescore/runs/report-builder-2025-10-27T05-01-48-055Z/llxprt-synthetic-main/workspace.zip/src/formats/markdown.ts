import type { ReportData, ReportOptions, FormatRenderer } from '../types.js';

export const renderMarkdown: FormatRenderer = (
  data: ReportData,
  options: ReportOptions,
): string => {
  const { title, summary, entries } = data;
  const { includeTotals } = options;

  let output = `# ${title}\n\n${summary}\n\n## Entries\n`;

  for (const entry of entries) {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    output += `- **${entry.label}** — ${formattedAmount}\n`;
  }

  if (includeTotals) {
    const total = entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    output += `\n**Total:** ${formattedTotal}`;
  }

  return output;
};