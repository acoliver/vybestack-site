export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  // Email regex that:
  // - Allows letters, digits, dots, hyphens, underscores, plus in local part
  // - Rejects consecutive dots (..)
  // - Rejects dots at start or end of local part
  // - Rejects underscores in domain
  // - Requires at least one dot in domain with valid TLD
  // - Allows subdomains and country code TLDs
  const emailRegex = /^[a-zA-Z0-9](?:[a-zA-Z0-9+._%+-]*[a-zA-Z0-9])?@[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]*[a-zA-Z0-9])?)+$/;
  
  // Additional checks for patterns that shouldn't occur
  if (value.includes('..')) return false;
  if (value.includes('@.') || value.includes('.@')) return false;
  if (value.startsWith('.') || value.endsWith('.')) return false;
  if (value.includes('_')) {
    // Underscores are only allowed in local part, not domain
    const parts = value.split('@');
    if (parts.length === 2 && parts[1].includes('_')) return false;
  }
  
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number, or 11 with +1)
  if (digits.length < 10) return false;
  if (digits.length > 11) return false;
  
  // Handle +1 country code
  let areaCodeStart = 0;
  if (digits.length === 11) {
    if (digits[0] !== '1') return false;
    areaCodeStart = 1;
  }
  
  // Area code cannot start with 0 or 1
  const areaCode = digits.slice(areaCodeStart, areaCodeStart + 3);
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Check total digit count is exactly 10 or 11 with country code
  if (digits.length === 10 || (digits.length === 11 && digits[0] === '1')) {
    return true;
  }
  
  return false;
}

/**
 * Validates Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and hyphens for validation
  const normalized = value.replace(/[ -]/g, '');
  
  // Regex breakdown:
  // ^\+?54? - Optional +54 country code
  // 9? - Optional mobile indicator 9
  // 0? - Optional trunk prefix 0
  // [1-9]\d{1,3} - Area code (2-4 digits, leading 1-9)
  // \d{6,8}$ - Subscriber number (6-8 digits)
  const regex = /^\+?549?[1-9]\d{1,3}\d{6,8}$/;
  
  if (!regex.test(normalized)) {
    // Try without country code but with trunk prefix
    const withoutCountry = normalized.replace(/^\+?54/, '');
    if (withoutCountry.startsWith('0')) {
      const trunkRegex = /^0[1-9]\d{1,3}\d{6,8}$/;
      if (trunkRegex.test(withoutCountry)) return true;
    }
    return false;
  }
  
  // Additional validation: if country code is omitted, must have trunk prefix
  if (!normalized.startsWith('+54') && !normalized.startsWith('54')) {
    if (!normalized.startsWith('0')) {
      return false;
    }
  }
  
  // Extract area code and subscriber for length validation
  let areaStart = 0;
  if (normalized.startsWith('+54')) areaStart = 3;
  else if (normalized.startsWith('54')) areaStart = 2;
  
  let remaining = normalized.slice(areaStart);
  if (remaining.startsWith('9')) remaining = remaining.slice(1);
  if (remaining.startsWith('0')) remaining = remaining.slice(1);
  
  // Find area code (2-4 digits starting with 1-9)
  const areaMatch = remaining.match(/^([1-9]\d{1,3})(\d+)$/);
  if (!areaMatch) return false;
  
  const [, areaCode, subscriber] = areaMatch;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // Subscriber must be 6-8 digits
  if (subscriber.length < 6 || subscriber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names.
 * Permits unicode letters, accents, apostrophes, hyphens, spaces.
 * Rejects digits, symbols, and X Æ A-12 style names.
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least one letter
  // Cannot contain digits or most symbols
  const nameRegex = /^[\p{L}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one unicode letter
  const hasLetter = /[\p{L}]/u.test(value);
  if (!hasLetter) return false;
  
  // Cannot contain digits
  if (/\d/.test(value)) return false;
  
  // Reject certain symbol characters that might pass the main regex
  const invalidChars = /[!"#$%&()*+,./:;<=>?@[\\\]^_`{|}0-9]/;
  if (invalidChars.test(value)) return false;
  
  return true;
}

/**
 * Helper function to perform Luhn checksum validation.
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.split('').map(Number);
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = digits[i];
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers.
 * Accepts Visa/Mastercard/AmEx prefixes and lengths.
 * Runs a Luhn checksum.
 */
export function isValidCreditCard(value: string): boolean {
  // Remove spaces and hyphens
  const cleaned = value.replace(/[\s-]/g, '');
  
  // Must be all digits
  if (!/^\d+$/.test(cleaned)) return false;
  
  // Check Visa: starts with 4, length 13 or 16
  const visaRegex = /^4\d{12}(\d{3})?$/;
  
  // Check Mastercard: starts with 51-55 or 2221-2720, length 16
  const mastercardRegex = /^(?:5[1-5]\d{2}|2[2-7][0-2]\d)\d{12}$/;
  
  // Check AmEx: starts with 34 or 37, length 15
  const amexRegex = /^3[47]\d{13}$/;
  
  const validFormat = visaRegex.test(cleaned) || 
                      mastercardRegex.test(cleaned) || 
                      amexRegex.test(cleaned);
  
  if (!validFormat) return false;
  
  // Run Luhn check
  return runLuhnCheck(cleaned);
}
