/**
 * Finds words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Escape special regex characters in the prefix
  const escapedPrefix = prefix.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Match words starting with the prefix
  const wordPattern = new RegExp(`\\b${escapedPrefix}[a-zA-Z]+\\b`, 'g');
  
  const matches = text.match(wordPattern) || [];
  
  // Filter out exceptions (case-insensitive)
  const exceptionsLower = exceptions.map(e => e.toLowerCase());
  
  return matches.filter(word => {
    return !exceptionsLower.includes(word.toLowerCase());
  });
}

/**
 * Finds occurrences of a token only when it appears after a digit and not at the start of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');

  // Match token only when preceded by a digit (positive lookbehind)
  // And not at the start of the string
  const pattern = new RegExp(`(\\d${escapedToken})(?![a-zA-Z0-9])`, 'g');

  // Also check that there's at least one character before the match
  // to ensure it's not at the start
  const results: string[] = [];
  let lastIndex = 0;

  while (lastIndex < text.length) {
    const match = pattern.exec(text);
    if (!match) break;

    // Ensure match is not at the start
    if (match.index > 0) {
      results.push(match[1]); // Push the captured group (digit + token)
    }

    lastIndex = match.index + match[0].length;
  }

  return results;
}

/**
 * Validates passwords according to the policy:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Must be at least 10 characters
  if (value.length < 10) {
    return false;
  }
  
  // No whitespace allowed
  if (/\s/.test(value)) {
    return false;
  }
  
  // Must contain at least one uppercase letter
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one lowercase letter
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  // Must contain at least one digit
  if (!/\d/.test(value)) {
    return false;
  }
  
  // Must contain at least one symbol (non-alphanumeric)
  if (!/[^a-zA-Z0-9]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc)
  // A sequence of 2+ characters that repeats immediately
  const repeatedSequenceRegex = /(.{2,})\1/;
  if (repeatedSequenceRegex.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) and excludes IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // Comprehensive IPv6 pattern that handles:
  // - Full notation: 2001:0db8:85a3:0000:0000:8a2e:0370:7334
  // - Compressed zeros (::): 2001:db8::1, ::1, ::
  // - Mixed: fe80::1ff:fe23:4567:890a
  // - Must contain at least one colon and valid hex characters

  // Pattern matches valid IPv6 formats
  // Uses word boundaries and negative lookbehind to avoid matching IPv4
  const ipv6Pattern = /(?<![.\d])(?:[0-9a-fA-F]{1,4}:){1,7}[0-9a-fA-F]{1,4}|(?:[0-9a-fA-F]{1,4}:)*::(?:[0-9a-fA-F]{1,4}:*)*/g;

  const matches = value.match(ipv6Pattern);
  if (!matches) {
    return false;
  }

  // Validate each match
  for (const match of matches) {
    // Must contain colon
    if (!match.includes(':')) {
      continue;
    }

    // Must not be purely numeric (IPv4)
    if (!/[a-fA-F:]/.test(match)) {
      continue;
    }

    // Count colons - valid IPv6 has at least 2 double colons or multiple single colons
    const colonCount = (match.match(/:/g) || []).length;
    
    // :: counts as 2 colons but represents multiple zero groups
    // So we need at least one colon sequence (either :: or multiple single colons)
    if (colonCount < 1) {
      continue;
    }

    // Must be valid IPv6 format (hex and colons only, properly structured)
    // Check for basic validity: hex digits separated by colons
    if (/^[\da-fA-F:]+$/.test(match)) {
      // Not an IPv4 address (x.x.x.x format)
      if (!/^\d+\.\d+\.\d+\.\d+$/.test(match)) {
        // Ensure it has at least one valid hextet
        if (match.split(':').some(part => part.length <= 4 && /^[\da-fA-F]*$/.test(part))) {
          return true;
        }
      }
    }
  }
  
  return false;
}
