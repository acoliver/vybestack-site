/**
 * Capitalizes the first character of each sentence.
 * Insert exactly one space between sentences even if input omitted it.
 * Collapse extra spaces sensibly while leaving abbreviations intact when possible.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace around sentence terminators
  // Remove extra spaces and ensure one space after punctuation
  const normalized = text
    // Replace multiple spaces with single space
    .replace(/[ \t]+/g, ' ')
    // Ensure space after sentence terminators if not already present
    .replace(/([.!?])(?=[A-Za-z])/g, '$1 ')
    // Remove spaces before sentence terminators
    .replace(/\s+([.!?])/g, '$1')
    // Ensure exactly one space after terminators
    .replace(/([.!?])\s+/g, '$1 ');

  // Now capitalize first letter of each sentence
  // A sentence starts after: beginning of string, or [.!?] followed by space
  const result = normalized.replace(/(^|[.!?]\s+)([a-z])/g, (_, prefix, letter) => {
    return prefix + letter.toUpperCase();
  });

  // Handle edge case: very first character
  if (result.length > 0 && /^[a-z]/.test(result)) {
    return result[0].toUpperCase() + result.slice(1);
  }

  return result;
}

/**
 * Finds URLs in the text.
 * Returns an array of matched URL strings without trailing punctuation.
 */
export function extractUrls(text: string): string[] {
  // URL pattern matching:
  // - http:// or https:// protocol
  // - Domain (letters, digits, hyphens, dots)
  // - Optional port
  // - Optional path
  // - Optional query string
  // - Optional fragment
  // Exclude trailing punctuation like .,;!?
  const urlRegex = /https?:\/\/[^\s<>[\](){},.!?;:"][^\s<>[\](){},!?;:]*(?:\/[^\s<>[\](){},.!?;:"`]*)?/g;

  const matches = text.match(urlRegex) || [];

  // Clean up trailing punctuation
  return matches.map(url => {
    // Remove trailing characters that are not part of URL
    return url.replace(/[,.;:!?]+$/, '');
  });
}

/**
 * Forces all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https:// only
  // Use word boundary or similar to avoid replacing parts of words
  return text.replace(/http:\/\//g, 'https://');
}

/**
 * Rewrites http://example.com/... to https://docs.example.com/... where applicable.
 * - Always upgrade the scheme to https://.
 * - When path begins with /docs/, rewrite host to docs.example.com.
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions).
 * - Preserve nested paths like /docs/api/v1.
 */
export function rewriteDocsUrls(text: string): string {
  // Pattern to match http://example.com URLs
  // Capture groups: protocol, domain, optional path
  const urlPattern = /(https?):\/\/(example\.com)(\/[^\s<>[\]{}"]*)?/gi;

  return text.replace(urlPattern, (match, protocol, domain, path = '') => {
    // Always upgrade to https
    const newProtocol = 'https';

    // Check if path exists and starts with /docs/
    if (path && path.startsWith('/docs/')) {
      // Check for dynamic hints that should skip host rewrite
      const lowerPath = path.toLowerCase();
      const hasDynamicHint =
        lowerPath.includes('cgi-bin') ||
        lowerPath.includes('?') ||
        lowerPath.includes('&') ||
        lowerPath.includes('=') ||
        /\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?|$)/.test(lowerPath);

      if (!hasDynamicHint) {
        // Rewrite host to docs.example.com
        return `${newProtocol}://docs.example.com${path}`;
      }
    }

    // Just upgrade the protocol
    return `${newProtocol}://${domain}${path}`;
  });
}

/**
 * Extracts the year from mm/dd/yyyy strings.
 * Returns 'N/A' when the format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format exactly
  // Month: 01-12, Day: 01-31, Year: 0000-9999
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);

  if (!match) {
    return 'N/A';
  }

  const [, monthStr, dayStr, year] = match;
  const month = parseInt(monthStr, 10);
  const day = parseInt(dayStr, 10);

  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }

  // Validate day based on month
  const daysInMonth = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];

  if (day < 1 || day > daysInMonth[month - 1]) {
    return 'N/A';
  }

  return year;
}
