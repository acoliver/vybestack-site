import { Submission } from './database';

export interface ValidationError {
  field: string;
  message: string;
}

export interface ValidationResult {
  isValid: boolean;
  errors: ValidationError[];
}

export function validateSubmission(data: Partial<Submission>): ValidationResult {
  const errors: ValidationError[] = [];

  // Required field validation
  const requiredFields = [
    { field: 'firstName', value: data.firstName, label: 'First name' },
    { field: 'lastName', value: data.lastName, label: 'Last name' },
    { field: 'streetAddress', value: data.streetAddress, label: 'Street address' },
    { field: 'city', value: data.city, label: 'City' },
    { field: 'stateProvinceRegion', value: data.stateProvinceRegion, label: 'State / Province / Region' },
    { field: 'postalCode', value: data.postalCode, label: 'Postal / Zip code' },
    { field: 'country', value: data.country, label: 'Country' },
    { field: 'email', value: data.email, label: 'Email' },
    { field: 'phoneNumber', value: data.phoneNumber, label: 'Phone number' }
  ];

  for (const { field, value, label } of requiredFields) {
    if (!value || value.trim() === '') {
      errors.push({
        field,
        message: `${label} is required`
      });
    }
  }

  // Email validation
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.push({
        field: 'email',
        message: 'Please enter a valid email address'
      });
    }
  }

  // Phone number validation
  if (data.phoneNumber && data.phoneNumber.trim() !== '') {
    const phoneRegex = /^[+]?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phoneNumber)) {
      errors.push({
        field: 'phoneNumber',
        message: 'Please enter a valid phone number'
      });
    }
  }

  // Postal code validation (alphanumeric, can include spaces and hyphens)
  if (data.postalCode && data.postalCode.trim() !== '') {
    const postalRegex = /^[\w\-\s]+$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.push({
        field: 'postalCode',
        message: 'Please enter a valid postal code'
      });
    }
  }

  return {
    isValid: errors.length === 0,
    errors
  };
}
