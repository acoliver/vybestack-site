import initSqlJs, { Database, SqlJsStatic } from 'sql.js';
import * as fs from 'fs';
import * as path from 'path';

export interface Submission {
  id?: number;
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phoneNumber: string;
  createdAt?: string;
}

class DatabaseService {
  private db: Database | null = null;
  private sql: SqlJsStatic | null = null;
  private dbPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), 'data', 'submissions.sqlite');
  }

  async initialize(): Promise<void> {
    this.sql = await initSqlJs({
      locateFile: (file: string) => {
        // sql.js will look for its wasm file in node_modules
        return require.resolve(`sql.js/dist/${file}`);
      }
    });

    const schemaPath = path.join(process.cwd(), 'db', 'schema.sql');
    const schema = fs.readFileSync(schemaPath, 'utf8');

    if (fs.existsSync(this.dbPath)) {
      const dbBuffer = fs.readFileSync(this.dbPath);
      this.db = new this.sql.Database(dbBuffer);
    } else {
      this.db = new this.sql.Database();
      this.db.exec(schema);
      this.saveToDisk();
    }
  }

  async saveSubmission(submission: Omit<Submission, 'id' | 'createdAt'>): Promise<number> {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, state_province_region,
        postal_code, country, email, phone_number
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      submission.firstName,
      submission.lastName,
      submission.streetAddress,
      submission.city,
      submission.stateProvinceRegion,
      submission.postalCode,
      submission.country,
      submission.email,
      submission.phoneNumber
    ]);

    const id = this.db.exec('SELECT last_insert_rowid() as id')[0].values[0][0] as number;
    this.saveToDisk();
    return id;
  }

  getAllSubmissions(): Submission[] {
    if (!this.db) {
      throw new Error('Database not initialized');
    }

    const result = this.db.exec('SELECT * FROM submissions ORDER BY created_at DESC');
    if (result.length === 0) {
      return [];
    }

    const submissions: Submission[] = [];
    const values = result[0].values;

    for (const row of values) {
      const submission: Submission = {
        id: row[0] as number,
        firstName: row[1] as string,
        lastName: row[2] as string,
        streetAddress: row[3] as string,
        city: row[4] as string,
        stateProvinceRegion: row[5] as string,
        postalCode: row[6] as string,
        country: row[7] as string,
        email: row[8] as string,
        phoneNumber: row[9] as string,
        createdAt: row[10] as string
      };
      submissions.push(submission);
    }

    return submissions;
  }

  private saveToDisk(): void {
    if (!this.db) {
      return;
    }

    const data = this.db.export();
    fs.writeFileSync(this.dbPath, Buffer.from(data));
  }

  close(): void {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export const databaseService = new DatabaseService();
