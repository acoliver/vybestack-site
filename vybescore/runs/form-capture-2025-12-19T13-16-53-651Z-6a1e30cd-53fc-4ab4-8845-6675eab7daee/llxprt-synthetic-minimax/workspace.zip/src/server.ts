import express from 'express';
import * as path from 'path';
import { databaseService } from './database';
import { validateSubmission } from './validation';
import { Submission } from './database';

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), 'public')));

// Set view engine
app.set('view engine', 'ejs');
app.set('views', path.join(process.cwd(), 'views'));

// Routes

// GET / - Show the form
app.get('/', (req, res) => {
  res.render('form', {
    title: 'Friendly Contact Form',
    errors: [],
    formData: {},
    hasErrors: false
  });
});

// POST /submit - Handle form submission
app.post('/submit', async (req, res) => {
  try {
    const formData: Partial<Submission> = {
      firstName: req.body.firstName,
      lastName: req.body.lastName,
      streetAddress: req.body.streetAddress,
      city: req.body.city,
      stateProvinceRegion: req.body.stateProvinceRegion,
      postalCode: req.body.postalCode,
      country: req.body.country,
      email: req.body.email,
      phoneNumber: req.body.phoneNumber
    };

    const validation = validateSubmission(formData);

    if (!validation.isValid) {
      // Re-render form with errors and previously entered values
      res.status(400).render('form', {
        title: 'Friendly Contact Form',
        errors: validation.errors,
        formData: req.body,
        hasErrors: true
      });
      return;
    }

    // Save to database
    const submissionData = formData as Omit<Submission, 'id' | 'createdAt'>;
    await databaseService.saveSubmission(submissionData);

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Error processing form submission:', error);
    res.status(500).render('form', {
      title: 'Friendly Contact Form',
      errors: [{ field: 'general', message: 'An unexpected error occurred. Please try again.' }],
      formData: req.body,
      hasErrors: true
    });
  }
});

// GET /thank-you - Show thank you page
app.get('/thank-you', (req, res) => {
  res.render('thank-you', {
    title: 'Thank You - We\'ll Be In Touch!'
  });
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('SIGTERM received, shutting down gracefully...');
  databaseService.close();
  process.exit(0);
});

// Initialize database and start server
async function startServer() {
  try {
    await databaseService.initialize();
    app.listen(PORT, () => {
      console.log(`Server running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
}

startServer();

export default app;