/**
 * Capitalize the first character of each sentence.
 * Handles sentence boundaries (.?!) while preserving abbreviations,
 * ensures exactly one space between sentences, collapses extra spaces.
 */
export function capitalizeSentences(text: string): string {
  // First, normalize whitespace - collapse multiple spaces to single space
  let result = text.replace(/\s+/g, ' ').trim();
  
  // Ensure proper spacing after sentence endings
  result = result.replace(/([.!?])(?!\s|$)/g, '$1 ');
  
  // Split into sentences and capitalize each one
  const sentences = result.split(/([.!?]\s*)/);
  
  for (let i = 0; i < sentences.length; i += 2) {
    const sentence = sentences[i];
    if (sentence && sentence.trim()) {
      // Capitalize first letter, keep rest as is
      sentences[i] = sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
  }
  
  // Rejoin sentences
  result = sentences.join('');
  
  // Clean up any double spaces that might have been created
  result = result.replace(/\s+/g, ' ').trim();
  
  return result;
}

/**
 * Extract URLs from text without trailing punctuation.
 * Returns array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // Comprehensive URL regex that matches most common URL patterns
  // Negative lookahead to avoid trailing punctuation
  const urlRegex = /\bhttps?:\/\/(?:www\.)?[-a-zA-Z0-9@:%._\+~#=]{1,256}\.[a-zA-Z0-9()]{1,6}\b(?:[-a-zA-Z0-9()@:%_\+.~#?&\/=]*)/g;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from each match
  return matches.map(url => url.replace(/[.,;:!?\])}]+$/g, ''));
}

/**
 * Force all http:// URLs to https:// while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://, but not if it's already https://
  return text.replace(/\bhttp:\/\//g, 'https://');
}

/**
 * Rewrite http://example.com/... URLs:
 * - Always upgrade scheme to https://
 * - When path starts with /docs/, rewrite host to docs.example.com
 * - Skip host rewrite for dynamic hints (cgi-bin, query strings, legacy extensions)
 */
export function rewriteDocsUrls(text: string): string {
  // Match http://example.com/ URLs and handle the rewriting logic
  return text.replace(/\bhttp:\/\/([^\/]+)(\/[^\s]*)/g, (match, host, path) => {
    // Always upgrade to https
    let newUrl = 'https://';
    
    // Check if we should rewrite the host for /docs/ paths
    const shouldRewriteHost = path.startsWith('/docs/') && 
      !path.match(/\/(cgi-bin|.*\.(jsp|php|asp|aspx|do|cgi|pl|py)(\?.*)?$)/) &&
      !path.includes('?');
    
    if (shouldRewriteHost) {
      newUrl += `docs.${host}${path}`;
    } else {
      newUrl += `${host}${path}`;
    }
    
    return newUrl;
  });
}

/**
 * Extract the year from mm/dd/yyyy strings.
 * Returns 'N/A' when format is invalid or month/day are invalid.
 */
export function extractYear(value: string): string {
  // Exact match for mm/dd/yyyy format
  const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) return 'N/A';
  
  const [, month, day, year] = match;
  const monthNum = parseInt(month, 10);
  const dayNum = parseInt(day, 10);
  
  // Additional validation for day based on month
  const daysInMonth = [0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  
  // Basic leap year check
  const isLeapYear = (parseInt(year, 10) % 4 === 0 && parseInt(year, 10) % 100 !== 0) || (parseInt(year, 10) % 400 === 0);
  const maxDays = monthNum === 2 && isLeapYear ? 29 : daysInMonth[monthNum];
  
  if (dayNum > maxDays) return 'N/A';
  
  return year;
}
