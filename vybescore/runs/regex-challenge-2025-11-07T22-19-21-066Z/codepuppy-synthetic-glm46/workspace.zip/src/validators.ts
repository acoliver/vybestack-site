export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validate email addresses with comprehensive rules.
 * Accepts typical addresses like name+tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  // Basic structure: local@domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
  
  if (!emailRegex.test(value)) return false;
  
  const [localPart, domain] = value.split('@');
  
  // Local part validation
  // No consecutive dots, no leading/trailing dot
  if (localPart.includes('..') || localPart.startsWith('.') || localPart.endsWith('.')) {
    return false;
  }
  
  // Domain validation
  // No underscores in domain
  if (domain.includes('_')) return false;
  
  // No consecutive dots in domain
  if (domain.includes('..')) return false;
  
  // Domain must have at least one dot and valid TLD
  const domainParts = domain.split('.');
  if (domainParts.length < 2) return false;
  
  // Each domain part must be at least 2 characters except maybe TLD
  for (let i = 0; i < domainParts.length - 1; i++) {
    if (domainParts[i].length < 2) return false;
  }
  
  // TLD should be at least 2 characters
  const tld = domainParts[domainParts.length - 1];
  if (tld.length < 2) return false;
  
  return true;
}

/**
 * Validate US phone numbers.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, _options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters first
  const digits = value.replace(/\D/g, '');
  
  // Check minimum length (10 digits for US number)
  if (digits.length < 10) return false;
  
  // Remove optional +1 country code
  let phoneDigits = digits;
  if (digits.length === 11 && digits.startsWith('1')) {
    phoneDigits = digits.slice(1);
  } else if (digits.length > 11) {
    return false; // Too long even with country code
  }
  
  // Must be exactly 10 digits after removing country code
  if (phoneDigits.length !== 10) return false;
  
  // Extract area code (first 3 digits)
  const areaCode = phoneDigits.slice(0, 3);
  
  // Area code cannot start with 0 or 1
  if (areaCode[0] === '0' || areaCode[0] === '1') return false;
  
  // Validate format using regex for acceptable patterns
  const phonePattern = /^(?:\+?\d{1,3}[-.\s]?)?\(?\d{3}\)?[-.\s]?\d{3}[-.\s]?\d{4}$/;
  return phonePattern.test(value);
}

/**
 * Validate Argentine phone numbers.
 * Handles landlines and mobiles like +54 9 11 1234 5678, 011 1234 5678
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove all spaces and hyphens for validation
  const cleanValue = value.replace(/[\s-]/g, '');
  
  // Argentine phone regex:
  // ^\+54? optional country code
  // 0? optional trunk prefix (when no country code)
  // 9? optional mobile indicator
  // Area code: 2-4 digits starting with 1-9
  // Subscriber number: 6-8 digits
  const argentinePhoneRegex = /^(?:\+54)?(?:0)?(9)?([1-9]\d{1,3})(\d{6,8})$/;
  
  const match = cleanValue.match(argentinePhoneRegex);
  if (!match) return false;
  
  const [, , areaCode] = match;
  
  // Area code must be 2-4 digits
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  
  // When country code is omitted, must have trunk prefix 0
  if (!cleanValue.startsWith('+54') && !cleanValue.startsWith('0')) return false;
  
  // Total length validation
  const totalDigits = cleanValue.replace(/\D/g, '').length;
  if (totalDigits < 8 || totalDigits > 13) return false; // Allow reasonable range
  
  return true;
}

/**
 * Validate personal names.
 * Allows unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and X Æ A-12 style names
 */
export function isValidName(value: string): boolean {
  // Allow unicode letters, accents, apostrophes, hyphens, and spaces
  // Must have at least one letter
  // No digits or most symbols (except allowed apostrophes and hyphens)
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  if (!nameRegex.test(value)) return false;
  
  // Must contain at least one letter
  const hasLetter = /[\p{L}\p{M}]/u.test(value);
  if (!hasLetter) return false;
  
  // Check for obvious invalid patterns like consecutive symbols
  if (/[']{2,}|-{2,}/.test(value)) return false;
  
  // Check for digit characters explicitly
  if (/\d/.test(value)) return false;
  
  // Reject names that are just symbols or spaces
  const trimmedName = value.trim();
  if (trimmedName.length === 0) return false;
  
  // Reject names that only consist of allowed symbols without letters
  const lettersOnly = trimmedName.replace(/['\-\s]/g, '');
  if (lettersOnly.length === 0) return false;
  
  return true;
}

/**
 * Luhn checksum algorithm helper
 */
function runLuhnCheck(value: string): boolean {
  const digits = value.replace(/\D/g, '');
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let digit = parseInt(digits[i], 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validate credit card numbers.
 * Accepts Visa/Mastercard/AmEx with proper prefixes and lengths, plus Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const digits = value.replace(/\D/g, '');
  
  // Basic length check (13-19 digits for major cards)
  if (digits.length < 13 || digits.length > 19) return false;
  
  // Card-specific validation
  let isValid = false;
  
  // Visa: starts with 4, length 13 or 16
  if (/^4/.test(digits)) {
    isValid = digits.length === 13 || digits.length === 16 || digits.length === 19;
  }
  // Mastercard: starts with 51-55, 2221-2720, length 16
  else if (/^5[1-5]/.test(digits) || /^2[2-7]/.test(digits)) {
    isValid = digits.length === 16;
  }
  // American Express: starts with 34 or 37, length 15
  else if (/^3[47]/.test(digits)) {
    isValid = digits.length === 15;
  }
  // Discover: starts with 6011, 65, 644-649, length 16
  else if (/^6011|^65|^6[4-9]/.test(digits)) {
    isValid = digits.length === 16;
  }
  // Diners Club: starts with 300-305, 36, 38, length 14
  else if (/^3[0-6]/.test(digits)) {
    isValid = digits.length === 14;
  }
  // JCB: starts with 2131, 1800, 35, length 15-16
  else if (/^2131|^1800|^35/.test(digits)) {
    isValid = digits.length === 15 || digits.length === 16;
  }
  
  if (!isValid) return false;
  
  // Run Luhn checksum
  return runLuhnCheck(digits);
}
