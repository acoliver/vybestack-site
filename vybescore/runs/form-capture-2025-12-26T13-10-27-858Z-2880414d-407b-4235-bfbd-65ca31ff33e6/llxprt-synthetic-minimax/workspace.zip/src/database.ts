import initSqlJs, { Database as SqlJsDatabase } from "sql.js";
import fs from "fs";
import path from "path";

export interface Submission {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

class DatabaseService {
  private db: SqlJsDatabase | null = null;
  private dbPath: string;
  private schemaPath: string;

  constructor() {
    this.dbPath = path.join(process.cwd(), "data", "submissions.sqlite");
    this.schemaPath = path.join(process.cwd(), "db", "schema.sql");
  }

  async initialize(): Promise<void> {
    try {
      const SQL = await initSqlJs();
      
      // Ensure data directory exists
      const dataDir = path.dirname(this.dbPath);
      if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
      }

      // Load existing database or create new one
      if (fs.existsSync(this.dbPath)) {
        const dbBuffer = fs.readFileSync(this.dbPath);
        this.db = new SQL.Database(dbBuffer);
      } else {
        this.db = new SQL.Database();
        await this.createSchema();
      }

      // Ensure the submissions table exists
      await this.createSchema();
    } catch (error) {
      console.error("Failed to initialize database:", error);
      throw error;
    }
  }

  private async createSchema(): Promise<void> {
    if (!this.db) {
      throw new Error("Database not initialized");
    }

    try {
      const schema = fs.readFileSync(this.schemaPath, "utf8");
      this.db.exec(schema);
      await this.save();
    } catch (error) {
      console.error("Failed to create schema:", error);
      throw error;
    }
  }

  async save(): Promise<void> {
    if (!this.db) {
      throw new Error("Database not initialized");
    }

    try {
      const data = this.db.export();
      fs.writeFileSync(this.dbPath, Buffer.from(data));
    } catch (error) {
      console.error("Failed to save database:", error);
      throw error;
    }
  }

  async insertSubmission(submission: Submission): Promise<number> {
    if (!this.db) {
      throw new Error("Database not initialized");
    }

    const stmt = this.db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province_region, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    try {
      stmt.run([
        submission.firstName,
        submission.lastName,
        submission.streetAddress,
        submission.city,
        submission.stateProvinceRegion,
        submission.postalCode,
        submission.country,
        submission.email,
        submission.phone
      ]);

      const result = this.db.exec("SELECT last_insert_rowid() as id");
      const id = result[0].values[0][0] as number;
      
      await this.save();
      return id;
    } finally {
      stmt.free();
    }
  }

  async close(): Promise<void> {
    if (this.db) {
      this.db.close();
      this.db = null;
    }
  }
}

export default new DatabaseService();
