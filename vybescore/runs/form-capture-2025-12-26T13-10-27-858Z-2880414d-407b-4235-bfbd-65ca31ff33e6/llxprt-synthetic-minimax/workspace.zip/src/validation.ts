import { Request } from "express";

export interface ValidationResult {
  isValid: boolean;
  errors: Record<string, string>;
  data?: FormData;
}

export interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvinceRegion: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

export function validateFormData(req: Request): ValidationResult {
  const errors: Record<string, string> = {};
  const data: FormData = {
    firstName: (req.body.firstName || "").trim(),
    lastName: (req.body.lastName || "").trim(),
    streetAddress: (req.body.streetAddress || "").trim(),
    city: (req.body.city || "").trim(),
    stateProvinceRegion: (req.body.stateProvinceRegion || "").trim(),
    postalCode: (req.body.postalCode || "").trim(),
    country: (req.body.country || "").trim(),
    email: (req.body.email || "").trim(),
    phone: (req.body.phone || "").trim()
  };

  const requiredFields: Array<keyof FormData> = [
    "firstName", "lastName", "streetAddress", "city", 
    "stateProvinceRegion", "postalCode", "country", "email", "phone"
  ];

  requiredFields.forEach(field => {
    if (!data[field]) {
      errors[field] = `${field.replace(/([A-Z])/g, " $1").toLowerCase()} is required`;
    }
  });

  if (data.email && !isValidEmail(data.email)) {
    errors.email = "Please enter a valid email address";
  }

  if (data.phone && !isValidPhone(data.phone)) {
    errors.phone = "Please enter a valid phone number";
  }

  if (data.postalCode && !isValidPostalCode(data.postalCode)) {
    errors.postalCode = "Please enter a valid postal code";
  }

  return {
    isValid: Object.keys(errors).length === 0,
    errors,
    data: Object.keys(errors).length === 0 ? data : undefined
  };
}

function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function isValidPhone(phone: string): boolean {
  const phoneRegex = /^\+?[\d\s()-]+$/;
  return phoneRegex.test(phone) && phone.replace(/\D/g, "").length >= 7;
}

function isValidPostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode) && postalCode.trim().length >= 3;
}
