import express, { Request, Response } from "express";
import path from "path";
import database from "./database";
import { validateFormData, FormData } from "./validation";

const app = express();
const PORT = process.env.PORT || 3535;

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(express.static(path.join(process.cwd(), "public")));
app.set("views", path.join(process.cwd(), "views"));
app.set("view engine", "ejs");

// Routes
app.get("/", (req: Request, res: Response) => {
  res.render("index", {
    errors: {},
    data: {},
    title: "Contact Us"
  });
});

app.post("/submit", async (req: Request, res: Response) => {
  const validation = validateFormData(req);
  
  if (!validation.isValid) {
    return res.status(400).render("index", {
      errors: validation.errors,
      data: req.body,
      title: "Contact Us - Please Fix Errors"
    });
  }

  try {
    const submissionData = validation.data as FormData;
    await database.insertSubmission(submissionData);
    res.redirect(302, "/thank-you");
  } catch (error) {
    console.error("Failed to save submission:", error);
    return res.status(500).render("index", {
      errors: { submit: "Failed to save your submission. Please try again." },
      data: req.body,
      title: "Contact Us - Error"
    });
  }
});

app.get("/thank-you", (req: Request, res: Response) => {
  res.render("thank-you", {
    title: "Thank You!"
  });
});

// Graceful shutdown handling
let server: ReturnType<typeof app.listen> | undefined;

async function shutdown() {
  console.log("Shutting down gracefully...");
  if (server) {
    server.close(async () => {
      await database.close();
      process.exit(0);
    });
  } else {
    await database.close();
    process.exit(0);
  }
}

// Handle SIGTERM and SIGINT
process.on("SIGTERM", shutdown);
process.on("SIGINT", shutdown);

// Initialize database and start server
async function startServer() {
  try {
    await database.initialize();
    server = app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (error) {
    console.error("Failed to start server:", error);
    process.exit(1);
  }
}

startServer();
