// Simple test to debug the reactive system
import { createInput, createComputed } from './src/index.js'

console.log('Testing dependency tracking...')

const [input, setInput] = createInput(1)
console.log('Initial input:', input())

const timesTwo = createComputed(() => {
  console.log('Computing timesTwo, input is:', input())
  return input() * 2
})
console.log('Initial timesTwo:', timesTwo())

const timesThirty = createComputed(() => {
  console.log('Computing timesThirty, input is:', input())
  return input() * 30
})
console.log('Initial timesThirty:', timesThirty())

const sum = createComputed(() => {
  console.log('Computing sum, timesTwo:', timesTwo(), 'timesThirty:', timesThirty())
  return timesTwo() + timesThirty()
})
console.log('Initial sum:', sum())

console.log('Updating input to 3')
setInput(3)

console.log('After update:')
console.log('input:', input())
console.log('timesTwo:', timesTwo())
console.log('timesThirty:', timesThirty())
console.log('sum:', sum())