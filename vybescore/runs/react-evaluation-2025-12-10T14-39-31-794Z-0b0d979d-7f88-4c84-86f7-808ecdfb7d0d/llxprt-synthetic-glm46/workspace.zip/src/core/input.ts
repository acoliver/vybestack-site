/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  ObserverR,
  getActiveObserver,
  notifyObservers,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  let equalFn: EqualFn<T> | undefined
  if (equal === true) {
    equalFn = (a: T, b: T) => a === b
  } else if (equal === false) {
    equalFn = undefined
  } else if (typeof equal === 'function') {
    equalFn = equal
  }

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value,
    equalFn,
  }

  // Note: observers will be used for notification when implementing the full system
  const observers: Set<ObserverR> = new Set()

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // Store the observer so we can notify it when this input changes
      s.observer = observer
      observers.add(observer)
    }
    return s.value
  }

  const write: SetterFn<T> = (newValue: T) => {
    // Skip update if values are equal
    if (equalFn && equalFn(s.value, newValue)) {
      return s.value
    }
    
    // Update the value
    s.value = newValue
    
    // Notify all observers
    observers.forEach(observer => {
      notifyObservers(observer)
    })

    return s.value
  }

  return [read, write]
}