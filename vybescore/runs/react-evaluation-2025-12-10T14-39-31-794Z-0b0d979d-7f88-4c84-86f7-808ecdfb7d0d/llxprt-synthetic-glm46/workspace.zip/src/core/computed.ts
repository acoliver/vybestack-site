/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  ObserverR,
  updateObserver,
  getActiveObserver,
  setActiveObserver,
  notifyObservers,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Track dependent observers
  const observers: Set<ObserverR> = new Set()
  
  // Add update method to observer for notification
  o.update = () => {
    updateObserver(o)
    // Notify all dependent observers
    observers.forEach(observer => {
      notifyObservers(observer)
    })
  }
  
  // Initial computation
  updateObserver(o)
  
  // Return getter that recomputes when dependencies change
  const getter = (): T => {
    // If this is being accessed during an update, track the dependency
    const observer = getActiveObserver()
    if (observer) {
      // This computed value is being observed
      observers.add(observer)
      o.observer = observer
    }
    return o.value!
  }
  
  // Override getter to include observer tracking  
  getter.update = () => {
    const previous = setActiveObserver(o)
    try {
      updateObserver(o)
      observers.forEach(observer => {
        notifyObservers(observer)
      })
    } finally {
      setActiveObserver(previous)
    }
  }
  
  return getter
}