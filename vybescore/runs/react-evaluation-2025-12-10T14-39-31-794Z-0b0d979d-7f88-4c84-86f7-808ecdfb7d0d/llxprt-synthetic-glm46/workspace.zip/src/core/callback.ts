/**
 * Callback closure implementation for reactive side effects.
 */

import { UnsubscribeFn, Observer, UpdateFn, setActiveObserver, updateObserver, ObserverR } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  // Create a simple observer that just executes the callback
  const observer: Observer<T> = {
    name: undefined,
    value,
    updateFn: (prev?: T) => {
      return updateFn(prev)
    },
    observer: undefined
  }
  
  // Add update method to observer for notification
  observer.update = () => {
    updateObserver(observer)
  }
  
  // Track dependencies to clean up later
  const dependencies: Set<ObserverR> = new Set()
  
  // Execute the callback initially to track dependencies
  const previous = setActiveObserver(observer)
  try {
    updateFn(value)
  } finally {
    setActiveObserver(previous)
  }
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Clear all dependencies to stop further updates
    dependencies.clear()
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
    observer.update = () => {}
  }
}