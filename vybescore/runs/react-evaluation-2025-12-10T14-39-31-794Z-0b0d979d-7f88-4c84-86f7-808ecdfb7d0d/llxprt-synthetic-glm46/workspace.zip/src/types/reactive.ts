/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  update?: () => void // Add update method to call when notified
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type ObserverT<T> = ObserverR & ObserverV<T> & {
  observer?: ObserverR
}

export type Observer<T> = ObserverR & ObserverV<T> & {
  observer?: ObserverR
}

export type SubjectR = {
  name?: string
  observer?: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): ObserverR | undefined {
  const previous = activeObserver
  activeObserver = observer
  return previous
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = setActiveObserver(observer)
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    setActiveObserver(previous)
  }
}

export function notifyObservers(observer: ObserverR | undefined): void {
  if (!observer) return
  
  // Call the observer's update method if available
  if (typeof observer.update === 'function') {
    observer.update()
  }
}