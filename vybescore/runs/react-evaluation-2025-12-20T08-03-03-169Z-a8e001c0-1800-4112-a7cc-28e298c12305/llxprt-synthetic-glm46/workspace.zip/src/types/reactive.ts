/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observer: ObserverR | undefined
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function updateObserver<T>(observer: Observer<T>): void {
  const previous = activeObserver
  activeObserver = observer
  try {
    const oldValue = observer.value
    observer.value = observer.updateFn(observer.value)
    // Trigger cascade if value actually changed
    if (observer.value !== oldValue) {
      cascadeUpdate(observer)
    }
  } finally {
    activeObserver = previous
  }
}

// Reactive dependency tracking system
const dependencyGraph = new Map<ObserverR, Set<Observer<unknown>>>()

export function trackDependency<T>(subject: ObserverR, dependent: Observer<T>): void {
  if (!dependencyGraph.has(subject)) {
    dependencyGraph.set(subject, new Set())
  }
  dependencyGraph.get(subject)!.add(dependent as Observer<unknown>)
}

export function cascadeUpdate(changedSubject: ObserverR): void {
  const visited = new Set<ObserverR>()
  const toUpdate: Observer<unknown>[] = []
  
  // Collect all dependencies recursively
  function collect(subject: ObserverR): void {
    if (visited.has(subject)) return
    visited.add(subject)
    
    const dependents = dependencyGraph.get(subject)
    if (dependents) {
      dependents.forEach(observer => {
        const observerR = observer as ObserverR
        if (!visited.has(observerR)) {
          toUpdate.push(observer)
          collect(observerR)
        }
      })
    }
  }
  
  collect(changedSubject)
  
  // Update all collected observers
  toUpdate.forEach(observer => {
    updateObserver(observer as Observer<unknown>)
  })
}
