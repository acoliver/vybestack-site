/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  ObserverR, 
  updateObserver,
  getActiveObserver,
  trackDependency,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  // Initial computation to establish dependencies
  updateObserver(o)
  
  const getter: GetterFn<T> = (): T => {
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      // Track this computed value as a dependency for the active observer
      trackDependency(o as ObserverR, activeObserver as Observer<T>)
    }
    return o.value!
  }
  
  return getter
}
