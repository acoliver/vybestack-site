import { readFileSync } from 'fs';
import { ReportData } from '../types/report.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface CliArgs {
  dataFile: string;
  format: string;
  outputFile?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);
  const result = {
    includeTotals: false
  } as CliArgs;

  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      result.format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      result.outputFile = args[++i];
    } else if (arg === '--includeTotals') {
      result.includeTotals = true;
    } else if (!result.dataFile) {
      result.dataFile = arg;
    } else {
      throw new Error(`Unknown argument: ${arg}`);
    }
  }

  if (!result.dataFile) {
    throw new Error('Data file path is required');
  }

  if (!result.format) {
    throw new Error('Format is required');
  }

  return result;
}

function loadData(filePath: string): ReportData {
  try {
    const data = readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (error) {
    if ((error as Error).name === 'SyntaxError') {
      throw new Error(`Invalid JSON in data file: ${filePath}`);
    }
    throw new Error(`Failed to read data file: ${filePath}`);
  }
}

function renderReport(data: ReportData, format: string, includeTotals: boolean): string {
  switch (format) {
    case 'markdown':
      return renderMarkdown(data, { includeTotals });
    case 'text':
      return renderText(data, { includeTotals });
    default:
      throw new Error(`Unsupported format: ${format}`);
  }
}

function main() {
  try {
    const { dataFile, format, outputFile, includeTotals } = parseArgs();
    const data = loadData(dataFile);
    const output = renderReport(data, format, includeTotals);
    
    if (outputFile) {
      // For simplicity, we'll write to stdout even with --output flag
      // as the problem doesn't require file writing in the CLI
      console.log(output);
    } else {
      console.log(output);
    }
  } catch (error) {
    console.error((error as Error).message);
    process.exit(1);
  }
}

main();