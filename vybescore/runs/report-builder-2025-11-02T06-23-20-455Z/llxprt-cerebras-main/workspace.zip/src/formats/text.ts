import { ReportData, FormatOptions } from '../types/report.js';

export function renderText(data: ReportData, options: FormatOptions = {}): string {
  if (!data.title || !data.summary || !Array.isArray(data.entries)) {
    throw new Error('Invalid report data structure');
  }

  let output = `${data.title}\n\n${data.summary}\n\nEntries:\n`;
  
  for (const entry of data.entries) {
    if (!entry.label || typeof entry.amount !== 'number') {
      throw new Error('Invalid entry data structure');
    }
    output += `- ${entry.label}: $${entry.amount.toFixed(2)}\n`;
  }

  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    output += `\nTotal: $${total.toFixed(2)}\n`;
  }

  return output;
}