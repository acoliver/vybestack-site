declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    exec(sql: string): QueryExecResult[];
    export(): Uint8Array;
    close(): void;
    prepare(sql: string): Statement;
    freemem(): void;
  }

  export interface Statement {
    run(params?: unknown[]): RunResult;
    get(params?: unknown[]): unknown[] | null;
    all(params?: unknown[]): unknown[];
    getColumnNames(): string[];
    getAsObject(params?: { [key: string]: unknown }): { [key: string]: unknown } | null;
    bind(params?: unknown[] | { [key: string]: unknown }): boolean;
    step(): boolean;
    free(): void;
  }

  export interface RunResult {
    changes: number;
    lastInsertRowid: number;
  }

  export interface QueryExecResult {
    columns: string[];
    values: unknown[][];
  }

  export interface SqlJsStatic {
    Database: new (data?: ArrayLike<number> | Buffer | null) => Database;
  }

  export default function initSqlJs(config?: { locateFile?: (filename: string) => string }): Promise<SqlJsStatic>;
}
