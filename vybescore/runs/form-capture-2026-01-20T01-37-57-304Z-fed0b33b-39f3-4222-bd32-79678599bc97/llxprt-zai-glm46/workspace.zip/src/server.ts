import express, { Request, Response } from 'express';
import path from 'node:path';
import fs from 'node:fs';
import initSqlJs, { Database } from 'sql.js';

const PORT = process.env.PORT || '3535';
const DB_PATH = path.resolve('data', 'submissions.sqlite');
const SCHEMA_PATH = path.resolve('db', 'schema.sql');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationResult {
  valid: boolean;
  errors: string[];
}

let db: Database | null = null;
const app = express();

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.set('view engine', 'ejs');
app.set('views', path.resolve('src', 'templates'));

app.use('/public', express.static(path.resolve('public')));

function validatePhoneNumber(phone: string): boolean {
  const phoneRegex = /^\+?[0-9\s()-]+$/;
  return phoneRegex.test(phone);
}

function validateEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailRegex.test(email);
}

function validatePostalCode(postalCode: string): boolean {
  const postalRegex = /^[A-Za-z0-9\s-]+$/;
  return postalRegex.test(postalCode);
}

function validateFormData(data: Partial<FormData>): ValidationResult {
  const errors: string[] = [];

  if (!data.firstName || data.firstName.trim() === '') {
    errors.push('First name is required');
  }
  if (!data.lastName || data.lastName.trim() === '') {
    errors.push('Last name is required');
  }
  if (!data.streetAddress || data.streetAddress.trim() === '') {
    errors.push('Street address is required');
  }
  if (!data.city || data.city.trim() === '') {
    errors.push('City is required');
  }
  if (!data.stateProvince || data.stateProvince.trim() === '') {
    errors.push('State / Province / Region is required');
  }
  if (!data.postalCode || data.postalCode.trim() === '') {
    errors.push('Postal / Zip code is required');
  } else if (!validatePostalCode(data.postalCode)) {
    errors.push('Postal code must contain only letters, numbers, spaces, and hyphens');
  }
  if (!data.country || data.country.trim() === '') {
    errors.push('Country is required');
  }
  if (!data.email || data.email.trim() === '') {
    errors.push('Email is required');
  } else if (!validateEmail(data.email)) {
    errors.push('Please enter a valid email address');
  }
  if (!data.phone || data.phone.trim() === '') {
    errors.push('Phone number is required');
  } else if (!validatePhoneNumber(data.phone)) {
    errors.push('Phone number must contain only digits, spaces, parentheses, dashes, and an optional leading +');
  }

  return {
    valid: errors.length === 0,
    errors
  };
}

app.get('/', (req: Request, res: Response) => {
  res.render('form.ejs', { errors: [], values: {} });
});

app.post('/submit', async (req: Request, res: Response) => {
  const formData: Partial<FormData> = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    streetAddress: req.body.streetAddress,
    city: req.body.city,
    stateProvince: req.body.stateProvince,
    postalCode: req.body.postalCode,
    country: req.body.country,
    email: req.body.email,
    phone: req.body.phone
  };

  const validation = validateFormData(formData);

  if (!validation.valid) {
    return res.status(400).render('form.ejs', {
      errors: validation.errors,
      values: formData
    });
  }

  if (!db) {
    return res.status(500).send('Database not initialized');
  }

  try {
    const stmt = db.prepare(
      'INSERT INTO submissions (first_name, last_name, street_address, city, state_province, postal_code, country, email, phone) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    );
    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone
    ]);
    stmt.free();

    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);

    res.redirect(302, '/thank-you');
  } catch (error) {
    console.error('Database error:', error);
    res.status(500).send('An error occurred while saving your submission');
  }
});

app.get('/thank-you', (req: Request, res: Response) => {
  const firstName = req.query.firstName as string || 'Friend';
  res.render('thank-you.ejs', { firstName });
});

async function startServer() {
  const SQL = await initSqlJs();
  const dataDir = path.dirname(DB_PATH);
  if (!fs.existsSync(dataDir)) {
    fs.mkdirSync(dataDir, { recursive: true });
  }

  if (fs.existsSync(DB_PATH)) {
    const buffer = fs.readFileSync(DB_PATH);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
    const schema = fs.readFileSync(SCHEMA_PATH, 'utf-8');
    db.run(schema);
    const data = db.export();
    const buffer = Buffer.from(data);
    fs.writeFileSync(DB_PATH, buffer);
  }

  const server = app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
  });

  process.on('SIGTERM', () => gracefulShutdown(server));
  process.on('SIGINT', () => gracefulShutdown(server));

  return server;
}

function gracefulShutdown(server: ReturnType<typeof app.listen>) {
  console.log('Shutting down gracefully...');
  if (db) {
    db.close();
    db = null;
  }
  server.close(() => {
    console.log('Server closed');
    process.exit(0);
  });
}

if (import.meta.url === `file://${process.argv[1]}`) {
  startServer();
}

export { app, startServer };
