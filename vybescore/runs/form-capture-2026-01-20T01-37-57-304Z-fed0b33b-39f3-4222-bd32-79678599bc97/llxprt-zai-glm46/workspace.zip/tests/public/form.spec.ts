import { describe, expect, it, beforeAll, afterAll } from 'vitest';
import request from 'supertest';
import fs from 'node:fs';
import path from 'node:path';

import { startServer } from '../../src/server';

interface ServerWithClose extends Awaited<ReturnType<typeof startServer>> {
  close: () => void;
}

let server: ServerWithClose;
const dbPath = path.resolve('data', 'submissions.sqlite');

beforeAll(async () => {
  server = await startServer();
});

afterAll(() => {
  if (server && server.close) {
    server.close();
  }
});

describe('friendly form (public smoke)', () => {
  it('renders the form with all fields', async () => {
    const response = await request(server).get('/');
    expect(response.status).toBe(200);
    expect(response.text).toContain('Tell us who you are');
    expect(response.text).toContain('First name');
    expect(response.text).toContain('Last name');
    expect(response.text).toContain('Email');
    expect(response.text).toContain('Phone number');
    expect(response.text).toContain('Postal / Zip code');
    expect(response.text).toContain('Country');
  });

  it('persists submission and redirects', async () => {
    if (fs.existsSync(dbPath)) {
      fs.unlinkSync(dbPath);
    }

    const response = await request(server).post('/submit').type('form').send({
      firstName: 'Test',
      lastName: 'User',
      streetAddress: '123 Main Street',
      city: 'Buenos Aires',
      stateProvince: 'CABA',
      postalCode: 'C1000',
      country: 'Argentina',
      email: 'test@example.com',
      phone: '+54 9 11 1234-5678'
    });

    expect(response.status).toBe(302);
    expect(response.headers.location).toBe('/thank-you');
    expect(fs.existsSync(dbPath)).toBe(true);
  });
});
