declare module 'sql.js' {
  export interface Database {
    run(sql: string, params?: unknown[]): void;
    prepare(sql: string): Statement;
    exec(sql: string): void;
    export(): Uint8Array;
    close(): void;
  }

  export interface Statement {
    run(params?: unknown[]): void;
    free(): void;
  }

  export interface InitSqlJsConfig {
    locateFile: (file: string) => string;
  }

  export default function initSqlJs(config?: InitSqlJsConfig): Promise<{
    Database: new (buffer?: Uint8Array) => Database;
    Statement: new () => Statement;
  }>;
}