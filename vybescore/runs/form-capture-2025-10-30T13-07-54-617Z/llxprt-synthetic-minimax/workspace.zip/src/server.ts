import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import initSqlJs from 'sql.js';
import fs from 'fs';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Minimal type definition for sql.js usage
interface SqlJsDatabase {
  run(sql: string, params?: unknown[]): void;
  prepare(sql: string): SqlJsStatement;
  exec(sql: string): void;
  export(): Uint8Array;
  close(): void;
}

interface SqlJsStatement {
  run(params?: unknown[]): void;
  free(): void;
}

const PORT = parseInt(process.env.PORT || '3000', 10);
const DB_PATH = path.join(__dirname, '../data/submissions.sqlite');

interface FormData {
  firstName: string;
  lastName: string;
  streetAddress: string;
  city: string;
  stateProvince: string;
  postalCode: string;
  country: string;
  email: string;
  phone: string;
}

interface ValidationErrors {
  [key: string]: string;
}

let db: SqlJsDatabase | null = null;

async function initializeDatabase(): Promise<void> {
  const SQL = await initSqlJs({
    locateFile: (file: string) => path.join(__dirname, '../node_modules/sql.js/dist/', file),
  });

  let buffer: Uint8Array | undefined;

  if (fs.existsSync(DB_PATH)) {
    const fileBuffer = fs.readFileSync(DB_PATH);
    buffer = new Uint8Array(fileBuffer);
  }

  db = new SQL.Database(buffer);

  // Read and execute schema
  const schemaPath = path.join(__dirname, '../db/schema.sql');
  const schema = fs.readFileSync(schemaPath, 'utf8');
  db.exec(schema);

  console.log('Database initialized successfully');
}

function validateForm(data: FormData): ValidationErrors {
  const errors: ValidationErrors = {};

  // Check required fields
  const requiredFields: (keyof FormData)[] = [
    'firstName',
    'lastName',
    'streetAddress',
    'city',
    'stateProvince',
    'postalCode',
    'country',
    'email',
    'phone',
  ];

  for (const field of requiredFields) {
    if (!data[field] || data[field].trim() === '') {
      errors[field] = 'This field is required';
    }
  }

  // Validate email format
  if (data.email && data.email.trim() !== '') {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(data.email)) {
      errors.email = 'Please enter a valid email address';
    }
  }

  // Validate phone (digits, spaces, parentheses, dashes, and leading +)
  if (data.phone && data.phone.trim() !== '') {
    const phoneRegex = /^\+?[\d\s\-()]+$/;
    if (!phoneRegex.test(data.phone)) {
      errors.phone = 'Please enter a valid phone number';
    }
  }

  // Validate postal code (alphanumeric)
  if (data.postalCode && data.postalCode.trim() !== '') {
    const postalRegex = /^[A-Za-z0-9\s-]+$/;
    if (!postalRegex.test(data.postalCode)) {
      errors.postalCode = 'Please enter a valid postal code';
    }
  }

  return errors;
}

function saveDatabase(): void {
  if (db !== null) {
    const data = db.export();
    fs.writeFileSync(DB_PATH, Buffer.from(data));
  }
}

async function main(): Promise<void> {
  await initializeDatabase();

  const app = express();

  // Middleware
  app.use(express.urlencoded({ extended: true }));
  app.use(express.json());
  app.use(express.static(path.join(__dirname, '../public')));

  // Set view engine
  app.set('view engine', 'ejs');
  app.set('views', path.join(__dirname, 'templates'));

  // GET / - Render form
  app.get('/', (req: Request, res: Response) => {
    res.render('form', {
      errors: {},
      data: {},
      title: 'Friendly Contact Form',
    });
  });

  // POST /submit - Handle form submission
  app.post('/submit', (req: Request, res: Response) => {
    if (!db) {
      res.status(500).send('Database not initialized');
      return;
    }

    const formData: FormData = {
      firstName: req.body.firstName?.trim() || '',
      lastName: req.body.lastName?.trim() || '',
      streetAddress: req.body.streetAddress?.trim() || '',
      city: req.body.city?.trim() || '',
      stateProvince: req.body.stateProvince?.trim() || '',
      postalCode: req.body.postalCode?.trim() || '',
      country: req.body.country?.trim() || '',
      email: req.body.email?.trim() || '',
      phone: req.body.phone?.trim() || '',
    };

    const errors = validateForm(formData);

    if (Object.keys(errors).length > 0) {
      res.status(400).render('form', {
        errors,
        data: formData,
        title: 'Friendly Contact Form',
      });
      return;
    }

    // Insert into database
    const stmt = db.prepare(`
      INSERT INTO submissions (
        first_name, last_name, street_address, city, 
        state_province, postal_code, country, email, phone
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);

    stmt.run([
      formData.firstName,
      formData.lastName,
      formData.streetAddress,
      formData.city,
      formData.stateProvince,
      formData.postalCode,
      formData.country,
      formData.email,
      formData.phone,
    ]);

    stmt.free();
    saveDatabase();

    // Redirect to thank you page
    res.redirect(302, '/thank-you');
  });

  // GET /thank-you - Render thank you page
  app.get('/thank-you', (req: Request, res: Response) => {
    res.render('thank-you', {
      title: 'Thank You!',
    });
  });

  // Graceful shutdown
  const server = app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
  });

  process.on('SIGTERM', () => {
    console.log('SIGTERM received, shutting down gracefully');
    if (db) {
      saveDatabase();
      db.close();
    }
    server.close(() => {
      console.log('Server closed');
      process.exit(0);
    });
  });
}

main().catch((error) => {
  console.error('Failed to start server:', error);
  process.exit(1);
});