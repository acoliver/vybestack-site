export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * TODO: Implement robust email validation.
 * Requirements are described in problem.md.
 */
export function isValidEmail(value: string): boolean {
  // Regex breakdown:
  // Local part: [a-zA-Z0-9._+-]+ (alphanumeric, dots, underscores, plus, hyphen)
  // @ symbol
  // Domain part: [a-zA-Z0-9-]+ (alphanumeric and hyphen)
  // At least one dot followed by TLD: \.[a-zA-Z]{2,}
  // Additional domains: (\.[a-zA-Z0-9-]+)* (optional additional dots with domains)
  const emailRegex = /^[a-zA-Z0-9._+-]+@[a-zA-Z0-9-]+(\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  return emailRegex.test(value);
}

/**
 * TODO: Implement US phone number validation supporting common separators and optional +1.
 */
export function isValidUSPhone(value: string, /* eslint-disable @typescript-eslint/no-unused-vars */ options?: PhoneValidationOptions): boolean {
  // Remove all non-digit characters except leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for valid format with optional +1
  const phoneRegex = /^\+?1?[2-9]\d{2}[2-9]\d{2}\d{4}$/;
  
  return phoneRegex.test(cleaned);
}

/**
 * TODO: Implement Argentine phone number validation covering mobile/landline formats.
 */
export function isValidArgentinePhone(value: string): boolean {
  // Handle Argentine phone formats:
  // +54 9 11 1234 5678 (mobile with country code)
  // 011 1234 5678 (landline without country code)
  // +54 341 123 4567 (mobile with country code)
  // 0341 4234567 (landline without country code)
  
  const cleaned = value.replace(/[\s-]/g, ''); // Remove spaces and hyphens
  
  // Two patterns:
  // 1. With country code: +54[9]?[area][subscriber] - area code must be 2-4 digits
  // 2. Without country code: 0[area][subscriber] - area code must be 2-4 digits
  const withCountryCode = /^\+54[9]?[1-9]\d{1,3}\d{6,8}$/;
  const withoutCountryCode = /^0[1-9]\d{1,3}\d{6,8}$/;
  
  // More specific check: ensure area code is exactly 2-4 digits
  if (withCountryCode.test(cleaned)) {
    const match = cleaned.match(/^\+54[9]?([1-9]\d{1,3})\d{6,8}$/);
    if (match) {
      const areaCode = match[1];
      return areaCode.length >= 2 && areaCode.length <= 4;
    }
  }
  
  if (withoutCountryCode.test(cleaned)) {
    const match = cleaned.match(/^0([1-9]\d{1,3})\d{6,8}$/);
    if (match) {
      const areaCode = match[1];
      return areaCode.length >= 2 && areaCode.length <= 4;
    }
  }
  
  return false;
}

/**
 * TODO: Validate personal names allowing unicode letters, accents, apostrophes, and hyphenation.
 */
export function isValidName(value: string): boolean {
  // Regex breakdown:
  // ^ - Start of string
  // [\p{L}\p{M}\s'-]+ - Unicode letters (including accents), spaces, apostrophes, hyphens
  // $ - End of string
  // Test with 'u' flag for unicode support
  const nameRegex = /^[\p{L}\p{M}\s'-]+$/u;
  
  // Also reject if it contains digits or special symbols not allowed
  const hasDigitsOrInvalidSymbols = /[0-9]|[^\p{L}\p{M}\s'-]/u.test(value);
  
  // Reject empty or just whitespace
  if (!value.trim()) return false;
  
  return nameRegex.test(value) && !hasDigitsOrInvalidSymbols;
}

/**
 * TODO: Validate credit card numbers (length/prefix + Luhn checksum).
 */
export function isValidCreditCard(value: string): boolean {
  // Remove all non-digit characters
  const cleaned = value.replace(/\D/g, '');
  
  // Check basic format patterns for major credit cards
  const visaPattern = /^4\d{12}(\d{3})?(\d{3})?$/; // 13, 16, or 19 digits starting with 4
  const mastercardPattern = /^(5[1-5]\d{14}|2[2-7]\d{13})$/; // 16 digits: 51-55 or 2221-2720
  const amexPattern = /^3[47]\d{13}$/; // 15 digits starting with 34 or 37
  
  if (!visaPattern.test(cleaned) && !mastercardPattern.test(cleaned) && !amexPattern.test(cleaned)) {
    return false;
  }
  
  // Run Luhn checksum
  return luhnCheck(cleaned);
}

function luhnCheck(cardNumber: string): boolean {
  let sum = 0;
  let isEven = false;
  
  // Process digits from right to left
  for (let i = cardNumber.length - 1; i >= 0; i--) {
    let digit = parseInt(cardNumber.charAt(i), 10);
    
    if (isEven) {
      digit *= 2;
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}
