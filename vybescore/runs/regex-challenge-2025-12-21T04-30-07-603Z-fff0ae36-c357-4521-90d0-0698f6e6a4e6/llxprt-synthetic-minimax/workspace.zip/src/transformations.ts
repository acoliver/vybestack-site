/**
 * TODO: Capitalize the first character of each sentence, preserving spacing rules described in problem.md.
 */
export function capitalizeSentences(text: string): string {
  if (!text.trim()) return text;
  
  // First, clean up whitespace and ensure single spaces between sentences
  let cleaned = text.replace(/\s+/g, ' ').trim();
  
  // Simple pattern: sentence ending punctuation followed by spaces and a lowercase letter
  const pattern = /([.?!])(\s+)([a-z])/g;
  
  cleaned = cleaned.replace(pattern, (match, punct, spaces, letter) => {
    if (!letter) return match;
    return punct + spaces + letter.toUpperCase();
  });
  
  // Capitalize the first letter of the text if it's lowercase
  cleaned = cleaned.replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
  
  return cleaned;
}

/**
 * TODO: Find URLs in the text. Return an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern:
  // http(s)?:// - protocol
  // [^\s<>"']+ - any characters except whitespace, <, ", '
  // Then trim trailing punctuation (.,;:!?)
  const urlRegex = /https?:\/\/[^\s<>"']+/gi;
  
  const matches = text.match(urlRegex) || [];
  
  // Remove trailing punctuation from URLs
  return matches.map(url => {
    return url.replace(/[.,;:!?]+$/g, '');
  });
}

/**
 * TODO: Force all http URLs to https while leaving already secure URLs untouched.
 */
export function enforceHttps(text: string): string {
  // Replace http:// with https://
  // Pattern: http:// followed by any characters (non-greedy), then word boundary or end of string
  return text.replace(/http:\/\/\b/gi, 'https://');
}

/**
 * TODO: Rewrite http://example.com/... to https://..., moving docs paths to https://docs.example.com/ where applicable.
*/
export function rewriteDocsUrls(text: string): string {
  // Find all HTTP URLs
  const urlRegex = /https?:\/\/[^\s<>"']+/gi;
  
  return text.replace(urlRegex, (url) => {
    // Skip HTTPS URLs - only process HTTP
    if (url.startsWith('https://')) {
      return url;
    }
    
    // Try to parse the URL
    try {
      const httpUrl = url.startsWith('http://') ? url : 'http://' + url;
      const parsed = new URL(httpUrl);
      
      // Always upgrade to HTTPS
      let newUrl = 'https://' + parsed.host + parsed.pathname + parsed.search + parsed.hash;
      
      // Check if path starts with /docs/ and doesn't contain dynamic hints
      const path = parsed.pathname;
      const dynamicHints = ['cgi-bin', '?', '&', '=', '.jsp', '.php', '.asp', '.aspx', '.do', '.cgi', '.pl', '.py'];
      const hasDynamicHints = dynamicHints.some(hint => 
        path.includes(hint) || parsed.search.includes(hint) || parsed.hash.includes(hint)
      );
      
      // If path starts with /docs/ and no dynamic hints, rewrite host
      if (path.startsWith('/docs/') && !hasDynamicHints) {
        newUrl = 'https://docs.' + parsed.host + parsed.pathname + parsed.search + parsed.hash;
      }
      
      return newUrl;
    } catch (e) {
      // If URL parsing fails, fall back to just upgrading scheme
      return url.replace(/^http:\/\//, 'https://');
    }
  });
}

/**
 * TODO: Extract the year from mm/dd/yyyy strings. Return 'N/A' when the format is invalid.
 */
export function extractYear(value: string): string {
  // Match mm/dd/yyyy format
  const dateRegex = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  // Validate day based on month
  const daysInMonth = [31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  const maxDay = daysInMonth[month - 1];
  
  // Handle leap years for February
  if (month === 2) {
    const isLeapYear = parseInt(year) % 4 === 0 && (parseInt(year) % 100 !== 0 || parseInt(year) % 400 === 0);
    if (isLeapYear && day > 29) {
      return 'N/A';
    }
    if (!isLeapYear && day > 28) {
      return 'N/A';
    }
  } else if (day < 1 || day > maxDay) {
    return 'N/A';
  }
  
  return year;
}
