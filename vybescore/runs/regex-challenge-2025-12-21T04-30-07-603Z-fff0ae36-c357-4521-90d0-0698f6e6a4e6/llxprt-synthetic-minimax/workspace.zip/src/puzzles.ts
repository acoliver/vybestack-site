/**
 * TODO: Match words starting with the prefix but excluding banned words.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  // Use word boundaries to match complete words that start with the prefix
  const prefixRegex = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'gi');
  
  const matches = text.match(prefixRegex) || [];
  
  // Filter out exceptions (case insensitive) and ensure words actually start with prefix
  return matches.filter(word => {
    // Check if word starts with prefix (case insensitive)
    const startsWithPrefix = word.toLowerCase().startsWith(prefix.toLowerCase());
    
    // Filter out exceptions
    const isException = exceptions.some(exception => 
      word.toLowerCase() === exception.toLowerCase()
    );
    
    return startsWithPrefix && !isException;
  });
}

/**
 * TODO: Find occurrences of a token only when it appears after a digit and not at the beginning of the string.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Escape special characters in token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Capture digit followed by token (not at start of string)
  const embeddedTokenRegex = new RegExp(`(\\d)${escapedToken}`, 'gi');
  
  const matches = text.match(embeddedTokenRegex) || [];
  
  return matches;
}

/**
 * TODO: Validate passwords according to the policy outlined in problem.md.
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) return false;
  
  // Check no whitespace
  if (/\s/.test(value)) return false;
  
  // Check required character types
  const hasUppercase = /[A-Z]/.test(value);
  const hasLowercase = /[a-z]/.test(value);
  const hasDigit = /\d/.test(value);
  const hasSymbol = /[^A-Za-z0-9]/.test(value);
  
  if (!hasUppercase || !hasLowercase || !hasDigit || !hasSymbol) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, abcabc, etc.)
  for (let i = 0; i <= value.length - 4; i++) {
    const sequence = value.substring(i, i + 4);
    const firstTwo = sequence.substring(0, 2);
    const lastTwo = sequence.substring(2, 4);
    
    // Check if it's an immediate repetition (abab pattern)
    if (firstTwo === lastTwo) {
      return false;
    }
  }
  
  return true;
}

/**
 * TODO: Detect IPv6 addresses (including shorthand) and exclude IPv4 addresses.
 */
export function containsIPv6(value: string): boolean {
  // First, check if this looks like an IPv4 address (exclude it)
  const ipv4Pattern = /(?:\d{1,3}\.){3}\d{1,3}/;
  if (ipv4Pattern.test(value)) {
    return false;
  }
  
  // IPv6 detection patterns - look for patterns that indicate IPv6 addresses
  // These patterns should match IPv6 in various formats
  
  const ipv6Patterns = [
    // Pattern for IPv6 with colons and hex digits, allowing :: compression
    /(?:[0-9a-fA-F]{0,4}:){1,}[0-9a-fA-F]{0,4}::/,
    // Pattern for compressed IPv6 addresses
    /::[0-9a-fA-F]/,
    // Pattern for full IPv6 addresses with multiple colons
    /(?:[0-9a-fA-F]*:){2,7}[0-9a-fA-F]*/,
    // More specific pattern for common IPv6 formats
    /[0-9a-fA-F]*:[0-9a-fA-F]*::[0-9a-fA-F:]*/
  ];
  
  // Test if any pattern matches
  return ipv6Patterns.some(pattern => pattern.test(value));
}
