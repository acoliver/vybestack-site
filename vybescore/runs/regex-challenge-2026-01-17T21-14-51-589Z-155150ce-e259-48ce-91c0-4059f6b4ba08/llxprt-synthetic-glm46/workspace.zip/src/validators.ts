export type PhoneValidationOptions = {
  allowExtensions?: boolean;
};

/**
 * Validates email addresses according to common RFC standards.
 * Accepts typical addresses like name+tag@example.co.uk.
 * Rejects double dots, trailing dots, domains with underscores, and other invalid forms.
 */
export function isValidEmail(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Basic email structure: local@domain.tld
  // No double dots consecutive anywhere
  // No leading/trailing dots in local part
  // No underscores in domain
  // Valid characters in local part and domain
  const emailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  // Check the basic format first
  if (!emailRegex.test(value)) return false;
  
  // Split into local and domain parts
  const [local, domain] = value.split('@');
  
  // Local part cannot start or end with a dot
  if (!local || local.startsWith('.') || local.endsWith('.')) return false;
  
  // Local part cannot have consecutive dots
  if (local.includes('..')) return false;
  
  // Domain part cannot have underscores
  if (domain.includes('_')) return false;
  
  // Domain part cannot have consecutive dots
  if (domain.includes('..')) return false;
  
  // Both parts must be non-empty
  if (!local || !domain) return false;
  
  // Final verification with more comprehensive pattern
  const fullEmailRegex = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+(?:\.[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+)*@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*\.[a-zA-Z]{2,}$/;
  
  return fullEmailRegex.test(value);
}

/**
 * Validates US phone numbers in common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
/**
 * Validates US phone numbers in common formats.
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix.
 * Disallows impossible area codes (leading 0/1) and too short inputs.
 */
export function isValidUSPhone(value: string, options?: PhoneValidationOptions): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check if extensions are allowed
  const allowExtensions = options?.allowExtensions || false;
  
  // Remove common separators (spaces, hyphens, parentheses)
  let cleanNumber = value.replace(/[\s\-()]/g, '');
  
  // If extensions are not allowed, check for extension patterns
  if (!allowExtensions) {
    // Check for common extension patterns like x123, ext. 123, etc.
    const extensionRegex = /(ext\.?|x)\s*\d+/i;
    if (extensionRegex.test(value)) {
      // Handle extensions by keeping the main number only
      cleanNumber = value.split(/[xX]|ext\.?\s*/i)[0].replace(/[\s\-()]/g, '');
    }
  }
  
  // Full validation regex
  const phoneRegex = /^(?:\+?1)?([2-9]\d{2})([2-9]\d{2})(\d{4})$/;
  
  const match = cleanNumber.match(phoneRegex);
  if (!match) return false;
  
  return true;
}

/**
 * Validates Argentine phone numbers for both landlines and mobiles.
 * Handles formats like:
 * - +54 9 11 1234 5678 (mobile with country code)
 * - 011 1234 5678 (landline with trunk prefix)
 * - +54 341 123 4567 (landline with country code)
 * - 0341 4234567 (landline with trunk prefix)
 * 
 * Rules:
 * - Optional country code +54
 * - Optional trunk prefix 0 before area code
 * - Optional mobile indicator 9 between country/trunk and area code
 * - Area code: 2-4 digits, leading digit 1-9
 * - Subscriber number: 6-8 digits total
 * - Without country code, must start with trunk prefix 0
 * - Separators: single spaces or hyphens
 */
export function isValidArgentinePhone(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove all spaces and hyphens for easier validation
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if the number has the country code +54
  const hasCountryCode = cleanNumber.startsWith('+54');
  
  // If no country code, must start with trunk prefix 0
  if (!hasCountryCode && !cleanNumber.startsWith('0')) return false;
  
  // Create regex pattern based on whether country code is present
  const countryCodePart = hasCountryCode ? '\\+54' : '0';
  const argentinePhoneRegex = new RegExp(`^${countryCodePart}(?:9)?([1-9]\\d{1,3})(\\d{6,8})$`);
  
  const match = cleanNumber.match(argentinePhoneRegex);
  if (!match) return false;
  
  const areaCode = match[1];
  const subscriberNumber = match[2];
  
  // Validate area code length (2-4 digits, leading digit 1-9)
  if (areaCode.length < 2 || areaCode.length > 4) return false;
  if (areaCode[0] === '0') return false;
  
  // Validate subscriber number length (6-8 digits)
  if (subscriberNumber.length < 6 || subscriberNumber.length > 8) return false;
  
  return true;
}

/**
 * Validates personal names allowing unicode letters, accents, apostrophes, hyphens, and spaces.
 * Rejects digits, symbols, and invalid names like "X Æ A-12".
 */
export function isValidName(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Check for empty or only whitespace
  if (value.trim().length === 0) return false;
  
  // Pattern allows:
  // - Unicode letters (including accented characters)
  // - Apostrophes and hyphens
  // - Spaces
  // - Names like "O'Malley", "Jean-Paul", "Álvaro"
  const nameRegex = /^[\p{L}\p{M}'\-\s]+$/u;
  
  // Check if the value contains only valid name characters
  if (!nameRegex.test(value)) return false;
  
// Reject names that contain digits or special symbols
  const invalidCharsRegex = /[0-9@#$%^&*()+=[{}|\\:<>./?,`~!]/;
  if (invalidCharsRegex.test(value)) return false;
  
  // Ensure at least one letter character (not just hyphens, apostrophes, or spaces)
  const containsLetterRegex = /[\p{L}\p{M}]/u;
  if (!containsLetterRegex.test(value)) return false;
  
  return true;
}

/**
 * Validates credit card numbers for major card types (Visa, Mastercard, AmEx).
 * Checks prefixes, lengths, and performs Luhn checksum validation.
 */
export function isValidCreditCard(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Remove non-digit characters (spaces, hyphens)
  const cleanNumber = value.replace(/[\s-]/g, '');
  
  // Check if all characters are digits
  if (!/^\d+$/.test(cleanNumber)) return false;
  
  // Check length (13-19 digits for major cards)
  if (cleanNumber.length < 13 || cleanNumber.length > 19) return false;
  
  // Validate prefixes for major card types
  const visaRegex = /^4\d{12}(\d{3})?$/;  // 13 or 16 digits
  const mastercardRegex = /^(5[1-5]\d{14})$|^2(2[2-9]\d{13})$|^2[3-6]\d{14}$/; // 16 digits
  const amexRegex = /^3[47]\d{13}$/; // 15 digits
  
  const isValidPrefix = visaRegex.test(cleanNumber) || 
                        mastercardRegex.test(cleanNumber) || 
                        amexRegex.test(cleanNumber);
  
  if (!isValidPrefix) return false;
  
  // Perform Luhn checksum validation
  return runLuhnCheck(cleanNumber);
}

/**
 * Helper function to perform Luhn checksum validation
 */
function runLuhnCheck(number: string): boolean {
  let sum = 0;
  
  // Process digits from right to left
  for (let i = 0; i < number.length; i++) {
    let digit = parseInt(number[number.length - 1 - i]);
    
    // Double every second digit (starting from the second to last)
    if (i % 2 === 1) {
      digit *= 2;
      
      // If result is two digits, add them together
      if (digit > 9) {
        digit -= 9;
      }
    }
    
    sum += digit;
  }
  
  // Valid if sum is divisible by 10
  return sum % 10 === 0;
}
