/**
 * Finds words beginning with the given prefix but excludes the listed exceptions.
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  if (!text || typeof text !== 'string' || !prefix || typeof prefix !== 'string') return [];
  
  // Create a regex to find words starting with the prefix
  // \b ensures we match whole words only
  // \w+ matches word characters
  // Case-insensitive matching
  const prefixRegex = new RegExp(`\\b${prefix}\\w+`, 'gi');
  
  // Find all matches
  const matches = text.match(prefixRegex) || [];
  
  // Convert exceptions to lowercase for case-insensitive comparison
  const exceptionsLower = exceptions.map(ex => ex.toLowerCase());
  
  // Filter out exceptions
  return matches.filter(word => {
    return !exceptionsLower.includes(word.toLowerCase());
  });
}

/**
 * Finds occurrences of a token when it appears after a digit and not at the start of the string.
 * Uses lookaheads and lookbehinds for precise matching.
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  if (!text || typeof text !== 'string' || !token || typeof token !== 'string') return [];
  
  // Escape special regex characters in the token
  const escapedToken = token.replace(/[.*+?^${}()|[\]\\]/g, '\\$&');
  
  // Use a regex with lookbehind to match token preceded by a digit
  // Note: Using a different approach to extract just the match with the digit included
  const tokenRegex = new RegExp(`\\d${escapedToken}(?=\\W|$)`, 'g');
  
  // Use match with the regex to find all occurrences
  const matches = [...text.matchAll(tokenRegex)];
  
  // Return the matched tokens (with the digit included)
  return matches.map(match => match[0]);
}

/**
 * Validates passwords according to policy requirements:
 * - At least 10 characters
 * - One uppercase letter
 * - One lowercase letter
 * - One digit
 * - One symbol
 * - No whitespace
 * - No immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // Minimum length check
  if (value.length < 10) return false;
  
  // Check for whitespace
  if (/\s/.test(value)) return false;
  
  // Check for at least one uppercase letter
  if (!/[A-Z]/.test(value)) return false;
  
  // Check for at least one lowercase letter
  if (!/[a-z]/.test(value)) return false;
  
  // Check for at least one digit
  if (!/[0-9]/.test(value)) return false;
  
  // Check for at least one symbol (non-alphanumeric character)
  if (!/[^a-zA-Z0-9]/.test(value)) return false;
  
  // Check for repeated sequences (like abab, 123123, etc.)
  // This looks for any pattern of 2+ characters that repeats immediately
  if (/(.{2,})\1/.test(value)) return false;
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand like ::) in the text.
 * Ensures IPv4 addresses do not trigger a positive result.
 */
export function containsIPv6(value: string): boolean {
  if (!value || typeof value !== 'string') return false;
  
  // IPv6 address regex pattern excluding IPv4 addresses
  // Supports standard IPv6 notation and shorthand (e.g., ::)
  const ipv6Regex = /\b(?:[0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}\b|::(?:[0-9a-fA-F]{1,4}:){0,6}[0-9a-fA-F]{1,4}\b|[0-9a-fA-F]{1,4}::(?:[0-9a-fA-F]{1,4}:){0,5}[0-9a-fA-F]{1,4}\b|(?:[0-9a-fA-F]{1,4}:){1,7}:\b|(?:[0-9a-fA-F]{0,4}:){2,7}[0-9a-fA-F]{0,4}\b/g;
  
  // First find any potential IPv6 matches
  const matches = [...value.matchAll(ipv6Regex)];
  
  if (matches.length === 0) return false;
  
  // For each match, check if it looks like IPv4 mixed with IPv6
  // IPv4-mapped IPv6 addresses: ::ffff:192.0.2.128
  const ipv4InIPv6Regex = /:([0-9]{1,3}\.){3}[0-9]{1,3}$/;
  
  for (const match of matches) {
    const candidate = match[0];
    
    // Skip if this looks like IPv4 with IPv6 notation
    if (ipv4InIPv6Regex.test(candidate)) continue;
    
    // Additional validation to ensure this is actually IPv6
    // Count of colon-separated groups should be between 2 and 8
    const groups = candidate.split(':').filter(g => g !== '');
    const hasShorthand = candidate.includes('::');
    
    if (hasShorthand) {
      // IPv6 with shorthand is valid if groups count ≤ 7
      if (groups.length <= 7) return true;
    } else if (groups.length === 8) {
      // Standard IPv6 with 8 groups
      return true;
    }
  }
  
  return false;
}
