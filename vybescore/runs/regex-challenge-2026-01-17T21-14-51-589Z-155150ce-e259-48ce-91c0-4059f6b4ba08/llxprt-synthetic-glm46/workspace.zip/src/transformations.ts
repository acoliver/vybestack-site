/**
 * Capitalizes the first character of each sentence.
 * Inserts exactly one space between sentences even if input omitted it.
 * Collapses extra spaces while preserving abbreviations when possible.
 */
export function capitalizeSentences(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // First, replace multiple spaces with a single space
  let normalizedText = text.replace(/\s+/g, ' ').trim();
  
  // Add space after sentence endings if missing
  normalizedText = normalizedText.replace(/([.?!])(?=\S)/g, '$1 ');
  
  // Split into sentences using sentence ending punctuation
  const sentences = normalizedText.split(/(?<=[.?!])\s+/);
  
  // Process each sentence
  const capitalizedSentences = sentences.map(sentence => {
    if (!sentence) return '';
    
    // Find common abbreviations to avoid false sentence breaks
    const abbreviations = ['Mr.', 'Mrs.', 'Dr.', 'Prof.', 'Sr.', 'Jr.', 'St.', 'Ave.', 'Blvd.', 'Rd.', 'Inc.', 'Ltd.', 'Co.', 'vs.', 'etc.', 'e.g.', 'i.e.', 'Ph.D.'];
    const sentenceStart = sentence.substring(0, 4);
    
    // If this looks like an abbreviation continuation, don't capitalize
    if (abbreviations.some(abbr => sentenceStart === abbr)) {
      return sentence;
    }
    
    // Capitalize first character, lower the rest for consistency
    if (sentence.length > 0) {
      return sentence.charAt(0).toUpperCase() + sentence.slice(1);
    }
    return sentence;
  });
  
  // Join sentences back with a single space
  let result = capitalizedSentences.join(' ');
  
  // Fix any double spaces that might have been created
  result = result.replace(/\s{2,}/g, ' ');
  
  // Ensure no trailing space
  return result.trim();
}

/**
 * Extracts all URLs from the text without trailing punctuation.
 * Returns an array of matched URL strings.
 */
export function extractUrls(text: string): string[] {
  if (!text || typeof text !== 'string') return [];
  
  // Simple pattern to extract URLs with protocols or www
  // Match protocols followed by domain and optional path
  const urlRegex = /(https?:\/\/|ftp:\/\/)[^\s]+|[www][.][^\s]+/gi;
  
  const matches = [...text.matchAll(urlRegex)];
  if (!matches || matches.length === 0) return [];
  
  // Clean each URL by removing trailing punctuation
  return matches.map(match => {
    let url = match[0];
    // Remove trailing punctuation
    url = url.replace(/[.,;:!?)]+$/g, '');
    return url;
  });
}

/**
 * Replaces http:// schemes with https:// while leaving already secure URLs unchanged.
 */
export function enforceHttps(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Regular expression to match http:// URLs
  const httpUrlRegex = /http:\/\/[^\s]+/gi;
  
  // Replace all http:// with https://
  return text.replace(httpUrlRegex, (match) => match.replace(/^http:\/\//, 'https://'));
}

/**
 * Rewrites URLs according to specific rules:
 * - Always upgrade http:// to https://
 * - For URLs from http://example.com/..., when path begins with /docs/, 
 *   rewrite host to docs.example.com (e.g., https://docs.example.com/...)
 * - Skip host rewrite for URLs with dynamic hints (cgi-bin, query strings, 
 *   legacy extensions like .jsp, .php, .asp, .aspx, .do, .cgi, .pl, .py)
 * - Preserve nested paths (e.g., /docs/api/v1)
 */
export function rewriteDocsUrls(text: string): string {
  if (!text || typeof text !== 'string') return '';
  
  // Match http://example.com URLs
  const exampleUrlRegex = /(http:\/\/example\.com)([^\s]+?)(?=[\s,.!?]|$)/gi;
  
  return text.replace(exampleUrlRegex, (match, protocolHost, path) => {
    // Always upgrade to https
    const secureUrl = match.replace(/^http:\/\//, 'https://');
    
    // Extract just the path part after the host
    const pathOnly = path.startsWith('/') ? path : '/' + path;
    
    // Check if this URL should have its host rewritten
    // Conditions for NOT rewriting:
    // 1. Contains query parameters
    // 2. Contains cgi-bin
    // 3. Ends with dynamic file extensions
    const hasDynamicHints = /[?&=]|cgi-bin|(\.(jsp|php|asp|aspx|do|cgi|pl|py)[^\w]*$)/gi.test(pathOnly);
    
    // Rewrite host if this is a docs path and doesn't have dynamic hints
    if (pathOnly.startsWith('/docs/') && !hasDynamicHints) {
      return secureUrl.replace(/^https:\/\/example\.com/, 'https://docs.example.com');
    }
    
    return secureUrl;
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format strings.
 * Returns 'N/A' when the format is invalid or month/day values are incorrect.
 */
export function extractYear(value: string): string {
  if (!value || typeof value !== 'string') return 'N/A';
  
  // Regular expression to match mm/dd/yyyy format
  const dateRegex = /^(\d{2})\/(\d{2})\/(\d{4})$/;
  const match = value.match(dateRegex);
  
  if (!match || match.length !== 4) return 'N/A';
  
  const month = parseInt(match[1], 10);
  const day = parseInt(match[2], 10);
  const year = match[3];
  
  // Validate month (1-12)
  if (month < 1 || month > 12) return 'N/A';
  
  // Validate day (1-31, with basic month-specific validation)
  const maxDays = [31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31]; // Assuming Feb has 29 days
  if (day < 1 || day > maxDays[month - 1]) return 'N/A';
  
  // Special validation for February with leap year logic
  if (month === 2 && day === 29) {
    const yearNum = parseInt(year, 10);
    // Leap year if divisible by 4, but not by 100 unless also divisible by 400
    const isLeapYear = (yearNum % 4 === 0 && yearNum % 100 !== 0) || (yearNum % 400 === 0);
    if (!isLeapYear) return 'N/A';
  }
  
  return year;
}
