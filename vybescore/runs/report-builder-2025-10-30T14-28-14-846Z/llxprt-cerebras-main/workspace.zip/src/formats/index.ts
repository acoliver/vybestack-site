import { renderMarkdown } from './markdown.js';
import { renderText } from './text.js';
import { ReportData, FormatOptions } from '../types.js';

// Define a type for our formatters
type Formatter = (data: ReportData, options: FormatOptions) => string;

// Create a registry mapping format names to their render functions
export const formatters: Record<string, Formatter> = {
  markdown: renderMarkdown,
  text: renderText,
};