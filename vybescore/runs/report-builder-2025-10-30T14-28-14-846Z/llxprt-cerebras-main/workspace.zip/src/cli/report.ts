#!/usr/bin/env node

import { readFile } from 'fs/promises';
import { ReportData } from '../types.js';
import { formatters } from '../formats/index.js';

async function main() {
  const args = process.argv.slice(2);
  
  // Parse arguments
  let dataFile: string | undefined;
  let format: string | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg === '--format' && i + 1 < args.length) {
      format = args[++i];
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[++i];
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!dataFile && !arg.startsWith('-')) {
      dataFile = arg;
    }
  }
  
  // Validate arguments
  if (!dataFile) {
    console.error('Error: Data file path is required');
    process.exit(1);
  }
  
  if (!format) {
    console.error('Error: Format is required');
    process.exit(1);
  }
  
  // Validate format
  if (!formatters[format]) {
    console.error(`Error: Unsupported format "${format}"`);
    process.exit(1);
  }
  
  try {
    // Read and parse data file
    const dataContent = await readFile(dataFile, 'utf8');
    const data: ReportData = JSON.parse(dataContent);
    
    // Validate data structure
    if (!data.title || !data.summary || !Array.isArray(data.entries)) {
      console.error('Error: Invalid data structure. Required fields: title, summary, entries');
      process.exit(1);
    }
    
    // Render report
    const output = formatters[format](data, { includeTotals });
    
    // Output to file or stdout
    if (outputPath) {
      await writeFile(outputPath, output);
      console.log(`Report written to ${outputPath}`);
    } else {
      console.log(output);
    }
  } catch (error: unknown) {
    if (error instanceof SyntaxError) {
      console.error('Error: Invalid JSON in data file');
    } else if (error instanceof Error) {
      console.error(`Error: ${error.message}`);
    } else {
      console.error('Error: Unknown error occurred');
    }
    process.exit(1);
  }
}

// Helper function to write output to file
async function writeFile(path: string, content: string) {
  const { writeFile: fsWriteFile } = await import('fs/promises');
  await fsWriteFile(path, content, 'utf8');
}

main();