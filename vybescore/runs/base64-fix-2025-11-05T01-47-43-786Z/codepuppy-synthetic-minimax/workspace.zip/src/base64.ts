/**
 * Encode plain text to Base64 using RFC 4648 standard alphabet.
 * Uses canonical Base64 with proper padding.
 */
export function encode(input: string): string {
  try {
    return Buffer.from(input, 'utf8').toString('base64');
  } catch (error) {
    throw new Error('Failed to encode input to Base64');
  }
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts standard Base64 input with or without padding.
 * Throws an error for invalid Base64 input.
 */
export function decode(input: string): string {
  if (!input || typeof input !== 'string') {
    throw new Error('Invalid Base64 input: input must be a non-empty string');
  }

  // Check for valid Base64 characters (canonical alphabet plus optional padding)
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input.trim())) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }

  const trimmed = input.trim();
  
  // Check padding validity
  const paddingIndex = trimmed.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const paddingOnly = trimmed.slice(paddingIndex);
    if (!/^=+$/.test(paddingOnly)) {
      throw new Error('Invalid Base64 input: padding characters must be at the end');
    }
    
    // Maximum 2 padding characters allowed
    if (paddingOnly.length > 2) {
      throw new Error('Invalid Base64 input: too many padding characters');
    }
    
    // Total length must be multiple of 4 when padding is present
    if (trimmed.length % 4 !== 0) {
      throw new Error('Invalid Base64 input: incorrect length for padding');
    }
  } else {
    // Without padding, length must be multiple of 4
    if (trimmed.length % 4 !== 0) {
      // Add padding to make it valid for Buffer decoding
      const paddedLength = Math.ceil(trimmed.length / 4) * 4;
      const paddingNeeded = paddedLength - trimmed.length;
      return Buffer.from(trimmed + '='.repeat(paddingNeeded), 'base64').toString('utf8');
    }
  }

  try {
    const result = Buffer.from(trimmed, 'base64').toString('utf8');
    
    // Verify the result by re-encoding and comparing
    // This catches malformed Base64 that Buffer might silently handle
    const reencoded = Buffer.from(result, 'utf8').toString('base64');
    const normalizedReencoded = reencoded.replace(/=+$/, '');
    const normalizedInput = trimmed.replace(/=+$/, '');
    
    if (normalizedReencoded !== normalizedInput) {
      throw new Error('Invalid Base64 input: corrupted or malformed data');
    }
    
    return result;
  } catch (error) {
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('Failed to decode Base64 input');
  }
}
