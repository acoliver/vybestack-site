/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  getActiveObserver,
  Subject
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
    observers: new Set(),
  }
  
  // Create a subject to represent this computed value
  const computedSubject: Subject<T> = {
    name: options?.name,
    observer: o as Observer<unknown>,
    value: value as T,
    observers: new Set(),
  }
  
  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer && computedSubject.observers) {
      // This observer now depends on this computed value
      computedSubject.observers.add(observer as Observer<unknown>)
    }
    return computedSubject.value
  }
  
  // Override the observer's update function to update the subject value
  const originalUpdateFn = o.updateFn
  o.updateFn = (prev) => {
    const result = originalUpdateFn(prev)
    computedSubject.value = result
    
    // Notify observers that depend on this computed value
    if (computedSubject.observers) {
      computedSubject.observers.forEach(observer => {
        updateObserver(observer)
      })
    }
    
    return result
  }
  
  // Initial computation
  updateObserver(o)
  computedSubject.value = o.value!
  
  return read
}
