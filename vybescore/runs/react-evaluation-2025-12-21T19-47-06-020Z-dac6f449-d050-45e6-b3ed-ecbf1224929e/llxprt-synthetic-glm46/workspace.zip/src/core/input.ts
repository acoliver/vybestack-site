/**
 * Input closure implementation for reactive primitives.
 */

import {
  InputPair,
  Subject,
  Observer,
  getActiveObserver,
  updateObserver,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'
import { callbacks } from './callback.js'

// Global registry to track computed subjects and their dependencies
const computedSubjects = new WeakMap<Observer<unknown>, Subject<unknown>>()

export function registerComputedSubject(observer: Observer<unknown>, subject: Subject<unknown>): void {
  computedSubjects.set(observer, subject)
}

export function getComputedSubject(observer: Observer<unknown>): Subject<unknown> | undefined {
  return computedSubjects.get(observer)
}

// Registry to track which observers depend on which subjects (using a Map for iteration)
const observerToSubjects = new Map<Observer<unknown>, Set<Subject<unknown>>>()
const subjectToObservers = new Map<Subject<unknown>, Set<Observer<unknown>>>()

export function trackObserverDependency(observer: Observer<unknown>, subject: Subject<unknown>): void {
  if (!observerToSubjects.has(observer)) {
    observerToSubjects.set(observer, new Set())
  }
  observerToSubjects.get(observer)!.add(subject)
  
  if (!subjectToObservers.has(subject)) {
    subjectToObservers.set(subject, new Set())
  }
  subjectToObservers.get(subject)!.add(observer)
}

// Topological sort utility for proper dependency ordering
function topologicalSort(observers: Observer<unknown>[]): Observer<unknown>[] {
  const visited = new Set<Observer<unknown>>()
  const visiting = new Set<Observer<unknown>>()
  const result: Observer<unknown>[] = []
  
  function visit(observer: Observer<unknown>) {
    if (visiting.has(observer)) {
      // Circular dependency detected, put it at the end
      return
    }
    
    if (visited.has(observer)) return
    
    visiting.add(observer)
    
    // Visit all dependencies first
    const dependencies = observerToSubjects.get(observer)
    if (dependencies) {
      dependencies.forEach(subject => {
        const dependentObservers = subjectToObservers.get(subject)
        if (dependentObservers) {
          dependentObservers.forEach(dep => {
            if (dep !== observer) {
              visit(dep)
            }
          })
        }
      })
    }
    
    visiting.delete(observer)
    visited.add(observer)
    result.push(observer)
  }
  
  observers.forEach(observer => visit(observer))
  
  return result
}

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const equalFn: EqualFn<T> | undefined = _equal === true 
    ? ((a, b) => a === b) 
    : typeof _equal === 'function' 
      ? _equal 
      : undefined

  const s: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value,
    equalFn,
  }

  const read: GetterFn<T> = () => {
    const observer = getActiveObserver()
    if (observer) {
      // This observer now depends on this subject
      s.observer = observer
      
      // This observer is an actual observer, not a mock one
      // So track the actual dependency
      trackObserverDependency(observer as Observer<unknown>, s as Subject<unknown>)
    }
    return s.value as T
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check equality if an equality function is provided
    if (equalFn && s.value !== undefined && equalFn(s.value as T, nextValue)) {
      return s.value as T
    }
    
    s.value = nextValue
    
    // Create a set to track which observers have been processed
    const processed = new Set<Observer<unknown>>()
    const toUpdate: Observer<unknown>[] = []
    
    // Helper function to recursively collect all observers that depend on this subject
    const collectDependents = (subject: Subject<unknown>) => {
      const observers = subjectToObservers.get(subject)
      if (!observers) return
      
      observers.forEach(observer => {
        if (!processed.has(observer)) {
          processed.add(observer)
          toUpdate.push(observer)
          
          // If this is a computed observer, also collect its dependents
          const computedSubject = getComputedSubject(observer)
          if (computedSubject) {
            collectDependents(computedSubject)
          }
        }
      })
    }
    
    // Collect all observers that depend on this subject
    collectDependents(s as Subject<unknown>)
    
    // Also collect all callbacks (they don't have subjects, but might depend on inputs)
    callbacks.forEach(callback => {
      if (!processed.has(callback as Observer<unknown>)) {
        toUpdate.push(callback as Observer<unknown>)
      }
    })
    
    // Sort observers using topological sort to ensure dependencies are updated before dependents
    const sortedObservers = topologicalSort(toUpdate)
    
    // Update all observers in the correct order
    sortedObservers.forEach(observer => {
      updateObserver(observer)
      
      // If this is a computed observer, update its subject's value
      const computedSubject = getComputedSubject(observer)
      if (computedSubject) {
        computedSubject.value = observer.value
      }
    })
    
    return s.value
  }

  return [read, write]
}
