/**
 * Computed closure implementation for derived values.
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer, 
  updateObserver,
  EqualFn,
  Options,
  Subject,
  getActiveObserver
} from '../types/reactive.js'
import { registerComputedSubject, trackObserverDependency } from './input.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: Options
): GetterFn<T> {
  const equalFn: EqualFn<T> | undefined = _equal === true 
    ? ((a, b) => a === b) 
    : typeof _equal === 'function' 
      ? _equal 
      : undefined

  // Create a subject for this computed value so other computed values can depend on it
  const computedSubject: Subject<T> = {
    name: options?.name,
    observer: undefined,
    value: value !== undefined ? value : undefined,
    equalFn,
  }

  // Create the observer/computed function
  const observer: Observer<T> = {
    name: options?.name,
    value: value !== undefined ? value : undefined as T,
    updateFn,
  }
  
  // Register the relationship between observer and subject
  registerComputedSubject(observer as Observer<unknown>, computedSubject as Subject<unknown>)
  
  // Run the update function to establish dependencies and get initial value
  updateObserver(observer)
  // Update the computed subject's value if defined
  if (observer.value !== undefined) {
    computedSubject.value = observer.value
  }
  
  // Create the getter function
  const getter: GetterFn<T> = () => {
    // When this computed is accessed, track dependencies
    const activeObserver = getActiveObserver()
    if (activeObserver) {
      computedSubject.observer = activeObserver
      
      // Track the actual dependency
      trackObserverDependency(activeObserver as Observer<unknown>, computedSubject as Subject<unknown>)
    }
    return observer.value!
  }
  
  return getter
}
