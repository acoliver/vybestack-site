// Debug script to understand the reactive system behavior
// We need to import from compiled JavaScript since this is a test script

// Since this is an ESM project, let's create a proper import
import { createInput, createComputed } from './src/index.js';

const [input, setInput] = createInput(1);
console.log('Initial input:', input());

const timesTwo = createComputed(() => {
  console.log('Computing timesTwo, input is:', input());
  return input() * 2;
});

const timesThirty = createComputed(() => {
  console.log('Computing timesThirty, input is:', input());
  return input() * 30;
});

console.log('timesTwo:', timesTwo());
console.log('timesThirty:', timesThirty());

const sum = createComputed(() => {
  console.log('Computing sum, timesTwo is:', timesTwo(), 'timesThirty is:', timesThirty());
  return timesTwo() + timesThirty();
});

console.log('sum:', sum());

console.log('Setting input to 3...');
setInput(3);

console.log('After setInput(3):');
console.log('input:', input());
console.log('timesTwo:', timesTwo());
console.log('timesThirty:', timesThirty());
console.log('sum:', sum());