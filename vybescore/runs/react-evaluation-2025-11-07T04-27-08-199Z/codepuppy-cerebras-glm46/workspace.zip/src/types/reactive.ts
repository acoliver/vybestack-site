/**
 * Type definitions for the reactive programming system
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
  dependencies?: Set<Subject<any>>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers: Set<Observer<any>>
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

let activeObserver: Observer<any> | undefined

export function getActiveObserver(): Observer<any> | undefined {
  return activeObserver
}

export function setActiveObserver(observer: Observer<any> | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Clear previous dependencies
  observer.dependencies = new Set()
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  subject.observers.forEach(observer => {
    updateObserver(observer)
  })
}

export function trackDependency<T>(subject: Subject<T>): void {
  const observer = getActiveObserver()
  if (observer && !observer.dependencies?.has(subject)) {
    observer.dependencies?.add(subject)
    subject.observers.add(observer)
  }
}

// Helper function to create equality function
export function createEqualFn<T>(equal?: boolean | EqualFn<T>): EqualFn<T> | undefined {
  if (equal === undefined) return undefined
  if (typeof equal === 'boolean') {
    return equal ? (lhs: T, rhs: T) => lhs === rhs : undefined
  }
  return equal
}
