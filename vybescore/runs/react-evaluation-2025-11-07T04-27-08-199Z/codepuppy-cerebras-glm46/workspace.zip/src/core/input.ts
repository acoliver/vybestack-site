/**
 * Input closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import {
  InputPair,
  Subject,
  trackDependency,
  notifyObservers,
  createEqualFn,
  EqualFn,
  GetterFn,
  SetterFn,
  Options
} from '../types/reactive.js'

/**
 * Creates an input closure. The value is accessed
 * via the accessor and changed via the
 * mutator returned as part an `InputPair<T>`.
 */
export function createInput<T>(
  value: T,
  equal?: boolean | EqualFn<T>,
  options?: Options
): InputPair<T> {
  const s: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value,
    equalFn: createEqualFn(equal),
  }

  const read: GetterFn<T> = () => {
    trackDependency(s)
    return s.value
  }

  const write: SetterFn<T> = (nextValue) => {
    // Check if value actually changed using equality function
    if (s.equalFn && s.equalFn(s.value, nextValue)) {
      return s.value
    }
    
    s.value = nextValue
    notifyObservers(s)
    return s.value
  }

  return [read, write]
}
