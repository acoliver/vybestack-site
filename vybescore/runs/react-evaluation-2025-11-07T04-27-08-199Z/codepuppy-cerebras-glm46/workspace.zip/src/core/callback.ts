/**
 * Callback closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { UnsubscribeFn, Observer, UpdateFn, updateObserver } from '../types/reactive.js'

/**
 * Creates a callback closure with the supplied
 * function which is expected to perform side effects.
 */
export function createCallback<T>(updateFn: UpdateFn<T>, value?: T): UnsubscribeFn {
  const observer: Observer<T> = {
    value,
    dependencies: new Set(),
    updateFn: (currentValue?: T) => {
      const newValue = updateFn(currentValue)
      // For callbacks, we don't care about the return value, just the side effect
      return newValue
    },
  }
  
  // Register observer to track dependencies
  updateObserver(observer)
  
  let disposed = false
  
  return () => {
    if (disposed) return
    disposed = true
    
    // Remove observer from all its dependencies
    if (observer.dependencies) {
      observer.dependencies.forEach(subject => {
        subject.observers.delete(observer as any)
      })
      observer.dependencies.clear()
    }
    
    // Clear the observer to stop further updates
    observer.value = undefined
    observer.updateFn = () => value!
  }
}