/**
 * Computed closure implementation
 * Adapted from Exercism TypeScript React exercise
 * MIT License - Original by Exercism community
 */

import { 
  GetterFn, 
  UpdateFn, 
  Observer,
  Subject,
  updateObserver,
  trackDependency,
  notifyObservers,
  createEqualFn,
  EqualFn
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const equalFn = createEqualFn(equal)
  
  // Create a subject for the computed value to track its observers
  const computedSubject: Subject<T> = {
    name: options?.name,
    observers: new Set(),
    value: value as T,
    equalFn,
  }
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    dependencies: new Set(),
    updateFn: (currentValue?: T) => {
      const newValue = updateFn(currentValue)
      // Check if value actually changed
      if (equalFn && currentValue !== undefined && equalFn(currentValue, newValue)) {
        return currentValue!
      }
      
      // Update the subject's value and notify its observers
      computedSubject.value = newValue
      notifyObservers(computedSubject)
      
      return newValue
    },
  }
  
  // Initialize the computed value
  updateObserver(o)
  
  return (): T => {
    // When accessed, track this computed as a dependency
    trackDependency(computedSubject)
    return computedSubject.value
  }
}