import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API (public smoke)', () => {
  it('returns some inventory rows', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeGreaterThan(0);
  });

  it('returns correct pagination metadata', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1&limit=5');
    expect(response.status).toBe(200);
    expect(response.body).toHaveProperty('page', 1);
    expect(response.body).toHaveProperty('limit', 5);
    expect(response.body).toHaveProperty('total');
    expect(response.body).toHaveProperty('hasNext');
    expect(response.body).toHaveProperty('items');
    expect(Array.isArray(response.body.items)).toBe(true);
  });

  it('paginates correctly with different pages', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get page 1
    const page1 = await request(app).get('/inventory?page=1&limit=3');
    expect(page1.status).toBe(200);
    expect(page1.body.page).toBe(1);
    expect(page1.body.limit).toBe(3);
    
    // Get page 2
    const page2 = await request(app).get('/inventory?page=2&limit=3');
    expect(page2.status).toBe(200);
    expect(page2.body.page).toBe(2);
    expect(page2.body.limit).toBe(3);
    
    // Items should be different
    expect(page1.body.items[0].id).not.toBe(page2.body.items[0].id);
  });

  it('validates invalid page parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test negative page
    const negativePage = await request(app).get('/inventory?page=-1');
    expect(negativePage.status).toBe(400);
    expect(negativePage.body.error).toContain('page must be a positive number');
    
    // Test zero page
    const zeroPage = await request(app).get('/inventory?page=0');
    expect(zeroPage.status).toBe(400);
    expect(zeroPage.body.error).toContain('page must be a positive number');
    
    // Test non-numeric page
    const nanPage = await request(app).get('/inventory?page=abc');
    expect(nanPage.status).toBe(400);
    expect(nanPage.body.error).toContain('page must be a positive number');
  });

  it('validates invalid limit parameters', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Test negative limit
    const negativeLimit = await request(app).get('/inventory?limit=-1');
    expect(negativeLimit.status).toBe(400);
    expect(negativeLimit.body.error).toContain('limit must be a positive number not exceeding 100');
    
    // Test zero limit
    const zeroLimit = await request(app).get('/inventory?limit=0');
    expect(zeroLimit.status).toBe(400);
    expect(zeroLimit.body.error).toContain('limit must be a positive number not exceeding 100');
    
    // Test excessive limit
    const excessiveLimit = await request(app).get('/inventory?limit=101');
    expect(excessiveLimit.status).toBe(400);
    expect(excessiveLimit.body.error).toContain('limit must be a positive number not exceeding 100');
    
    // Test non-numeric limit
    const nanLimit = await request(app).get('/inventory?limit=abc');
    expect(nanLimit.status).toBe(400);
    expect(nanLimit.body.error).toContain('limit must be a positive number not exceeding 100');
  });

  it('hasNext flag is calculated correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    // Get small page size to test pagination
    const response = await request(app).get('/inventory?limit=3');
    expect(response.status).toBe(200);
    
    const total = response.body.total;
    const limit = response.body.limit;
    const currentPage = response.body.page;
    const hasNext = response.body.hasNext;
    
    // hasNext should be true if there are more items
    const expectedHasNext = currentPage * limit < total;
    expect(hasNext).toBe(expectedHasNext);
  });

  it('returns default values when no parameters provided', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5); // DEFAULT_LIMIT
  });
});
