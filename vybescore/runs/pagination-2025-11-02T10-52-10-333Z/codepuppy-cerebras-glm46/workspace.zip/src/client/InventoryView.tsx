import { useState } from 'react';
import type { InventoryItem } from '../shared/types';
import { useInventory } from './useInventory';

const PAGE_LIMIT = 5;

function InventoryList({ items }: { items: InventoryItem[] }) {
  if (items.length === 0) {
    return <p>No inventory items found.</p>;
  }
  
  return (
    <ul>
      {items.map((item) => (
        <li key={item.id}>
          <strong>{item.name}</strong> <span>({item.sku})</span> – ${(item.priceCents / 100).toFixed(2)}
        </li>
      ))}
    </ul>
  );
}

function PaginationControls({ 
  currentPage, 
  hasNext, 
  total, 
  limit,
  onPageChange 
}: {
  currentPage: number;
  hasNext: boolean;
  total: number;
  limit: number;
  onPageChange: (page: number) => void;
}) {
  const hasPrevious = currentPage > 1;
  const totalPages = Math.ceil(total / limit);

  return (
    <nav aria-label="Inventory pagination">
      <div className="pagination-info">
        Page {currentPage} of {totalPages} ({total} total items)
      </div>
      <div className="pagination-controls">
        <button
          onClick={() => onPageChange(currentPage - 1)}
          disabled={!hasPrevious}
          aria-label="Previous page"
        >
          Previous
        </button>
        <button
          onClick={() => onPageChange(currentPage + 1)}
          disabled={!hasNext}
          aria-label="Next page"
        >
          Next
        </button>
      </div>
    </nav>
  );
}

export function InventoryView() {
  const [currentPage, setCurrentPage] = useState(1);
  const { status, data, error } = useInventory(currentPage, PAGE_LIMIT);

  if (status === 'loading') {
    return <p>Loading inventory…</p>;
  }

  if (status === 'error' || !data) {
    return <p role="alert">{error ?? 'Unable to load inventory.'}</p>;
  }

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1) {
      setCurrentPage(newPage);
    }
  };

  return (
    <section>
      <h1>Inventory</h1>
      <InventoryList items={data.items} />
      <PaginationControls
        currentPage={data.page}
        hasNext={data.hasNext}
        total={data.total}
        limit={data.limit}
        onPageChange={handlePageChange}
      />
    </section>
  );
}