/**
 * Data model for report entries
 */
export interface ReportEntry {
  label: string;
  amount: number;
}

/**
 * Main report data structure
 */
export interface ReportData {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

/**
 * Common options for all formatters
 */
export interface RenderOptions {
  includeTotals: boolean;
}

/**
 * Base interface for report formatters
 */
export interface ReportFormatter {
  render(data: ReportData, options: RenderOptions): string;
}