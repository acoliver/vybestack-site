#!/usr/bin/env node

import fs from 'node:fs';
import process from 'node:process';
import { validateReportData } from '../utils.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

/**
 * CLI argument parser for report generation
 */
interface CliArgs {
  inputFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(): CliArgs {
  const args = process.argv.slice(2);

  if (args.length < 3) {
    console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
    process.exit(1);
  }

  const inputFile = args[0];
  
  // Find format index
  const formatIndex = args.indexOf('--format');
  if (formatIndex === -1 || formatIndex === args.length - 1) {
    console.error('Error: --format argument is required');
    process.exit(1);
  }
  const format = args[formatIndex + 1];

  // Find output index
  const outputIndex = args.indexOf('--output');
  const outputPath = outputIndex !== -1 && outputIndex < args.length - 1 ? args[outputIndex + 1] : undefined;

  // Check for includeTotals flag
  const includeTotals = args.includes('--includeTotals');

  return {
    inputFile,
    format,
    outputPath,
    includeTotals
  };
}

/**
 * Main CLI execution function
 */
async function main(): Promise<void> {
  try {
    const args = parseArgs();

    // Validate format
    if (!['markdown', 'text'].includes(args.format)) {
      console.error(`Error: Unsupported format "${args.format}". Supported formats: markdown, text`);
      process.exit(1);
    }

    // Read and parse input file
    let fileContent: string;
    try {
      fileContent = fs.readFileSync(args.inputFile, 'utf-8');
    } catch (error) {
      console.error(`Error: Unable to read file "${args.inputFile}"`);
      process.exit(1);
    }

    let data: unknown;
    try {
      data = JSON.parse(fileContent);
    } catch (error) {
      console.error(`Error: Invalid JSON in file "${args.inputFile}"`);
      process.exit(1);
    }

    // Validate and normalize data
    const reportData = validateReportData(data);

    // Render report
    const output = args.format === 'markdown' 
      ? renderMarkdown(reportData, { includeTotals: args.includeTotals })
      : renderText(reportData, { includeTotals: args.includeTotals });

    // Write output
    if (args.outputPath) {
      try {
        fs.writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error: Unable to write to file "${args.outputPath}"`);
        process.exit(1);
      }
    } else {
      console.log(output);
    }

    process.exit(0);
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'Unknown error'}`);
    process.exit(1);
  }
}

// Execute main function
if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((error) => {
    console.error('Fatal error:', error);
    process.exit(1);
  });
}