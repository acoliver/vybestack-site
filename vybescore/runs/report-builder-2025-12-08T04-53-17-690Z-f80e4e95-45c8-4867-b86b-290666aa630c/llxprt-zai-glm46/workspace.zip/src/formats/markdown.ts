import type { ReportData, RenderOptions, ReportFormatter } from '../types.js';
import { calculateTotal, formatCurrency } from '../utils.js';

/**
 * Markdown formatter for reports
 */
export class MarkdownFormatter implements ReportFormatter {
  render(data: ReportData, options: RenderOptions): string {
    const lines: string[] = [];

    // Title
    lines.push(`# ${data.title}`);
    lines.push('');

    // Summary
    lines.push(data.summary);
    lines.push('');

    // Entries heading
    lines.push('## Entries');

    // Entries list
    for (const entry of data.entries) {
      lines.push(`- **${entry.label}** — ${formatCurrency(entry.amount)}`);
    }

    // Total if requested
    if (options.includeTotals) {
      const total = calculateTotal(data.entries);
      lines.push(`\n**Total:** ${formatCurrency(total)}`);
    }

    return lines.join('\n');
  }
}

// Export a default instance for convenience
export const renderMarkdown = (data: ReportData, options: RenderOptions): string => {
  const formatter = new MarkdownFormatter();
  return formatter.render(data, options);
};