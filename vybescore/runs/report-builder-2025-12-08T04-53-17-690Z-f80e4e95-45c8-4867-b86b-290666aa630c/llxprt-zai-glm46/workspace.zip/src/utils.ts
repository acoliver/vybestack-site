import type { ReportData, ReportEntry } from './types.js';

/**
 * Validates that the input data conforms to the expected ReportData structure
 */
export function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid data: must be an object');
  }

  const obj = data as Record<string, unknown>;

  if (typeof obj.title !== 'string') {
    throw new Error('Invalid data: title must be a string');
  }

  if (typeof obj.summary !== 'string') {
    throw new Error('Invalid data: summary must be a string');
  }

  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid data: entries must be an array');
  }

  const entries: ReportEntry[] = obj.entries.map((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: must be an object`);
    }

    const entryObj = entry as Record<string, unknown>;
    
    if (typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: label must be a string`);
    }

    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: amount must be a number`);
    }

    if (!Number.isFinite(entryObj.amount)) {
      throw new Error(`Invalid entry at index ${index}: amount must be a finite number`);
    }

    return {
      label: entryObj.label,
      amount: entryObj.amount
    };
  });

  return {
    title: obj.title,
    summary: obj.summary,
    entries
  };
}

/**
 * Calculate the total amount from all entries
 */
export function calculateTotal(entries: ReportEntry[]): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

/**
 * Format a number as a dollar amount with two decimal places
 */
export function formatCurrency(amount: number): string {
  return `$${amount.toFixed(2)}`;
}