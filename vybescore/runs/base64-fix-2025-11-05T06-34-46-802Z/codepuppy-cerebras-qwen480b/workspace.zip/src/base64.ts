/**
 * Encode plain text to Base64 using RFC 4648 standard.
 * Returns canonical Base64 with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8 using RFC 4648 standard.
 * Accepts valid Base64 with or without padding and rejects invalid input.
 */
export function decode(input: string): string {
  if (!input) {
    throw new Error('Input cannot be empty');
  }

  // Basic validation: only allow valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  if (!base64Regex.test(input)) {
    throw new Error('Invalid Base64 format');
  }

  // Validate padding rules
  const paddingIndex = input.indexOf('=');
  if (paddingIndex !== -1) {
    // Padding can only appear at the end
    const padding = input.slice(paddingIndex);
    if (!/^=+$/.test(padding) || padding.length > 2) {
      throw new Error('Invalid Base64 padding');
    }
    // No non-padding characters after padding
    if (paddingIndex + padding.length !== input.length) {
      throw new Error('Invalid Base64 padding');
    }
  }

  // Length must be a multiple of 4 when padded, or when unpadded must also be multiple of 4
  // Actually, let Node.js handle the detailed validation
  try {
    const buffer = Buffer.from(input, 'base64');
    const result = buffer.toString('utf8');
    return result;
  } catch (error) {
    throw new Error('Failed to decode Base64 input');
  }
}
