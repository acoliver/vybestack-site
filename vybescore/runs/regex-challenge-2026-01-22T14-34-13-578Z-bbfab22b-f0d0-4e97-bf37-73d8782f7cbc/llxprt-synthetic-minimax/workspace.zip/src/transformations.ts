// Text transformation functions using regex patterns

/**
 * Capitalizes the first character of each sentence
 * Handles periods, question marks, and exclamation marks
 * Preserves abbreviations when possible
 */
export function capitalizeSentences(text: string): string {
  // Pattern to match sentence endings and beginning of next sentence
  return text.replace(/([.?!]\s*)([a-z])/g, (match, ending, letter) => {
    return ending + letter.toUpperCase();
  }).replace(/^([a-z])/, (match, letter) => letter.toUpperCase());
}

/**
 * Extracts all URLs from text without trailing punctuation
 */
export function extractUrls(text: string): string[] {
  // URL regex pattern - match full URLs until sentence-ending punctuation or space
  const urlPattern = /\b(?:https?|ftp):\/\/[a-zA-Z0-9.-]+(?:\/[a-zA-Z0-9.-]*)?(?=\s|[.,;:!?])/gi;
  const urls = text.match(urlPattern) || [];
  
  // Remove trailing punctuation
  return urls.map(url => {
    let cleanUrl = url;
    // Remove trailing punctuation
    while (/[.,;:!?]$/.test(cleanUrl)) {
      cleanUrl = cleanUrl.slice(0, -1);
    }
    return cleanUrl;
  });
}

/**
 * Converts http:// schemes to https:// while leaving secure URLs untouched
 */
export function enforceHttps(text: string): string {
  return text.replace(/http:\/\//gi, 'https://');
}

/**
 * Rewrites docs URLs with host and scheme changes
 * - Always upgrades scheme to https://
 * - When path begins with /docs/, rewrites host to docs.example.com
 * - Skips host rewrite for dynamic URLs with cgi-bin, query strings, or legacy extensions
 */
export function rewriteDocsUrls(text: string): string {
  return text.replace(/http:\/\/example\.com\/docs\/([a-zA-Z0-9._-]*)/gi, (match, path) => {
    // Check for dynamic hints or legacy extensions (be specific to avoid false matches)
    // Only match extensions with dots or actual query indicators
    const dynamicPatterns = /(cgi-bin|\.(jsp|php|asp|aspx|do|cgi|pl|py)|[?&](?!.*$))/i;
    if (dynamicPatterns.test(match)) {
      // Upgrade scheme only
      return match.replace(/http:\/\//gi, 'https://');
    } else {
      // Upgrade scheme and rewrite host
      return `https://docs.example.com/docs/${path}`;
    }
  });
}

/**
 * Extracts the four-digit year from mm/dd/yyyy format
 * Returns N/A if format doesn't match or dates are invalid
 */
export function extractYear(value: string): string {
  // Pattern for mm/dd/yyyy format
  const datePattern = /^(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01])\/(\d{4})$/;
  const match = value.match(datePattern);
  
  if (!match) {
    return 'N/A';
  }
  
  const month = parseInt(match[1]);
  const day = parseInt(match[2]);
  const yearMatch = match[3];
  
  // Basic validation for month and day
  if (month < 1 || month > 12) {
    return 'N/A';
  }
  
  if (day < 1 || day > 31) {
    return 'N/A';
  }
  
  // Check for valid month/day combination (simple validation)
  if ((month === 4 || month === 6 || month === 9 || month === 11) && day > 30) {
    return 'N/A';
  }
  
  if (month === 2 && day > 29) {
    return 'N/A';
  }
  
  return yearMatch;
}