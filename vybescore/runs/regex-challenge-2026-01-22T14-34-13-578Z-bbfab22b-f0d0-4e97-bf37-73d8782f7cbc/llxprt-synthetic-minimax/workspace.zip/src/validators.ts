// Validators for common data types using regex patterns

/**
 * Validates email addresses
 * Accepts typical addresses such as name@tag@example.co.uk
 * Rejects double dots, trailing dots, domains with underscores
 */
export function isValidEmail(value: string): boolean {
  const emailRegex = /^[a-zA-Z0-9]([a-zA-Z0-9._-]*[a-zA-Z0-9])?@[a-zA-Z0-9]([a-zA-Z0-9.-]*[a-zA-Z0-9])?\.[a-zA-Z]{2,}$/;
  return emailRegex.test(value);
}

/**
 * Validates US phone numbers
 * Supports (212) 555-7890, 212-555-7890, 2125557890, optional +1 prefix
 * Disallows impossible area codes (leading 0/1) and too short inputs
 */
export function isValidUSPhone(value: string, options?: { allowExtension?: boolean }): boolean {
  // Remove all non-digit characters except the leading +
  const cleaned = value.replace(/[^\d+]/g, '');
  
  // Check for +1 prefix
  let phoneNumber = cleaned;
  
  if (cleaned.startsWith('+1')) {
    phoneNumber = cleaned.substring(2);
  } else if (cleaned.startsWith('1') && cleaned.length === 11) {
    phoneNumber = cleaned.substring(1);
  }
  
  // Extract extension if present
  const extensionMatch = phoneNumber.match(/ext\.?\s*(\d+)$/i);
  if (extensionMatch && options?.allowExtension) {
    phoneNumber = phoneNumber.replace(/ext\.?\s*\d+$/i, '');
  }
  
  // Remove any remaining non-digits (should be none)
  phoneNumber = phoneNumber.replace(/\D/g, '');
  
  // Check length
  if (phoneNumber.length !== 10) {
    return false;
  }
  
  // Check area code (first digit cannot be 0 or 1)
  const areaCode = parseInt(phoneNumber.substring(0, 3));
  if (areaCode <= 100 || areaCode >= 999) {
    return false;
  }
  
  // Check if we have a valid format
  const formatRegex = /^\+?1?[\s.-]?(\([2-9]\d{2}\)|[2-9]\d{2})[\s.-]?[2-9]\d{2}[\s.-]?\d{4}$/;
  return formatRegex.test(value);
}

/**
 * Validates Argentine phone numbers
 * Handles landlines and mobiles such as +54 9 11 1234 5678, 011 1234 5678, +54 341 123 4567, 0341 4234567
 */
export function isValidArgentinePhone(value: string): boolean {
  // Remove spaces and normalize
  const cleaned = value.replace(/\s+/g, ' ').trim();
  
  // Pattern to match: country code +54, optional mobile indicator 9, trunk prefix 0, area code, subscriber number
  const regex = /^\+?54\s?(?:9\s?)?(?:0\s?)?([2-9]\d{2,3})\s?(\d{3}\s?\d{3,4})$/;
  const match = cleaned.match(regex);
  
  if (!match) {
    return false;
  }
  
  const areaCode = match[1];
  const subscriberNumber = match[2].replace(/\s/g, '');
  
  // Area code validation (leading digit 1-9)
  const areaCodeDigit = parseInt(areaCode.charAt(0));
  if (areaCodeDigit < 1 || areaCodeDigit > 9) {
    return false;
  }
  
  // Total number validation (area code + subscriber number should be 8-11 digits)
  const totalNumber = areaCode + subscriberNumber;
  if (totalNumber.length < 8 || totalNumber.length > 11) {
    return false;
  }
  
  return true;
}

/**
 * Validates names
 * Permits unicode letters, accents, apostrophes, hyphens, spaces
 * Rejects digits, symbols, and invalid patterns
 */
export function isValidName(value: string): boolean {
  // Allow letters (including unicode), spaces, apostrophes, and hyphens
  // Start with a letter, allow words separated by spaces
  const nameRegex = /^[\p{L}\p{M}]+(?:[\s-][\p{L}\p{M}]+)*$/u;
  return nameRegex.test(value);
}

/**
 * Helper function for Luhn checksum algorithm
 */
function runLuhnCheck(cardNumber: string): boolean {
  const digits = cardNumber.replace(/\D/g, '').split('').map(Number);
  
  let sum = 0;
  let isEven = false;
  
  for (let i = digits.length - 1; i >= 0; i--) {
    let num = digits[i];
    
    if (isEven) {
      num *= 2;
      if (num > 9) {
        num -= 9;
      }
    }
    
    sum += num;
    isEven = !isEven;
  }
  
  return sum % 10 === 0;
}

/**
 * Validates credit card numbers
 * Accepts Visa/Mastercard/AmEx prefixes and lengths
 * Runs Luhn checksum
 */
export function isValidCreditCard(value: string): boolean {
  const cleaned = value.replace(/\D/g, '');
  
  // Length validation for major card types
  if (cleaned.length < 13 || cleaned.length > 19) {
    return false;
  }
  
  // Prefix validation for major card types
  // Visa: starts with 4, length 13, 16, or 19
  if (/^4/.test(cleaned) && (cleaned.length === 13 || cleaned.length === 16 || cleaned.length === 19)) {
    return runLuhnCheck(cleaned);
  }
  
  // Mastercard: starts with 51-55 or 2221-2720, length 16
  if (/^(5[1-5]|2[2-7]\d)/.test(cleaned) && cleaned.length === 16) {
    return runLuhnCheck(cleaned);
  }
  
  // American Express: starts with 34 or 37, length 15
  if (/^(34|37)/.test(cleaned) && cleaned.length === 15) {
    return runLuhnCheck(cleaned);
  }
  
  // Discover: starts with 6011 or 65, length 16
  if (/^(6011|65)/.test(cleaned) && cleaned.length === 16) {
    return runLuhnCheck(cleaned);
  }
  
  // Not a recognized card type
  return false;
}