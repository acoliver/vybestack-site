// Regex puzzle functions

/**
 * Finds words beginning with the prefix but excluding listed exceptions
 */
export function findPrefixedWords(text: string, prefix: string, exceptions: string[]): string[] {
  // Create regex pattern for words starting with prefix
  const pattern = new RegExp(`\\b${prefix}[a-zA-Z]*\\b`, 'g');
  const matches = text.match(pattern) || [];
  
  // Filter out exceptions (case insensitive)
  return matches.filter(word => {
    const lowerWord = word.toLowerCase();
    return !exceptions.some(exc => 
      exc.toLowerCase() === lowerWord
    );
  });
}

/**
 * Returns occurrences where the token appears after a digit
 * and not at the start of the string (use lookaheads/lookbehinds)
 */
export function findEmbeddedToken(text: string, token: string): string[] {
  // Pattern: digit followed by the token, token not at start of string
  const pattern = new RegExp(`(?<!^)\\d(?=${token})`, 'g');
  
  // For each match position, extract the full pattern
  const results: string[] = [];
  
  const match = pattern.exec(text);
  if (match) {
    const startIndex = match.index;
    // Find where the token ends
    const tokenIndex = text.indexOf(token, startIndex);
    if (tokenIndex !== -1) {
      // Extract the full pattern (digit + token)
      const fullPattern = text.substring(startIndex, tokenIndex + token.length);
      results.push(fullPattern);
    }
  }
  
  return results;
}

/**
 * Validates strong password requirements
 * At least 10 characters, one uppercase, one lowercase, one digit, one symbol,
 * no whitespace, no immediate repeated sequences (e.g., abab should fail)
 */
export function isStrongPassword(value: string): boolean {
  // Check minimum length
  if (value.length < 10) {
    return false;
  }
  
  // Check for whitespace
  if (/\s/.test(value)) {
    return false;
  }
  
  // Check for required character types
  if (!/[A-Z]/.test(value)) {
    return false;
  }
  
  if (!/[a-z]/.test(value)) {
    return false;
  }
  
  if (!/\d/.test(value)) {
    return false;
  }
  
  if (!/[!@#$%^&*()_+\-={}[\];':"\\|,.<>?]/.test(value)) {
    return false;
  }
  
  // Check for immediate repeated sequences (like abab, ababab)
  const repeatPattern = /([a-zA-Z]{2})\1/;
  if (repeatPattern.test(value)) {
    return false;
  }
  
  // Check for alternating pattern like abab, ababab
  const altPattern = /([a-zA-Z]{2})\1{2,}/;
  if (altPattern.test(value)) {
    return false;
  }
  
  return true;
}

/**
 * Detects IPv6 addresses (including shorthand ::) 
 * Ensures IPv4 addresses do not trigger a positive result
 */
export function containsIPv6(value: string): boolean {
  // Remove IPv4 addresses (numbers and dots only)
  const ipv4Pattern = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g;
  const withoutIPv4 = value.replace(ipv4Pattern, '');
  
  // IPv6 regex pattern
  // Supports full IPv6 addresses and compressed notation with ::
  const ipv6Pattern = /\b(?:[a-fA-F0-9]{1,4}:){1,7}[a-fA-F0-9]{1,4}\b|\b[a-fA-F0-9]{1,4}::(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{1,4}\b|\b::(?:[a-fA-F0-9]{1,4}:){0,6}[a-fA-F0-9]{1,4}\b|\b[a-fA-F0-9]{1,4}::\b|\b::\b/g;
  
  return ipv6Pattern.test(withoutIPv4);
}