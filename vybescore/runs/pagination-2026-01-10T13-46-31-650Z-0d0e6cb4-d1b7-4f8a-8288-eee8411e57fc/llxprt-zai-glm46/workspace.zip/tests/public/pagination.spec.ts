import { describe, expect, it } from 'vitest';
import request from 'supertest';
import { createApp } from '../../src/server/app';
import { createDatabase } from '../../src/server/db';

describe('inventory API pagination (public)', () => {
  it('returns default page (page=1, limit=5)', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory');
    expect(response.status).toBe(200);
    expect(response.body.page).toBe(1);
    expect(response.body.limit).toBe(5);
    expect(Array.isArray(response.body.items)).toBe(true);
    expect(response.body.items.length).toBeLessThanOrEqual(5);
    expect(typeof response.body.total).toBe('number');
    expect(typeof response.body.hasNext).toBe('boolean');
  });

  it('returns page 2 with correct offset', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response1 = await request(app).get('/inventory?page=1&limit=3');
    const response2 = await request(app).get('/inventory?page=2&limit=3');
    
    expect(response1.status).toBe(200);
    expect(response2.status).toBe(200);
    
    // Ensure items on page 2 are different from page 1
    const idsPage1 = response1.body.items.map((i: { id: number }) => i.id);
    const idsPage2 = response2.body.items.map((i: { id: number }) => i.id);
    const intersection = idsPage1.filter((id: number) => idsPage2.includes(id));
    expect(intersection).toHaveLength(0);
  });

  it('validates non-numeric page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=abc');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid page parameter');
  });

  it('validates non-numeric limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=xyz');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('Invalid limit parameter');
  });

  it('validates zero page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be greater than 0');
  });

  it('validates negative page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=-1');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be greater than 0');
  });

  it('validates zero limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=0');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be greater than 0');
  });

  it('validates excessive limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=1000');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('cannot exceed');
  });

  it('validates decimal page parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=1.5');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be a whole number');
  });

  it('validates decimal limit parameter', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?limit=2.5');
    expect(response.status).toBe(400);
    expect(response.body.error).toContain('must be a whole number');
  });

  it('returns empty items array when page exceeds available data', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    const response = await request(app).get('/inventory?page=9999&limit=5');
    expect(response.status).toBe(200);
    expect(response.body.items).toEqual([]);
    expect(response.body.hasNext).toBe(false);
  });

  it('calculates hasNext correctly', async () => {
    const db = await createDatabase();
    const app = await createApp(db);
    
    const response1 = await request(app).get('/inventory?page=1&limit=3');
    expect(response1.status).toBe(200);
    
    const total = response1.body.total;
    const expectedHasNext = total > 3;
    expect(response1.body.hasNext).toBe(expectedHasNext);
  });
});
