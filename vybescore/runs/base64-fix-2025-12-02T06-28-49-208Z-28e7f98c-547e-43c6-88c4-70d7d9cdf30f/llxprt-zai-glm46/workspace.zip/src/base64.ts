/**
 * Encode plain text to Base64 using the standard Base64 alphabet with proper padding.
 */
export function encode(input: string): string {
  return Buffer.from(input, 'utf8').toString('base64');
}

/**
 * Decode Base64 text back to plain UTF-8.
 * Accepts valid Base64 input (with or without padding) and rejects clearly invalid payloads.
 */
export function decode(input: string): string {
  // Check if input contains only valid Base64 characters
  const base64Regex = /^[A-Za-z0-9+/]*={0,2}$/;
  
  // Remove whitespace characters for more robust handling
  const cleanInput = input.replace(/\s+/g, '');
  
  if (!cleanInput) {
    throw new Error('Input is empty');
  }
  
  // Validate Base64 format
  if (!base64Regex.test(cleanInput)) {
    throw new Error('Invalid Base64 input: contains invalid characters');
  }
  
  // Check padding rules - padding must be at the end only
  const paddingIndex = cleanInput.indexOf('=');
  if (paddingIndex !== -1 && paddingIndex !== cleanInput.lastIndexOf('=')) {
    throw new Error('Invalid Base64 input: padding in wrong position');
  }
  
  // Count padding and check padding rules
  const paddingCount = (cleanInput.match(/=/g) || []).length;
  if (paddingCount > 2) {
    throw new Error('Invalid Base64 input: too much padding');
  }
  
  try {
    // Try to decode using Node.js Buffer - this will handle padding automatically
    return Buffer.from(cleanInput, 'base64').toString('utf8');
  } catch (error) {
    // If Buffer fails, it's invalid Base64
    throw new Error('Failed to decode Base64 input: malformed data');
  }
}