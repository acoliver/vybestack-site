export interface ReportEntry {
  label: string;
  amount: number;
}

export interface Report {
  title: string;
  summary: string;
  entries: ReportEntry[];
}

export interface RenderOptions {
  includeTotals: boolean;
}

export type Format = 'markdown' | 'text';

export interface Formatter {
  render(report: Report, options: RenderOptions): string;
}