import type { Formatter, Report, RenderOptions } from '../types.js';

function formatAmount(amount: number): string {
  return `$${amount.toFixed(2)}`;
}

function calculateTotal(entries: Report['entries']): number {
  return entries.reduce((sum, entry) => sum + entry.amount, 0);
}

export const renderMarkdown: Formatter = {
  render(report: Report, options: RenderOptions): string {
    const lines: string[] = [];
    
    // Title
    lines.push(`# ${report.title}`);
    lines.push('');
    
    // Summary
    lines.push(report.summary);
    lines.push('');
    
    // Entries heading
    lines.push('## Entries');
    
    // Entries list
    for (const entry of report.entries) {
      lines.push(`- **${entry.label}** — ${formatAmount(entry.amount)}`);
    }
    
    // Total if requested
    if (options.includeTotals) {
      lines.push('');
      const total = calculateTotal(report.entries);
      lines.push(`**Total:** ${formatAmount(total)}`);
    }
    
    return lines.join('\n');
  },
};