#!/usr/bin/env node

import fs from 'node:fs';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';
import type { Report, Format, RenderOptions } from '../types.js';

function parseArguments(): { file: string; format: Format; outputPath?: string; includeTotals: boolean } {
  const args = process.argv.slice(2);
  
  let file: string | undefined;
  let format: Format | undefined;
  let outputPath: string | undefined;
  let includeTotals = false;
  
  for (let i = 0; i < args.length; i++) {
    const arg = args[i];
    
    if (arg.startsWith('--format=')) {
      const formatValue = arg.split('=')[1];
      if (formatValue === 'markdown' || formatValue === 'text') {
        format = formatValue;
      } else {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
    } else if (arg === '--format' && i + 1 < args.length) {
      const formatValue = args[i + 1];
      if (formatValue === 'markdown' || formatValue === 'text') {
        format = formatValue;
        i++; // Skip the next argument
      } else {
        throw new Error(`Unsupported format: ${formatValue}`);
      }
    } else if (arg.startsWith('--output=')) {
      outputPath = arg.split('=')[1];
    } else if (arg === '--output' && i + 1 < args.length) {
      outputPath = args[i + 1];
      i++; // Skip the next argument
    } else if (arg === '--includeTotals') {
      includeTotals = true;
    } else if (!arg.startsWith('-') && !file) {
      file = arg;
    }
  }
  
  if (!file) {
    throw new Error('Input file path is required');
  }
  
  if (!format) {
    throw new Error('--format <format> is required (markdown or text)');
  }
  
  return { file, format, outputPath, includeTotals };
}

function validateReport(report: unknown): Report {
  if (!report || typeof report !== 'object') {
    throw new Error('Invalid report: expected object');
  }
  
  const obj = report as Record<string, unknown>;
  
  if (!obj.title || typeof obj.title !== 'string') {
    throw new Error('Invalid report: title (string) is required');
  }
  
  if (!obj.summary || typeof obj.summary !== 'string') {
    throw new Error('Invalid report: summary (string) is required');
  }
  
  if (!Array.isArray(obj.entries)) {
    throw new Error('Invalid report: entries (array) is required');
  }
  
  for (const [index, entry] of obj.entries.entries()) {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid entry at index ${index}: expected object`);
    }
    
    const entryObj = entry as Record<string, unknown>;
    if (!entryObj.label || typeof entryObj.label !== 'string') {
      throw new Error(`Invalid entry at index ${index}: label (string) is required`);
    }
    
    if (typeof entryObj.amount !== 'number') {
      throw new Error(`Invalid entry at index ${index}: amount (number) is required`);
    }
  }
  
  return obj as unknown as Report;
}

function main(): void {
  try {
    const { file, format, outputPath, includeTotals } = parseArguments();
    
    // Read and parse JSON file
    let jsonContent: string;
    try {
      jsonContent = fs.readFileSync(file, 'utf-8');
    } catch (error) {
      throw new Error(`Failed to read file ${file}: ${error instanceof Error ? error.message : String(error)}`);
    }
    
    let report: unknown;
    try {
      report = JSON.parse(jsonContent);
    } catch (error) {
      throw new Error(`Failed to parse JSON: ${error instanceof Error ? error.message : String(error)}`);
    }
    
    // Validate report structure
    const validatedReport = validateReport(report);
    
    // Select formatter
    const formatter = format === 'markdown' ? renderMarkdown : renderText;
    
    // Render report
    const options: RenderOptions = { includeTotals };
    const output = formatter.render(validatedReport, options);
    
    // Write output
    if (outputPath) {
      try {
        fs.writeFileSync(outputPath, output, 'utf-8');
      } catch (error) {
        throw new Error(`Failed to write to ${outputPath}: ${error instanceof Error ? error.message : String(error)}`);
      }
    } else {
      process.stdout.write(output);
    }
  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : String(error)}`);
    process.exit(1);
  }
}

main();
