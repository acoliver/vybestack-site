/**
 * Computed closure implementation for derived values.
 */

import {
  GetterFn,
  UpdateFn,
  Observer,
  updateObserver,
  addObserver,
  notifyObservers,
  EqualFn,
  Subject,
  getActiveObserver
} from '../types/reactive.js'

/**
 * Creates a computed (derived) closure with the
 * supplied function which computes the current value
 * of the closure.
 */
export function createComputed<T>(
  updateFn: UpdateFn<T>,
  value?: T,
  _equal?: boolean | EqualFn<T>,
  options?: { name?: string }
): GetterFn<T> {
  const subject: Subject<T> = {
    name: options?.name,
    value: value,
    observers: new Set()
  }
  
  const o: Observer<T> = {
    name: options?.name,
    value,
    updateFn,
  }
  
  const compute = (): T => {
    updateObserver(o)
    
    // Always notify observers after computation
    notifyObservers(subject)
    
    return o.value!
  }
  
  const wrappedCompute = (): T => {
    // Track observers for dependency tracking
    const observer = getActiveObserver()
    if (observer && observer !== o) {
      addObserver(subject, observer)
    }
    
    return compute()
  }
  
  return wrappedCompute
}
