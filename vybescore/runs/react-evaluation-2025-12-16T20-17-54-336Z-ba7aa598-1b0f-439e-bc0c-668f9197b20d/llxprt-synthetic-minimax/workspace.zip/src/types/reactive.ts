/**
 * Type definitions for the reactive programming system.
 */

export type EqualFn<T> = (lhs: T, rhs: T) => boolean
export type GetterFn<T> = () => T
export type SetterFn<T> = (value: T) => T
export type UnsubscribeFn = () => void
export type UpdateFn<T> = (value?: T) => T

export type InputPair<T> = [GetterFn<T>, SetterFn<T>]

export type Options = {
  name?: string // for debugging
}

export type ObserverR = {
  name?: string
  disposed?: boolean
}

export type ObserverV<T> = {
  value?: T
  updateFn: UpdateFn<T>
}

export type Observer<T> = ObserverR & ObserverV<T>

export type SubjectR = {
  name?: string
  observers?: Set<ObserverR> // Track multiple observers
}

export type SubjectV<T> = {
  value: T
  equalFn?: EqualFn<T>
}

export type Subject<T> = SubjectR & SubjectV<T>

export type ComputedSubject<T> = SubjectR & {
  value?: T
  updateFn: UpdateFn<T>
}

let activeObserver: ObserverR | undefined

export function getActiveObserver(): ObserverR | undefined {
  return activeObserver
}

export function setActiveObserver(observer: ObserverR | undefined): void {
  activeObserver = observer
}

export function updateObserver<T>(observer: Observer<T>): void {
  // Skip disposed observers
  if (observer.disposed) return
  
  const previous = activeObserver
  activeObserver = observer
  try {
    observer.value = observer.updateFn(observer.value)
  } finally {
    activeObserver = previous
  }
}

export function addObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  if (!subject.observers) {
    subject.observers = new Set()
  }
  subject.observers.add(observer)
}

export function removeObserver<T>(subject: Subject<T>, observer: ObserverR): void {
  if (subject.observers) {
    subject.observers.delete(observer)
  }
}

export function notifyObservers<T>(subject: Subject<T>): void {
  if (subject.observers) {
    // Create a copy to avoid issues while iterating
    const observers = Array.from(subject.observers)
    for (const observer of observers) {
      updateObserver(observer as Observer<unknown>)
    }
  }
}
