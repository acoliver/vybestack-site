import { ReportData, ReportOptions, Renderer } from '../types.js';

export const renderMarkdown: Renderer = (data: ReportData, options: ReportOptions): string => {
  const parts: string[] = [];
  
  // Title
  parts.push(`# ${data.title}`);
  parts.push('');
  
  // Summary
  parts.push(data.summary);
  parts.push('');
  
  // Entries section
  parts.push('## Entries');
  
  // Entry bullet points
  data.entries.forEach(entry => {
    const formattedAmount = `$${entry.amount.toFixed(2)}`;
    parts.push(`- **${entry.label}** — ${formattedAmount}`);
  });
  
  // Total if requested
  if (options.includeTotals) {
    const total = data.entries.reduce((sum, entry) => sum + entry.amount, 0);
    const formattedTotal = `$${total.toFixed(2)}`;
    parts.push('');
    parts.push(`**Total:** ${formattedTotal}`);
  }
  
  return parts.join('\n');
};