#!/usr/bin/env node

import { readFileSync, writeFileSync } from 'node:fs';
import { ReportData, ReportOptions } from '../types.js';
import { renderMarkdown } from '../formats/markdown.js';
import { renderText } from '../formats/text.js';

interface ParsedArgs {
  dataFile: string;
  format: string;
  outputPath?: string;
  includeTotals: boolean;
}

function parseArgs(argv: string[]): ParsedArgs {
  const args: ParsedArgs = {
    dataFile: '',
    format: '',
    includeTotals: false
  };

  // Skip node and script path
  const argsList = argv.slice(2);
  
  let i = 0;
  while (i < argsList.length) {
    const arg = argsList[i];
    
    if (!arg.startsWith('--')) {
      // Positional argument - data file
      if (!args.dataFile) {
        args.dataFile = arg;
      }
    } else {
      // Named argument
      switch (arg) {
        case '--format':
          args.format = argsList[i + 1] || '';
          i++; // Skip next arg as it's the value
          break;
        case '--output':
          args.outputPath = argsList[i + 1] || '';
          i++; // Skip next arg as it's the value
          break;
        case '--includeTotals':
          args.includeTotals = true;
          break;
        default:
          // Unknown option
          throw new Error(`Unknown option: ${arg}`);
      }
    }
    i++;
  }

  return args;
}

function validateFormat(format: string): 'markdown' | 'text' {
  const lowerFormat = format.toLowerCase();
  if (lowerFormat === 'markdown' || lowerFormat === 'text') {
    return lowerFormat as 'markdown' | 'text';
  }
  throw new Error(`Unsupported format: ${format}`);
}

function validateReportData(data: unknown): ReportData {
  if (!data || typeof data !== 'object') {
    throw new Error('Invalid JSON: root must be an object');
  }

  const report = data as { title?: unknown; summary?: unknown; entries?: unknown };
  
  if (!report.title || typeof report.title !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "title" field');
  }
  
  if (!report.summary || typeof report.summary !== 'string') {
    throw new Error('Invalid JSON: missing or invalid "summary" field');
  }
  
  if (!report.entries || !Array.isArray(report.entries)) {
    throw new Error('Invalid JSON: missing or invalid "entries" field');
  }

  // Validate entries
  report.entries.forEach((entry, index) => {
    if (!entry || typeof entry !== 'object') {
      throw new Error(`Invalid JSON: entries[${index}] must be an object`);
    }
    
    const reportEntry = entry as { label?: unknown; amount?: unknown };
    
    if (!reportEntry.label || typeof reportEntry.label !== 'string') {
      throw new Error(`Invalid JSON: entries[${index}] missing or invalid "label" field`);
    }
    
    if (reportEntry.amount === undefined || 
        typeof reportEntry.amount !== 'number' ||
        isNaN(reportEntry.amount)) {
      throw new Error(`Invalid JSON: entries[${index}] missing or invalid "amount" field`);
    }
  });

  return data as ReportData;
}

function main() {
  try {
    // Parse command line arguments
    const args = parseArgs(process.argv);
    
    // Validate required arguments
    if (!args.dataFile) {
      console.error('Usage: node dist/cli/report.js <data.json> --format <format> [--output <path>] [--includeTotals]');
      process.exit(1);
    }
    
    if (!args.format) {
      console.error('Error: --format option is required');
      process.exit(1);
    }

    // Validate and normalize format
    const format = validateFormat(args.format);
    
    // Read and parse JSON data
    let rawData: string;
    try {
      rawData = readFileSync(args.dataFile, 'utf-8');
    } catch (error) {
      console.error(`Error reading file "${args.dataFile}": ${error instanceof Error ? error.message : 'unknown error'}`);
      process.exit(1);
    }

    let jsonData: unknown;
    try {
      jsonData = JSON.parse(rawData);
    } catch (error) {
      console.error(`Error parsing JSON: ${error instanceof Error ? error.message : 'invalid JSON'}`);
      process.exit(1);
    }

    // Validate report data structure
    let reportData: ReportData;
    try {
      reportData = validateReportData(jsonData);
    } catch (error) {
      console.error(error instanceof Error ? error.message : 'Invalid report data');
      process.exit(1);
    }

    // Render report
    const options: ReportOptions = {
      format,
      includeTotals: args.includeTotals,
      outputPath: args.outputPath
    };

    const renderers = {
      markdown: renderMarkdown,
      text: renderText
    };

    const renderer = renderers[format];
    const output = renderer(reportData, options);

    // Write output
    if (args.outputPath) {
      try {
        writeFileSync(args.outputPath, output, 'utf-8');
      } catch (error) {
        console.error(`Error writing output file "${args.outputPath}": ${error instanceof Error ? error.message : 'unknown error'}`);
        process.exit(1);
      }
    } else {
      process.stdout.write(output);
    }

  } catch (error) {
    console.error(`Error: ${error instanceof Error ? error.message : 'unknown error'}`);
    process.exit(1);
  }
}

main();
